// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system
   (DDR_0_addr,
    DDR_0_ba,
    DDR_0_cas_n,
    DDR_0_ck_n,
    DDR_0_ck_p,
    DDR_0_cke,
    DDR_0_cs_n,
    DDR_0_dm,
    DDR_0_dq,
    DDR_0_dqs_n,
    DDR_0_dqs_p,
    DDR_0_odt,
    DDR_0_ras_n,
    DDR_0_reset_n,
    DDR_0_we_n,
    FIXED_IO_0_ddr_vrn,
    FIXED_IO_0_ddr_vrp,
    FIXED_IO_0_mio,
    FIXED_IO_0_ps_clk,
    FIXED_IO_0_ps_porb,
    FIXED_IO_0_ps_srstb);
    inout [14:0]DDR_0_addr;
   inout [2:0]DDR_0_ba;
   inout DDR_0_cas_n;
   inout DDR_0_ck_n;
   inout DDR_0_ck_p;
   inout DDR_0_cke;
   inout DDR_0_cs_n;
   inout [3:0]DDR_0_dm;
   inout [31:0]DDR_0_dq;
   inout [3:0]DDR_0_dqs_n;
   inout [3:0]DDR_0_dqs_p;
   inout DDR_0_odt;
   inout DDR_0_ras_n;
   inout DDR_0_reset_n;
   inout DDR_0_we_n;
    inout FIXED_IO_0_ddr_vrn;
   inout FIXED_IO_0_ddr_vrp;
   inout [53:0]FIXED_IO_0_mio;
   inout FIXED_IO_0_ps_clk;
   inout FIXED_IO_0_ps_porb;
   inout FIXED_IO_0_ps_srstb;

  wire [14:0]DDR_0_addr;
  wire [2:0]DDR_0_ba;
  wire DDR_0_cas_n;
  wire DDR_0_ck_n;
  wire DDR_0_ck_p;
  wire DDR_0_cke;
  wire DDR_0_cs_n;
  wire [3:0]DDR_0_dm;
  wire [31:0]DDR_0_dq;
  wire [3:0]DDR_0_dqs_n;
  wire [3:0]DDR_0_dqs_p;
  wire DDR_0_odt;
  wire DDR_0_ras_n;
  wire DDR_0_reset_n;
  wire DDR_0_we_n;
  wire FIXED_IO_0_ddr_vrn;
  wire FIXED_IO_0_ddr_vrp;
  wire [53:0]FIXED_IO_0_mio;
  wire FIXED_IO_0_ps_clk;
  wire FIXED_IO_0_ps_porb;
  wire FIXED_IO_0_ps_srstb;
  wire [63:0]blue_locator_packed_0_m_axi_frame_ARADDR;
  wire [7:0]blue_locator_packed_0_m_axi_frame_ARLEN;
  wire blue_locator_packed_0_m_axi_frame_ARREADY;
  wire blue_locator_packed_0_m_axi_frame_ARVALID;
  wire [31:0]blue_locator_packed_0_m_axi_frame_RDATA;
  wire blue_locator_packed_0_m_axi_frame_RLAST;
  wire blue_locator_packed_0_m_axi_frame_RREADY;
  wire [1:0]blue_locator_packed_0_m_axi_frame_RRESP;
  wire blue_locator_packed_0_m_axi_frame_RVALID;
  wire [63:0]blue_locator_packed_0_m_axi_output_r_AWADDR;
  wire [7:0]blue_locator_packed_0_m_axi_output_r_AWLEN;
  wire blue_locator_packed_0_m_axi_output_r_AWREADY;
  wire blue_locator_packed_0_m_axi_output_r_AWVALID;
  wire blue_locator_packed_0_m_axi_output_r_BREADY;
  wire blue_locator_packed_0_m_axi_output_r_BVALID;
  wire [31:0]blue_locator_packed_0_m_axi_output_r_WDATA;
  wire blue_locator_packed_0_m_axi_output_r_WLAST;
  wire blue_locator_packed_0_m_axi_output_r_WREADY;
  wire [3:0]blue_locator_packed_0_m_axi_output_r_WSTRB;
  wire blue_locator_packed_0_m_axi_output_r_WVALID;
  wire [5:0]control_ic_M00_AXI_ARADDR;
  wire control_ic_M00_AXI_ARREADY;
  wire control_ic_M00_AXI_ARVALID;
  wire [5:0]control_ic_M00_AXI_AWADDR;
  wire control_ic_M00_AXI_AWREADY;
  wire control_ic_M00_AXI_AWVALID;
  wire control_ic_M00_AXI_BREADY;
  wire control_ic_M00_AXI_BVALID;
  wire [31:0]control_ic_M00_AXI_RDATA;
  wire control_ic_M00_AXI_RREADY;
  wire control_ic_M00_AXI_RVALID;
  wire [31:0]control_ic_M00_AXI_WDATA;
  wire control_ic_M00_AXI_WREADY;
  wire [3:0]control_ic_M00_AXI_WSTRB;
  wire control_ic_M00_AXI_WVALID;
  wire [31:0]control_ic_M01_AXI_ARADDR;
  wire [1:0]control_ic_M01_AXI_ARBURST;
  wire [11:0]control_ic_M01_AXI_ARID;
  wire [7:0]control_ic_M01_AXI_ARLEN;
  wire control_ic_M01_AXI_ARREADY;
  wire control_ic_M01_AXI_ARVALID;
  wire [31:0]control_ic_M01_AXI_AWADDR;
  wire [1:0]control_ic_M01_AXI_AWBURST;
  wire [11:0]control_ic_M01_AXI_AWID;
  wire [7:0]control_ic_M01_AXI_AWLEN;
  wire control_ic_M01_AXI_AWREADY;
  wire control_ic_M01_AXI_AWVALID;
  wire [11:0]control_ic_M01_AXI_BID;
  wire control_ic_M01_AXI_BREADY;
  wire [1:0]control_ic_M01_AXI_BRESP;
  wire control_ic_M01_AXI_BVALID;
  wire [31:0]control_ic_M01_AXI_RDATA;
  wire [11:0]control_ic_M01_AXI_RID;
  wire control_ic_M01_AXI_RLAST;
  wire control_ic_M01_AXI_RREADY;
  wire [1:0]control_ic_M01_AXI_RRESP;
  wire control_ic_M01_AXI_RVALID;
  wire [31:0]control_ic_M01_AXI_WDATA;
  wire control_ic_M01_AXI_WLAST;
  wire control_ic_M01_AXI_WREADY;
  wire [3:0]control_ic_M01_AXI_WSTRB;
  wire control_ic_M01_AXI_WVALID;
  wire [16:0]image_bram_ctrl_BRAM_PORTA_ADDR;
  wire image_bram_ctrl_BRAM_PORTA_CLK;
  wire [31:0]image_bram_ctrl_BRAM_PORTA_DIN;
  wire [31:0]image_bram_ctrl_BRAM_PORTA_DOUT;
  wire image_bram_ctrl_BRAM_PORTA_EN;
  wire [3:0]image_bram_ctrl_BRAM_PORTA_WE;
  wire [16:0]memory_ic_M00_AXI_ARADDR;
  wire [1:0]memory_ic_M00_AXI_ARBURST;
  wire [13:0]memory_ic_M00_AXI_ARID;
  wire [7:0]memory_ic_M00_AXI_ARLEN;
  wire memory_ic_M00_AXI_ARREADY;
  wire memory_ic_M00_AXI_ARVALID;
  wire [16:0]memory_ic_M00_AXI_AWADDR;
  wire [1:0]memory_ic_M00_AXI_AWBURST;
  wire [13:0]memory_ic_M00_AXI_AWID;
  wire [7:0]memory_ic_M00_AXI_AWLEN;
  wire memory_ic_M00_AXI_AWREADY;
  wire memory_ic_M00_AXI_AWVALID;
  wire [13:0]memory_ic_M00_AXI_BID;
  wire memory_ic_M00_AXI_BREADY;
  wire memory_ic_M00_AXI_BVALID;
  wire [31:0]memory_ic_M00_AXI_RDATA;
  wire [13:0]memory_ic_M00_AXI_RID;
  wire memory_ic_M00_AXI_RLAST;
  wire memory_ic_M00_AXI_RREADY;
  wire memory_ic_M00_AXI_RVALID;
  wire [31:0]memory_ic_M00_AXI_WDATA;
  wire memory_ic_M00_AXI_WLAST;
  wire memory_ic_M00_AXI_WREADY;
  wire [3:0]memory_ic_M00_AXI_WSTRB;
  wire memory_ic_M00_AXI_WVALID;
  wire ps7_0_FCLK_CLK0;
  wire ps7_0_FCLK_RESET0_N;
  wire [31:0]ps7_0_M_AXI_GP0_ARADDR;
  wire [1:0]ps7_0_M_AXI_GP0_ARBURST;
  wire [11:0]ps7_0_M_AXI_GP0_ARID;
  wire [3:0]ps7_0_M_AXI_GP0_ARLEN;
  wire ps7_0_M_AXI_GP0_ARREADY;
  wire [2:0]ps7_0_M_AXI_GP0_ARSIZE;
  wire ps7_0_M_AXI_GP0_ARVALID;
  wire [31:0]ps7_0_M_AXI_GP0_AWADDR;
  wire [1:0]ps7_0_M_AXI_GP0_AWBURST;
  wire [11:0]ps7_0_M_AXI_GP0_AWID;
  wire [3:0]ps7_0_M_AXI_GP0_AWLEN;
  wire ps7_0_M_AXI_GP0_AWREADY;
  wire [2:0]ps7_0_M_AXI_GP0_AWSIZE;
  wire ps7_0_M_AXI_GP0_AWVALID;
  wire [11:0]ps7_0_M_AXI_GP0_BID;
  wire ps7_0_M_AXI_GP0_BREADY;
  wire [1:0]ps7_0_M_AXI_GP0_BRESP;
  wire ps7_0_M_AXI_GP0_BVALID;
  wire [31:0]ps7_0_M_AXI_GP0_RDATA;
  wire [11:0]ps7_0_M_AXI_GP0_RID;
  wire ps7_0_M_AXI_GP0_RLAST;
  wire ps7_0_M_AXI_GP0_RREADY;
  wire [1:0]ps7_0_M_AXI_GP0_RRESP;
  wire ps7_0_M_AXI_GP0_RVALID;
  wire [31:0]ps7_0_M_AXI_GP0_WDATA;
  wire ps7_0_M_AXI_GP0_WLAST;
  wire ps7_0_M_AXI_GP0_WREADY;
  wire [3:0]ps7_0_M_AXI_GP0_WSTRB;
  wire ps7_0_M_AXI_GP0_WVALID;
  wire reset_0_interconnect_aresetn;
  wire reset_0_peripheral_aresetn;
  wire [63:0]NLW_blue_locator_packed_0_m_axi_frame_ARADDR_UNCONNECTED;
  wire [63:0]NLW_blue_locator_packed_0_m_axi_output_r_AWADDR_UNCONNECTED;
  wire [31:0]NLW_control_ic_M01_AXI_araddr_UNCONNECTED;
  wire [31:0]NLW_control_ic_M01_AXI_awaddr_UNCONNECTED;
  wire [31:0]NLW_image_bram_addra_UNCONNECTED;
  wire [16:0]NLW_image_bram_ctrl_bram_addr_a_UNCONNECTED;
  wire [16:0]NLW_image_bram_ctrl_s_axi_araddr_UNCONNECTED;
  wire [16:0]NLW_image_bram_ctrl_s_axi_awaddr_UNCONNECTED;
  wire [13:0]NLW_image_bram_ctrl_s_axi_awid_UNCONNECTED;
  wire [13:0]NLW_image_bram_ctrl_s_axi_bid_UNCONNECTED;
  wire [63:0]NLW_memory_ic_M00_AXI_araddr_UNCONNECTED;
  wire [63:0]NLW_memory_ic_M00_AXI_awaddr_UNCONNECTED;
  wire [13:0]NLW_memory_ic_M00_AXI_awid_UNCONNECTED;
  wire [13:0]NLW_memory_ic_M00_AXI_bid_UNCONNECTED;
  wire [31:0]NLW_memory_ic_S00_AXI_araddr_UNCONNECTED;
  wire [31:0]NLW_memory_ic_S00_AXI_awaddr_UNCONNECTED;
  wire [63:0]NLW_memory_ic_S01_AXI_araddr_UNCONNECTED;
  wire [63:0]NLW_memory_ic_S02_AXI_awaddr_UNCONNECTED;

  system_blue_locator_packed_0_0 blue_locator_packed_0
       (.ap_clk(ps7_0_FCLK_CLK0),
        .ap_rst_n(reset_0_peripheral_aresetn),
        .m_axi_frame_ARADDR({blue_locator_packed_0_m_axi_frame_ARADDR[63:2],NLW_blue_locator_packed_0_m_axi_frame_ARADDR_UNCONNECTED[1:0]}),
        .m_axi_frame_ARLEN(blue_locator_packed_0_m_axi_frame_ARLEN[3:0]),
        .m_axi_frame_ARREADY(blue_locator_packed_0_m_axi_frame_ARREADY),
        .m_axi_frame_ARVALID(blue_locator_packed_0_m_axi_frame_ARVALID),
        .m_axi_frame_RDATA(blue_locator_packed_0_m_axi_frame_RDATA),
        .m_axi_frame_RLAST(blue_locator_packed_0_m_axi_frame_RLAST),
        .m_axi_frame_RREADY(blue_locator_packed_0_m_axi_frame_RREADY),
        .m_axi_frame_RRESP(blue_locator_packed_0_m_axi_frame_RRESP),
        .m_axi_frame_RVALID(blue_locator_packed_0_m_axi_frame_RVALID),
        .m_axi_output_r_AWADDR({blue_locator_packed_0_m_axi_output_r_AWADDR[63:2],NLW_blue_locator_packed_0_m_axi_output_r_AWADDR_UNCONNECTED[1:0]}),
        .m_axi_output_r_AWLEN(blue_locator_packed_0_m_axi_output_r_AWLEN[3:0]),
        .m_axi_output_r_AWREADY(blue_locator_packed_0_m_axi_output_r_AWREADY),
        .m_axi_output_r_AWVALID(blue_locator_packed_0_m_axi_output_r_AWVALID),
        .m_axi_output_r_BREADY(blue_locator_packed_0_m_axi_output_r_BREADY),
        .m_axi_output_r_BVALID(blue_locator_packed_0_m_axi_output_r_BVALID),
        .m_axi_output_r_WDATA(blue_locator_packed_0_m_axi_output_r_WDATA),
        .m_axi_output_r_WLAST(blue_locator_packed_0_m_axi_output_r_WLAST),
        .m_axi_output_r_WREADY(blue_locator_packed_0_m_axi_output_r_WREADY),
        .m_axi_output_r_WSTRB(blue_locator_packed_0_m_axi_output_r_WSTRB),
        .m_axi_output_r_WVALID(blue_locator_packed_0_m_axi_output_r_WVALID),
        .s_axi_control_ARADDR(control_ic_M00_AXI_ARADDR),
        .s_axi_control_ARREADY(control_ic_M00_AXI_ARREADY),
        .s_axi_control_ARVALID(control_ic_M00_AXI_ARVALID),
        .s_axi_control_AWADDR(control_ic_M00_AXI_AWADDR),
        .s_axi_control_AWREADY(control_ic_M00_AXI_AWREADY),
        .s_axi_control_AWVALID(control_ic_M00_AXI_AWVALID),
        .s_axi_control_BREADY(control_ic_M00_AXI_BREADY),
        .s_axi_control_BVALID(control_ic_M00_AXI_BVALID),
        .s_axi_control_RDATA(control_ic_M00_AXI_RDATA),
        .s_axi_control_RREADY(control_ic_M00_AXI_RREADY),
        .s_axi_control_RVALID(control_ic_M00_AXI_RVALID),
        .s_axi_control_WDATA(control_ic_M00_AXI_WDATA),
        .s_axi_control_WREADY(control_ic_M00_AXI_WREADY),
        .s_axi_control_WSTRB(control_ic_M00_AXI_WSTRB),
        .s_axi_control_WVALID(control_ic_M00_AXI_WVALID));
  system_control_ic_0 control_ic
       (.ARESETN(reset_0_interconnect_aresetn),
        .M00_AXI_araddr(control_ic_M00_AXI_ARADDR),
        .M00_AXI_arready(control_ic_M00_AXI_ARREADY),
        .M00_AXI_arvalid(control_ic_M00_AXI_ARVALID),
        .M00_AXI_awaddr(control_ic_M00_AXI_AWADDR),
        .M00_AXI_awready(control_ic_M00_AXI_AWREADY),
        .M00_AXI_awvalid(control_ic_M00_AXI_AWVALID),
        .M00_AXI_bready(control_ic_M00_AXI_BREADY),
        .M00_AXI_bvalid(control_ic_M00_AXI_BVALID),
        .M00_AXI_rdata(control_ic_M00_AXI_RDATA),
        .M00_AXI_rready(control_ic_M00_AXI_RREADY),
        .M00_AXI_rvalid(control_ic_M00_AXI_RVALID),
        .M00_AXI_wdata(control_ic_M00_AXI_WDATA),
        .M00_AXI_wready(control_ic_M00_AXI_WREADY),
        .M00_AXI_wstrb(control_ic_M00_AXI_WSTRB),
        .M00_AXI_wvalid(control_ic_M00_AXI_WVALID),
        .M01_AXI_araddr({control_ic_M01_AXI_ARADDR[31:2],NLW_control_ic_M01_AXI_araddr_UNCONNECTED[1:0]}),
        .M01_AXI_arburst(control_ic_M01_AXI_ARBURST),
        .M01_AXI_arid(control_ic_M01_AXI_ARID),
        .M01_AXI_arlen(control_ic_M01_AXI_ARLEN[3:0]),
        .M01_AXI_arready(control_ic_M01_AXI_ARREADY),
        .M01_AXI_arvalid(control_ic_M01_AXI_ARVALID),
        .M01_AXI_awaddr({control_ic_M01_AXI_AWADDR[31:2],NLW_control_ic_M01_AXI_awaddr_UNCONNECTED[1:0]}),
        .M01_AXI_awburst(control_ic_M01_AXI_AWBURST),
        .M01_AXI_awid(control_ic_M01_AXI_AWID),
        .M01_AXI_awlen(control_ic_M01_AXI_AWLEN[3:0]),
        .M01_AXI_awready(control_ic_M01_AXI_AWREADY),
        .M01_AXI_awvalid(control_ic_M01_AXI_AWVALID),
        .M01_AXI_bid(control_ic_M01_AXI_BID),
        .M01_AXI_bready(control_ic_M01_AXI_BREADY),
        .M01_AXI_bresp(control_ic_M01_AXI_BRESP),
        .M01_AXI_bvalid(control_ic_M01_AXI_BVALID),
        .M01_AXI_rdata(control_ic_M01_AXI_RDATA),
        .M01_AXI_rid(control_ic_M01_AXI_RID),
        .M01_AXI_rlast(control_ic_M01_AXI_RLAST),
        .M01_AXI_rready(control_ic_M01_AXI_RREADY),
        .M01_AXI_rresp(control_ic_M01_AXI_RRESP),
        .M01_AXI_rvalid(control_ic_M01_AXI_RVALID),
        .M01_AXI_wdata(control_ic_M01_AXI_WDATA),
        .M01_AXI_wlast(control_ic_M01_AXI_WLAST),
        .M01_AXI_wready(control_ic_M01_AXI_WREADY),
        .M01_AXI_wstrb(control_ic_M01_AXI_WSTRB),
        .M01_AXI_wvalid(control_ic_M01_AXI_WVALID),
        .S00_ACLK(ps7_0_FCLK_CLK0),
        .S00_AXI_araddr(ps7_0_M_AXI_GP0_ARADDR),
        .S00_AXI_arburst(ps7_0_M_AXI_GP0_ARBURST),
        .S00_AXI_arid(ps7_0_M_AXI_GP0_ARID),
        .S00_AXI_arlen(ps7_0_M_AXI_GP0_ARLEN),
        .S00_AXI_arready(ps7_0_M_AXI_GP0_ARREADY),
        .S00_AXI_arsize(ps7_0_M_AXI_GP0_ARSIZE[1:0]),
        .S00_AXI_arvalid(ps7_0_M_AXI_GP0_ARVALID),
        .S00_AXI_awaddr(ps7_0_M_AXI_GP0_AWADDR),
        .S00_AXI_awburst(ps7_0_M_AXI_GP0_AWBURST),
        .S00_AXI_awid(ps7_0_M_AXI_GP0_AWID),
        .S00_AXI_awlen(ps7_0_M_AXI_GP0_AWLEN),
        .S00_AXI_awready(ps7_0_M_AXI_GP0_AWREADY),
        .S00_AXI_awsize(ps7_0_M_AXI_GP0_AWSIZE[1:0]),
        .S00_AXI_awvalid(ps7_0_M_AXI_GP0_AWVALID),
        .S00_AXI_bid(ps7_0_M_AXI_GP0_BID),
        .S00_AXI_bready(ps7_0_M_AXI_GP0_BREADY),
        .S00_AXI_bresp(ps7_0_M_AXI_GP0_BRESP),
        .S00_AXI_bvalid(ps7_0_M_AXI_GP0_BVALID),
        .S00_AXI_rdata(ps7_0_M_AXI_GP0_RDATA),
        .S00_AXI_rid(ps7_0_M_AXI_GP0_RID),
        .S00_AXI_rlast(ps7_0_M_AXI_GP0_RLAST),
        .S00_AXI_rready(ps7_0_M_AXI_GP0_RREADY),
        .S00_AXI_rresp(ps7_0_M_AXI_GP0_RRESP),
        .S00_AXI_rvalid(ps7_0_M_AXI_GP0_RVALID),
        .S00_AXI_wdata(ps7_0_M_AXI_GP0_WDATA),
        .S00_AXI_wlast(ps7_0_M_AXI_GP0_WLAST),
        .S00_AXI_wready(ps7_0_M_AXI_GP0_WREADY),
        .S00_AXI_wstrb(ps7_0_M_AXI_GP0_WSTRB),
        .S00_AXI_wvalid(ps7_0_M_AXI_GP0_WVALID));

  system_image_bram_0 image_bram
       (.addra({image_bram_ctrl_BRAM_PORTA_ADDR[16:2],NLW_image_bram_addra_UNCONNECTED[1:0]}),
        .clka(image_bram_ctrl_BRAM_PORTA_CLK),
        .dina(image_bram_ctrl_BRAM_PORTA_DIN),
        .douta(image_bram_ctrl_BRAM_PORTA_DOUT),
        .ena(image_bram_ctrl_BRAM_PORTA_EN),
        .lopt(reset_0_peripheral_aresetn),
        .wea(image_bram_ctrl_BRAM_PORTA_WE));

  system_image_bram_ctrl_0 image_bram_ctrl
       (.bram_addr_a({image_bram_ctrl_BRAM_PORTA_ADDR[16:2],NLW_image_bram_ctrl_bram_addr_a_UNCONNECTED[1:0]}),
        .bram_clk_a(image_bram_ctrl_BRAM_PORTA_CLK),
        .bram_en_a(image_bram_ctrl_BRAM_PORTA_EN),
        .bram_rddata_a(image_bram_ctrl_BRAM_PORTA_DOUT),
        .bram_we_a(image_bram_ctrl_BRAM_PORTA_WE),
        .bram_wrdata_a(image_bram_ctrl_BRAM_PORTA_DIN),
        .s_axi_aclk(ps7_0_FCLK_CLK0),
        .s_axi_araddr({memory_ic_M00_AXI_ARADDR[16:2],NLW_image_bram_ctrl_s_axi_araddr_UNCONNECTED[1:0]}),
        .s_axi_arburst(memory_ic_M00_AXI_ARBURST),
        .s_axi_aresetn(reset_0_peripheral_aresetn),
        .s_axi_arid(memory_ic_M00_AXI_ARID[12:0]),
        .s_axi_arlen(memory_ic_M00_AXI_ARLEN[3:0]),
        .s_axi_arready(memory_ic_M00_AXI_ARREADY),
        .s_axi_arvalid(memory_ic_M00_AXI_ARVALID),
        .s_axi_awaddr({memory_ic_M00_AXI_AWADDR[16:2],NLW_image_bram_ctrl_s_axi_awaddr_UNCONNECTED[1:0]}),
        .s_axi_awburst(memory_ic_M00_AXI_AWBURST),
        .s_axi_awid({memory_ic_M00_AXI_AWID[13],NLW_image_bram_ctrl_s_axi_awid_UNCONNECTED[12],memory_ic_M00_AXI_AWID[11:0]}),
        .s_axi_awlen(memory_ic_M00_AXI_AWLEN[3:0]),
        .s_axi_awready(memory_ic_M00_AXI_AWREADY),
        .s_axi_awvalid(memory_ic_M00_AXI_AWVALID),
        .s_axi_bid({memory_ic_M00_AXI_BID[13],NLW_image_bram_ctrl_s_axi_bid_UNCONNECTED[12],memory_ic_M00_AXI_BID[11:0]}),
        .s_axi_bready(memory_ic_M00_AXI_BREADY),
        .s_axi_bvalid(memory_ic_M00_AXI_BVALID),
        .s_axi_rdata(memory_ic_M00_AXI_RDATA),
        .s_axi_rid(memory_ic_M00_AXI_RID[12:0]),
        .s_axi_rlast(memory_ic_M00_AXI_RLAST),
        .s_axi_rready(memory_ic_M00_AXI_RREADY),
        .s_axi_rvalid(memory_ic_M00_AXI_RVALID),
        .s_axi_wdata(memory_ic_M00_AXI_WDATA),
        .s_axi_wlast(memory_ic_M00_AXI_WLAST),
        .s_axi_wready(memory_ic_M00_AXI_WREADY),
        .s_axi_wstrb(memory_ic_M00_AXI_WSTRB),
        .s_axi_wvalid(memory_ic_M00_AXI_WVALID));
  system_memory_ic_0 memory_ic
       (.ACLK(ps7_0_FCLK_CLK0),
        .ARESETN(reset_0_interconnect_aresetn),
        .M00_AXI_araddr({memory_ic_M00_AXI_ARADDR[16:2],NLW_memory_ic_M00_AXI_araddr_UNCONNECTED[1:0]}),
        .M00_AXI_arburst(memory_ic_M00_AXI_ARBURST),
        .M00_AXI_arid(memory_ic_M00_AXI_ARID[12:0]),
        .M00_AXI_arlen(memory_ic_M00_AXI_ARLEN[3:0]),
        .M00_AXI_arready(memory_ic_M00_AXI_ARREADY),
        .M00_AXI_arvalid(memory_ic_M00_AXI_ARVALID),
        .M00_AXI_awaddr({memory_ic_M00_AXI_AWADDR[16:2],NLW_memory_ic_M00_AXI_awaddr_UNCONNECTED[1:0]}),
        .M00_AXI_awburst(memory_ic_M00_AXI_AWBURST),
        .M00_AXI_awid({memory_ic_M00_AXI_AWID[13],NLW_memory_ic_M00_AXI_awid_UNCONNECTED[12],memory_ic_M00_AXI_AWID[11:0]}),
        .M00_AXI_awlen(memory_ic_M00_AXI_AWLEN[3:0]),
        .M00_AXI_awready(memory_ic_M00_AXI_AWREADY),
        .M00_AXI_awvalid(memory_ic_M00_AXI_AWVALID),
        .M00_AXI_bid({memory_ic_M00_AXI_BID[13],NLW_memory_ic_M00_AXI_bid_UNCONNECTED[12],memory_ic_M00_AXI_BID[11:0]}),
        .M00_AXI_bready(memory_ic_M00_AXI_BREADY),
        .M00_AXI_bvalid(memory_ic_M00_AXI_BVALID),
        .M00_AXI_rdata(memory_ic_M00_AXI_RDATA),
        .M00_AXI_rid(memory_ic_M00_AXI_RID[12:0]),
        .M00_AXI_rlast(memory_ic_M00_AXI_RLAST),
        .M00_AXI_rready(memory_ic_M00_AXI_RREADY),
        .M00_AXI_rvalid(memory_ic_M00_AXI_RVALID),
        .M00_AXI_wdata(memory_ic_M00_AXI_WDATA),
        .M00_AXI_wlast(memory_ic_M00_AXI_WLAST),
        .M00_AXI_wready(memory_ic_M00_AXI_WREADY),
        .M00_AXI_wstrb(memory_ic_M00_AXI_WSTRB),
        .M00_AXI_wvalid(memory_ic_M00_AXI_WVALID),
        .S00_AXI_araddr({control_ic_M01_AXI_ARADDR[31:2],NLW_memory_ic_S00_AXI_araddr_UNCONNECTED[1:0]}),
        .S00_AXI_arburst(control_ic_M01_AXI_ARBURST),
        .S00_AXI_arid(control_ic_M01_AXI_ARID),
        .S00_AXI_arlen(control_ic_M01_AXI_ARLEN[3:0]),
        .S00_AXI_arready(control_ic_M01_AXI_ARREADY),
        .S00_AXI_arvalid(control_ic_M01_AXI_ARVALID),
        .S00_AXI_awaddr({control_ic_M01_AXI_AWADDR[31:2],NLW_memory_ic_S00_AXI_awaddr_UNCONNECTED[1:0]}),
        .S00_AXI_awburst(control_ic_M01_AXI_AWBURST),
        .S00_AXI_awid(control_ic_M01_AXI_AWID),
        .S00_AXI_awlen(control_ic_M01_AXI_AWLEN[3:0]),
        .S00_AXI_awready(control_ic_M01_AXI_AWREADY),
        .S00_AXI_awvalid(control_ic_M01_AXI_AWVALID),
        .S00_AXI_bid(control_ic_M01_AXI_BID),
        .S00_AXI_bready(control_ic_M01_AXI_BREADY),
        .S00_AXI_bresp(control_ic_M01_AXI_BRESP),
        .S00_AXI_bvalid(control_ic_M01_AXI_BVALID),
        .S00_AXI_rdata(control_ic_M01_AXI_RDATA),
        .S00_AXI_rid(control_ic_M01_AXI_RID),
        .S00_AXI_rlast(control_ic_M01_AXI_RLAST),
        .S00_AXI_rready(control_ic_M01_AXI_RREADY),
        .S00_AXI_rresp(control_ic_M01_AXI_RRESP),
        .S00_AXI_rvalid(control_ic_M01_AXI_RVALID),
        .S00_AXI_wdata(control_ic_M01_AXI_WDATA),
        .S00_AXI_wlast(control_ic_M01_AXI_WLAST),
        .S00_AXI_wready(control_ic_M01_AXI_WREADY),
        .S00_AXI_wstrb(control_ic_M01_AXI_WSTRB),
        .S00_AXI_wvalid(control_ic_M01_AXI_WVALID),
        .S01_AXI_araddr({blue_locator_packed_0_m_axi_frame_ARADDR[63:2],NLW_memory_ic_S01_AXI_araddr_UNCONNECTED[1:0]}),
        .S01_AXI_arlen(blue_locator_packed_0_m_axi_frame_ARLEN[3:0]),
        .S01_AXI_arready(blue_locator_packed_0_m_axi_frame_ARREADY),
        .S01_AXI_arvalid(blue_locator_packed_0_m_axi_frame_ARVALID),
        .S01_AXI_rdata(blue_locator_packed_0_m_axi_frame_RDATA),
        .S01_AXI_rlast(blue_locator_packed_0_m_axi_frame_RLAST),
        .S01_AXI_rready(blue_locator_packed_0_m_axi_frame_RREADY),
        .S01_AXI_rresp(blue_locator_packed_0_m_axi_frame_RRESP),
        .S01_AXI_rvalid(blue_locator_packed_0_m_axi_frame_RVALID),
        .S02_AXI_awaddr({blue_locator_packed_0_m_axi_output_r_AWADDR[63:2],NLW_memory_ic_S02_AXI_awaddr_UNCONNECTED[1:0]}),
        .S02_AXI_awlen(blue_locator_packed_0_m_axi_output_r_AWLEN[3:0]),
        .S02_AXI_awready(blue_locator_packed_0_m_axi_output_r_AWREADY),
        .S02_AXI_awvalid(blue_locator_packed_0_m_axi_output_r_AWVALID),
        .S02_AXI_bready(blue_locator_packed_0_m_axi_output_r_BREADY),
        .S02_AXI_bvalid(blue_locator_packed_0_m_axi_output_r_BVALID),
        .S02_AXI_wdata(blue_locator_packed_0_m_axi_output_r_WDATA),
        .S02_AXI_wlast(blue_locator_packed_0_m_axi_output_r_WLAST),
        .S02_AXI_wready(blue_locator_packed_0_m_axi_output_r_WREADY),
        .S02_AXI_wstrb(blue_locator_packed_0_m_axi_output_r_WSTRB),
        .S02_AXI_wvalid(blue_locator_packed_0_m_axi_output_r_WVALID));

  system_ps7_0_0 ps7_0
       (.DDR_Addr(DDR_0_addr),
        .DDR_BankAddr(DDR_0_ba),
        .DDR_CAS_n(DDR_0_cas_n),
        .DDR_CKE(DDR_0_cke),
        .DDR_CS_n(DDR_0_cs_n),
        .DDR_Clk(DDR_0_ck_p),
        .DDR_Clk_n(DDR_0_ck_n),
        .DDR_DM(DDR_0_dm),
        .DDR_DQ(DDR_0_dq),
        .DDR_DQS(DDR_0_dqs_p),
        .DDR_DQS_n(DDR_0_dqs_n),
        .DDR_DRSTB(DDR_0_reset_n),
        .DDR_ODT(DDR_0_odt),
        .DDR_RAS_n(DDR_0_ras_n),
        .DDR_VRN(FIXED_IO_0_ddr_vrn),
        .DDR_VRP(FIXED_IO_0_ddr_vrp),
        .DDR_WEB(DDR_0_we_n),
        .FCLK_CLK0(ps7_0_FCLK_CLK0),
        .FCLK_RESET0_N(ps7_0_FCLK_RESET0_N),
        .MIO(FIXED_IO_0_mio),
        .M_AXI_GP0_ACLK(ps7_0_FCLK_CLK0),
        .M_AXI_GP0_ARADDR(ps7_0_M_AXI_GP0_ARADDR),
        .M_AXI_GP0_ARBURST(ps7_0_M_AXI_GP0_ARBURST),
        .M_AXI_GP0_ARID(ps7_0_M_AXI_GP0_ARID),
        .M_AXI_GP0_ARLEN(ps7_0_M_AXI_GP0_ARLEN),
        .M_AXI_GP0_ARREADY(ps7_0_M_AXI_GP0_ARREADY),
        .M_AXI_GP0_ARSIZE(ps7_0_M_AXI_GP0_ARSIZE[1:0]),
        .M_AXI_GP0_ARVALID(ps7_0_M_AXI_GP0_ARVALID),
        .M_AXI_GP0_AWADDR(ps7_0_M_AXI_GP0_AWADDR),
        .M_AXI_GP0_AWBURST(ps7_0_M_AXI_GP0_AWBURST),
        .M_AXI_GP0_AWID(ps7_0_M_AXI_GP0_AWID),
        .M_AXI_GP0_AWLEN(ps7_0_M_AXI_GP0_AWLEN),
        .M_AXI_GP0_AWREADY(ps7_0_M_AXI_GP0_AWREADY),
        .M_AXI_GP0_AWSIZE(ps7_0_M_AXI_GP0_AWSIZE[1:0]),
        .M_AXI_GP0_AWVALID(ps7_0_M_AXI_GP0_AWVALID),
        .M_AXI_GP0_BID(ps7_0_M_AXI_GP0_BID),
        .M_AXI_GP0_BREADY(ps7_0_M_AXI_GP0_BREADY),
        .M_AXI_GP0_BRESP(ps7_0_M_AXI_GP0_BRESP),
        .M_AXI_GP0_BVALID(ps7_0_M_AXI_GP0_BVALID),
        .M_AXI_GP0_RDATA(ps7_0_M_AXI_GP0_RDATA),
        .M_AXI_GP0_RID(ps7_0_M_AXI_GP0_RID),
        .M_AXI_GP0_RLAST(ps7_0_M_AXI_GP0_RLAST),
        .M_AXI_GP0_RREADY(ps7_0_M_AXI_GP0_RREADY),
        .M_AXI_GP0_RRESP(ps7_0_M_AXI_GP0_RRESP),
        .M_AXI_GP0_RVALID(ps7_0_M_AXI_GP0_RVALID),
        .M_AXI_GP0_WDATA(ps7_0_M_AXI_GP0_WDATA),
        .M_AXI_GP0_WLAST(ps7_0_M_AXI_GP0_WLAST),
        .M_AXI_GP0_WREADY(ps7_0_M_AXI_GP0_WREADY),
        .M_AXI_GP0_WSTRB(ps7_0_M_AXI_GP0_WSTRB),
        .M_AXI_GP0_WVALID(ps7_0_M_AXI_GP0_WVALID),
        .PS_CLK(FIXED_IO_0_ps_clk),
        .PS_PORB(FIXED_IO_0_ps_porb),
        .PS_SRSTB(FIXED_IO_0_ps_srstb));

  system_reset_0_0 reset_0
       (.ext_reset_in(ps7_0_FCLK_RESET0_N),
        .interconnect_aresetn(reset_0_interconnect_aresetn),
        .peripheral_aresetn(reset_0_peripheral_aresetn),
        .slowest_sync_clk(ps7_0_FCLK_CLK0));
endmodule

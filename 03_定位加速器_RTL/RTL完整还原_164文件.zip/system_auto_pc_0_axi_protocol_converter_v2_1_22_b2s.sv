// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s
   (s_axi_bvalid,
    s_axi_awready,
    s_axi_arready,
    Q,
    esc_m_payload_i_reg_34_a1cd3d0 ,
    esc_m_payload_i_reg_13_5fdb661 ,
    s_axi_rvalid,
    esc_m_payload_i_reg_46_022e045 ,
    m_axi_awvalid,
    m_axi_bready,
    m_axi_arvalid,
    m_axi_rready,
    m_axi_awaddr,
    m_axi_araddr,
    s_axi_bready,
    s_axi_awvalid,
    s_axi_arvalid,
    aclk,
    in,
    s_axi_awid,
    s_axi_awlen,
    s_axi_awburst,
    s_axi_awsize,
    s_axi_awprot,
    s_axi_awaddr,
    m_axi_bresp,
    s_axi_arid,
    s_axi_arlen,
    s_axi_arburst,
    s_axi_arsize,
    s_axi_arprot,
    s_axi_araddr,
    m_axi_arready,
    m_axi_awready,
    m_axi_bvalid,
    s_axi_rready,
    m_axi_rvalid,
    aresetn);
  output s_axi_bvalid;
  output s_axi_awready;
  output s_axi_arready;
  output [22:0]Q;
  output [22:0]esc_m_payload_i_reg_34_a1cd3d0 ;
  output [13:0]esc_m_payload_i_reg_13_5fdb661 ;
  output s_axi_rvalid;
  output [46:0]esc_m_payload_i_reg_46_022e045 ;
  output m_axi_awvalid;
  output m_axi_bready;
  output m_axi_arvalid;
  output m_axi_rready;
  output [11:0]m_axi_awaddr;
  output [11:0]m_axi_araddr;
  input s_axi_bready;
  input s_axi_awvalid;
  input s_axi_arvalid;
  input aclk;
  input [33:0]in;
  input [11:0]s_axi_awid;
  input [7:0]s_axi_awlen;
  input [1:0]s_axi_awburst;
  input [1:0]s_axi_awsize;
  input [2:0]s_axi_awprot;
  input [31:0]s_axi_awaddr;
  input [1:0]m_axi_bresp;
  input [11:0]s_axi_arid;
  input [7:0]s_axi_arlen;
  input [1:0]s_axi_arburst;
  input [1:0]s_axi_arsize;
  input [2:0]s_axi_arprot;
  input [31:0]s_axi_araddr;
  input m_axi_arready;
  input m_axi_awready;
  input m_axi_bvalid;
  input s_axi_rready;
  input m_axi_rvalid;
  input aresetn;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire esc_RD_ar_channel_0_n_1_45d8c80 ;
  wire esc_RD_ar_channel_0_n_12_73fab77 ;
  wire esc_RD_ar_channel_0_n_13_25ff364 ;
  wire esc_RD_ar_channel_0_n_14_8d43573 ;
  wire esc_RD_ar_channel_0_n_15_0cf68f3 ;
  wire esc_RD_ar_channel_0_n_16_aefce17 ;
  wire esc_RD_ar_channel_0_n_17_ed5b5db ;
  wire esc_RD_ar_channel_0_n_24_e4f418c ;
  wire esc_RD_ar_channel_0_n_25_cd89a39 ;
  wire esc_RD_ar_channel_0_n_26_76a856f ;
  wire esc_RD_ar_channel_0_n_27_95f74ba ;
  wire esc_RD_ar_channel_0_n_28_607fb24 ;
  wire esc_RD_ar_channel_0_n_29_32000fb ;
  wire esc_RD_ar_channel_0_n_30_2de60ae ;
  wire esc_RD_ar_channel_0_n_32_5ca4a62 ;
  wire esc_RD_ar_channel_0_n_39_0b11b32 ;
  wire esc_RD_ar_channel_0_n_5_6f604cb ;
  wire esc_RD_ar_channel_0_n_57_3919078 ;
  wire esc_RD_ar_channel_0_n_58_3aa228a ;
  wire esc_RD_ar_channel_0_n_59_883c3b2 ;
  wire esc_RD_ar_channel_0_n_60_42cf8f1 ;
  wire esc_RD_r_channel_0_n_0_f506563 ;
  wire SI_REG_n_132;
  wire SI_REG_n_133;
  wire SI_REG_n_146;
  wire SI_REG_n_147;
  wire SI_REG_n_148;
  wire SI_REG_n_149;
  wire SI_REG_n_150;
  wire SI_REG_n_151;
  wire SI_REG_n_152;
  wire SI_REG_n_153;
  wire SI_REG_n_158;
  wire SI_REG_n_165;
  wire SI_REG_n_172;
  wire SI_REG_n_174;
  wire SI_REG_n_175;
  wire SI_REG_n_180;
  wire SI_REG_n_185;
  wire SI_REG_n_186;
  wire SI_REG_n_187;
  wire SI_REG_n_188;
  wire SI_REG_n_189;
  wire SI_REG_n_190;
  wire SI_REG_n_191;
  wire SI_REG_n_192;
  wire SI_REG_n_193;
  wire SI_REG_n_194;
  wire SI_REG_n_195;
  wire SI_REG_n_196;
  wire SI_REG_n_197;
  wire SI_REG_n_198;
  wire SI_REG_n_31;
  wire SI_REG_n_69;
  wire SI_REG_n_70;
  wire SI_REG_n_71;
  wire SI_REG_n_72;
  wire SI_REG_n_8;
  wire SI_REG_n_9;
  wire SI_REG_n_94;
  wire SI_REG_n_95;
  wire SI_REG_n_96;
  wire esc_WR_aw_channel_0_n_22_b682d56 ;
  wire esc_WR_aw_channel_0_n_23_46f1434 ;
  wire esc_WR_aw_channel_0_n_24_0c68968 ;
  wire esc_WR_aw_channel_0_n_25_ebd5ee8 ;
  wire esc_WR_aw_channel_0_n_26_7371460 ;
  wire esc_WR_aw_channel_0_n_27_74f1a47 ;
  wire esc_WR_aw_channel_0_n_30_4bc6fdd ;
  wire esc_WR_aw_channel_0_n_38_5cf20db ;
  wire esc_WR_aw_channel_0_n_63_c322f31 ;
  wire esc_WR_aw_channel_0_n_64_198f5e9 ;
  wire esc_WR_aw_channel_0_n_65_3e014f1 ;
  wire esc_WR_aw_channel_0_n_66_a6878da ;
  wire esc_WR_b_channel_0_n_2_b9039d6 ;
  wire aclk;
  wire esc_ar_ar_pipe_p_1_in_3e6a78b ;
  wire esc_ar_ar_pipe_s_ready_i0_e764319 ;
  wire [1:0]esc_ar_cmd_fsm_0_state_5f3d93d ;
  wire areset_d1;
  wire areset_d1_i_1_n_0;
  wire aresetn;
  wire esc_aw_aw_pipe_p_1_in_d422a68 ;
  wire [0:0]esc_aw_cmd_fsm_0_next_state__0_f92ae48 ;
  wire [1:0]esc_aw_cmd_fsm_0_state_42d1d7b ;
  wire [11:0]axaddr_incr;
  wire [11:0]axaddr_wrap;
  wire [1:0]axsize;
  wire [11:0]b_awid;
  wire [7:0]b_awlen;
  wire b_push;
  wire esc_cmd_translator_0_incr_cmd_0_sel_first_55d65de ;
  wire esc_cmd_translator_0_incr_cmd_0_sel_first_4_df569ac ;
  wire esc_cmd_translator_0_incr_next_pending_5d59886 ;
  wire esc_cmd_translator_0_s_axburst_eq0_b6d120c ;
  wire esc_cmd_translator_0_s_axburst_eq1_0f64594 ;
  wire [3:0]esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_7d23b38 ;
  wire [3:0]esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_0_3c79b96 ;
  wire [3:0]esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_r_04ae746 ;
  wire [3:0]esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_r_2_5e6787e ;
  wire [3:0]esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_64a27b7 ;
  wire [3:0]esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_1_d34419a ;
  wire [3:0]esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_r_bac13ca ;
  wire [3:0]esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_r_3_146112a ;
  wire [33:0]in;
  wire [11:0]m_axi_araddr;
  wire m_axi_arready;
  wire m_axi_arvalid;
  wire [11:0]m_axi_awaddr;
  wire m_axi_awready;
  wire m_axi_awvalid;
  wire m_axi_bready;
  wire m_axi_bvalid;
  wire m_axi_rready;
  wire m_axi_rvalid;
  wire [13:0]esc_m_payload_i_reg_13_5fdb661 ;
  wire [46:0]esc_m_payload_i_reg_46_022e045 ;
  wire r_full;
  wire r_push;
  wire r_rlast;
  wire [11:0]s_arid;
  wire [11:0]s_arid_r;
  wire [11:0]s_awid;
  wire [31:0]s_axi_araddr;
  wire [1:0]s_axi_arburst;
  wire [11:0]s_axi_arid;
  wire [7:0]s_axi_arlen;
  wire s_axi_arready;
  wire [1:0]s_axi_arsize;
  wire s_axi_arvalid;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [11:0]s_axi_awid;
  wire [7:0]s_axi_awlen;
  wire s_axi_awready;
  wire [1:0]s_axi_awsize;
  wire s_axi_awvalid;
  wire s_axi_bready;
  wire s_axi_bvalid;
  wire s_axi_rready;
  wire s_axi_rvalid;
  wire sel_first;
  wire shandshake;
  wire [11:0]si_rs_araddr;
  wire [1:1]si_rs_arburst;
  wire [3:0]si_rs_arlen;
  wire si_rs_arvalid;
  wire [11:0]si_rs_awaddr;
  wire [1:1]si_rs_awburst;
  wire [3:0]si_rs_awlen;
  wire si_rs_awvalid;
  wire [11:0]si_rs_bid;
  wire si_rs_bready;
  wire [1:0]si_rs_bresp;
  wire si_rs_bvalid;
  wire [31:0]si_rs_rdata;
  wire [11:0]si_rs_rid;
  wire si_rs_rlast;
  wire si_rs_rready;
  wire [3:2]wrap_cnt;
  wire [35:0]esc_NLW_RD_ar_channel_0_s_arid_r_reg_11__1_UNCONNECTED_7ab0a9c ;
  wire [46:0]esc_NLW_SI_REG_m_payload_i_reg_46__UNCONNECTED_c4a5821 ;
  wire [58:0]esc_NLW_SI_REG_m_payload_i_reg_64__UNCONNECTED_fe98315 ;
  wire [58:0]esc_NLW_SI_REG_m_payload_i_reg_64__0_UNCONNECTED_ccd527e ;
  wire [19:0]esc_NLW_WR_aw_channel_0_in_UNCONNECTED_fc9d824 ;
  wire [35:0]esc_NLW_WR_aw_channel_0_s_awid_r_reg_11__0_UNCONNECTED_a730f3a ;
  wire [19:0]esc_NLW_WR_b_channel_0_in_UNCONNECTED_02d8392 ;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_ar_channel esc_RD_ar_channel_0_b09d01b 
       (.D(esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_64a27b7 ),
        .E(esc_ar_ar_pipe_p_1_in_3e6a78b ),
        .esc_FSM_sequential_state_reg_1_aa5780a (esc_RD_ar_channel_0_n_5_6f604cb ),
        .esc_FSM_sequential_state_reg_1__0_5c93d31 (esc_RD_ar_channel_0_n_32_5ca4a62 ),
        .Q(esc_ar_cmd_fsm_0_state_5f3d93d ),
        .S({SI_REG_n_132,SI_REG_n_133}),
        .aclk(aclk),
        .areset_d1(areset_d1),
        .esc_axaddr_incr_reg_11_7a60f66 ({esc_RD_ar_channel_0_n_24_e4f418c ,esc_RD_ar_channel_0_n_25_cd89a39 ,esc_RD_ar_channel_0_n_26_76a856f ,esc_RD_ar_channel_0_n_27_95f74ba ,esc_RD_ar_channel_0_n_28_607fb24 ,esc_RD_ar_channel_0_n_29_32000fb }),
        .esc_axaddr_incr_reg_3_2fa58c8 ({SI_REG_n_71,SI_REG_n_72}),
        .esc_axaddr_incr_reg_3__0_6132b06 ({SI_REG_n_146,SI_REG_n_147,SI_REG_n_148,SI_REG_n_149}),
        .esc_axaddr_incr_reg_7_9e14042 ({SI_REG_n_150,SI_REG_n_151,SI_REG_n_152,SI_REG_n_153}),
        .axaddr_offset(esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_7d23b38 ),
        .esc_axaddr_offset_r_reg_3_9b4a3fc (esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_r_04ae746 ),
        .esc_axaddr_wrap_reg_11_66b57d3 ({esc_RD_ar_channel_0_n_12_73fab77 ,esc_RD_ar_channel_0_n_13_25ff364 ,esc_RD_ar_channel_0_n_14_8d43573 ,esc_RD_ar_channel_0_n_15_0cf68f3 ,esc_RD_ar_channel_0_n_16_aefce17 ,esc_RD_ar_channel_0_n_17_ed5b5db }),
        .incr_next_pending(esc_cmd_translator_0_incr_next_pending_5d59886 ),
        .m_axi_arready(m_axi_arready),
        .m_axi_arvalid(m_axi_arvalid),
        .esc_m_payload_i_reg_3_3eab624 ({esc_RD_ar_channel_0_n_57_3919078 ,esc_RD_ar_channel_0_n_58_3aa228a ,esc_RD_ar_channel_0_n_59_883c3b2 ,esc_RD_ar_channel_0_n_60_42cf8f1 }),
        .next_pending_r_reg(esc_RD_ar_channel_0_n_30_2de60ae ),
        .next_pending_r_reg_0(SI_REG_n_172),
        .r_full(r_full),
        .r_push(r_push),
        .r_rlast(r_rlast),
        .esc_s_arid_r_reg_11__0_80c4afa (s_arid_r),
        .esc_s_arid_r_reg_11__1_95e8899 ({s_arid,esc_NLW_RD_ar_channel_0_s_arid_r_reg_11__1_UNCONNECTED_7ab0a9c [23:20],si_rs_arlen,si_rs_arburst,SI_REG_n_94,SI_REG_n_95,SI_REG_n_96,esc_NLW_RD_ar_channel_0_s_arid_r_reg_11__1_UNCONNECTED_7ab0a9c [11:8],si_rs_araddr[7:0]}),
        .s_axi_arvalid(s_axi_arvalid),
        .s_ready_i0(esc_ar_ar_pipe_s_ready_i0_e764319 ),
        .s_ready_i_reg(s_axi_arready),
        .sel_first(esc_cmd_translator_0_incr_cmd_0_sel_first_55d65de ),
        .sel_first_reg(esc_RD_ar_channel_0_n_1_45d8c80 ),
        .sel_first_reg_0(esc_RD_ar_channel_0_n_39_0b11b32 ),
        .si_rs_arvalid(si_rs_arvalid),
        .esc_wrap_boundary_axaddr_r_reg_6_a91079e ({SI_REG_n_192,SI_REG_n_193,SI_REG_n_194,SI_REG_n_195,SI_REG_n_196,SI_REG_n_197,SI_REG_n_198}),
        .esc_wrap_cnt_r_reg_1_4617ef8 (SI_REG_n_180),
        .esc_wrap_cnt_r_reg_3_8701380 ({SI_REG_n_174,SI_REG_n_175}),
        .esc_wrap_second_len_r_reg_3_130d984 (esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_r_bac13ca ));
  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_r_channel esc_RD_r_channel_0_a6b1865 
       (.D(s_arid_r),
        .aclk(aclk),
        .areset_d1(areset_d1),
        .esc_cnt_read_reg_1_2152f9a (esc_RD_r_channel_0_n_0_f506563 ),
        .in(in[31:0]),
        .m_axi_rready(m_axi_rready),
        .m_axi_rvalid(m_axi_rvalid),
        .out(si_rs_rdata),
        .r_full(r_full),
        .r_push(r_push),
        .r_push_r_reg_0({si_rs_rid,si_rs_rlast}),
        .r_rlast(r_rlast),
        .si_rs_rready(si_rs_rready));
  system_auto_pc_0_axi_register_slice_v2_1_22_axi_register_slice SI_REG
       (.D(wrap_cnt),
        .E(esc_aw_aw_pipe_p_1_in_d422a68 ),
        .Q({esc_WR_aw_channel_0_n_22_b682d56 ,esc_WR_aw_channel_0_n_23_46f1434 ,esc_WR_aw_channel_0_n_24_0c68968 ,esc_WR_aw_channel_0_n_25_ebd5ee8 ,esc_WR_aw_channel_0_n_26_7371460 ,esc_WR_aw_channel_0_n_27_74f1a47 }),
        .S({SI_REG_n_8,SI_REG_n_9}),
        .aclk(aclk),
        .aresetn(aresetn),
        .axaddr_incr(axaddr_incr[7:0]),
        .esc_axaddr_incr_reg_3_2fa58c8 ({SI_REG_n_71,SI_REG_n_72}),
        .esc_axaddr_incr_reg_3__0_6132b06 ({esc_WR_aw_channel_0_n_63_c322f31 ,esc_WR_aw_channel_0_n_64_198f5e9 ,esc_WR_aw_channel_0_n_65_3e014f1 ,esc_WR_aw_channel_0_n_66_a6878da }),
        .esc_axaddr_incr_reg_3__1_c45cd30 ({esc_RD_ar_channel_0_n_57_3919078 ,esc_RD_ar_channel_0_n_58_3aa228a ,esc_RD_ar_channel_0_n_59_883c3b2 ,esc_RD_ar_channel_0_n_60_42cf8f1 }),
        .axaddr_offset(esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_0_3c79b96 ),
        .axaddr_offset_0(esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_7d23b38 ),
        .esc_axaddr_offset_r_reg_0_a3138f8 (esc_aw_cmd_fsm_0_state_42d1d7b ),
        .esc_axaddr_offset_r_reg_3_9b4a3fc (esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_r_2_5e6787e ),
        .esc_axaddr_offset_r_reg_3__0_89647ed (esc_ar_cmd_fsm_0_state_5f3d93d ),
        .esc_axaddr_offset_r_reg_3__1_174c336 (esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_r_04ae746 ),
        .esc_axaddr_wrap_reg_3_f9d1eab ({SI_REG_n_69,SI_REG_n_70}),
        .esc_axaddr_wrap_reg_3__0_a824587 ({SI_REG_n_132,SI_REG_n_133}),
        .b_push(b_push),
        .incr_next_pending(esc_cmd_translator_0_incr_next_pending_5d59886 ),
        .m_axi_araddr(m_axi_araddr[5:0]),
        .esc_m_axi_araddr_11_4618f72 ({esc_RD_ar_channel_0_n_24_e4f418c ,esc_RD_ar_channel_0_n_25_cd89a39 ,esc_RD_ar_channel_0_n_26_76a856f ,esc_RD_ar_channel_0_n_27_95f74ba ,esc_RD_ar_channel_0_n_28_607fb24 ,esc_RD_ar_channel_0_n_29_32000fb }),
        .esc_m_axi_araddr_11__0_a45329d ({esc_RD_ar_channel_0_n_12_73fab77 ,esc_RD_ar_channel_0_n_13_25ff364 ,esc_RD_ar_channel_0_n_14_8d43573 ,esc_RD_ar_channel_0_n_15_0cf68f3 ,esc_RD_ar_channel_0_n_16_aefce17 ,esc_RD_ar_channel_0_n_17_ed5b5db }),
        .esc_m_axi_araddr_11__1_69dc7e5 (esc_RD_ar_channel_0_n_39_0b11b32 ),
        .esc_m_axi_araddr_11__2_89d9808 (esc_RD_ar_channel_0_n_1_45d8c80 ),
        .m_axi_awaddr(m_axi_awaddr[5:0]),
        .esc_m_axi_awaddr_11_2270491 (axaddr_wrap[5:0]),
        .esc_m_axi_awaddr_11__0_1b007f9 (esc_WR_aw_channel_0_n_38_5cf20db ),
        .esc_m_payload_i_reg_0_2f8d71c (esc_ar_ar_pipe_p_1_in_3e6a78b ),
        .esc_m_payload_i_reg_13_5fdb661 (esc_m_payload_i_reg_13_5fdb661 ),
        .esc_m_payload_i_reg_3_3eab624 ({SI_REG_n_146,SI_REG_n_147,SI_REG_n_148,SI_REG_n_149}),
        .esc_m_payload_i_reg_44_7279c72 (SI_REG_n_165),
        .esc_m_payload_i_reg_44__0_3e7cb03 (SI_REG_n_180),
        .esc_m_payload_i_reg_46_022e045 ({esc_m_payload_i_reg_46_022e045 [46:34],esc_NLW_SI_REG_m_payload_i_reg_46__UNCONNECTED_c4a5821 [33:32],esc_m_payload_i_reg_46_022e045 [31:0]}),
        .esc_m_payload_i_reg_47_8c317be (SI_REG_n_158),
        .esc_m_payload_i_reg_47__0_fbbb04b (SI_REG_n_172),
        .esc_m_payload_i_reg_47__1_6188148 ({SI_REG_n_185,SI_REG_n_186,SI_REG_n_187,SI_REG_n_188,SI_REG_n_189,SI_REG_n_190,SI_REG_n_191}),
        .esc_m_payload_i_reg_47__2_d1e0165 ({SI_REG_n_192,SI_REG_n_193,SI_REG_n_194,SI_REG_n_195,SI_REG_n_196,SI_REG_n_197,SI_REG_n_198}),
        .esc_m_payload_i_reg_64_2ba99a2 ({s_awid,esc_NLW_SI_REG_m_payload_i_reg_64__UNCONNECTED_fe98315 [46:43],si_rs_awlen,si_rs_awburst,SI_REG_n_31,axsize,esc_NLW_SI_REG_m_payload_i_reg_64__UNCONNECTED_fe98315 [34:8],si_rs_awaddr[7:0]}),
        .esc_m_payload_i_reg_64__0_7cd5a09 ({s_arid,esc_NLW_SI_REG_m_payload_i_reg_64__0_UNCONNECTED_ccd527e [46:43],si_rs_arlen,si_rs_arburst,SI_REG_n_94,SI_REG_n_95,SI_REG_n_96,esc_NLW_SI_REG_m_payload_i_reg_64__0_UNCONNECTED_ccd527e [34:8],si_rs_araddr[7:0]}),
        .esc_m_payload_i_reg_7_ba4380d ({SI_REG_n_150,SI_REG_n_151,SI_REG_n_152,SI_REG_n_153}),
        .m_valid_i_reg(s_axi_bvalid),
        .m_valid_i_reg_0(s_axi_rvalid),
        .m_valid_i_reg_1(esc_RD_ar_channel_0_n_5_6f604cb ),
        .m_valid_i_reg_2(esc_RD_r_channel_0_n_0_f506563 ),
        .next_pending_r_reg(esc_RD_ar_channel_0_n_30_2de60ae ),
        .out(si_rs_bid),
        .s_axi_araddr(s_axi_araddr[7:0]),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_arid(s_axi_arid),
        .s_axi_arlen(s_axi_arlen[3:0]),
        .s_axi_arsize(s_axi_arsize),
        .s_axi_awaddr(s_axi_awaddr[7:0]),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awid(s_axi_awid),
        .s_axi_awlen(s_axi_awlen[3:0]),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_bready(s_axi_bready),
        .s_axi_rready(s_axi_rready),
        .s_ready_i0(esc_ar_ar_pipe_s_ready_i0_e764319 ),
        .s_ready_i_reg(s_axi_awready),
        .s_ready_i_reg_0(s_axi_arready),
        .sel_first(sel_first),
        .sel_first_1(esc_cmd_translator_0_incr_cmd_0_sel_first_4_df569ac ),
        .sel_first_2(esc_cmd_translator_0_incr_cmd_0_sel_first_55d65de ),
        .shandshake(shandshake),
        .si_rs_arvalid(si_rs_arvalid),
        .si_rs_awvalid(si_rs_awvalid),
        .si_rs_bready(si_rs_bready),
        .si_rs_bvalid(si_rs_bvalid),
        .si_rs_rready(si_rs_rready),
        .esc_skid_buffer_reg_1_56ed2e4 (si_rs_bresp),
        .esc_skid_buffer_reg_33_39a8494 (si_rs_rdata),
        .esc_skid_buffer_reg_46_665ac24 ({si_rs_rid,si_rs_rlast}),
        .esc_wrap_second_len_r_reg_2_01b34aa ({SI_REG_n_174,SI_REG_n_175}),
        .esc_wrap_second_len_r_reg_2__0_7d5dd64 (esc_WR_aw_channel_0_n_30_4bc6fdd ),
        .esc_wrap_second_len_r_reg_3_130d984 (esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_1_d34419a ),
        .esc_wrap_second_len_r_reg_3__0_61735c7 (esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_64a27b7 ),
        .esc_wrap_second_len_r_reg_3__1_e9d1a95 (esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_r_3_146112a ),
        .esc_wrap_second_len_r_reg_3__2_20f8099 (esc_RD_ar_channel_0_n_32_5ca4a62 ),
        .esc_wrap_second_len_r_reg_3__3_a7b0a59 (esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_r_bac13ca ));

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_aw_channel esc_WR_aw_channel_0_becc047 
       (.D(wrap_cnt),
        .E(esc_aw_aw_pipe_p_1_in_d422a68 ),
        .esc_FSM_sequential_state_reg_0_392f9b0 (esc_aw_cmd_fsm_0_next_state__0_f92ae48 ),
        .esc_FSM_sequential_state_reg_1_aa5780a (esc_aw_cmd_fsm_0_state_42d1d7b ),
        .esc_FSM_sequential_state_reg_1__0_5c93d31 (esc_WR_aw_channel_0_n_30_4bc6fdd ),
        .Q(axaddr_wrap[5:0]),
        .S({SI_REG_n_8,SI_REG_n_9}),
        .aclk(aclk),
        .areset_d1(areset_d1),
        .axaddr_incr(axaddr_incr[7:0]),
        .esc_axaddr_incr_reg_11_7a60f66 ({esc_WR_aw_channel_0_n_22_b682d56 ,esc_WR_aw_channel_0_n_23_46f1434 ,esc_WR_aw_channel_0_n_24_0c68968 ,esc_WR_aw_channel_0_n_25_ebd5ee8 ,esc_WR_aw_channel_0_n_26_7371460 ,esc_WR_aw_channel_0_n_27_74f1a47 }),
        .esc_axaddr_offset_r_reg_3_9b4a3fc (esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_r_2_5e6787e ),
        .esc_axaddr_offset_r_reg_3__0_89647ed (esc_cmd_translator_0_wrap_cmd_0_axaddr_offset_0_3c79b96 ),
        .esc_axaddr_wrap_reg_0_4889146 (esc_WR_b_channel_0_n_2_b9039d6 ),
        .esc_axaddr_wrap_reg_3_f9d1eab ({SI_REG_n_69,SI_REG_n_70}),
        .b_push(b_push),
        .in({b_awid,esc_NLW_WR_aw_channel_0_in_UNCONNECTED_fc9d824 [7:4],b_awlen[3:0]}),
        .m_axi_awready(m_axi_awready),
        .m_axi_awvalid(m_axi_awvalid),
        .esc_m_payload_i_reg_3_3eab624 ({esc_WR_aw_channel_0_n_63_c322f31 ,esc_WR_aw_channel_0_n_64_198f5e9 ,esc_WR_aw_channel_0_n_65_3e014f1 ,esc_WR_aw_channel_0_n_66_a6878da }),
        .next_pending_r_reg(SI_REG_n_158),
        .esc_s_awid_r_reg_11__0_dfa8ce6 ({s_awid,esc_NLW_WR_aw_channel_0_s_awid_r_reg_11__0_UNCONNECTED_a730f3a [23:20],si_rs_awlen,si_rs_awburst,SI_REG_n_31,axsize,esc_NLW_WR_aw_channel_0_s_awid_r_reg_11__0_UNCONNECTED_a730f3a [11:8],si_rs_awaddr[7:0]}),
        .s_axburst_eq0(esc_cmd_translator_0_s_axburst_eq0_b6d120c ),
        .s_axburst_eq1(esc_cmd_translator_0_s_axburst_eq1_0f64594 ),
        .sel_first(sel_first),
        .sel_first_0(esc_cmd_translator_0_incr_cmd_0_sel_first_4_df569ac ),
        .sel_first_reg(esc_WR_aw_channel_0_n_38_5cf20db ),
        .si_rs_awvalid(si_rs_awvalid),
        .esc_wrap_boundary_axaddr_r_reg_6_a91079e ({SI_REG_n_185,SI_REG_n_186,SI_REG_n_187,SI_REG_n_188,SI_REG_n_189,SI_REG_n_190,SI_REG_n_191}),
        .esc_wrap_cnt_r_reg_1_4617ef8 (SI_REG_n_165),
        .esc_wrap_second_len_r_reg_3_130d984 (esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_r_3_146112a ),
        .esc_wrap_second_len_r_reg_3__0_61735c7 (esc_cmd_translator_0_wrap_cmd_0_wrap_second_len_1_d34419a ));
  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_b_channel esc_WR_b_channel_0_de9b1cb 
       (.esc_FSM_sequential_state_reg_0_392f9b0 (esc_aw_cmd_fsm_0_next_state__0_f92ae48 ),
        .esc_FSM_sequential_state_reg_0__0_171b21e (esc_aw_cmd_fsm_0_state_42d1d7b ),
        .esc_FSM_sequential_state_reg_0__1_44612ba (si_rs_awburst),
        .aclk(aclk),
        .areset_d1(areset_d1),
        .b_push(b_push),
        .esc_cnt_read_reg_0_59fb42f (esc_WR_b_channel_0_n_2_b9039d6 ),
        .in({b_awid,esc_NLW_WR_b_channel_0_in_UNCONNECTED_02d8392 [7:4],b_awlen[3:0]}),
        .m_axi_awready(m_axi_awready),
        .m_axi_bready(m_axi_bready),
        .m_axi_bvalid(m_axi_bvalid),
        .out(si_rs_bid),
        .s_axburst_eq0(esc_cmd_translator_0_s_axburst_eq0_b6d120c ),
        .s_axburst_eq1(esc_cmd_translator_0_s_axburst_eq1_0f64594 ),
        .esc_s_bresp_acc_reg_1__0_5af6641 (si_rs_bresp),
        .shandshake(shandshake),
        .si_rs_bready(si_rs_bready),
        .si_rs_bvalid(si_rs_bvalid));

  // Reconstructed LUT1: areset_d1_i_1
  assign areset_d1_i_1_n_0 = ~(aresetn);

  // Reconstructed FDRE: areset_d1_reg
  reg recovered_9_q = 1'b0;
  assign areset_d1 = recovered_9_q;
  wire recovered_9_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (areset_d1_i_1_n_0)))) recovered_9_q <= (areset_d1_i_1_n_0);
  end

endmodule

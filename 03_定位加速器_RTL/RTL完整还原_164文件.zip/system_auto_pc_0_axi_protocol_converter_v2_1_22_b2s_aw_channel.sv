// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_aw_channel
   (s_axburst_eq0,
    s_axburst_eq1,
    sel_first_0,
    sel_first,
    Q,
    esc_axaddr_incr_reg_11_7a60f66 ,
    esc_FSM_sequential_state_reg_1_aa5780a ,
    esc_FSM_sequential_state_reg_1__0_5c93d31 ,
    E,
    b_push,
    esc_wrap_second_len_r_reg_3_130d984 ,
    m_axi_awvalid,
    sel_first_reg,
    esc_axaddr_offset_r_reg_3_9b4a3fc ,
    in,
    esc_m_payload_i_reg_3_3eab624 ,
    aclk,
    esc_s_awid_r_reg_11__0_dfa8ce6 ,
    esc_axaddr_wrap_reg_3_f9d1eab ,
    S,
    si_rs_awvalid,
    areset_d1,
    next_pending_r_reg,
    m_axi_awready,
    esc_axaddr_wrap_reg_0_4889146 ,
    D,
    esc_axaddr_offset_r_reg_3__0_89647ed ,
    esc_wrap_cnt_r_reg_1_4617ef8 ,
    axaddr_incr,
    esc_FSM_sequential_state_reg_0_392f9b0 ,
    esc_wrap_second_len_r_reg_3__0_61735c7 ,
    esc_wrap_boundary_axaddr_r_reg_6_a91079e );
  output s_axburst_eq0;
  output s_axburst_eq1;
  output sel_first_0;
  output sel_first;
  output [11:0]Q;
  output [11:0]esc_axaddr_incr_reg_11_7a60f66 ;
  output [1:0]esc_FSM_sequential_state_reg_1_aa5780a ;
  output esc_FSM_sequential_state_reg_1__0_5c93d31 ;
  output [0:0]E;
  output b_push;
  output [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  output m_axi_awvalid;
  output sel_first_reg;
  output [3:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  output [19:0]in;
  output [3:0]esc_m_payload_i_reg_3_3eab624 ;
  input aclk;
  input [35:0]esc_s_awid_r_reg_11__0_dfa8ce6 ;
  input [1:0]esc_axaddr_wrap_reg_3_f9d1eab ;
  input [1:0]S;
  input si_rs_awvalid;
  input areset_d1;
  input next_pending_r_reg;
  input m_axi_awready;
  input esc_axaddr_wrap_reg_0_4889146 ;
  input [1:0]D;
  input [3:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  input esc_wrap_cnt_r_reg_1_4617ef8 ;
  input [11:0]axaddr_incr;
  input [0:0]esc_FSM_sequential_state_reg_0_392f9b0 ;
  input [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  input [6:0]esc_wrap_boundary_axaddr_r_reg_6_a91079e ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [1:0]D;
  wire [0:0]E;
  wire [0:0]esc_FSM_sequential_state_reg_0_392f9b0 ;
  wire [1:0]esc_FSM_sequential_state_reg_1_aa5780a ;
  wire esc_FSM_sequential_state_reg_1__0_5c93d31 ;
  wire [11:0]Q;
  wire [1:0]S;
  wire aclk;
  wire areset_d1;
  wire aw_cmd_fsm_0_n_0;
  wire aw_cmd_fsm_0_n_10;
  wire aw_cmd_fsm_0_n_13;
  wire aw_cmd_fsm_0_n_4;
  wire aw_cmd_fsm_0_n_5;
  wire aw_cmd_fsm_0_n_7;
  wire [11:0]axaddr_incr;
  wire [11:0]esc_axaddr_incr_reg_11_7a60f66 ;
  wire [3:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  wire [3:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  wire esc_axaddr_wrap_reg_0_4889146 ;
  wire [1:0]esc_axaddr_wrap_reg_3_f9d1eab ;
  wire b_push;
  wire cmd_translator_0_n_2;
  wire cmd_translator_0_n_31;
  wire cmd_translator_0_n_32;
  wire cmd_translator_0_n_33;
  wire cmd_translator_0_n_34;
  wire [19:0]in;
  wire esc_incr_cmd_0_next_pending_r_d0b8dba ;
  wire incr_next_pending;
  wire m_axi_awready;
  wire m_axi_awvalid;
  wire [3:0]esc_m_payload_i_reg_3_3eab624 ;
  wire next;
  wire next_pending_r_reg;
  wire [35:0]esc_s_awid_r_reg_11__0_dfa8ce6 ;
  wire s_axburst_eq0;
  wire s_axburst_eq1;
  wire sel_first;
  wire sel_first_0;
  wire sel_first_i;
  wire sel_first_reg;
  wire si_rs_awvalid;
  wire [6:0]esc_wrap_boundary_axaddr_r_reg_6_a91079e ;
  wire [0:0]wrap_cnt;
  wire esc_wrap_cnt_r_reg_1_4617ef8 ;
  wire wrap_next_pending;
  wire [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  wire [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  wire [23:0]esc_NLW_cmd_translator_0_axlen_cnt_reg_7__UNCONNECTED_a87463b ;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_wr_cmd_fsm aw_cmd_fsm_0
       (.D(aw_cmd_fsm_0_n_13),
        .E(esc_FSM_sequential_state_reg_1__0_5c93d31 ),
        .esc_FSM_sequential_state_reg_0__0_171b21e (esc_FSM_sequential_state_reg_0_392f9b0 ),
        .esc_FSM_sequential_state_reg_1__0_5c93d31 (aw_cmd_fsm_0_n_0),
        .esc_FSM_sequential_state_reg_1__1_12501c6 (aw_cmd_fsm_0_n_4),
        .esc_FSM_sequential_state_reg_1__2_92698b2 (wrap_cnt),
        .Q(esc_FSM_sequential_state_reg_1_aa5780a ),
        .aclk(aclk),
        .areset_d1(areset_d1),
        .esc_axaddr_wrap_reg_0_4889146 (cmd_translator_0_n_34),
        .esc_axaddr_wrap_reg_0__0_8ebf4f6 (esc_axaddr_wrap_reg_0_4889146 ),
        .esc_axlen_cnt_reg_0_56abf15 (cmd_translator_0_n_32),
        .esc_axlen_cnt_reg_0__0_31fcd59 (cmd_translator_0_n_31),
        .b_push(b_push),
        .incr_next_pending(incr_next_pending),
        .m_axi_awready(m_axi_awready),
        .m_axi_awready_0(aw_cmd_fsm_0_n_10),
        .m_axi_awvalid(m_axi_awvalid),
        .esc_m_payload_i_reg_39_ea68878 (aw_cmd_fsm_0_n_5),
        .esc_m_payload_i_reg_39__0_7251a5e (aw_cmd_fsm_0_n_7),
        .m_valid_i_reg(E),
        .next(next),
        .next_pending_r(esc_incr_cmd_0_next_pending_r_d0b8dba ),
        .next_pending_r_reg(esc_s_awid_r_reg_11__0_dfa8ce6 [16:15]),
        .next_pending_r_reg_0(cmd_translator_0_n_33),
        .next_pending_r_reg_1(next_pending_r_reg),
        .sel_first(sel_first),
        .sel_first_i(sel_first_i),
        .sel_first_reg(sel_first_0),
        .sel_first_reg_0(cmd_translator_0_n_2),
        .si_rs_awvalid(si_rs_awvalid),
        .esc_wrap_cnt_r_reg_0_9ce1d67 (esc_axaddr_offset_r_reg_3__0_89647ed [0]),
        .esc_wrap_cnt_r_reg_0__0_ed4efd2 (esc_wrap_second_len_r_reg_3_130d984 [0]),
        .esc_wrap_cnt_r_reg_0__1_5374db8 (esc_wrap_cnt_r_reg_1_4617ef8 ),
        .wrap_next_pending(wrap_next_pending));
  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_cmd_translator cmd_translator_0
       (.D({D,wrap_cnt}),
        .E(esc_FSM_sequential_state_reg_1__0_5c93d31 ),
        .Q(Q[5:0]),
        .S(S),
        .aclk(aclk),
        .axaddr_incr(axaddr_incr[7:0]),
        .esc_axaddr_incr_reg_11_7a60f66 (esc_axaddr_incr_reg_11_7a60f66 [5:0]),
        .esc_axaddr_offset_r_reg_3_9b4a3fc (esc_axaddr_offset_r_reg_3_9b4a3fc ),
        .esc_axaddr_offset_r_reg_3__0_89647ed (esc_axaddr_offset_r_reg_3__0_89647ed ),
        .esc_axaddr_wrap_reg_0_4889146 (aw_cmd_fsm_0_n_10),
        .esc_axaddr_wrap_reg_3_f9d1eab (esc_axaddr_wrap_reg_3_f9d1eab ),
        .esc_axlen_cnt_reg_0_56abf15 (cmd_translator_0_n_32),
        .esc_axlen_cnt_reg_0__0_31fcd59 (esc_FSM_sequential_state_reg_1_aa5780a ),
        .esc_axlen_cnt_reg_0__1_4dc9f21 (aw_cmd_fsm_0_n_13),
        .esc_axlen_cnt_reg_2_379d3d4 (cmd_translator_0_n_33),
        .esc_axlen_cnt_reg_3_46333b8 (cmd_translator_0_n_31),
        .esc_axlen_cnt_reg_7_01da386 ({esc_s_awid_r_reg_11__0_dfa8ce6 [19:12],esc_NLW_cmd_translator_0_axlen_cnt_reg_7__UNCONNECTED_a87463b [11:8],esc_s_awid_r_reg_11__0_dfa8ce6 [7:0]}),
        .incr_next_pending(incr_next_pending),
        .esc_m_payload_i_reg_3_3eab624 (esc_m_payload_i_reg_3_3eab624 ),
        .next(next),
        .next_pending_r(esc_incr_cmd_0_next_pending_r_d0b8dba ),
        .next_pending_r_reg(next_pending_r_reg),
        .s_axburst_eq0(s_axburst_eq0),
        .s_axburst_eq0_reg_0(aw_cmd_fsm_0_n_5),
        .s_axburst_eq1(s_axburst_eq1),
        .s_axburst_eq1_reg_0(cmd_translator_0_n_34),
        .s_axburst_eq1_reg_1(aw_cmd_fsm_0_n_7),
        .sel_first(sel_first),
        .sel_first_i(sel_first_i),
        .sel_first_reg_0(cmd_translator_0_n_2),
        .sel_first_reg_1(sel_first_0),
        .sel_first_reg_2(sel_first_reg),
        .sel_first_reg_3(aw_cmd_fsm_0_n_0),
        .sel_first_reg_4(aw_cmd_fsm_0_n_4),
        .si_rs_awvalid(si_rs_awvalid),
        .esc_wrap_boundary_axaddr_r_reg_6_a91079e (esc_wrap_boundary_axaddr_r_reg_6_a91079e ),
        .esc_wrap_cnt_r_reg_1_4617ef8 (esc_wrap_cnt_r_reg_1_4617ef8 ),
        .wrap_next_pending(wrap_next_pending),
        .esc_wrap_second_len_r_reg_3_130d984 (esc_wrap_second_len_r_reg_3_130d984 ),
        .esc_wrap_second_len_r_reg_3__0_61735c7 (esc_wrap_second_len_r_reg_3__0_61735c7 ));

  // Reconstructed FDRE: esc_s_awid_r_reg_0_8ce2459
  reg recovered_5_q = 1'b0;
  assign in[8] = recovered_5_q;
  wire recovered_5_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [24])))) recovered_5_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [24]);
  end

  // Reconstructed FDRE: esc_s_awid_r_reg_10_bbc2f0d
  reg recovered_6_q = 1'b0;
  assign in[18] = recovered_6_q;
  wire recovered_6_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [34])))) recovered_6_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [34]);
  end

  // Reconstructed FDRE: esc_s_awid_r_reg_11_95ed7c7
  reg recovered_7_q = 1'b0;
  assign in[19] = recovered_7_q;
  wire recovered_7_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [35])))) recovered_7_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [35]);
  end

  // Reconstructed FDRE: esc_s_awid_r_reg_1_981318a
  reg recovered_8_q = 1'b0;
  assign in[9] = recovered_8_q;
  wire recovered_8_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_8_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_8_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [25])))) recovered_8_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [25]);
  end

  // Reconstructed FDRE: esc_s_awid_r_reg_2_2940373
  reg recovered_9_q = 1'b0;
  assign in[10] = recovered_9_q;
  wire recovered_9_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [26])))) recovered_9_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [26]);
  end

  // Reconstructed FDRE: esc_s_awid_r_reg_3_6edbb24
  reg recovered_10_q = 1'b0;
  assign in[11] = recovered_10_q;
  wire recovered_10_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_10_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_10_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [27])))) recovered_10_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [27]);
  end

  // Reconstructed FDRE: esc_s_awid_r_reg_4_80324f9
  reg recovered_11_q = 1'b0;
  assign in[12] = recovered_11_q;
  wire recovered_11_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_11_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_11_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [28])))) recovered_11_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [28]);
  end

  // Reconstructed FDRE: esc_s_awid_r_reg_5_4dcafbe
  reg recovered_12_q = 1'b0;
  assign in[13] = recovered_12_q;
  wire recovered_12_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_12_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_12_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [29])))) recovered_12_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [29]);
  end

  // Reconstructed FDRE: esc_s_awid_r_reg_6_204fc54
  reg recovered_13_q = 1'b0;
  assign in[14] = recovered_13_q;
  wire recovered_13_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_13_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [30])))) recovered_13_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [30]);
  end

  // Reconstructed FDRE: esc_s_awid_r_reg_7_8d5894e
  reg recovered_14_q = 1'b0;
  assign in[15] = recovered_14_q;
  wire recovered_14_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_14_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_14_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [31])))) recovered_14_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [31]);
  end

  // Reconstructed FDRE: esc_s_awid_r_reg_8_09f94da
  reg recovered_15_q = 1'b0;
  assign in[16] = recovered_15_q;
  wire recovered_15_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_15_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_15_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [32])))) recovered_15_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [32]);
  end

  // Reconstructed FDRE: esc_s_awid_r_reg_9_72a235f
  reg recovered_16_q = 1'b0;
  assign in[17] = recovered_16_q;
  wire recovered_16_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_16_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_16_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [33])))) recovered_16_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [33]);
  end

  // Reconstructed FDRE: esc_s_awlen_r_reg_0_1b267b5
  reg recovered_17_q = 1'b0;
  assign in[0] = recovered_17_q;
  wire recovered_17_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_17_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_17_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [16])))) recovered_17_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [16]);
  end

  // Reconstructed FDRE: esc_s_awlen_r_reg_1_b4078b9
  reg recovered_18_q = 1'b0;
  assign in[1] = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_18_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [17])))) recovered_18_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [17]);
  end

  // Reconstructed FDRE: esc_s_awlen_r_reg_2_0d9d4f6
  reg recovered_19_q = 1'b0;
  assign in[2] = recovered_19_q;
  wire recovered_19_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_19_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [18])))) recovered_19_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [18]);
  end

  // Reconstructed FDRE: esc_s_awlen_r_reg_3_b3645a4
  reg recovered_20_q = 1'b0;
  assign in[3] = recovered_20_q;
  wire recovered_20_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_20_q == (esc_s_awid_r_reg_11__0_dfa8ce6 [19])))) recovered_20_q <= (esc_s_awid_r_reg_11__0_dfa8ce6 [19]);
  end

endmodule

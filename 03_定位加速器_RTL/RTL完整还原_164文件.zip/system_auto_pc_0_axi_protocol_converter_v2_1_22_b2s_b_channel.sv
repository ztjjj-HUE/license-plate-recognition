// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_b_channel
   (si_rs_bvalid,
    esc_FSM_sequential_state_reg_0_392f9b0 ,
    esc_cnt_read_reg_0_59fb42f ,
    m_axi_bready,
    out,
    esc_s_bresp_acc_reg_1__0_5af6641 ,
    areset_d1,
    shandshake,
    aclk,
    esc_FSM_sequential_state_reg_0__0_171b21e ,
    s_axburst_eq0,
    esc_FSM_sequential_state_reg_0__1_44612ba ,
    s_axburst_eq1,
    m_axi_awready,
    si_rs_bready,
    m_axi_bvalid,
    b_push,
    in,
    m_axi_bresp);
  output si_rs_bvalid;
  output [0:0]esc_FSM_sequential_state_reg_0_392f9b0 ;
  output esc_cnt_read_reg_0_59fb42f ;
  output m_axi_bready;
  output [11:0]out;
  output [1:0]esc_s_bresp_acc_reg_1__0_5af6641 ;
  input areset_d1;
  input shandshake;
  input aclk;
  input [1:0]esc_FSM_sequential_state_reg_0__0_171b21e ;
  input s_axburst_eq0;
  input [0:0]esc_FSM_sequential_state_reg_0__1_44612ba ;
  input s_axburst_eq1;
  input m_axi_awready;
  input si_rs_bready;
  input m_axi_bvalid;
  input b_push;
  input [19:0]in;
  input [1:0]m_axi_bresp;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]esc_FSM_sequential_state_reg_0_392f9b0 ;
  wire [1:0]esc_FSM_sequential_state_reg_0__0_171b21e ;
  wire [0:0]esc_FSM_sequential_state_reg_0__1_44612ba ;
  wire aclk;
  wire areset_d1;
  wire b_push;
  wire bid_fifo_0_n_4;
  wire esc_bresp_cnt_7__i_5_n_0_ad56276 ;
  wire [7:0]bresp_cnt_reg;
  wire bresp_fifo_0_n_0;
  wire bresp_push;
  wire esc_cnt_read_reg_0_59fb42f ;
  wire [19:0]in;
  wire m_axi_awready;
  wire m_axi_bready;
  wire m_axi_bvalid;
  wire mhandshake;
  wire mhandshake_r;
  wire [11:0]out;
  wire [7:0]p_0_in;
  wire s_axburst_eq0;
  wire s_axburst_eq1;
  wire s_bresp_acc0;
  wire esc_s_bresp_acc_0__i_1_n_0_e75d903 ;
  wire esc_s_bresp_acc_1__i_1_n_0_25b7351 ;
  wire [1:0]esc_s_bresp_acc_reg_1__0_5af6641 ;
  wire esc_s_bresp_acc_reg_n_0__0_fe551a6 ;
  wire esc_s_bresp_acc_reg_n_0__1_a736ca3 ;
  wire shandshake;
  wire shandshake_r;
  wire si_rs_bready;
  wire si_rs_bvalid;
  wire [19:0]NLW_bid_fifo_0_in_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_simple_fifo bid_fifo_0
       (.esc_FSM_sequential_state_reg_0_392f9b0 (esc_FSM_sequential_state_reg_0_392f9b0 ),
        .esc_FSM_sequential_state_reg_0__0_171b21e (esc_FSM_sequential_state_reg_0__0_171b21e ),
        .esc_FSM_sequential_state_reg_0__1_44612ba (esc_FSM_sequential_state_reg_0__1_44612ba ),
        .Q(bresp_cnt_reg),
        .SR(s_bresp_acc0),
        .aclk(aclk),
        .areset_d1(areset_d1),
        .b_push(b_push),
        .bresp_push(bresp_push),
        .esc_cnt_read_reg_0__0_6de67a2 (esc_cnt_read_reg_0_59fb42f ),
        .esc_cnt_read_reg_1__0_8b39e39 (bid_fifo_0_n_4),
        .in({in[19:8],NLW_bid_fifo_0_in_UNCONNECTED[7:4],in[3:0]}),
        .m_axi_awready(m_axi_awready),
        .mhandshake_r(mhandshake_r),
        .out(out),
        .s_axburst_eq0(s_axburst_eq0),
        .s_axburst_eq1(s_axburst_eq1),
        .shandshake_r(shandshake_r));

  // Reconstructed LUT1: esc_bresp_cnt_0__i_1_cb097f2
  assign p_0_in[0] = ~(bresp_cnt_reg[0]);

  // Reconstructed LUT2: esc_bresp_cnt_1__i_1_990e9a0
  assign p_0_in[1] = ((bresp_cnt_reg[1]) ? (~(bresp_cnt_reg[0])) : (bresp_cnt_reg[0]));

  // Reconstructed LUT3: esc_bresp_cnt_2__i_1_ced9f13
  assign p_0_in[2] = ((bresp_cnt_reg[2]) ? (((bresp_cnt_reg[1]) ? (~(bresp_cnt_reg[0])) : (1'b1))) : (((bresp_cnt_reg[1]) ? (bresp_cnt_reg[0]) : (1'b0))));

  // Reconstructed LUT4: esc_bresp_cnt_3__i_1_86e13a3
  assign p_0_in[3] = ((bresp_cnt_reg[3]) ? (((bresp_cnt_reg[0]) ? (((bresp_cnt_reg[1]) ? (~(bresp_cnt_reg[2])) : (1'b1))) : (1'b1))) : (((bresp_cnt_reg[0]) ? (((bresp_cnt_reg[1]) ? (bresp_cnt_reg[2]) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_bresp_cnt_4__i_1_8e4ea6d
  assign p_0_in[4] = ((bresp_cnt_reg[4]) ? (((bresp_cnt_reg[2]) ? (((bresp_cnt_reg[1]) ? (((bresp_cnt_reg[0]) ? (~(bresp_cnt_reg[3])) : (1'b1))) : (1'b1))) : (1'b1))) : (((bresp_cnt_reg[2]) ? (((bresp_cnt_reg[1]) ? (((bresp_cnt_reg[0]) ? (bresp_cnt_reg[3]) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_bresp_cnt_5__i_1_8c5e7b7
  assign p_0_in[5] = ((bresp_cnt_reg[5]) ? (((bresp_cnt_reg[4]) ? (((bresp_cnt_reg[3]) ? (((bresp_cnt_reg[0]) ? (((bresp_cnt_reg[1]) ? (~(bresp_cnt_reg[2])) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1))) : (((bresp_cnt_reg[4]) ? (((bresp_cnt_reg[3]) ? (((bresp_cnt_reg[0]) ? (((bresp_cnt_reg[1]) ? (bresp_cnt_reg[2]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT2: esc_bresp_cnt_6__i_1_646d835
  assign p_0_in[6] = ((bresp_cnt_reg[6]) ? (esc_bresp_cnt_7__i_5_n_0_ad56276) : (~(esc_bresp_cnt_7__i_5_n_0_ad56276)));

  // Reconstructed LUT3: esc_bresp_cnt_7__i_2_e781d15
  assign p_0_in[7] = ((bresp_cnt_reg[7]) ? (((esc_bresp_cnt_7__i_5_n_0_ad56276) ? (1'b1) : (~(bresp_cnt_reg[6])))) : (((esc_bresp_cnt_7__i_5_n_0_ad56276) ? (1'b0) : (bresp_cnt_reg[6]))));

  // Reconstructed LUT6: esc_bresp_cnt_7__i_5_130f20d
  assign esc_bresp_cnt_7__i_5_n_0_ad56276 = ((bresp_cnt_reg[5]) ? (((bresp_cnt_reg[4]) ? (((bresp_cnt_reg[3]) ? (((bresp_cnt_reg[0]) ? (((bresp_cnt_reg[1]) ? (~(bresp_cnt_reg[2])) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed FDRE: esc_bresp_cnt_reg_0_5d2f336
  reg recovered_13_q = 1'b0;
  assign bresp_cnt_reg[0] = recovered_13_q;
  wire recovered_13_reset = ((s_bresp_acc0)) && ((s_bresp_acc0) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((s_bresp_acc0) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((mhandshake_r) || ((mhandshake_r) === 1'bz) || (((mhandshake_r) === 1'bx) && (recovered_13_q == (p_0_in[0])))) recovered_13_q <= (p_0_in[0]);
  end

  // Reconstructed FDRE: esc_bresp_cnt_reg_1_ece6a72
  reg recovered_14_q = 1'b0;
  assign bresp_cnt_reg[1] = recovered_14_q;
  wire recovered_14_reset = ((s_bresp_acc0)) && ((s_bresp_acc0) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_14_reset || (((s_bresp_acc0) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((mhandshake_r) || ((mhandshake_r) === 1'bz) || (((mhandshake_r) === 1'bx) && (recovered_14_q == (p_0_in[1])))) recovered_14_q <= (p_0_in[1]);
  end

  // Reconstructed FDRE: esc_bresp_cnt_reg_2_4489fad
  reg recovered_15_q = 1'b0;
  assign bresp_cnt_reg[2] = recovered_15_q;
  wire recovered_15_reset = ((s_bresp_acc0)) && ((s_bresp_acc0) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_15_reset || (((s_bresp_acc0) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((mhandshake_r) || ((mhandshake_r) === 1'bz) || (((mhandshake_r) === 1'bx) && (recovered_15_q == (p_0_in[2])))) recovered_15_q <= (p_0_in[2]);
  end

  // Reconstructed FDRE: esc_bresp_cnt_reg_3_3c17269
  reg recovered_16_q = 1'b0;
  assign bresp_cnt_reg[3] = recovered_16_q;
  wire recovered_16_reset = ((s_bresp_acc0)) && ((s_bresp_acc0) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_16_reset || (((s_bresp_acc0) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((mhandshake_r) || ((mhandshake_r) === 1'bz) || (((mhandshake_r) === 1'bx) && (recovered_16_q == (p_0_in[3])))) recovered_16_q <= (p_0_in[3]);
  end

  // Reconstructed FDRE: esc_bresp_cnt_reg_4_56e2212
  reg recovered_17_q = 1'b0;
  assign bresp_cnt_reg[4] = recovered_17_q;
  wire recovered_17_reset = ((s_bresp_acc0)) && ((s_bresp_acc0) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_17_reset || (((s_bresp_acc0) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((mhandshake_r) || ((mhandshake_r) === 1'bz) || (((mhandshake_r) === 1'bx) && (recovered_17_q == (p_0_in[4])))) recovered_17_q <= (p_0_in[4]);
  end

  // Reconstructed FDRE: esc_bresp_cnt_reg_5_f6c34cf
  reg recovered_18_q = 1'b0;
  assign bresp_cnt_reg[5] = recovered_18_q;
  wire recovered_18_reset = ((s_bresp_acc0)) && ((s_bresp_acc0) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((s_bresp_acc0) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((mhandshake_r) || ((mhandshake_r) === 1'bz) || (((mhandshake_r) === 1'bx) && (recovered_18_q == (p_0_in[5])))) recovered_18_q <= (p_0_in[5]);
  end

  // Reconstructed FDRE: esc_bresp_cnt_reg_6_38e213e
  reg recovered_19_q = 1'b0;
  assign bresp_cnt_reg[6] = recovered_19_q;
  wire recovered_19_reset = ((s_bresp_acc0)) && ((s_bresp_acc0) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((s_bresp_acc0) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((mhandshake_r) || ((mhandshake_r) === 1'bz) || (((mhandshake_r) === 1'bx) && (recovered_19_q == (p_0_in[6])))) recovered_19_q <= (p_0_in[6]);
  end

  // Reconstructed FDRE: esc_bresp_cnt_reg_7_a1af3b3
  reg recovered_20_q = 1'b0;
  assign bresp_cnt_reg[7] = recovered_20_q;
  wire recovered_20_reset = ((s_bresp_acc0)) && ((s_bresp_acc0) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((s_bresp_acc0) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((mhandshake_r) || ((mhandshake_r) === 1'bz) || (((mhandshake_r) === 1'bx) && (recovered_20_q == (p_0_in[7])))) recovered_20_q <= (p_0_in[7]);
  end

  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_simple_fifo__parameterized0 bresp_fifo_0
       (.aclk(aclk),
        .areset_d1(areset_d1),
        .areset_d1_reg(bresp_fifo_0_n_0),
        .bresp_push(bresp_push),
        .bvalid_i_reg(bid_fifo_0_n_4),
        .in({esc_s_bresp_acc_reg_n_0__1_a736ca3 ,esc_s_bresp_acc_reg_n_0__0_fe551a6 }),
        .m_axi_bready(m_axi_bready),
        .m_axi_bvalid(m_axi_bvalid),
        .mhandshake(mhandshake),
        .mhandshake_r(mhandshake_r),
        .esc_s_bresp_acc_reg_1_b8a96a2 (esc_s_bresp_acc_reg_1__0_5af6641 ),
        .shandshake_r(shandshake_r),
        .si_rs_bready(si_rs_bready),
        .si_rs_bvalid(si_rs_bvalid));

  // Reconstructed FDRE: bvalid_i_reg
  reg recovered_22_q = 1'b0;
  assign si_rs_bvalid = recovered_22_q;
  wire recovered_22_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_22_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_22_q == (bresp_fifo_0_n_0)))) recovered_22_q <= (bresp_fifo_0_n_0);
  end

  // Reconstructed FDRE: mhandshake_r_reg
  reg recovered_23_q = 1'b0;
  assign mhandshake_r = recovered_23_q;
  wire recovered_23_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_23_reset || (((areset_d1) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_23_q == (mhandshake)))) recovered_23_q <= (mhandshake);
  end

  // Reconstructed LUT2: esc_s_bresp_acc_0__i_1_11e99af
  assign esc_s_bresp_acc_0__i_1_n_0_e75d903 = ((s_bresp_acc0) ? (1'b0) : (esc_s_bresp_acc_reg_n_0__0_fe551a6));

  // Reconstructed LUT2: esc_s_bresp_acc_1__i_1_7a9e932
  assign esc_s_bresp_acc_1__i_1_n_0_25b7351 = ((s_bresp_acc0) ? (1'b0) : (esc_s_bresp_acc_reg_n_0__1_a736ca3));

  // Reconstructed FDRE: esc_s_bresp_acc_reg_0_91b26c7
  reg recovered_26_q = 1'b0;
  assign esc_s_bresp_acc_reg_n_0__0_fe551a6 = recovered_26_q;
  wire recovered_26_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_26_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_26_q == (esc_s_bresp_acc_0__i_1_n_0_e75d903)))) recovered_26_q <= (esc_s_bresp_acc_0__i_1_n_0_e75d903);
  end

  // Reconstructed FDRE: esc_s_bresp_acc_reg_1_b8a96a2
  reg recovered_27_q = 1'b0;
  assign esc_s_bresp_acc_reg_n_0__1_a736ca3 = recovered_27_q;
  wire recovered_27_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_27_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_27_q == (esc_s_bresp_acc_1__i_1_n_0_25b7351)))) recovered_27_q <= (esc_s_bresp_acc_1__i_1_n_0_25b7351);
  end

  // Reconstructed FDRE: shandshake_r_reg
  reg recovered_28_q = 1'b0;
  assign shandshake_r = recovered_28_q;
  wire recovered_28_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_28_reset || (((areset_d1) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_28_q == (shandshake)))) recovered_28_q <= (shandshake);
  end

endmodule

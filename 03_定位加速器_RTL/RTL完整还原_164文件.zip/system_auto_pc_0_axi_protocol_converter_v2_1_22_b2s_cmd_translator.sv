// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_cmd_translator
   (next_pending_r,
    wrap_next_pending,
    sel_first_reg_0,
    s_axburst_eq0,
    s_axburst_eq1,
    sel_first_reg_1,
    sel_first,
    Q,
    esc_axaddr_incr_reg_11_7a60f66 ,
    esc_axlen_cnt_reg_3_46333b8 ,
    esc_axlen_cnt_reg_0_56abf15 ,
    esc_axlen_cnt_reg_2_379d3d4 ,
    s_axburst_eq1_reg_0,
    sel_first_reg_2,
    esc_wrap_second_len_r_reg_3_130d984 ,
    esc_axaddr_offset_r_reg_3_9b4a3fc ,
    esc_m_payload_i_reg_3_3eab624 ,
    incr_next_pending,
    aclk,
    sel_first_i,
    s_axburst_eq0_reg_0,
    s_axburst_eq1_reg_1,
    sel_first_reg_3,
    sel_first_reg_4,
    next,
    esc_axlen_cnt_reg_7_01da386 ,
    esc_axaddr_wrap_reg_3_f9d1eab ,
    S,
    next_pending_r_reg,
    E,
    esc_axlen_cnt_reg_0__0_31fcd59 ,
    si_rs_awvalid,
    axaddr_incr,
    D,
    esc_axaddr_offset_r_reg_3__0_89647ed ,
    esc_wrap_cnt_r_reg_1_4617ef8 ,
    esc_axaddr_wrap_reg_0_4889146 ,
    esc_wrap_second_len_r_reg_3__0_61735c7 ,
    esc_axlen_cnt_reg_0__1_4dc9f21 ,
    esc_wrap_boundary_axaddr_r_reg_6_a91079e );
  output next_pending_r;
  output wrap_next_pending;
  output sel_first_reg_0;
  output s_axburst_eq0;
  output s_axburst_eq1;
  output sel_first_reg_1;
  output sel_first;
  output [11:0]Q;
  output [11:0]esc_axaddr_incr_reg_11_7a60f66 ;
  output esc_axlen_cnt_reg_3_46333b8 ;
  output [0:0]esc_axlen_cnt_reg_0_56abf15 ;
  output esc_axlen_cnt_reg_2_379d3d4 ;
  output s_axburst_eq1_reg_0;
  output sel_first_reg_2;
  output [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  output [3:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  output [3:0]esc_m_payload_i_reg_3_3eab624 ;
  input incr_next_pending;
  input aclk;
  input sel_first_i;
  input s_axburst_eq0_reg_0;
  input s_axburst_eq1_reg_1;
  input sel_first_reg_3;
  input sel_first_reg_4;
  input next;
  input [23:0]esc_axlen_cnt_reg_7_01da386 ;
  input [1:0]esc_axaddr_wrap_reg_3_f9d1eab ;
  input [1:0]S;
  input next_pending_r_reg;
  input [0:0]E;
  input [1:0]esc_axlen_cnt_reg_0__0_31fcd59 ;
  input si_rs_awvalid;
  input [11:0]axaddr_incr;
  input [2:0]D;
  input [3:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  input esc_wrap_cnt_r_reg_1_4617ef8 ;
  input [0:0]esc_axaddr_wrap_reg_0_4889146 ;
  input [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  input [0:0]esc_axlen_cnt_reg_0__1_4dc9f21 ;
  input [6:0]esc_wrap_boundary_axaddr_r_reg_6_a91079e ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [2:0]D;
  wire [0:0]E;
  wire [11:0]Q;
  wire [1:0]S;
  wire aclk;
  wire [11:0]axaddr_incr;
  wire [11:0]esc_axaddr_incr_reg_11_7a60f66 ;
  wire [3:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  wire [3:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  wire [0:0]esc_axaddr_wrap_reg_0_4889146 ;
  wire [1:0]esc_axaddr_wrap_reg_3_f9d1eab ;
  wire [0:0]esc_axlen_cnt_reg_0_56abf15 ;
  wire [1:0]esc_axlen_cnt_reg_0__0_31fcd59 ;
  wire [0:0]esc_axlen_cnt_reg_0__1_4dc9f21 ;
  wire esc_axlen_cnt_reg_2_379d3d4 ;
  wire esc_axlen_cnt_reg_3_46333b8 ;
  wire [23:0]esc_axlen_cnt_reg_7_01da386 ;
  wire incr_next_pending;
  wire [3:0]esc_m_payload_i_reg_3_3eab624 ;
  wire next;
  wire next_pending_r;
  wire next_pending_r_reg;
  wire s_axburst_eq0;
  wire s_axburst_eq0_reg_0;
  wire s_axburst_eq1;
  wire s_axburst_eq1_reg_0;
  wire s_axburst_eq1_reg_1;
  wire sel_first;
  wire sel_first_i;
  wire sel_first_reg_0;
  wire sel_first_reg_1;
  wire sel_first_reg_2;
  wire sel_first_reg_3;
  wire sel_first_reg_4;
  wire si_rs_awvalid;
  wire [6:0]esc_wrap_boundary_axaddr_r_reg_6_a91079e ;
  wire esc_wrap_cnt_r_reg_1_4617ef8 ;
  wire wrap_next_pending;
  wire [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  wire [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  wire [18:0]esc_NLW_wrap_cmd_0_axlen_cnt_reg_3__1_UNCONNECTED_39bd23f ;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_incr_cmd incr_cmd_0
       (.E(E),
        .S(S),
        .aclk(aclk),
        .axaddr_incr(axaddr_incr[7:0]),
        .esc_axaddr_incr_reg_11__0_994a90f (esc_axaddr_incr_reg_11_7a60f66 [5:0]),
        .esc_axlen_cnt_reg_0__0_31fcd59 (esc_axlen_cnt_reg_0__0_31fcd59 ),
        .esc_axlen_cnt_reg_0__1_4dc9f21 (esc_axaddr_wrap_reg_0_4889146 ),
        .esc_axlen_cnt_reg_2__0_56e9e46 (esc_axlen_cnt_reg_2_379d3d4 ),
        .esc_axlen_cnt_reg_7__0_4417ab1 ({esc_axlen_cnt_reg_7_01da386 [19:16],esc_axlen_cnt_reg_7_01da386 [13:12],esc_axlen_cnt_reg_7_01da386 [3:0]}),
        .incr_next_pending(incr_next_pending),
        .esc_m_payload_i_reg_3_3eab624 (esc_m_payload_i_reg_3_3eab624 ),
        .next(next),
        .next_pending_r(next_pending_r),
        .sel_first_reg_0(sel_first_reg_1),
        .sel_first_reg_1(sel_first_reg_3),
        .si_rs_awvalid(si_rs_awvalid));

  // Reconstructed FDRE: s_axburst_eq0_reg
  reg recovered_4_q = 1'b0;
  assign s_axburst_eq0 = recovered_4_q;
  wire recovered_4_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_4_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (s_axburst_eq0_reg_0)))) recovered_4_q <= (s_axburst_eq0_reg_0);
  end

  // Reconstructed FDRE: s_axburst_eq1_reg
  reg recovered_5_q = 1'b0;
  assign s_axburst_eq1 = recovered_5_q;
  wire recovered_5_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (s_axburst_eq1_reg_1)))) recovered_5_q <= (s_axburst_eq1_reg_1);
  end

  // Reconstructed FDRE: sel_first_reg
  reg recovered_6_q = 1'b0;
  assign sel_first_reg_0 = recovered_6_q;
  wire recovered_6_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (sel_first_i)))) recovered_6_q <= (sel_first_i);
  end

  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_wrap_cmd wrap_cmd_0
       (.D(D),
        .E(E),
        .Q(Q[5:0]),
        .aclk(aclk),
        .esc_axaddr_offset_r_reg_3__0_89647ed (esc_axaddr_offset_r_reg_3_9b4a3fc ),
        .esc_axaddr_offset_r_reg_3__1_174c336 (esc_axaddr_offset_r_reg_3__0_89647ed ),
        .esc_axaddr_wrap_reg_0__0_8ebf4f6 (esc_axaddr_wrap_reg_0_4889146 ),
        .esc_axaddr_wrap_reg_3__0_a824587 (esc_axaddr_wrap_reg_3_f9d1eab ),
        .esc_axlen_cnt_reg_0__0_31fcd59 (esc_axlen_cnt_reg_0_56abf15 ),
        .esc_axlen_cnt_reg_0__1_4dc9f21 (esc_axlen_cnt_reg_0__1_4dc9f21 ),
        .esc_axlen_cnt_reg_3__0_a623c36 (esc_axlen_cnt_reg_3_46333b8 ),
        .esc_axlen_cnt_reg_3__1_92cec45 ({esc_axlen_cnt_reg_7_01da386 [19:17],esc_axlen_cnt_reg_7_01da386 [15:12],esc_NLW_wrap_cmd_0_axlen_cnt_reg_3__1_UNCONNECTED_39bd23f [11:8],esc_axlen_cnt_reg_7_01da386 [7:0]}),
        .esc_m_axi_awaddr_11_2270491 (sel_first_reg_1),
        .next(next),
        .next_pending_r_reg_0(next_pending_r_reg),
        .s_axburst_eq0(s_axburst_eq0),
        .s_axburst_eq1(s_axburst_eq1),
        .s_axburst_eq1_reg(s_axburst_eq1_reg_0),
        .sel_first(sel_first),
        .sel_first_reg_0(sel_first_reg_2),
        .sel_first_reg_1(sel_first_reg_4),
        .esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 (esc_wrap_boundary_axaddr_r_reg_6_a91079e ),
        .esc_wrap_cnt_r_reg_1__0_205e7f9 (esc_wrap_cnt_r_reg_1_4617ef8 ),
        .wrap_next_pending(wrap_next_pending),
        .esc_wrap_second_len_r_reg_3__0_61735c7 (esc_wrap_second_len_r_reg_3_130d984 ),
        .esc_wrap_second_len_r_reg_3__1_e9d1a95 (esc_wrap_second_len_r_reg_3__0_61735c7 ));
endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_cmd_translator_1
   (sel_first_reg_0,
    sel_first_reg_1,
    sel_first_reg_2,
    O,
    esc_axaddr_wrap_reg_11_66b57d3 ,
    esc_axaddr_wrap_reg_7_0468310 ,
    esc_axaddr_wrap_reg_11__0_0f67430 ,
    esc_axaddr_incr_reg_11_7a60f66 ,
    next_pending_r_reg,
    r_rlast,
    s_axburst_eq1_reg_0,
    esc_axlen_cnt_reg_4_3087e61 ,
    sel_first_reg_3,
    esc_wrap_second_len_r_reg_3_130d984 ,
    esc_axaddr_offset_r_reg_3_9b4a3fc ,
    esc_wrap_boundary_axaddr_r_reg_11_dc8445d ,
    esc_m_payload_i_reg_3_3eab624 ,
    incr_next_pending,
    aclk,
    sel_first_i,
    sel_first_reg_4,
    sel_first_reg_5,
    S,
    esc_axaddr_incr_reg_3_2fa58c8 ,
    s_axburst_eq1_reg_1,
    esc_axlen_cnt_reg_7_01da386 ,
    r_push,
    E,
    next_pending_r_reg_0,
    esc_axaddr_incr_reg_11__0_994a90f ,
    esc_axaddr_incr_reg_7_9e14042 ,
    esc_axaddr_incr_reg_3__0_6132b06 ,
    Q,
    si_rs_arvalid,
    axaddr_offset,
    esc_wrap_cnt_r_reg_1_4617ef8 ,
    esc_axaddr_wrap_reg_0_4889146 ,
    D,
    esc_wrap_cnt_r_reg_3_8701380 ,
    esc_wrap_boundary_axaddr_r_reg_6_a91079e ,
    esc_axaddr_wrap_reg_11__1_cfa1a32 ,
    esc_axaddr_incr_reg_0_e6951a6 ,
    m_axi_arready);
  output sel_first_reg_0;
  output sel_first_reg_1;
  output sel_first_reg_2;
  output [3:0]O;
  output [11:0]esc_axaddr_wrap_reg_11_66b57d3 ;
  output [3:0]esc_axaddr_wrap_reg_7_0468310 ;
  output [3:0]esc_axaddr_wrap_reg_11__0_0f67430 ;
  output [11:0]esc_axaddr_incr_reg_11_7a60f66 ;
  output next_pending_r_reg;
  output r_rlast;
  output s_axburst_eq1_reg_0;
  output esc_axlen_cnt_reg_4_3087e61 ;
  output sel_first_reg_3;
  output [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  output [3:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  output [11:0]esc_wrap_boundary_axaddr_r_reg_11_dc8445d ;
  output [3:0]esc_m_payload_i_reg_3_3eab624 ;
  input incr_next_pending;
  input aclk;
  input sel_first_i;
  input sel_first_reg_4;
  input sel_first_reg_5;
  input [1:0]S;
  input [1:0]esc_axaddr_incr_reg_3_2fa58c8 ;
  input s_axburst_eq1_reg_1;
  input [20:0]esc_axlen_cnt_reg_7_01da386 ;
  input r_push;
  input [0:0]E;
  input next_pending_r_reg_0;
  input [3:0]esc_axaddr_incr_reg_11__0_994a90f ;
  input [3:0]esc_axaddr_incr_reg_7_9e14042 ;
  input [3:0]esc_axaddr_incr_reg_3__0_6132b06 ;
  input [1:0]Q;
  input si_rs_arvalid;
  input [3:0]axaddr_offset;
  input esc_wrap_cnt_r_reg_1_4617ef8 ;
  input [0:0]esc_axaddr_wrap_reg_0_4889146 ;
  input [3:0]D;
  input [2:0]esc_wrap_cnt_r_reg_3_8701380 ;
  input [6:0]esc_wrap_boundary_axaddr_r_reg_6_a91079e ;
  input [11:0]esc_axaddr_wrap_reg_11__1_cfa1a32 ;
  input [0:0]esc_axaddr_incr_reg_0_e6951a6 ;
  input m_axi_arready;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [3:0]D;
  wire [0:0]E;
  wire [3:0]O;
  wire [1:0]Q;
  wire [1:0]S;
  wire aclk;
  wire [0:0]esc_axaddr_incr_reg_0_e6951a6 ;
  wire [11:0]esc_axaddr_incr_reg_11_7a60f66 ;
  wire [1:0]esc_axaddr_incr_reg_3_2fa58c8 ;
  wire [3:0]esc_axaddr_incr_reg_3__0_6132b06 ;
  wire [3:0]esc_axaddr_incr_reg_7_9e14042 ;
  wire [3:0]axaddr_offset;
  wire [3:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  wire [0:0]esc_axaddr_wrap_reg_0_4889146 ;
  wire [11:0]esc_axaddr_wrap_reg_11_66b57d3 ;
  wire [11:0]esc_axaddr_wrap_reg_11__1_cfa1a32 ;
  wire [3:0]esc_axaddr_wrap_reg_7_0468310 ;
  wire esc_axlen_cnt_reg_4_3087e61 ;
  wire [20:0]esc_axlen_cnt_reg_7_01da386 ;
  wire incr_cmd_0_n_13;
  wire incr_next_pending;
  wire m_axi_arready;
  wire [3:0]esc_m_payload_i_reg_3_3eab624 ;
  wire next_pending_r_reg;
  wire next_pending_r_reg_0;
  wire r_push;
  wire r_rlast;
  wire s_axburst_eq0;
  wire s_axburst_eq1;
  wire s_axburst_eq1_reg_0;
  wire sel_first_i;
  wire sel_first_reg_0;
  wire sel_first_reg_1;
  wire sel_first_reg_2;
  wire sel_first_reg_3;
  wire sel_first_reg_4;
  wire sel_first_reg_5;
  wire si_rs_arvalid;
  wire [11:0]esc_wrap_boundary_axaddr_r_reg_11_dc8445d ;
  wire [6:0]esc_wrap_boundary_axaddr_r_reg_6_a91079e ;
  wire wrap_cmd_0_n_26;
  wire esc_wrap_cnt_r_reg_1_4617ef8 ;
  wire [2:0]esc_wrap_cnt_r_reg_3_8701380 ;
  wire wrap_next_pending;
  wire [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  wire [12:0]esc_NLW_wrap_cmd_0_axlen_cnt_reg_3__0_UNCONNECTED_fe6f81d ;

  // Reconstructed LUT3: esc_FSM_sequential_state_1__i_3_e907487
  assign s_axburst_eq1_reg_0 = ((s_axburst_eq0) ? (((esc_axlen_cnt_reg_7_01da386 [12]) ? (s_axburst_eq1) : (1'b1))) : (((esc_axlen_cnt_reg_7_01da386 [12]) ? (s_axburst_eq1) : (1'b0))));

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_incr_cmd_2 incr_cmd_0
       (.E(E),
        .Q(Q),
        .aclk(aclk),
        .esc_axaddr_incr_reg_0__0_fcbf1b4 (esc_axaddr_incr_reg_0_e6951a6 ),
        .esc_axaddr_incr_reg_11__0_994a90f (esc_axaddr_incr_reg_11_7a60f66 [5:0]),
        .esc_axaddr_incr_reg_3__0_6132b06 (esc_axaddr_incr_reg_3_2fa58c8 ),
        .esc_axaddr_incr_reg_3__1_c45cd30 (esc_axaddr_incr_reg_3__0_6132b06 ),
        .esc_axaddr_incr_reg_7__0_7321d37 (esc_axaddr_incr_reg_7_9e14042 ),
        .esc_axlen_cnt_reg_0__0_31fcd59 (esc_axaddr_wrap_reg_0_4889146 ),
        .esc_axlen_cnt_reg_7__0_4417ab1 ({esc_axlen_cnt_reg_7_01da386 [16:12],esc_axlen_cnt_reg_7_01da386 [10:9],esc_axlen_cnt_reg_7_01da386 [3:0]}),
        .incr_next_pending(incr_next_pending),
        .m_axi_arready(m_axi_arready),
        .esc_m_payload_i_reg_39_ea68878 (incr_cmd_0_n_13),
        .esc_m_payload_i_reg_3_3eab624 (esc_m_payload_i_reg_3_3eab624 ),
        .next_pending_r_reg_0(next_pending_r_reg),
        .r_push(r_push),
        .s_axburst_eq0_reg_0(next_pending_r_reg_0),
        .sel_first_i(sel_first_i),
        .sel_first_reg_0(sel_first_reg_1),
        .sel_first_reg_1(sel_first_reg_4),
        .si_rs_arvalid(si_rs_arvalid),
        .wrap_next_pending(wrap_next_pending));

  // Reconstructed LUT3: r_rlast_r_i_1
  assign r_rlast = ((s_axburst_eq1) ? (((esc_axlen_cnt_reg_7_01da386 [12]) ? (1'b0) : (~(s_axburst_eq0)))) : (((esc_axlen_cnt_reg_7_01da386 [12]) ? (1'b1) : (~(s_axburst_eq0)))));

  // Reconstructed FDRE: s_axburst_eq0_reg
  reg recovered_6_q = 1'b0;
  assign s_axburst_eq0 = recovered_6_q;
  wire recovered_6_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (incr_cmd_0_n_13)))) recovered_6_q <= (incr_cmd_0_n_13);
  end

  // Reconstructed FDRE: s_axburst_eq1_reg
  reg recovered_7_q = 1'b0;
  assign s_axburst_eq1 = recovered_7_q;
  wire recovered_7_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (wrap_cmd_0_n_26)))) recovered_7_q <= (wrap_cmd_0_n_26);
  end

  // Reconstructed FDRE: sel_first_reg
  reg recovered_8_q = 1'b0;
  assign sel_first_reg_0 = recovered_8_q;
  wire recovered_8_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_8_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_8_q == (sel_first_i)))) recovered_8_q <= (sel_first_i);
  end

  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_wrap_cmd_3 wrap_cmd_0
       (.D(D),
        .E(E),
        .O(O),
        .Q(Q[1]),
        .S(S),
        .aclk(aclk),
        .axaddr_offset(axaddr_offset),
        .esc_axaddr_offset_r_reg_3__0_89647ed (esc_axaddr_offset_r_reg_3_9b4a3fc ),
        .esc_axaddr_wrap_reg_0__0_8ebf4f6 (esc_axaddr_wrap_reg_0_4889146 ),
        .esc_axaddr_wrap_reg_11__0_0f67430 (esc_axaddr_wrap_reg_11_66b57d3 [5:0]),
        .esc_axaddr_wrap_reg_11__2_82ad777 (esc_axaddr_wrap_reg_11__1_cfa1a32 [7:0]),
        .esc_axaddr_wrap_reg_7__0_317aa52 (esc_axaddr_wrap_reg_7_0468310 ),
        .esc_axlen_cnt_reg_3__0_a623c36 ({esc_axlen_cnt_reg_7_01da386 [16:9],esc_NLW_wrap_cmd_0_axlen_cnt_reg_3__0_UNCONNECTED_fe6f81d [4:1],esc_axlen_cnt_reg_7_01da386 [4]}),
        .esc_axlen_cnt_reg_4__0_bb101a4 (esc_axlen_cnt_reg_4_3087e61 ),
        .esc_m_axi_araddr_11_4618f72 (sel_first_reg_1),
        .esc_m_payload_i_reg_39_ea68878 (wrap_cmd_0_n_26),
        .next_pending_r_reg_0(next_pending_r_reg_0),
        .r_push(r_push),
        .s_axburst_eq1_reg(next_pending_r_reg),
        .sel_first_i(sel_first_i),
        .sel_first_reg_0(sel_first_reg_2),
        .sel_first_reg_1(sel_first_reg_3),
        .sel_first_reg_2(sel_first_reg_5),
        .si_rs_arvalid(si_rs_arvalid),
        .esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 (esc_wrap_boundary_axaddr_r_reg_11_dc8445d [7:0]),
        .esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 (esc_wrap_boundary_axaddr_r_reg_6_a91079e ),
        .esc_wrap_cnt_r_reg_1__0_205e7f9 (esc_wrap_cnt_r_reg_1_4617ef8 ),
        .esc_wrap_cnt_r_reg_3__0_82edd32 (esc_wrap_cnt_r_reg_3_8701380 ),
        .wrap_next_pending(wrap_next_pending),
        .esc_wrap_second_len_r_reg_3__0_61735c7 (esc_wrap_second_len_r_reg_3_130d984 ));
endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_incr_cmd
   (next_pending_r,
    sel_first_reg_0,
    esc_axaddr_incr_reg_11__0_994a90f ,
    esc_axlen_cnt_reg_2__0_56e9e46 ,
    esc_m_payload_i_reg_3_3eab624 ,
    incr_next_pending,
    aclk,
    sel_first_reg_1,
    S,
    next,
    esc_axlen_cnt_reg_0__0_31fcd59 ,
    si_rs_awvalid,
    esc_axlen_cnt_reg_7__0_4417ab1 ,
    E,
    axaddr_incr,
    esc_axlen_cnt_reg_0__1_4dc9f21 );
  output next_pending_r;
  output sel_first_reg_0;
  output [11:0]esc_axaddr_incr_reg_11__0_994a90f ;
  output esc_axlen_cnt_reg_2__0_56e9e46 ;
  output [3:0]esc_m_payload_i_reg_3_3eab624 ;
  input incr_next_pending;
  input aclk;
  input sel_first_reg_1;
  input [1:0]S;
  input next;
  input [1:0]esc_axlen_cnt_reg_0__0_31fcd59 ;
  input si_rs_awvalid;
  input [13:0]esc_axlen_cnt_reg_7__0_4417ab1 ;
  input [0:0]E;
  input [11:0]axaddr_incr;
  input [0:0]esc_axlen_cnt_reg_0__1_4dc9f21 ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]E;
  wire [1:0]S;
  wire aclk;
  wire [11:0]axaddr_incr;
  wire esc_axaddr_incr_11__i_1_n_0_1397659 ;
  wire esc_axaddr_incr_3__i_12_n_0_a26b335 ;
  wire esc_axaddr_incr_3__i_13_n_0_a3e90a2 ;
  wire [11:0]esc_axaddr_incr_reg_11__0_c1f8e0c ;
  wire esc_axaddr_incr_reg_3__i_3_n_0_17ceca3 ;
  wire esc_axaddr_incr_reg_3__i_3_n_4_6de9b63 ;
  wire esc_axaddr_incr_reg_3__i_3_n_5_b4f6540 ;
  wire esc_axaddr_incr_reg_3__i_3_n_6_55fb8de ;
  wire esc_axaddr_incr_reg_3__i_3_n_7_4a06007 ;
  wire esc_axaddr_incr_reg_7__i_3_n_4_0a10508 ;
  wire esc_axaddr_incr_reg_7__i_3_n_5_43d9b68 ;
  wire esc_axaddr_incr_reg_7__i_3_n_6_8968e4e ;
  wire esc_axaddr_incr_reg_7__i_3_n_7_f1c1393 ;
  wire [8:0]axlen_cnt;
  wire esc_axlen_cnt_0__i_1__0_n_0_e83ecbb ;
  wire esc_axlen_cnt_1__i_1__0_n_0_656a01b ;
  wire esc_axlen_cnt_2__i_1__0_n_0_e5e3d92 ;
  wire esc_axlen_cnt_3__i_1__0_n_0_7355a98 ;
  wire esc_axlen_cnt_3__i_2__1_n_0_22ad326 ;
  wire esc_axlen_cnt_4__i_1__0_n_0_e227796 ;
  wire esc_axlen_cnt_5__i_1_n_0_43a6a26 ;
  wire esc_axlen_cnt_5__i_2_n_0_601cdfe ;
  wire esc_axlen_cnt_6__i_1_n_0_5d9505a ;
  wire esc_axlen_cnt_7__i_1_n_0_4728bfc ;
  wire esc_axlen_cnt_8__i_2_n_0_17d7d90 ;
  wire esc_axlen_cnt_8__i_3_n_0_91e9491 ;
  wire [1:0]esc_axlen_cnt_reg_0__0_31fcd59 ;
  wire [0:0]esc_axlen_cnt_reg_0__1_4dc9f21 ;
  wire esc_axlen_cnt_reg_2__0_56e9e46 ;
  wire [13:0]esc_axlen_cnt_reg_7__0_4417ab1 ;
  wire incr_next_pending;
  wire [3:0]esc_m_payload_i_reg_3_3eab624 ;
  wire next;
  wire next_pending_r;
  wire next_pending_r_i_5_n_0;
  wire [11:0]p_1_in;
  wire sel_first_reg_0;
  wire sel_first_reg_1;
  wire si_rs_awvalid;
  wire [3:0]esc_NLW_axaddr_incr_reg_3__i_3_CO_UNCONNECTED_59f5c13 ;

  assign esc_axaddr_incr_reg_11__0_994a90f [5:0] = esc_axaddr_incr_reg_11__0_c1f8e0c [5:0];

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT3: esc_axaddr_incr_0__i_1_9fb5903
  assign p_1_in[0] = ((esc_axaddr_incr_reg_3__i_3_n_7_4a06007) ? (((sel_first_reg_0) ? (axaddr_incr[0]) : (1'b1))) : (((sel_first_reg_0) ? (axaddr_incr[0]) : (1'b0))));

  // Reconstructed LUT2: esc_axaddr_incr_11__i_1_3718702
  assign esc_axaddr_incr_11__i_1_n_0_1397659 = ((next) ? (1'b1) : (sel_first_reg_0));

  // Reconstructed LUT3: esc_axaddr_incr_1__i_1_20fab09
  assign p_1_in[1] = ((esc_axaddr_incr_reg_3__i_3_n_6_55fb8de) ? (((sel_first_reg_0) ? (axaddr_incr[1]) : (1'b1))) : (((sel_first_reg_0) ? (axaddr_incr[1]) : (1'b0))));

  // Reconstructed LUT3: esc_axaddr_incr_2__i_1_e74dec5
  assign p_1_in[2] = ((esc_axaddr_incr_reg_3__i_3_n_5_b4f6540) ? (((sel_first_reg_0) ? (axaddr_incr[2]) : (1'b1))) : (((sel_first_reg_0) ? (axaddr_incr[2]) : (1'b0))));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_1_934d951
  assign p_1_in[3] = ((esc_axaddr_incr_reg_3__i_3_n_4_6de9b63) ? (((sel_first_reg_0) ? (axaddr_incr[3]) : (1'b1))) : (((sel_first_reg_0) ? (axaddr_incr[3]) : (1'b0))));

  // Reconstructed LUT4: esc_axaddr_incr_3__i_10_656b2ce
  assign esc_m_payload_i_reg_3_3eab624 [0] = ((next) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (1'b0) : (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (1'b0) : (~(esc_axlen_cnt_reg_7__0_4417ab1 [0])))))) : (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (1'b0) : (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (1'b0) : (esc_axlen_cnt_reg_7__0_4417ab1 [0]))))));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_12_eed7387
  assign esc_axaddr_incr_3__i_12_n_0_a26b335 = ((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (esc_axaddr_incr_reg_11__0_c1f8e0c [2]) : (~(esc_axaddr_incr_reg_11__0_c1f8e0c [2])))) : (esc_axaddr_incr_reg_11__0_c1f8e0c [2]));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_13_6d3491b
  assign esc_axaddr_incr_3__i_13_n_0_a3e90a2 = ((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (esc_axaddr_incr_reg_11__0_c1f8e0c [1]) : (~(esc_axaddr_incr_reg_11__0_c1f8e0c [1])))) : (esc_axaddr_incr_reg_11__0_c1f8e0c [1]));

  // Reconstructed LUT4: esc_axaddr_incr_3__i_7_b339971
  assign esc_m_payload_i_reg_3_3eab624 [3] = ((next) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (~(esc_axlen_cnt_reg_7__0_4417ab1 [3])) : (esc_axlen_cnt_reg_7__0_4417ab1 [3]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [3]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [3]));

  // Reconstructed LUT4: esc_axaddr_incr_3__i_8_4c94e30
  assign esc_m_payload_i_reg_3_3eab624 [2] = ((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (1'b0) : (esc_axlen_cnt_reg_7__0_4417ab1 [2]))) : (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (((next) ? (~(esc_axlen_cnt_reg_7__0_4417ab1 [2])) : (esc_axlen_cnt_reg_7__0_4417ab1 [2]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [2]))));

  // Reconstructed LUT4: esc_axaddr_incr_3__i_9_c69616f
  assign esc_m_payload_i_reg_3_3eab624 [1] = ((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (1'b0) : (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (((next) ? (~(esc_axlen_cnt_reg_7__0_4417ab1 [1])) : (esc_axlen_cnt_reg_7__0_4417ab1 [1]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [1]))));

  // Reconstructed LUT3: esc_axaddr_incr_4__i_1_579b178
  assign p_1_in[4] = ((esc_axaddr_incr_reg_7__i_3_n_7_f1c1393) ? (((sel_first_reg_0) ? (axaddr_incr[4]) : (1'b1))) : (((sel_first_reg_0) ? (axaddr_incr[4]) : (1'b0))));

  // Reconstructed LUT3: esc_axaddr_incr_5__i_1_95a44c7
  assign p_1_in[5] = ((esc_axaddr_incr_reg_7__i_3_n_6_8968e4e) ? (((sel_first_reg_0) ? (axaddr_incr[5]) : (1'b1))) : (((sel_first_reg_0) ? (axaddr_incr[5]) : (1'b0))));

  // Reconstructed LUT3: esc_axaddr_incr_6__i_1_c749cff
  assign p_1_in[6] = ((esc_axaddr_incr_reg_7__i_3_n_5_43d9b68) ? (((sel_first_reg_0) ? (axaddr_incr[6]) : (1'b1))) : (((sel_first_reg_0) ? (axaddr_incr[6]) : (1'b0))));

  // Reconstructed LUT3: esc_axaddr_incr_7__i_1_0d9992a
  assign p_1_in[7] = ((esc_axaddr_incr_reg_7__i_3_n_4_0a10508) ? (((sel_first_reg_0) ? (axaddr_incr[7]) : (1'b1))) : (((sel_first_reg_0) ? (axaddr_incr[7]) : (1'b0))));

  // Reconstructed FDRE: esc_axaddr_incr_reg_0_e6951a6
  reg recovered_18_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [0] = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((esc_axaddr_incr_11__i_1_n_0_1397659) || ((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bz) || (((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bx) && (recovered_18_q == (p_1_in[0])))) recovered_18_q <= (p_1_in[0]);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_1_d6d54b2
  reg recovered_19_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [1] = recovered_19_q;
  wire recovered_19_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((esc_axaddr_incr_11__i_1_n_0_1397659) || ((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bz) || (((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bx) && (recovered_19_q == (p_1_in[1])))) recovered_19_q <= (p_1_in[1]);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_2_987eab4
  reg recovered_20_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [2] = recovered_20_q;
  wire recovered_20_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((esc_axaddr_incr_11__i_1_n_0_1397659) || ((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bz) || (((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bx) && (recovered_20_q == (p_1_in[2])))) recovered_20_q <= (p_1_in[2]);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_3_2fa58c8
  reg recovered_21_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [3] = recovered_21_q;
  wire recovered_21_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_21_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((esc_axaddr_incr_11__i_1_n_0_1397659) || ((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bz) || (((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bx) && (recovered_21_q == (p_1_in[3])))) recovered_21_q <= (p_1_in[3]);
  end

  // Reconstructed CARRY4: esc_axaddr_incr_reg_3__i_3_d11f7e9
  wire [3:0] recovered_22_co, recovered_22_o, recovered_22_s, recovered_22_di;
  assign recovered_22_s = {S[1],esc_axaddr_incr_3__i_12_n_0_a26b335 ,esc_axaddr_incr_3__i_13_n_0_a3e90a2 ,S[0]};
  assign recovered_22_di = esc_axaddr_incr_reg_11__0_c1f8e0c [3:0];
  wire recovered_22_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_22_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_22_o[0] = recovered_22_s[0] ^ (recovered_22_ci || recovered_22_cy);
  assign recovered_22_co[0] = (recovered_22_s[0] & (recovered_22_ci || recovered_22_cy)) | (~recovered_22_s[0] & recovered_22_di[0]);
  assign recovered_22_o[1] = recovered_22_s[1] ^ recovered_22_co[0];
  assign recovered_22_co[1] = (recovered_22_s[1] & recovered_22_co[0]) | (~recovered_22_s[1] & recovered_22_di[1]);
  assign recovered_22_o[2] = recovered_22_s[2] ^ recovered_22_co[1];
  assign recovered_22_co[2] = (recovered_22_s[2] & recovered_22_co[1]) | (~recovered_22_s[2] & recovered_22_di[2]);
  assign recovered_22_o[3] = recovered_22_s[3] ^ recovered_22_co[2];
  assign recovered_22_co[3] = (recovered_22_s[3] & recovered_22_co[2]) | (~recovered_22_s[3] & recovered_22_di[3]);
  assign {esc_axaddr_incr_reg_3__i_3_n_0_17ceca3 ,esc_NLW_axaddr_incr_reg_3__i_3_CO_UNCONNECTED_59f5c13 [2:0]} = recovered_22_co;
  assign {esc_axaddr_incr_reg_3__i_3_n_4_6de9b63 ,esc_axaddr_incr_reg_3__i_3_n_5_b4f6540 ,esc_axaddr_incr_reg_3__i_3_n_6_55fb8de ,esc_axaddr_incr_reg_3__i_3_n_7_4a06007 } = recovered_22_o;

  // Reconstructed FDRE: esc_axaddr_incr_reg_4_6c9fbf9
  reg recovered_23_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [4] = recovered_23_q;
  wire recovered_23_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_23_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((esc_axaddr_incr_11__i_1_n_0_1397659) || ((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bz) || (((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bx) && (recovered_23_q == (p_1_in[4])))) recovered_23_q <= (p_1_in[4]);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_5_a5f36b7
  reg recovered_24_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [5] = recovered_24_q;
  wire recovered_24_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_24_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((esc_axaddr_incr_11__i_1_n_0_1397659) || ((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bz) || (((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bx) && (recovered_24_q == (p_1_in[5])))) recovered_24_q <= (p_1_in[5]);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_6_74a8f29
  reg recovered_25_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [6] = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((esc_axaddr_incr_11__i_1_n_0_1397659) || ((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bz) || (((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bx) && (recovered_25_q == (p_1_in[6])))) recovered_25_q <= (p_1_in[6]);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_7_9e14042
  reg recovered_26_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [7] = recovered_26_q;
  wire recovered_26_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_26_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((esc_axaddr_incr_11__i_1_n_0_1397659) || ((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bz) || (((esc_axaddr_incr_11__i_1_n_0_1397659) === 1'bx) && (recovered_26_q == (p_1_in[7])))) recovered_26_q <= (p_1_in[7]);
  end

  // Reconstructed CARRY4: esc_axaddr_incr_reg_7__i_3_423b0fe
  wire [3:0] recovered_27_co, recovered_27_o, recovered_27_s, recovered_27_di;
  assign recovered_27_s = esc_axaddr_incr_reg_11__0_c1f8e0c [7:4];
  assign recovered_27_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_27_ci = ((esc_axaddr_incr_reg_3__i_3_n_0_17ceca3) !== 1'bz) && (esc_axaddr_incr_reg_3__i_3_n_0_17ceca3);
  wire recovered_27_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_27_o[0] = recovered_27_s[0] ^ (recovered_27_ci || recovered_27_cy);
  assign recovered_27_co[0] = (recovered_27_s[0] & (recovered_27_ci || recovered_27_cy)) | (~recovered_27_s[0] & recovered_27_di[0]);
  assign recovered_27_o[1] = recovered_27_s[1] ^ recovered_27_co[0];
  assign recovered_27_co[1] = (recovered_27_s[1] & recovered_27_co[0]) | (~recovered_27_s[1] & recovered_27_di[1]);
  assign recovered_27_o[2] = recovered_27_s[2] ^ recovered_27_co[1];
  assign recovered_27_co[2] = (recovered_27_s[2] & recovered_27_co[1]) | (~recovered_27_s[2] & recovered_27_di[2]);
  assign recovered_27_o[3] = recovered_27_s[3] ^ recovered_27_co[2];
  assign recovered_27_co[3] = (recovered_27_s[3] & recovered_27_co[2]) | (~recovered_27_s[3] & recovered_27_di[3]);
  assign {esc_axaddr_incr_reg_7__i_3_n_4_0a10508 ,esc_axaddr_incr_reg_7__i_3_n_5_43d9b68 ,esc_axaddr_incr_reg_7__i_3_n_6_8968e4e ,esc_axaddr_incr_reg_7__i_3_n_7_f1c1393 } = recovered_27_o;

  // Reconstructed LUT6: esc_axlen_cnt_0__i_1__0_36c5cb3
  assign esc_axlen_cnt_0__i_1__0_n_0_e83ecbb = ((esc_axlen_cnt_reg_7__0_4417ab1 [6]) ? (((si_rs_awvalid) ? (((esc_axlen_cnt_reg_0__0_31fcd59 [0]) ? (((esc_axlen_cnt_reg_0__0_31fcd59 [1]) ? (((esc_axlen_cnt_reg_2__0_56e9e46) ? (~(axlen_cnt[0])) : (1'b0))) : (1'b1))) : (((esc_axlen_cnt_reg_2__0_56e9e46) ? (~(axlen_cnt[0])) : (1'b0))))) : (((esc_axlen_cnt_reg_2__0_56e9e46) ? (~(axlen_cnt[0])) : (1'b0))))) : (((esc_axlen_cnt_reg_2__0_56e9e46) ? (~(axlen_cnt[0])) : (1'b0))));

  // Reconstructed LUT5: esc_axlen_cnt_1__i_1__0_0ba921d
  assign esc_axlen_cnt_1__i_1__0_n_0_656a01b = ((axlen_cnt[1]) ? (((axlen_cnt[0]) ? (((esc_axlen_cnt_reg_2__0_56e9e46) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [7]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [7]) : (1'b0))))) : (((axlen_cnt[0]) ? (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [7]) : (1'b0))) : (((esc_axlen_cnt_reg_2__0_56e9e46) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [7]) : (1'b0))))))));

  // Reconstructed LUT6: esc_axlen_cnt_2__i_1__0_216f945
  assign esc_axlen_cnt_2__i_1__0_n_0_e5e3d92 = ((axlen_cnt[2]) ? (((axlen_cnt[0]) ? (((esc_axlen_cnt_reg_2__0_56e9e46) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [8]) : (1'b0))))) : (((axlen_cnt[1]) ? (((esc_axlen_cnt_reg_2__0_56e9e46) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [8]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [8]) : (1'b0))))))) : (((axlen_cnt[0]) ? (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [8]) : (1'b0))) : (((axlen_cnt[1]) ? (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [8]) : (1'b0))) : (((esc_axlen_cnt_reg_2__0_56e9e46) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [8]) : (1'b0))))))))));

  // Reconstructed LUT5: esc_axlen_cnt_3__i_1__0_79de624
  assign esc_axlen_cnt_3__i_1__0_n_0_7355a98 = ((axlen_cnt[3]) ? (((esc_axlen_cnt_3__i_2__1_n_0_22ad326) ? (((esc_axlen_cnt_reg_2__0_56e9e46) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [9]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [9]) : (1'b0))))) : (((esc_axlen_cnt_3__i_2__1_n_0_22ad326) ? (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [9]) : (1'b0))) : (((esc_axlen_cnt_reg_2__0_56e9e46) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [9]) : (1'b0))))))));

  // Reconstructed LUT3: esc_axlen_cnt_3__i_2__1_c163d85
  assign esc_axlen_cnt_3__i_2__1_n_0_22ad326 = ((axlen_cnt[2]) ? (1'b1) : (((axlen_cnt[0]) ? (1'b1) : (axlen_cnt[1]))));

  // Reconstructed LUT3: esc_axlen_cnt_4__i_1__0_36917a2
  assign esc_axlen_cnt_4__i_1__0_n_0_e227796 = ((axlen_cnt[4]) ? (((esc_axlen_cnt_reg_2__0_56e9e46) ? (esc_axlen_cnt_5__i_2_n_0_601cdfe) : (1'b0))) : (((esc_axlen_cnt_reg_2__0_56e9e46) ? (~(esc_axlen_cnt_5__i_2_n_0_601cdfe)) : (1'b0))));

  // Reconstructed LUT4: esc_axlen_cnt_5__i_1_a90268d
  assign esc_axlen_cnt_5__i_1_n_0_43a6a26 = ((axlen_cnt[5]) ? (((esc_axlen_cnt_reg_2__0_56e9e46) ? (((axlen_cnt[4]) ? (1'b1) : (esc_axlen_cnt_5__i_2_n_0_601cdfe))) : (1'b0))) : (((esc_axlen_cnt_reg_2__0_56e9e46) ? (((axlen_cnt[4]) ? (1'b0) : (~(esc_axlen_cnt_5__i_2_n_0_601cdfe)))) : (1'b0))));

  // Reconstructed LUT4: esc_axlen_cnt_5__i_2_0d4a465
  assign esc_axlen_cnt_5__i_2_n_0_601cdfe = ((axlen_cnt[3]) ? (1'b1) : (((axlen_cnt[1]) ? (1'b1) : (((axlen_cnt[0]) ? (1'b1) : (axlen_cnt[2]))))));

  // Reconstructed LUT3: esc_axlen_cnt_6__i_1_99241ca
  assign esc_axlen_cnt_6__i_1_n_0_5d9505a = ((axlen_cnt[6]) ? (((esc_axlen_cnt_reg_2__0_56e9e46) ? (esc_axlen_cnt_8__i_3_n_0_91e9491) : (1'b0))) : (((esc_axlen_cnt_reg_2__0_56e9e46) ? (~(esc_axlen_cnt_8__i_3_n_0_91e9491)) : (1'b0))));

  // Reconstructed LUT4: esc_axlen_cnt_7__i_1_c5a0442
  assign esc_axlen_cnt_7__i_1_n_0_4728bfc = ((axlen_cnt[7]) ? (((esc_axlen_cnt_reg_2__0_56e9e46) ? (((axlen_cnt[6]) ? (1'b1) : (esc_axlen_cnt_8__i_3_n_0_91e9491))) : (1'b0))) : (((esc_axlen_cnt_reg_2__0_56e9e46) ? (((axlen_cnt[6]) ? (1'b0) : (~(esc_axlen_cnt_8__i_3_n_0_91e9491)))) : (1'b0))));

  // Reconstructed LUT5: esc_axlen_cnt_8__i_2_867b5bc
  assign esc_axlen_cnt_8__i_2_n_0_17d7d90 = ((axlen_cnt[8]) ? (((esc_axlen_cnt_reg_2__0_56e9e46) ? (((axlen_cnt[7]) ? (1'b1) : (((esc_axlen_cnt_8__i_3_n_0_91e9491) ? (1'b1) : (axlen_cnt[6]))))) : (1'b0))) : (((esc_axlen_cnt_reg_2__0_56e9e46) ? (((axlen_cnt[7]) ? (1'b0) : (((esc_axlen_cnt_8__i_3_n_0_91e9491) ? (1'b0) : (~(axlen_cnt[6])))))) : (1'b0))));

  // Reconstructed LUT6: esc_axlen_cnt_8__i_3_cab0430
  assign esc_axlen_cnt_8__i_3_n_0_91e9491 = ((axlen_cnt[5]) ? (1'b1) : (((axlen_cnt[3]) ? (1'b1) : (((axlen_cnt[1]) ? (1'b1) : (((axlen_cnt[0]) ? (1'b1) : (((axlen_cnt[2]) ? (1'b1) : (axlen_cnt[4]))))))))));

  // Reconstructed FDRE: esc_axlen_cnt_reg_0_56abf15
  reg recovered_40_q = 1'b0;
  assign axlen_cnt[0] = recovered_40_q;
  wire recovered_40_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_40_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_40_q == 1'b0))) recovered_40_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__1_4dc9f21) || ((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bz) || (((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bx) && (recovered_40_q == (esc_axlen_cnt_0__i_1__0_n_0_e83ecbb)))) recovered_40_q <= (esc_axlen_cnt_0__i_1__0_n_0_e83ecbb);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_1_405fc67
  reg recovered_41_q = 1'b0;
  assign axlen_cnt[1] = recovered_41_q;
  wire recovered_41_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_41_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_41_q == 1'b0))) recovered_41_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__1_4dc9f21) || ((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bz) || (((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bx) && (recovered_41_q == (esc_axlen_cnt_1__i_1__0_n_0_656a01b)))) recovered_41_q <= (esc_axlen_cnt_1__i_1__0_n_0_656a01b);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_2_379d3d4
  reg recovered_42_q = 1'b0;
  assign axlen_cnt[2] = recovered_42_q;
  wire recovered_42_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_42_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_42_q == 1'b0))) recovered_42_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__1_4dc9f21) || ((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bz) || (((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bx) && (recovered_42_q == (esc_axlen_cnt_2__i_1__0_n_0_e5e3d92)))) recovered_42_q <= (esc_axlen_cnt_2__i_1__0_n_0_e5e3d92);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_3_46333b8
  reg recovered_43_q = 1'b0;
  assign axlen_cnt[3] = recovered_43_q;
  wire recovered_43_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_43_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__1_4dc9f21) || ((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bz) || (((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bx) && (recovered_43_q == (esc_axlen_cnt_3__i_1__0_n_0_7355a98)))) recovered_43_q <= (esc_axlen_cnt_3__i_1__0_n_0_7355a98);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_4_3087e61
  reg recovered_44_q = 1'b0;
  assign axlen_cnt[4] = recovered_44_q;
  wire recovered_44_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_44_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__1_4dc9f21) || ((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bz) || (((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bx) && (recovered_44_q == (esc_axlen_cnt_4__i_1__0_n_0_e227796)))) recovered_44_q <= (esc_axlen_cnt_4__i_1__0_n_0_e227796);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_5_823e3b6
  reg recovered_45_q = 1'b0;
  assign axlen_cnt[5] = recovered_45_q;
  wire recovered_45_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_45_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_45_q == 1'b0))) recovered_45_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__1_4dc9f21) || ((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bz) || (((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bx) && (recovered_45_q == (esc_axlen_cnt_5__i_1_n_0_43a6a26)))) recovered_45_q <= (esc_axlen_cnt_5__i_1_n_0_43a6a26);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_6_661f05a
  reg recovered_46_q = 1'b0;
  assign axlen_cnt[6] = recovered_46_q;
  wire recovered_46_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_46_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_46_q == 1'b0))) recovered_46_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__1_4dc9f21) || ((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bz) || (((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bx) && (recovered_46_q == (esc_axlen_cnt_6__i_1_n_0_5d9505a)))) recovered_46_q <= (esc_axlen_cnt_6__i_1_n_0_5d9505a);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_7_01da386
  reg recovered_47_q = 1'b0;
  assign axlen_cnt[7] = recovered_47_q;
  wire recovered_47_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_47_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_47_q == 1'b0))) recovered_47_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__1_4dc9f21) || ((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bz) || (((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bx) && (recovered_47_q == (esc_axlen_cnt_7__i_1_n_0_4728bfc)))) recovered_47_q <= (esc_axlen_cnt_7__i_1_n_0_4728bfc);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_8_6ec61c1
  reg recovered_48_q = 1'b0;
  assign axlen_cnt[8] = recovered_48_q;
  wire recovered_48_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_48_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_48_q == 1'b0))) recovered_48_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__1_4dc9f21) || ((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bz) || (((esc_axlen_cnt_reg_0__1_4dc9f21) === 1'bx) && (recovered_48_q == (esc_axlen_cnt_8__i_2_n_0_17d7d90)))) recovered_48_q <= (esc_axlen_cnt_8__i_2_n_0_17d7d90);
  end

  // Reconstructed LUT6: next_pending_r_i_3
  assign esc_axlen_cnt_reg_2__0_56e9e46 = ((E) ? (1'b0) : (((axlen_cnt[3]) ? (1'b1) : (((axlen_cnt[4]) ? (1'b1) : (((axlen_cnt[1]) ? (1'b1) : (((axlen_cnt[2]) ? (1'b1) : (next_pending_r_i_5_n_0))))))))));

  // Reconstructed LUT4: next_pending_r_i_5
  assign next_pending_r_i_5_n_0 = ((axlen_cnt[7]) ? (1'b1) : (((axlen_cnt[8]) ? (1'b1) : (((axlen_cnt[5]) ? (1'b1) : (axlen_cnt[6]))))));

  // Reconstructed FDRE: next_pending_r_reg
  reg recovered_51_q = 1'b0;
  assign next_pending_r = recovered_51_q;
  wire recovered_51_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_51_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_51_q == 1'b0))) recovered_51_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_51_q == (incr_next_pending)))) recovered_51_q <= (incr_next_pending);
  end

  // Reconstructed FDRE: sel_first_reg
  reg recovered_52_q = 1'b0;
  assign sel_first_reg_0 = recovered_52_q;
  wire recovered_52_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_52_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_52_q == 1'b0))) recovered_52_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_52_q == (sel_first_reg_1)))) recovered_52_q <= (sel_first_reg_1);
  end

endmodule

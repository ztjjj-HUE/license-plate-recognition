// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_incr_cmd_2
   (sel_first_reg_0,
    esc_axaddr_incr_reg_11__0_994a90f ,
    esc_m_payload_i_reg_39_ea68878 ,
    next_pending_r_reg_0,
    esc_m_payload_i_reg_3_3eab624 ,
    incr_next_pending,
    aclk,
    sel_first_reg_1,
    esc_axaddr_incr_reg_3__0_6132b06 ,
    s_axburst_eq0_reg,
    sel_first_i,
    esc_axlen_cnt_reg_7__0_4417ab1 ,
    wrap_next_pending,
    r_push,
    E,
    s_axburst_eq0_reg_0,
    esc_axaddr_incr_reg_11__1_58ded89 ,
    esc_axaddr_incr_reg_7__0_7321d37 ,
    esc_axaddr_incr_reg_3__1_c45cd30 ,
    Q,
    si_rs_arvalid,
    esc_axlen_cnt_reg_0__0_31fcd59 ,
    esc_axaddr_incr_reg_0__0_fcbf1b4 ,
    m_axi_arready);
  output sel_first_reg_0;
  output [11:0]esc_axaddr_incr_reg_11__0_994a90f ;
  output esc_m_payload_i_reg_39_ea68878 ;
  output next_pending_r_reg_0;
  output [3:0]esc_m_payload_i_reg_3_3eab624 ;
  input incr_next_pending;
  input aclk;
  input sel_first_reg_1;
  input [1:0]esc_axaddr_incr_reg_3__0_6132b06 ;
  input s_axburst_eq0_reg;
  input sel_first_i;
  input [14:0]esc_axlen_cnt_reg_7__0_4417ab1 ;
  input wrap_next_pending;
  input r_push;
  input [0:0]E;
  input s_axburst_eq0_reg_0;
  input [3:0]esc_axaddr_incr_reg_11__1_58ded89 ;
  input [3:0]esc_axaddr_incr_reg_7__0_7321d37 ;
  input [3:0]esc_axaddr_incr_reg_3__1_c45cd30 ;
  input [1:0]Q;
  input si_rs_arvalid;
  input [0:0]esc_axlen_cnt_reg_0__0_31fcd59 ;
  input [0:0]esc_axaddr_incr_reg_0__0_fcbf1b4 ;
  input m_axi_arready;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]E;
  wire [1:0]Q;
  wire aclk;
  wire esc_axaddr_incr_0__i_1__0_n_0_f6e239b ;
  wire esc_axaddr_incr_1__i_1__0_n_0_9e85f55 ;
  wire esc_axaddr_incr_2__i_1__0_n_0_8b521b9 ;
  wire esc_axaddr_incr_3__i_12_n_0_a26b335 ;
  wire esc_axaddr_incr_3__i_13_n_0_a3e90a2 ;
  wire esc_axaddr_incr_3__i_1__0_n_0_4ccc26e ;
  wire esc_axaddr_incr_4__i_1__0_n_0_2121d6f ;
  wire esc_axaddr_incr_5__i_1__0_n_0_9cb0494 ;
  wire esc_axaddr_incr_6__i_1__0_n_0_4aff204 ;
  wire esc_axaddr_incr_7__i_1__0_n_0_0f64b3f ;
  wire [0:0]esc_axaddr_incr_reg_0__0_fcbf1b4 ;
  wire [11:0]esc_axaddr_incr_reg_11__0_c1f8e0c ;
  wire [1:0]esc_axaddr_incr_reg_3__0_6132b06 ;
  wire [3:0]esc_axaddr_incr_reg_3__1_c45cd30 ;
  wire esc_axaddr_incr_reg_3__i_3__0_n_0_9e09ec4 ;
  wire esc_axaddr_incr_reg_3__i_3__0_n_4_758ac0c ;
  wire esc_axaddr_incr_reg_3__i_3__0_n_5_e4a0b2c ;
  wire esc_axaddr_incr_reg_3__i_3__0_n_6_f911e34 ;
  wire esc_axaddr_incr_reg_3__i_3__0_n_7_2cf5748 ;
  wire [3:0]esc_axaddr_incr_reg_7__0_7321d37 ;
  wire esc_axaddr_incr_reg_7__i_3__0_n_4_f08175f ;
  wire esc_axaddr_incr_reg_7__i_3__0_n_5_9a7c9af ;
  wire esc_axaddr_incr_reg_7__i_3__0_n_6_0e347ab ;
  wire esc_axaddr_incr_reg_7__i_3__0_n_7_49a46ed ;
  wire esc_axlen_cnt_0__i_1__1_n_0_03e0c5e ;
  wire esc_axlen_cnt_1__i_1__2_n_0_4336e64 ;
  wire esc_axlen_cnt_2__i_1__2_n_0_7522db7 ;
  wire esc_axlen_cnt_3__i_1__2_n_0_5f3aa38 ;
  wire esc_axlen_cnt_3__i_2__2_n_0_466a47b ;
  wire esc_axlen_cnt_4__i_1__2_n_0_221a47a ;
  wire esc_axlen_cnt_5__i_1__0_n_0_8f9ee8a ;
  wire esc_axlen_cnt_5__i_2__0_n_0_b0d357a ;
  wire esc_axlen_cnt_6__i_1__0_n_0_77f9d40 ;
  wire esc_axlen_cnt_7__i_1__0_n_0_1757170 ;
  wire esc_axlen_cnt_8__i_2__0_n_0_3a24127 ;
  wire esc_axlen_cnt_8__i_3__0_n_0_ae1a0fd ;
  wire esc_axlen_cnt_8__i_4_n_0_f58fcfa ;
  wire esc_axlen_cnt_8__i_5_n_0_2e0d7f1 ;
  wire [0:0]esc_axlen_cnt_reg_0__0_31fcd59 ;
  wire [14:0]esc_axlen_cnt_reg_7__0_4417ab1 ;
  wire esc_axlen_cnt_reg_n_0__0_6b9adfb ;
  wire esc_axlen_cnt_reg_n_0__1_db9fc63 ;
  wire esc_axlen_cnt_reg_n_0__2_a2d60e4 ;
  wire esc_axlen_cnt_reg_n_0__3_8857ffe ;
  wire esc_axlen_cnt_reg_n_0__4_f78fcda ;
  wire esc_axlen_cnt_reg_n_0__5_09f5246 ;
  wire esc_axlen_cnt_reg_n_0__6_ccec93f ;
  wire esc_axlen_cnt_reg_n_0__7_86ccd5b ;
  wire esc_axlen_cnt_reg_n_0__8_fb2ebdd ;
  wire incr_next_pending;
  wire m_axi_arready;
  wire esc_m_payload_i_reg_39_ea68878 ;
  wire [3:0]esc_m_payload_i_reg_3_3eab624 ;
  wire next_pending_r;
  wire next_pending_r_reg_0;
  wire r_push;
  wire s_axburst_eq0_reg_0;
  wire sel_first_i;
  wire sel_first_reg_0;
  wire sel_first_reg_1;
  wire si_rs_arvalid;
  wire wrap_next_pending;
  wire [3:0]esc_NLW_axaddr_incr_reg_3__i_3__0_CO_UNCONNECTED_e8af2eb ;

  assign esc_axaddr_incr_reg_11__0_994a90f [5:0] = esc_axaddr_incr_reg_11__0_c1f8e0c [5:0];

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT3: esc_axaddr_incr_0__i_1__0_c0c428d
  assign esc_axaddr_incr_0__i_1__0_n_0_f6e239b = ((esc_axaddr_incr_reg_3__i_3__0_n_7_2cf5748) ? (((sel_first_reg_0) ? (esc_axaddr_incr_reg_3__1_c45cd30 [0]) : (1'b1))) : (((sel_first_reg_0) ? (esc_axaddr_incr_reg_3__1_c45cd30 [0]) : (1'b0))));

  // Reconstructed LUT3: esc_axaddr_incr_1__i_1__0_8cef6f7
  assign esc_axaddr_incr_1__i_1__0_n_0_9e85f55 = ((esc_axaddr_incr_reg_3__i_3__0_n_6_f911e34) ? (((sel_first_reg_0) ? (esc_axaddr_incr_reg_3__1_c45cd30 [1]) : (1'b1))) : (((sel_first_reg_0) ? (esc_axaddr_incr_reg_3__1_c45cd30 [1]) : (1'b0))));

  // Reconstructed LUT3: esc_axaddr_incr_2__i_1__0_a8cc45f
  assign esc_axaddr_incr_2__i_1__0_n_0_8b521b9 = ((esc_axaddr_incr_reg_3__i_3__0_n_5_e4a0b2c) ? (((sel_first_reg_0) ? (esc_axaddr_incr_reg_3__1_c45cd30 [2]) : (1'b1))) : (((sel_first_reg_0) ? (esc_axaddr_incr_reg_3__1_c45cd30 [2]) : (1'b0))));

  // Reconstructed LUT6: esc_axaddr_incr_3__i_10_656b2ce
  assign esc_m_payload_i_reg_3_3eab624 [0] = ((m_axi_arready) ? (((Q[0]) ? (((Q[1]) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (1'b0) : (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (1'b0) : (~(esc_axlen_cnt_reg_7__0_4417ab1 [0])))))) : (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (1'b0) : (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (1'b0) : (esc_axlen_cnt_reg_7__0_4417ab1 [0]))))))) : (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (1'b0) : (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (1'b0) : (esc_axlen_cnt_reg_7__0_4417ab1 [0]))))))) : (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (1'b0) : (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (1'b0) : (esc_axlen_cnt_reg_7__0_4417ab1 [0]))))));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_12_eed7387
  assign esc_axaddr_incr_3__i_12_n_0_a26b335 = ((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (esc_axaddr_incr_reg_11__0_c1f8e0c [2]) : (~(esc_axaddr_incr_reg_11__0_c1f8e0c [2])))) : (esc_axaddr_incr_reg_11__0_c1f8e0c [2]));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_13_6d3491b
  assign esc_axaddr_incr_3__i_13_n_0_a3e90a2 = ((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (esc_axaddr_incr_reg_11__0_c1f8e0c [1]) : (~(esc_axaddr_incr_reg_11__0_c1f8e0c [1])))) : (esc_axaddr_incr_reg_11__0_c1f8e0c [1]));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_1__0_f5b5036
  assign esc_axaddr_incr_3__i_1__0_n_0_4ccc26e = ((esc_axaddr_incr_reg_3__i_3__0_n_4_758ac0c) ? (((sel_first_reg_0) ? (esc_axaddr_incr_reg_3__1_c45cd30 [3]) : (1'b1))) : (((sel_first_reg_0) ? (esc_axaddr_incr_reg_3__1_c45cd30 [3]) : (1'b0))));

  // Reconstructed LUT6: esc_axaddr_incr_3__i_7_b339971
  assign esc_m_payload_i_reg_3_3eab624 [3] = ((m_axi_arready) ? (((Q[0]) ? (((Q[1]) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (~(esc_axlen_cnt_reg_7__0_4417ab1 [3])) : (esc_axlen_cnt_reg_7__0_4417ab1 [3]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [3]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [3]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [3]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [3]));

  // Reconstructed LUT6: esc_axaddr_incr_3__i_8_4c94e30
  assign esc_m_payload_i_reg_3_3eab624 [2] = ((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (1'b0) : (esc_axlen_cnt_reg_7__0_4417ab1 [2]))) : (((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (((m_axi_arready) ? (((Q[0]) ? (((Q[1]) ? (~(esc_axlen_cnt_reg_7__0_4417ab1 [2])) : (esc_axlen_cnt_reg_7__0_4417ab1 [2]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [2]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [2]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [2]))));

  // Reconstructed LUT6: esc_axaddr_incr_3__i_9_c69616f
  assign esc_m_payload_i_reg_3_3eab624 [1] = ((esc_axlen_cnt_reg_7__0_4417ab1 [5]) ? (1'b0) : (((esc_axlen_cnt_reg_7__0_4417ab1 [4]) ? (((m_axi_arready) ? (((Q[0]) ? (((Q[1]) ? (~(esc_axlen_cnt_reg_7__0_4417ab1 [1])) : (esc_axlen_cnt_reg_7__0_4417ab1 [1]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [1]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [1]))) : (esc_axlen_cnt_reg_7__0_4417ab1 [1]))));

  // Reconstructed LUT3: esc_axaddr_incr_4__i_1__0_299a01f
  assign esc_axaddr_incr_4__i_1__0_n_0_2121d6f = ((esc_axaddr_incr_reg_7__i_3__0_n_7_49a46ed) ? (((sel_first_reg_0) ? (esc_axaddr_incr_reg_7__0_7321d37 [0]) : (1'b1))) : (((sel_first_reg_0) ? (esc_axaddr_incr_reg_7__0_7321d37 [0]) : (1'b0))));

  // Reconstructed LUT3: esc_axaddr_incr_5__i_1__0_d3b3484
  assign esc_axaddr_incr_5__i_1__0_n_0_9cb0494 = ((esc_axaddr_incr_reg_7__i_3__0_n_6_0e347ab) ? (((sel_first_reg_0) ? (esc_axaddr_incr_reg_7__0_7321d37 [1]) : (1'b1))) : (((sel_first_reg_0) ? (esc_axaddr_incr_reg_7__0_7321d37 [1]) : (1'b0))));

  // Reconstructed LUT3: esc_axaddr_incr_6__i_1__0_c393fbe
  assign esc_axaddr_incr_6__i_1__0_n_0_4aff204 = ((esc_axaddr_incr_reg_7__i_3__0_n_5_9a7c9af) ? (((sel_first_reg_0) ? (esc_axaddr_incr_reg_7__0_7321d37 [2]) : (1'b1))) : (((sel_first_reg_0) ? (esc_axaddr_incr_reg_7__0_7321d37 [2]) : (1'b0))));

  // Reconstructed LUT3: esc_axaddr_incr_7__i_1__0_84d94ca
  assign esc_axaddr_incr_7__i_1__0_n_0_0f64b3f = ((esc_axaddr_incr_reg_7__i_3__0_n_4_f08175f) ? (((sel_first_reg_0) ? (esc_axaddr_incr_reg_7__0_7321d37 [3]) : (1'b1))) : (((sel_first_reg_0) ? (esc_axaddr_incr_reg_7__0_7321d37 [3]) : (1'b0))));

  // Reconstructed FDRE: esc_axaddr_incr_reg_0_e6951a6
  reg recovered_17_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [0] = recovered_17_q;
  wire recovered_17_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_17_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((esc_axaddr_incr_reg_0__0_fcbf1b4) || ((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bz) || (((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bx) && (recovered_17_q == (esc_axaddr_incr_0__i_1__0_n_0_f6e239b)))) recovered_17_q <= (esc_axaddr_incr_0__i_1__0_n_0_f6e239b);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_1_d6d54b2
  reg recovered_18_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [1] = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((esc_axaddr_incr_reg_0__0_fcbf1b4) || ((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bz) || (((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bx) && (recovered_18_q == (esc_axaddr_incr_1__i_1__0_n_0_9e85f55)))) recovered_18_q <= (esc_axaddr_incr_1__i_1__0_n_0_9e85f55);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_2_987eab4
  reg recovered_19_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [2] = recovered_19_q;
  wire recovered_19_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((esc_axaddr_incr_reg_0__0_fcbf1b4) || ((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bz) || (((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bx) && (recovered_19_q == (esc_axaddr_incr_2__i_1__0_n_0_8b521b9)))) recovered_19_q <= (esc_axaddr_incr_2__i_1__0_n_0_8b521b9);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_3_2fa58c8
  reg recovered_20_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [3] = recovered_20_q;
  wire recovered_20_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((esc_axaddr_incr_reg_0__0_fcbf1b4) || ((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bz) || (((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bx) && (recovered_20_q == (esc_axaddr_incr_3__i_1__0_n_0_4ccc26e)))) recovered_20_q <= (esc_axaddr_incr_3__i_1__0_n_0_4ccc26e);
  end

  // Reconstructed CARRY4: esc_axaddr_incr_reg_3__i_3__0_6d37c96
  wire [3:0] recovered_21_co, recovered_21_o, recovered_21_s, recovered_21_di;
  assign recovered_21_s = {esc_axaddr_incr_reg_3__0_6132b06 [1],esc_axaddr_incr_3__i_12_n_0_a26b335 ,esc_axaddr_incr_3__i_13_n_0_a3e90a2 ,esc_axaddr_incr_reg_3__0_6132b06 [0]};
  assign recovered_21_di = esc_axaddr_incr_reg_11__0_c1f8e0c [3:0];
  wire recovered_21_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_21_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_21_o[0] = recovered_21_s[0] ^ (recovered_21_ci || recovered_21_cy);
  assign recovered_21_co[0] = (recovered_21_s[0] & (recovered_21_ci || recovered_21_cy)) | (~recovered_21_s[0] & recovered_21_di[0]);
  assign recovered_21_o[1] = recovered_21_s[1] ^ recovered_21_co[0];
  assign recovered_21_co[1] = (recovered_21_s[1] & recovered_21_co[0]) | (~recovered_21_s[1] & recovered_21_di[1]);
  assign recovered_21_o[2] = recovered_21_s[2] ^ recovered_21_co[1];
  assign recovered_21_co[2] = (recovered_21_s[2] & recovered_21_co[1]) | (~recovered_21_s[2] & recovered_21_di[2]);
  assign recovered_21_o[3] = recovered_21_s[3] ^ recovered_21_co[2];
  assign recovered_21_co[3] = (recovered_21_s[3] & recovered_21_co[2]) | (~recovered_21_s[3] & recovered_21_di[3]);
  assign {esc_axaddr_incr_reg_3__i_3__0_n_0_9e09ec4 ,esc_NLW_axaddr_incr_reg_3__i_3__0_CO_UNCONNECTED_e8af2eb [2:0]} = recovered_21_co;
  assign {esc_axaddr_incr_reg_3__i_3__0_n_4_758ac0c ,esc_axaddr_incr_reg_3__i_3__0_n_5_e4a0b2c ,esc_axaddr_incr_reg_3__i_3__0_n_6_f911e34 ,esc_axaddr_incr_reg_3__i_3__0_n_7_2cf5748 } = recovered_21_o;

  // Reconstructed FDRE: esc_axaddr_incr_reg_4_6c9fbf9
  reg recovered_22_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [4] = recovered_22_q;
  wire recovered_22_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_22_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((esc_axaddr_incr_reg_0__0_fcbf1b4) || ((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bz) || (((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bx) && (recovered_22_q == (esc_axaddr_incr_4__i_1__0_n_0_2121d6f)))) recovered_22_q <= (esc_axaddr_incr_4__i_1__0_n_0_2121d6f);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_5_a5f36b7
  reg recovered_23_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [5] = recovered_23_q;
  wire recovered_23_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_23_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((esc_axaddr_incr_reg_0__0_fcbf1b4) || ((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bz) || (((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bx) && (recovered_23_q == (esc_axaddr_incr_5__i_1__0_n_0_9cb0494)))) recovered_23_q <= (esc_axaddr_incr_5__i_1__0_n_0_9cb0494);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_6_74a8f29
  reg recovered_24_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [6] = recovered_24_q;
  wire recovered_24_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_24_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((esc_axaddr_incr_reg_0__0_fcbf1b4) || ((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bz) || (((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bx) && (recovered_24_q == (esc_axaddr_incr_6__i_1__0_n_0_4aff204)))) recovered_24_q <= (esc_axaddr_incr_6__i_1__0_n_0_4aff204);
  end

  // Reconstructed FDRE: esc_axaddr_incr_reg_7_9e14042
  reg recovered_25_q = 1'b0;
  assign esc_axaddr_incr_reg_11__0_c1f8e0c [7] = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((esc_axaddr_incr_reg_0__0_fcbf1b4) || ((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bz) || (((esc_axaddr_incr_reg_0__0_fcbf1b4) === 1'bx) && (recovered_25_q == (esc_axaddr_incr_7__i_1__0_n_0_0f64b3f)))) recovered_25_q <= (esc_axaddr_incr_7__i_1__0_n_0_0f64b3f);
  end

  // Reconstructed CARRY4: esc_axaddr_incr_reg_7__i_3__0_732363d
  wire [3:0] recovered_26_co, recovered_26_o, recovered_26_s, recovered_26_di;
  assign recovered_26_s = esc_axaddr_incr_reg_11__0_c1f8e0c [7:4];
  assign recovered_26_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_26_ci = ((esc_axaddr_incr_reg_3__i_3__0_n_0_9e09ec4) !== 1'bz) && (esc_axaddr_incr_reg_3__i_3__0_n_0_9e09ec4);
  wire recovered_26_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_26_o[0] = recovered_26_s[0] ^ (recovered_26_ci || recovered_26_cy);
  assign recovered_26_co[0] = (recovered_26_s[0] & (recovered_26_ci || recovered_26_cy)) | (~recovered_26_s[0] & recovered_26_di[0]);
  assign recovered_26_o[1] = recovered_26_s[1] ^ recovered_26_co[0];
  assign recovered_26_co[1] = (recovered_26_s[1] & recovered_26_co[0]) | (~recovered_26_s[1] & recovered_26_di[1]);
  assign recovered_26_o[2] = recovered_26_s[2] ^ recovered_26_co[1];
  assign recovered_26_co[2] = (recovered_26_s[2] & recovered_26_co[1]) | (~recovered_26_s[2] & recovered_26_di[2]);
  assign recovered_26_o[3] = recovered_26_s[3] ^ recovered_26_co[2];
  assign recovered_26_co[3] = (recovered_26_s[3] & recovered_26_co[2]) | (~recovered_26_s[3] & recovered_26_di[3]);
  assign {esc_axaddr_incr_reg_7__i_3__0_n_4_f08175f ,esc_axaddr_incr_reg_7__i_3__0_n_5_9a7c9af ,esc_axaddr_incr_reg_7__i_3__0_n_6_0e347ab ,esc_axaddr_incr_reg_7__i_3__0_n_7_49a46ed } = recovered_26_o;

  // Reconstructed LUT5: esc_axlen_cnt_0__i_1__1_95279ca
  assign esc_axlen_cnt_0__i_1__1_n_0_03e0c5e = ((esc_axlen_cnt_reg_7__0_4417ab1 [7]) ? (((si_rs_arvalid) ? (((Q[1]) ? (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (~(esc_axlen_cnt_reg_n_0__0_6b9adfb)) : (1'b0))) : (1'b1))) : (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (~(esc_axlen_cnt_reg_n_0__0_6b9adfb)) : (1'b0))))) : (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (~(esc_axlen_cnt_reg_n_0__0_6b9adfb)) : (1'b0))));

  // Reconstructed LUT5: esc_axlen_cnt_1__i_1__2_f084e8c
  assign esc_axlen_cnt_1__i_1__2_n_0_4336e64 = ((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [8]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [8]) : (1'b0))))) : (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [8]) : (1'b0))) : (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [8]) : (1'b0))))))));

  // Reconstructed LUT6: esc_axlen_cnt_2__i_1__2_ac8c4ec
  assign esc_axlen_cnt_2__i_1__2_n_0_7522db7 = ((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [9]) : (1'b0))))) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [9]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [9]) : (1'b0))))))) : (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [9]) : (1'b0))) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [9]) : (1'b0))) : (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [9]) : (1'b0))))))))));

  // Reconstructed LUT5: esc_axlen_cnt_3__i_1__2_1ea4125
  assign esc_axlen_cnt_3__i_1__2_n_0_5f3aa38 = ((esc_axlen_cnt_reg_n_0__3_8857ffe) ? (((esc_axlen_cnt_3__i_2__2_n_0_466a47b) ? (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [10]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [10]) : (1'b0))))) : (((esc_axlen_cnt_3__i_2__2_n_0_466a47b) ? (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [10]) : (1'b0))) : (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_7__0_4417ab1 [10]) : (1'b0))))))));

  // Reconstructed LUT3: esc_axlen_cnt_3__i_2__2_c58a56e
  assign esc_axlen_cnt_3__i_2__2_n_0_466a47b = ((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (1'b1) : (esc_axlen_cnt_reg_n_0__1_db9fc63))));

  // Reconstructed LUT3: esc_axlen_cnt_4__i_1__2_06603f3
  assign esc_axlen_cnt_4__i_1__2_n_0_221a47a = ((esc_axlen_cnt_reg_n_0__4_f78fcda) ? (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (esc_axlen_cnt_5__i_2__0_n_0_b0d357a) : (1'b0))) : (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (~(esc_axlen_cnt_5__i_2__0_n_0_b0d357a)) : (1'b0))));

  // Reconstructed LUT4: esc_axlen_cnt_5__i_1__0_07e4c50
  assign esc_axlen_cnt_5__i_1__0_n_0_8f9ee8a = ((esc_axlen_cnt_reg_n_0__5_09f5246) ? (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (((esc_axlen_cnt_reg_n_0__4_f78fcda) ? (1'b1) : (esc_axlen_cnt_5__i_2__0_n_0_b0d357a))) : (1'b0))) : (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (((esc_axlen_cnt_reg_n_0__4_f78fcda) ? (1'b0) : (~(esc_axlen_cnt_5__i_2__0_n_0_b0d357a)))) : (1'b0))));

  // Reconstructed LUT4: esc_axlen_cnt_5__i_2__0_526f858
  assign esc_axlen_cnt_5__i_2__0_n_0_b0d357a = ((esc_axlen_cnt_reg_n_0__3_8857ffe) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (1'b1) : (esc_axlen_cnt_reg_n_0__2_a2d60e4))))));

  // Reconstructed LUT3: esc_axlen_cnt_6__i_1__0_d22f00c
  assign esc_axlen_cnt_6__i_1__0_n_0_77f9d40 = ((esc_axlen_cnt_reg_n_0__6_ccec93f) ? (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (esc_axlen_cnt_8__i_3__0_n_0_ae1a0fd) : (1'b0))) : (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (~(esc_axlen_cnt_8__i_3__0_n_0_ae1a0fd)) : (1'b0))));

  // Reconstructed LUT4: esc_axlen_cnt_7__i_1__0_a3edf98
  assign esc_axlen_cnt_7__i_1__0_n_0_1757170 = ((esc_axlen_cnt_reg_n_0__7_86ccd5b) ? (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (((esc_axlen_cnt_reg_n_0__6_ccec93f) ? (1'b1) : (esc_axlen_cnt_8__i_3__0_n_0_ae1a0fd))) : (1'b0))) : (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (((esc_axlen_cnt_reg_n_0__6_ccec93f) ? (1'b0) : (~(esc_axlen_cnt_8__i_3__0_n_0_ae1a0fd)))) : (1'b0))));

  // Reconstructed LUT5: esc_axlen_cnt_8__i_2__0_e86396f
  assign esc_axlen_cnt_8__i_2__0_n_0_3a24127 = ((esc_axlen_cnt_reg_n_0__8_fb2ebdd) ? (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (((esc_axlen_cnt_reg_n_0__7_86ccd5b) ? (1'b1) : (((esc_axlen_cnt_8__i_3__0_n_0_ae1a0fd) ? (1'b1) : (esc_axlen_cnt_reg_n_0__6_ccec93f))))) : (1'b0))) : (((esc_axlen_cnt_8__i_4_n_0_f58fcfa) ? (((esc_axlen_cnt_reg_n_0__7_86ccd5b) ? (1'b0) : (((esc_axlen_cnt_8__i_3__0_n_0_ae1a0fd) ? (1'b0) : (~(esc_axlen_cnt_reg_n_0__6_ccec93f)))))) : (1'b0))));

  // Reconstructed LUT6: esc_axlen_cnt_8__i_3__0_19beac4
  assign esc_axlen_cnt_8__i_3__0_n_0_ae1a0fd = ((esc_axlen_cnt_reg_n_0__5_09f5246) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__3_8857ffe) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (1'b1) : (esc_axlen_cnt_reg_n_0__4_f78fcda))))))))));

  // Reconstructed LUT6: esc_axlen_cnt_8__i_4_70d30c3
  assign esc_axlen_cnt_8__i_4_n_0_f58fcfa = ((E) ? (1'b0) : (((esc_axlen_cnt_reg_n_0__3_8857ffe) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__4_f78fcda) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (1'b1) : (esc_axlen_cnt_8__i_5_n_0_2e0d7f1))))))))));

  // Reconstructed LUT4: esc_axlen_cnt_8__i_5_ec07438
  assign esc_axlen_cnt_8__i_5_n_0_2e0d7f1 = ((esc_axlen_cnt_reg_n_0__7_86ccd5b) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__8_fb2ebdd) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__5_09f5246) ? (1'b1) : (esc_axlen_cnt_reg_n_0__6_ccec93f))))));

  // Reconstructed FDRE: esc_axlen_cnt_reg_0_56abf15
  reg recovered_41_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__0_6b9adfb = recovered_41_q;
  wire recovered_41_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_41_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_41_q == 1'b0))) recovered_41_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__0_31fcd59) || ((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bz) || (((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bx) && (recovered_41_q == (esc_axlen_cnt_0__i_1__1_n_0_03e0c5e)))) recovered_41_q <= (esc_axlen_cnt_0__i_1__1_n_0_03e0c5e);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_1_405fc67
  reg recovered_42_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__1_db9fc63 = recovered_42_q;
  wire recovered_42_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_42_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_42_q == 1'b0))) recovered_42_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__0_31fcd59) || ((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bz) || (((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bx) && (recovered_42_q == (esc_axlen_cnt_1__i_1__2_n_0_4336e64)))) recovered_42_q <= (esc_axlen_cnt_1__i_1__2_n_0_4336e64);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_2_379d3d4
  reg recovered_43_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__2_a2d60e4 = recovered_43_q;
  wire recovered_43_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_43_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__0_31fcd59) || ((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bz) || (((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bx) && (recovered_43_q == (esc_axlen_cnt_2__i_1__2_n_0_7522db7)))) recovered_43_q <= (esc_axlen_cnt_2__i_1__2_n_0_7522db7);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_3_46333b8
  reg recovered_44_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__3_8857ffe = recovered_44_q;
  wire recovered_44_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_44_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__0_31fcd59) || ((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bz) || (((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bx) && (recovered_44_q == (esc_axlen_cnt_3__i_1__2_n_0_5f3aa38)))) recovered_44_q <= (esc_axlen_cnt_3__i_1__2_n_0_5f3aa38);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_4_3087e61
  reg recovered_45_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__4_f78fcda = recovered_45_q;
  wire recovered_45_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_45_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_45_q == 1'b0))) recovered_45_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__0_31fcd59) || ((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bz) || (((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bx) && (recovered_45_q == (esc_axlen_cnt_4__i_1__2_n_0_221a47a)))) recovered_45_q <= (esc_axlen_cnt_4__i_1__2_n_0_221a47a);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_5_823e3b6
  reg recovered_46_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__5_09f5246 = recovered_46_q;
  wire recovered_46_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_46_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_46_q == 1'b0))) recovered_46_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__0_31fcd59) || ((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bz) || (((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bx) && (recovered_46_q == (esc_axlen_cnt_5__i_1__0_n_0_8f9ee8a)))) recovered_46_q <= (esc_axlen_cnt_5__i_1__0_n_0_8f9ee8a);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_6_661f05a
  reg recovered_47_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__6_ccec93f = recovered_47_q;
  wire recovered_47_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_47_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_47_q == 1'b0))) recovered_47_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__0_31fcd59) || ((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bz) || (((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bx) && (recovered_47_q == (esc_axlen_cnt_6__i_1__0_n_0_77f9d40)))) recovered_47_q <= (esc_axlen_cnt_6__i_1__0_n_0_77f9d40);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_7_01da386
  reg recovered_48_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__7_86ccd5b = recovered_48_q;
  wire recovered_48_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_48_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_48_q == 1'b0))) recovered_48_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__0_31fcd59) || ((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bz) || (((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bx) && (recovered_48_q == (esc_axlen_cnt_7__i_1__0_n_0_1757170)))) recovered_48_q <= (esc_axlen_cnt_7__i_1__0_n_0_1757170);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_8_6ec61c1
  reg recovered_49_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__8_fb2ebdd = recovered_49_q;
  wire recovered_49_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_49_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_49_q == 1'b0))) recovered_49_q <= 1'b0;
    else if ((esc_axlen_cnt_reg_0__0_31fcd59) || ((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bz) || (((esc_axlen_cnt_reg_0__0_31fcd59) === 1'bx) && (recovered_49_q == (esc_axlen_cnt_8__i_2__0_n_0_3a24127)))) recovered_49_q <= (esc_axlen_cnt_8__i_2__0_n_0_3a24127);
  end

  // Reconstructed LUT5: next_pending_r_i_2__1
  assign next_pending_r_reg_0 = ((s_axburst_eq0_reg_0) ? (1'b1) : (((E) ? (((r_push) ? (esc_axlen_cnt_8__i_4_n_0_f58fcfa) : (1'b0))) : (((next_pending_r) ? (((r_push) ? (esc_axlen_cnt_8__i_4_n_0_f58fcfa) : (1'b1))) : (((r_push) ? (esc_axlen_cnt_8__i_4_n_0_f58fcfa) : (1'b0))))))));

  // Reconstructed FDRE: next_pending_r_reg
  reg recovered_51_q = 1'b0;
  assign next_pending_r = recovered_51_q;
  wire recovered_51_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_51_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_51_q == 1'b0))) recovered_51_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_51_q == (incr_next_pending)))) recovered_51_q <= (incr_next_pending);
  end

  // Reconstructed LUT4: s_axburst_eq0_i_1__0
  assign esc_m_payload_i_reg_39_ea68878 = ((wrap_next_pending) ? (((esc_axlen_cnt_reg_7__0_4417ab1 [6]) ? (((sel_first_i) ? (next_pending_r_reg_0) : (1'b1))) : (next_pending_r_reg_0))) : (((esc_axlen_cnt_reg_7__0_4417ab1 [6]) ? (((sel_first_i) ? (next_pending_r_reg_0) : (1'b0))) : (next_pending_r_reg_0))));

  // Reconstructed FDRE: sel_first_reg
  reg recovered_53_q = 1'b0;
  assign sel_first_reg_0 = recovered_53_q;
  wire recovered_53_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_53_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_53_q == 1'b0))) recovered_53_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_53_q == (sel_first_reg_1)))) recovered_53_q <= (sel_first_reg_1);
  end

endmodule

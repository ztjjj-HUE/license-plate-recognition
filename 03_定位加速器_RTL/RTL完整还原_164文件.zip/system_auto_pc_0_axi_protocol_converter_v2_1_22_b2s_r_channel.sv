// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_r_channel
   (esc_cnt_read_reg_1_2152f9a ,
    r_full,
    m_axi_rready,
    out,
    r_push_r_reg_0,
    r_push,
    aclk,
    r_rlast,
    si_rs_rready,
    m_axi_rvalid,
    in,
    D,
    areset_d1);
  output esc_cnt_read_reg_1_2152f9a ;
  output r_full;
  output m_axi_rready;
  output [33:0]out;
  output [12:0]r_push_r_reg_0;
  input r_push;
  input aclk;
  input r_rlast;
  input si_rs_rready;
  input m_axi_rvalid;
  input [33:0]in;
  input [11:0]D;
  input areset_d1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [11:0]D;
  wire a_full0;
  wire aclk;
  wire areset_d1;
  wire esc_cnt_read_reg_1_2152f9a ;
  wire [33:0]in;
  wire m_axi_rready;
  wire m_axi_rvalid;
  wire [33:0]out;
  wire r_full;
  wire r_push;
  wire r_push_r;
  wire [12:0]r_push_r_reg_0;
  wire r_rlast;
  wire rd_a_full;
  wire rd_data_fifo_0_n_0;
  wire si_rs_rready;
  wire [12:0]trans_in;
  wire transaction_fifo_0_n_0;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed FDRE: esc_r_arid_r_reg_0_f5ca598
  reg recovered_3_q = 1'b0;
  assign trans_in[1] = recovered_3_q;
  wire recovered_3_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_3_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_3_q == 1'b0))) recovered_3_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_3_q == (D[0])))) recovered_3_q <= (D[0]);
  end

  // Reconstructed FDRE: esc_r_arid_r_reg_10_a77b6b3
  reg recovered_4_q = 1'b0;
  assign trans_in[11] = recovered_4_q;
  wire recovered_4_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_4_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (D[10])))) recovered_4_q <= (D[10]);
  end

  // Reconstructed FDRE: esc_r_arid_r_reg_11_37e629f
  reg recovered_5_q = 1'b0;
  assign trans_in[12] = recovered_5_q;
  wire recovered_5_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (D[11])))) recovered_5_q <= (D[11]);
  end

  // Reconstructed FDRE: esc_r_arid_r_reg_1_4b4a3d6
  reg recovered_6_q = 1'b0;
  assign trans_in[2] = recovered_6_q;
  wire recovered_6_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (D[1])))) recovered_6_q <= (D[1]);
  end

  // Reconstructed FDRE: esc_r_arid_r_reg_2_f3d57f1
  reg recovered_7_q = 1'b0;
  assign trans_in[3] = recovered_7_q;
  wire recovered_7_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (D[2])))) recovered_7_q <= (D[2]);
  end

  // Reconstructed FDRE: esc_r_arid_r_reg_3_717e985
  reg recovered_8_q = 1'b0;
  assign trans_in[4] = recovered_8_q;
  wire recovered_8_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_8_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_8_q == (D[3])))) recovered_8_q <= (D[3]);
  end

  // Reconstructed FDRE: esc_r_arid_r_reg_4_dc6b020
  reg recovered_9_q = 1'b0;
  assign trans_in[5] = recovered_9_q;
  wire recovered_9_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (D[4])))) recovered_9_q <= (D[4]);
  end

  // Reconstructed FDRE: esc_r_arid_r_reg_5_4dfd1a8
  reg recovered_10_q = 1'b0;
  assign trans_in[6] = recovered_10_q;
  wire recovered_10_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_10_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_10_q == (D[5])))) recovered_10_q <= (D[5]);
  end

  // Reconstructed FDRE: esc_r_arid_r_reg_6_86de0ee
  reg recovered_11_q = 1'b0;
  assign trans_in[7] = recovered_11_q;
  wire recovered_11_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_11_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_11_q == (D[6])))) recovered_11_q <= (D[6]);
  end

  // Reconstructed FDRE: esc_r_arid_r_reg_7_07a88e1
  reg recovered_12_q = 1'b0;
  assign trans_in[8] = recovered_12_q;
  wire recovered_12_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_12_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_12_q == (D[7])))) recovered_12_q <= (D[7]);
  end

  // Reconstructed FDRE: esc_r_arid_r_reg_8_ebaddb1
  reg recovered_13_q = 1'b0;
  assign trans_in[9] = recovered_13_q;
  wire recovered_13_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_13_q == (D[8])))) recovered_13_q <= (D[8]);
  end

  // Reconstructed FDRE: esc_r_arid_r_reg_9_c942661
  reg recovered_14_q = 1'b0;
  assign trans_in[10] = recovered_14_q;
  wire recovered_14_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_14_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_14_q == (D[9])))) recovered_14_q <= (D[9]);
  end

  // Reconstructed FDRE: r_push_r_reg
  reg recovered_15_q = 1'b0;
  assign r_push_r = recovered_15_q;
  wire recovered_15_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_15_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_15_q == (r_push)))) recovered_15_q <= (r_push);
  end

  // Reconstructed FDRE: r_rlast_r_reg
  reg recovered_16_q = 1'b0;
  assign trans_in[0] = recovered_16_q;
  wire recovered_16_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_16_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_16_q == (r_rlast)))) recovered_16_q <= (r_rlast);
  end

  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_simple_fifo__parameterized1 rd_data_fifo_0
       (.E(transaction_fifo_0_n_0),
        .a_full0(a_full0),
        .aclk(aclk),
        .areset_d1(areset_d1),
        .esc_cnt_read_reg_1__0_8b39e39 (rd_data_fifo_0_n_0),
        .esc_cnt_read_reg_4__0_906f7bd (esc_cnt_read_reg_1_2152f9a ),
        .in(in[31:0]),
        .m_axi_rready(m_axi_rready),
        .m_axi_rvalid(m_axi_rvalid),
        .out(out[31:0]),
        .rd_a_full(rd_a_full),
        .si_rs_rready(si_rs_rready));
  system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_simple_fifo__parameterized2 transaction_fifo_0
       (.E(transaction_fifo_0_n_0),
        .a_full0(a_full0),
        .aclk(aclk),
        .areset_d1(areset_d1),
        .esc_cnt_read_reg_0__0_6de67a2 (rd_data_fifo_0_n_0),
        .esc_cnt_read_reg_1__0_8b39e39 (esc_cnt_read_reg_1_2152f9a ),
        .in(trans_in),
        .r_full(r_full),
        .r_push_r(r_push_r),
        .r_push_r_reg(r_push_r_reg_0),
        .rd_a_full(rd_a_full),
        .si_rs_rready(si_rs_rready));
endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_rd_cmd_fsm
   (s_ready_i0,
    Q,
    esc_FSM_sequential_state_reg_1__0_5c93d31 ,
    areset_d1_reg,
    areset_d1_reg_0,
    E,
    m_axi_arready_0,
    sel_first_i,
    D,
    esc_FSM_sequential_state_reg_1__1_12501c6 ,
    m_axi_arvalid,
    esc_FSM_sequential_state_reg_1__2_92698b2 ,
    esc_FSM_sequential_state_reg_1__3_6c5e1dd ,
    esc_FSM_sequential_state_reg_1__4_9740bc3 ,
    si_rs_arvalid,
    s_axi_arvalid,
    s_ready_i_reg,
    areset_d1,
    m_axi_arready,
    esc_axaddr_incr_reg_0_e6951a6 ,
    sel_first_reg,
    sel_first_reg_0,
    O,
    esc_axaddr_wrap_reg_11_66b57d3 ,
    esc_axaddr_wrap_reg_11__0_0f67430 ,
    esc_axaddr_wrap_reg_7_0468310 ,
    esc_axaddr_wrap_reg_11__1_cfa1a32 ,
    esc_axaddr_wrap_reg_11__2_82ad777 ,
    esc_FSM_sequential_state_reg_0__0_171b21e ,
    r_full,
    axaddr_offset,
    esc_wrap_cnt_r_reg_0_9ce1d67 ,
    esc_wrap_cnt_r_reg_0__0_ed4efd2 ,
    aclk);
  output s_ready_i0;
  output [1:0]Q;
  output esc_FSM_sequential_state_reg_1__0_5c93d31 ;
  output areset_d1_reg;
  output areset_d1_reg_0;
  output [0:0]E;
  output [0:0]m_axi_arready_0;
  output sel_first_i;
  output [11:0]D;
  output esc_FSM_sequential_state_reg_1__1_12501c6 ;
  output m_axi_arvalid;
  output [0:0]esc_FSM_sequential_state_reg_1__2_92698b2 ;
  output [0:0]esc_FSM_sequential_state_reg_1__3_6c5e1dd ;
  output [0:0]esc_FSM_sequential_state_reg_1__4_9740bc3 ;
  input si_rs_arvalid;
  input s_axi_arvalid;
  input s_ready_i_reg;
  input areset_d1;
  input m_axi_arready;
  input esc_axaddr_incr_reg_0_e6951a6 ;
  input sel_first_reg;
  input sel_first_reg_0;
  input [3:0]O;
  input [11:0]esc_axaddr_wrap_reg_11_66b57d3 ;
  input [11:0]esc_axaddr_wrap_reg_11__0_0f67430 ;
  input [3:0]esc_axaddr_wrap_reg_7_0468310 ;
  input [3:0]esc_axaddr_wrap_reg_11__1_cfa1a32 ;
  input esc_axaddr_wrap_reg_11__2_82ad777 ;
  input esc_FSM_sequential_state_reg_0__0_171b21e ;
  input r_full;
  input [0:0]axaddr_offset;
  input [0:0]esc_wrap_cnt_r_reg_0_9ce1d67 ;
  input esc_wrap_cnt_r_reg_0__0_ed4efd2 ;
  input aclk;

  wire esc_const1_c064970 ;
  wire [11:0]D;
  wire [0:0]E;
  wire esc_FSM_sequential_state_reg_0__0_171b21e ;
  wire esc_FSM_sequential_state_reg_1__0_5c93d31 ;
  wire esc_FSM_sequential_state_reg_1__1_12501c6 ;
  wire [0:0]esc_FSM_sequential_state_reg_1__2_92698b2 ;
  wire [0:0]esc_FSM_sequential_state_reg_1__3_6c5e1dd ;
  wire [0:0]esc_FSM_sequential_state_reg_1__4_9740bc3 ;
  wire [3:0]O;
  wire [1:0]Q;
  wire aclk;
  wire areset_d1;
  wire areset_d1_reg;
  wire areset_d1_reg_0;
  wire esc_axaddr_incr_reg_0_e6951a6 ;
  wire [0:0]axaddr_offset;
  wire esc_axaddr_wrap_11__i_2_n_0_de0c2aa ;
  wire esc_axaddr_wrap_11__i_4_n_0_64280cd ;
  wire [11:0]esc_axaddr_wrap_reg_11_66b57d3 ;
  wire [11:0]esc_axaddr_wrap_reg_11__0_0f67430 ;
  wire esc_axaddr_wrap_reg_11__2_82ad777 ;
  wire [3:0]esc_axaddr_wrap_reg_7_0468310 ;
  wire m_axi_arready;
  wire [0:0]m_axi_arready_0;
  wire m_axi_arvalid;
  wire [1:0]next_state__0;
  wire r_full;
  wire s_axi_arvalid;
  wire s_ready_i0;
  wire s_ready_i_reg;
  wire sel_first_i;
  wire sel_first_reg;
  wire sel_first_reg_0;
  wire si_rs_arvalid;
  wire [0:0]esc_wrap_cnt_r_reg_0_9ce1d67 ;
  wire esc_wrap_cnt_r_reg_0__0_ed4efd2 ;

  // Reconstructed LUT5: esc_FSM_sequential_state_0__i_1__0_8d9ad3c
  assign next_state__0[0] = ((Q[0]) ? (((r_full) ? (((m_axi_arready) ? (~(Q[1])) : (1'b1))) : (((esc_FSM_sequential_state_reg_0__0_171b21e) ? (1'b1) : (((m_axi_arready) ? (~(Q[1])) : (1'b1))))))) : (((r_full) ? (~(Q[1])) : (1'b1))));

  // Reconstructed LUT6: esc_FSM_sequential_state_1__i_1_0114fae
  assign next_state__0[1] = ((Q[0]) ? (((m_axi_arready) ? (((esc_FSM_sequential_state_reg_0__0_171b21e) ? (((r_full) ? (Q[1]) : (((Q[1]) ? (1'b1) : (si_rs_arvalid))))) : (((r_full) ? (1'b0) : (((Q[1]) ? (1'b0) : (si_rs_arvalid))))))) : (((r_full) ? (Q[1]) : (((Q[1]) ? (1'b1) : (si_rs_arvalid))))))) : (Q[1]));

  // Reconstructed FDSE: esc_FSM_sequential_state_reg_0_392f9b0
  reg recovered_3_q = 1'b1;
  assign Q[0] = recovered_3_q;
  wire recovered_3_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_3_reset || (((areset_d1) === 1'bx) && (recovered_3_q == 1'b1))) recovered_3_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_3_q == (next_state__0[0])))) recovered_3_q <= (next_state__0[0]);
  end

  // Reconstructed FDRE: esc_FSM_sequential_state_reg_1_aa5780a
  reg recovered_4_q = 1'b0;
  assign Q[1] = recovered_4_q;
  wire recovered_4_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_4_reset || (((areset_d1) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (next_state__0[1])))) recovered_4_q <= (next_state__0[1]);
  end

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT4: esc_axaddr_incr_11__i_1__0_c5a632d
  assign E = ((Q[1]) ? (((Q[0]) ? (((m_axi_arready) ? (1'b1) : (esc_axaddr_incr_reg_0_e6951a6))) : (esc_axaddr_incr_reg_0_e6951a6))) : (esc_axaddr_incr_reg_0_e6951a6));

  // Reconstructed LUT6: esc_axaddr_wrap_0__i_1_8635ab3
  assign D[0] = ((esc_axaddr_wrap_11__i_4_n_0_64280cd) ? (((esc_axaddr_wrap_reg_11__0_0f67430 [0]) ? (1'b1) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((O[0]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [0]) ? (1'b1) : (((O[0]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))))) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((O[0]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [0]) ? (1'b1) : (((O[0]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))));

  // Reconstructed LUT4: esc_axaddr_wrap_11__i_2_ea516ac
  assign esc_axaddr_wrap_11__i_2_n_0_de0c2aa = ((esc_axaddr_wrap_reg_11__2_82ad777) ? (1'b0) : (((Q[1]) ? (((Q[0]) ? (m_axi_arready) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: esc_axaddr_wrap_11__i_4_9aec0c1
  assign esc_axaddr_wrap_11__i_4_n_0_64280cd = ((Q[1]) ? (((Q[0]) ? (((m_axi_arready) ? (esc_axaddr_wrap_reg_11__2_82ad777) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: esc_axaddr_wrap_1__i_1_7760894
  assign D[1] = ((esc_axaddr_wrap_11__i_4_n_0_64280cd) ? (((esc_axaddr_wrap_reg_11__0_0f67430 [1]) ? (1'b1) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((O[1]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [1]) ? (1'b1) : (((O[1]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))))) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((O[1]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [1]) ? (1'b1) : (((O[1]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))));

  // Reconstructed LUT6: esc_axaddr_wrap_2__i_1_ec1905b
  assign D[2] = ((esc_axaddr_wrap_11__i_4_n_0_64280cd) ? (((esc_axaddr_wrap_reg_11__0_0f67430 [2]) ? (1'b1) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((O[2]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [2]) ? (1'b1) : (((O[2]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))))) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((O[2]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [2]) ? (1'b1) : (((O[2]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))));

  // Reconstructed LUT6: esc_axaddr_wrap_3__i_1_61fc009
  assign D[3] = ((esc_axaddr_wrap_11__i_4_n_0_64280cd) ? (((esc_axaddr_wrap_reg_11__0_0f67430 [3]) ? (1'b1) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((O[3]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [3]) ? (1'b1) : (((O[3]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))))) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((O[3]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [3]) ? (1'b1) : (((O[3]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))));

  // Reconstructed LUT6: esc_axaddr_wrap_4__i_1_0cf415f
  assign D[4] = ((esc_axaddr_wrap_11__i_4_n_0_64280cd) ? (((esc_axaddr_wrap_reg_11__0_0f67430 [4]) ? (1'b1) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((esc_axaddr_wrap_reg_7_0468310 [0]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [4]) ? (1'b1) : (((esc_axaddr_wrap_reg_7_0468310 [0]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))))) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((esc_axaddr_wrap_reg_7_0468310 [0]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [4]) ? (1'b1) : (((esc_axaddr_wrap_reg_7_0468310 [0]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))));

  // Reconstructed LUT6: esc_axaddr_wrap_5__i_1_274182f
  assign D[5] = ((esc_axaddr_wrap_11__i_4_n_0_64280cd) ? (((esc_axaddr_wrap_reg_11__0_0f67430 [5]) ? (1'b1) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((esc_axaddr_wrap_reg_7_0468310 [1]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [5]) ? (1'b1) : (((esc_axaddr_wrap_reg_7_0468310 [1]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))))) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((esc_axaddr_wrap_reg_7_0468310 [1]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [5]) ? (1'b1) : (((esc_axaddr_wrap_reg_7_0468310 [1]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))));

  // Reconstructed LUT6: esc_axaddr_wrap_6__i_1_39f3703
  assign D[6] = ((esc_axaddr_wrap_11__i_4_n_0_64280cd) ? (((esc_axaddr_wrap_reg_11__0_0f67430 [6]) ? (1'b1) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((esc_axaddr_wrap_reg_7_0468310 [2]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [6]) ? (1'b1) : (((esc_axaddr_wrap_reg_7_0468310 [2]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))))) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((esc_axaddr_wrap_reg_7_0468310 [2]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [6]) ? (1'b1) : (((esc_axaddr_wrap_reg_7_0468310 [2]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))));

  // Reconstructed LUT6: esc_axaddr_wrap_7__i_1_89e6c4c
  assign D[7] = ((esc_axaddr_wrap_11__i_4_n_0_64280cd) ? (((esc_axaddr_wrap_reg_11__0_0f67430 [7]) ? (1'b1) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((esc_axaddr_wrap_reg_7_0468310 [3]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [7]) ? (1'b1) : (((esc_axaddr_wrap_reg_7_0468310 [3]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))))) : (((esc_FSM_sequential_state_reg_1__1_12501c6) ? (((esc_axaddr_wrap_reg_7_0468310 [3]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))) : (((esc_axaddr_wrap_reg_11_66b57d3 [7]) ? (1'b1) : (((esc_axaddr_wrap_reg_7_0468310 [3]) ? (esc_axaddr_wrap_11__i_2_n_0_de0c2aa) : (1'b0))))))));

  // Reconstructed LUT4: esc_axlen_cnt_8__i_1__0_131da42
  assign m_axi_arready_0 = ((Q[1]) ? (((Q[0]) ? (m_axi_arready) : (1'b0))) : (((Q[0]) ? (si_rs_arvalid) : (1'b0))));

  // Reconstructed LUT2: m_axi_arvalid_INST_0
  assign m_axi_arvalid = ((Q[1]) ? (Q[0]) : (1'b0));

  // Reconstructed LUT3: esc_m_payload_i_31__i_1__1_980aa11
  assign esc_FSM_sequential_state_reg_1__4_9740bc3 = ((si_rs_arvalid) ? (((Q[0]) ? (1'b0) : (~(Q[1])))) : (1'b1));

  // Reconstructed LUT5: m_valid_i_i_1__2
  assign esc_FSM_sequential_state_reg_1__0_5c93d31 = ((s_ready_i_reg) ? (((s_axi_arvalid) ? (1'b1) : (((si_rs_arvalid) ? (((Q[0]) ? (1'b1) : (Q[1]))) : (1'b0))))) : (1'b1));

  // Reconstructed LUT3: r_push_r_i_1
  assign esc_FSM_sequential_state_reg_1__1_12501c6 = ((m_axi_arready) ? (((Q[0]) ? (Q[1]) : (1'b0))) : (1'b0));

  // Reconstructed LUT5: s_ready_i_i_1__2
  assign s_ready_i0 = ((s_ready_i_reg) ? (((s_axi_arvalid) ? (((si_rs_arvalid) ? (((Q[0]) ? (1'b0) : (~(Q[1])))) : (1'b1))) : (1'b1))) : (((si_rs_arvalid) ? (((Q[0]) ? (1'b0) : (~(Q[1])))) : (1'b1))));

  // Reconstructed LUT6: sel_first_i_1__2
  assign areset_d1_reg = ((esc_axaddr_incr_reg_0_e6951a6) ? (((m_axi_arready) ? (((Q[0]) ? (((Q[1]) ? (areset_d1) : (1'b1))) : (1'b1))) : (1'b1))) : (((Q[0]) ? (((Q[1]) ? (areset_d1) : (((si_rs_arvalid) ? (1'b1) : (areset_d1))))) : (areset_d1))));

  // Reconstructed LUT6: sel_first_i_1__3
  assign areset_d1_reg_0 = ((sel_first_reg) ? (((m_axi_arready) ? (((Q[0]) ? (((Q[1]) ? (areset_d1) : (1'b1))) : (1'b1))) : (1'b1))) : (((Q[0]) ? (((Q[1]) ? (areset_d1) : (((si_rs_arvalid) ? (1'b1) : (areset_d1))))) : (areset_d1))));

  // Reconstructed LUT6: sel_first_i_1__4
  assign sel_first_i = ((si_rs_arvalid) ? (((Q[0]) ? (((Q[1]) ? (((areset_d1) ? (1'b1) : (((sel_first_reg_0) ? (~(m_axi_arready)) : (1'b0))))) : (1'b1))) : (((areset_d1) ? (1'b1) : (sel_first_reg_0))))) : (((Q[0]) ? (((Q[1]) ? (((areset_d1) ? (1'b1) : (((sel_first_reg_0) ? (~(m_axi_arready)) : (1'b0))))) : (((areset_d1) ? (1'b1) : (sel_first_reg_0))))) : (((areset_d1) ? (1'b1) : (sel_first_reg_0))))));

  // Reconstructed LUT3: esc_wrap_boundary_axaddr_r_11__i_1__0_3e2dd77
  assign esc_FSM_sequential_state_reg_1__3_6c5e1dd = ((si_rs_arvalid) ? (((Q[0]) ? (~(Q[1])) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: esc_wrap_cnt_r_0__i_1__0_3c78541
  assign esc_FSM_sequential_state_reg_1__2_92698b2 = ((esc_wrap_cnt_r_reg_0__0_ed4efd2) ? (((esc_wrap_cnt_r_reg_0_9ce1d67) ? (((axaddr_offset) ? (((si_rs_arvalid) ? (((Q[0]) ? (~(Q[1])) : (1'b0))) : (1'b0))) : (1'b0))) : (((axaddr_offset) ? (1'b1) : (((si_rs_arvalid) ? (((Q[0]) ? (Q[1]) : (1'b1))) : (1'b1))))))) : (((esc_wrap_cnt_r_reg_0_9ce1d67) ? (((si_rs_arvalid) ? (((Q[0]) ? (Q[1]) : (1'b1))) : (1'b1))) : (1'b0))));

endmodule

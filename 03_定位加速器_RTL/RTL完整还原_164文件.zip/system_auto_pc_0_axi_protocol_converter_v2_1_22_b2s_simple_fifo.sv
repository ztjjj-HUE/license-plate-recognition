// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_simple_fifo
   (esc_FSM_sequential_state_reg_0_392f9b0 ,
    esc_cnt_read_reg_0__0_6de67a2 ,
    SR,
    bresp_push,
    esc_cnt_read_reg_1__0_8b39e39 ,
    out,
    esc_FSM_sequential_state_reg_0__0_171b21e ,
    s_axburst_eq0,
    esc_FSM_sequential_state_reg_0__1_44612ba ,
    s_axburst_eq1,
    m_axi_awready,
    areset_d1,
    mhandshake_r,
    Q,
    b_push,
    in,
    aclk,
    shandshake_r);
  output [0:0]esc_FSM_sequential_state_reg_0_392f9b0 ;
  output esc_cnt_read_reg_0__0_6de67a2 ;
  output [0:0]SR;
  output bresp_push;
  output esc_cnt_read_reg_1__0_8b39e39 ;
  output [11:0]out;
  input [1:0]esc_FSM_sequential_state_reg_0__0_171b21e ;
  input s_axburst_eq0;
  input [0:0]esc_FSM_sequential_state_reg_0__1_44612ba ;
  input s_axburst_eq1;
  input m_axi_awready;
  input areset_d1;
  input mhandshake_r;
  input [7:0]Q;
  input b_push;
  input [19:0]in;
  input aclk;
  input shandshake_r;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire esc_FSM_sequential_state_0__i_2_n_0_ba6c195 ;
  wire [0:0]esc_FSM_sequential_state_reg_0_392f9b0 ;
  wire [1:0]esc_FSM_sequential_state_reg_0__0_171b21e ;
  wire [0:0]esc_FSM_sequential_state_reg_0__1_44612ba ;
  wire [7:0]Q;
  wire [0:0]SR;
  wire aclk;
  wire areset_d1;
  wire b_push;
  wire esc_bresp_cnt_7__i_3_n_0_d567cb2 ;
  wire esc_bresp_cnt_7__i_4_n_0_0a63241 ;
  wire esc_bresp_cnt_7__i_6_n_0_1571d4b ;
  wire bresp_push;
  wire [1:0]cnt_read;
  wire esc_cnt_read_0__i_1_n_0_233f34e ;
  wire esc_cnt_read_1__i_1_n_0_f125110 ;
  wire esc_cnt_read_reg_0__0_6de67a2 ;
  wire esc_cnt_read_reg_1__0_8b39e39 ;
  wire [19:0]in;
  wire m_axi_awready;
  wire esc_memory_reg_3__0__srl4_i_2__0_n_0_8e39e02 ;
  wire esc_memory_reg_3__0__srl4_i_3_n_0_4c438fe ;
  wire esc_memory_reg_3__0__srl4_i_4_n_0_9af9351 ;
  wire esc_memory_reg_3__0__srl4_n_0_11e329a ;
  wire esc_memory_reg_3__1__srl4_n_0_1417838 ;
  wire esc_memory_reg_3__2__srl4_n_0_6173acb ;
  wire esc_memory_reg_3__3__srl4_n_0_1f1e2a4 ;
  wire mhandshake_r;
  wire [11:0]out;
  wire s_axburst_eq0;
  wire s_axburst_eq1;
  wire shandshake_r;

  // Reconstructed LUT5: esc_FSM_sequential_state_0__i_1_c847423
  assign esc_FSM_sequential_state_reg_0_392f9b0 = ((esc_FSM_sequential_state_reg_0__0_171b21e [1]) ? (((esc_FSM_sequential_state_0__i_2_n_0_ba6c195) ? (~(esc_FSM_sequential_state_reg_0__0_171b21e [0])) : (1'b1))) : (((cnt_read[0]) ? (1'b1) : (((cnt_read[1]) ? (esc_FSM_sequential_state_reg_0__0_171b21e [0]) : (1'b1))))));

  // Reconstructed LUT6: esc_FSM_sequential_state_0__i_2_a18e4e0
  assign esc_FSM_sequential_state_0__i_2_n_0_ba6c195 = ((m_axi_awready) ? (((s_axburst_eq1) ? (((esc_FSM_sequential_state_reg_0__1_44612ba) ? (1'b1) : (((s_axburst_eq0) ? (1'b1) : (((cnt_read[1]) ? (~(cnt_read[0])) : (1'b0))))))) : (((esc_FSM_sequential_state_reg_0__1_44612ba) ? (((cnt_read[1]) ? (~(cnt_read[0])) : (1'b0))) : (((s_axburst_eq0) ? (1'b1) : (((cnt_read[1]) ? (~(cnt_read[0])) : (1'b0))))))))) : (1'b0));

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_bresp_cnt_7__i_1_bd85f96
  assign SR = ((esc_bresp_cnt_7__i_4_n_0_0a63241) ? (areset_d1) : (((cnt_read[0]) ? (((cnt_read[1]) ? (areset_d1) : (((mhandshake_r) ? (((esc_bresp_cnt_7__i_3_n_0_d567cb2) ? (areset_d1) : (1'b1))) : (areset_d1))))) : (((mhandshake_r) ? (((esc_bresp_cnt_7__i_3_n_0_d567cb2) ? (areset_d1) : (1'b1))) : (areset_d1))))));

  // Reconstructed LUT5: esc_bresp_cnt_7__i_3_0de0350
  assign esc_bresp_cnt_7__i_3_n_0_d567cb2 = ((esc_bresp_cnt_7__i_6_n_0_1571d4b) ? (1'b1) : (((Q[4]) ? (1'b1) : (((esc_memory_reg_3__3__srl4_n_0_1f1e2a4) ? (((Q[3]) ? (esc_memory_reg_3__0__srl4_i_4_n_0_9af9351) : (1'b1))) : (((Q[3]) ? (1'b1) : (esc_memory_reg_3__0__srl4_i_4_n_0_9af9351))))))));

  // Reconstructed LUT2: esc_bresp_cnt_7__i_4_df2801a
  assign esc_bresp_cnt_7__i_4_n_0_0a63241 = ((Q[7]) ? (1'b1) : (Q[6]));

  // Reconstructed LUT3: esc_bresp_cnt_7__i_6_3c3290e
  assign esc_bresp_cnt_7__i_6_n_0_1571d4b = ((Q[5]) ? (1'b1) : (((esc_memory_reg_3__2__srl4_n_0_6173acb) ? (~(Q[2])) : (Q[2]))));

  // Reconstructed LUT2: bvalid_i_i_3
  assign esc_cnt_read_reg_1__0_8b39e39 = ((cnt_read[0]) ? (~(cnt_read[1])) : (1'b1));

  // Reconstructed LUT3: esc_cnt_read_0__i_1_5082dfc
  assign esc_cnt_read_0__i_1_n_0_233f34e = ((cnt_read[0]) ? (((b_push) ? (shandshake_r) : (~(shandshake_r)))) : (((b_push) ? (~(shandshake_r)) : (shandshake_r))));

  // Reconstructed LUT4: esc_cnt_read_1__i_1_ed4c7a8
  assign esc_cnt_read_1__i_1_n_0_f125110 = ((cnt_read[1]) ? (((shandshake_r) ? (((b_push) ? (1'b1) : (cnt_read[0]))) : (((b_push) ? (~(cnt_read[0])) : (1'b1))))) : (((shandshake_r) ? (((b_push) ? (1'b0) : (~(cnt_read[0])))) : (((b_push) ? (cnt_read[0]) : (1'b0))))));

  // Reconstructed FDSE: esc_cnt_read_reg_0_59fb42f
  reg recovered_12_q = 1'b1;
  assign cnt_read[0] = recovered_12_q;
  wire recovered_12_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_12_reset || (((areset_d1) === 1'bx) && (recovered_12_q == 1'b1))) recovered_12_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_12_q == (esc_cnt_read_0__i_1_n_0_233f34e)))) recovered_12_q <= (esc_cnt_read_0__i_1_n_0_233f34e);
  end

  // Reconstructed FDSE: esc_cnt_read_reg_1_2152f9a
  reg recovered_13_q = 1'b1;
  assign cnt_read[1] = recovered_13_q;
  wire recovered_13_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((areset_d1) === 1'bx) && (recovered_13_q == 1'b1))) recovered_13_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_13_q == (esc_cnt_read_1__i_1_n_0_f125110)))) recovered_13_q <= (esc_cnt_read_1__i_1_n_0_f125110);
  end

  // Reconstructed SRL16E: esc_memory_reg_3__0__srl4_1f58c57
  reg [15:0] recovered_14_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_14_shift <= {recovered_14_shift[14:0],in[0]};
  assign esc_memory_reg_3__0__srl4_n_0_11e329a = recovered_14_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed LUT5: esc_memory_reg_3__0__srl4_i_1_07e1fc0
  assign bresp_push = ((esc_memory_reg_3__0__srl4_i_3_n_0_4c438fe) ? (1'b0) : (((Q[5]) ? (1'b0) : (((esc_memory_reg_3__2__srl4_n_0_6173acb) ? (((Q[2]) ? (esc_memory_reg_3__0__srl4_i_2__0_n_0_8e39e02) : (1'b0))) : (((Q[2]) ? (1'b0) : (esc_memory_reg_3__0__srl4_i_2__0_n_0_8e39e02))))))));

  // Reconstructed LUT2: esc_memory_reg_3__0__srl4_i_2_3fd86b0
  assign esc_cnt_read_reg_0__0_6de67a2 = ((cnt_read[1]) ? (cnt_read[0]) : (1'b1));

  // Reconstructed LUT4: esc_memory_reg_3__0__srl4_i_2__0_318f886
  assign esc_memory_reg_3__0__srl4_i_2__0_n_0_8e39e02 = ((Q[6]) ? (1'b0) : (((Q[7]) ? (1'b0) : (((esc_cnt_read_reg_1__0_8b39e39) ? (mhandshake_r) : (1'b0))))));

  // Reconstructed LUT4: esc_memory_reg_3__0__srl4_i_3_c41eb35
  assign esc_memory_reg_3__0__srl4_i_3_n_0_4c438fe = ((esc_memory_reg_3__0__srl4_i_4_n_0_9af9351) ? (1'b1) : (((Q[3]) ? (((esc_memory_reg_3__3__srl4_n_0_1f1e2a4) ? (Q[4]) : (1'b1))) : (((esc_memory_reg_3__3__srl4_n_0_1f1e2a4) ? (1'b1) : (Q[4]))))));

  // Reconstructed LUT4: esc_memory_reg_3__0__srl4_i_4_d35b05c
  assign esc_memory_reg_3__0__srl4_i_4_n_0_9af9351 = ((esc_memory_reg_3__1__srl4_n_0_1417838) ? (((Q[1]) ? (((esc_memory_reg_3__0__srl4_n_0_11e329a) ? (~(Q[0])) : (Q[0]))) : (1'b1))) : (((Q[1]) ? (1'b1) : (((esc_memory_reg_3__0__srl4_n_0_11e329a) ? (~(Q[0])) : (Q[0]))))));

  // Reconstructed SRL16E: esc_memory_reg_3__10__srl4_e8aca94
  reg [15:0] recovered_20_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_20_shift <= {recovered_20_shift[14:0],in[10]};
  assign out[2] = recovered_20_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__11__srl4_4b56563
  reg [15:0] recovered_21_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_21_shift <= {recovered_21_shift[14:0],in[11]};
  assign out[3] = recovered_21_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__12__srl4_a1d5fbd
  reg [15:0] recovered_22_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_22_shift <= {recovered_22_shift[14:0],in[12]};
  assign out[4] = recovered_22_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__13__srl4_1d8afae
  reg [15:0] recovered_23_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_23_shift <= {recovered_23_shift[14:0],in[13]};
  assign out[5] = recovered_23_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__14__srl4_e5ddac0
  reg [15:0] recovered_24_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_24_shift <= {recovered_24_shift[14:0],in[14]};
  assign out[6] = recovered_24_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__15__srl4_6488974
  reg [15:0] recovered_25_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_25_shift <= {recovered_25_shift[14:0],in[15]};
  assign out[7] = recovered_25_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__16__srl4_f4033a3
  reg [15:0] recovered_26_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_26_shift <= {recovered_26_shift[14:0],in[16]};
  assign out[8] = recovered_26_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__17__srl4_7075e29
  reg [15:0] recovered_27_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_27_shift <= {recovered_27_shift[14:0],in[17]};
  assign out[9] = recovered_27_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__18__srl4_f086b29
  reg [15:0] recovered_28_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_28_shift <= {recovered_28_shift[14:0],in[18]};
  assign out[10] = recovered_28_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__19__srl4_dc06d0d
  reg [15:0] recovered_29_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_29_shift <= {recovered_29_shift[14:0],in[19]};
  assign out[11] = recovered_29_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__1__srl4_4f502ff
  reg [15:0] recovered_30_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_30_shift <= {recovered_30_shift[14:0],in[1]};
  assign esc_memory_reg_3__1__srl4_n_0_1417838 = recovered_30_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__2__srl4_b5bec2f
  reg [15:0] recovered_31_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_31_shift <= {recovered_31_shift[14:0],in[2]};
  assign esc_memory_reg_3__2__srl4_n_0_6173acb = recovered_31_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__3__srl4_7a4f681
  reg [15:0] recovered_32_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_32_shift <= {recovered_32_shift[14:0],in[3]};
  assign esc_memory_reg_3__3__srl4_n_0_1f1e2a4 = recovered_32_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__8__srl4_fecbd40
  reg [15:0] recovered_33_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_33_shift <= {recovered_33_shift[14:0],in[8]};
  assign out[0] = recovered_33_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__9__srl4_1b74265
  reg [15:0] recovered_34_shift = 16'h0000;
  always @(posedge aclk)
    if ((b_push) == 1'b1 || (b_push) === 1'bz) recovered_34_shift <= {recovered_34_shift[14:0],in[9]};
  assign out[1] = recovered_34_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

endmodule

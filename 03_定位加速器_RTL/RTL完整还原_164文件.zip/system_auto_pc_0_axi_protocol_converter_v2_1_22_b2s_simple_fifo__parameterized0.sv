// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_simple_fifo__parameterized0
   (areset_d1_reg,
    m_axi_bready,
    mhandshake,
    esc_s_bresp_acc_reg_1_b8a96a2 ,
    areset_d1,
    bvalid_i_reg,
    shandshake_r,
    si_rs_bready,
    si_rs_bvalid,
    mhandshake_r,
    m_axi_bvalid,
    bresp_push,
    in,
    aclk);
  output areset_d1_reg;
  output m_axi_bready;
  output mhandshake;
  output [1:0]esc_s_bresp_acc_reg_1_b8a96a2 ;
  input areset_d1;
  input bvalid_i_reg;
  input shandshake_r;
  input si_rs_bready;
  input si_rs_bvalid;
  input mhandshake_r;
  input m_axi_bvalid;
  input bresp_push;
  input [1:0]in;
  input aclk;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire aclk;
  wire areset_d1;
  wire areset_d1_reg;
  wire bresp_push;
  wire bvalid_i_i_2_n_0;
  wire bvalid_i_reg;
  wire [1:0]cnt_read;
  wire esc_cnt_read_0__i_1_n_0_233f34e ;
  wire esc_cnt_read_1__i_1_n_0_f125110 ;
  wire [1:0]in;
  wire m_axi_bready;
  wire m_axi_bvalid;
  wire mhandshake;
  wire mhandshake_r;
  wire [1:0]esc_s_bresp_acc_reg_1_b8a96a2 ;
  wire shandshake_r;
  wire si_rs_bready;
  wire si_rs_bvalid;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: bvalid_i_i_1
  assign areset_d1_reg = ((si_rs_bvalid) ? (((si_rs_bready) ? (1'b0) : (~(areset_d1)))) : (((shandshake_r) ? (1'b0) : (((bvalid_i_reg) ? (((bvalid_i_i_2_n_0) ? (~(areset_d1)) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT2: bvalid_i_i_2
  assign bvalid_i_i_2_n_0 = ((cnt_read[1]) ? (~(cnt_read[0])) : (1'b1));

  // Reconstructed LUT3: esc_cnt_read_0__i_1_5082dfc
  assign esc_cnt_read_0__i_1_n_0_233f34e = ((cnt_read[0]) ? (((bresp_push) ? (shandshake_r) : (~(shandshake_r)))) : (((bresp_push) ? (~(shandshake_r)) : (shandshake_r))));

  // Reconstructed LUT4: esc_cnt_read_1__i_1_ed4c7a8
  assign esc_cnt_read_1__i_1_n_0_f125110 = ((cnt_read[1]) ? (((shandshake_r) ? (((bresp_push) ? (1'b1) : (cnt_read[0]))) : (((bresp_push) ? (~(cnt_read[0])) : (1'b1))))) : (((shandshake_r) ? (((bresp_push) ? (1'b0) : (~(cnt_read[0])))) : (((bresp_push) ? (cnt_read[0]) : (1'b0))))));

  // Reconstructed FDSE: esc_cnt_read_reg_0_59fb42f
  reg recovered_7_q = 1'b1;
  assign cnt_read[0] = recovered_7_q;
  wire recovered_7_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((areset_d1) === 1'bx) && (recovered_7_q == 1'b1))) recovered_7_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (esc_cnt_read_0__i_1_n_0_233f34e)))) recovered_7_q <= (esc_cnt_read_0__i_1_n_0_233f34e);
  end

  // Reconstructed FDSE: esc_cnt_read_reg_1_2152f9a
  reg recovered_8_q = 1'b1;
  assign cnt_read[1] = recovered_8_q;
  wire recovered_8_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_8_reset || (((areset_d1) === 1'bx) && (recovered_8_q == 1'b1))) recovered_8_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_8_q == (esc_cnt_read_1__i_1_n_0_f125110)))) recovered_8_q <= (esc_cnt_read_1__i_1_n_0_f125110);
  end

  // Reconstructed LUT3: m_axi_bready_INST_0
  assign m_axi_bready = ((mhandshake_r) ? (1'b0) : (((cnt_read[0]) ? (cnt_read[1]) : (1'b0))));

  // Reconstructed SRL16E: esc_memory_reg_3__0__srl4_1f58c57
  reg [15:0] recovered_10_shift = 16'h0000;
  always @(posedge aclk)
    if ((bresp_push) == 1'b1 || (bresp_push) === 1'bz) recovered_10_shift <= {recovered_10_shift[14:0],in[0]};
  assign esc_s_bresp_acc_reg_1_b8a96a2 [0] = recovered_10_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed SRL16E: esc_memory_reg_3__1__srl4_4f502ff
  reg [15:0] recovered_11_shift = 16'h0000;
  always @(posedge aclk)
    if ((bresp_push) == 1'b1 || (bresp_push) === 1'bz) recovered_11_shift <= {recovered_11_shift[14:0],in[1]};
  assign esc_s_bresp_acc_reg_1_b8a96a2 [1] = recovered_11_shift[{esc_const0_a0cf646,esc_const0_a0cf646,cnt_read[1],cnt_read[0]}];

  // Reconstructed LUT4: mhandshake_r_i_1
  assign mhandshake = ((cnt_read[0]) ? (((cnt_read[1]) ? (((m_axi_bvalid) ? (~(mhandshake_r)) : (1'b0))) : (1'b0))) : (1'b0));

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_simple_fifo__parameterized1
   (esc_cnt_read_reg_1__0_8b39e39 ,
    m_axi_rready,
    rd_a_full,
    a_full0,
    out,
    esc_cnt_read_reg_4__0_906f7bd ,
    si_rs_rready,
    m_axi_rvalid,
    in,
    aclk,
    areset_d1,
    E);
  output esc_cnt_read_reg_1__0_8b39e39 ;
  output m_axi_rready;
  output rd_a_full;
  output a_full0;
  output [33:0]out;
  input esc_cnt_read_reg_4__0_906f7bd ;
  input si_rs_rready;
  input m_axi_rvalid;
  input [33:0]in;
  input aclk;
  input areset_d1;
  input [0:0]E;

  wire [0:0]E;
  wire a_full0;
  wire aclk;
  wire areset_d1;
  wire esc_cnt_read_0__i_1_n_0_233f34e ;
  wire esc_cnt_read_1__i_1__0_n_0_f263ba5 ;
  wire esc_cnt_read_2__i_1__0_n_0_210bf62 ;
  wire esc_cnt_read_3__i_1__0_n_0_cbfb031 ;
  wire esc_cnt_read_4__i_2__0_n_0_8ce17de ;
  wire esc_cnt_read_4__i_4_n_0_5473b07 ;
  wire [4:0]cnt_read_reg;
  wire esc_cnt_read_reg_1__0_8b39e39 ;
  wire esc_cnt_read_reg_4__0_906f7bd ;
  wire [33:0]in;
  wire m_axi_rready;
  wire m_axi_rvalid;
  wire [33:0]out;
  wire rd_a_full;
  wire si_rs_rready;
  wire wr_en0;

  // Reconstructed LUT5: esc_FSM_sequential_state_1__i_4_fc67455
  assign rd_a_full = ((cnt_read_reg[1]) ? (((cnt_read_reg[3]) ? (((cnt_read_reg[4]) ? (((cnt_read_reg[2]) ? (~(cnt_read_reg[0])) : (1'b1))) : (1'b0))) : (1'b0))) : (((cnt_read_reg[3]) ? (((cnt_read_reg[4]) ? (cnt_read_reg[2]) : (1'b0))) : (1'b0))));

  // Reconstructed LUT1: esc_cnt_read_0__i_1_5082dfc
  assign esc_cnt_read_0__i_1_n_0_233f34e = ~(cnt_read_reg[0]);

  // Reconstructed LUT3: esc_cnt_read_1__i_1__0_2d37a01
  assign esc_cnt_read_1__i_1__0_n_0_f263ba5 = ((cnt_read_reg[1]) ? (((cnt_read_reg[0]) ? (esc_cnt_read_4__i_4_n_0_5473b07) : (~(esc_cnt_read_4__i_4_n_0_5473b07)))) : (((cnt_read_reg[0]) ? (~(esc_cnt_read_4__i_4_n_0_5473b07)) : (esc_cnt_read_4__i_4_n_0_5473b07))));

  // Reconstructed LUT4: esc_cnt_read_2__i_1__0_0cfb3b6
  assign esc_cnt_read_2__i_1__0_n_0_210bf62 = ((cnt_read_reg[0]) ? (((esc_cnt_read_4__i_4_n_0_5473b07) ? (cnt_read_reg[2]) : (((cnt_read_reg[1]) ? (~(cnt_read_reg[2])) : (cnt_read_reg[2]))))) : (((esc_cnt_read_4__i_4_n_0_5473b07) ? (((cnt_read_reg[1]) ? (cnt_read_reg[2]) : (~(cnt_read_reg[2])))) : (cnt_read_reg[2]))));

  // Reconstructed LUT5: esc_cnt_read_3__i_1__0_f6eb7f5
  assign esc_cnt_read_3__i_1__0_n_0_cbfb031 = ((cnt_read_reg[2]) ? (((cnt_read_reg[1]) ? (((cnt_read_reg[0]) ? (((esc_cnt_read_4__i_4_n_0_5473b07) ? (cnt_read_reg[3]) : (~(cnt_read_reg[3])))) : (cnt_read_reg[3]))) : (cnt_read_reg[3]))) : (((cnt_read_reg[1]) ? (cnt_read_reg[3]) : (((cnt_read_reg[0]) ? (cnt_read_reg[3]) : (((esc_cnt_read_4__i_4_n_0_5473b07) ? (~(cnt_read_reg[3])) : (cnt_read_reg[3]))))))));

  // Reconstructed LUT6: esc_cnt_read_4__i_2__0_90a5225
  assign esc_cnt_read_4__i_2__0_n_0_8ce17de = ((cnt_read_reg[3]) ? (((cnt_read_reg[2]) ? (((cnt_read_reg[1]) ? (((cnt_read_reg[0]) ? (((esc_cnt_read_4__i_4_n_0_5473b07) ? (cnt_read_reg[4]) : (~(cnt_read_reg[4])))) : (cnt_read_reg[4]))) : (cnt_read_reg[4]))) : (cnt_read_reg[4]))) : (((cnt_read_reg[2]) ? (cnt_read_reg[4]) : (((cnt_read_reg[1]) ? (cnt_read_reg[4]) : (((cnt_read_reg[0]) ? (cnt_read_reg[4]) : (((esc_cnt_read_4__i_4_n_0_5473b07) ? (~(cnt_read_reg[4])) : (cnt_read_reg[4]))))))))));

  // Reconstructed LUT6: esc_cnt_read_4__i_3__0_aa2a401
  assign esc_cnt_read_reg_1__0_8b39e39 = ((m_axi_rvalid) ? (((cnt_read_reg[0]) ? (((cnt_read_reg[2]) ? (((cnt_read_reg[4]) ? (((cnt_read_reg[3]) ? (~(cnt_read_reg[1])) : (1'b0))) : (1'b0))) : (((cnt_read_reg[4]) ? (((cnt_read_reg[3]) ? (cnt_read_reg[1]) : (1'b0))) : (1'b0))))) : (((cnt_read_reg[2]) ? (((cnt_read_reg[4]) ? (cnt_read_reg[3]) : (1'b0))) : (((cnt_read_reg[4]) ? (((cnt_read_reg[3]) ? (cnt_read_reg[1]) : (1'b0))) : (1'b0))))))) : (1'b1));

  // Reconstructed LUT3: esc_cnt_read_4__i_4_f7974b5
  assign esc_cnt_read_4__i_4_n_0_5473b07 = ((si_rs_rready) ? (((esc_cnt_read_reg_4__0_906f7bd) ? (esc_cnt_read_reg_1__0_8b39e39) : (1'b1))) : (esc_cnt_read_reg_1__0_8b39e39));

  // Reconstructed FDSE: esc_cnt_read_reg_0_59fb42f
  reg recovered_9_q = 1'b1;
  assign cnt_read_reg[0] = recovered_9_q;
  wire recovered_9_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((areset_d1) === 1'bx) && (recovered_9_q == 1'b1))) recovered_9_q <= 1'b1;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_9_q == (esc_cnt_read_0__i_1_n_0_233f34e)))) recovered_9_q <= (esc_cnt_read_0__i_1_n_0_233f34e);
  end

  // Reconstructed FDSE: esc_cnt_read_reg_1_2152f9a
  reg recovered_10_q = 1'b1;
  assign cnt_read_reg[1] = recovered_10_q;
  wire recovered_10_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_10_reset || (((areset_d1) === 1'bx) && (recovered_10_q == 1'b1))) recovered_10_q <= 1'b1;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_10_q == (esc_cnt_read_1__i_1__0_n_0_f263ba5)))) recovered_10_q <= (esc_cnt_read_1__i_1__0_n_0_f263ba5);
  end

  // Reconstructed FDSE: esc_cnt_read_reg_2_654cc15
  reg recovered_11_q = 1'b1;
  assign cnt_read_reg[2] = recovered_11_q;
  wire recovered_11_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_11_reset || (((areset_d1) === 1'bx) && (recovered_11_q == 1'b1))) recovered_11_q <= 1'b1;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_11_q == (esc_cnt_read_2__i_1__0_n_0_210bf62)))) recovered_11_q <= (esc_cnt_read_2__i_1__0_n_0_210bf62);
  end

  // Reconstructed FDSE: esc_cnt_read_reg_3_4691d7c
  reg recovered_12_q = 1'b1;
  assign cnt_read_reg[3] = recovered_12_q;
  wire recovered_12_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_12_reset || (((areset_d1) === 1'bx) && (recovered_12_q == 1'b1))) recovered_12_q <= 1'b1;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_12_q == (esc_cnt_read_3__i_1__0_n_0_cbfb031)))) recovered_12_q <= (esc_cnt_read_3__i_1__0_n_0_cbfb031);
  end

  // Reconstructed FDSE: esc_cnt_read_reg_4_644a9ad
  reg recovered_13_q = 1'b1;
  assign cnt_read_reg[4] = recovered_13_q;
  wire recovered_13_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((areset_d1) === 1'bx) && (recovered_13_q == 1'b1))) recovered_13_q <= 1'b1;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_13_q == (esc_cnt_read_4__i_2__0_n_0_8ce17de)))) recovered_13_q <= (esc_cnt_read_4__i_2__0_n_0_8ce17de);
  end

  // Reconstructed LUT5: m_axi_rready_INST_0
  assign m_axi_rready = ((cnt_read_reg[0]) ? (((cnt_read_reg[2]) ? (((cnt_read_reg[4]) ? (((cnt_read_reg[3]) ? (cnt_read_reg[1]) : (1'b1))) : (1'b1))) : (((cnt_read_reg[4]) ? (((cnt_read_reg[3]) ? (~(cnt_read_reg[1])) : (1'b1))) : (1'b1))))) : (((cnt_read_reg[2]) ? (((cnt_read_reg[4]) ? (~(cnt_read_reg[3])) : (1'b1))) : (((cnt_read_reg[4]) ? (((cnt_read_reg[3]) ? (~(cnt_read_reg[1])) : (1'b1))) : (1'b1))))));

  // Reconstructed LUT5: m_valid_i_i_3
  assign a_full0 = ((cnt_read_reg[0]) ? (((cnt_read_reg[2]) ? (((cnt_read_reg[4]) ? (((cnt_read_reg[3]) ? (~(cnt_read_reg[1])) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed SRLC32E: esc_memory_reg_31__0__srl32_9268924
  reg [31:0] recovered_16_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_16_shift <= {recovered_16_shift[30:0],in[0]};
  assign out[0] = recovered_16_shift[cnt_read_reg];

  // Reconstructed LUT6: esc_memory_reg_31__0__srl32_i_1_dc52bf7
  assign wr_en0 = ((cnt_read_reg[1]) ? (((cnt_read_reg[3]) ? (((cnt_read_reg[4]) ? (((cnt_read_reg[2]) ? (((cnt_read_reg[0]) ? (m_axi_rvalid) : (1'b0))) : (1'b0))) : (m_axi_rvalid))) : (m_axi_rvalid))) : (((cnt_read_reg[3]) ? (((cnt_read_reg[4]) ? (((cnt_read_reg[2]) ? (1'b0) : (m_axi_rvalid))) : (m_axi_rvalid))) : (m_axi_rvalid))));

  // Reconstructed SRLC32E: esc_memory_reg_31__10__srl32_137902b
  reg [31:0] recovered_18_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_18_shift <= {recovered_18_shift[30:0],in[10]};
  assign out[10] = recovered_18_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__11__srl32_f8c4cab
  reg [31:0] recovered_19_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_19_shift <= {recovered_19_shift[30:0],in[11]};
  assign out[11] = recovered_19_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__12__srl32_5ccc564
  reg [31:0] recovered_20_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_20_shift <= {recovered_20_shift[30:0],in[12]};
  assign out[12] = recovered_20_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__13__srl32_a8fa33d
  reg [31:0] recovered_21_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_21_shift <= {recovered_21_shift[30:0],in[13]};
  assign out[13] = recovered_21_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__14__srl32_86cf4c3
  reg [31:0] recovered_22_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_22_shift <= {recovered_22_shift[30:0],in[14]};
  assign out[14] = recovered_22_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__15__srl32_e0feafe
  reg [31:0] recovered_23_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_23_shift <= {recovered_23_shift[30:0],in[15]};
  assign out[15] = recovered_23_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__16__srl32_9aa27d7
  reg [31:0] recovered_24_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_24_shift <= {recovered_24_shift[30:0],in[16]};
  assign out[16] = recovered_24_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__17__srl32_61d178c
  reg [31:0] recovered_25_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_25_shift <= {recovered_25_shift[30:0],in[17]};
  assign out[17] = recovered_25_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__18__srl32_ae8a813
  reg [31:0] recovered_26_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_26_shift <= {recovered_26_shift[30:0],in[18]};
  assign out[18] = recovered_26_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__19__srl32_3a1cd97
  reg [31:0] recovered_27_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_27_shift <= {recovered_27_shift[30:0],in[19]};
  assign out[19] = recovered_27_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__1__srl32_ee2d0c8
  reg [31:0] recovered_28_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_28_shift <= {recovered_28_shift[30:0],in[1]};
  assign out[1] = recovered_28_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__20__srl32_8272a2a
  reg [31:0] recovered_29_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_29_shift <= {recovered_29_shift[30:0],in[20]};
  assign out[20] = recovered_29_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__21__srl32_7a39c15
  reg [31:0] recovered_30_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_30_shift <= {recovered_30_shift[30:0],in[21]};
  assign out[21] = recovered_30_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__22__srl32_336c8b4
  reg [31:0] recovered_31_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_31_shift <= {recovered_31_shift[30:0],in[22]};
  assign out[22] = recovered_31_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__23__srl32_bf6d378
  reg [31:0] recovered_32_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_32_shift <= {recovered_32_shift[30:0],in[23]};
  assign out[23] = recovered_32_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__24__srl32_3c7068e
  reg [31:0] recovered_33_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_33_shift <= {recovered_33_shift[30:0],in[24]};
  assign out[24] = recovered_33_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__25__srl32_068bd2e
  reg [31:0] recovered_34_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_34_shift <= {recovered_34_shift[30:0],in[25]};
  assign out[25] = recovered_34_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__26__srl32_262c261
  reg [31:0] recovered_35_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_35_shift <= {recovered_35_shift[30:0],in[26]};
  assign out[26] = recovered_35_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__27__srl32_fb3d8e5
  reg [31:0] recovered_36_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_36_shift <= {recovered_36_shift[30:0],in[27]};
  assign out[27] = recovered_36_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__28__srl32_b75455b
  reg [31:0] recovered_37_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_37_shift <= {recovered_37_shift[30:0],in[28]};
  assign out[28] = recovered_37_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__29__srl32_6ce497f
  reg [31:0] recovered_38_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_38_shift <= {recovered_38_shift[30:0],in[29]};
  assign out[29] = recovered_38_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__2__srl32_0ba1249
  reg [31:0] recovered_39_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_39_shift <= {recovered_39_shift[30:0],in[2]};
  assign out[2] = recovered_39_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__30__srl32_2c14b3d
  reg [31:0] recovered_40_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_40_shift <= {recovered_40_shift[30:0],in[30]};
  assign out[30] = recovered_40_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__31__srl32_3ef33ab
  reg [31:0] recovered_41_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_41_shift <= {recovered_41_shift[30:0],in[31]};
  assign out[31] = recovered_41_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__3__srl32_e3ac965
  reg [31:0] recovered_42_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_42_shift <= {recovered_42_shift[30:0],in[3]};
  assign out[3] = recovered_42_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__4__srl32_33c2b8a
  reg [31:0] recovered_43_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_43_shift <= {recovered_43_shift[30:0],in[4]};
  assign out[4] = recovered_43_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__5__srl32_30eef22
  reg [31:0] recovered_44_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_44_shift <= {recovered_44_shift[30:0],in[5]};
  assign out[5] = recovered_44_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__6__srl32_3325416
  reg [31:0] recovered_45_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_45_shift <= {recovered_45_shift[30:0],in[6]};
  assign out[6] = recovered_45_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__7__srl32_b02212f
  reg [31:0] recovered_46_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_46_shift <= {recovered_46_shift[30:0],in[7]};
  assign out[7] = recovered_46_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__8__srl32_0ff8600
  reg [31:0] recovered_47_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_47_shift <= {recovered_47_shift[30:0],in[8]};
  assign out[8] = recovered_47_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__9__srl32_31b962a
  reg [31:0] recovered_48_shift = 32'h00000000;
  always @(posedge aclk)
    if ((wr_en0) == 1'b1 || (wr_en0) === 1'bz) recovered_48_shift <= {recovered_48_shift[30:0],in[9]};
  assign out[9] = recovered_48_shift[cnt_read_reg];

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_simple_fifo__parameterized2
   (E,
    esc_cnt_read_reg_1__0_8b39e39 ,
    r_full,
    r_push_r_reg,
    si_rs_rready,
    esc_cnt_read_reg_0__0_6de67a2 ,
    r_push_r,
    a_full0,
    rd_a_full,
    in,
    aclk,
    areset_d1);
  output [0:0]E;
  output esc_cnt_read_reg_1__0_8b39e39 ;
  output r_full;
  output [12:0]r_push_r_reg;
  input si_rs_rready;
  input esc_cnt_read_reg_0__0_6de67a2 ;
  input r_push_r;
  input a_full0;
  input rd_a_full;
  input [12:0]in;
  input aclk;
  input areset_d1;

  wire [0:0]E;
  wire a_full0;
  wire aclk;
  wire areset_d1;
  wire esc_cnt_read_0__i_1__0_n_0_f3fbf93 ;
  wire esc_cnt_read_1__i_1_n_0_f125110 ;
  wire esc_cnt_read_2__i_1_n_0_5463bec ;
  wire esc_cnt_read_3__i_1_n_0_6794038 ;
  wire esc_cnt_read_4__i_1__0_n_0_ec46902 ;
  wire esc_cnt_read_4__i_2_n_0_27a5cd6 ;
  wire esc_cnt_read_4__i_3_n_0_b9e22d1 ;
  wire [4:0]cnt_read_reg;
  wire esc_cnt_read_reg_0__0_6de67a2 ;
  wire esc_cnt_read_reg_1__0_8b39e39 ;
  wire [12:0]in;
  wire r_full;
  wire r_push_r;
  wire [12:0]r_push_r_reg;
  wire rd_a_full;
  wire si_rs_rready;

  // Reconstructed LUT6: esc_FSM_sequential_state_1__i_2__0_be0e145
  assign r_full = ((rd_a_full) ? (1'b1) : (((cnt_read_reg[1]) ? (((cnt_read_reg[2]) ? (((cnt_read_reg[3]) ? (((cnt_read_reg[4]) ? (~(cnt_read_reg[0])) : (1'b0))) : (1'b0))) : (((cnt_read_reg[3]) ? (cnt_read_reg[4]) : (1'b0))))) : (((cnt_read_reg[2]) ? (((cnt_read_reg[3]) ? (cnt_read_reg[4]) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT1: esc_cnt_read_0__i_1__0_3f59dac
  assign esc_cnt_read_0__i_1__0_n_0_f3fbf93 = ~(cnt_read_reg[0]);

  // Reconstructed LUT3: esc_cnt_read_1__i_1_ed4c7a8
  assign esc_cnt_read_1__i_1_n_0_f125110 = ((esc_cnt_read_4__i_3_n_0_b9e22d1) ? (((cnt_read_reg[0]) ? (cnt_read_reg[1]) : (~(cnt_read_reg[1])))) : (((cnt_read_reg[0]) ? (~(cnt_read_reg[1])) : (cnt_read_reg[1]))));

  // Reconstructed LUT4: esc_cnt_read_2__i_1_10aaedb
  assign esc_cnt_read_2__i_1_n_0_5463bec = ((esc_cnt_read_4__i_3_n_0_b9e22d1) ? (((cnt_read_reg[0]) ? (cnt_read_reg[2]) : (((cnt_read_reg[1]) ? (cnt_read_reg[2]) : (~(cnt_read_reg[2])))))) : (((cnt_read_reg[0]) ? (((cnt_read_reg[1]) ? (~(cnt_read_reg[2])) : (cnt_read_reg[2]))) : (cnt_read_reg[2]))));

  // Reconstructed LUT5: esc_cnt_read_3__i_1_30d94b8
  assign esc_cnt_read_3__i_1_n_0_6794038 = ((cnt_read_reg[2]) ? (((cnt_read_reg[1]) ? (((esc_cnt_read_4__i_3_n_0_b9e22d1) ? (cnt_read_reg[3]) : (((cnt_read_reg[0]) ? (~(cnt_read_reg[3])) : (cnt_read_reg[3]))))) : (cnt_read_reg[3]))) : (((cnt_read_reg[1]) ? (cnt_read_reg[3]) : (((esc_cnt_read_4__i_3_n_0_b9e22d1) ? (((cnt_read_reg[0]) ? (cnt_read_reg[3]) : (~(cnt_read_reg[3])))) : (cnt_read_reg[3]))))));

  // Reconstructed LUT3: esc_cnt_read_4__i_1_4226bb6
  assign E = ((esc_cnt_read_reg_0__0_6de67a2) ? (((esc_cnt_read_reg_1__0_8b39e39) ? (1'b0) : (si_rs_rready))) : (((esc_cnt_read_reg_1__0_8b39e39) ? (1'b1) : (~(si_rs_rready)))));

  // Reconstructed LUT3: esc_cnt_read_4__i_1__0_06bf916
  assign esc_cnt_read_4__i_1__0_n_0_ec46902 = ((r_push_r) ? (((esc_cnt_read_reg_1__0_8b39e39) ? (1'b1) : (~(si_rs_rready)))) : (((esc_cnt_read_reg_1__0_8b39e39) ? (1'b0) : (si_rs_rready))));

  // Reconstructed LUT6: esc_cnt_read_4__i_2_235ec1e
  assign esc_cnt_read_4__i_2_n_0_27a5cd6 = ((cnt_read_reg[3]) ? (((cnt_read_reg[2]) ? (((cnt_read_reg[1]) ? (((esc_cnt_read_4__i_3_n_0_b9e22d1) ? (cnt_read_reg[4]) : (((cnt_read_reg[0]) ? (~(cnt_read_reg[4])) : (cnt_read_reg[4]))))) : (cnt_read_reg[4]))) : (cnt_read_reg[4]))) : (((cnt_read_reg[2]) ? (cnt_read_reg[4]) : (((cnt_read_reg[1]) ? (cnt_read_reg[4]) : (((esc_cnt_read_4__i_3_n_0_b9e22d1) ? (((cnt_read_reg[0]) ? (cnt_read_reg[4]) : (~(cnt_read_reg[4])))) : (cnt_read_reg[4]))))))));

  // Reconstructed LUT3: esc_cnt_read_4__i_3_84f8b00
  assign esc_cnt_read_4__i_3_n_0_b9e22d1 = ((r_push_r) ? (((si_rs_rready) ? (~(esc_cnt_read_reg_1__0_8b39e39)) : (1'b0))) : (1'b1));

  // Reconstructed FDSE: esc_cnt_read_reg_0_59fb42f
  reg recovered_10_q = 1'b1;
  assign cnt_read_reg[0] = recovered_10_q;
  wire recovered_10_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_10_reset || (((areset_d1) === 1'bx) && (recovered_10_q == 1'b1))) recovered_10_q <= 1'b1;
    else if ((esc_cnt_read_4__i_1__0_n_0_ec46902) || ((esc_cnt_read_4__i_1__0_n_0_ec46902) === 1'bz) || (((esc_cnt_read_4__i_1__0_n_0_ec46902) === 1'bx) && (recovered_10_q == (esc_cnt_read_0__i_1__0_n_0_f3fbf93)))) recovered_10_q <= (esc_cnt_read_0__i_1__0_n_0_f3fbf93);
  end

  // Reconstructed FDSE: esc_cnt_read_reg_1_2152f9a
  reg recovered_11_q = 1'b1;
  assign cnt_read_reg[1] = recovered_11_q;
  wire recovered_11_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_11_reset || (((areset_d1) === 1'bx) && (recovered_11_q == 1'b1))) recovered_11_q <= 1'b1;
    else if ((esc_cnt_read_4__i_1__0_n_0_ec46902) || ((esc_cnt_read_4__i_1__0_n_0_ec46902) === 1'bz) || (((esc_cnt_read_4__i_1__0_n_0_ec46902) === 1'bx) && (recovered_11_q == (esc_cnt_read_1__i_1_n_0_f125110)))) recovered_11_q <= (esc_cnt_read_1__i_1_n_0_f125110);
  end

  // Reconstructed FDSE: esc_cnt_read_reg_2_654cc15
  reg recovered_12_q = 1'b1;
  assign cnt_read_reg[2] = recovered_12_q;
  wire recovered_12_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_12_reset || (((areset_d1) === 1'bx) && (recovered_12_q == 1'b1))) recovered_12_q <= 1'b1;
    else if ((esc_cnt_read_4__i_1__0_n_0_ec46902) || ((esc_cnt_read_4__i_1__0_n_0_ec46902) === 1'bz) || (((esc_cnt_read_4__i_1__0_n_0_ec46902) === 1'bx) && (recovered_12_q == (esc_cnt_read_2__i_1_n_0_5463bec)))) recovered_12_q <= (esc_cnt_read_2__i_1_n_0_5463bec);
  end

  // Reconstructed FDSE: esc_cnt_read_reg_3_4691d7c
  reg recovered_13_q = 1'b1;
  assign cnt_read_reg[3] = recovered_13_q;
  wire recovered_13_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((areset_d1) === 1'bx) && (recovered_13_q == 1'b1))) recovered_13_q <= 1'b1;
    else if ((esc_cnt_read_4__i_1__0_n_0_ec46902) || ((esc_cnt_read_4__i_1__0_n_0_ec46902) === 1'bz) || (((esc_cnt_read_4__i_1__0_n_0_ec46902) === 1'bx) && (recovered_13_q == (esc_cnt_read_3__i_1_n_0_6794038)))) recovered_13_q <= (esc_cnt_read_3__i_1_n_0_6794038);
  end

  // Reconstructed FDSE: esc_cnt_read_reg_4_644a9ad
  reg recovered_14_q = 1'b1;
  assign cnt_read_reg[4] = recovered_14_q;
  wire recovered_14_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_14_reset || (((areset_d1) === 1'bx) && (recovered_14_q == 1'b1))) recovered_14_q <= 1'b1;
    else if ((esc_cnt_read_4__i_1__0_n_0_ec46902) || ((esc_cnt_read_4__i_1__0_n_0_ec46902) === 1'bz) || (((esc_cnt_read_4__i_1__0_n_0_ec46902) === 1'bx) && (recovered_14_q == (esc_cnt_read_4__i_2_n_0_27a5cd6)))) recovered_14_q <= (esc_cnt_read_4__i_2_n_0_27a5cd6);
  end

  // Reconstructed LUT6: m_valid_i_i_2
  assign esc_cnt_read_reg_1__0_8b39e39 = ((a_full0) ? (((cnt_read_reg[0]) ? (((cnt_read_reg[4]) ? (((cnt_read_reg[3]) ? (((cnt_read_reg[2]) ? (cnt_read_reg[1]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b1));

  // Reconstructed SRLC32E: esc_memory_reg_31__0__srl32_9268924
  reg [31:0] recovered_16_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_16_shift <= {recovered_16_shift[30:0],in[0]};
  assign r_push_r_reg[0] = recovered_16_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__10__srl32_137902b
  reg [31:0] recovered_17_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_17_shift <= {recovered_17_shift[30:0],in[10]};
  assign r_push_r_reg[10] = recovered_17_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__11__srl32_f8c4cab
  reg [31:0] recovered_18_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_18_shift <= {recovered_18_shift[30:0],in[11]};
  assign r_push_r_reg[11] = recovered_18_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__12__srl32_5ccc564
  reg [31:0] recovered_19_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_19_shift <= {recovered_19_shift[30:0],in[12]};
  assign r_push_r_reg[12] = recovered_19_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__1__srl32_ee2d0c8
  reg [31:0] recovered_20_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_20_shift <= {recovered_20_shift[30:0],in[1]};
  assign r_push_r_reg[1] = recovered_20_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__2__srl32_0ba1249
  reg [31:0] recovered_21_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_21_shift <= {recovered_21_shift[30:0],in[2]};
  assign r_push_r_reg[2] = recovered_21_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__3__srl32_e3ac965
  reg [31:0] recovered_22_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_22_shift <= {recovered_22_shift[30:0],in[3]};
  assign r_push_r_reg[3] = recovered_22_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__4__srl32_33c2b8a
  reg [31:0] recovered_23_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_23_shift <= {recovered_23_shift[30:0],in[4]};
  assign r_push_r_reg[4] = recovered_23_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__5__srl32_30eef22
  reg [31:0] recovered_24_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_24_shift <= {recovered_24_shift[30:0],in[5]};
  assign r_push_r_reg[5] = recovered_24_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__6__srl32_3325416
  reg [31:0] recovered_25_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_25_shift <= {recovered_25_shift[30:0],in[6]};
  assign r_push_r_reg[6] = recovered_25_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__7__srl32_b02212f
  reg [31:0] recovered_26_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_26_shift <= {recovered_26_shift[30:0],in[7]};
  assign r_push_r_reg[7] = recovered_26_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__8__srl32_0ff8600
  reg [31:0] recovered_27_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_27_shift <= {recovered_27_shift[30:0],in[8]};
  assign r_push_r_reg[8] = recovered_27_shift[cnt_read_reg];

  // Reconstructed SRLC32E: esc_memory_reg_31__9__srl32_31b962a
  reg [31:0] recovered_28_shift = 32'h00000000;
  always @(posedge aclk)
    if ((r_push_r) == 1'b1 || (r_push_r) === 1'bz) recovered_28_shift <= {recovered_28_shift[30:0],in[9]};
  assign r_push_r_reg[9] = recovered_28_shift[cnt_read_reg];

endmodule

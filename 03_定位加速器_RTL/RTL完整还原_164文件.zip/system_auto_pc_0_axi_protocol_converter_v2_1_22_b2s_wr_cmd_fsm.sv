// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_wr_cmd_fsm
   (esc_FSM_sequential_state_reg_1__0_5c93d31 ,
    Q,
    next,
    esc_FSM_sequential_state_reg_1__1_12501c6 ,
    esc_m_payload_i_reg_39_ea68878 ,
    sel_first_i,
    esc_m_payload_i_reg_39__0_7251a5e ,
    incr_next_pending,
    E,
    m_axi_awready_0,
    m_valid_i_reg,
    b_push,
    D,
    esc_FSM_sequential_state_reg_1__2_92698b2 ,
    m_axi_awvalid,
    si_rs_awvalid,
    areset_d1,
    sel_first_reg,
    sel_first,
    next_pending_r_reg,
    wrap_next_pending,
    next_pending_r_reg_0,
    next_pending_r,
    next_pending_r_reg_1,
    m_axi_awready,
    esc_axaddr_wrap_reg_0_4889146 ,
    esc_axaddr_wrap_reg_0__0_8ebf4f6 ,
    sel_first_reg_0,
    esc_axlen_cnt_reg_0_56abf15 ,
    esc_axlen_cnt_reg_0__0_31fcd59 ,
    esc_wrap_cnt_r_reg_0_9ce1d67 ,
    esc_wrap_cnt_r_reg_0__0_ed4efd2 ,
    esc_wrap_cnt_r_reg_0__1_5374db8 ,
    aclk,
    esc_FSM_sequential_state_reg_0__0_171b21e );
  output esc_FSM_sequential_state_reg_1__0_5c93d31 ;
  output [1:0]Q;
  output next;
  output esc_FSM_sequential_state_reg_1__1_12501c6 ;
  output esc_m_payload_i_reg_39_ea68878 ;
  output sel_first_i;
  output esc_m_payload_i_reg_39__0_7251a5e ;
  output incr_next_pending;
  output [0:0]E;
  output [0:0]m_axi_awready_0;
  output [0:0]m_valid_i_reg;
  output b_push;
  output [0:0]D;
  output [0:0]esc_FSM_sequential_state_reg_1__2_92698b2 ;
  output m_axi_awvalid;
  input si_rs_awvalid;
  input areset_d1;
  input sel_first_reg;
  input sel_first;
  input [5:0]next_pending_r_reg;
  input wrap_next_pending;
  input next_pending_r_reg_0;
  input next_pending_r;
  input next_pending_r_reg_1;
  input m_axi_awready;
  input esc_axaddr_wrap_reg_0_4889146 ;
  input esc_axaddr_wrap_reg_0__0_8ebf4f6 ;
  input sel_first_reg_0;
  input [0:0]esc_axlen_cnt_reg_0_56abf15 ;
  input esc_axlen_cnt_reg_0__0_31fcd59 ;
  input [0:0]esc_wrap_cnt_r_reg_0_9ce1d67 ;
  input [0:0]esc_wrap_cnt_r_reg_0__0_ed4efd2 ;
  input esc_wrap_cnt_r_reg_0__1_5374db8 ;
  input aclk;
  input [0:0]esc_FSM_sequential_state_reg_0__0_171b21e ;

  wire esc_const1_c064970 ;
  wire [0:0]D;
  wire [0:0]E;
  wire [0:0]esc_FSM_sequential_state_reg_0__0_171b21e ;
  wire esc_FSM_sequential_state_reg_1__0_5c93d31 ;
  wire esc_FSM_sequential_state_reg_1__1_12501c6 ;
  wire [0:0]esc_FSM_sequential_state_reg_1__2_92698b2 ;
  wire [1:0]Q;
  wire aclk;
  wire areset_d1;
  wire esc_axaddr_wrap_reg_0_4889146 ;
  wire esc_axaddr_wrap_reg_0__0_8ebf4f6 ;
  wire [0:0]esc_axlen_cnt_reg_0_56abf15 ;
  wire esc_axlen_cnt_reg_0__0_31fcd59 ;
  wire b_push;
  wire incr_next_pending;
  wire m_axi_awready;
  wire [0:0]m_axi_awready_0;
  wire m_axi_awvalid;
  wire esc_m_payload_i_reg_39_ea68878 ;
  wire esc_m_payload_i_reg_39__0_7251a5e ;
  wire [0:0]m_valid_i_reg;
  wire next;
  wire next_pending_r;
  wire next_pending_r_i_2_n_0;
  wire [5:0]next_pending_r_reg;
  wire next_pending_r_reg_0;
  wire next_pending_r_reg_1;
  wire [1:1]next_state__0;
  wire s_axburst_eq0_i_2_n_0;
  wire sel_first;
  wire sel_first_i;
  wire sel_first_reg;
  wire sel_first_reg_0;
  wire si_rs_awvalid;
  wire [0:0]esc_wrap_cnt_r_reg_0_9ce1d67 ;
  wire [0:0]esc_wrap_cnt_r_reg_0__0_ed4efd2 ;
  wire esc_wrap_cnt_r_reg_0__1_5374db8 ;
  wire wrap_next_pending;

  // Reconstructed LUT5: esc_FSM_sequential_state_1__i_1__0_5c8ebb8
  assign next_state__0 = ((Q[1]) ? (((esc_axaddr_wrap_reg_0_4889146) ? (((m_axi_awready) ? (~(Q[0])) : (1'b1))) : (1'b1))) : (((Q[0]) ? (si_rs_awvalid) : (1'b0))));

  // Reconstructed FDSE: esc_FSM_sequential_state_reg_0_392f9b0
  reg recovered_2_q = 1'b1;
  assign Q[0] = recovered_2_q;
  wire recovered_2_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_2_reset || (((areset_d1) === 1'bx) && (recovered_2_q == 1'b1))) recovered_2_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_2_q == (esc_FSM_sequential_state_reg_0__0_171b21e)))) recovered_2_q <= (esc_FSM_sequential_state_reg_0__0_171b21e);
  end

  // Reconstructed FDRE: esc_FSM_sequential_state_reg_1_aa5780a
  reg recovered_3_q = 1'b0;
  assign Q[1] = recovered_3_q;
  wire recovered_3_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_3_reset || (((areset_d1) === 1'bx) && (recovered_3_q == 1'b0))) recovered_3_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_3_q == (next_state__0)))) recovered_3_q <= (next_state__0);
  end

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_axlen_cnt_0__i_1_512bcd9
  assign D = ((esc_axlen_cnt_reg_0__0_31fcd59) ? (((esc_axlen_cnt_reg_0_56abf15) ? (((next_pending_r_reg[1]) ? (((si_rs_awvalid) ? (((Q[0]) ? (~(Q[1])) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b1))) : (((next_pending_r_reg[1]) ? (((si_rs_awvalid) ? (((Q[0]) ? (~(Q[1])) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_axlen_cnt_8__i_1_55c082b
  assign m_axi_awready_0 = ((Q[1]) ? (((Q[0]) ? (((esc_axaddr_wrap_reg_0__0_8ebf4f6) ? (((esc_axaddr_wrap_reg_0_4889146) ? (m_axi_awready) : (1'b0))) : (1'b0))) : (1'b1))) : (((Q[0]) ? (si_rs_awvalid) : (esc_axaddr_wrap_reg_0__0_8ebf4f6))));

  // Reconstructed LUT2: m_axi_awvalid_INST_0
  assign m_axi_awvalid = ((Q[1]) ? (Q[0]) : (1'b0));

  // Reconstructed LUT2: esc_m_payload_i_31__i_1_86bc887
  assign m_valid_i_reg = ((si_rs_awvalid) ? (b_push) : (1'b1));

  // Reconstructed LUT5: esc_memory_reg_3__0__srl4_i_1__0_4d7cf50
  assign b_push = ((Q[0]) ? (((esc_axaddr_wrap_reg_0__0_8ebf4f6) ? (((esc_axaddr_wrap_reg_0_4889146) ? (((m_axi_awready) ? (Q[1]) : (1'b0))) : (1'b0))) : (1'b0))) : (((esc_axaddr_wrap_reg_0__0_8ebf4f6) ? (~(Q[1])) : (1'b0))));

  // Reconstructed LUT3: next_pending_r_i_1__0
  assign incr_next_pending = ((next) ? (((next_pending_r_reg_0) ? (1'b1) : (next_pending_r_i_2_n_0))) : (next_pending_r_i_2_n_0));

  // Reconstructed LUT3: next_pending_r_i_2
  assign next_pending_r_i_2_n_0 = ((next_pending_r_reg_1) ? (1'b1) : (((m_axi_awready_0) ? (1'b0) : (next_pending_r))));

  // Reconstructed LUT5: next_pending_r_i_4
  assign next = ((Q[1]) ? (((m_axi_awready) ? (((esc_axaddr_wrap_reg_0_4889146) ? (((esc_axaddr_wrap_reg_0__0_8ebf4f6) ? (1'b1) : (~(Q[0])))) : (~(Q[0])))) : (~(Q[0])))) : (((esc_axaddr_wrap_reg_0__0_8ebf4f6) ? (~(Q[0])) : (1'b0))));

  // Reconstructed LUT5: s_axburst_eq0_i_1
  assign esc_m_payload_i_reg_39_ea68878 = ((wrap_next_pending) ? (((next_pending_r_reg[0]) ? (((sel_first_i) ? (((s_axburst_eq0_i_2_n_0) ? (1'b1) : (next_pending_r_i_2_n_0))) : (1'b1))) : (((s_axburst_eq0_i_2_n_0) ? (1'b1) : (next_pending_r_i_2_n_0))))) : (((next_pending_r_reg[0]) ? (((sel_first_i) ? (((s_axburst_eq0_i_2_n_0) ? (1'b1) : (next_pending_r_i_2_n_0))) : (1'b0))) : (((s_axburst_eq0_i_2_n_0) ? (1'b1) : (next_pending_r_i_2_n_0))))));

  // Reconstructed LUT2: s_axburst_eq0_i_2
  assign s_axburst_eq0_i_2_n_0 = ((next_pending_r_reg_0) ? (next) : (1'b0));

  // Reconstructed LUT5: s_axburst_eq1_i_1
  assign esc_m_payload_i_reg_39__0_7251a5e = ((s_axburst_eq0_i_2_n_0) ? (((next_pending_r_reg[0]) ? (wrap_next_pending) : (((sel_first_i) ? (wrap_next_pending) : (1'b1))))) : (((next_pending_r_i_2_n_0) ? (((next_pending_r_reg[0]) ? (wrap_next_pending) : (((sel_first_i) ? (wrap_next_pending) : (1'b1))))) : (((next_pending_r_reg[0]) ? (wrap_next_pending) : (((sel_first_i) ? (wrap_next_pending) : (1'b0))))))));

  // Reconstructed LUT6: sel_first_i_1
  assign esc_FSM_sequential_state_reg_1__0_5c93d31 = ((sel_first_reg) ? (((next) ? (((areset_d1) ? (1'b1) : (((si_rs_awvalid) ? (((Q[0]) ? (~(Q[1])) : (1'b0))) : (1'b0))))) : (1'b1))) : (((areset_d1) ? (1'b1) : (((si_rs_awvalid) ? (((Q[0]) ? (~(Q[1])) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT6: sel_first_i_1__0
  assign esc_FSM_sequential_state_reg_1__1_12501c6 = ((sel_first) ? (((next) ? (((areset_d1) ? (1'b1) : (((si_rs_awvalid) ? (((Q[0]) ? (~(Q[1])) : (1'b0))) : (1'b0))))) : (1'b1))) : (((areset_d1) ? (1'b1) : (((si_rs_awvalid) ? (((Q[0]) ? (~(Q[1])) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT6: sel_first_i_1__1
  assign sel_first_i = ((areset_d1) ? (1'b1) : (((si_rs_awvalid) ? (((Q[0]) ? (((Q[1]) ? (((sel_first_reg_0) ? (~(next)) : (1'b0))) : (1'b1))) : (((sel_first_reg_0) ? (~(next)) : (1'b0))))) : (((sel_first_reg_0) ? (~(next)) : (1'b0))))));

  // Reconstructed LUT3: esc_wrap_boundary_axaddr_r_11__i_1_d843106
  assign E = ((si_rs_awvalid) ? (((Q[0]) ? (~(Q[1])) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: esc_wrap_cnt_r_0__i_1_3122d55
  assign esc_FSM_sequential_state_reg_1__2_92698b2 = ((esc_wrap_cnt_r_reg_0__1_5374db8) ? (((esc_wrap_cnt_r_reg_0__0_ed4efd2) ? (((esc_wrap_cnt_r_reg_0_9ce1d67) ? (((si_rs_awvalid) ? (((Q[0]) ? (~(Q[1])) : (1'b0))) : (1'b0))) : (1'b0))) : (((esc_wrap_cnt_r_reg_0_9ce1d67) ? (1'b1) : (((si_rs_awvalid) ? (((Q[0]) ? (Q[1]) : (1'b1))) : (1'b1))))))) : (((esc_wrap_cnt_r_reg_0__0_ed4efd2) ? (((si_rs_awvalid) ? (((Q[0]) ? (Q[1]) : (1'b1))) : (1'b1))) : (1'b0))));

endmodule

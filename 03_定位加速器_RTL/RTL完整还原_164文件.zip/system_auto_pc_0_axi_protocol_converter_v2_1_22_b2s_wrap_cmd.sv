// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_wrap_cmd
   (wrap_next_pending,
    sel_first,
    Q,
    esc_axlen_cnt_reg_3__0_a623c36 ,
    esc_axlen_cnt_reg_0__0_31fcd59 ,
    s_axburst_eq1_reg,
    sel_first_reg_0,
    esc_wrap_second_len_r_reg_3__0_61735c7 ,
    esc_axaddr_offset_r_reg_3__0_89647ed ,
    aclk,
    sel_first_reg_1,
    next,
    esc_axlen_cnt_reg_3__1_92cec45 ,
    esc_axaddr_wrap_reg_3__0_a824587 ,
    next_pending_r_reg_0,
    E,
    s_axburst_eq1,
    s_axburst_eq0,
    esc_m_axi_awaddr_11_2270491 ,
    esc_axaddr_offset_r_reg_3__1_174c336 ,
    esc_wrap_cnt_r_reg_1__0_205e7f9 ,
    esc_wrap_second_len_r_reg_3__1_e9d1a95 ,
    esc_axaddr_wrap_reg_0__0_8ebf4f6 ,
    esc_axlen_cnt_reg_0__1_4dc9f21 ,
    D,
    esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 );
  output wrap_next_pending;
  output sel_first;
  output [11:0]Q;
  output esc_axlen_cnt_reg_3__0_a623c36 ;
  output [0:0]esc_axlen_cnt_reg_0__0_31fcd59 ;
  output s_axburst_eq1_reg;
  output sel_first_reg_0;
  output [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  output [3:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  input aclk;
  input sel_first_reg_1;
  input next;
  input [18:0]esc_axlen_cnt_reg_3__1_92cec45 ;
  input [1:0]esc_axaddr_wrap_reg_3__0_a824587 ;
  input next_pending_r_reg_0;
  input [0:0]E;
  input s_axburst_eq1;
  input s_axburst_eq0;
  input esc_m_axi_awaddr_11_2270491 ;
  input [3:0]esc_axaddr_offset_r_reg_3__1_174c336 ;
  input esc_wrap_cnt_r_reg_1__0_205e7f9 ;
  input [3:0]esc_wrap_second_len_r_reg_3__1_e9d1a95 ;
  input [0:0]esc_axaddr_wrap_reg_0__0_8ebf4f6 ;
  input [0:0]esc_axlen_cnt_reg_0__1_4dc9f21 ;
  input [2:0]D;
  input [6:0]esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [2:0]D;
  wire [0:0]E;
  wire [11:0]esc_Q_b4c2e74 ;
  wire aclk;
  wire [3:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  wire [3:0]esc_axaddr_offset_r_reg_3__1_174c336 ;
  wire [11:0]axaddr_wrap0;
  wire axaddr_wrap1;
  wire esc_axaddr_wrap_0__i_1__0_n_0_2bc813d ;
  wire esc_axaddr_wrap_11__i_4__0_n_0_68c8d9c ;
  wire esc_axaddr_wrap_1__i_1__0_n_0_7e9e685 ;
  wire esc_axaddr_wrap_2__i_1__0_n_0_2187430 ;
  wire esc_axaddr_wrap_3__i_1__0_n_0_f1b3085 ;
  wire esc_axaddr_wrap_3__i_4_n_0_bd97fb1 ;
  wire esc_axaddr_wrap_3__i_5_n_0_718b011 ;
  wire esc_axaddr_wrap_4__i_1__0_n_0_542a523 ;
  wire esc_axaddr_wrap_5__i_1__0_n_0_2613bbb ;
  wire esc_axaddr_wrap_6__i_1__0_n_0_bdf5f46 ;
  wire esc_axaddr_wrap_7__i_1__0_n_0_f0dcc2c ;
  wire [0:0]esc_axaddr_wrap_reg_0__0_8ebf4f6 ;
  wire [1:0]esc_axaddr_wrap_reg_3__0_a824587 ;
  wire esc_axaddr_wrap_reg_3__i_2_n_0_51f9f5f ;
  wire esc_axlen_cnt_1__i_1_n_0_908ce45 ;
  wire esc_axlen_cnt_2__i_1_n_0_6f8daed ;
  wire esc_axlen_cnt_3__i_1_n_0_a26b5a5 ;
  wire esc_axlen_cnt_3__i_3_n_0_34c51f8 ;
  wire esc_axlen_cnt_4__i_1_n_0_8539436 ;
  wire [0:0]esc_axlen_cnt_reg_0__0_31fcd59 ;
  wire [0:0]esc_axlen_cnt_reg_0__1_4dc9f21 ;
  wire esc_axlen_cnt_reg_3__0_a623c36 ;
  wire [18:0]esc_axlen_cnt_reg_3__1_92cec45 ;
  wire esc_axlen_cnt_reg_n_0__1_db9fc63 ;
  wire esc_axlen_cnt_reg_n_0__2_a2d60e4 ;
  wire esc_axlen_cnt_reg_n_0__3_8857ffe ;
  wire esc_axlen_cnt_reg_n_0__4_f78fcda ;
  wire esc_m_axi_awaddr_11_2270491 ;
  wire next;
  wire next_pending_r;
  wire next_pending_r_reg_0;
  wire s_axburst_eq0;
  wire s_axburst_eq1;
  wire s_axburst_eq1_reg;
  wire sel_first;
  wire sel_first_reg_0;
  wire sel_first_reg_1;
  wire [11:0]wrap_boundary_axaddr_r;
  wire [6:0]esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 ;
  wire [1:1]wrap_cnt;
  wire [3:0]wrap_cnt_r;
  wire esc_wrap_cnt_r_reg_1__0_205e7f9 ;
  wire wrap_next_pending;
  wire [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  wire [3:0]esc_wrap_second_len_r_reg_3__1_e9d1a95 ;
  wire [3:0]esc_NLW_axaddr_wrap_reg_3__i_2_CO_UNCONNECTED_8aca731 ;

  assign Q[5:0] = esc_Q_b4c2e74 [5:0];

  // Reconstructed LUT3: esc_FSM_sequential_state_1__i_2_0d612f0
  assign s_axburst_eq1_reg = ((s_axburst_eq0) ? (((esc_axlen_cnt_reg_3__1_92cec45 [15]) ? (~(s_axburst_eq1)) : (1'b0))) : (((esc_axlen_cnt_reg_3__1_92cec45 [15]) ? (~(s_axburst_eq1)) : (1'b1))));

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed FDRE: esc_axaddr_offset_r_reg_0_a3138f8
  reg recovered_4_q = 1'b0;
  assign esc_axaddr_offset_r_reg_3__0_89647ed [0] = recovered_4_q;
  wire recovered_4_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_4_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (esc_axaddr_offset_r_reg_3__1_174c336 [0])))) recovered_4_q <= (esc_axaddr_offset_r_reg_3__1_174c336 [0]);
  end

  // Reconstructed FDRE: esc_axaddr_offset_r_reg_1_631cdbe
  reg recovered_5_q = 1'b0;
  assign esc_axaddr_offset_r_reg_3__0_89647ed [1] = recovered_5_q;
  wire recovered_5_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (esc_axaddr_offset_r_reg_3__1_174c336 [1])))) recovered_5_q <= (esc_axaddr_offset_r_reg_3__1_174c336 [1]);
  end

  // Reconstructed FDRE: esc_axaddr_offset_r_reg_2_c2282b8
  reg recovered_6_q = 1'b0;
  assign esc_axaddr_offset_r_reg_3__0_89647ed [2] = recovered_6_q;
  wire recovered_6_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (esc_axaddr_offset_r_reg_3__1_174c336 [2])))) recovered_6_q <= (esc_axaddr_offset_r_reg_3__1_174c336 [2]);
  end

  // Reconstructed FDRE: esc_axaddr_offset_r_reg_3_9b4a3fc
  reg recovered_7_q = 1'b0;
  assign esc_axaddr_offset_r_reg_3__0_89647ed [3] = recovered_7_q;
  wire recovered_7_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (esc_axaddr_offset_r_reg_3__1_174c336 [3])))) recovered_7_q <= (esc_axaddr_offset_r_reg_3__1_174c336 [3]);
  end

  // Reconstructed LUT5: esc_axaddr_wrap_0__i_1__0_8bfe2cc
  assign esc_axaddr_wrap_0__i_1__0_n_0_2bc813d = ((esc_axlen_cnt_reg_3__1_92cec45 [0]) ? (((wrap_boundary_axaddr_r[0]) ? (((axaddr_wrap0[0]) ? (1'b1) : (((next) ? (axaddr_wrap1) : (1'b1))))) : (((axaddr_wrap0[0]) ? (((next) ? (~(axaddr_wrap1)) : (1'b1))) : (~(next)))))) : (((wrap_boundary_axaddr_r[0]) ? (((axaddr_wrap0[0]) ? (next) : (((next) ? (axaddr_wrap1) : (1'b0))))) : (((axaddr_wrap0[0]) ? (((next) ? (~(axaddr_wrap1)) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT6: esc_axaddr_wrap_11__i_2__0_ad859b8
  assign axaddr_wrap1 = ((esc_axaddr_wrap_11__i_4__0_n_0_68c8d9c) ? (((wrap_cnt_r[1]) ? (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (((esc_axlen_cnt_reg_0__0_31fcd59) ? (((wrap_cnt_r[0]) ? (~(esc_axlen_cnt_reg_n_0__4_f78fcda)) : (1'b0))) : (((wrap_cnt_r[0]) ? (1'b0) : (~(esc_axlen_cnt_reg_n_0__4_f78fcda)))))) : (1'b0))) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (1'b0) : (((esc_axlen_cnt_reg_0__0_31fcd59) ? (((wrap_cnt_r[0]) ? (~(esc_axlen_cnt_reg_n_0__4_f78fcda)) : (1'b0))) : (((wrap_cnt_r[0]) ? (1'b0) : (~(esc_axlen_cnt_reg_n_0__4_f78fcda)))))))))) : (1'b0));

  // Reconstructed LUT4: esc_axaddr_wrap_11__i_4__0_8088f1b
  assign esc_axaddr_wrap_11__i_4__0_n_0_68c8d9c = ((esc_axlen_cnt_reg_n_0__3_8857ffe) ? (((wrap_cnt_r[3]) ? (((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (wrap_cnt_r[2]) : (~(wrap_cnt_r[2])))) : (1'b0))) : (((wrap_cnt_r[3]) ? (1'b0) : (((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (wrap_cnt_r[2]) : (~(wrap_cnt_r[2])))))));

  // Reconstructed LUT5: esc_axaddr_wrap_1__i_1__0_8f036cf
  assign esc_axaddr_wrap_1__i_1__0_n_0_7e9e685 = ((esc_axlen_cnt_reg_3__1_92cec45 [1]) ? (((wrap_boundary_axaddr_r[1]) ? (((axaddr_wrap0[1]) ? (1'b1) : (((next) ? (axaddr_wrap1) : (1'b1))))) : (((axaddr_wrap0[1]) ? (((next) ? (~(axaddr_wrap1)) : (1'b1))) : (~(next)))))) : (((wrap_boundary_axaddr_r[1]) ? (((axaddr_wrap0[1]) ? (next) : (((next) ? (axaddr_wrap1) : (1'b0))))) : (((axaddr_wrap0[1]) ? (((next) ? (~(axaddr_wrap1)) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: esc_axaddr_wrap_2__i_1__0_b2dd3d3
  assign esc_axaddr_wrap_2__i_1__0_n_0_2187430 = ((esc_axlen_cnt_reg_3__1_92cec45 [2]) ? (((wrap_boundary_axaddr_r[2]) ? (((axaddr_wrap0[2]) ? (1'b1) : (((next) ? (axaddr_wrap1) : (1'b1))))) : (((axaddr_wrap0[2]) ? (((next) ? (~(axaddr_wrap1)) : (1'b1))) : (~(next)))))) : (((wrap_boundary_axaddr_r[2]) ? (((axaddr_wrap0[2]) ? (next) : (((next) ? (axaddr_wrap1) : (1'b0))))) : (((axaddr_wrap0[2]) ? (((next) ? (~(axaddr_wrap1)) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: esc_axaddr_wrap_3__i_1__0_a241512
  assign esc_axaddr_wrap_3__i_1__0_n_0_f1b3085 = ((esc_axlen_cnt_reg_3__1_92cec45 [3]) ? (((wrap_boundary_axaddr_r[3]) ? (((axaddr_wrap0[3]) ? (1'b1) : (((next) ? (axaddr_wrap1) : (1'b1))))) : (((axaddr_wrap0[3]) ? (((next) ? (~(axaddr_wrap1)) : (1'b1))) : (~(next)))))) : (((wrap_boundary_axaddr_r[3]) ? (((axaddr_wrap0[3]) ? (next) : (((next) ? (axaddr_wrap1) : (1'b0))))) : (((axaddr_wrap0[3]) ? (((next) ? (~(axaddr_wrap1)) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT3: esc_axaddr_wrap_3__i_4_c4a11f5
  assign esc_axaddr_wrap_3__i_4_n_0_bd97fb1 = ((esc_axlen_cnt_reg_3__1_92cec45 [13]) ? (((esc_axlen_cnt_reg_3__1_92cec45 [12]) ? (esc_Q_b4c2e74 [2]) : (~(esc_Q_b4c2e74 [2])))) : (esc_Q_b4c2e74 [2]));

  // Reconstructed LUT3: esc_axaddr_wrap_3__i_5_b631825
  assign esc_axaddr_wrap_3__i_5_n_0_718b011 = ((esc_axlen_cnt_reg_3__1_92cec45 [12]) ? (((esc_axlen_cnt_reg_3__1_92cec45 [13]) ? (esc_Q_b4c2e74 [1]) : (~(esc_Q_b4c2e74 [1])))) : (esc_Q_b4c2e74 [1]));

  // Reconstructed LUT5: esc_axaddr_wrap_4__i_1__0_25b9e93
  assign esc_axaddr_wrap_4__i_1__0_n_0_542a523 = ((esc_axlen_cnt_reg_3__1_92cec45 [4]) ? (((wrap_boundary_axaddr_r[4]) ? (((axaddr_wrap0[4]) ? (1'b1) : (((next) ? (axaddr_wrap1) : (1'b1))))) : (((axaddr_wrap0[4]) ? (((next) ? (~(axaddr_wrap1)) : (1'b1))) : (~(next)))))) : (((wrap_boundary_axaddr_r[4]) ? (((axaddr_wrap0[4]) ? (next) : (((next) ? (axaddr_wrap1) : (1'b0))))) : (((axaddr_wrap0[4]) ? (((next) ? (~(axaddr_wrap1)) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: esc_axaddr_wrap_5__i_1__0_d3c717f
  assign esc_axaddr_wrap_5__i_1__0_n_0_2613bbb = ((esc_axlen_cnt_reg_3__1_92cec45 [5]) ? (((wrap_boundary_axaddr_r[5]) ? (((axaddr_wrap0[5]) ? (1'b1) : (((next) ? (axaddr_wrap1) : (1'b1))))) : (((axaddr_wrap0[5]) ? (((next) ? (~(axaddr_wrap1)) : (1'b1))) : (~(next)))))) : (((wrap_boundary_axaddr_r[5]) ? (((axaddr_wrap0[5]) ? (next) : (((next) ? (axaddr_wrap1) : (1'b0))))) : (((axaddr_wrap0[5]) ? (((next) ? (~(axaddr_wrap1)) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: esc_axaddr_wrap_6__i_1__0_f7f35a5
  assign esc_axaddr_wrap_6__i_1__0_n_0_bdf5f46 = ((esc_axlen_cnt_reg_3__1_92cec45 [6]) ? (((wrap_boundary_axaddr_r[6]) ? (((axaddr_wrap0[6]) ? (1'b1) : (((next) ? (axaddr_wrap1) : (1'b1))))) : (((axaddr_wrap0[6]) ? (((next) ? (~(axaddr_wrap1)) : (1'b1))) : (~(next)))))) : (((wrap_boundary_axaddr_r[6]) ? (((axaddr_wrap0[6]) ? (next) : (((next) ? (axaddr_wrap1) : (1'b0))))) : (((axaddr_wrap0[6]) ? (((next) ? (~(axaddr_wrap1)) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: esc_axaddr_wrap_7__i_1__0_07fb87d
  assign esc_axaddr_wrap_7__i_1__0_n_0_f0dcc2c = ((esc_axlen_cnt_reg_3__1_92cec45 [7]) ? (((wrap_boundary_axaddr_r[7]) ? (((axaddr_wrap0[7]) ? (1'b1) : (((next) ? (axaddr_wrap1) : (1'b1))))) : (((axaddr_wrap0[7]) ? (((next) ? (~(axaddr_wrap1)) : (1'b1))) : (~(next)))))) : (((wrap_boundary_axaddr_r[7]) ? (((axaddr_wrap0[7]) ? (next) : (((next) ? (axaddr_wrap1) : (1'b0))))) : (((axaddr_wrap0[7]) ? (((next) ? (~(axaddr_wrap1)) : (1'b0))) : (1'b0))))));

  // Reconstructed FDRE: esc_axaddr_wrap_reg_0_4889146
  reg recovered_20_q = 1'b0;
  assign esc_Q_b4c2e74 [0] = recovered_20_q;
  wire recovered_20_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_20_q == (esc_axaddr_wrap_0__i_1__0_n_0_2bc813d)))) recovered_20_q <= (esc_axaddr_wrap_0__i_1__0_n_0_2bc813d);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_1_fe74833
  reg recovered_21_q = 1'b0;
  assign esc_Q_b4c2e74 [1] = recovered_21_q;
  wire recovered_21_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_21_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_21_q == (esc_axaddr_wrap_1__i_1__0_n_0_7e9e685)))) recovered_21_q <= (esc_axaddr_wrap_1__i_1__0_n_0_7e9e685);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_2_ef2eafe
  reg recovered_22_q = 1'b0;
  assign esc_Q_b4c2e74 [2] = recovered_22_q;
  wire recovered_22_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_22_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_22_q == (esc_axaddr_wrap_2__i_1__0_n_0_2187430)))) recovered_22_q <= (esc_axaddr_wrap_2__i_1__0_n_0_2187430);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_3_f9d1eab
  reg recovered_23_q = 1'b0;
  assign esc_Q_b4c2e74 [3] = recovered_23_q;
  wire recovered_23_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_23_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_23_q == (esc_axaddr_wrap_3__i_1__0_n_0_f1b3085)))) recovered_23_q <= (esc_axaddr_wrap_3__i_1__0_n_0_f1b3085);
  end

  // Reconstructed CARRY4: esc_axaddr_wrap_reg_3__i_2_ac5a0a5
  wire [3:0] recovered_24_co, recovered_24_o, recovered_24_s, recovered_24_di;
  assign recovered_24_s = {esc_axaddr_wrap_reg_3__0_a824587 [1],esc_axaddr_wrap_3__i_4_n_0_bd97fb1 ,esc_axaddr_wrap_3__i_5_n_0_718b011 ,esc_axaddr_wrap_reg_3__0_a824587 [0]};
  assign recovered_24_di = esc_Q_b4c2e74 [3:0];
  wire recovered_24_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_24_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_24_o[0] = recovered_24_s[0] ^ (recovered_24_ci || recovered_24_cy);
  assign recovered_24_co[0] = (recovered_24_s[0] & (recovered_24_ci || recovered_24_cy)) | (~recovered_24_s[0] & recovered_24_di[0]);
  assign recovered_24_o[1] = recovered_24_s[1] ^ recovered_24_co[0];
  assign recovered_24_co[1] = (recovered_24_s[1] & recovered_24_co[0]) | (~recovered_24_s[1] & recovered_24_di[1]);
  assign recovered_24_o[2] = recovered_24_s[2] ^ recovered_24_co[1];
  assign recovered_24_co[2] = (recovered_24_s[2] & recovered_24_co[1]) | (~recovered_24_s[2] & recovered_24_di[2]);
  assign recovered_24_o[3] = recovered_24_s[3] ^ recovered_24_co[2];
  assign recovered_24_co[3] = (recovered_24_s[3] & recovered_24_co[2]) | (~recovered_24_s[3] & recovered_24_di[3]);
  assign {esc_axaddr_wrap_reg_3__i_2_n_0_51f9f5f ,esc_NLW_axaddr_wrap_reg_3__i_2_CO_UNCONNECTED_8aca731 [2:0]} = recovered_24_co;
  assign axaddr_wrap0[3:0] = recovered_24_o;

  // Reconstructed FDRE: esc_axaddr_wrap_reg_4_3609701
  reg recovered_25_q = 1'b0;
  assign esc_Q_b4c2e74 [4] = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_25_q == (esc_axaddr_wrap_4__i_1__0_n_0_542a523)))) recovered_25_q <= (esc_axaddr_wrap_4__i_1__0_n_0_542a523);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_5_e65c61e
  reg recovered_26_q = 1'b0;
  assign esc_Q_b4c2e74 [5] = recovered_26_q;
  wire recovered_26_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_26_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_26_q == (esc_axaddr_wrap_5__i_1__0_n_0_2613bbb)))) recovered_26_q <= (esc_axaddr_wrap_5__i_1__0_n_0_2613bbb);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_6_e11600c
  reg recovered_27_q = 1'b0;
  assign esc_Q_b4c2e74 [6] = recovered_27_q;
  wire recovered_27_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_27_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_27_q == (esc_axaddr_wrap_6__i_1__0_n_0_bdf5f46)))) recovered_27_q <= (esc_axaddr_wrap_6__i_1__0_n_0_bdf5f46);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_7_0468310
  reg recovered_28_q = 1'b0;
  assign esc_Q_b4c2e74 [7] = recovered_28_q;
  wire recovered_28_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_28_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_28_q == (esc_axaddr_wrap_7__i_1__0_n_0_f0dcc2c)))) recovered_28_q <= (esc_axaddr_wrap_7__i_1__0_n_0_f0dcc2c);
  end

  // Reconstructed CARRY4: esc_axaddr_wrap_reg_7__i_2_dd50c65
  wire [3:0] recovered_29_co, recovered_29_o, recovered_29_s, recovered_29_di;
  assign recovered_29_s = esc_Q_b4c2e74 [7:4];
  assign recovered_29_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_29_ci = ((esc_axaddr_wrap_reg_3__i_2_n_0_51f9f5f) !== 1'bz) && (esc_axaddr_wrap_reg_3__i_2_n_0_51f9f5f);
  wire recovered_29_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_29_o[0] = recovered_29_s[0] ^ (recovered_29_ci || recovered_29_cy);
  assign recovered_29_co[0] = (recovered_29_s[0] & (recovered_29_ci || recovered_29_cy)) | (~recovered_29_s[0] & recovered_29_di[0]);
  assign recovered_29_o[1] = recovered_29_s[1] ^ recovered_29_co[0];
  assign recovered_29_co[1] = (recovered_29_s[1] & recovered_29_co[0]) | (~recovered_29_s[1] & recovered_29_di[1]);
  assign recovered_29_o[2] = recovered_29_s[2] ^ recovered_29_co[1];
  assign recovered_29_co[2] = (recovered_29_s[2] & recovered_29_co[1]) | (~recovered_29_s[2] & recovered_29_di[2]);
  assign recovered_29_o[3] = recovered_29_s[3] ^ recovered_29_co[2];
  assign recovered_29_co[3] = (recovered_29_s[3] & recovered_29_co[2]) | (~recovered_29_s[3] & recovered_29_di[3]);
  assign axaddr_wrap0[7:4] = recovered_29_o;

  // Reconstructed LUT5: esc_axlen_cnt_1__i_1_fbedcf7
  assign esc_axlen_cnt_1__i_1_n_0_908ce45 = ((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (((esc_axlen_cnt_reg_0__0_31fcd59) ? (((esc_axlen_cnt_reg_3__0_a623c36) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [16]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [16]) : (1'b0))))) : (((esc_axlen_cnt_reg_0__0_31fcd59) ? (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [16]) : (1'b0))) : (((esc_axlen_cnt_reg_3__0_a623c36) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [16]) : (1'b0))))))));

  // Reconstructed LUT6: esc_axlen_cnt_2__i_1_17fb3d4
  assign esc_axlen_cnt_2__i_1_n_0_6f8daed = ((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (((esc_axlen_cnt_reg_0__0_31fcd59) ? (((esc_axlen_cnt_reg_3__0_a623c36) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [17]) : (1'b0))))) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (((esc_axlen_cnt_reg_3__0_a623c36) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [17]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [17]) : (1'b0))))))) : (((esc_axlen_cnt_reg_0__0_31fcd59) ? (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [17]) : (1'b0))) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [17]) : (1'b0))) : (((esc_axlen_cnt_reg_3__0_a623c36) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [17]) : (1'b0))))))))));

  // Reconstructed LUT5: esc_axlen_cnt_3__i_1_bca53ca
  assign esc_axlen_cnt_3__i_1_n_0_a26b5a5 = ((esc_axlen_cnt_reg_n_0__3_8857ffe) ? (((esc_axlen_cnt_3__i_3_n_0_34c51f8) ? (((esc_axlen_cnt_reg_3__0_a623c36) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [18]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [18]) : (1'b0))))) : (((esc_axlen_cnt_3__i_3_n_0_34c51f8) ? (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [18]) : (1'b0))) : (((esc_axlen_cnt_reg_3__0_a623c36) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__1_92cec45 [18]) : (1'b0))))))));

  // Reconstructed LUT5: esc_axlen_cnt_3__i_2_fd18eb9
  assign esc_axlen_cnt_reg_3__0_a623c36 = ((E) ? (1'b0) : (((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__4_f78fcda) ? (1'b1) : (esc_axlen_cnt_reg_n_0__3_8857ffe))))))));

  // Reconstructed LUT3: esc_axlen_cnt_3__i_3_730b112
  assign esc_axlen_cnt_3__i_3_n_0_34c51f8 = ((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (1'b1) : (((esc_axlen_cnt_reg_0__0_31fcd59) ? (1'b1) : (esc_axlen_cnt_reg_n_0__1_db9fc63))));

  // Reconstructed LUT6: esc_axlen_cnt_4__i_1_c0d7f43
  assign esc_axlen_cnt_4__i_1_n_0_8539436 = ((esc_axlen_cnt_reg_n_0__4_f78fcda) ? (((E) ? (1'b0) : (((esc_axlen_cnt_reg_n_0__3_8857ffe) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (1'b1) : (((esc_axlen_cnt_reg_0__0_31fcd59) ? (1'b1) : (esc_axlen_cnt_reg_n_0__2_a2d60e4))))))))) : (1'b0));

  // Reconstructed FDRE: esc_axlen_cnt_reg_0_56abf15
  reg recovered_36_q = 1'b0;
  assign esc_axlen_cnt_reg_0__0_31fcd59 = recovered_36_q;
  wire recovered_36_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_36_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_36_q == 1'b0))) recovered_36_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_36_q == (esc_axlen_cnt_reg_0__1_4dc9f21)))) recovered_36_q <= (esc_axlen_cnt_reg_0__1_4dc9f21);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_1_405fc67
  reg recovered_37_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__1_db9fc63 = recovered_37_q;
  wire recovered_37_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_37_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_37_q == 1'b0))) recovered_37_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_37_q == (esc_axlen_cnt_1__i_1_n_0_908ce45)))) recovered_37_q <= (esc_axlen_cnt_1__i_1_n_0_908ce45);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_2_379d3d4
  reg recovered_38_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__2_a2d60e4 = recovered_38_q;
  wire recovered_38_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_38_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_38_q == 1'b0))) recovered_38_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_38_q == (esc_axlen_cnt_2__i_1_n_0_6f8daed)))) recovered_38_q <= (esc_axlen_cnt_2__i_1_n_0_6f8daed);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_3_46333b8
  reg recovered_39_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__3_8857ffe = recovered_39_q;
  wire recovered_39_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_39_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_39_q == 1'b0))) recovered_39_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_39_q == (esc_axlen_cnt_3__i_1_n_0_a26b5a5)))) recovered_39_q <= (esc_axlen_cnt_3__i_1_n_0_a26b5a5);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_4_3087e61
  reg recovered_40_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__4_f78fcda = recovered_40_q;
  wire recovered_40_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_40_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_40_q == 1'b0))) recovered_40_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_40_q == (esc_axlen_cnt_4__i_1_n_0_8539436)))) recovered_40_q <= (esc_axlen_cnt_4__i_1_n_0_8539436);
  end

  // Reconstructed LUT4: esc_m_axi_awaddr_11__INST_0_i_3_075e3be
  assign sel_first_reg_0 = ((esc_axlen_cnt_reg_3__1_92cec45 [14]) ? (((esc_m_axi_awaddr_11_2270491) ? (((esc_axlen_cnt_reg_3__1_92cec45 [15]) ? (sel_first) : (1'b1))) : (((esc_axlen_cnt_reg_3__1_92cec45 [15]) ? (sel_first) : (1'b0))))) : (((esc_axlen_cnt_reg_3__1_92cec45 [15]) ? (sel_first) : (1'b1))));

  // Reconstructed LUT5: next_pending_r_i_1
  assign wrap_next_pending = ((esc_axlen_cnt_reg_3__0_a623c36) ? (((next) ? (1'b1) : (((E) ? (next_pending_r_reg_0) : (((next_pending_r) ? (1'b1) : (next_pending_r_reg_0))))))) : (((next) ? (next_pending_r_reg_0) : (((E) ? (next_pending_r_reg_0) : (((next_pending_r) ? (1'b1) : (next_pending_r_reg_0))))))));

  // Reconstructed FDRE: next_pending_r_reg
  reg recovered_43_q = 1'b0;
  assign next_pending_r = recovered_43_q;
  wire recovered_43_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_43_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_43_q == (wrap_next_pending)))) recovered_43_q <= (wrap_next_pending);
  end

  // Reconstructed FDRE: sel_first_reg
  reg recovered_44_q = 1'b0;
  assign sel_first = recovered_44_q;
  wire recovered_44_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_44_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_44_q == (sel_first_reg_1)))) recovered_44_q <= (sel_first_reg_1);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_0_9761f59
  reg recovered_45_q = 1'b0;
  assign wrap_boundary_axaddr_r[0] = recovered_45_q;
  wire recovered_45_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_45_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_45_q == 1'b0))) recovered_45_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_45_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [0])))) recovered_45_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [0]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_1_5a2ef29
  reg recovered_46_q = 1'b0;
  assign wrap_boundary_axaddr_r[1] = recovered_46_q;
  wire recovered_46_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_46_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_46_q == 1'b0))) recovered_46_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_46_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [1])))) recovered_46_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [1]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_2_f6bab03
  reg recovered_47_q = 1'b0;
  assign wrap_boundary_axaddr_r[2] = recovered_47_q;
  wire recovered_47_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_47_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_47_q == 1'b0))) recovered_47_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_47_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [2])))) recovered_47_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [2]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_3_f49857a
  reg recovered_48_q = 1'b0;
  assign wrap_boundary_axaddr_r[3] = recovered_48_q;
  wire recovered_48_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_48_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_48_q == 1'b0))) recovered_48_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_48_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [3])))) recovered_48_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [3]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_4_c6a7357
  reg recovered_49_q = 1'b0;
  assign wrap_boundary_axaddr_r[4] = recovered_49_q;
  wire recovered_49_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_49_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_49_q == 1'b0))) recovered_49_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_49_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [4])))) recovered_49_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [4]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_5_e137ab2
  reg recovered_50_q = 1'b0;
  assign wrap_boundary_axaddr_r[5] = recovered_50_q;
  wire recovered_50_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_50_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_50_q == 1'b0))) recovered_50_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_50_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [5])))) recovered_50_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [5]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_6_a91079e
  reg recovered_51_q = 1'b0;
  assign wrap_boundary_axaddr_r[6] = recovered_51_q;
  wire recovered_51_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_51_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_51_q == 1'b0))) recovered_51_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_51_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [6])))) recovered_51_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [6]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_7_6e4e160
  reg recovered_52_q = 1'b0;
  assign wrap_boundary_axaddr_r[7] = recovered_52_q;
  wire recovered_52_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_52_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_52_q == 1'b0))) recovered_52_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_52_q == (esc_axlen_cnt_reg_3__1_92cec45 [7])))) recovered_52_q <= (esc_axlen_cnt_reg_3__1_92cec45 [7]);
  end

  // Reconstructed LUT5: esc_wrap_cnt_r_1__i_1_edd1e4d
  assign wrap_cnt = ((esc_wrap_second_len_r_reg_3__0_61735c7 [1]) ? (((E) ? (((esc_wrap_cnt_r_reg_1__0_205e7f9) ? (esc_axaddr_offset_r_reg_3__1_174c336 [1]) : (1'b0))) : (((esc_wrap_cnt_r_reg_1__0_205e7f9) ? (~(esc_wrap_second_len_r_reg_3__0_61735c7 [0])) : (1'b1))))) : (((E) ? (((esc_wrap_cnt_r_reg_1__0_205e7f9) ? (esc_axaddr_offset_r_reg_3__1_174c336 [1]) : (1'b0))) : (((esc_wrap_cnt_r_reg_1__0_205e7f9) ? (esc_wrap_second_len_r_reg_3__0_61735c7 [0]) : (1'b0))))));

  // Reconstructed FDRE: esc_wrap_cnt_r_reg_0_9ce1d67
  reg recovered_54_q = 1'b0;
  assign wrap_cnt_r[0] = recovered_54_q;
  wire recovered_54_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_54_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_54_q == 1'b0))) recovered_54_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_54_q == (D[0])))) recovered_54_q <= (D[0]);
  end

  // Reconstructed FDRE: esc_wrap_cnt_r_reg_1_4617ef8
  reg recovered_55_q = 1'b0;
  assign wrap_cnt_r[1] = recovered_55_q;
  wire recovered_55_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_55_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_55_q == 1'b0))) recovered_55_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_55_q == (wrap_cnt)))) recovered_55_q <= (wrap_cnt);
  end

  // Reconstructed FDRE: esc_wrap_cnt_r_reg_2_6dcb155
  reg recovered_56_q = 1'b0;
  assign wrap_cnt_r[2] = recovered_56_q;
  wire recovered_56_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_56_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_56_q == 1'b0))) recovered_56_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_56_q == (D[1])))) recovered_56_q <= (D[1]);
  end

  // Reconstructed FDRE: esc_wrap_cnt_r_reg_3_8701380
  reg recovered_57_q = 1'b0;
  assign wrap_cnt_r[3] = recovered_57_q;
  wire recovered_57_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_57_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_57_q == 1'b0))) recovered_57_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_57_q == (D[2])))) recovered_57_q <= (D[2]);
  end

  // Reconstructed FDRE: esc_wrap_second_len_r_reg_0_933d6c0
  reg recovered_58_q = 1'b0;
  assign esc_wrap_second_len_r_reg_3__0_61735c7 [0] = recovered_58_q;
  wire recovered_58_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_58_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_58_q == 1'b0))) recovered_58_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_58_q == (esc_wrap_second_len_r_reg_3__1_e9d1a95 [0])))) recovered_58_q <= (esc_wrap_second_len_r_reg_3__1_e9d1a95 [0]);
  end

  // Reconstructed FDRE: esc_wrap_second_len_r_reg_1_dd27002
  reg recovered_59_q = 1'b0;
  assign esc_wrap_second_len_r_reg_3__0_61735c7 [1] = recovered_59_q;
  wire recovered_59_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_59_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_59_q == 1'b0))) recovered_59_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_59_q == (esc_wrap_second_len_r_reg_3__1_e9d1a95 [1])))) recovered_59_q <= (esc_wrap_second_len_r_reg_3__1_e9d1a95 [1]);
  end

  // Reconstructed FDRE: esc_wrap_second_len_r_reg_2_01b34aa
  reg recovered_60_q = 1'b0;
  assign esc_wrap_second_len_r_reg_3__0_61735c7 [2] = recovered_60_q;
  wire recovered_60_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_60_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_60_q == 1'b0))) recovered_60_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_60_q == (esc_wrap_second_len_r_reg_3__1_e9d1a95 [2])))) recovered_60_q <= (esc_wrap_second_len_r_reg_3__1_e9d1a95 [2]);
  end

  // Reconstructed FDRE: esc_wrap_second_len_r_reg_3_130d984
  reg recovered_61_q = 1'b0;
  assign esc_wrap_second_len_r_reg_3__0_61735c7 [3] = recovered_61_q;
  wire recovered_61_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_61_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_61_q == 1'b0))) recovered_61_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_61_q == (esc_wrap_second_len_r_reg_3__1_e9d1a95 [3])))) recovered_61_q <= (esc_wrap_second_len_r_reg_3__1_e9d1a95 [3]);
  end

endmodule

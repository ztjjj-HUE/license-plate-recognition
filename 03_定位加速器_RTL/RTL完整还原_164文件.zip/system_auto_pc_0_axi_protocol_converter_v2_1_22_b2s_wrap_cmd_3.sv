// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_protocol_converter_v2_1_22_b2s_wrap_cmd_3
   (wrap_next_pending,
    sel_first_reg_0,
    O,
    esc_axaddr_wrap_reg_11__0_0f67430 ,
    esc_axaddr_wrap_reg_7__0_317aa52 ,
    esc_axaddr_wrap_reg_11__1_cfa1a32 ,
    esc_m_payload_i_reg_39_ea68878 ,
    esc_axlen_cnt_reg_4__0_bb101a4 ,
    sel_first_reg_1,
    esc_wrap_second_len_r_reg_3__0_61735c7 ,
    esc_axaddr_offset_r_reg_3__0_89647ed ,
    esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 ,
    aclk,
    sel_first_reg_2,
    S,
    esc_axlen_cnt_reg_3__0_a623c36 ,
    sel_first_i,
    s_axburst_eq1_reg,
    s_axburst_eq1_reg_0,
    r_push,
    E,
    next_pending_r_reg_0,
    esc_m_axi_araddr_11_4618f72 ,
    Q,
    si_rs_arvalid,
    axaddr_offset,
    esc_wrap_cnt_r_reg_1__0_205e7f9 ,
    D,
    esc_axaddr_wrap_reg_0__0_8ebf4f6 ,
    esc_wrap_cnt_r_reg_3__0_82edd32 ,
    esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 ,
    esc_axaddr_wrap_reg_11__2_82ad777 );
  output wrap_next_pending;
  output sel_first_reg_0;
  output [3:0]O;
  output [11:0]esc_axaddr_wrap_reg_11__0_0f67430 ;
  output [3:0]esc_axaddr_wrap_reg_7__0_317aa52 ;
  output [3:0]esc_axaddr_wrap_reg_11__1_cfa1a32 ;
  output esc_m_payload_i_reg_39_ea68878 ;
  output esc_axlen_cnt_reg_4__0_bb101a4 ;
  output sel_first_reg_1;
  output [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  output [3:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  output [11:0]esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 ;
  input aclk;
  input sel_first_reg_2;
  input [1:0]S;
  input [12:0]esc_axlen_cnt_reg_3__0_a623c36 ;
  input sel_first_i;
  input s_axburst_eq1_reg;
  input s_axburst_eq1_reg_0;
  input r_push;
  input [0:0]E;
  input next_pending_r_reg_0;
  input esc_m_axi_araddr_11_4618f72 ;
  input [0:0]Q;
  input si_rs_arvalid;
  input [3:0]axaddr_offset;
  input esc_wrap_cnt_r_reg_1__0_205e7f9 ;
  input [3:0]D;
  input [0:0]esc_axaddr_wrap_reg_0__0_8ebf4f6 ;
  input [2:0]esc_wrap_cnt_r_reg_3__0_82edd32 ;
  input [6:0]esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 ;
  input [11:0]esc_axaddr_wrap_reg_11__2_82ad777 ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [3:0]D;
  wire [0:0]E;
  wire [3:0]O;
  wire [0:0]Q;
  wire [1:0]S;
  wire aclk;
  wire [3:0]axaddr_offset;
  wire [3:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  wire esc_axaddr_wrap_11__i_6_n_0_bc7d692 ;
  wire esc_axaddr_wrap_3__i_4_n_0_bd97fb1 ;
  wire esc_axaddr_wrap_3__i_5_n_0_718b011 ;
  wire [0:0]esc_axaddr_wrap_reg_0__0_8ebf4f6 ;
  wire [11:0]esc_axaddr_wrap_reg_11__0_3bfc4ca ;
  wire [11:0]esc_axaddr_wrap_reg_11__2_82ad777 ;
  wire esc_axaddr_wrap_reg_3__i_2__0_n_0_6ac5b39 ;
  wire [3:0]esc_axaddr_wrap_reg_7__0_317aa52 ;
  wire esc_axlen_cnt_0__i_1__2_n_0_ac33be6 ;
  wire esc_axlen_cnt_1__i_1__1_n_0_1fb243f ;
  wire esc_axlen_cnt_2__i_1__1_n_0_eb3799f ;
  wire esc_axlen_cnt_3__i_1__1_n_0_0b7fa2b ;
  wire esc_axlen_cnt_3__i_2__0_n_0_cd0db03 ;
  wire esc_axlen_cnt_3__i_3__0_n_0_e168a7c ;
  wire esc_axlen_cnt_4__i_1__1_n_0_ec07f7b ;
  wire [12:0]esc_axlen_cnt_reg_3__0_a623c36 ;
  wire esc_axlen_cnt_reg_4__0_bb101a4 ;
  wire esc_axlen_cnt_reg_n_0__0_6b9adfb ;
  wire esc_axlen_cnt_reg_n_0__1_db9fc63 ;
  wire esc_axlen_cnt_reg_n_0__2_a2d60e4 ;
  wire esc_axlen_cnt_reg_n_0__3_8857ffe ;
  wire esc_axlen_cnt_reg_n_0__4_f78fcda ;
  wire esc_m_axi_araddr_11_4618f72 ;
  wire esc_m_payload_i_reg_39_ea68878 ;
  wire next_pending_r;
  wire next_pending_r_reg_0;
  wire r_push;
  wire s_axburst_eq1_reg;
  wire sel_first_i;
  wire sel_first_reg_0;
  wire sel_first_reg_1;
  wire sel_first_reg_2;
  wire si_rs_arvalid;
  wire [11:0]esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 ;
  wire [6:0]esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 ;
  wire esc_wrap_cnt_r_1__i_1__0_n_0_d9bd43a ;
  wire esc_wrap_cnt_r_reg_1__0_205e7f9 ;
  wire [2:0]esc_wrap_cnt_r_reg_3__0_82edd32 ;
  wire esc_wrap_cnt_r_reg_n_0__0_0ce605c ;
  wire esc_wrap_cnt_r_reg_n_0__1_b7d6f34 ;
  wire esc_wrap_cnt_r_reg_n_0__2_1531d71 ;
  wire esc_wrap_cnt_r_reg_n_0__3_a1075d2 ;
  wire wrap_next_pending;
  wire [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  wire [3:0]esc_NLW_axaddr_wrap_reg_3__i_2__0_CO_UNCONNECTED_1f6f501 ;

  assign esc_axaddr_wrap_reg_11__0_0f67430 [5:0] = esc_axaddr_wrap_reg_11__0_3bfc4ca [5:0];

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed FDRE: esc_axaddr_offset_r_reg_0_a3138f8
  reg recovered_3_q = 1'b0;
  assign esc_axaddr_offset_r_reg_3__0_89647ed [0] = recovered_3_q;
  wire recovered_3_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_3_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_3_q == 1'b0))) recovered_3_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_3_q == (axaddr_offset[0])))) recovered_3_q <= (axaddr_offset[0]);
  end

  // Reconstructed FDRE: esc_axaddr_offset_r_reg_1_631cdbe
  reg recovered_4_q = 1'b0;
  assign esc_axaddr_offset_r_reg_3__0_89647ed [1] = recovered_4_q;
  wire recovered_4_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_4_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (axaddr_offset[1])))) recovered_4_q <= (axaddr_offset[1]);
  end

  // Reconstructed FDRE: esc_axaddr_offset_r_reg_2_c2282b8
  reg recovered_5_q = 1'b0;
  assign esc_axaddr_offset_r_reg_3__0_89647ed [2] = recovered_5_q;
  wire recovered_5_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (axaddr_offset[2])))) recovered_5_q <= (axaddr_offset[2]);
  end

  // Reconstructed FDRE: esc_axaddr_offset_r_reg_3_9b4a3fc
  reg recovered_6_q = 1'b0;
  assign esc_axaddr_offset_r_reg_3__0_89647ed [3] = recovered_6_q;
  wire recovered_6_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (axaddr_offset[3])))) recovered_6_q <= (axaddr_offset[3]);
  end

  // Reconstructed LUT6: esc_axaddr_wrap_11__i_5_88ddb37
  assign esc_axlen_cnt_reg_4__0_bb101a4 = ((esc_axaddr_wrap_11__i_6_n_0_bc7d692) ? (((esc_wrap_cnt_r_reg_n_0__1_b7d6f34) ? (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (((esc_wrap_cnt_r_reg_n_0__0_0ce605c) ? (~(esc_axlen_cnt_reg_n_0__4_f78fcda)) : (1'b0))) : (((esc_wrap_cnt_r_reg_n_0__0_0ce605c) ? (1'b0) : (~(esc_axlen_cnt_reg_n_0__4_f78fcda)))))) : (1'b0))) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (1'b0) : (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (((esc_wrap_cnt_r_reg_n_0__0_0ce605c) ? (~(esc_axlen_cnt_reg_n_0__4_f78fcda)) : (1'b0))) : (((esc_wrap_cnt_r_reg_n_0__0_0ce605c) ? (1'b0) : (~(esc_axlen_cnt_reg_n_0__4_f78fcda)))))))))) : (1'b0));

  // Reconstructed LUT4: esc_axaddr_wrap_11__i_6_c968e8f
  assign esc_axaddr_wrap_11__i_6_n_0_bc7d692 = ((esc_axlen_cnt_reg_n_0__3_8857ffe) ? (((esc_wrap_cnt_r_reg_n_0__3_a1075d2) ? (((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (esc_wrap_cnt_r_reg_n_0__2_1531d71) : (~(esc_wrap_cnt_r_reg_n_0__2_1531d71)))) : (1'b0))) : (((esc_wrap_cnt_r_reg_n_0__3_a1075d2) ? (1'b0) : (((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (esc_wrap_cnt_r_reg_n_0__2_1531d71) : (~(esc_wrap_cnt_r_reg_n_0__2_1531d71)))))));

  // Reconstructed LUT3: esc_axaddr_wrap_3__i_4_c4a11f5
  assign esc_axaddr_wrap_3__i_4_n_0_bd97fb1 = ((esc_axlen_cnt_reg_3__0_a623c36 [6]) ? (((esc_axlen_cnt_reg_3__0_a623c36 [5]) ? (esc_axaddr_wrap_reg_11__0_3bfc4ca [2]) : (~(esc_axaddr_wrap_reg_11__0_3bfc4ca [2])))) : (esc_axaddr_wrap_reg_11__0_3bfc4ca [2]));

  // Reconstructed LUT3: esc_axaddr_wrap_3__i_5_b631825
  assign esc_axaddr_wrap_3__i_5_n_0_718b011 = ((esc_axlen_cnt_reg_3__0_a623c36 [5]) ? (((esc_axlen_cnt_reg_3__0_a623c36 [6]) ? (esc_axaddr_wrap_reg_11__0_3bfc4ca [1]) : (~(esc_axaddr_wrap_reg_11__0_3bfc4ca [1])))) : (esc_axaddr_wrap_reg_11__0_3bfc4ca [1]));

  // Reconstructed FDRE: esc_axaddr_wrap_reg_0_4889146
  reg recovered_11_q = 1'b0;
  assign esc_axaddr_wrap_reg_11__0_3bfc4ca [0] = recovered_11_q;
  wire recovered_11_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_11_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_11_q == (esc_axaddr_wrap_reg_11__2_82ad777 [0])))) recovered_11_q <= (esc_axaddr_wrap_reg_11__2_82ad777 [0]);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_1_fe74833
  reg recovered_12_q = 1'b0;
  assign esc_axaddr_wrap_reg_11__0_3bfc4ca [1] = recovered_12_q;
  wire recovered_12_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_12_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_12_q == (esc_axaddr_wrap_reg_11__2_82ad777 [1])))) recovered_12_q <= (esc_axaddr_wrap_reg_11__2_82ad777 [1]);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_2_ef2eafe
  reg recovered_13_q = 1'b0;
  assign esc_axaddr_wrap_reg_11__0_3bfc4ca [2] = recovered_13_q;
  wire recovered_13_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_13_q == (esc_axaddr_wrap_reg_11__2_82ad777 [2])))) recovered_13_q <= (esc_axaddr_wrap_reg_11__2_82ad777 [2]);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_3_f9d1eab
  reg recovered_14_q = 1'b0;
  assign esc_axaddr_wrap_reg_11__0_3bfc4ca [3] = recovered_14_q;
  wire recovered_14_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_14_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_14_q == (esc_axaddr_wrap_reg_11__2_82ad777 [3])))) recovered_14_q <= (esc_axaddr_wrap_reg_11__2_82ad777 [3]);
  end

  // Reconstructed CARRY4: esc_axaddr_wrap_reg_3__i_2__0_b4588e8
  wire [3:0] recovered_15_co, recovered_15_o, recovered_15_s, recovered_15_di;
  assign recovered_15_s = {S[1],esc_axaddr_wrap_3__i_4_n_0_bd97fb1 ,esc_axaddr_wrap_3__i_5_n_0_718b011 ,S[0]};
  assign recovered_15_di = esc_axaddr_wrap_reg_11__0_3bfc4ca [3:0];
  wire recovered_15_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_15_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_15_o[0] = recovered_15_s[0] ^ (recovered_15_ci || recovered_15_cy);
  assign recovered_15_co[0] = (recovered_15_s[0] & (recovered_15_ci || recovered_15_cy)) | (~recovered_15_s[0] & recovered_15_di[0]);
  assign recovered_15_o[1] = recovered_15_s[1] ^ recovered_15_co[0];
  assign recovered_15_co[1] = (recovered_15_s[1] & recovered_15_co[0]) | (~recovered_15_s[1] & recovered_15_di[1]);
  assign recovered_15_o[2] = recovered_15_s[2] ^ recovered_15_co[1];
  assign recovered_15_co[2] = (recovered_15_s[2] & recovered_15_co[1]) | (~recovered_15_s[2] & recovered_15_di[2]);
  assign recovered_15_o[3] = recovered_15_s[3] ^ recovered_15_co[2];
  assign recovered_15_co[3] = (recovered_15_s[3] & recovered_15_co[2]) | (~recovered_15_s[3] & recovered_15_di[3]);
  assign {esc_axaddr_wrap_reg_3__i_2__0_n_0_6ac5b39 ,esc_NLW_axaddr_wrap_reg_3__i_2__0_CO_UNCONNECTED_1f6f501 [2:0]} = recovered_15_co;
  assign O = recovered_15_o;

  // Reconstructed FDRE: esc_axaddr_wrap_reg_4_3609701
  reg recovered_16_q = 1'b0;
  assign esc_axaddr_wrap_reg_11__0_3bfc4ca [4] = recovered_16_q;
  wire recovered_16_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_16_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_16_q == (esc_axaddr_wrap_reg_11__2_82ad777 [4])))) recovered_16_q <= (esc_axaddr_wrap_reg_11__2_82ad777 [4]);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_5_e65c61e
  reg recovered_17_q = 1'b0;
  assign esc_axaddr_wrap_reg_11__0_3bfc4ca [5] = recovered_17_q;
  wire recovered_17_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_17_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_17_q == (esc_axaddr_wrap_reg_11__2_82ad777 [5])))) recovered_17_q <= (esc_axaddr_wrap_reg_11__2_82ad777 [5]);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_6_e11600c
  reg recovered_18_q = 1'b0;
  assign esc_axaddr_wrap_reg_11__0_3bfc4ca [6] = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_18_q == (esc_axaddr_wrap_reg_11__2_82ad777 [6])))) recovered_18_q <= (esc_axaddr_wrap_reg_11__2_82ad777 [6]);
  end

  // Reconstructed FDRE: esc_axaddr_wrap_reg_7_0468310
  reg recovered_19_q = 1'b0;
  assign esc_axaddr_wrap_reg_11__0_3bfc4ca [7] = recovered_19_q;
  wire recovered_19_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_19_q == (esc_axaddr_wrap_reg_11__2_82ad777 [7])))) recovered_19_q <= (esc_axaddr_wrap_reg_11__2_82ad777 [7]);
  end

  // Reconstructed CARRY4: esc_axaddr_wrap_reg_7__i_2__0_9114290
  wire [3:0] recovered_20_co, recovered_20_o, recovered_20_s, recovered_20_di;
  assign recovered_20_s = esc_axaddr_wrap_reg_11__0_3bfc4ca [7:4];
  assign recovered_20_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_20_ci = ((esc_axaddr_wrap_reg_3__i_2__0_n_0_6ac5b39) !== 1'bz) && (esc_axaddr_wrap_reg_3__i_2__0_n_0_6ac5b39);
  wire recovered_20_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_20_o[0] = recovered_20_s[0] ^ (recovered_20_ci || recovered_20_cy);
  assign recovered_20_co[0] = (recovered_20_s[0] & (recovered_20_ci || recovered_20_cy)) | (~recovered_20_s[0] & recovered_20_di[0]);
  assign recovered_20_o[1] = recovered_20_s[1] ^ recovered_20_co[0];
  assign recovered_20_co[1] = (recovered_20_s[1] & recovered_20_co[0]) | (~recovered_20_s[1] & recovered_20_di[1]);
  assign recovered_20_o[2] = recovered_20_s[2] ^ recovered_20_co[1];
  assign recovered_20_co[2] = (recovered_20_s[2] & recovered_20_co[1]) | (~recovered_20_s[2] & recovered_20_di[2]);
  assign recovered_20_o[3] = recovered_20_s[3] ^ recovered_20_co[2];
  assign recovered_20_co[3] = (recovered_20_s[3] & recovered_20_co[2]) | (~recovered_20_s[3] & recovered_20_di[3]);
  assign esc_axaddr_wrap_reg_7__0_317aa52 = recovered_20_o;

  // Reconstructed LUT5: esc_axlen_cnt_0__i_1__2_8b05720
  assign esc_axlen_cnt_0__i_1__2_n_0_ac33be6 = ((esc_axlen_cnt_3__i_2__0_n_0_cd0db03) ? (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (((esc_axlen_cnt_reg_3__0_a623c36 [9]) ? (((si_rs_arvalid) ? (~(Q)) : (1'b0))) : (1'b0))) : (1'b1))) : (((esc_axlen_cnt_reg_3__0_a623c36 [9]) ? (((si_rs_arvalid) ? (~(Q)) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_axlen_cnt_1__i_1__1_66827ba
  assign esc_axlen_cnt_1__i_1__1_n_0_1fb243f = ((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (((esc_axlen_cnt_3__i_2__0_n_0_cd0db03) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [10]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [10]) : (1'b0))))) : (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [10]) : (1'b0))) : (((esc_axlen_cnt_3__i_2__0_n_0_cd0db03) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [10]) : (1'b0))))))));

  // Reconstructed LUT6: esc_axlen_cnt_2__i_1__1_1c17f63
  assign esc_axlen_cnt_2__i_1__1_n_0_eb3799f = ((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (((esc_axlen_cnt_3__i_2__0_n_0_cd0db03) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [11]) : (1'b0))))) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (((esc_axlen_cnt_3__i_2__0_n_0_cd0db03) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [11]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [11]) : (1'b0))))))) : (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [11]) : (1'b0))) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [11]) : (1'b0))) : (((esc_axlen_cnt_3__i_2__0_n_0_cd0db03) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [11]) : (1'b0))))))))));

  // Reconstructed LUT5: esc_axlen_cnt_3__i_1__1_77027a7
  assign esc_axlen_cnt_3__i_1__1_n_0_0b7fa2b = ((esc_axlen_cnt_reg_n_0__3_8857ffe) ? (((esc_axlen_cnt_3__i_3__0_n_0_e168a7c) ? (((esc_axlen_cnt_3__i_2__0_n_0_cd0db03) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [12]) : (1'b0))))) : (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [12]) : (1'b0))))) : (((esc_axlen_cnt_3__i_3__0_n_0_e168a7c) ? (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [12]) : (1'b0))) : (((esc_axlen_cnt_3__i_2__0_n_0_cd0db03) ? (1'b1) : (((E) ? (esc_axlen_cnt_reg_3__0_a623c36 [12]) : (1'b0))))))));

  // Reconstructed LUT5: esc_axlen_cnt_3__i_2__0_b63b8af
  assign esc_axlen_cnt_3__i_2__0_n_0_cd0db03 = ((E) ? (1'b0) : (((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__4_f78fcda) ? (1'b1) : (esc_axlen_cnt_reg_n_0__3_8857ffe))))))));

  // Reconstructed LUT3: esc_axlen_cnt_3__i_3__0_58d633f
  assign esc_axlen_cnt_3__i_3__0_n_0_e168a7c = ((esc_axlen_cnt_reg_n_0__2_a2d60e4) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (1'b1) : (esc_axlen_cnt_reg_n_0__1_db9fc63))));

  // Reconstructed LUT6: esc_axlen_cnt_4__i_1__1_debdcee
  assign esc_axlen_cnt_4__i_1__1_n_0_ec07f7b = ((esc_axlen_cnt_reg_n_0__4_f78fcda) ? (((E) ? (1'b0) : (((esc_axlen_cnt_reg_n_0__3_8857ffe) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__1_db9fc63) ? (1'b1) : (((esc_axlen_cnt_reg_n_0__0_6b9adfb) ? (1'b1) : (esc_axlen_cnt_reg_n_0__2_a2d60e4))))))))) : (1'b0));

  // Reconstructed FDRE: esc_axlen_cnt_reg_0_56abf15
  reg recovered_28_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__0_6b9adfb = recovered_28_q;
  wire recovered_28_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_28_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_28_q == (esc_axlen_cnt_0__i_1__2_n_0_ac33be6)))) recovered_28_q <= (esc_axlen_cnt_0__i_1__2_n_0_ac33be6);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_1_405fc67
  reg recovered_29_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__1_db9fc63 = recovered_29_q;
  wire recovered_29_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_29_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_29_q == (esc_axlen_cnt_1__i_1__1_n_0_1fb243f)))) recovered_29_q <= (esc_axlen_cnt_1__i_1__1_n_0_1fb243f);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_2_379d3d4
  reg recovered_30_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__2_a2d60e4 = recovered_30_q;
  wire recovered_30_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_30_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_30_q == (esc_axlen_cnt_2__i_1__1_n_0_eb3799f)))) recovered_30_q <= (esc_axlen_cnt_2__i_1__1_n_0_eb3799f);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_3_46333b8
  reg recovered_31_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__3_8857ffe = recovered_31_q;
  wire recovered_31_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_31_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_31_q == (esc_axlen_cnt_3__i_1__1_n_0_0b7fa2b)))) recovered_31_q <= (esc_axlen_cnt_3__i_1__1_n_0_0b7fa2b);
  end

  // Reconstructed FDRE: esc_axlen_cnt_reg_4_3087e61
  reg recovered_32_q = 1'b0;
  assign esc_axlen_cnt_reg_n_0__4_f78fcda = recovered_32_q;
  wire recovered_32_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_32_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_32_q == 1'b0))) recovered_32_q <= 1'b0;
    else if ((esc_axaddr_wrap_reg_0__0_8ebf4f6) || ((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bz) || (((esc_axaddr_wrap_reg_0__0_8ebf4f6) === 1'bx) && (recovered_32_q == (esc_axlen_cnt_4__i_1__1_n_0_ec07f7b)))) recovered_32_q <= (esc_axlen_cnt_4__i_1__1_n_0_ec07f7b);
  end

  // Reconstructed LUT4: esc_m_axi_araddr_11__INST_0_i_3_dbce229
  assign sel_first_reg_1 = ((esc_axlen_cnt_reg_3__0_a623c36 [7]) ? (((esc_m_axi_araddr_11_4618f72) ? (((esc_axlen_cnt_reg_3__0_a623c36 [8]) ? (sel_first_reg_0) : (1'b1))) : (((esc_axlen_cnt_reg_3__0_a623c36 [8]) ? (sel_first_reg_0) : (1'b0))))) : (((esc_axlen_cnt_reg_3__0_a623c36 [8]) ? (sel_first_reg_0) : (1'b1))));

  // Reconstructed LUT5: next_pending_r_i_1__1
  assign wrap_next_pending = ((next_pending_r_reg_0) ? (1'b1) : (((E) ? (((r_push) ? (esc_axlen_cnt_3__i_2__0_n_0_cd0db03) : (1'b0))) : (((next_pending_r) ? (((r_push) ? (esc_axlen_cnt_3__i_2__0_n_0_cd0db03) : (1'b1))) : (((r_push) ? (esc_axlen_cnt_3__i_2__0_n_0_cd0db03) : (1'b0))))))));

  // Reconstructed FDRE: next_pending_r_reg
  reg recovered_35_q = 1'b0;
  assign next_pending_r = recovered_35_q;
  wire recovered_35_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_35_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_35_q == 1'b0))) recovered_35_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_35_q == (wrap_next_pending)))) recovered_35_q <= (wrap_next_pending);
  end

  // Reconstructed LUT4: s_axburst_eq1_i_1__0
  assign esc_m_payload_i_reg_39_ea68878 = ((s_axburst_eq1_reg) ? (((sel_first_i) ? (wrap_next_pending) : (((esc_axlen_cnt_reg_3__0_a623c36 [8]) ? (wrap_next_pending) : (1'b1))))) : (((sel_first_i) ? (wrap_next_pending) : (((esc_axlen_cnt_reg_3__0_a623c36 [8]) ? (wrap_next_pending) : (1'b0))))));

  // Reconstructed FDRE: sel_first_reg
  reg recovered_37_q = 1'b0;
  assign sel_first_reg_0 = recovered_37_q;
  wire recovered_37_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_37_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_37_q == 1'b0))) recovered_37_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_37_q == (sel_first_reg_2)))) recovered_37_q <= (sel_first_reg_2);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_0_9761f59
  reg recovered_38_q = 1'b0;
  assign esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 [0] = recovered_38_q;
  wire recovered_38_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_38_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_38_q == 1'b0))) recovered_38_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_38_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [0])))) recovered_38_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [0]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_1_5a2ef29
  reg recovered_39_q = 1'b0;
  assign esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 [1] = recovered_39_q;
  wire recovered_39_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_39_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_39_q == 1'b0))) recovered_39_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_39_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [1])))) recovered_39_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [1]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_2_f6bab03
  reg recovered_40_q = 1'b0;
  assign esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 [2] = recovered_40_q;
  wire recovered_40_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_40_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_40_q == 1'b0))) recovered_40_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_40_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [2])))) recovered_40_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [2]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_3_f49857a
  reg recovered_41_q = 1'b0;
  assign esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 [3] = recovered_41_q;
  wire recovered_41_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_41_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_41_q == 1'b0))) recovered_41_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_41_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [3])))) recovered_41_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [3]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_4_c6a7357
  reg recovered_42_q = 1'b0;
  assign esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 [4] = recovered_42_q;
  wire recovered_42_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_42_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_42_q == 1'b0))) recovered_42_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_42_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [4])))) recovered_42_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [4]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_5_e137ab2
  reg recovered_43_q = 1'b0;
  assign esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 [5] = recovered_43_q;
  wire recovered_43_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_43_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_43_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [5])))) recovered_43_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [5]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_6_a91079e
  reg recovered_44_q = 1'b0;
  assign esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 [6] = recovered_44_q;
  wire recovered_44_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_44_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_44_q == (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [6])))) recovered_44_q <= (esc_wrap_boundary_axaddr_r_reg_6__0_a597ac3 [6]);
  end

  // Reconstructed FDRE: esc_wrap_boundary_axaddr_r_reg_7_6e4e160
  reg recovered_45_q = 1'b0;
  assign esc_wrap_boundary_axaddr_r_reg_11__0_a0a4297 [7] = recovered_45_q;
  wire recovered_45_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_45_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_45_q == 1'b0))) recovered_45_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_45_q == (esc_axlen_cnt_reg_3__0_a623c36 [0])))) recovered_45_q <= (esc_axlen_cnt_reg_3__0_a623c36 [0]);
  end

  // Reconstructed LUT5: esc_wrap_cnt_r_1__i_1__0_c3b1e04
  assign esc_wrap_cnt_r_1__i_1__0_n_0_d9bd43a = ((esc_wrap_second_len_r_reg_3__0_61735c7 [1]) ? (((E) ? (((esc_wrap_cnt_r_reg_1__0_205e7f9) ? (axaddr_offset[1]) : (1'b0))) : (((esc_wrap_cnt_r_reg_1__0_205e7f9) ? (~(esc_wrap_second_len_r_reg_3__0_61735c7 [0])) : (1'b1))))) : (((E) ? (((esc_wrap_cnt_r_reg_1__0_205e7f9) ? (axaddr_offset[1]) : (1'b0))) : (((esc_wrap_cnt_r_reg_1__0_205e7f9) ? (esc_wrap_second_len_r_reg_3__0_61735c7 [0]) : (1'b0))))));

  // Reconstructed FDRE: esc_wrap_cnt_r_reg_0_9ce1d67
  reg recovered_47_q = 1'b0;
  assign esc_wrap_cnt_r_reg_n_0__0_0ce605c = recovered_47_q;
  wire recovered_47_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_47_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_47_q == 1'b0))) recovered_47_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_47_q == (esc_wrap_cnt_r_reg_3__0_82edd32 [0])))) recovered_47_q <= (esc_wrap_cnt_r_reg_3__0_82edd32 [0]);
  end

  // Reconstructed FDRE: esc_wrap_cnt_r_reg_1_4617ef8
  reg recovered_48_q = 1'b0;
  assign esc_wrap_cnt_r_reg_n_0__1_b7d6f34 = recovered_48_q;
  wire recovered_48_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_48_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_48_q == 1'b0))) recovered_48_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_48_q == (esc_wrap_cnt_r_1__i_1__0_n_0_d9bd43a)))) recovered_48_q <= (esc_wrap_cnt_r_1__i_1__0_n_0_d9bd43a);
  end

  // Reconstructed FDRE: esc_wrap_cnt_r_reg_2_6dcb155
  reg recovered_49_q = 1'b0;
  assign esc_wrap_cnt_r_reg_n_0__2_1531d71 = recovered_49_q;
  wire recovered_49_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_49_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_49_q == 1'b0))) recovered_49_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_49_q == (esc_wrap_cnt_r_reg_3__0_82edd32 [1])))) recovered_49_q <= (esc_wrap_cnt_r_reg_3__0_82edd32 [1]);
  end

  // Reconstructed FDRE: esc_wrap_cnt_r_reg_3_8701380
  reg recovered_50_q = 1'b0;
  assign esc_wrap_cnt_r_reg_n_0__3_a1075d2 = recovered_50_q;
  wire recovered_50_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_50_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_50_q == 1'b0))) recovered_50_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_50_q == (esc_wrap_cnt_r_reg_3__0_82edd32 [2])))) recovered_50_q <= (esc_wrap_cnt_r_reg_3__0_82edd32 [2]);
  end

  // Reconstructed FDRE: esc_wrap_second_len_r_reg_0_933d6c0
  reg recovered_51_q = 1'b0;
  assign esc_wrap_second_len_r_reg_3__0_61735c7 [0] = recovered_51_q;
  wire recovered_51_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_51_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_51_q == 1'b0))) recovered_51_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_51_q == (D[0])))) recovered_51_q <= (D[0]);
  end

  // Reconstructed FDRE: esc_wrap_second_len_r_reg_1_dd27002
  reg recovered_52_q = 1'b0;
  assign esc_wrap_second_len_r_reg_3__0_61735c7 [1] = recovered_52_q;
  wire recovered_52_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_52_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_52_q == 1'b0))) recovered_52_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_52_q == (D[1])))) recovered_52_q <= (D[1]);
  end

  // Reconstructed FDRE: esc_wrap_second_len_r_reg_2_01b34aa
  reg recovered_53_q = 1'b0;
  assign esc_wrap_second_len_r_reg_3__0_61735c7 [2] = recovered_53_q;
  wire recovered_53_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_53_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_53_q == 1'b0))) recovered_53_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_53_q == (D[2])))) recovered_53_q <= (D[2]);
  end

  // Reconstructed FDRE: esc_wrap_second_len_r_reg_3_130d984
  reg recovered_54_q = 1'b0;
  assign esc_wrap_second_len_r_reg_3__0_61735c7 [3] = recovered_54_q;
  wire recovered_54_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_54_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_54_q == 1'b0))) recovered_54_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_54_q == (D[3])))) recovered_54_q <= (D[3]);
  end

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_register_slice_v2_1_22_axi_register_slice
   (s_ready_i_reg,
    s_ready_i_reg_0,
    si_rs_awvalid,
    m_valid_i_reg,
    si_rs_bready,
    si_rs_arvalid,
    m_valid_i_reg_0,
    si_rs_rready,
    S,
    esc_m_payload_i_reg_64_2ba99a2 ,
    esc_axaddr_wrap_reg_3_f9d1eab ,
    esc_axaddr_incr_reg_3_2fa58c8 ,
    esc_m_payload_i_reg_64__0_7cd5a09 ,
    esc_axaddr_wrap_reg_3__0_a824587 ,
    axaddr_incr,
    esc_m_payload_i_reg_3_3eab624 ,
    esc_m_payload_i_reg_7_ba4380d ,
    O,
    esc_m_payload_i_reg_47_8c317be ,
    D,
    esc_wrap_second_len_r_reg_3_130d984 ,
    esc_m_payload_i_reg_44_7279c72 ,
    axaddr_offset,
    shandshake,
    incr_next_pending,
    esc_m_payload_i_reg_47__0_fbbb04b ,
    esc_m_payload_i_reg_49_7738e67 ,
    esc_wrap_second_len_r_reg_2_01b34aa ,
    esc_wrap_second_len_r_reg_3__0_61735c7 ,
    esc_m_payload_i_reg_44__0_3e7cb03 ,
    axaddr_offset_0,
    esc_m_payload_i_reg_47__1_6188148 ,
    esc_m_payload_i_reg_47__2_d1e0165 ,
    m_axi_awaddr,
    m_axi_araddr,
    esc_m_payload_i_reg_13_5fdb661 ,
    esc_m_payload_i_reg_46_022e045 ,
    aclk,
    s_ready_i0,
    m_valid_i_reg_1,
    aresetn,
    s_axi_bready,
    si_rs_bvalid,
    Q,
    esc_m_axi_awaddr_11_2270491 ,
    esc_m_axi_araddr_11_4618f72 ,
    esc_m_axi_araddr_11__0_a45329d ,
    b_push,
    s_axi_awvalid,
    esc_axaddr_incr_reg_3__0_6132b06 ,
    esc_axaddr_incr_reg_3__1_c45cd30 ,
    esc_wrap_second_len_r_reg_2__0_7d5dd64 ,
    esc_wrap_second_len_r_reg_3__1_e9d1a95 ,
    esc_axaddr_offset_r_reg_0_a3138f8 ,
    esc_axaddr_offset_r_reg_3_9b4a3fc ,
    next_pending_r_reg,
    esc_wrap_second_len_r_reg_3__2_20f8099 ,
    esc_axaddr_offset_r_reg_3__0_89647ed ,
    m_valid_i_reg_2,
    s_axi_rready,
    esc_wrap_second_len_r_reg_3__3_a7b0a59 ,
    esc_axaddr_offset_r_reg_3__1_174c336 ,
    s_axi_awid,
    s_axi_awlen,
    s_axi_awburst,
    s_axi_awsize,
    s_axi_awprot,
    s_axi_awaddr,
    esc_m_axi_awaddr_11__0_1b007f9 ,
    sel_first_1,
    sel_first,
    s_axi_arid,
    s_axi_arlen,
    s_axi_arburst,
    s_axi_arsize,
    s_axi_arprot,
    s_axi_araddr,
    esc_m_axi_araddr_11__1_69dc7e5 ,
    sel_first_2,
    esc_m_axi_araddr_11__2_89d9808 ,
    out,
    esc_skid_buffer_reg_1_56ed2e4 ,
    esc_skid_buffer_reg_46_665ac24 ,
    esc_skid_buffer_reg_33_39a8494 ,
    E,
    esc_m_payload_i_reg_0_2f8d71c );
  output s_ready_i_reg;
  output s_ready_i_reg_0;
  output si_rs_awvalid;
  output m_valid_i_reg;
  output si_rs_bready;
  output si_rs_arvalid;
  output m_valid_i_reg_0;
  output si_rs_rready;
  output [1:0]S;
  output [58:0]esc_m_payload_i_reg_64_2ba99a2 ;
  output [1:0]esc_axaddr_wrap_reg_3_f9d1eab ;
  output [1:0]esc_axaddr_incr_reg_3_2fa58c8 ;
  output [58:0]esc_m_payload_i_reg_64__0_7cd5a09 ;
  output [1:0]esc_axaddr_wrap_reg_3__0_a824587 ;
  output [11:0]axaddr_incr;
  output [3:0]esc_m_payload_i_reg_3_3eab624 ;
  output [3:0]esc_m_payload_i_reg_7_ba4380d ;
  output [3:0]O;
  output esc_m_payload_i_reg_47_8c317be ;
  output [1:0]D;
  output [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  output esc_m_payload_i_reg_44_7279c72 ;
  output [3:0]axaddr_offset;
  output shandshake;
  output incr_next_pending;
  output esc_m_payload_i_reg_47__0_fbbb04b ;
  output esc_m_payload_i_reg_49_7738e67 ;
  output [1:0]esc_wrap_second_len_r_reg_2_01b34aa ;
  output [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  output esc_m_payload_i_reg_44__0_3e7cb03 ;
  output [3:0]axaddr_offset_0;
  output [6:0]esc_m_payload_i_reg_47__1_6188148 ;
  output [6:0]esc_m_payload_i_reg_47__2_d1e0165 ;
  output [11:0]m_axi_awaddr;
  output [11:0]m_axi_araddr;
  output [13:0]esc_m_payload_i_reg_13_5fdb661 ;
  output [46:0]esc_m_payload_i_reg_46_022e045 ;
  input aclk;
  input s_ready_i0;
  input m_valid_i_reg_1;
  input aresetn;
  input s_axi_bready;
  input si_rs_bvalid;
  input [11:0]Q;
  input [11:0]esc_m_axi_awaddr_11_2270491 ;
  input [11:0]esc_m_axi_araddr_11_4618f72 ;
  input [11:0]esc_m_axi_araddr_11__0_a45329d ;
  input b_push;
  input s_axi_awvalid;
  input [3:0]esc_axaddr_incr_reg_3__0_6132b06 ;
  input [3:0]esc_axaddr_incr_reg_3__1_c45cd30 ;
  input esc_wrap_second_len_r_reg_2__0_7d5dd64 ;
  input [3:0]esc_wrap_second_len_r_reg_3__1_e9d1a95 ;
  input [1:0]esc_axaddr_offset_r_reg_0_a3138f8 ;
  input [3:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  input next_pending_r_reg;
  input esc_wrap_second_len_r_reg_3__2_20f8099 ;
  input [1:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  input m_valid_i_reg_2;
  input s_axi_rready;
  input [3:0]esc_wrap_second_len_r_reg_3__3_a7b0a59 ;
  input [3:0]esc_axaddr_offset_r_reg_3__1_174c336 ;
  input [11:0]s_axi_awid;
  input [7:0]s_axi_awlen;
  input [1:0]s_axi_awburst;
  input [1:0]s_axi_awsize;
  input [2:0]s_axi_awprot;
  input [31:0]s_axi_awaddr;
  input esc_m_axi_awaddr_11__0_1b007f9 ;
  input sel_first_1;
  input sel_first;
  input [11:0]s_axi_arid;
  input [7:0]s_axi_arlen;
  input [1:0]s_axi_arburst;
  input [1:0]s_axi_arsize;
  input [2:0]s_axi_arprot;
  input [31:0]s_axi_araddr;
  input esc_m_axi_araddr_11__1_69dc7e5 ;
  input sel_first_2;
  input esc_m_axi_araddr_11__2_89d9808 ;
  input [11:0]out;
  input [1:0]esc_skid_buffer_reg_1_56ed2e4 ;
  input [12:0]esc_skid_buffer_reg_46_665ac24 ;
  input [33:0]esc_skid_buffer_reg_33_39a8494 ;
  input [0:0]E;
  input [0:0]esc_m_payload_i_reg_0_2f8d71c ;

  wire [1:0]D;
  wire [0:0]E;
  wire [11:0]Q;
  wire [1:0]S;
  wire aclk;
  wire esc_ar_ar_pipe_n_2_642796f ;
  wire aresetn;
  wire esc_aw_aw_pipe_n_1_8857a0b ;
  wire esc_aw_aw_pipe_n_109_8803245 ;
  wire [11:0]axaddr_incr;
  wire [1:0]esc_axaddr_incr_reg_3_2fa58c8 ;
  wire [3:0]esc_axaddr_incr_reg_3__0_6132b06 ;
  wire [3:0]esc_axaddr_incr_reg_3__1_c45cd30 ;
  wire [3:0]axaddr_offset;
  wire [3:0]axaddr_offset_0;
  wire [1:0]esc_axaddr_offset_r_reg_0_a3138f8 ;
  wire [3:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  wire [1:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  wire [3:0]esc_axaddr_offset_r_reg_3__1_174c336 ;
  wire [1:0]esc_axaddr_wrap_reg_3_f9d1eab ;
  wire [1:0]esc_axaddr_wrap_reg_3__0_a824587 ;
  wire b_push;
  wire incr_next_pending;
  wire [11:0]m_axi_araddr;
  wire [11:0]esc_m_axi_araddr_11_4618f72 ;
  wire [11:0]esc_m_axi_araddr_11__0_a45329d ;
  wire esc_m_axi_araddr_11__1_69dc7e5 ;
  wire esc_m_axi_araddr_11__2_89d9808 ;
  wire [11:0]m_axi_awaddr;
  wire [11:0]esc_m_axi_awaddr_11_2270491 ;
  wire esc_m_axi_awaddr_11__0_1b007f9 ;
  wire [0:0]esc_m_payload_i_reg_0_2f8d71c ;
  wire [13:0]esc_m_payload_i_reg_13_5fdb661 ;
  wire [3:0]esc_m_payload_i_reg_3_3eab624 ;
  wire esc_m_payload_i_reg_44_7279c72 ;
  wire esc_m_payload_i_reg_44__0_3e7cb03 ;
  wire [46:0]esc_m_payload_i_reg_46_022e045 ;
  wire esc_m_payload_i_reg_47_8c317be ;
  wire esc_m_payload_i_reg_47__0_fbbb04b ;
  wire [6:0]esc_m_payload_i_reg_47__1_6188148 ;
  wire [6:0]esc_m_payload_i_reg_47__2_d1e0165 ;
  wire [58:0]esc_m_payload_i_reg_64_2ba99a2 ;
  wire [58:0]esc_m_payload_i_reg_64__0_7cd5a09 ;
  wire [3:0]esc_m_payload_i_reg_7_ba4380d ;
  wire m_valid_i_reg;
  wire m_valid_i_reg_0;
  wire m_valid_i_reg_1;
  wire m_valid_i_reg_2;
  wire next_pending_r_reg;
  wire [11:0]out;
  wire [31:0]s_axi_araddr;
  wire [1:0]s_axi_arburst;
  wire [11:0]s_axi_arid;
  wire [7:0]s_axi_arlen;
  wire [1:0]s_axi_arsize;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [11:0]s_axi_awid;
  wire [7:0]s_axi_awlen;
  wire [1:0]s_axi_awsize;
  wire s_axi_awvalid;
  wire s_axi_bready;
  wire s_axi_rready;
  wire s_ready_i0;
  wire s_ready_i_reg;
  wire s_ready_i_reg_0;
  wire sel_first;
  wire sel_first_1;
  wire sel_first_2;
  wire shandshake;
  wire si_rs_arvalid;
  wire si_rs_awvalid;
  wire si_rs_bready;
  wire si_rs_bvalid;
  wire si_rs_rready;
  wire [1:0]esc_skid_buffer_reg_1_56ed2e4 ;
  wire [33:0]esc_skid_buffer_reg_33_39a8494 ;
  wire [12:0]esc_skid_buffer_reg_46_665ac24 ;
  wire [1:0]esc_wrap_second_len_r_reg_2_01b34aa ;
  wire esc_wrap_second_len_r_reg_2__0_7d5dd64 ;
  wire [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  wire [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  wire [3:0]esc_wrap_second_len_r_reg_3__1_e9d1a95 ;
  wire esc_wrap_second_len_r_reg_3__2_20f8099 ;
  wire [3:0]esc_wrap_second_len_r_reg_3__3_a7b0a59 ;
  wire [58:0]esc_NLW_ar_ar_pipe_Q_UNCONNECTED_3cabb6b ;
  wire [58:0]esc_NLW_aw_aw_pipe_m_payload_i_reg_64__0_UNCONNECTED_6cbdc07 ;
  wire [46:0]esc_NLW_r_r_pipe_m_payload_i_reg_46__0_UNCONNECTED_0f6fd07 ;

  system_auto_pc_0_axi_register_slice_v2_1_22_axic_register_slice esc_ar_ar_pipe_5a3db50 
       (.esc_FSM_sequential_state_reg_1_aa5780a (axaddr_offset_0[1]),
        .esc_FSM_sequential_state_reg_1__0_5c93d31 (axaddr_offset_0[2]),
        .Q({esc_m_payload_i_reg_64__0_7cd5a09 [58:47],esc_NLW_ar_ar_pipe_Q_UNCONNECTED_3cabb6b [46:43],esc_m_payload_i_reg_64__0_7cd5a09 [42:35],esc_NLW_ar_ar_pipe_Q_UNCONNECTED_3cabb6b [34:8],esc_m_payload_i_reg_64__0_7cd5a09 [7:0]}),
        .aclk(aclk),
        .esc_aresetn_d_reg_1__inv_0_a6031eb (esc_ar_ar_pipe_n_2_642796f ),
        .esc_aresetn_d_reg_1__inv_1_8c340ab (esc_aw_aw_pipe_n_109_8803245 ),
        .esc_axaddr_incr_reg_3_2fa58c8 (esc_axaddr_incr_reg_3_2fa58c8 ),
        .esc_axaddr_incr_reg_3__0_6132b06 (esc_axaddr_incr_reg_3__1_c45cd30 ),
        .esc_axaddr_offset_r_reg_3_9b4a3fc (esc_axaddr_offset_r_reg_3__0_89647ed ),
        .esc_axaddr_offset_r_reg_3__0_89647ed (esc_axaddr_offset_r_reg_3__1_174c336 ),
        .esc_axaddr_wrap_reg_3_f9d1eab (esc_axaddr_wrap_reg_3__0_a824587 ),
        .incr_next_pending(incr_next_pending),
        .m_axi_araddr(m_axi_araddr[5:0]),
        .esc_m_axi_araddr_11_4618f72 (esc_m_axi_araddr_11_4618f72 [5:0]),
        .esc_m_axi_araddr_11__0_a45329d (esc_m_axi_araddr_11__0_a45329d [5:0]),
        .esc_m_axi_araddr_11__1_69dc7e5 (esc_m_axi_araddr_11__1_69dc7e5 ),
        .esc_m_axi_araddr_11__2_89d9808 (esc_m_axi_araddr_11__2_89d9808 ),
        .esc_m_payload_i_reg_0__0_0129b79 (esc_m_payload_i_reg_0_2f8d71c ),
        .esc_m_payload_i_reg_3__0_fc3b1db (esc_m_payload_i_reg_3_3eab624 ),
        .esc_m_payload_i_reg_44__0_3e7cb03 (esc_m_payload_i_reg_44__0_3e7cb03 ),
        .esc_m_payload_i_reg_44__1_a8cd662 (axaddr_offset_0[0]),
        .esc_m_payload_i_reg_47__0_fbbb04b (esc_m_payload_i_reg_47__0_fbbb04b ),
        .esc_m_payload_i_reg_47__1_6188148 (axaddr_offset_0[3]),
        .esc_m_payload_i_reg_47__2_d1e0165 (esc_m_payload_i_reg_47__2_d1e0165 ),
        .esc_m_payload_i_reg_7__0_d32552f (esc_m_payload_i_reg_7_ba4380d ),
        .m_valid_i_reg_0(si_rs_arvalid),
        .m_valid_i_reg_1(m_valid_i_reg_1),
        .next_pending_r_reg(next_pending_r_reg),
        .s_axi_araddr(s_axi_araddr[7:0]),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_arid(s_axi_arid),
        .s_axi_arlen(s_axi_arlen[3:0]),
        .s_axi_arsize(s_axi_arsize),
        .s_ready_i0(s_ready_i0),
        .s_ready_i_reg_0(s_ready_i_reg_0),
        .s_ready_i_reg_1(esc_aw_aw_pipe_n_1_8857a0b ),
        .sel_first_2(sel_first_2),
        .esc_wrap_second_len_r_reg_2_01b34aa (esc_wrap_second_len_r_reg_2_01b34aa ),
        .esc_wrap_second_len_r_reg_3_130d984 (esc_wrap_second_len_r_reg_3__0_61735c7 ),
        .esc_wrap_second_len_r_reg_3__0_61735c7 (esc_wrap_second_len_r_reg_3__2_20f8099 ),
        .esc_wrap_second_len_r_reg_3__1_e9d1a95 (esc_wrap_second_len_r_reg_3__3_a7b0a59 ));
  system_auto_pc_0_axi_register_slice_v2_1_22_axic_register_slice_0 esc_aw_aw_pipe_07310ac 
       (.D(D),
        .E(E),
        .esc_FSM_sequential_state_reg_1_aa5780a (axaddr_offset[1]),
        .esc_FSM_sequential_state_reg_1__0_5c93d31 (axaddr_offset[2]),
        .Q(Q[5:0]),
        .S(S),
        .aclk(aclk),
        .aresetn(aresetn),
        .esc_aresetn_d_reg_0__0_7ec703c (esc_aw_aw_pipe_n_1_8857a0b ),
        .esc_aresetn_d_reg_0__1_e5ad447 (esc_aw_aw_pipe_n_109_8803245 ),
        .axaddr_incr(axaddr_incr[7:0]),
        .esc_axaddr_incr_reg_3_2fa58c8 (esc_axaddr_incr_reg_3__0_6132b06 ),
        .esc_axaddr_offset_r_reg_0_a3138f8 (esc_axaddr_offset_r_reg_0_a3138f8 ),
        .esc_axaddr_offset_r_reg_3_9b4a3fc (esc_axaddr_offset_r_reg_3_9b4a3fc ),
        .esc_axaddr_wrap_reg_3_f9d1eab (esc_axaddr_wrap_reg_3_f9d1eab ),
        .b_push(b_push),
        .m_axi_awaddr(m_axi_awaddr[5:0]),
        .esc_m_axi_awaddr_11_2270491 (esc_m_axi_awaddr_11_2270491 [5:0]),
        .esc_m_axi_awaddr_11__0_1b007f9 (esc_m_axi_awaddr_11__0_1b007f9 ),
        .esc_m_payload_i_reg_44__0_3e7cb03 (esc_m_payload_i_reg_44_7279c72 ),
        .esc_m_payload_i_reg_44__1_a8cd662 (axaddr_offset[0]),
        .esc_m_payload_i_reg_47__0_fbbb04b (esc_m_payload_i_reg_47_8c317be ),
        .esc_m_payload_i_reg_47__1_6188148 (axaddr_offset[3]),
        .esc_m_payload_i_reg_47__2_d1e0165 (esc_m_payload_i_reg_47__1_6188148 ),
        .esc_m_payload_i_reg_64__0_7cd5a09 ({esc_m_payload_i_reg_64_2ba99a2 [58:47],esc_NLW_aw_aw_pipe_m_payload_i_reg_64__0_UNCONNECTED_6cbdc07 [46:43],esc_m_payload_i_reg_64_2ba99a2 [42:35],esc_NLW_aw_aw_pipe_m_payload_i_reg_64__0_UNCONNECTED_6cbdc07 [34:8],esc_m_payload_i_reg_64_2ba99a2 [7:0]}),
        .m_valid_i_reg_0(si_rs_awvalid),
        .m_valid_i_reg_1(esc_ar_ar_pipe_n_2_642796f ),
        .s_axi_awaddr(s_axi_awaddr[7:0]),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awid(s_axi_awid),
        .s_axi_awlen(s_axi_awlen[3:0]),
        .s_axi_awsize(s_axi_awsize),
        .s_axi_awvalid(s_axi_awvalid),
        .s_ready_i_reg_0(s_ready_i_reg),
        .sel_first(sel_first),
        .sel_first_1(sel_first_1),
        .esc_wrap_second_len_r_reg_2_01b34aa (esc_wrap_second_len_r_reg_2__0_7d5dd64 ),
        .esc_wrap_second_len_r_reg_3_130d984 (esc_wrap_second_len_r_reg_3_130d984 ),
        .esc_wrap_second_len_r_reg_3__0_61735c7 (esc_wrap_second_len_r_reg_3__1_e9d1a95 ));
  system_auto_pc_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized1 esc_b_b_pipe_f512acc 
       (.aclk(aclk),
        .esc_m_payload_i_reg_13__0_806bc71 (esc_m_payload_i_reg_13_5fdb661 ),
        .m_valid_i_reg_0(m_valid_i_reg),
        .m_valid_i_reg_1(esc_ar_ar_pipe_n_2_642796f ),
        .out(out),
        .s_axi_bready(s_axi_bready),
        .s_ready_i_reg_0(si_rs_bready),
        .s_ready_i_reg_1(esc_aw_aw_pipe_n_1_8857a0b ),
        .shandshake(shandshake),
        .si_rs_bvalid(si_rs_bvalid),
        .esc_skid_buffer_reg_1__0_c42767f (esc_skid_buffer_reg_1_56ed2e4 ));
  system_auto_pc_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized2 esc_r_r_pipe_b1606f9 
       (.aclk(aclk),
        .esc_m_payload_i_reg_46__0_de80657 ({esc_m_payload_i_reg_46_022e045 [46:34],esc_NLW_r_r_pipe_m_payload_i_reg_46__0_UNCONNECTED_0f6fd07 [33:32],esc_m_payload_i_reg_46_022e045 [31:0]}),
        .m_valid_i_reg_0(m_valid_i_reg_0),
        .m_valid_i_reg_1(esc_ar_ar_pipe_n_2_642796f ),
        .m_valid_i_reg_2(m_valid_i_reg_2),
        .s_axi_rready(s_axi_rready),
        .s_ready_i_reg_0(si_rs_rready),
        .s_ready_i_reg_1(esc_aw_aw_pipe_n_1_8857a0b ),
        .esc_skid_buffer_reg_33__0_d09158b (esc_skid_buffer_reg_33_39a8494 [31:0]),
        .esc_skid_buffer_reg_46__0_5d60302 (esc_skid_buffer_reg_46_665ac24 ));
endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_register_slice_v2_1_22_axic_register_slice
   (s_ready_i_reg_0,
    m_valid_i_reg_0,
    esc_aresetn_d_reg_1__inv_0_a6031eb ,
    esc_axaddr_incr_reg_3_2fa58c8 ,
    Q,
    esc_axaddr_wrap_reg_3_f9d1eab ,
    esc_m_payload_i_reg_3__0_fc3b1db ,
    esc_m_payload_i_reg_7__0_d32552f ,
    O,
    incr_next_pending,
    esc_m_payload_i_reg_47__0_fbbb04b ,
    esc_m_payload_i_reg_49__0_f216c9f ,
    esc_wrap_second_len_r_reg_2_01b34aa ,
    esc_wrap_second_len_r_reg_3_130d984 ,
    esc_m_payload_i_reg_44__0_3e7cb03 ,
    esc_m_payload_i_reg_44__1_a8cd662 ,
    esc_m_payload_i_reg_47__1_6188148 ,
    esc_FSM_sequential_state_reg_1_aa5780a ,
    esc_FSM_sequential_state_reg_1__0_5c93d31 ,
    esc_m_payload_i_reg_47__2_d1e0165 ,
    m_axi_araddr,
    s_ready_i_reg_1,
    s_ready_i0,
    aclk,
    m_valid_i_reg_1,
    esc_aresetn_d_reg_1__inv_1_8c340ab ,
    esc_m_axi_araddr_11_4618f72 ,
    esc_m_axi_araddr_11__0_a45329d ,
    esc_axaddr_incr_reg_3__0_6132b06 ,
    next_pending_r_reg,
    esc_wrap_second_len_r_reg_3__0_61735c7 ,
    esc_axaddr_offset_r_reg_3_9b4a3fc ,
    esc_wrap_second_len_r_reg_3__1_e9d1a95 ,
    esc_axaddr_offset_r_reg_3__0_89647ed ,
    s_axi_arid,
    s_axi_arlen,
    s_axi_arburst,
    s_axi_arsize,
    s_axi_arprot,
    s_axi_araddr,
    esc_m_axi_araddr_11__1_69dc7e5 ,
    sel_first_2,
    esc_m_axi_araddr_11__2_89d9808 ,
    esc_m_payload_i_reg_0__0_0129b79 );
  output s_ready_i_reg_0;
  output m_valid_i_reg_0;
  output esc_aresetn_d_reg_1__inv_0_a6031eb ;
  output [1:0]esc_axaddr_incr_reg_3_2fa58c8 ;
  output [58:0]Q;
  output [1:0]esc_axaddr_wrap_reg_3_f9d1eab ;
  output [3:0]esc_m_payload_i_reg_3__0_fc3b1db ;
  output [3:0]esc_m_payload_i_reg_7__0_d32552f ;
  output [3:0]O;
  output incr_next_pending;
  output esc_m_payload_i_reg_47__0_fbbb04b ;
  output esc_m_payload_i_reg_49__0_f216c9f ;
  output [1:0]esc_wrap_second_len_r_reg_2_01b34aa ;
  output [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  output esc_m_payload_i_reg_44__0_3e7cb03 ;
  output esc_m_payload_i_reg_44__1_a8cd662 ;
  output esc_m_payload_i_reg_47__1_6188148 ;
  output esc_FSM_sequential_state_reg_1_aa5780a ;
  output esc_FSM_sequential_state_reg_1__0_5c93d31 ;
  output [6:0]esc_m_payload_i_reg_47__2_d1e0165 ;
  output [11:0]m_axi_araddr;
  input s_ready_i_reg_1;
  input s_ready_i0;
  input aclk;
  input m_valid_i_reg_1;
  input esc_aresetn_d_reg_1__inv_1_8c340ab ;
  input [11:0]esc_m_axi_araddr_11_4618f72 ;
  input [11:0]esc_m_axi_araddr_11__0_a45329d ;
  input [3:0]esc_axaddr_incr_reg_3__0_6132b06 ;
  input next_pending_r_reg;
  input esc_wrap_second_len_r_reg_3__0_61735c7 ;
  input [1:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  input [3:0]esc_wrap_second_len_r_reg_3__1_e9d1a95 ;
  input [3:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  input [11:0]s_axi_arid;
  input [7:0]s_axi_arlen;
  input [1:0]s_axi_arburst;
  input [1:0]s_axi_arsize;
  input [2:0]s_axi_arprot;
  input [31:0]s_axi_araddr;
  input esc_m_axi_araddr_11__1_69dc7e5 ;
  input sel_first_2;
  input esc_m_axi_araddr_11__2_89d9808 ;
  input [0:0]esc_m_payload_i_reg_0__0_0129b79 ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire esc_FSM_sequential_state_reg_1_aa5780a ;
  wire esc_FSM_sequential_state_reg_1__0_5c93d31 ;
  wire [58:0]Q;
  wire aclk;
  wire esc_aresetn_d_reg_1__inv_0_a6031eb ;
  wire esc_aresetn_d_reg_1__inv_1_8c340ab ;
  wire esc_axaddr_incr_3__i_4__0_n_0_b06cb67 ;
  wire esc_axaddr_incr_3__i_5__0_n_0_99d50ae ;
  wire esc_axaddr_incr_3__i_6__0_n_0_80ff2e9 ;
  wire [1:0]esc_axaddr_incr_reg_3_2fa58c8 ;
  wire [3:0]esc_axaddr_incr_reg_3__0_6132b06 ;
  wire esc_axaddr_incr_reg_3__i_2__0_n_0_1331864 ;
  wire esc_axaddr_offset_r_0__i_2__0_n_0_2d607e8 ;
  wire esc_axaddr_offset_r_1__i_2__0_n_0_a48106e ;
  wire esc_axaddr_offset_r_1__i_3__0_n_0_5409b6a ;
  wire esc_axaddr_offset_r_2__i_2__0_n_0_7ca6160 ;
  wire esc_axaddr_offset_r_2__i_3__0_n_0_1c4b601 ;
  wire esc_axaddr_offset_r_3__i_2__0_n_0_c286e81 ;
  wire [1:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  wire [3:0]esc_axaddr_offset_r_reg_3__0_89647ed ;
  wire [1:0]esc_axaddr_wrap_reg_3_f9d1eab ;
  wire [11:0]m_axi_araddr;
  wire [11:0]esc_m_axi_araddr_11_4618f72 ;
  wire [11:0]esc_m_axi_araddr_11__0_a45329d ;
  wire esc_m_axi_araddr_11__1_69dc7e5 ;
  wire esc_m_axi_araddr_11__2_89d9808 ;
  wire esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440 ;
  wire esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6 ;
  wire esc_m_payload_i_0__i_1__0_n_0_577a48d ;
  wire esc_m_payload_i_1__i_1__0_n_0_13033f2 ;
  wire esc_m_payload_i_2__i_1__0_n_0_7fb17b7 ;
  wire esc_m_payload_i_35__i_1__0_n_0_28762fa ;
  wire esc_m_payload_i_36__i_1__0_n_0_5447fbd ;
  wire esc_m_payload_i_38__i_1__0_n_0_e79aa65 ;
  wire esc_m_payload_i_39__i_1__0_n_0_03ae231 ;
  wire esc_m_payload_i_3__i_1__0_n_0_233c5de ;
  wire esc_m_payload_i_44__i_1__0_n_0_d434db6 ;
  wire esc_m_payload_i_45__i_1__0_n_0_e71e7cb ;
  wire esc_m_payload_i_46__i_1__1_n_0_eafb976 ;
  wire esc_m_payload_i_47__i_1__0_n_0_9bf52a4 ;
  wire esc_m_payload_i_4__i_1__0_n_0_3b5c78c ;
  wire esc_m_payload_i_53__i_1__0_n_0_2ea2137 ;
  wire esc_m_payload_i_54__i_1__0_n_0_8ad130e ;
  wire esc_m_payload_i_55__i_1__0_n_0_75ffc14 ;
  wire esc_m_payload_i_56__i_1__0_n_0_085bd2f ;
  wire esc_m_payload_i_57__i_1__0_n_0_a360114 ;
  wire esc_m_payload_i_58__i_1__0_n_0_3ebb899 ;
  wire esc_m_payload_i_59__i_1__0_n_0_331429a ;
  wire esc_m_payload_i_5__i_1__0_n_0_3729cd0 ;
  wire esc_m_payload_i_60__i_1__0_n_0_280fa3d ;
  wire esc_m_payload_i_61__i_1__0_n_0_1c65503 ;
  wire esc_m_payload_i_62__i_1__0_n_0_548421c ;
  wire esc_m_payload_i_63__i_1__0_n_0_20a727a ;
  wire esc_m_payload_i_64__i_1__0_n_0_573a786 ;
  wire esc_m_payload_i_6__i_1__0_n_0_a973987 ;
  wire esc_m_payload_i_7__i_1__0_n_0_c99a872 ;
  wire [0:0]esc_m_payload_i_reg_0__0_0129b79 ;
  wire [3:0]esc_m_payload_i_reg_3__0_fc3b1db ;
  wire esc_m_payload_i_reg_44__0_3e7cb03 ;
  wire esc_m_payload_i_reg_44__1_a8cd662 ;
  wire esc_m_payload_i_reg_47__0_fbbb04b ;
  wire esc_m_payload_i_reg_47__1_6188148 ;
  wire [6:0]esc_m_payload_i_reg_47__2_d1e0165 ;
  wire [3:0]esc_m_payload_i_reg_7__0_d32552f ;
  wire m_valid_i_reg_0;
  wire m_valid_i_reg_1;
  wire next_pending_r_reg;
  wire [31:0]s_axi_araddr;
  wire [1:0]s_axi_arburst;
  wire [11:0]s_axi_arid;
  wire [7:0]s_axi_arlen;
  wire [1:0]s_axi_arsize;
  wire s_ready_i0;
  wire s_ready_i_reg_0;
  wire s_ready_i_reg_1;
  wire sel_first_2;
  wire esc_skid_buffer_reg_n_0__0_33bcee8 ;
  wire esc_skid_buffer_reg_n_0__1_71722f5 ;
  wire esc_skid_buffer_reg_n_0__2_21e7f94 ;
  wire esc_skid_buffer_reg_n_0__35_27754b0 ;
  wire esc_skid_buffer_reg_n_0__36_49139cd ;
  wire esc_skid_buffer_reg_n_0__38_66da518 ;
  wire esc_skid_buffer_reg_n_0__39_753eaf3 ;
  wire esc_skid_buffer_reg_n_0__3_2d17305 ;
  wire esc_skid_buffer_reg_n_0__44_4973a46 ;
  wire esc_skid_buffer_reg_n_0__45_ae6ce43 ;
  wire esc_skid_buffer_reg_n_0__46_e862893 ;
  wire esc_skid_buffer_reg_n_0__47_1ce944e ;
  wire esc_skid_buffer_reg_n_0__4_31058d6 ;
  wire esc_skid_buffer_reg_n_0__53_bc11961 ;
  wire esc_skid_buffer_reg_n_0__54_de97db8 ;
  wire esc_skid_buffer_reg_n_0__55_b96df6e ;
  wire esc_skid_buffer_reg_n_0__56_b9b25f2 ;
  wire esc_skid_buffer_reg_n_0__57_97d47d8 ;
  wire esc_skid_buffer_reg_n_0__58_55e72f7 ;
  wire esc_skid_buffer_reg_n_0__59_4478807 ;
  wire esc_skid_buffer_reg_n_0__5_f837c66 ;
  wire esc_skid_buffer_reg_n_0__60_b805d41 ;
  wire esc_skid_buffer_reg_n_0__61_42cdcde ;
  wire esc_skid_buffer_reg_n_0__62_5bcd135 ;
  wire esc_skid_buffer_reg_n_0__63_bee6e3d ;
  wire esc_skid_buffer_reg_n_0__64_1d37155 ;
  wire esc_skid_buffer_reg_n_0__6_e84291a ;
  wire esc_skid_buffer_reg_n_0__7_355ab42 ;
  wire esc_wrap_boundary_axaddr_r_3__i_2__0_n_0_4441e0a ;
  wire esc_wrap_cnt_r_3__i_2__0_n_0_172f9eb ;
  wire [1:0]esc_wrap_second_len_r_reg_2_01b34aa ;
  wire [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  wire esc_wrap_second_len_r_reg_3__0_61735c7 ;
  wire [3:0]esc_wrap_second_len_r_reg_3__1_e9d1a95 ;
  wire [3:0]esc_NLW_axaddr_incr_reg_3__i_2__0_CO_UNCONNECTED_a1a5fb5 ;

  assign incr_next_pending = next_pending_r_reg;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed FDRE: esc_aresetn_d_reg_1__inv_69e3fd2
  reg recovered_3_q = 1'b1;
  assign esc_aresetn_d_reg_1__inv_0_a6031eb = recovered_3_q;
  wire recovered_3_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_3_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_3_q == 1'b0))) recovered_3_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_3_q == (esc_aresetn_d_reg_1__inv_1_8c340ab)))) recovered_3_q <= (esc_aresetn_d_reg_1__inv_1_8c340ab);
  end

  // Reconstructed LUT3: esc_axaddr_incr_3__i_11__0_3f050b7
  assign esc_axaddr_incr_reg_3_2fa58c8 [1] = ((Q[35]) ? (((Q[36]) ? (~(esc_m_axi_araddr_11_4618f72 [3])) : (esc_m_axi_araddr_11_4618f72 [3]))) : (esc_m_axi_araddr_11_4618f72 [3]));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_14__0_09ddaf1
  assign esc_axaddr_incr_reg_3_2fa58c8 [0] = ((Q[35]) ? (esc_m_axi_araddr_11_4618f72 [0]) : (((Q[36]) ? (esc_m_axi_araddr_11_4618f72 [0]) : (~(esc_m_axi_araddr_11_4618f72 [0])))));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_4__0_0a15f22
  assign esc_axaddr_incr_3__i_4__0_n_0_b06cb67 = ((Q[2]) ? (((Q[35]) ? (~(Q[36])) : (1'b1))) : (1'b0));

  // Reconstructed LUT2: esc_axaddr_incr_3__i_5__0_43b1ee6
  assign esc_axaddr_incr_3__i_5__0_n_0_99d50ae = ((Q[36]) ? (1'b0) : (Q[1]));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_6__0_3ae9dce
  assign esc_axaddr_incr_3__i_6__0_n_0_80ff2e9 = ((Q[35]) ? (1'b0) : (((Q[36]) ? (1'b0) : (Q[0]))));

  // Reconstructed CARRY4: esc_axaddr_incr_reg_3__i_2__0_b83065c
  wire [3:0] recovered_9_co, recovered_9_o, recovered_9_s, recovered_9_di;
  assign recovered_9_s = esc_axaddr_incr_reg_3__0_6132b06;
  assign recovered_9_di = {Q[3],esc_axaddr_incr_3__i_4__0_n_0_b06cb67 ,esc_axaddr_incr_3__i_5__0_n_0_99d50ae ,esc_axaddr_incr_3__i_6__0_n_0_80ff2e9 };
  wire recovered_9_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_9_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_9_o[0] = recovered_9_s[0] ^ (recovered_9_ci || recovered_9_cy);
  assign recovered_9_co[0] = (recovered_9_s[0] & (recovered_9_ci || recovered_9_cy)) | (~recovered_9_s[0] & recovered_9_di[0]);
  assign recovered_9_o[1] = recovered_9_s[1] ^ recovered_9_co[0];
  assign recovered_9_co[1] = (recovered_9_s[1] & recovered_9_co[0]) | (~recovered_9_s[1] & recovered_9_di[1]);
  assign recovered_9_o[2] = recovered_9_s[2] ^ recovered_9_co[1];
  assign recovered_9_co[2] = (recovered_9_s[2] & recovered_9_co[1]) | (~recovered_9_s[2] & recovered_9_di[2]);
  assign recovered_9_o[3] = recovered_9_s[3] ^ recovered_9_co[2];
  assign recovered_9_co[3] = (recovered_9_s[3] & recovered_9_co[2]) | (~recovered_9_s[3] & recovered_9_di[3]);
  assign {esc_axaddr_incr_reg_3__i_2__0_n_0_1331864 ,esc_NLW_axaddr_incr_reg_3__i_2__0_CO_UNCONNECTED_a1a5fb5 [2:0]} = recovered_9_co;
  assign esc_m_payload_i_reg_3__0_fc3b1db = recovered_9_o;

  // Reconstructed CARRY4: esc_axaddr_incr_reg_7__i_2__0_d11eaef
  wire [3:0] recovered_10_co, recovered_10_o, recovered_10_s, recovered_10_di;
  assign recovered_10_s = Q[7:4];
  assign recovered_10_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_10_ci = ((esc_axaddr_incr_reg_3__i_2__0_n_0_1331864) !== 1'bz) && (esc_axaddr_incr_reg_3__i_2__0_n_0_1331864);
  wire recovered_10_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_10_o[0] = recovered_10_s[0] ^ (recovered_10_ci || recovered_10_cy);
  assign recovered_10_co[0] = (recovered_10_s[0] & (recovered_10_ci || recovered_10_cy)) | (~recovered_10_s[0] & recovered_10_di[0]);
  assign recovered_10_o[1] = recovered_10_s[1] ^ recovered_10_co[0];
  assign recovered_10_co[1] = (recovered_10_s[1] & recovered_10_co[0]) | (~recovered_10_s[1] & recovered_10_di[1]);
  assign recovered_10_o[2] = recovered_10_s[2] ^ recovered_10_co[1];
  assign recovered_10_co[2] = (recovered_10_s[2] & recovered_10_co[1]) | (~recovered_10_s[2] & recovered_10_di[2]);
  assign recovered_10_o[3] = recovered_10_s[3] ^ recovered_10_co[2];
  assign recovered_10_co[3] = (recovered_10_s[3] & recovered_10_co[2]) | (~recovered_10_s[3] & recovered_10_di[3]);
  assign esc_m_payload_i_reg_7__0_d32552f = recovered_10_o;

  // Reconstructed LUT6: esc_axaddr_offset_r_0__i_1__0_96416f2
  assign esc_m_payload_i_reg_44__1_a8cd662 = ((esc_axaddr_offset_r_reg_3__0_89647ed [0]) ? (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [0]) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [1]) ? (1'b1) : (((Q[39]) ? (esc_axaddr_offset_r_0__i_2__0_n_0_2d607e8) : (1'b0))))) : (1'b1))) : (1'b1))) : (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [0]) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [1]) ? (1'b0) : (((Q[39]) ? (esc_axaddr_offset_r_0__i_2__0_n_0_2d607e8) : (1'b0))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_axaddr_offset_r_0__i_2__0_6e9e46e
  assign esc_axaddr_offset_r_0__i_2__0_n_0_2d607e8 = ((Q[2]) ? (((Q[35]) ? (((Q[36]) ? (Q[3]) : (Q[1]))) : (((Q[36]) ? (1'b1) : (Q[0]))))) : (((Q[35]) ? (((Q[36]) ? (Q[3]) : (Q[1]))) : (((Q[36]) ? (1'b0) : (Q[0]))))));

  // Reconstructed LUT6: esc_axaddr_offset_r_1__i_1__0_586be93
  assign esc_FSM_sequential_state_reg_1_aa5780a = ((esc_axaddr_offset_r_reg_3__0_89647ed [1]) ? (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [0]) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [1]) ? (1'b1) : (((esc_axaddr_offset_r_1__i_3__0_n_0_5409b6a) ? (1'b1) : (esc_axaddr_offset_r_1__i_2__0_n_0_a48106e))))) : (1'b1))) : (1'b1))) : (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [0]) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [1]) ? (1'b0) : (((esc_axaddr_offset_r_1__i_3__0_n_0_5409b6a) ? (1'b1) : (esc_axaddr_offset_r_1__i_2__0_n_0_a48106e))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_axaddr_offset_r_1__i_2__0_966cada
  assign esc_axaddr_offset_r_1__i_2__0_n_0_a48106e = ((Q[2]) ? (((Q[40]) ? (((Q[36]) ? (1'b0) : (((Q[35]) ? (1'b1) : (Q[1]))))) : (1'b0))) : (((Q[40]) ? (((Q[36]) ? (1'b0) : (((Q[35]) ? (1'b0) : (Q[1]))))) : (1'b0))));

  // Reconstructed LUT5: esc_axaddr_offset_r_1__i_3__0_f93c00b
  assign esc_axaddr_offset_r_1__i_3__0_n_0_5409b6a = ((Q[4]) ? (((Q[40]) ? (((Q[36]) ? (((Q[35]) ? (1'b1) : (Q[3]))) : (1'b0))) : (1'b0))) : (((Q[40]) ? (((Q[36]) ? (((Q[35]) ? (1'b0) : (Q[3]))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_axaddr_offset_r_2__i_1__0_c8f5e8c
  assign esc_FSM_sequential_state_reg_1__0_5c93d31 = ((esc_axaddr_offset_r_reg_3__0_89647ed [2]) ? (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [0]) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [1]) ? (1'b1) : (((esc_axaddr_offset_r_2__i_3__0_n_0_1c4b601) ? (1'b1) : (esc_axaddr_offset_r_2__i_2__0_n_0_7ca6160))))) : (1'b1))) : (1'b1))) : (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [0]) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [1]) ? (1'b0) : (((esc_axaddr_offset_r_2__i_3__0_n_0_1c4b601) ? (1'b1) : (esc_axaddr_offset_r_2__i_2__0_n_0_7ca6160))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_axaddr_offset_r_2__i_2__0_dd767b8
  assign esc_axaddr_offset_r_2__i_2__0_n_0_7ca6160 = ((Q[3]) ? (((Q[41]) ? (((Q[36]) ? (1'b0) : (((Q[35]) ? (1'b1) : (Q[2]))))) : (1'b0))) : (((Q[41]) ? (((Q[36]) ? (1'b0) : (((Q[35]) ? (1'b0) : (Q[2]))))) : (1'b0))));

  // Reconstructed LUT5: esc_axaddr_offset_r_2__i_3__0_bcdbf5e
  assign esc_axaddr_offset_r_2__i_3__0_n_0_1c4b601 = ((Q[5]) ? (((Q[41]) ? (((Q[36]) ? (((Q[35]) ? (1'b1) : (Q[4]))) : (1'b0))) : (1'b0))) : (((Q[41]) ? (((Q[36]) ? (((Q[35]) ? (1'b0) : (Q[4]))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_axaddr_offset_r_3__i_1__0_55d4f1c
  assign esc_m_payload_i_reg_47__1_6188148 = ((esc_axaddr_offset_r_reg_3__0_89647ed [3]) ? (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [0]) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [1]) ? (1'b1) : (((Q[42]) ? (esc_axaddr_offset_r_3__i_2__0_n_0_c286e81) : (1'b0))))) : (1'b1))) : (1'b1))) : (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [0]) ? (((esc_axaddr_offset_r_reg_3_9b4a3fc [1]) ? (1'b0) : (((Q[42]) ? (esc_axaddr_offset_r_3__i_2__0_n_0_c286e81) : (1'b0))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_axaddr_offset_r_3__i_2__0_013d30a
  assign esc_axaddr_offset_r_3__i_2__0_n_0_c286e81 = ((Q[5]) ? (((Q[35]) ? (((Q[36]) ? (Q[6]) : (Q[4]))) : (((Q[36]) ? (1'b1) : (Q[3]))))) : (((Q[35]) ? (((Q[36]) ? (Q[6]) : (Q[4]))) : (((Q[36]) ? (1'b0) : (Q[3]))))));

  // Reconstructed LUT3: esc_axaddr_wrap_3__i_3__0_6b14237
  assign esc_axaddr_wrap_reg_3_f9d1eab [1] = ((Q[35]) ? (((Q[36]) ? (~(esc_m_axi_araddr_11__0_a45329d [3])) : (esc_m_axi_araddr_11__0_a45329d [3]))) : (esc_m_axi_araddr_11__0_a45329d [3]));

  // Reconstructed LUT3: esc_axaddr_wrap_3__i_6__0_975a10e
  assign esc_axaddr_wrap_reg_3_f9d1eab [0] = ((Q[35]) ? (esc_m_axi_araddr_11__0_a45329d [0]) : (((Q[36]) ? (esc_m_axi_araddr_11__0_a45329d [0]) : (~(esc_m_axi_araddr_11__0_a45329d [0])))));

  // Reconstructed LUT6: esc_m_axi_araddr_0__INST_0_df490eb
  assign m_axi_araddr[0] = ((esc_m_axi_araddr_11__1_69dc7e5) ? (((Q[0]) ? (1'b1) : (((esc_m_axi_araddr_11_4618f72 [0]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [0]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [0]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))))) : (((esc_m_axi_araddr_11_4618f72 [0]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [0]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [0]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))));

  // Reconstructed LUT2: esc_m_axi_araddr_11__INST_0_i_1_49bd335
  assign esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440 = ((esc_m_axi_araddr_11__2_89d9808) ? (1'b0) : (Q[38]));

  // Reconstructed LUT3: esc_m_axi_araddr_11__INST_0_i_2_a1e948b
  assign esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6 = ((Q[38]) ? (1'b0) : (((sel_first_2) ? (1'b0) : (Q[37]))));

  // Reconstructed LUT6: esc_m_axi_araddr_1__INST_0_c67ca04
  assign m_axi_araddr[1] = ((esc_m_axi_araddr_11__1_69dc7e5) ? (((Q[1]) ? (1'b1) : (((esc_m_axi_araddr_11_4618f72 [1]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [1]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [1]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))))) : (((esc_m_axi_araddr_11_4618f72 [1]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [1]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [1]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))));

  // Reconstructed LUT6: esc_m_axi_araddr_2__INST_0_b171706
  assign m_axi_araddr[2] = ((esc_m_axi_araddr_11__1_69dc7e5) ? (((Q[2]) ? (1'b1) : (((esc_m_axi_araddr_11_4618f72 [2]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [2]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [2]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))))) : (((esc_m_axi_araddr_11_4618f72 [2]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [2]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [2]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))));

  // Reconstructed LUT6: esc_m_axi_araddr_3__INST_0_ef1ad2c
  assign m_axi_araddr[3] = ((esc_m_axi_araddr_11__1_69dc7e5) ? (((Q[3]) ? (1'b1) : (((esc_m_axi_araddr_11_4618f72 [3]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [3]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [3]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))))) : (((esc_m_axi_araddr_11_4618f72 [3]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [3]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [3]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))));

  // Reconstructed LUT6: esc_m_axi_araddr_4__INST_0_3d13695
  assign m_axi_araddr[4] = ((esc_m_axi_araddr_11__1_69dc7e5) ? (((Q[4]) ? (1'b1) : (((esc_m_axi_araddr_11_4618f72 [4]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [4]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [4]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))))) : (((esc_m_axi_araddr_11_4618f72 [4]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [4]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [4]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))));

  // Reconstructed LUT6: esc_m_axi_araddr_5__INST_0_541940e
  assign m_axi_araddr[5] = ((esc_m_axi_araddr_11__1_69dc7e5) ? (((Q[5]) ? (1'b1) : (((esc_m_axi_araddr_11_4618f72 [5]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [5]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [5]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))))) : (((esc_m_axi_araddr_11_4618f72 [5]) ? (((esc_m_axi_araddr_11__INST_0_i_2_n_0_50a80d6) ? (1'b1) : (((esc_m_axi_araddr_11__0_a45329d [5]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))) : (((esc_m_axi_araddr_11__0_a45329d [5]) ? (esc_m_axi_araddr_11__INST_0_i_1_n_0_5eda440) : (1'b0))))));

  // Reconstructed LUT3: esc_m_payload_i_0__i_1__0_ef07be5
  assign esc_m_payload_i_0__i_1__0_n_0_577a48d = ((esc_skid_buffer_reg_n_0__0_33bcee8) ? (((s_ready_i_reg_0) ? (s_axi_araddr[0]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_araddr[0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_1__i_1__0_db23efe
  assign esc_m_payload_i_1__i_1__0_n_0_13033f2 = ((esc_skid_buffer_reg_n_0__1_71722f5) ? (((s_ready_i_reg_0) ? (s_axi_araddr[1]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_araddr[1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_2__i_1__0_22737d8
  assign esc_m_payload_i_2__i_1__0_n_0_7fb17b7 = ((esc_skid_buffer_reg_n_0__2_21e7f94) ? (((s_ready_i_reg_0) ? (s_axi_araddr[2]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_araddr[2]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_35__i_1__0_e944aa1
  assign esc_m_payload_i_35__i_1__0_n_0_28762fa = ((esc_skid_buffer_reg_n_0__35_27754b0) ? (((s_ready_i_reg_0) ? (s_axi_arsize[0]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arsize[0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_36__i_1__0_4b7ba40
  assign esc_m_payload_i_36__i_1__0_n_0_5447fbd = ((esc_skid_buffer_reg_n_0__36_49139cd) ? (((s_ready_i_reg_0) ? (s_axi_arsize[1]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arsize[1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_38__i_1__0_cfd94ed
  assign esc_m_payload_i_38__i_1__0_n_0_e79aa65 = ((esc_skid_buffer_reg_n_0__38_66da518) ? (((s_ready_i_reg_0) ? (s_axi_arburst[0]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arburst[0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_39__i_1__0_fd68ce2
  assign esc_m_payload_i_39__i_1__0_n_0_03ae231 = ((esc_skid_buffer_reg_n_0__39_753eaf3) ? (((s_ready_i_reg_0) ? (s_axi_arburst[1]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arburst[1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_3__i_1__0_1c47ac5
  assign esc_m_payload_i_3__i_1__0_n_0_233c5de = ((esc_skid_buffer_reg_n_0__3_2d17305) ? (((s_ready_i_reg_0) ? (s_axi_araddr[3]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_araddr[3]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_44__i_1__0_cb89258
  assign esc_m_payload_i_44__i_1__0_n_0_d434db6 = ((esc_skid_buffer_reg_n_0__44_4973a46) ? (((s_ready_i_reg_0) ? (s_axi_arlen[0]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arlen[0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_45__i_1__0_50c5f07
  assign esc_m_payload_i_45__i_1__0_n_0_e71e7cb = ((esc_skid_buffer_reg_n_0__45_ae6ce43) ? (((s_ready_i_reg_0) ? (s_axi_arlen[1]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arlen[1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_46__i_1__1_2d987c2
  assign esc_m_payload_i_46__i_1__1_n_0_eafb976 = ((esc_skid_buffer_reg_n_0__46_e862893) ? (((s_ready_i_reg_0) ? (s_axi_arlen[2]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arlen[2]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_47__i_1__0_ac2f9e6
  assign esc_m_payload_i_47__i_1__0_n_0_9bf52a4 = ((esc_skid_buffer_reg_n_0__47_1ce944e) ? (((s_ready_i_reg_0) ? (s_axi_arlen[3]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arlen[3]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_4__i_1__0_890d4c2
  assign esc_m_payload_i_4__i_1__0_n_0_3b5c78c = ((esc_skid_buffer_reg_n_0__4_31058d6) ? (((s_ready_i_reg_0) ? (s_axi_araddr[4]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_araddr[4]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_53__i_1__0_fc54157
  assign esc_m_payload_i_53__i_1__0_n_0_2ea2137 = ((esc_skid_buffer_reg_n_0__53_bc11961) ? (((s_ready_i_reg_0) ? (s_axi_arid[0]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_54__i_1__0_8d6f926
  assign esc_m_payload_i_54__i_1__0_n_0_8ad130e = ((esc_skid_buffer_reg_n_0__54_de97db8) ? (((s_ready_i_reg_0) ? (s_axi_arid[1]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_55__i_1__0_468af2b
  assign esc_m_payload_i_55__i_1__0_n_0_75ffc14 = ((esc_skid_buffer_reg_n_0__55_b96df6e) ? (((s_ready_i_reg_0) ? (s_axi_arid[2]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[2]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_56__i_1__0_a89afd5
  assign esc_m_payload_i_56__i_1__0_n_0_085bd2f = ((esc_skid_buffer_reg_n_0__56_b9b25f2) ? (((s_ready_i_reg_0) ? (s_axi_arid[3]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[3]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_57__i_1__0_944b6f8
  assign esc_m_payload_i_57__i_1__0_n_0_a360114 = ((esc_skid_buffer_reg_n_0__57_97d47d8) ? (((s_ready_i_reg_0) ? (s_axi_arid[4]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[4]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_58__i_1__0_d2b6977
  assign esc_m_payload_i_58__i_1__0_n_0_3ebb899 = ((esc_skid_buffer_reg_n_0__58_55e72f7) ? (((s_ready_i_reg_0) ? (s_axi_arid[5]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[5]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_59__i_1__0_be46232
  assign esc_m_payload_i_59__i_1__0_n_0_331429a = ((esc_skid_buffer_reg_n_0__59_4478807) ? (((s_ready_i_reg_0) ? (s_axi_arid[6]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[6]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_5__i_1__0_555700f
  assign esc_m_payload_i_5__i_1__0_n_0_3729cd0 = ((esc_skid_buffer_reg_n_0__5_f837c66) ? (((s_ready_i_reg_0) ? (s_axi_araddr[5]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_araddr[5]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_60__i_1__0_7e60909
  assign esc_m_payload_i_60__i_1__0_n_0_280fa3d = ((esc_skid_buffer_reg_n_0__60_b805d41) ? (((s_ready_i_reg_0) ? (s_axi_arid[7]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[7]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_61__i_1__0_056b180
  assign esc_m_payload_i_61__i_1__0_n_0_1c65503 = ((esc_skid_buffer_reg_n_0__61_42cdcde) ? (((s_ready_i_reg_0) ? (s_axi_arid[8]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[8]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_62__i_1__0_ed3f5bc
  assign esc_m_payload_i_62__i_1__0_n_0_548421c = ((esc_skid_buffer_reg_n_0__62_5bcd135) ? (((s_ready_i_reg_0) ? (s_axi_arid[9]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[9]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_63__i_1__0_0ea02fe
  assign esc_m_payload_i_63__i_1__0_n_0_20a727a = ((esc_skid_buffer_reg_n_0__63_bee6e3d) ? (((s_ready_i_reg_0) ? (s_axi_arid[10]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[10]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_64__i_1__0_ab62255
  assign esc_m_payload_i_64__i_1__0_n_0_573a786 = ((esc_skid_buffer_reg_n_0__64_1d37155) ? (((s_ready_i_reg_0) ? (s_axi_arid[11]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_arid[11]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_6__i_1__0_68514cc
  assign esc_m_payload_i_6__i_1__0_n_0_a973987 = ((esc_skid_buffer_reg_n_0__6_e84291a) ? (((s_ready_i_reg_0) ? (s_axi_araddr[6]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_araddr[6]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_7__i_1__0_5ad9d73
  assign esc_m_payload_i_7__i_1__0_n_0_c99a872 = ((esc_skid_buffer_reg_n_0__7_355ab42) ? (((s_ready_i_reg_0) ? (s_axi_araddr[7]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_araddr[7]) : (1'b0))));

  // Reconstructed FDRE: esc_m_payload_i_reg_0_2f8d71c
  reg recovered_59_q = 1'b0;
  assign Q[0] = recovered_59_q;
  wire recovered_59_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_59_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_59_q == 1'b0))) recovered_59_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_59_q == (esc_m_payload_i_0__i_1__0_n_0_577a48d)))) recovered_59_q <= (esc_m_payload_i_0__i_1__0_n_0_577a48d);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_1_a76cbaf
  reg recovered_60_q = 1'b0;
  assign Q[1] = recovered_60_q;
  wire recovered_60_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_60_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_60_q == 1'b0))) recovered_60_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_60_q == (esc_m_payload_i_1__i_1__0_n_0_13033f2)))) recovered_60_q <= (esc_m_payload_i_1__i_1__0_n_0_13033f2);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_2_3bf2adb
  reg recovered_61_q = 1'b0;
  assign Q[2] = recovered_61_q;
  wire recovered_61_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_61_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_61_q == 1'b0))) recovered_61_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_61_q == (esc_m_payload_i_2__i_1__0_n_0_7fb17b7)))) recovered_61_q <= (esc_m_payload_i_2__i_1__0_n_0_7fb17b7);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_35_235a12d
  reg recovered_62_q = 1'b0;
  assign Q[35] = recovered_62_q;
  wire recovered_62_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_62_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_62_q == 1'b0))) recovered_62_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_62_q == (esc_m_payload_i_35__i_1__0_n_0_28762fa)))) recovered_62_q <= (esc_m_payload_i_35__i_1__0_n_0_28762fa);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_36_9854560
  reg recovered_63_q = 1'b0;
  assign Q[36] = recovered_63_q;
  wire recovered_63_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_63_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_63_q == 1'b0))) recovered_63_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_63_q == (esc_m_payload_i_36__i_1__0_n_0_5447fbd)))) recovered_63_q <= (esc_m_payload_i_36__i_1__0_n_0_5447fbd);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_38_b34fad1
  reg recovered_64_q = 1'b0;
  assign Q[37] = recovered_64_q;
  wire recovered_64_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_64_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_64_q == 1'b0))) recovered_64_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_64_q == (esc_m_payload_i_38__i_1__0_n_0_e79aa65)))) recovered_64_q <= (esc_m_payload_i_38__i_1__0_n_0_e79aa65);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_39_ea68878
  reg recovered_65_q = 1'b0;
  assign Q[38] = recovered_65_q;
  wire recovered_65_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_65_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_65_q == 1'b0))) recovered_65_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_65_q == (esc_m_payload_i_39__i_1__0_n_0_03ae231)))) recovered_65_q <= (esc_m_payload_i_39__i_1__0_n_0_03ae231);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_3_3eab624
  reg recovered_66_q = 1'b0;
  assign Q[3] = recovered_66_q;
  wire recovered_66_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_66_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_66_q == 1'b0))) recovered_66_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_66_q == (esc_m_payload_i_3__i_1__0_n_0_233c5de)))) recovered_66_q <= (esc_m_payload_i_3__i_1__0_n_0_233c5de);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_44_7279c72
  reg recovered_67_q = 1'b0;
  assign Q[39] = recovered_67_q;
  wire recovered_67_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_67_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_67_q == 1'b0))) recovered_67_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_67_q == (esc_m_payload_i_44__i_1__0_n_0_d434db6)))) recovered_67_q <= (esc_m_payload_i_44__i_1__0_n_0_d434db6);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_45_fff3a3b
  reg recovered_68_q = 1'b0;
  assign Q[40] = recovered_68_q;
  wire recovered_68_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_68_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_68_q == 1'b0))) recovered_68_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_68_q == (esc_m_payload_i_45__i_1__0_n_0_e71e7cb)))) recovered_68_q <= (esc_m_payload_i_45__i_1__0_n_0_e71e7cb);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_46_022e045
  reg recovered_69_q = 1'b0;
  assign Q[41] = recovered_69_q;
  wire recovered_69_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_69_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_69_q == 1'b0))) recovered_69_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_69_q == (esc_m_payload_i_46__i_1__1_n_0_eafb976)))) recovered_69_q <= (esc_m_payload_i_46__i_1__1_n_0_eafb976);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_47_8c317be
  reg recovered_70_q = 1'b0;
  assign Q[42] = recovered_70_q;
  wire recovered_70_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_70_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_70_q == 1'b0))) recovered_70_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_70_q == (esc_m_payload_i_47__i_1__0_n_0_9bf52a4)))) recovered_70_q <= (esc_m_payload_i_47__i_1__0_n_0_9bf52a4);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_4_60ef705
  reg recovered_71_q = 1'b0;
  assign Q[4] = recovered_71_q;
  wire recovered_71_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_71_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_71_q == 1'b0))) recovered_71_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_71_q == (esc_m_payload_i_4__i_1__0_n_0_3b5c78c)))) recovered_71_q <= (esc_m_payload_i_4__i_1__0_n_0_3b5c78c);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_53_5057f9f
  reg recovered_72_q = 1'b0;
  assign Q[47] = recovered_72_q;
  wire recovered_72_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_72_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_72_q == 1'b0))) recovered_72_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_72_q == (esc_m_payload_i_53__i_1__0_n_0_2ea2137)))) recovered_72_q <= (esc_m_payload_i_53__i_1__0_n_0_2ea2137);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_54_9d2ea8e
  reg recovered_73_q = 1'b0;
  assign Q[48] = recovered_73_q;
  wire recovered_73_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_73_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_73_q == 1'b0))) recovered_73_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_73_q == (esc_m_payload_i_54__i_1__0_n_0_8ad130e)))) recovered_73_q <= (esc_m_payload_i_54__i_1__0_n_0_8ad130e);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_55_5d43526
  reg recovered_74_q = 1'b0;
  assign Q[49] = recovered_74_q;
  wire recovered_74_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_74_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_74_q == 1'b0))) recovered_74_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_74_q == (esc_m_payload_i_55__i_1__0_n_0_75ffc14)))) recovered_74_q <= (esc_m_payload_i_55__i_1__0_n_0_75ffc14);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_56_bdf5998
  reg recovered_75_q = 1'b0;
  assign Q[50] = recovered_75_q;
  wire recovered_75_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_75_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_75_q == 1'b0))) recovered_75_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_75_q == (esc_m_payload_i_56__i_1__0_n_0_085bd2f)))) recovered_75_q <= (esc_m_payload_i_56__i_1__0_n_0_085bd2f);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_57_07cb7bd
  reg recovered_76_q = 1'b0;
  assign Q[51] = recovered_76_q;
  wire recovered_76_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_76_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_76_q == 1'b0))) recovered_76_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_76_q == (esc_m_payload_i_57__i_1__0_n_0_a360114)))) recovered_76_q <= (esc_m_payload_i_57__i_1__0_n_0_a360114);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_58_b00fbf5
  reg recovered_77_q = 1'b0;
  assign Q[52] = recovered_77_q;
  wire recovered_77_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_77_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_77_q == 1'b0))) recovered_77_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_77_q == (esc_m_payload_i_58__i_1__0_n_0_3ebb899)))) recovered_77_q <= (esc_m_payload_i_58__i_1__0_n_0_3ebb899);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_59_63248e5
  reg recovered_78_q = 1'b0;
  assign Q[53] = recovered_78_q;
  wire recovered_78_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_78_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_78_q == 1'b0))) recovered_78_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_78_q == (esc_m_payload_i_59__i_1__0_n_0_331429a)))) recovered_78_q <= (esc_m_payload_i_59__i_1__0_n_0_331429a);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_5_6200800
  reg recovered_79_q = 1'b0;
  assign Q[5] = recovered_79_q;
  wire recovered_79_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_79_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_79_q == 1'b0))) recovered_79_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_79_q == (esc_m_payload_i_5__i_1__0_n_0_3729cd0)))) recovered_79_q <= (esc_m_payload_i_5__i_1__0_n_0_3729cd0);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_60_a2bf4d1
  reg recovered_80_q = 1'b0;
  assign Q[54] = recovered_80_q;
  wire recovered_80_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_80_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_80_q == 1'b0))) recovered_80_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_80_q == (esc_m_payload_i_60__i_1__0_n_0_280fa3d)))) recovered_80_q <= (esc_m_payload_i_60__i_1__0_n_0_280fa3d);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_61_833d8b1
  reg recovered_81_q = 1'b0;
  assign Q[55] = recovered_81_q;
  wire recovered_81_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_81_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_81_q == 1'b0))) recovered_81_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_81_q == (esc_m_payload_i_61__i_1__0_n_0_1c65503)))) recovered_81_q <= (esc_m_payload_i_61__i_1__0_n_0_1c65503);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_62_cbed6bd
  reg recovered_82_q = 1'b0;
  assign Q[56] = recovered_82_q;
  wire recovered_82_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_82_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_82_q == 1'b0))) recovered_82_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_82_q == (esc_m_payload_i_62__i_1__0_n_0_548421c)))) recovered_82_q <= (esc_m_payload_i_62__i_1__0_n_0_548421c);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_63_e78dc9f
  reg recovered_83_q = 1'b0;
  assign Q[57] = recovered_83_q;
  wire recovered_83_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_83_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_83_q == 1'b0))) recovered_83_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_83_q == (esc_m_payload_i_63__i_1__0_n_0_20a727a)))) recovered_83_q <= (esc_m_payload_i_63__i_1__0_n_0_20a727a);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_64_2ba99a2
  reg recovered_84_q = 1'b0;
  assign Q[58] = recovered_84_q;
  wire recovered_84_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_84_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_84_q == 1'b0))) recovered_84_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_84_q == (esc_m_payload_i_64__i_1__0_n_0_573a786)))) recovered_84_q <= (esc_m_payload_i_64__i_1__0_n_0_573a786);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_6_8d56399
  reg recovered_85_q = 1'b0;
  assign Q[6] = recovered_85_q;
  wire recovered_85_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_85_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_85_q == 1'b0))) recovered_85_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_85_q == (esc_m_payload_i_6__i_1__0_n_0_a973987)))) recovered_85_q <= (esc_m_payload_i_6__i_1__0_n_0_a973987);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_7_ba4380d
  reg recovered_86_q = 1'b0;
  assign Q[7] = recovered_86_q;
  wire recovered_86_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_86_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_86_q == 1'b0))) recovered_86_q <= 1'b0;
    else if ((esc_m_payload_i_reg_0__0_0129b79) || ((esc_m_payload_i_reg_0__0_0129b79) === 1'bz) || (((esc_m_payload_i_reg_0__0_0129b79) === 1'bx) && (recovered_86_q == (esc_m_payload_i_7__i_1__0_n_0_c99a872)))) recovered_86_q <= (esc_m_payload_i_7__i_1__0_n_0_c99a872);
  end

  // Reconstructed FDRE: m_valid_i_reg
  reg recovered_87_q = 1'b0;
  assign m_valid_i_reg_0 = recovered_87_q;
  wire recovered_87_reset = ((esc_aresetn_d_reg_1__inv_0_a6031eb)) && ((esc_aresetn_d_reg_1__inv_0_a6031eb) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_87_reset || (((esc_aresetn_d_reg_1__inv_0_a6031eb) === 1'bx) && (recovered_87_q == 1'b0))) recovered_87_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_87_q == (m_valid_i_reg_1)))) recovered_87_q <= (m_valid_i_reg_1);
  end

  // Reconstructed LUT5: next_pending_r_i_2__2
  assign esc_m_payload_i_reg_47__0_fbbb04b = ((esc_wrap_second_len_r_reg_3__0_61735c7) ? (((Q[41]) ? (1'b1) : (((Q[40]) ? (1'b1) : (((Q[39]) ? (1'b1) : (Q[42]))))))) : (1'b0));

  // Reconstructed FDRE: s_ready_i_reg
  reg recovered_89_q = 1'b0;
  assign s_ready_i_reg_0 = recovered_89_q;
  wire recovered_89_reset = ((s_ready_i_reg_1)) && ((s_ready_i_reg_1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_89_reset || (((s_ready_i_reg_1) === 1'bx) && (recovered_89_q == 1'b0))) recovered_89_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_89_q == (s_ready_i0)))) recovered_89_q <= (s_ready_i0);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_0_76b369d
  reg recovered_90_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__0_33bcee8 = recovered_90_q;
  wire recovered_90_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_90_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_90_q == 1'b0))) recovered_90_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_90_q == (s_axi_araddr[0])))) recovered_90_q <= (s_axi_araddr[0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_1_56ed2e4
  reg recovered_91_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__1_71722f5 = recovered_91_q;
  wire recovered_91_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_91_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_91_q == 1'b0))) recovered_91_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_91_q == (s_axi_araddr[1])))) recovered_91_q <= (s_axi_araddr[1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_2_a1b118e
  reg recovered_92_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__2_21e7f94 = recovered_92_q;
  wire recovered_92_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_92_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_92_q == 1'b0))) recovered_92_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_92_q == (s_axi_araddr[2])))) recovered_92_q <= (s_axi_araddr[2]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_35_1832a0f
  reg recovered_93_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__35_27754b0 = recovered_93_q;
  wire recovered_93_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_93_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_93_q == 1'b0))) recovered_93_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_93_q == (s_axi_arsize[0])))) recovered_93_q <= (s_axi_arsize[0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_36_590360f
  reg recovered_94_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__36_49139cd = recovered_94_q;
  wire recovered_94_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_94_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_94_q == 1'b0))) recovered_94_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_94_q == (s_axi_arsize[1])))) recovered_94_q <= (s_axi_arsize[1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_38_2e7b154
  reg recovered_95_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__38_66da518 = recovered_95_q;
  wire recovered_95_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_95_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_95_q == 1'b0))) recovered_95_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_95_q == (s_axi_arburst[0])))) recovered_95_q <= (s_axi_arburst[0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_39_f9c8e20
  reg recovered_96_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__39_753eaf3 = recovered_96_q;
  wire recovered_96_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_96_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_96_q == 1'b0))) recovered_96_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_96_q == (s_axi_arburst[1])))) recovered_96_q <= (s_axi_arburst[1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_3_b2015ce
  reg recovered_97_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__3_2d17305 = recovered_97_q;
  wire recovered_97_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_97_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_97_q == 1'b0))) recovered_97_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_97_q == (s_axi_araddr[3])))) recovered_97_q <= (s_axi_araddr[3]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_44_ba14b87
  reg recovered_98_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__44_4973a46 = recovered_98_q;
  wire recovered_98_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_98_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_98_q == 1'b0))) recovered_98_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_98_q == (s_axi_arlen[0])))) recovered_98_q <= (s_axi_arlen[0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_45_e8f1309
  reg recovered_99_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__45_ae6ce43 = recovered_99_q;
  wire recovered_99_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_99_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_99_q == 1'b0))) recovered_99_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_99_q == (s_axi_arlen[1])))) recovered_99_q <= (s_axi_arlen[1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_46_665ac24
  reg recovered_100_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__46_e862893 = recovered_100_q;
  wire recovered_100_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_100_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_100_q == 1'b0))) recovered_100_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_100_q == (s_axi_arlen[2])))) recovered_100_q <= (s_axi_arlen[2]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_47_030045d
  reg recovered_101_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__47_1ce944e = recovered_101_q;
  wire recovered_101_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_101_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_101_q == 1'b0))) recovered_101_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_101_q == (s_axi_arlen[3])))) recovered_101_q <= (s_axi_arlen[3]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_4_8811fae
  reg recovered_102_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__4_31058d6 = recovered_102_q;
  wire recovered_102_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_102_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_102_q == 1'b0))) recovered_102_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_102_q == (s_axi_araddr[4])))) recovered_102_q <= (s_axi_araddr[4]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_53_e0b802e
  reg recovered_103_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__53_bc11961 = recovered_103_q;
  wire recovered_103_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_103_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_103_q == 1'b0))) recovered_103_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_103_q == (s_axi_arid[0])))) recovered_103_q <= (s_axi_arid[0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_54_291a902
  reg recovered_104_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__54_de97db8 = recovered_104_q;
  wire recovered_104_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_104_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_104_q == 1'b0))) recovered_104_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_104_q == (s_axi_arid[1])))) recovered_104_q <= (s_axi_arid[1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_55_45f6563
  reg recovered_105_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__55_b96df6e = recovered_105_q;
  wire recovered_105_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_105_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_105_q == 1'b0))) recovered_105_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_105_q == (s_axi_arid[2])))) recovered_105_q <= (s_axi_arid[2]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_56_02fdde7
  reg recovered_106_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__56_b9b25f2 = recovered_106_q;
  wire recovered_106_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_106_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_106_q == 1'b0))) recovered_106_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_106_q == (s_axi_arid[3])))) recovered_106_q <= (s_axi_arid[3]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_57_1a385c7
  reg recovered_107_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__57_97d47d8 = recovered_107_q;
  wire recovered_107_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_107_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_107_q == 1'b0))) recovered_107_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_107_q == (s_axi_arid[4])))) recovered_107_q <= (s_axi_arid[4]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_58_364cc5f
  reg recovered_108_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__58_55e72f7 = recovered_108_q;
  wire recovered_108_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_108_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_108_q == 1'b0))) recovered_108_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_108_q == (s_axi_arid[5])))) recovered_108_q <= (s_axi_arid[5]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_59_b28a823
  reg recovered_109_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__59_4478807 = recovered_109_q;
  wire recovered_109_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_109_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_109_q == 1'b0))) recovered_109_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_109_q == (s_axi_arid[6])))) recovered_109_q <= (s_axi_arid[6]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_5_2379aaf
  reg recovered_110_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__5_f837c66 = recovered_110_q;
  wire recovered_110_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_110_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_110_q == 1'b0))) recovered_110_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_110_q == (s_axi_araddr[5])))) recovered_110_q <= (s_axi_araddr[5]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_60_3367d87
  reg recovered_111_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__60_b805d41 = recovered_111_q;
  wire recovered_111_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_111_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_111_q == 1'b0))) recovered_111_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_111_q == (s_axi_arid[7])))) recovered_111_q <= (s_axi_arid[7]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_61_4705321
  reg recovered_112_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__61_42cdcde = recovered_112_q;
  wire recovered_112_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_112_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_112_q == 1'b0))) recovered_112_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_112_q == (s_axi_arid[8])))) recovered_112_q <= (s_axi_arid[8]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_62_a5f2c02
  reg recovered_113_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__62_5bcd135 = recovered_113_q;
  wire recovered_113_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_113_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_113_q == 1'b0))) recovered_113_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_113_q == (s_axi_arid[9])))) recovered_113_q <= (s_axi_arid[9]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_63_a4fe3d0
  reg recovered_114_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__63_bee6e3d = recovered_114_q;
  wire recovered_114_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_114_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_114_q == 1'b0))) recovered_114_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_114_q == (s_axi_arid[10])))) recovered_114_q <= (s_axi_arid[10]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_64_976996b
  reg recovered_115_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__64_1d37155 = recovered_115_q;
  wire recovered_115_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_115_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_115_q == 1'b0))) recovered_115_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_115_q == (s_axi_arid[11])))) recovered_115_q <= (s_axi_arid[11]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_6_8005d57
  reg recovered_116_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__6_e84291a = recovered_116_q;
  wire recovered_116_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_116_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_116_q == 1'b0))) recovered_116_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_116_q == (s_axi_araddr[6])))) recovered_116_q <= (s_axi_araddr[6]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_7_2a42553
  reg recovered_117_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__7_355ab42 = recovered_117_q;
  wire recovered_117_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_117_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_117_q == 1'b0))) recovered_117_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_117_q == (s_axi_araddr[7])))) recovered_117_q <= (s_axi_araddr[7]);
  end

  // Reconstructed LUT4: esc_wrap_boundary_axaddr_r_0__i_1__0_a9f9717
  assign esc_m_payload_i_reg_47__2_d1e0165 [0] = ((Q[36]) ? (Q[0]) : (((Q[35]) ? (Q[0]) : (((Q[0]) ? (~(Q[39])) : (1'b0))))));

  // Reconstructed LUT5: esc_wrap_boundary_axaddr_r_1__i_1__0_f8f6ce1
  assign esc_m_payload_i_reg_47__2_d1e0165 [1] = ((Q[39]) ? (((Q[35]) ? (((Q[1]) ? (Q[36]) : (1'b0))) : (((Q[1]) ? (((Q[40]) ? (Q[36]) : (1'b1))) : (1'b0))))) : (((Q[35]) ? (Q[1]) : (((Q[1]) ? (((Q[40]) ? (Q[36]) : (1'b1))) : (1'b0))))));

  // Reconstructed LUT6: esc_wrap_boundary_axaddr_r_2__i_1__0_af7243b
  assign esc_m_payload_i_reg_47__2_d1e0165 [2] = ((Q[39]) ? (((Q[35]) ? (((Q[36]) ? (Q[2]) : (((Q[2]) ? (~(Q[40])) : (1'b0))))) : (((Q[36]) ? (1'b0) : (((Q[2]) ? (~(Q[41])) : (1'b0))))))) : (((Q[35]) ? (((Q[36]) ? (Q[2]) : (((Q[2]) ? (~(Q[40])) : (1'b0))))) : (((Q[36]) ? (Q[2]) : (((Q[2]) ? (~(Q[41])) : (1'b0))))))));

  // Reconstructed LUT6: esc_wrap_boundary_axaddr_r_3__i_1__0_e907e20
  assign esc_m_payload_i_reg_47__2_d1e0165 [3] = ((esc_wrap_boundary_axaddr_r_3__i_2__0_n_0_4441e0a) ? (1'b1) : (((Q[42]) ? (((Q[36]) ? (((Q[35]) ? (1'b0) : (((Q[3]) ? (~(Q[40])) : (1'b0))))) : (1'b0))) : (((Q[36]) ? (((Q[35]) ? (1'b0) : (((Q[3]) ? (~(Q[40])) : (1'b0))))) : (((Q[35]) ? (1'b0) : (Q[3]))))))));

  // Reconstructed LUT5: esc_wrap_boundary_axaddr_r_3__i_2__0_9531949
  assign esc_wrap_boundary_axaddr_r_3__i_2__0_n_0_4441e0a = ((Q[39]) ? (((Q[3]) ? (((Q[36]) ? (1'b0) : (((Q[35]) ? (~(Q[41])) : (1'b0))))) : (1'b0))) : (((Q[3]) ? (((Q[36]) ? (Q[35]) : (((Q[35]) ? (~(Q[41])) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_wrap_boundary_axaddr_r_4__i_1__0_52fe9b5
  assign esc_m_payload_i_reg_47__2_d1e0165 [4] = ((Q[40]) ? (((Q[35]) ? (((Q[36]) ? (1'b0) : (((Q[4]) ? (~(Q[42])) : (1'b0))))) : (((Q[36]) ? (((Q[4]) ? (~(Q[41])) : (1'b0))) : (Q[4]))))) : (((Q[35]) ? (((Q[36]) ? (Q[4]) : (((Q[4]) ? (~(Q[42])) : (1'b0))))) : (((Q[36]) ? (((Q[4]) ? (~(Q[41])) : (1'b0))) : (Q[4]))))));

  // Reconstructed LUT5: esc_wrap_boundary_axaddr_r_5__i_1__0_adc6c24
  assign esc_m_payload_i_reg_47__2_d1e0165 [5] = ((Q[41]) ? (((Q[35]) ? (((Q[5]) ? (~(Q[36])) : (1'b0))) : (((Q[5]) ? (((Q[42]) ? (~(Q[36])) : (1'b1))) : (1'b0))))) : (((Q[35]) ? (Q[5]) : (((Q[5]) ? (((Q[42]) ? (~(Q[36])) : (1'b1))) : (1'b0))))));

  // Reconstructed LUT4: esc_wrap_boundary_axaddr_r_6__i_1__0_f3a2eb3
  assign esc_m_payload_i_reg_47__2_d1e0165 [6] = ((Q[36]) ? (((Q[35]) ? (((Q[6]) ? (~(Q[42])) : (1'b0))) : (Q[6]))) : (Q[6]));

  // Reconstructed LUT6: esc_wrap_cnt_r_2__i_1__0_35a0cee
  assign esc_wrap_second_len_r_reg_2_01b34aa [0] = ((esc_wrap_second_len_r_reg_3_130d984 [2]) ? (((esc_wrap_second_len_r_reg_3__1_e9d1a95 [0]) ? (((esc_m_payload_i_reg_44__1_a8cd662) ? (((esc_m_payload_i_reg_44__0_3e7cb03) ? (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (1'b1) : (~(esc_wrap_second_len_r_reg_3_130d984 [1])))) : (1'b1))) : (((esc_m_payload_i_reg_44__0_3e7cb03) ? (~(esc_wrap_second_len_r_reg_3_130d984 [1])) : (1'b1))))) : (((esc_m_payload_i_reg_44__1_a8cd662) ? (1'b1) : (((esc_m_payload_i_reg_44__0_3e7cb03) ? (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (~(esc_wrap_second_len_r_reg_3_130d984 [1])) : (1'b1))) : (1'b1))))))) : (((esc_wrap_second_len_r_reg_3__1_e9d1a95 [0]) ? (((esc_m_payload_i_reg_44__1_a8cd662) ? (((esc_m_payload_i_reg_44__0_3e7cb03) ? (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (1'b0) : (esc_wrap_second_len_r_reg_3_130d984 [1]))) : (1'b0))) : (((esc_m_payload_i_reg_44__0_3e7cb03) ? (esc_wrap_second_len_r_reg_3_130d984 [1]) : (1'b0))))) : (((esc_m_payload_i_reg_44__1_a8cd662) ? (1'b0) : (((esc_m_payload_i_reg_44__0_3e7cb03) ? (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (esc_wrap_second_len_r_reg_3_130d984 [1]) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT4: esc_wrap_cnt_r_2__i_2__0_1e78ed4
  assign esc_m_payload_i_reg_44__0_3e7cb03 = ((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (1'b1) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (1'b1) : (((esc_m_payload_i_reg_47__1_6188148) ? (1'b1) : (esc_m_payload_i_reg_44__1_a8cd662))))));

  // Reconstructed LUT4: esc_wrap_cnt_r_3__i_1__0_d0e0a27
  assign esc_wrap_second_len_r_reg_2_01b34aa [1] = ((esc_wrap_second_len_r_reg_3_130d984 [3]) ? (((esc_wrap_second_len_r_reg_3_130d984 [1]) ? (((esc_wrap_cnt_r_3__i_2__0_n_0_172f9eb) ? (1'b1) : (~(esc_wrap_second_len_r_reg_3_130d984 [2])))) : (1'b1))) : (((esc_wrap_second_len_r_reg_3_130d984 [1]) ? (((esc_wrap_cnt_r_3__i_2__0_n_0_172f9eb) ? (1'b0) : (esc_wrap_second_len_r_reg_3_130d984 [2]))) : (1'b0))));

  // Reconstructed LUT6: esc_wrap_cnt_r_3__i_2__0_8d0629a
  assign esc_wrap_cnt_r_3__i_2__0_n_0_172f9eb = ((esc_wrap_second_len_r_reg_3__1_e9d1a95 [0]) ? (((esc_m_payload_i_reg_44__1_a8cd662) ? (esc_wrap_second_len_r_reg_3__0_61735c7) : (((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (1'b0) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (1'b0) : (~(esc_m_payload_i_reg_47__1_6188148)))))))) : (((esc_m_payload_i_reg_44__1_a8cd662) ? (1'b1) : (((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (~(esc_wrap_second_len_r_reg_3__0_61735c7)) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (~(esc_wrap_second_len_r_reg_3__0_61735c7)) : (((esc_m_payload_i_reg_47__1_6188148) ? (~(esc_wrap_second_len_r_reg_3__0_61735c7)) : (1'b1))))))))));

  // Reconstructed LUT6: esc_wrap_second_len_r_0__i_1__0_e96f1d6
  assign esc_wrap_second_len_r_reg_3_130d984 [0] = ((esc_wrap_second_len_r_reg_3__0_61735c7) ? (((esc_m_payload_i_reg_47__1_6188148) ? (~(esc_m_payload_i_reg_44__1_a8cd662)) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (~(esc_m_payload_i_reg_44__1_a8cd662)) : (((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (~(esc_m_payload_i_reg_44__1_a8cd662)) : (1'b0))))))) : (esc_wrap_second_len_r_reg_3__1_e9d1a95 [0]));

  // Reconstructed LUT6: esc_wrap_second_len_r_1__i_1__0_2658ff6
  assign esc_wrap_second_len_r_reg_3_130d984 [1] = ((esc_FSM_sequential_state_reg_1_aa5780a) ? (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (esc_m_payload_i_reg_44__1_a8cd662) : (esc_wrap_second_len_r_reg_3__1_e9d1a95 [1]))) : (((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (~(esc_m_payload_i_reg_44__1_a8cd662)) : (esc_wrap_second_len_r_reg_3__1_e9d1a95 [1]))) : (((esc_m_payload_i_reg_47__1_6188148) ? (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (~(esc_m_payload_i_reg_44__1_a8cd662)) : (esc_wrap_second_len_r_reg_3__1_e9d1a95 [1]))) : (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (1'b0) : (esc_wrap_second_len_r_reg_3__1_e9d1a95 [1]))))))));

  // Reconstructed LUT6: esc_wrap_second_len_r_2__i_1__0_91beb96
  assign esc_wrap_second_len_r_reg_3_130d984 [2] = ((esc_wrap_second_len_r_reg_3__0_61735c7) ? (((esc_m_payload_i_reg_44__1_a8cd662) ? (esc_FSM_sequential_state_reg_1__0_5c93d31) : (((esc_m_payload_i_reg_47__1_6188148) ? (((esc_FSM_sequential_state_reg_1_aa5780a) ? (esc_FSM_sequential_state_reg_1__0_5c93d31) : (~(esc_FSM_sequential_state_reg_1__0_5c93d31)))) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (esc_FSM_sequential_state_reg_1__0_5c93d31) : (1'b0))))))) : (esc_wrap_second_len_r_reg_3__1_e9d1a95 [2]));

  // Reconstructed LUT6: esc_wrap_second_len_r_3__i_1__0_df501c2
  assign esc_wrap_second_len_r_reg_3_130d984 [3] = ((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (esc_m_payload_i_reg_47__1_6188148) : (esc_wrap_second_len_r_reg_3__1_e9d1a95 [3]))) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (esc_m_payload_i_reg_47__1_6188148) : (esc_wrap_second_len_r_reg_3__1_e9d1a95 [3]))) : (((esc_m_payload_i_reg_44__1_a8cd662) ? (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (esc_m_payload_i_reg_47__1_6188148) : (esc_wrap_second_len_r_reg_3__1_e9d1a95 [3]))) : (((esc_wrap_second_len_r_reg_3__0_61735c7) ? (1'b0) : (esc_wrap_second_len_r_reg_3__1_e9d1a95 [3]))))))));

endmodule

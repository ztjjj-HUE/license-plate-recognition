// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_register_slice_v2_1_22_axic_register_slice_0
   (s_ready_i_reg_0,
    esc_aresetn_d_reg_0__0_7ec703c ,
    m_valid_i_reg_0,
    S,
    esc_m_payload_i_reg_64__0_7cd5a09 ,
    esc_axaddr_wrap_reg_3_f9d1eab ,
    axaddr_incr,
    esc_m_payload_i_reg_47__0_fbbb04b ,
    D,
    esc_wrap_second_len_r_reg_3_130d984 ,
    esc_m_payload_i_reg_44__0_3e7cb03 ,
    esc_m_payload_i_reg_44__1_a8cd662 ,
    esc_m_payload_i_reg_47__1_6188148 ,
    esc_FSM_sequential_state_reg_1_aa5780a ,
    esc_FSM_sequential_state_reg_1__0_5c93d31 ,
    esc_m_payload_i_reg_47__2_d1e0165 ,
    m_axi_awaddr,
    esc_aresetn_d_reg_0__1_e5ad447 ,
    aclk,
    m_valid_i_reg_1,
    aresetn,
    Q,
    esc_m_axi_awaddr_11_2270491 ,
    b_push,
    s_axi_awvalid,
    esc_axaddr_incr_reg_3_2fa58c8 ,
    esc_wrap_second_len_r_reg_2_01b34aa ,
    esc_wrap_second_len_r_reg_3__0_61735c7 ,
    esc_axaddr_offset_r_reg_0_a3138f8 ,
    esc_axaddr_offset_r_reg_3_9b4a3fc ,
    s_axi_awid,
    s_axi_awlen,
    s_axi_awburst,
    s_axi_awsize,
    s_axi_awprot,
    s_axi_awaddr,
    esc_m_axi_awaddr_11__0_1b007f9 ,
    sel_first_1,
    sel_first,
    E);
  output s_ready_i_reg_0;
  output esc_aresetn_d_reg_0__0_7ec703c ;
  output m_valid_i_reg_0;
  output [1:0]S;
  output [58:0]esc_m_payload_i_reg_64__0_7cd5a09 ;
  output [1:0]esc_axaddr_wrap_reg_3_f9d1eab ;
  output [11:0]axaddr_incr;
  output esc_m_payload_i_reg_47__0_fbbb04b ;
  output [1:0]D;
  output [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  output esc_m_payload_i_reg_44__0_3e7cb03 ;
  output esc_m_payload_i_reg_44__1_a8cd662 ;
  output esc_m_payload_i_reg_47__1_6188148 ;
  output esc_FSM_sequential_state_reg_1_aa5780a ;
  output esc_FSM_sequential_state_reg_1__0_5c93d31 ;
  output [6:0]esc_m_payload_i_reg_47__2_d1e0165 ;
  output [11:0]m_axi_awaddr;
  output esc_aresetn_d_reg_0__1_e5ad447 ;
  input aclk;
  input m_valid_i_reg_1;
  input aresetn;
  input [11:0]Q;
  input [11:0]esc_m_axi_awaddr_11_2270491 ;
  input b_push;
  input s_axi_awvalid;
  input [3:0]esc_axaddr_incr_reg_3_2fa58c8 ;
  input esc_wrap_second_len_r_reg_2_01b34aa ;
  input [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  input [1:0]esc_axaddr_offset_r_reg_0_a3138f8 ;
  input [3:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  input [11:0]s_axi_awid;
  input [7:0]s_axi_awlen;
  input [1:0]s_axi_awburst;
  input [1:0]s_axi_awsize;
  input [2:0]s_axi_awprot;
  input [31:0]s_axi_awaddr;
  input esc_m_axi_awaddr_11__0_1b007f9 ;
  input sel_first_1;
  input sel_first;
  input [0:0]E;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [1:0]D;
  wire [0:0]E;
  wire esc_FSM_sequential_state_reg_1_aa5780a ;
  wire esc_FSM_sequential_state_reg_1__0_5c93d31 ;
  wire [11:0]Q;
  wire [1:0]S;
  wire aclk;
  wire aresetn;
  wire esc_aresetn_d_reg_0__0_7ec703c ;
  wire esc_aresetn_d_reg_0__1_e5ad447 ;
  wire esc_aresetn_d_reg_n_0__0_417d18e ;
  wire [11:0]axaddr_incr;
  wire esc_axaddr_incr_3__i_4_n_0_cae8ab0 ;
  wire esc_axaddr_incr_3__i_5_n_0_308b2a4 ;
  wire esc_axaddr_incr_3__i_6_n_0_44cb3ec ;
  wire [3:0]esc_axaddr_incr_reg_3_2fa58c8 ;
  wire esc_axaddr_incr_reg_3__i_2_n_0_68e3ca1 ;
  wire esc_axaddr_offset_r_0__i_2_n_0_ab67376 ;
  wire esc_axaddr_offset_r_1__i_2_n_0_05207cf ;
  wire esc_axaddr_offset_r_1__i_3_n_0_96f5b58 ;
  wire esc_axaddr_offset_r_2__i_2_n_0_9eb00bc ;
  wire esc_axaddr_offset_r_2__i_3_n_0_d6e51b3 ;
  wire esc_axaddr_offset_r_3__i_2_n_0_c23290a ;
  wire [1:0]esc_axaddr_offset_r_reg_0_a3138f8 ;
  wire [3:0]esc_axaddr_offset_r_reg_3_9b4a3fc ;
  wire [1:0]esc_axaddr_wrap_reg_3_f9d1eab ;
  wire b_push;
  wire [11:0]m_axi_awaddr;
  wire [11:0]esc_m_axi_awaddr_11_2270491 ;
  wire esc_m_axi_awaddr_11__0_1b007f9 ;
  wire esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094 ;
  wire esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a ;
  wire esc_m_payload_i_reg_44__0_3e7cb03 ;
  wire esc_m_payload_i_reg_44__1_a8cd662 ;
  wire esc_m_payload_i_reg_47__0_fbbb04b ;
  wire esc_m_payload_i_reg_47__1_6188148 ;
  wire [6:0]esc_m_payload_i_reg_47__2_d1e0165 ;
  wire [58:0]esc_m_payload_i_reg_64__0_7cd5a09 ;
  wire m_valid_i_i_1__1_n_0;
  wire m_valid_i_reg_0;
  wire m_valid_i_reg_1;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [11:0]s_axi_awid;
  wire [7:0]s_axi_awlen;
  wire [1:0]s_axi_awsize;
  wire s_axi_awvalid;
  wire s_ready_i0;
  wire s_ready_i_reg_0;
  wire sel_first;
  wire sel_first_1;
  wire [64:0]skid_buffer;
  wire esc_skid_buffer_reg_n_0__0_33bcee8 ;
  wire esc_skid_buffer_reg_n_0__1_71722f5 ;
  wire esc_skid_buffer_reg_n_0__2_21e7f94 ;
  wire esc_skid_buffer_reg_n_0__35_27754b0 ;
  wire esc_skid_buffer_reg_n_0__36_49139cd ;
  wire esc_skid_buffer_reg_n_0__38_66da518 ;
  wire esc_skid_buffer_reg_n_0__39_753eaf3 ;
  wire esc_skid_buffer_reg_n_0__3_2d17305 ;
  wire esc_skid_buffer_reg_n_0__44_4973a46 ;
  wire esc_skid_buffer_reg_n_0__45_ae6ce43 ;
  wire esc_skid_buffer_reg_n_0__46_e862893 ;
  wire esc_skid_buffer_reg_n_0__47_1ce944e ;
  wire esc_skid_buffer_reg_n_0__4_31058d6 ;
  wire esc_skid_buffer_reg_n_0__53_bc11961 ;
  wire esc_skid_buffer_reg_n_0__54_de97db8 ;
  wire esc_skid_buffer_reg_n_0__55_b96df6e ;
  wire esc_skid_buffer_reg_n_0__56_b9b25f2 ;
  wire esc_skid_buffer_reg_n_0__57_97d47d8 ;
  wire esc_skid_buffer_reg_n_0__58_55e72f7 ;
  wire esc_skid_buffer_reg_n_0__59_4478807 ;
  wire esc_skid_buffer_reg_n_0__5_f837c66 ;
  wire esc_skid_buffer_reg_n_0__60_b805d41 ;
  wire esc_skid_buffer_reg_n_0__61_42cdcde ;
  wire esc_skid_buffer_reg_n_0__62_5bcd135 ;
  wire esc_skid_buffer_reg_n_0__63_bee6e3d ;
  wire esc_skid_buffer_reg_n_0__64_1d37155 ;
  wire esc_skid_buffer_reg_n_0__6_e84291a ;
  wire esc_skid_buffer_reg_n_0__7_355ab42 ;
  wire esc_wrap_boundary_axaddr_r_3__i_2_n_0_4685ec5 ;
  wire esc_wrap_cnt_r_3__i_2_n_0_1d56281 ;
  wire esc_wrap_second_len_r_reg_2_01b34aa ;
  wire [3:0]esc_wrap_second_len_r_reg_3_130d984 ;
  wire [3:0]esc_wrap_second_len_r_reg_3__0_61735c7 ;
  wire [3:0]esc_NLW_axaddr_incr_reg_3__i_2_CO_UNCONNECTED_3753592 ;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT2: esc_aresetn_d_1__inv_i_1_85da44f
  assign esc_aresetn_d_reg_0__1_e5ad447 = ((aresetn) ? (~(esc_aresetn_d_reg_n_0__0_417d18e)) : (1'b1));

  // Reconstructed FDRE: esc_aresetn_d_reg_0_e1dde1e
  reg recovered_4_q = 1'b0;
  assign esc_aresetn_d_reg_n_0__0_417d18e = recovered_4_q;
  wire recovered_4_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_4_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (aresetn)))) recovered_4_q <= (aresetn);
  end

  // Reconstructed LUT3: esc_axaddr_incr_3__i_11_486b39f
  assign S[1] = ((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (~(Q[3])) : (Q[3]))) : (Q[3]));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_14_8394cb7
  assign S[0] = ((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (Q[0]) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (Q[0]) : (~(Q[0])))));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_4_02f1eb9
  assign esc_axaddr_incr_3__i_4_n_0_cae8ab0 = ((esc_m_payload_i_reg_64__0_7cd5a09 [2]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [36])) : (1'b1))) : (1'b0));

  // Reconstructed LUT2: esc_axaddr_incr_3__i_5_3a20a54
  assign esc_axaddr_incr_3__i_5_n_0_308b2a4 = ((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b0) : (esc_m_payload_i_reg_64__0_7cd5a09 [1]));

  // Reconstructed LUT3: esc_axaddr_incr_3__i_6_35236ee
  assign esc_axaddr_incr_3__i_6_n_0_44cb3ec = ((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b0) : (esc_m_payload_i_reg_64__0_7cd5a09 [0]))));

  // Reconstructed CARRY4: esc_axaddr_incr_reg_3__i_2_11858d9
  wire [3:0] recovered_10_co, recovered_10_o, recovered_10_s, recovered_10_di;
  assign recovered_10_s = esc_axaddr_incr_reg_3_2fa58c8;
  assign recovered_10_di = {esc_m_payload_i_reg_64__0_7cd5a09 [3],esc_axaddr_incr_3__i_4_n_0_cae8ab0 ,esc_axaddr_incr_3__i_5_n_0_308b2a4 ,esc_axaddr_incr_3__i_6_n_0_44cb3ec };
  wire recovered_10_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_10_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_10_o[0] = recovered_10_s[0] ^ (recovered_10_ci || recovered_10_cy);
  assign recovered_10_co[0] = (recovered_10_s[0] & (recovered_10_ci || recovered_10_cy)) | (~recovered_10_s[0] & recovered_10_di[0]);
  assign recovered_10_o[1] = recovered_10_s[1] ^ recovered_10_co[0];
  assign recovered_10_co[1] = (recovered_10_s[1] & recovered_10_co[0]) | (~recovered_10_s[1] & recovered_10_di[1]);
  assign recovered_10_o[2] = recovered_10_s[2] ^ recovered_10_co[1];
  assign recovered_10_co[2] = (recovered_10_s[2] & recovered_10_co[1]) | (~recovered_10_s[2] & recovered_10_di[2]);
  assign recovered_10_o[3] = recovered_10_s[3] ^ recovered_10_co[2];
  assign recovered_10_co[3] = (recovered_10_s[3] & recovered_10_co[2]) | (~recovered_10_s[3] & recovered_10_di[3]);
  assign {esc_axaddr_incr_reg_3__i_2_n_0_68e3ca1 ,esc_NLW_axaddr_incr_reg_3__i_2_CO_UNCONNECTED_3753592 [2:0]} = recovered_10_co;
  assign axaddr_incr[3:0] = recovered_10_o;

  // Reconstructed CARRY4: esc_axaddr_incr_reg_7__i_2_2537394
  wire [3:0] recovered_11_co, recovered_11_o, recovered_11_s, recovered_11_di;
  assign recovered_11_s = esc_m_payload_i_reg_64__0_7cd5a09 [7:4];
  assign recovered_11_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_11_ci = ((esc_axaddr_incr_reg_3__i_2_n_0_68e3ca1) !== 1'bz) && (esc_axaddr_incr_reg_3__i_2_n_0_68e3ca1);
  wire recovered_11_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_11_o[0] = recovered_11_s[0] ^ (recovered_11_ci || recovered_11_cy);
  assign recovered_11_co[0] = (recovered_11_s[0] & (recovered_11_ci || recovered_11_cy)) | (~recovered_11_s[0] & recovered_11_di[0]);
  assign recovered_11_o[1] = recovered_11_s[1] ^ recovered_11_co[0];
  assign recovered_11_co[1] = (recovered_11_s[1] & recovered_11_co[0]) | (~recovered_11_s[1] & recovered_11_di[1]);
  assign recovered_11_o[2] = recovered_11_s[2] ^ recovered_11_co[1];
  assign recovered_11_co[2] = (recovered_11_s[2] & recovered_11_co[1]) | (~recovered_11_s[2] & recovered_11_di[2]);
  assign recovered_11_o[3] = recovered_11_s[3] ^ recovered_11_co[2];
  assign recovered_11_co[3] = (recovered_11_s[3] & recovered_11_co[2]) | (~recovered_11_s[3] & recovered_11_di[3]);
  assign axaddr_incr[7:4] = recovered_11_o;

  // Reconstructed LUT6: esc_axaddr_offset_r_0__i_1_11ebaa2
  assign esc_m_payload_i_reg_44__1_a8cd662 = ((esc_axaddr_offset_r_reg_3_9b4a3fc [0]) ? (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [0]) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [1]) ? (1'b1) : (((esc_m_payload_i_reg_64__0_7cd5a09 [39]) ? (esc_axaddr_offset_r_0__i_2_n_0_ab67376) : (1'b0))))) : (1'b1))) : (1'b1))) : (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [0]) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [1]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [39]) ? (esc_axaddr_offset_r_0__i_2_n_0_ab67376) : (1'b0))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_axaddr_offset_r_0__i_2_46e7fff
  assign esc_axaddr_offset_r_0__i_2_n_0_ab67376 = ((esc_m_payload_i_reg_64__0_7cd5a09 [2]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [3]) : (esc_m_payload_i_reg_64__0_7cd5a09 [1]))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b1) : (esc_m_payload_i_reg_64__0_7cd5a09 [0]))))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [3]) : (esc_m_payload_i_reg_64__0_7cd5a09 [1]))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b0) : (esc_m_payload_i_reg_64__0_7cd5a09 [0]))))));

  // Reconstructed LUT6: esc_axaddr_offset_r_1__i_1_429cb7b
  assign esc_FSM_sequential_state_reg_1_aa5780a = ((esc_axaddr_offset_r_reg_3_9b4a3fc [1]) ? (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [0]) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [1]) ? (1'b1) : (((esc_axaddr_offset_r_1__i_3_n_0_96f5b58) ? (1'b1) : (esc_axaddr_offset_r_1__i_2_n_0_05207cf))))) : (1'b1))) : (1'b1))) : (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [0]) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [1]) ? (1'b0) : (((esc_axaddr_offset_r_1__i_3_n_0_96f5b58) ? (1'b1) : (esc_axaddr_offset_r_1__i_2_n_0_05207cf))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_axaddr_offset_r_1__i_2_82bdc22
  assign esc_axaddr_offset_r_1__i_2_n_0_05207cf = ((esc_m_payload_i_reg_64__0_7cd5a09 [2]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [40]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b1) : (esc_m_payload_i_reg_64__0_7cd5a09 [1]))))) : (1'b0))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [40]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b0) : (esc_m_payload_i_reg_64__0_7cd5a09 [1]))))) : (1'b0))));

  // Reconstructed LUT5: esc_axaddr_offset_r_1__i_3_b4da14f
  assign esc_axaddr_offset_r_1__i_3_n_0_96f5b58 = ((esc_m_payload_i_reg_64__0_7cd5a09 [4]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [40]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b1) : (esc_m_payload_i_reg_64__0_7cd5a09 [3]))) : (1'b0))) : (1'b0))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [40]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b0) : (esc_m_payload_i_reg_64__0_7cd5a09 [3]))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_axaddr_offset_r_2__i_1_141c84d
  assign esc_FSM_sequential_state_reg_1__0_5c93d31 = ((esc_axaddr_offset_r_reg_3_9b4a3fc [2]) ? (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [0]) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [1]) ? (1'b1) : (((esc_axaddr_offset_r_2__i_3_n_0_d6e51b3) ? (1'b1) : (esc_axaddr_offset_r_2__i_2_n_0_9eb00bc))))) : (1'b1))) : (1'b1))) : (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [0]) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [1]) ? (1'b0) : (((esc_axaddr_offset_r_2__i_3_n_0_d6e51b3) ? (1'b1) : (esc_axaddr_offset_r_2__i_2_n_0_9eb00bc))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_axaddr_offset_r_2__i_2_bbeff55
  assign esc_axaddr_offset_r_2__i_2_n_0_9eb00bc = ((esc_m_payload_i_reg_64__0_7cd5a09 [3]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [41]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b1) : (esc_m_payload_i_reg_64__0_7cd5a09 [2]))))) : (1'b0))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [41]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b0) : (esc_m_payload_i_reg_64__0_7cd5a09 [2]))))) : (1'b0))));

  // Reconstructed LUT5: esc_axaddr_offset_r_2__i_3_657b81e
  assign esc_axaddr_offset_r_2__i_3_n_0_d6e51b3 = ((esc_m_payload_i_reg_64__0_7cd5a09 [5]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [41]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b1) : (esc_m_payload_i_reg_64__0_7cd5a09 [4]))) : (1'b0))) : (1'b0))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [41]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b0) : (esc_m_payload_i_reg_64__0_7cd5a09 [4]))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_axaddr_offset_r_3__i_1_d3d7282
  assign esc_m_payload_i_reg_47__1_6188148 = ((esc_axaddr_offset_r_reg_3_9b4a3fc [3]) ? (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [0]) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [1]) ? (1'b1) : (((esc_m_payload_i_reg_64__0_7cd5a09 [42]) ? (esc_axaddr_offset_r_3__i_2_n_0_c23290a) : (1'b0))))) : (1'b1))) : (1'b1))) : (((m_valid_i_reg_0) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [0]) ? (((esc_axaddr_offset_r_reg_0_a3138f8 [1]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [42]) ? (esc_axaddr_offset_r_3__i_2_n_0_c23290a) : (1'b0))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_axaddr_offset_r_3__i_2_f25b65a
  assign esc_axaddr_offset_r_3__i_2_n_0_c23290a = ((esc_m_payload_i_reg_64__0_7cd5a09 [5]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [6]) : (esc_m_payload_i_reg_64__0_7cd5a09 [4]))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b1) : (esc_m_payload_i_reg_64__0_7cd5a09 [3]))))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [6]) : (esc_m_payload_i_reg_64__0_7cd5a09 [4]))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b0) : (esc_m_payload_i_reg_64__0_7cd5a09 [3]))))));

  // Reconstructed LUT3: esc_axaddr_wrap_3__i_3_0c54baf
  assign esc_axaddr_wrap_reg_3_f9d1eab [1] = ((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (~(esc_m_axi_awaddr_11_2270491 [3])) : (esc_m_axi_awaddr_11_2270491 [3]))) : (esc_m_axi_awaddr_11_2270491 [3]));

  // Reconstructed LUT3: esc_axaddr_wrap_3__i_6_ea2161e
  assign esc_axaddr_wrap_reg_3_f9d1eab [0] = ((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (esc_m_axi_awaddr_11_2270491 [0]) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (esc_m_axi_awaddr_11_2270491 [0]) : (~(esc_m_axi_awaddr_11_2270491 [0])))));

  // Reconstructed LUT6: esc_m_axi_awaddr_0__INST_0_b8aa2f4
  assign m_axi_awaddr[0] = ((esc_m_axi_awaddr_11__0_1b007f9) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [0]) ? (1'b1) : (((Q[0]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [0]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [0]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))))) : (((Q[0]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [0]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [0]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))));

  // Reconstructed LUT2: esc_m_axi_awaddr_11__INST_0_i_1_50757f3
  assign esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094 = ((sel_first) ? (1'b0) : (esc_m_payload_i_reg_64__0_7cd5a09 [38]));

  // Reconstructed LUT3: esc_m_axi_awaddr_11__INST_0_i_2_5f75e7e
  assign esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a = ((esc_m_payload_i_reg_64__0_7cd5a09 [38]) ? (1'b0) : (((sel_first_1) ? (1'b0) : (esc_m_payload_i_reg_64__0_7cd5a09 [37]))));

  // Reconstructed LUT6: esc_m_axi_awaddr_1__INST_0_01c30e1
  assign m_axi_awaddr[1] = ((esc_m_axi_awaddr_11__0_1b007f9) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [1]) ? (1'b1) : (((Q[1]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [1]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [1]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))))) : (((Q[1]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [1]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [1]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))));

  // Reconstructed LUT6: esc_m_axi_awaddr_2__INST_0_c4bb20a
  assign m_axi_awaddr[2] = ((esc_m_axi_awaddr_11__0_1b007f9) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [2]) ? (1'b1) : (((Q[2]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [2]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [2]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))))) : (((Q[2]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [2]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [2]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))));

  // Reconstructed LUT6: esc_m_axi_awaddr_3__INST_0_91a8902
  assign m_axi_awaddr[3] = ((esc_m_axi_awaddr_11__0_1b007f9) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [3]) ? (1'b1) : (((Q[3]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [3]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [3]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))))) : (((Q[3]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [3]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [3]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))));

  // Reconstructed LUT6: esc_m_axi_awaddr_4__INST_0_a298375
  assign m_axi_awaddr[4] = ((esc_m_axi_awaddr_11__0_1b007f9) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [4]) ? (1'b1) : (((Q[4]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [4]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [4]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))))) : (((Q[4]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [4]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [4]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))));

  // Reconstructed LUT6: esc_m_axi_awaddr_5__INST_0_e2bdcb8
  assign m_axi_awaddr[5] = ((esc_m_axi_awaddr_11__0_1b007f9) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [5]) ? (1'b1) : (((Q[5]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [5]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [5]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))))) : (((Q[5]) ? (((esc_m_axi_awaddr_11__INST_0_i_2_n_0_2aedb6a) ? (1'b1) : (((esc_m_axi_awaddr_11_2270491 [5]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))) : (((esc_m_axi_awaddr_11_2270491 [5]) ? (esc_m_axi_awaddr_11__INST_0_i_1_n_0_5c5f094) : (1'b0))))));

  // Reconstructed LUT3: esc_m_payload_i_0__i_1_9a04f66
  assign skid_buffer[0] = ((esc_skid_buffer_reg_n_0__0_33bcee8) ? (((s_ready_i_reg_0) ? (s_axi_awaddr[0]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awaddr[0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_1__i_1_a2f639b
  assign skid_buffer[1] = ((esc_skid_buffer_reg_n_0__1_71722f5) ? (((s_ready_i_reg_0) ? (s_axi_awaddr[1]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awaddr[1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_2__i_1_1f5e3e2
  assign skid_buffer[2] = ((esc_skid_buffer_reg_n_0__2_21e7f94) ? (((s_ready_i_reg_0) ? (s_axi_awaddr[2]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awaddr[2]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_35__i_1_fd1e002
  assign skid_buffer[35] = ((esc_skid_buffer_reg_n_0__35_27754b0) ? (((s_ready_i_reg_0) ? (s_axi_awsize[0]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awsize[0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_36__i_1_5da8a1f
  assign skid_buffer[36] = ((esc_skid_buffer_reg_n_0__36_49139cd) ? (((s_ready_i_reg_0) ? (s_axi_awsize[1]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awsize[1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_38__i_1_d56b9f4
  assign skid_buffer[38] = ((esc_skid_buffer_reg_n_0__38_66da518) ? (((s_ready_i_reg_0) ? (s_axi_awburst[0]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awburst[0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_39__i_1_76327b9
  assign skid_buffer[39] = ((esc_skid_buffer_reg_n_0__39_753eaf3) ? (((s_ready_i_reg_0) ? (s_axi_awburst[1]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awburst[1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_3__i_1_3f9c1ef
  assign skid_buffer[3] = ((esc_skid_buffer_reg_n_0__3_2d17305) ? (((s_ready_i_reg_0) ? (s_axi_awaddr[3]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awaddr[3]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_44__i_1_8ec846e
  assign skid_buffer[44] = ((esc_skid_buffer_reg_n_0__44_4973a46) ? (((s_ready_i_reg_0) ? (s_axi_awlen[0]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awlen[0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_45__i_1_7e49427
  assign skid_buffer[45] = ((esc_skid_buffer_reg_n_0__45_ae6ce43) ? (((s_ready_i_reg_0) ? (s_axi_awlen[1]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awlen[1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_46__i_1__0_aa5979e
  assign skid_buffer[46] = ((esc_skid_buffer_reg_n_0__46_e862893) ? (((s_ready_i_reg_0) ? (s_axi_awlen[2]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awlen[2]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_47__i_1_e49be76
  assign skid_buffer[47] = ((esc_skid_buffer_reg_n_0__47_1ce944e) ? (((s_ready_i_reg_0) ? (s_axi_awlen[3]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awlen[3]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_4__i_1_cc0c78d
  assign skid_buffer[4] = ((esc_skid_buffer_reg_n_0__4_31058d6) ? (((s_ready_i_reg_0) ? (s_axi_awaddr[4]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awaddr[4]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_53__i_1_3d963dd
  assign skid_buffer[53] = ((esc_skid_buffer_reg_n_0__53_bc11961) ? (((s_ready_i_reg_0) ? (s_axi_awid[0]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_54__i_1_5ce55cf
  assign skid_buffer[54] = ((esc_skid_buffer_reg_n_0__54_de97db8) ? (((s_ready_i_reg_0) ? (s_axi_awid[1]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_55__i_1_3f8f879
  assign skid_buffer[55] = ((esc_skid_buffer_reg_n_0__55_b96df6e) ? (((s_ready_i_reg_0) ? (s_axi_awid[2]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[2]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_56__i_1_644bcb8
  assign skid_buffer[56] = ((esc_skid_buffer_reg_n_0__56_b9b25f2) ? (((s_ready_i_reg_0) ? (s_axi_awid[3]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[3]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_57__i_1_9d6e8c8
  assign skid_buffer[57] = ((esc_skid_buffer_reg_n_0__57_97d47d8) ? (((s_ready_i_reg_0) ? (s_axi_awid[4]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[4]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_58__i_1_dd30da9
  assign skid_buffer[58] = ((esc_skid_buffer_reg_n_0__58_55e72f7) ? (((s_ready_i_reg_0) ? (s_axi_awid[5]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[5]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_59__i_1_ed215ee
  assign skid_buffer[59] = ((esc_skid_buffer_reg_n_0__59_4478807) ? (((s_ready_i_reg_0) ? (s_axi_awid[6]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[6]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_5__i_1_730bfba
  assign skid_buffer[5] = ((esc_skid_buffer_reg_n_0__5_f837c66) ? (((s_ready_i_reg_0) ? (s_axi_awaddr[5]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awaddr[5]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_60__i_1_5cac9ed
  assign skid_buffer[60] = ((esc_skid_buffer_reg_n_0__60_b805d41) ? (((s_ready_i_reg_0) ? (s_axi_awid[7]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[7]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_61__i_1_ed2f0a4
  assign skid_buffer[61] = ((esc_skid_buffer_reg_n_0__61_42cdcde) ? (((s_ready_i_reg_0) ? (s_axi_awid[8]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[8]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_62__i_1_ca7253d
  assign skid_buffer[62] = ((esc_skid_buffer_reg_n_0__62_5bcd135) ? (((s_ready_i_reg_0) ? (s_axi_awid[9]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[9]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_63__i_1_2a48760
  assign skid_buffer[63] = ((esc_skid_buffer_reg_n_0__63_bee6e3d) ? (((s_ready_i_reg_0) ? (s_axi_awid[10]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[10]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_64__i_1_da78704
  assign skid_buffer[64] = ((esc_skid_buffer_reg_n_0__64_1d37155) ? (((s_ready_i_reg_0) ? (s_axi_awid[11]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awid[11]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_6__i_1_b23b14a
  assign skid_buffer[6] = ((esc_skid_buffer_reg_n_0__6_e84291a) ? (((s_ready_i_reg_0) ? (s_axi_awaddr[6]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awaddr[6]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_7__i_1_ed4f532
  assign skid_buffer[7] = ((esc_skid_buffer_reg_n_0__7_355ab42) ? (((s_ready_i_reg_0) ? (s_axi_awaddr[7]) : (1'b1))) : (((s_ready_i_reg_0) ? (s_axi_awaddr[7]) : (1'b0))));

  // Reconstructed FDRE: esc_m_payload_i_reg_0_2f8d71c
  reg recovered_60_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [0] = recovered_60_q;
  wire recovered_60_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_60_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_60_q == 1'b0))) recovered_60_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_60_q == (skid_buffer[0])))) recovered_60_q <= (skid_buffer[0]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_1_a76cbaf
  reg recovered_61_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [1] = recovered_61_q;
  wire recovered_61_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_61_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_61_q == 1'b0))) recovered_61_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_61_q == (skid_buffer[1])))) recovered_61_q <= (skid_buffer[1]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_2_3bf2adb
  reg recovered_62_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [2] = recovered_62_q;
  wire recovered_62_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_62_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_62_q == 1'b0))) recovered_62_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_62_q == (skid_buffer[2])))) recovered_62_q <= (skid_buffer[2]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_35_235a12d
  reg recovered_63_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [35] = recovered_63_q;
  wire recovered_63_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_63_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_63_q == 1'b0))) recovered_63_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_63_q == (skid_buffer[35])))) recovered_63_q <= (skid_buffer[35]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_36_9854560
  reg recovered_64_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [36] = recovered_64_q;
  wire recovered_64_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_64_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_64_q == 1'b0))) recovered_64_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_64_q == (skid_buffer[36])))) recovered_64_q <= (skid_buffer[36]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_38_b34fad1
  reg recovered_65_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [37] = recovered_65_q;
  wire recovered_65_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_65_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_65_q == 1'b0))) recovered_65_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_65_q == (skid_buffer[38])))) recovered_65_q <= (skid_buffer[38]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_39_ea68878
  reg recovered_66_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [38] = recovered_66_q;
  wire recovered_66_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_66_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_66_q == 1'b0))) recovered_66_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_66_q == (skid_buffer[39])))) recovered_66_q <= (skid_buffer[39]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_3_3eab624
  reg recovered_67_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [3] = recovered_67_q;
  wire recovered_67_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_67_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_67_q == 1'b0))) recovered_67_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_67_q == (skid_buffer[3])))) recovered_67_q <= (skid_buffer[3]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_44_7279c72
  reg recovered_68_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [39] = recovered_68_q;
  wire recovered_68_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_68_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_68_q == 1'b0))) recovered_68_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_68_q == (skid_buffer[44])))) recovered_68_q <= (skid_buffer[44]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_45_fff3a3b
  reg recovered_69_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [40] = recovered_69_q;
  wire recovered_69_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_69_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_69_q == 1'b0))) recovered_69_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_69_q == (skid_buffer[45])))) recovered_69_q <= (skid_buffer[45]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_46_022e045
  reg recovered_70_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [41] = recovered_70_q;
  wire recovered_70_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_70_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_70_q == 1'b0))) recovered_70_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_70_q == (skid_buffer[46])))) recovered_70_q <= (skid_buffer[46]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_47_8c317be
  reg recovered_71_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [42] = recovered_71_q;
  wire recovered_71_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_71_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_71_q == 1'b0))) recovered_71_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_71_q == (skid_buffer[47])))) recovered_71_q <= (skid_buffer[47]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_4_60ef705
  reg recovered_72_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [4] = recovered_72_q;
  wire recovered_72_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_72_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_72_q == 1'b0))) recovered_72_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_72_q == (skid_buffer[4])))) recovered_72_q <= (skid_buffer[4]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_53_5057f9f
  reg recovered_73_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [47] = recovered_73_q;
  wire recovered_73_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_73_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_73_q == 1'b0))) recovered_73_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_73_q == (skid_buffer[53])))) recovered_73_q <= (skid_buffer[53]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_54_9d2ea8e
  reg recovered_74_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [48] = recovered_74_q;
  wire recovered_74_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_74_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_74_q == 1'b0))) recovered_74_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_74_q == (skid_buffer[54])))) recovered_74_q <= (skid_buffer[54]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_55_5d43526
  reg recovered_75_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [49] = recovered_75_q;
  wire recovered_75_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_75_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_75_q == 1'b0))) recovered_75_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_75_q == (skid_buffer[55])))) recovered_75_q <= (skid_buffer[55]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_56_bdf5998
  reg recovered_76_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [50] = recovered_76_q;
  wire recovered_76_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_76_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_76_q == 1'b0))) recovered_76_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_76_q == (skid_buffer[56])))) recovered_76_q <= (skid_buffer[56]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_57_07cb7bd
  reg recovered_77_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [51] = recovered_77_q;
  wire recovered_77_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_77_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_77_q == 1'b0))) recovered_77_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_77_q == (skid_buffer[57])))) recovered_77_q <= (skid_buffer[57]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_58_b00fbf5
  reg recovered_78_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [52] = recovered_78_q;
  wire recovered_78_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_78_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_78_q == 1'b0))) recovered_78_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_78_q == (skid_buffer[58])))) recovered_78_q <= (skid_buffer[58]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_59_63248e5
  reg recovered_79_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [53] = recovered_79_q;
  wire recovered_79_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_79_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_79_q == 1'b0))) recovered_79_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_79_q == (skid_buffer[59])))) recovered_79_q <= (skid_buffer[59]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_5_6200800
  reg recovered_80_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [5] = recovered_80_q;
  wire recovered_80_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_80_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_80_q == 1'b0))) recovered_80_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_80_q == (skid_buffer[5])))) recovered_80_q <= (skid_buffer[5]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_60_a2bf4d1
  reg recovered_81_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [54] = recovered_81_q;
  wire recovered_81_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_81_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_81_q == 1'b0))) recovered_81_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_81_q == (skid_buffer[60])))) recovered_81_q <= (skid_buffer[60]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_61_833d8b1
  reg recovered_82_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [55] = recovered_82_q;
  wire recovered_82_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_82_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_82_q == 1'b0))) recovered_82_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_82_q == (skid_buffer[61])))) recovered_82_q <= (skid_buffer[61]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_62_cbed6bd
  reg recovered_83_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [56] = recovered_83_q;
  wire recovered_83_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_83_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_83_q == 1'b0))) recovered_83_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_83_q == (skid_buffer[62])))) recovered_83_q <= (skid_buffer[62]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_63_e78dc9f
  reg recovered_84_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [57] = recovered_84_q;
  wire recovered_84_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_84_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_84_q == 1'b0))) recovered_84_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_84_q == (skid_buffer[63])))) recovered_84_q <= (skid_buffer[63]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_64_2ba99a2
  reg recovered_85_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [58] = recovered_85_q;
  wire recovered_85_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_85_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_85_q == 1'b0))) recovered_85_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_85_q == (skid_buffer[64])))) recovered_85_q <= (skid_buffer[64]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_6_8d56399
  reg recovered_86_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [6] = recovered_86_q;
  wire recovered_86_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_86_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_86_q == 1'b0))) recovered_86_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_86_q == (skid_buffer[6])))) recovered_86_q <= (skid_buffer[6]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_7_ba4380d
  reg recovered_87_q = 1'b0;
  assign esc_m_payload_i_reg_64__0_7cd5a09 [7] = recovered_87_q;
  wire recovered_87_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_87_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_87_q == 1'b0))) recovered_87_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_87_q == (skid_buffer[7])))) recovered_87_q <= (skid_buffer[7]);
  end

  // Reconstructed LUT4: m_valid_i_i_1__1
  assign m_valid_i_i_1__1_n_0 = ((s_ready_i_reg_0) ? (((s_axi_awvalid) ? (1'b1) : (((m_valid_i_reg_0) ? (~(b_push)) : (1'b0))))) : (1'b1));

  // Reconstructed FDRE: m_valid_i_reg
  reg recovered_89_q = 1'b0;
  assign m_valid_i_reg_0 = recovered_89_q;
  wire recovered_89_reset = ((m_valid_i_reg_1)) && ((m_valid_i_reg_1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_89_reset || (((m_valid_i_reg_1) === 1'bx) && (recovered_89_q == 1'b0))) recovered_89_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_89_q == (m_valid_i_i_1__1_n_0)))) recovered_89_q <= (m_valid_i_i_1__1_n_0);
  end

  // Reconstructed LUT5: next_pending_r_i_2__0
  assign esc_m_payload_i_reg_47__0_fbbb04b = ((esc_wrap_second_len_r_reg_2_01b34aa) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [41]) ? (1'b1) : (((esc_m_payload_i_reg_64__0_7cd5a09 [40]) ? (1'b1) : (((esc_m_payload_i_reg_64__0_7cd5a09 [39]) ? (1'b1) : (esc_m_payload_i_reg_64__0_7cd5a09 [42]))))))) : (1'b0));

  // Reconstructed LUT1: s_ready_i_i_1__0
  assign esc_aresetn_d_reg_0__0_7ec703c = ~(esc_aresetn_d_reg_n_0__0_417d18e);

  // Reconstructed LUT4: s_ready_i_i_2
  assign s_ready_i0 = ((s_ready_i_reg_0) ? (((s_axi_awvalid) ? (((m_valid_i_reg_0) ? (b_push) : (1'b1))) : (1'b1))) : (((m_valid_i_reg_0) ? (b_push) : (1'b1))));

  // Reconstructed FDRE: s_ready_i_reg
  reg recovered_93_q = 1'b0;
  assign s_ready_i_reg_0 = recovered_93_q;
  wire recovered_93_reset = ((esc_aresetn_d_reg_0__0_7ec703c)) && ((esc_aresetn_d_reg_0__0_7ec703c) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_93_reset || (((esc_aresetn_d_reg_0__0_7ec703c) === 1'bx) && (recovered_93_q == 1'b0))) recovered_93_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_93_q == (s_ready_i0)))) recovered_93_q <= (s_ready_i0);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_0_76b369d
  reg recovered_94_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__0_33bcee8 = recovered_94_q;
  wire recovered_94_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_94_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_94_q == 1'b0))) recovered_94_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_94_q == (s_axi_awaddr[0])))) recovered_94_q <= (s_axi_awaddr[0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_1_56ed2e4
  reg recovered_95_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__1_71722f5 = recovered_95_q;
  wire recovered_95_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_95_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_95_q == 1'b0))) recovered_95_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_95_q == (s_axi_awaddr[1])))) recovered_95_q <= (s_axi_awaddr[1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_2_a1b118e
  reg recovered_96_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__2_21e7f94 = recovered_96_q;
  wire recovered_96_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_96_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_96_q == 1'b0))) recovered_96_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_96_q == (s_axi_awaddr[2])))) recovered_96_q <= (s_axi_awaddr[2]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_35_1832a0f
  reg recovered_97_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__35_27754b0 = recovered_97_q;
  wire recovered_97_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_97_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_97_q == 1'b0))) recovered_97_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_97_q == (s_axi_awsize[0])))) recovered_97_q <= (s_axi_awsize[0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_36_590360f
  reg recovered_98_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__36_49139cd = recovered_98_q;
  wire recovered_98_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_98_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_98_q == 1'b0))) recovered_98_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_98_q == (s_axi_awsize[1])))) recovered_98_q <= (s_axi_awsize[1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_38_2e7b154
  reg recovered_99_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__38_66da518 = recovered_99_q;
  wire recovered_99_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_99_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_99_q == 1'b0))) recovered_99_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_99_q == (s_axi_awburst[0])))) recovered_99_q <= (s_axi_awburst[0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_39_f9c8e20
  reg recovered_100_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__39_753eaf3 = recovered_100_q;
  wire recovered_100_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_100_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_100_q == 1'b0))) recovered_100_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_100_q == (s_axi_awburst[1])))) recovered_100_q <= (s_axi_awburst[1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_3_b2015ce
  reg recovered_101_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__3_2d17305 = recovered_101_q;
  wire recovered_101_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_101_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_101_q == 1'b0))) recovered_101_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_101_q == (s_axi_awaddr[3])))) recovered_101_q <= (s_axi_awaddr[3]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_44_ba14b87
  reg recovered_102_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__44_4973a46 = recovered_102_q;
  wire recovered_102_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_102_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_102_q == 1'b0))) recovered_102_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_102_q == (s_axi_awlen[0])))) recovered_102_q <= (s_axi_awlen[0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_45_e8f1309
  reg recovered_103_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__45_ae6ce43 = recovered_103_q;
  wire recovered_103_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_103_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_103_q == 1'b0))) recovered_103_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_103_q == (s_axi_awlen[1])))) recovered_103_q <= (s_axi_awlen[1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_46_665ac24
  reg recovered_104_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__46_e862893 = recovered_104_q;
  wire recovered_104_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_104_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_104_q == 1'b0))) recovered_104_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_104_q == (s_axi_awlen[2])))) recovered_104_q <= (s_axi_awlen[2]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_47_030045d
  reg recovered_105_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__47_1ce944e = recovered_105_q;
  wire recovered_105_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_105_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_105_q == 1'b0))) recovered_105_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_105_q == (s_axi_awlen[3])))) recovered_105_q <= (s_axi_awlen[3]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_4_8811fae
  reg recovered_106_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__4_31058d6 = recovered_106_q;
  wire recovered_106_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_106_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_106_q == 1'b0))) recovered_106_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_106_q == (s_axi_awaddr[4])))) recovered_106_q <= (s_axi_awaddr[4]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_53_e0b802e
  reg recovered_107_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__53_bc11961 = recovered_107_q;
  wire recovered_107_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_107_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_107_q == 1'b0))) recovered_107_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_107_q == (s_axi_awid[0])))) recovered_107_q <= (s_axi_awid[0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_54_291a902
  reg recovered_108_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__54_de97db8 = recovered_108_q;
  wire recovered_108_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_108_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_108_q == 1'b0))) recovered_108_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_108_q == (s_axi_awid[1])))) recovered_108_q <= (s_axi_awid[1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_55_45f6563
  reg recovered_109_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__55_b96df6e = recovered_109_q;
  wire recovered_109_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_109_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_109_q == 1'b0))) recovered_109_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_109_q == (s_axi_awid[2])))) recovered_109_q <= (s_axi_awid[2]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_56_02fdde7
  reg recovered_110_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__56_b9b25f2 = recovered_110_q;
  wire recovered_110_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_110_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_110_q == 1'b0))) recovered_110_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_110_q == (s_axi_awid[3])))) recovered_110_q <= (s_axi_awid[3]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_57_1a385c7
  reg recovered_111_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__57_97d47d8 = recovered_111_q;
  wire recovered_111_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_111_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_111_q == 1'b0))) recovered_111_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_111_q == (s_axi_awid[4])))) recovered_111_q <= (s_axi_awid[4]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_58_364cc5f
  reg recovered_112_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__58_55e72f7 = recovered_112_q;
  wire recovered_112_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_112_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_112_q == 1'b0))) recovered_112_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_112_q == (s_axi_awid[5])))) recovered_112_q <= (s_axi_awid[5]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_59_b28a823
  reg recovered_113_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__59_4478807 = recovered_113_q;
  wire recovered_113_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_113_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_113_q == 1'b0))) recovered_113_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_113_q == (s_axi_awid[6])))) recovered_113_q <= (s_axi_awid[6]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_5_2379aaf
  reg recovered_114_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__5_f837c66 = recovered_114_q;
  wire recovered_114_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_114_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_114_q == 1'b0))) recovered_114_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_114_q == (s_axi_awaddr[5])))) recovered_114_q <= (s_axi_awaddr[5]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_60_3367d87
  reg recovered_115_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__60_b805d41 = recovered_115_q;
  wire recovered_115_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_115_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_115_q == 1'b0))) recovered_115_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_115_q == (s_axi_awid[7])))) recovered_115_q <= (s_axi_awid[7]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_61_4705321
  reg recovered_116_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__61_42cdcde = recovered_116_q;
  wire recovered_116_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_116_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_116_q == 1'b0))) recovered_116_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_116_q == (s_axi_awid[8])))) recovered_116_q <= (s_axi_awid[8]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_62_a5f2c02
  reg recovered_117_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__62_5bcd135 = recovered_117_q;
  wire recovered_117_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_117_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_117_q == 1'b0))) recovered_117_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_117_q == (s_axi_awid[9])))) recovered_117_q <= (s_axi_awid[9]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_63_a4fe3d0
  reg recovered_118_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__63_bee6e3d = recovered_118_q;
  wire recovered_118_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_118_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_118_q == 1'b0))) recovered_118_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_118_q == (s_axi_awid[10])))) recovered_118_q <= (s_axi_awid[10]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_64_976996b
  reg recovered_119_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__64_1d37155 = recovered_119_q;
  wire recovered_119_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_119_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_119_q == 1'b0))) recovered_119_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_119_q == (s_axi_awid[11])))) recovered_119_q <= (s_axi_awid[11]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_6_8005d57
  reg recovered_120_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__6_e84291a = recovered_120_q;
  wire recovered_120_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_120_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_120_q == 1'b0))) recovered_120_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_120_q == (s_axi_awaddr[6])))) recovered_120_q <= (s_axi_awaddr[6]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_7_2a42553
  reg recovered_121_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__7_355ab42 = recovered_121_q;
  wire recovered_121_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_121_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_121_q == 1'b0))) recovered_121_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_121_q == (s_axi_awaddr[7])))) recovered_121_q <= (s_axi_awaddr[7]);
  end

  // Reconstructed LUT4: esc_wrap_boundary_axaddr_r_0__i_1_6a1c691
  assign esc_m_payload_i_reg_47__2_d1e0165 [0] = ((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [0]) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [0]) : (((esc_m_payload_i_reg_64__0_7cd5a09 [0]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [39])) : (1'b0))))));

  // Reconstructed LUT5: esc_wrap_boundary_axaddr_r_1__i_1_e5e4b99
  assign esc_m_payload_i_reg_47__2_d1e0165 [1] = ((esc_m_payload_i_reg_64__0_7cd5a09 [39]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [1]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [36]) : (1'b0))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [1]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [40]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [36]) : (1'b1))) : (1'b0))))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [1]) : (((esc_m_payload_i_reg_64__0_7cd5a09 [1]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [40]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [36]) : (1'b1))) : (1'b0))))));

  // Reconstructed LUT6: esc_wrap_boundary_axaddr_r_2__i_1_5d8be5f
  assign esc_m_payload_i_reg_47__2_d1e0165 [2] = ((esc_m_payload_i_reg_64__0_7cd5a09 [39]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [2]) : (((esc_m_payload_i_reg_64__0_7cd5a09 [2]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [40])) : (1'b0))))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [2]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [41])) : (1'b0))))))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [2]) : (((esc_m_payload_i_reg_64__0_7cd5a09 [2]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [40])) : (1'b0))))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [2]) : (((esc_m_payload_i_reg_64__0_7cd5a09 [2]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [41])) : (1'b0))))))));

  // Reconstructed LUT6: esc_wrap_boundary_axaddr_r_3__i_1_00cb26c
  assign esc_m_payload_i_reg_47__2_d1e0165 [3] = ((esc_wrap_boundary_axaddr_r_3__i_2_n_0_4685ec5) ? (1'b1) : (((esc_m_payload_i_reg_64__0_7cd5a09 [42]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [3]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [40])) : (1'b0))))) : (1'b0))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [3]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [40])) : (1'b0))))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (1'b0) : (esc_m_payload_i_reg_64__0_7cd5a09 [3]))))))));

  // Reconstructed LUT5: esc_wrap_boundary_axaddr_r_3__i_2_7b8dbbd
  assign esc_wrap_boundary_axaddr_r_3__i_2_n_0_4685ec5 = ((esc_m_payload_i_reg_64__0_7cd5a09 [39]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [3]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [41])) : (1'b0))))) : (1'b0))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [3]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [35]) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [41])) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_wrap_boundary_axaddr_r_4__i_1_f1eb3bb
  assign esc_m_payload_i_reg_47__2_d1e0165 [4] = ((esc_m_payload_i_reg_64__0_7cd5a09 [40]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (1'b0) : (((esc_m_payload_i_reg_64__0_7cd5a09 [4]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [42])) : (1'b0))))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [4]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [41])) : (1'b0))) : (esc_m_payload_i_reg_64__0_7cd5a09 [4]))))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [4]) : (((esc_m_payload_i_reg_64__0_7cd5a09 [4]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [42])) : (1'b0))))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [4]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [41])) : (1'b0))) : (esc_m_payload_i_reg_64__0_7cd5a09 [4]))))));

  // Reconstructed LUT5: esc_wrap_boundary_axaddr_r_5__i_1_4221caf
  assign esc_m_payload_i_reg_47__2_d1e0165 [5] = ((esc_m_payload_i_reg_64__0_7cd5a09 [41]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [5]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [36])) : (1'b0))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [5]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [42]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [36])) : (1'b1))) : (1'b0))))) : (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (esc_m_payload_i_reg_64__0_7cd5a09 [5]) : (((esc_m_payload_i_reg_64__0_7cd5a09 [5]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [42]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [36])) : (1'b1))) : (1'b0))))));

  // Reconstructed LUT4: esc_wrap_boundary_axaddr_r_6__i_1_cd2dca2
  assign esc_m_payload_i_reg_47__2_d1e0165 [6] = ((esc_m_payload_i_reg_64__0_7cd5a09 [36]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [35]) ? (((esc_m_payload_i_reg_64__0_7cd5a09 [6]) ? (~(esc_m_payload_i_reg_64__0_7cd5a09 [42])) : (1'b0))) : (esc_m_payload_i_reg_64__0_7cd5a09 [6]))) : (esc_m_payload_i_reg_64__0_7cd5a09 [6]));

  // Reconstructed LUT6: esc_wrap_cnt_r_2__i_1_9071abb
  assign D[0] = ((esc_wrap_second_len_r_reg_3_130d984 [2]) ? (((esc_wrap_second_len_r_reg_3__0_61735c7 [0]) ? (((esc_m_payload_i_reg_44__1_a8cd662) ? (((esc_m_payload_i_reg_44__0_3e7cb03) ? (((esc_wrap_second_len_r_reg_2_01b34aa) ? (1'b1) : (~(esc_wrap_second_len_r_reg_3_130d984 [1])))) : (1'b1))) : (((esc_m_payload_i_reg_44__0_3e7cb03) ? (~(esc_wrap_second_len_r_reg_3_130d984 [1])) : (1'b1))))) : (((esc_m_payload_i_reg_44__1_a8cd662) ? (1'b1) : (((esc_m_payload_i_reg_44__0_3e7cb03) ? (((esc_wrap_second_len_r_reg_2_01b34aa) ? (~(esc_wrap_second_len_r_reg_3_130d984 [1])) : (1'b1))) : (1'b1))))))) : (((esc_wrap_second_len_r_reg_3__0_61735c7 [0]) ? (((esc_m_payload_i_reg_44__1_a8cd662) ? (((esc_m_payload_i_reg_44__0_3e7cb03) ? (((esc_wrap_second_len_r_reg_2_01b34aa) ? (1'b0) : (esc_wrap_second_len_r_reg_3_130d984 [1]))) : (1'b0))) : (((esc_m_payload_i_reg_44__0_3e7cb03) ? (esc_wrap_second_len_r_reg_3_130d984 [1]) : (1'b0))))) : (((esc_m_payload_i_reg_44__1_a8cd662) ? (1'b0) : (((esc_m_payload_i_reg_44__0_3e7cb03) ? (((esc_wrap_second_len_r_reg_2_01b34aa) ? (esc_wrap_second_len_r_reg_3_130d984 [1]) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT4: esc_wrap_cnt_r_2__i_2_10bb4db
  assign esc_m_payload_i_reg_44__0_3e7cb03 = ((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (1'b1) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (1'b1) : (((esc_m_payload_i_reg_47__1_6188148) ? (1'b1) : (esc_m_payload_i_reg_44__1_a8cd662))))));

  // Reconstructed LUT4: esc_wrap_cnt_r_3__i_1_847fc72
  assign D[1] = ((esc_wrap_second_len_r_reg_3_130d984 [3]) ? (((esc_wrap_second_len_r_reg_3_130d984 [1]) ? (((esc_wrap_cnt_r_3__i_2_n_0_1d56281) ? (1'b1) : (~(esc_wrap_second_len_r_reg_3_130d984 [2])))) : (1'b1))) : (((esc_wrap_second_len_r_reg_3_130d984 [1]) ? (((esc_wrap_cnt_r_3__i_2_n_0_1d56281) ? (1'b0) : (esc_wrap_second_len_r_reg_3_130d984 [2]))) : (1'b0))));

  // Reconstructed LUT6: esc_wrap_cnt_r_3__i_2_707130c
  assign esc_wrap_cnt_r_3__i_2_n_0_1d56281 = ((esc_wrap_second_len_r_reg_3__0_61735c7 [0]) ? (((esc_m_payload_i_reg_44__1_a8cd662) ? (esc_wrap_second_len_r_reg_2_01b34aa) : (((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (1'b0) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (1'b0) : (~(esc_m_payload_i_reg_47__1_6188148)))))))) : (((esc_m_payload_i_reg_44__1_a8cd662) ? (1'b1) : (((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (~(esc_wrap_second_len_r_reg_2_01b34aa)) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (~(esc_wrap_second_len_r_reg_2_01b34aa)) : (((esc_m_payload_i_reg_47__1_6188148) ? (~(esc_wrap_second_len_r_reg_2_01b34aa)) : (1'b1))))))))));

  // Reconstructed LUT6: esc_wrap_second_len_r_0__i_1_25c02cc
  assign esc_wrap_second_len_r_reg_3_130d984 [0] = ((esc_wrap_second_len_r_reg_2_01b34aa) ? (((esc_m_payload_i_reg_47__1_6188148) ? (~(esc_m_payload_i_reg_44__1_a8cd662)) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (~(esc_m_payload_i_reg_44__1_a8cd662)) : (((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (~(esc_m_payload_i_reg_44__1_a8cd662)) : (1'b0))))))) : (esc_wrap_second_len_r_reg_3__0_61735c7 [0]));

  // Reconstructed LUT6: esc_wrap_second_len_r_1__i_1_bd83601
  assign esc_wrap_second_len_r_reg_3_130d984 [1] = ((esc_FSM_sequential_state_reg_1_aa5780a) ? (((esc_wrap_second_len_r_reg_2_01b34aa) ? (esc_m_payload_i_reg_44__1_a8cd662) : (esc_wrap_second_len_r_reg_3__0_61735c7 [1]))) : (((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (((esc_wrap_second_len_r_reg_2_01b34aa) ? (~(esc_m_payload_i_reg_44__1_a8cd662)) : (esc_wrap_second_len_r_reg_3__0_61735c7 [1]))) : (((esc_m_payload_i_reg_47__1_6188148) ? (((esc_wrap_second_len_r_reg_2_01b34aa) ? (~(esc_m_payload_i_reg_44__1_a8cd662)) : (esc_wrap_second_len_r_reg_3__0_61735c7 [1]))) : (((esc_wrap_second_len_r_reg_2_01b34aa) ? (1'b0) : (esc_wrap_second_len_r_reg_3__0_61735c7 [1]))))))));

  // Reconstructed LUT6: esc_wrap_second_len_r_2__i_1_84a0ca8
  assign esc_wrap_second_len_r_reg_3_130d984 [2] = ((esc_wrap_second_len_r_reg_2_01b34aa) ? (((esc_m_payload_i_reg_44__1_a8cd662) ? (esc_FSM_sequential_state_reg_1__0_5c93d31) : (((esc_m_payload_i_reg_47__1_6188148) ? (((esc_FSM_sequential_state_reg_1_aa5780a) ? (esc_FSM_sequential_state_reg_1__0_5c93d31) : (~(esc_FSM_sequential_state_reg_1__0_5c93d31)))) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (esc_FSM_sequential_state_reg_1__0_5c93d31) : (1'b0))))))) : (esc_wrap_second_len_r_reg_3__0_61735c7 [2]));

  // Reconstructed LUT6: esc_wrap_second_len_r_3__i_1_1fc4166
  assign esc_wrap_second_len_r_reg_3_130d984 [3] = ((esc_FSM_sequential_state_reg_1__0_5c93d31) ? (((esc_wrap_second_len_r_reg_2_01b34aa) ? (esc_m_payload_i_reg_47__1_6188148) : (esc_wrap_second_len_r_reg_3__0_61735c7 [3]))) : (((esc_FSM_sequential_state_reg_1_aa5780a) ? (((esc_wrap_second_len_r_reg_2_01b34aa) ? (esc_m_payload_i_reg_47__1_6188148) : (esc_wrap_second_len_r_reg_3__0_61735c7 [3]))) : (((esc_m_payload_i_reg_44__1_a8cd662) ? (((esc_wrap_second_len_r_reg_2_01b34aa) ? (esc_m_payload_i_reg_47__1_6188148) : (esc_wrap_second_len_r_reg_3__0_61735c7 [3]))) : (((esc_wrap_second_len_r_reg_2_01b34aa) ? (1'b0) : (esc_wrap_second_len_r_reg_3__0_61735c7 [3]))))))));

endmodule

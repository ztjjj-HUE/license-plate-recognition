// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_auto_pc_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized1
   (m_valid_i_reg_0,
    s_ready_i_reg_0,
    shandshake,
    esc_m_payload_i_reg_13__0_806bc71 ,
    m_valid_i_reg_1,
    aclk,
    s_ready_i_reg_1,
    s_axi_bready,
    si_rs_bvalid,
    out,
    esc_skid_buffer_reg_1__0_c42767f );
  output m_valid_i_reg_0;
  output s_ready_i_reg_0;
  output shandshake;
  output [13:0]esc_m_payload_i_reg_13__0_806bc71 ;
  input m_valid_i_reg_1;
  input aclk;
  input s_ready_i_reg_1;
  input s_axi_bready;
  input si_rs_bvalid;
  input [11:0]out;
  input [1:0]esc_skid_buffer_reg_1__0_c42767f ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire aclk;
  wire esc_m_payload_i_0__i_1__1_n_0_6d5236e ;
  wire esc_m_payload_i_10__i_1__1_n_0_402f7a4 ;
  wire esc_m_payload_i_11__i_1__1_n_0_bb273f8 ;
  wire esc_m_payload_i_12__i_1__1_n_0_736cc8c ;
  wire esc_m_payload_i_13__i_2_n_0_4358e34 ;
  wire esc_m_payload_i_1__i_1__1_n_0_3d35fc3 ;
  wire esc_m_payload_i_2__i_1__1_n_0_e3f8e0f ;
  wire esc_m_payload_i_3__i_1__1_n_0_7c1ee23 ;
  wire esc_m_payload_i_4__i_1__1_n_0_0263d83 ;
  wire esc_m_payload_i_5__i_1__1_n_0_db96443 ;
  wire esc_m_payload_i_6__i_1__1_n_0_c144fbe ;
  wire esc_m_payload_i_7__i_1__1_n_0_ee7c248 ;
  wire esc_m_payload_i_8__i_1__1_n_0_a810434 ;
  wire esc_m_payload_i_9__i_1__1_n_0_2de4704 ;
  wire [13:0]esc_m_payload_i_reg_13__0_806bc71 ;
  wire m_valid_i0;
  wire m_valid_i_reg_0;
  wire m_valid_i_reg_1;
  wire [11:0]out;
  wire p_1_in;
  wire s_axi_bready;
  wire s_ready_i_i_1__1_n_0;
  wire s_ready_i_reg_0;
  wire s_ready_i_reg_1;
  wire shandshake;
  wire si_rs_bvalid;
  wire [1:0]esc_skid_buffer_reg_1__0_c42767f ;
  wire esc_skid_buffer_reg_n_0__0_33bcee8 ;
  wire esc_skid_buffer_reg_n_0__10_da54f90 ;
  wire esc_skid_buffer_reg_n_0__11_635b5cd ;
  wire esc_skid_buffer_reg_n_0__12_642a9d1 ;
  wire esc_skid_buffer_reg_n_0__13_186ebbf ;
  wire esc_skid_buffer_reg_n_0__1_71722f5 ;
  wire esc_skid_buffer_reg_n_0__2_21e7f94 ;
  wire esc_skid_buffer_reg_n_0__3_2d17305 ;
  wire esc_skid_buffer_reg_n_0__4_31058d6 ;
  wire esc_skid_buffer_reg_n_0__5_f837c66 ;
  wire esc_skid_buffer_reg_n_0__6_e84291a ;
  wire esc_skid_buffer_reg_n_0__7_355ab42 ;
  wire esc_skid_buffer_reg_n_0__8_af00c4a ;
  wire esc_skid_buffer_reg_n_0__9_a8dd98f ;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT3: esc_m_payload_i_0__i_1__1_6dd60c0
  assign esc_m_payload_i_0__i_1__1_n_0_6d5236e = ((esc_skid_buffer_reg_n_0__0_33bcee8) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_1__0_c42767f [0]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_1__0_c42767f [0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_10__i_1__1_2fd0992
  assign esc_m_payload_i_10__i_1__1_n_0_402f7a4 = ((esc_skid_buffer_reg_n_0__10_da54f90) ? (((s_ready_i_reg_0) ? (out[8]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[8]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_11__i_1__1_520a332
  assign esc_m_payload_i_11__i_1__1_n_0_bb273f8 = ((esc_skid_buffer_reg_n_0__11_635b5cd) ? (((s_ready_i_reg_0) ? (out[9]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[9]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_12__i_1__1_6af0aac
  assign esc_m_payload_i_12__i_1__1_n_0_736cc8c = ((esc_skid_buffer_reg_n_0__12_642a9d1) ? (((s_ready_i_reg_0) ? (out[10]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[10]) : (1'b0))));

  // Reconstructed LUT2: esc_m_payload_i_13__i_1_cfcabaf
  assign p_1_in = ((m_valid_i_reg_0) ? (s_axi_bready) : (1'b1));

  // Reconstructed LUT3: esc_m_payload_i_13__i_2_d6fbd6c
  assign esc_m_payload_i_13__i_2_n_0_4358e34 = ((esc_skid_buffer_reg_n_0__13_186ebbf) ? (((s_ready_i_reg_0) ? (out[11]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[11]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_1__i_1__1_0977191
  assign esc_m_payload_i_1__i_1__1_n_0_3d35fc3 = ((esc_skid_buffer_reg_n_0__1_71722f5) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_1__0_c42767f [1]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_1__0_c42767f [1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_2__i_1__1_947e8b1
  assign esc_m_payload_i_2__i_1__1_n_0_e3f8e0f = ((esc_skid_buffer_reg_n_0__2_21e7f94) ? (((s_ready_i_reg_0) ? (out[0]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_3__i_1__1_f126640
  assign esc_m_payload_i_3__i_1__1_n_0_7c1ee23 = ((esc_skid_buffer_reg_n_0__3_2d17305) ? (((s_ready_i_reg_0) ? (out[1]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_4__i_1__1_1e97f48
  assign esc_m_payload_i_4__i_1__1_n_0_0263d83 = ((esc_skid_buffer_reg_n_0__4_31058d6) ? (((s_ready_i_reg_0) ? (out[2]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[2]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_5__i_1__1_7b11f56
  assign esc_m_payload_i_5__i_1__1_n_0_db96443 = ((esc_skid_buffer_reg_n_0__5_f837c66) ? (((s_ready_i_reg_0) ? (out[3]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[3]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_6__i_1__1_c8f0531
  assign esc_m_payload_i_6__i_1__1_n_0_c144fbe = ((esc_skid_buffer_reg_n_0__6_e84291a) ? (((s_ready_i_reg_0) ? (out[4]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[4]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_7__i_1__1_60d227c
  assign esc_m_payload_i_7__i_1__1_n_0_ee7c248 = ((esc_skid_buffer_reg_n_0__7_355ab42) ? (((s_ready_i_reg_0) ? (out[5]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[5]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_8__i_1__1_a228e7c
  assign esc_m_payload_i_8__i_1__1_n_0_a810434 = ((esc_skid_buffer_reg_n_0__8_af00c4a) ? (((s_ready_i_reg_0) ? (out[6]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[6]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_9__i_1__1_8f1a557
  assign esc_m_payload_i_9__i_1__1_n_0_2de4704 = ((esc_skid_buffer_reg_n_0__9_a8dd98f) ? (((s_ready_i_reg_0) ? (out[7]) : (1'b1))) : (((s_ready_i_reg_0) ? (out[7]) : (1'b0))));

  // Reconstructed FDRE: esc_m_payload_i_reg_0_2f8d71c
  reg recovered_18_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [0] = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_18_q == (esc_m_payload_i_0__i_1__1_n_0_6d5236e)))) recovered_18_q <= (esc_m_payload_i_0__i_1__1_n_0_6d5236e);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_10_ffe4795
  reg recovered_19_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [10] = recovered_19_q;
  wire recovered_19_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_19_q == (esc_m_payload_i_10__i_1__1_n_0_402f7a4)))) recovered_19_q <= (esc_m_payload_i_10__i_1__1_n_0_402f7a4);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_11_41a697a
  reg recovered_20_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [11] = recovered_20_q;
  wire recovered_20_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_20_q == (esc_m_payload_i_11__i_1__1_n_0_bb273f8)))) recovered_20_q <= (esc_m_payload_i_11__i_1__1_n_0_bb273f8);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_12_69d425e
  reg recovered_21_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [12] = recovered_21_q;
  wire recovered_21_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_21_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_21_q == (esc_m_payload_i_12__i_1__1_n_0_736cc8c)))) recovered_21_q <= (esc_m_payload_i_12__i_1__1_n_0_736cc8c);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_13_5fdb661
  reg recovered_22_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [13] = recovered_22_q;
  wire recovered_22_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_22_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_22_q == (esc_m_payload_i_13__i_2_n_0_4358e34)))) recovered_22_q <= (esc_m_payload_i_13__i_2_n_0_4358e34);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_1_a76cbaf
  reg recovered_23_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [1] = recovered_23_q;
  wire recovered_23_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_23_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_23_q == (esc_m_payload_i_1__i_1__1_n_0_3d35fc3)))) recovered_23_q <= (esc_m_payload_i_1__i_1__1_n_0_3d35fc3);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_2_3bf2adb
  reg recovered_24_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [2] = recovered_24_q;
  wire recovered_24_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_24_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_24_q == (esc_m_payload_i_2__i_1__1_n_0_e3f8e0f)))) recovered_24_q <= (esc_m_payload_i_2__i_1__1_n_0_e3f8e0f);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_3_3eab624
  reg recovered_25_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [3] = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_25_q == (esc_m_payload_i_3__i_1__1_n_0_7c1ee23)))) recovered_25_q <= (esc_m_payload_i_3__i_1__1_n_0_7c1ee23);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_4_60ef705
  reg recovered_26_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [4] = recovered_26_q;
  wire recovered_26_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_26_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_26_q == (esc_m_payload_i_4__i_1__1_n_0_0263d83)))) recovered_26_q <= (esc_m_payload_i_4__i_1__1_n_0_0263d83);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_5_6200800
  reg recovered_27_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [5] = recovered_27_q;
  wire recovered_27_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_27_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_27_q == (esc_m_payload_i_5__i_1__1_n_0_db96443)))) recovered_27_q <= (esc_m_payload_i_5__i_1__1_n_0_db96443);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_6_8d56399
  reg recovered_28_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [6] = recovered_28_q;
  wire recovered_28_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_28_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_28_q == (esc_m_payload_i_6__i_1__1_n_0_c144fbe)))) recovered_28_q <= (esc_m_payload_i_6__i_1__1_n_0_c144fbe);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_7_ba4380d
  reg recovered_29_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [7] = recovered_29_q;
  wire recovered_29_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_29_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_29_q == (esc_m_payload_i_7__i_1__1_n_0_ee7c248)))) recovered_29_q <= (esc_m_payload_i_7__i_1__1_n_0_ee7c248);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_8_f05b222
  reg recovered_30_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [8] = recovered_30_q;
  wire recovered_30_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_30_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_30_q == (esc_m_payload_i_8__i_1__1_n_0_a810434)))) recovered_30_q <= (esc_m_payload_i_8__i_1__1_n_0_a810434);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_9_9458063
  reg recovered_31_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [9] = recovered_31_q;
  wire recovered_31_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_31_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((p_1_in) || ((p_1_in) === 1'bz) || (((p_1_in) === 1'bx) && (recovered_31_q == (esc_m_payload_i_9__i_1__1_n_0_2de4704)))) recovered_31_q <= (esc_m_payload_i_9__i_1__1_n_0_2de4704);
  end

  // Reconstructed LUT4: m_valid_i_i_1__0
  assign m_valid_i0 = ((s_axi_bready) ? (((si_rs_bvalid) ? (1'b1) : (~(s_ready_i_reg_0)))) : (((m_valid_i_reg_0) ? (1'b1) : (((si_rs_bvalid) ? (1'b1) : (~(s_ready_i_reg_0)))))));

  // Reconstructed FDRE: m_valid_i_reg
  reg recovered_33_q = 1'b0;
  assign m_valid_i_reg_0 = recovered_33_q;
  wire recovered_33_reset = ((m_valid_i_reg_1)) && ((m_valid_i_reg_1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_33_reset || (((m_valid_i_reg_1) === 1'bx) && (recovered_33_q == 1'b0))) recovered_33_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_33_q == (m_valid_i0)))) recovered_33_q <= (m_valid_i0);
  end

  // Reconstructed LUT4: s_ready_i_i_1__1
  assign s_ready_i_i_1__1_n_0 = ((si_rs_bvalid) ? (((s_axi_bready) ? (1'b1) : (~(m_valid_i_reg_0)))) : (((s_ready_i_reg_0) ? (1'b1) : (((s_axi_bready) ? (1'b1) : (~(m_valid_i_reg_0)))))));

  // Reconstructed FDRE: s_ready_i_reg
  reg recovered_35_q = 1'b0;
  assign s_ready_i_reg_0 = recovered_35_q;
  wire recovered_35_reset = ((s_ready_i_reg_1)) && ((s_ready_i_reg_1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_35_reset || (((s_ready_i_reg_1) === 1'bx) && (recovered_35_q == 1'b0))) recovered_35_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_35_q == (s_ready_i_i_1__1_n_0)))) recovered_35_q <= (s_ready_i_i_1__1_n_0);
  end

  // Reconstructed LUT2: shandshake_r_i_1
  assign shandshake = ((si_rs_bvalid) ? (s_ready_i_reg_0) : (1'b0));

  // Reconstructed FDRE: esc_skid_buffer_reg_0_76b369d
  reg recovered_37_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__0_33bcee8 = recovered_37_q;
  wire recovered_37_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_37_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_37_q == 1'b0))) recovered_37_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_37_q == (esc_skid_buffer_reg_1__0_c42767f [0])))) recovered_37_q <= (esc_skid_buffer_reg_1__0_c42767f [0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_10_647878d
  reg recovered_38_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__10_da54f90 = recovered_38_q;
  wire recovered_38_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_38_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_38_q == 1'b0))) recovered_38_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_38_q == (out[8])))) recovered_38_q <= (out[8]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_11_980bfa2
  reg recovered_39_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__11_635b5cd = recovered_39_q;
  wire recovered_39_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_39_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_39_q == 1'b0))) recovered_39_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_39_q == (out[9])))) recovered_39_q <= (out[9]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_12_88d0b5e
  reg recovered_40_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__12_642a9d1 = recovered_40_q;
  wire recovered_40_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_40_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_40_q == 1'b0))) recovered_40_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_40_q == (out[10])))) recovered_40_q <= (out[10]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_13_2e20759
  reg recovered_41_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__13_186ebbf = recovered_41_q;
  wire recovered_41_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_41_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_41_q == 1'b0))) recovered_41_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_41_q == (out[11])))) recovered_41_q <= (out[11]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_1_56ed2e4
  reg recovered_42_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__1_71722f5 = recovered_42_q;
  wire recovered_42_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_42_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_42_q == 1'b0))) recovered_42_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_42_q == (esc_skid_buffer_reg_1__0_c42767f [1])))) recovered_42_q <= (esc_skid_buffer_reg_1__0_c42767f [1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_2_a1b118e
  reg recovered_43_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__2_21e7f94 = recovered_43_q;
  wire recovered_43_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_43_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_43_q == (out[0])))) recovered_43_q <= (out[0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_3_b2015ce
  reg recovered_44_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__3_2d17305 = recovered_44_q;
  wire recovered_44_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_44_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_44_q == (out[1])))) recovered_44_q <= (out[1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_4_8811fae
  reg recovered_45_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__4_31058d6 = recovered_45_q;
  wire recovered_45_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_45_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_45_q == 1'b0))) recovered_45_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_45_q == (out[2])))) recovered_45_q <= (out[2]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_5_2379aaf
  reg recovered_46_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__5_f837c66 = recovered_46_q;
  wire recovered_46_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_46_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_46_q == 1'b0))) recovered_46_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_46_q == (out[3])))) recovered_46_q <= (out[3]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_6_8005d57
  reg recovered_47_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__6_e84291a = recovered_47_q;
  wire recovered_47_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_47_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_47_q == 1'b0))) recovered_47_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_47_q == (out[4])))) recovered_47_q <= (out[4]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_7_2a42553
  reg recovered_48_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__7_355ab42 = recovered_48_q;
  wire recovered_48_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_48_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_48_q == 1'b0))) recovered_48_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_48_q == (out[5])))) recovered_48_q <= (out[5]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_8_0355eb3
  reg recovered_49_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__8_af00c4a = recovered_49_q;
  wire recovered_49_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_49_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_49_q == 1'b0))) recovered_49_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_49_q == (out[6])))) recovered_49_q <= (out[6]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_9_86c7e93
  reg recovered_50_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__9_a8dd98f = recovered_50_q;
  wire recovered_50_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_50_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_50_q == 1'b0))) recovered_50_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_50_q == (out[7])))) recovered_50_q <= (out[7]);
  end

endmodule

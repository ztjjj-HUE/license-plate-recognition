// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0
   (s_axi_control_AWADDR,
    s_axi_control_AWVALID,
    s_axi_control_AWREADY,
    s_axi_control_WDATA,
    s_axi_control_WSTRB,
    s_axi_control_WVALID,
    s_axi_control_WREADY,
    s_axi_control_BRESP,
    s_axi_control_BVALID,
    s_axi_control_BREADY,
    s_axi_control_ARADDR,
    s_axi_control_ARVALID,
    s_axi_control_ARREADY,
    s_axi_control_RDATA,
    s_axi_control_RRESP,
    s_axi_control_RVALID,
    s_axi_control_RREADY,
    ap_clk,
    ap_rst_n,
    interrupt,
    m_axi_frame_AWADDR,
    m_axi_frame_AWLEN,
    m_axi_frame_AWSIZE,
    m_axi_frame_AWBURST,
    m_axi_frame_AWLOCK,
    m_axi_frame_AWREGION,
    m_axi_frame_AWCACHE,
    m_axi_frame_AWPROT,
    m_axi_frame_AWQOS,
    m_axi_frame_AWVALID,
    m_axi_frame_AWREADY,
    m_axi_frame_WDATA,
    m_axi_frame_WSTRB,
    m_axi_frame_WLAST,
    m_axi_frame_WVALID,
    m_axi_frame_WREADY,
    m_axi_frame_BRESP,
    m_axi_frame_BVALID,
    m_axi_frame_BREADY,
    m_axi_frame_ARADDR,
    m_axi_frame_ARLEN,
    m_axi_frame_ARSIZE,
    m_axi_frame_ARBURST,
    m_axi_frame_ARLOCK,
    m_axi_frame_ARREGION,
    m_axi_frame_ARCACHE,
    m_axi_frame_ARPROT,
    m_axi_frame_ARQOS,
    m_axi_frame_ARVALID,
    m_axi_frame_ARREADY,
    m_axi_frame_RDATA,
    m_axi_frame_RRESP,
    m_axi_frame_RLAST,
    m_axi_frame_RVALID,
    m_axi_frame_RREADY,
    m_axi_output_r_AWADDR,
    m_axi_output_r_AWLEN,
    m_axi_output_r_AWSIZE,
    m_axi_output_r_AWBURST,
    m_axi_output_r_AWLOCK,
    m_axi_output_r_AWREGION,
    m_axi_output_r_AWCACHE,
    m_axi_output_r_AWPROT,
    m_axi_output_r_AWQOS,
    m_axi_output_r_AWVALID,
    m_axi_output_r_AWREADY,
    m_axi_output_r_WDATA,
    m_axi_output_r_WSTRB,
    m_axi_output_r_WLAST,
    m_axi_output_r_WVALID,
    m_axi_output_r_WREADY,
    m_axi_output_r_BRESP,
    m_axi_output_r_BVALID,
    m_axi_output_r_BREADY,
    m_axi_output_r_ARADDR,
    m_axi_output_r_ARLEN,
    m_axi_output_r_ARSIZE,
    m_axi_output_r_ARBURST,
    m_axi_output_r_ARLOCK,
    m_axi_output_r_ARREGION,
    m_axi_output_r_ARCACHE,
    m_axi_output_r_ARPROT,
    m_axi_output_r_ARQOS,
    m_axi_output_r_ARVALID,
    m_axi_output_r_ARREADY,
    m_axi_output_r_RDATA,
    m_axi_output_r_RRESP,
    m_axi_output_r_RLAST,
    m_axi_output_r_RVALID,
    m_axi_output_r_RREADY);
   input [5:0]s_axi_control_AWADDR;
   input s_axi_control_AWVALID;
   output s_axi_control_AWREADY;
   input [31:0]s_axi_control_WDATA;
   input [3:0]s_axi_control_WSTRB;
   input s_axi_control_WVALID;
   output s_axi_control_WREADY;
   output [1:0]s_axi_control_BRESP;
   output s_axi_control_BVALID;
   input s_axi_control_BREADY;
   input [5:0]s_axi_control_ARADDR;
   input s_axi_control_ARVALID;
   output s_axi_control_ARREADY;
   output [31:0]s_axi_control_RDATA;
   output [1:0]s_axi_control_RRESP;
   output s_axi_control_RVALID;
    input s_axi_control_RREADY;
    input ap_clk;
    input ap_rst_n;
    output interrupt;
   output [63:0]m_axi_frame_AWADDR;
   output [7:0]m_axi_frame_AWLEN;
   output [2:0]m_axi_frame_AWSIZE;
   output [1:0]m_axi_frame_AWBURST;
   output [1:0]m_axi_frame_AWLOCK;
   output [3:0]m_axi_frame_AWREGION;
   output [3:0]m_axi_frame_AWCACHE;
   output [2:0]m_axi_frame_AWPROT;
   output [3:0]m_axi_frame_AWQOS;
   output m_axi_frame_AWVALID;
   input m_axi_frame_AWREADY;
   output [31:0]m_axi_frame_WDATA;
   output [3:0]m_axi_frame_WSTRB;
   output m_axi_frame_WLAST;
   output m_axi_frame_WVALID;
   input m_axi_frame_WREADY;
   input [1:0]m_axi_frame_BRESP;
   input m_axi_frame_BVALID;
   output m_axi_frame_BREADY;
   output [63:0]m_axi_frame_ARADDR;
   output [7:0]m_axi_frame_ARLEN;
   output [2:0]m_axi_frame_ARSIZE;
   output [1:0]m_axi_frame_ARBURST;
   output [1:0]m_axi_frame_ARLOCK;
   output [3:0]m_axi_frame_ARREGION;
   output [3:0]m_axi_frame_ARCACHE;
   output [2:0]m_axi_frame_ARPROT;
   output [3:0]m_axi_frame_ARQOS;
   output m_axi_frame_ARVALID;
   input m_axi_frame_ARREADY;
   input [31:0]m_axi_frame_RDATA;
   input [1:0]m_axi_frame_RRESP;
   input m_axi_frame_RLAST;
   input m_axi_frame_RVALID;
    output m_axi_frame_RREADY;
   output [63:0]m_axi_output_r_AWADDR;
   output [7:0]m_axi_output_r_AWLEN;
   output [2:0]m_axi_output_r_AWSIZE;
   output [1:0]m_axi_output_r_AWBURST;
   output [1:0]m_axi_output_r_AWLOCK;
   output [3:0]m_axi_output_r_AWREGION;
   output [3:0]m_axi_output_r_AWCACHE;
   output [2:0]m_axi_output_r_AWPROT;
   output [3:0]m_axi_output_r_AWQOS;
   output m_axi_output_r_AWVALID;
   input m_axi_output_r_AWREADY;
   output [31:0]m_axi_output_r_WDATA;
   output [3:0]m_axi_output_r_WSTRB;
   output m_axi_output_r_WLAST;
   output m_axi_output_r_WVALID;
   input m_axi_output_r_WREADY;
   input [1:0]m_axi_output_r_BRESP;
   input m_axi_output_r_BVALID;
   output m_axi_output_r_BREADY;
   output [63:0]m_axi_output_r_ARADDR;
   output [7:0]m_axi_output_r_ARLEN;
   output [2:0]m_axi_output_r_ARSIZE;
   output [1:0]m_axi_output_r_ARBURST;
   output [1:0]m_axi_output_r_ARLOCK;
   output [3:0]m_axi_output_r_ARREGION;
   output [3:0]m_axi_output_r_ARCACHE;
   output [2:0]m_axi_output_r_ARPROT;
   output [3:0]m_axi_output_r_ARQOS;
   output m_axi_output_r_ARVALID;
   input m_axi_output_r_ARREADY;
   input [31:0]m_axi_output_r_RDATA;
   input [1:0]m_axi_output_r_RRESP;
   input m_axi_output_r_RLAST;
   input m_axi_output_r_RVALID;
    output m_axi_output_r_RREADY;

  wire ap_clk;
  wire ap_rst_n;
  wire [63:0]m_axi_frame_ARADDR;
  wire [7:0]m_axi_frame_ARLEN;
  wire m_axi_frame_ARREADY;
  wire m_axi_frame_ARVALID;
  wire [31:0]m_axi_frame_RDATA;
  wire m_axi_frame_RLAST;
  wire m_axi_frame_RREADY;
  wire [1:0]m_axi_frame_RRESP;
  wire m_axi_frame_RVALID;
  wire [63:0]m_axi_output_r_AWADDR;
  wire [7:0]m_axi_output_r_AWLEN;
  wire m_axi_output_r_AWREADY;
  wire m_axi_output_r_AWVALID;
  wire m_axi_output_r_BREADY;
  wire m_axi_output_r_BVALID;
  wire [31:0]m_axi_output_r_WDATA;
  wire m_axi_output_r_WLAST;
  wire m_axi_output_r_WREADY;
  wire [3:0]m_axi_output_r_WSTRB;
  wire m_axi_output_r_WVALID;
  wire [5:0]s_axi_control_ARADDR;
  wire s_axi_control_ARREADY;
  wire s_axi_control_ARVALID;
  wire [5:0]s_axi_control_AWADDR;
  wire s_axi_control_AWREADY;
  wire s_axi_control_AWVALID;
  wire s_axi_control_BREADY;
  wire s_axi_control_BVALID;
  wire [31:0]s_axi_control_RDATA;
  wire s_axi_control_RREADY;
  wire s_axi_control_RVALID;
  wire [31:0]s_axi_control_WDATA;
  wire s_axi_control_WREADY;
  wire [3:0]s_axi_control_WSTRB;
  wire s_axi_control_WVALID;
  wire [63:0]NLW_inst_m_axi_frame_ARADDR_UNCONNECTED;
  wire [63:0]NLW_inst_m_axi_output_r_AWADDR_UNCONNECTED;

  system_blue_locator_packed_0_0_blue_locator_packed inst
       (.ap_clk(ap_clk),
        .ap_rst_n(ap_rst_n),
        .m_axi_frame_ARADDR({m_axi_frame_ARADDR[63:2],NLW_inst_m_axi_frame_ARADDR_UNCONNECTED[1:0]}),
        .m_axi_frame_ARLEN(m_axi_frame_ARLEN[3:0]),
        .m_axi_frame_ARREADY(m_axi_frame_ARREADY),
        .m_axi_frame_ARVALID(m_axi_frame_ARVALID),
        .m_axi_frame_RDATA(m_axi_frame_RDATA),
        .m_axi_frame_RLAST(m_axi_frame_RLAST),
        .m_axi_frame_RREADY(m_axi_frame_RREADY),
        .m_axi_frame_RRESP(m_axi_frame_RRESP),
        .m_axi_frame_RVALID(m_axi_frame_RVALID),
        .m_axi_output_r_AWADDR({m_axi_output_r_AWADDR[63:2],NLW_inst_m_axi_output_r_AWADDR_UNCONNECTED[1:0]}),
        .m_axi_output_r_AWLEN(m_axi_output_r_AWLEN[3:0]),
        .m_axi_output_r_AWREADY(m_axi_output_r_AWREADY),
        .m_axi_output_r_AWVALID(m_axi_output_r_AWVALID),
        .m_axi_output_r_BREADY(m_axi_output_r_BREADY),
        .m_axi_output_r_BVALID(m_axi_output_r_BVALID),
        .m_axi_output_r_WDATA(m_axi_output_r_WDATA),
        .m_axi_output_r_WLAST(m_axi_output_r_WLAST),
        .m_axi_output_r_WREADY(m_axi_output_r_WREADY),
        .m_axi_output_r_WSTRB(m_axi_output_r_WSTRB),
        .m_axi_output_r_WVALID(m_axi_output_r_WVALID),
        .s_axi_control_ARADDR(s_axi_control_ARADDR),
        .s_axi_control_ARREADY(s_axi_control_ARREADY),
        .s_axi_control_ARVALID(s_axi_control_ARVALID),
        .s_axi_control_AWADDR(s_axi_control_AWADDR),
        .s_axi_control_AWREADY(s_axi_control_AWREADY),
        .s_axi_control_AWVALID(s_axi_control_AWVALID),
        .s_axi_control_BREADY(s_axi_control_BREADY),
        .s_axi_control_BVALID(s_axi_control_BVALID),
        .s_axi_control_RDATA(s_axi_control_RDATA),
        .s_axi_control_RREADY(s_axi_control_RREADY),
        .s_axi_control_RVALID(s_axi_control_RVALID),
        .s_axi_control_WDATA(s_axi_control_WDATA),
        .s_axi_control_WREADY(s_axi_control_WREADY),
        .s_axi_control_WSTRB(s_axi_control_WSTRB),
        .s_axi_control_WVALID(s_axi_control_WVALID));
endmodule

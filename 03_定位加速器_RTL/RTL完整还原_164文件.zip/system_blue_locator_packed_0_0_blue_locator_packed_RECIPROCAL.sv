// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_RECIPROCAL
   (B,
    ap_clk,
    Q,
    q0_reg,
    q0_reg_0,
    pwropt,
    pwropt_1);
  output [16:0]B;
  input ap_clk;
  input [0:0]Q;
  input [3:0]q0_reg;
  input [4:0]q0_reg_0;
  input pwropt;
  input pwropt_1;

  wire [16:0]B;
  wire [0:0]Q;
  wire ap_clk;
  wire pwropt;
  wire pwropt_1;
  wire [3:0]q0_reg;
  wire [4:0]q0_reg_0;

  system_blue_locator_packed_0_0_blue_locator_packed_RECIPROCAL_rom blue_locator_packed_RECIPROCAL_rom_U
       (.B(B),
        .Q(Q),
        .ap_clk(ap_clk),
        .pwropt(pwropt),
        .pwropt_1(pwropt_1),
        .q0_reg_0(q0_reg),
        .q0_reg_1(q0_reg_0));
endmodule

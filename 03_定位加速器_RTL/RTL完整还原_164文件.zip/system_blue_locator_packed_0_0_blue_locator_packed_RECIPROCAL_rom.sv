// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_RECIPROCAL_rom
   (B,
    ap_clk,
    Q,
    q0_reg_0,
    q0_reg_1,
    pwropt,
    pwropt_1);
  output [16:0]B;
  input ap_clk;
  input [0:0]Q;
  input [3:0]q0_reg_0;
  input [4:0]q0_reg_1;
  input pwropt;
  input pwropt_1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [16:0]B;
  wire GND_cooolDelFlop_1;
  wire [0:0]Q;
  wire VCC_cooolDelFlop_1;
  wire ap_clk;
  wire pwropt;
  wire pwropt_1;
  wire [3:0]q0_reg_0;
  wire [4:0]q0_reg_1;
  wire q0_reg_ENARDEN_cooolgate_en_sig_4;
  wire q0_reg_i_2_n_0;
  wire q0_reg_i_3_n_0;
  wire q0_reg_i_4_n_0;
  wire q0_reg_i_5_n_0;
  wire q0_reg_i_6_n_0;
  wire q0_reg_i_7_n_0;
  wire q0_reg_i_8_n_0;
  wire [7:0]sel;
  wire esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_3cc5514 ;
  wire esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_8d5982f ;
  wire esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_3bebe03 ;
  wire [3:0]NLW_q0_reg_i_2_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed GND: GND_cooolDelFlop
  assign GND_cooolDelFlop_1 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed VCC: VCC_cooolDelFlop
  assign VCC_cooolDelFlop_1 = 1'b1;

  RAMB18E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000001),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h35E538E33C3C4000444449244EC455555D17666671C780009249AAAACCCC0000),
    .INIT_01(256'h25ED28282AAA2D8230C3348338E33E0F44444BDA5555618671C78888AAAA3333),
    .INIT_02(256'h1E1E20002222249227622AAA2E8B333338E340004924555566668000222223EE),
    .INIT_03(256'h19991B4E1D411F812222253C28F52D8233333A83444451EB666619991AF21C71),
    .INIT_04(256'h16C118611A411C711F07222225ED2AAA30C338E344445555147A158E16C11818),
    .INIT_05(256'h14E5168118611A981D412082249229CB30C33A834924111111F712F614141555),
    .INIT_06(256'h13B11555174519991C71200024922AAA333340000EA00F661041113512491381),
    .INIT_07(256'h12F614AF16C119481C71208225ED2D8238E30CCC0D790E380F0F100011111249),
    .INIT_08(256'h129E147A16C119991D41222228F533330B600BFA0CA40D620E380F2B10411181),
    .INIT_09(256'h129E14AF17451A981F07253C2E8B0A3D0AC70B600C0C0CCC0DA70EA00FC01111),
    .INIT_0A(256'h12F6155518611C7122222AAA094F09CC0A570AF30BA20C690D4C0E520F8310EC),
    .INIT_0B(256'h00000000000000000000088808FB097B0A0A0AAA0B600C300D200E380F831111),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(18'h00000),
    .INIT_B(18'h00000),
    .INIT_FILE("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("PERFORMANCE"),
    .READ_WIDTH_A(18),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(18'h00000),
    .SRVAL_B(18'h00000),
    .WRITE_MODE_A("WRITE_FIRST"),
    .WRITE_MODE_B("WRITE_FIRST"),
    .WRITE_WIDTH_A(18),
    .WRITE_WIDTH_B(0)) 
    q0_reg
       (.ADDRARDADDR({esc_const0_a0cf646 ,esc_const0_a0cf646 ,sel,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .ADDRBWRADDR({esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .CLKARDCLK(ap_clk),
        .CLKBWRCLK(esc_const0_a0cf646 ),
        .DIADI({esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .DIBDI({esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .DIPADIP({esc_const0_a0cf646 ,esc_const1_c064970 }),
        .DIPBDIP({esc_const1_c064970 ,esc_const1_c064970 }),
        .DOADO(B[15:0]),
        .DOPADOP(B[16]),
        .ENARDEN(q0_reg_ENARDEN_cooolgate_en_sig_4),
        .ENBWREN(esc_const0_a0cf646 ),
        .REGCEAREGCE(esc_const0_a0cf646 ),
        .REGCEB(esc_const0_a0cf646 ),
        .RSTRAMARSTRAM(esc_const0_a0cf646 ),
        .RSTRAMB(esc_const0_a0cf646 ),
        .RSTREGARSTREG(esc_const0_a0cf646 ),
        .RSTREGB(esc_const0_a0cf646 ),
        .WEA({esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .WEBWE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }));

  // Reconstructed LUT4: q0_reg_ENARDEN_cooolgate_en_gate_4
  assign q0_reg_ENARDEN_cooolgate_en_sig_4 = ((Q) ? (((esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_3cc5514) ? (1'b1) : (((esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_8d5982f) ? (1'b1) : (~(esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_3bebe03)))))) : (1'b0));

  // Reconstructed CARRY4: q0_reg_i_1
  wire [3:0] recovered_7_co, recovered_7_o, recovered_7_s, recovered_7_di;
  assign recovered_7_s = {q0_reg_0[3:1],q0_reg_i_3_n_0};
  assign recovered_7_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,q0_reg_0[0]};
  wire recovered_7_ci = ((q0_reg_i_2_n_0) !== 1'bz) && (q0_reg_i_2_n_0);
  wire recovered_7_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_7_o[0] = recovered_7_s[0] ^ (recovered_7_ci || recovered_7_cy);
  assign recovered_7_co[0] = (recovered_7_s[0] & (recovered_7_ci || recovered_7_cy)) | (~recovered_7_s[0] & recovered_7_di[0]);
  assign recovered_7_o[1] = recovered_7_s[1] ^ recovered_7_co[0];
  assign recovered_7_co[1] = (recovered_7_s[1] & recovered_7_co[0]) | (~recovered_7_s[1] & recovered_7_di[1]);
  assign recovered_7_o[2] = recovered_7_s[2] ^ recovered_7_co[1];
  assign recovered_7_co[2] = (recovered_7_s[2] & recovered_7_co[1]) | (~recovered_7_s[2] & recovered_7_di[2]);
  assign recovered_7_o[3] = recovered_7_s[3] ^ recovered_7_co[2];
  assign recovered_7_co[3] = (recovered_7_s[3] & recovered_7_co[2]) | (~recovered_7_s[3] & recovered_7_di[3]);
  assign sel[7:4] = recovered_7_o;

  // Reconstructed CARRY4: q0_reg_i_2
  wire [3:0] recovered_8_co, recovered_8_o, recovered_8_s, recovered_8_di;
  assign recovered_8_s = {q0_reg_i_5_n_0,q0_reg_i_6_n_0,q0_reg_i_7_n_0,q0_reg_i_8_n_0};
  assign recovered_8_di = {q0_reg_0[3],q0_reg_i_4_n_0,q0_reg_1[1:0]};
  wire recovered_8_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_8_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_8_o[0] = recovered_8_s[0] ^ (recovered_8_ci || recovered_8_cy);
  assign recovered_8_co[0] = (recovered_8_s[0] & (recovered_8_ci || recovered_8_cy)) | (~recovered_8_s[0] & recovered_8_di[0]);
  assign recovered_8_o[1] = recovered_8_s[1] ^ recovered_8_co[0];
  assign recovered_8_co[1] = (recovered_8_s[1] & recovered_8_co[0]) | (~recovered_8_s[1] & recovered_8_di[1]);
  assign recovered_8_o[2] = recovered_8_s[2] ^ recovered_8_co[1];
  assign recovered_8_co[2] = (recovered_8_s[2] & recovered_8_co[1]) | (~recovered_8_s[2] & recovered_8_di[2]);
  assign recovered_8_o[3] = recovered_8_s[3] ^ recovered_8_co[2];
  assign recovered_8_co[3] = (recovered_8_s[3] & recovered_8_co[2]) | (~recovered_8_s[3] & recovered_8_di[3]);
  assign {q0_reg_i_2_n_0,NLW_q0_reg_i_2_CO_UNCONNECTED[2:0]} = recovered_8_co;
  assign sel[3:0] = recovered_8_o;

  // Reconstructed LUT4: q0_reg_i_3
  assign q0_reg_i_3_n_0 = ((q0_reg_1[4]) ? (((q0_reg_1[2]) ? (~(q0_reg_0[0])) : (((q0_reg_1[3]) ? (~(q0_reg_0[0])) : (q0_reg_0[0]))))) : (((q0_reg_1[2]) ? (q0_reg_0[0]) : (((q0_reg_1[3]) ? (q0_reg_0[0]) : (~(q0_reg_0[0])))))));

  // Reconstructed LUT1: q0_reg_i_4
  assign q0_reg_i_4_n_0 = ~(q0_reg_1[2]);

  // Reconstructed LUT3: q0_reg_i_5
  assign q0_reg_i_5_n_0 = ((q0_reg_0[3]) ? (((q0_reg_1[3]) ? (~(q0_reg_1[2])) : (q0_reg_1[2]))) : (((q0_reg_1[3]) ? (q0_reg_1[2]) : (~(q0_reg_1[2])))));

  // Reconstructed LUT2: q0_reg_i_6
  assign q0_reg_i_6_n_0 = ((q0_reg_0[2]) ? (q0_reg_1[2]) : (~(q0_reg_1[2])));

  // Reconstructed LUT2: q0_reg_i_7
  assign q0_reg_i_7_n_0 = ((q0_reg_0[1]) ? (~(q0_reg_1[1])) : (q0_reg_1[1]));

  // Reconstructed LUT2: q0_reg_i_8
  assign q0_reg_i_8_n_0 = ((q0_reg_0[0]) ? (~(q0_reg_1[0])) : (q0_reg_1[0]));

  // Reconstructed FDCE: esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_90a5e43
  reg recovered_15_q = 1'b1;
  assign esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_3cc5514 = recovered_15_q;
  wire recovered_15_reset = ((GND_cooolDelFlop_1)) && ((GND_cooolDelFlop_1) !== 1'bz);
  always @(posedge ap_clk or posedge recovered_15_reset) begin
    if (recovered_15_reset || (((GND_cooolDelFlop_1) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((VCC_cooolDelFlop_1) || ((VCC_cooolDelFlop_1) === 1'bz) || (((VCC_cooolDelFlop_1) === 1'bx) && (recovered_15_q == (pwropt)))) recovered_15_q <= (pwropt);
  end

  // Reconstructed FDCE: esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_80c6cdb
  reg recovered_16_q = 1'b1;
  assign esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_8d5982f = recovered_16_q;
  wire recovered_16_reset = ((GND_cooolDelFlop_1)) && ((GND_cooolDelFlop_1) !== 1'bz);
  always @(posedge ap_clk or posedge recovered_16_reset) begin
    if (recovered_16_reset || (((GND_cooolDelFlop_1) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((VCC_cooolDelFlop_1) || ((VCC_cooolDelFlop_1) === 1'bz) || (((VCC_cooolDelFlop_1) === 1'bx) && (recovered_16_q == (pwropt_1)))) recovered_16_q <= (pwropt_1);
  end

  // Reconstructed FDCE: esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_742248f
  reg recovered_17_q = 1'b0;
  assign esc_system_i_blue_locator_packed_0_inst_RECIPROCAL_U_blue_locator_packed_RECIPROCAL_rom_U_q0_r_3bebe03 = recovered_17_q;
  wire recovered_17_reset = ((GND_cooolDelFlop_1)) && ((GND_cooolDelFlop_1) !== 1'bz);
  always @(posedge ap_clk or posedge recovered_17_reset) begin
    if (recovered_17_reset || (((GND_cooolDelFlop_1) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((VCC_cooolDelFlop_1) || ((VCC_cooolDelFlop_1) === 1'bz) || (((VCC_cooolDelFlop_1) === 1'bx) && (recovered_17_q == (Q)))) recovered_17_q <= (Q);
  end

endmodule

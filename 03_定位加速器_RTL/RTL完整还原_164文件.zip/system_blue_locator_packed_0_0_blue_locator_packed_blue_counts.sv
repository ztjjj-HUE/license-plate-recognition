// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_blue_counts
   (DOADO,
    D,
    esc_add_ln208_40_reg_7067_reg_8_4748565 ,
    esc_add_ln208_44_reg_7119_reg_9_9449ba5 ,
    esc_add_ln208_47_reg_7171_reg_9_5141771 ,
    esc_add_ln208_50_reg_7223_reg_10_aa3bb5f ,
    esc_add_ln208_53_reg_7275_reg_10_0754859 ,
    esc_add_ln208_56_reg_7327_reg_10_b6e53dd ,
    esc_add_ln208_59_reg_7379_reg_10_8ef5260 ,
    esc_add_ln208_62_reg_7431_reg_11_6ab2f6a ,
    esc_add_ln208_65_reg_7483_reg_11_f154d09 ,
    esc_add_ln208_68_reg_7535_reg_11_e9aafb9 ,
    esc_add_ln208_71_reg_7587_reg_11_d2760f7 ,
    esc_add_ln208_74_reg_7649_reg_11_23515cd ,
    esc_add_ln208_77_reg_7711_reg_11_bc8d80b ,
    esc_add_ln208_80_reg_7773_reg_11_d71fa1b ,
    esc_add_ln208_83_reg_7835_reg_11_118cabd ,
    esc_add_ln208_86_reg_7897_reg_12_202b975 ,
    esc_add_ln208_89_reg_7959_reg_12_637a141 ,
    esc_add_ln208_92_reg_8021_reg_12_8f48385 ,
    esc_add_ln208_95_reg_8083_reg_12_2d1a536 ,
    esc_add_ln208_98_reg_8125_reg_12_1367b81 ,
    esc_add_ln208_101_reg_8167_reg_12_d11b77b ,
    esc_add_ln208_104_reg_8199_reg_12_b9a1976 ,
    esc_add_ln208_107_reg_8231_reg_12_85508a2 ,
    esc_add_ln208_110_reg_8263_reg_12_8c4af8a ,
    esc_add_ln208_113_reg_8295_reg_12_525514a ,
    esc_add_ln208_116_reg_8327_reg_12_e26cb33 ,
    esc_add_ln208_119_reg_8359_reg_12_abf25fc ,
    esc_add_ln208_122_reg_8391_reg_12_c056c12 ,
    esc_add_ln208_125_reg_8423_reg_12_a546884 ,
    esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 ,
    esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 ,
    esc_add_ln208_134_reg_8519_reg_13_79685f6 ,
    esc_add_ln208_137_reg_8551_reg_13_711eea5 ,
    esc_add_ln208_140_reg_8583_reg_13_3a2afb7 ,
    esc_add_ln208_143_reg_8615_reg_13_7ea25a2 ,
    esc_add_ln208_146_reg_8647_reg_13_c285ab8 ,
    esc_add_ln208_149_reg_8679_reg_13_a787366 ,
    zext_ln208_86_fu_5765_p1,
    ap_enable_reg_pp1_iter1_reg,
    esc_mul_ln215_reg_6908_reg_0_b3fe01c ,
    esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ,
    esc_mul_ln215_reg_6908_reg_0__1_55582ee ,
    ap_clk,
    blue_counts_ce0,
    Q,
    esc_add_ln208_47_reg_7171_reg_9__0_3783b12 ,
    esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 ,
    esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 ,
    esc_add_ln208_56_reg_7327_reg_10__0_e100627 ,
    esc_add_ln208_59_reg_7379_reg_10__0_cb96932 ,
    esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 ,
    esc_add_ln208_65_reg_7483_reg_11__0_6caa48b ,
    esc_add_ln208_68_reg_7535_reg_11__0_eeee088 ,
    esc_add_ln208_71_reg_7587_reg_11__0_248299a ,
    esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e ,
    esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 ,
    esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 ,
    esc_add_ln208_83_reg_7835_reg_11__0_741884e ,
    esc_add_ln208_86_reg_7897_reg_11_897ebea ,
    esc_add_ln208_89_reg_7959_reg_12__0_27a5822 ,
    esc_add_ln208_92_reg_8021_reg_12__0_1f8120a ,
    esc_add_ln208_95_reg_8083_reg_12__0_30298fc ,
    esc_add_ln208_98_reg_8125_reg_12__0_2065764 ,
    esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 ,
    esc_add_ln208_104_reg_8199_reg_12__0_418f127 ,
    esc_add_ln208_107_reg_8231_reg_12__0_575cc95 ,
    esc_add_ln208_110_reg_8263_reg_12__0_42182a4 ,
    esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 ,
    esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 ,
    esc_add_ln208_119_reg_8359_reg_12__0_63393ef ,
    esc_add_ln208_122_reg_8391_reg_12__0_cec336a ,
    esc_add_ln208_125_reg_8423_reg_12__0_5cba652 ,
    esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 ,
    esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 ,
    esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f ,
    esc_add_ln208_137_reg_8551_reg_13__0_215f155 ,
    esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 ,
    esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 ,
    esc_add_ln208_146_reg_8647_reg_13__0_24263ad ,
    esc_add_ln208_149_reg_8679_reg_13__0_b628b5d ,
    esc_add_ln208_152_reg_8711_reg_13_848699e ,
    esc_add_ln208_39_reg_8728_reg_15_81ea661 ,
    ram0_reg,
    ram0_reg_0,
    ram0_reg_1,
    ram0_reg_2,
    ram0_reg_3,
    ram0_reg_4,
    data42,
    ram0_reg_i_25,
    ram0_reg_i_25_0,
    ram0_reg_i_53,
    ram0_reg_5,
    ram0_reg_6,
    ram0_reg_7,
    ram0_reg_8,
    ram0_reg_9,
    ram0_reg_10,
    ram0_reg_11,
    ram0_reg_12,
    ram0_reg_13,
    ram0_reg_14,
    ram0_reg_15,
    ram0_reg_16,
    ram0_reg_17,
    ram0_reg_18,
    ram0_reg_19,
    ram0_reg_20,
    ram0_reg_21,
    ram0_reg_22,
    ram0_reg_23,
    ram0_reg_24,
    ram0_reg_25,
    ram0_reg_26,
    ram0_reg_27,
    ram0_reg_28,
    ram0_reg_29,
    ram0_reg_30,
    ap_enable_reg_pp1_iter0,
    ram0_reg_31,
    ram0_reg_32,
    ram0_reg_33,
    ram0_reg_34,
    ram0_reg_35,
    ram0_reg_36,
    ram0_reg_37,
    ap_enable_reg_pp0_iter1,
    previous_blue_1_reg_6804,
    ram0_reg_38,
    ap_phi_mux_y_2_phi_fu_2389_p4,
    ram0_reg_39,
    mul_ln215_reg_6908,
    ram0_reg_40,
    ram0_reg_41,
    ram0_reg_42,
    ram0_reg_43,
    ram0_reg_44,
    ram0_reg_i_53_0,
    ram0_reg_i_53_1,
    ap_enable_reg_pp3_iter0);
  output [7:0]DOADO;
  output [8:0]D;
  output [9:0]esc_add_ln208_40_reg_7067_reg_8_4748565 ;
  output [9:0]esc_add_ln208_44_reg_7119_reg_9_9449ba5 ;
  output [10:0]esc_add_ln208_47_reg_7171_reg_9_5141771 ;
  output [10:0]esc_add_ln208_50_reg_7223_reg_10_aa3bb5f ;
  output [10:0]esc_add_ln208_53_reg_7275_reg_10_0754859 ;
  output [10:0]esc_add_ln208_56_reg_7327_reg_10_b6e53dd ;
  output [11:0]esc_add_ln208_59_reg_7379_reg_10_8ef5260 ;
  output [11:0]esc_add_ln208_62_reg_7431_reg_11_6ab2f6a ;
  output [11:0]esc_add_ln208_65_reg_7483_reg_11_f154d09 ;
  output [11:0]esc_add_ln208_68_reg_7535_reg_11_e9aafb9 ;
  output [11:0]esc_add_ln208_71_reg_7587_reg_11_d2760f7 ;
  output [11:0]esc_add_ln208_74_reg_7649_reg_11_23515cd ;
  output [11:0]esc_add_ln208_77_reg_7711_reg_11_bc8d80b ;
  output [11:0]esc_add_ln208_80_reg_7773_reg_11_d71fa1b ;
  output [12:0]esc_add_ln208_83_reg_7835_reg_11_118cabd ;
  output [12:0]esc_add_ln208_86_reg_7897_reg_12_202b975 ;
  output [12:0]esc_add_ln208_89_reg_7959_reg_12_637a141 ;
  output [12:0]esc_add_ln208_92_reg_8021_reg_12_8f48385 ;
  output [12:0]esc_add_ln208_95_reg_8083_reg_12_2d1a536 ;
  output [12:0]esc_add_ln208_98_reg_8125_reg_12_1367b81 ;
  output [12:0]esc_add_ln208_101_reg_8167_reg_12_d11b77b ;
  output [12:0]esc_add_ln208_104_reg_8199_reg_12_b9a1976 ;
  output [12:0]esc_add_ln208_107_reg_8231_reg_12_85508a2 ;
  output [12:0]esc_add_ln208_110_reg_8263_reg_12_8c4af8a ;
  output [12:0]esc_add_ln208_113_reg_8295_reg_12_525514a ;
  output [12:0]esc_add_ln208_116_reg_8327_reg_12_e26cb33 ;
  output [12:0]esc_add_ln208_119_reg_8359_reg_12_abf25fc ;
  output [12:0]esc_add_ln208_122_reg_8391_reg_12_c056c12 ;
  output [12:0]esc_add_ln208_125_reg_8423_reg_12_a546884 ;
  output [12:0]esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 ;
  output [13:0]esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 ;
  output [13:0]esc_add_ln208_134_reg_8519_reg_13_79685f6 ;
  output [13:0]esc_add_ln208_137_reg_8551_reg_13_711eea5 ;
  output [13:0]esc_add_ln208_140_reg_8583_reg_13_3a2afb7 ;
  output [13:0]esc_add_ln208_143_reg_8615_reg_13_7ea25a2 ;
  output [13:0]esc_add_ln208_146_reg_8647_reg_13_c285ab8 ;
  output [13:0]esc_add_ln208_149_reg_8679_reg_13_a787366 ;
  output [13:0]zext_ln208_86_fu_5765_p1;
  output ap_enable_reg_pp1_iter1_reg;
  output esc_mul_ln215_reg_6908_reg_0_b3fe01c ;
  output esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ;
  output esc_mul_ln215_reg_6908_reg_0__1_55582ee ;
  input ap_clk;
  input blue_counts_ce0;
  input [8:0]Q;
  input [9:0]esc_add_ln208_47_reg_7171_reg_9__0_3783b12 ;
  input [9:0]esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 ;
  input [10:0]esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 ;
  input [10:0]esc_add_ln208_56_reg_7327_reg_10__0_e100627 ;
  input [10:0]esc_add_ln208_59_reg_7379_reg_10__0_cb96932 ;
  input [10:0]esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 ;
  input [11:0]esc_add_ln208_65_reg_7483_reg_11__0_6caa48b ;
  input [11:0]esc_add_ln208_68_reg_7535_reg_11__0_eeee088 ;
  input [11:0]esc_add_ln208_71_reg_7587_reg_11__0_248299a ;
  input [11:0]esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e ;
  input [11:0]esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 ;
  input [11:0]esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 ;
  input [11:0]esc_add_ln208_83_reg_7835_reg_11__0_741884e ;
  input [11:0]esc_add_ln208_86_reg_7897_reg_11_897ebea ;
  input [12:0]esc_add_ln208_89_reg_7959_reg_12__0_27a5822 ;
  input [12:0]esc_add_ln208_92_reg_8021_reg_12__0_1f8120a ;
  input [12:0]esc_add_ln208_95_reg_8083_reg_12__0_30298fc ;
  input [12:0]esc_add_ln208_98_reg_8125_reg_12__0_2065764 ;
  input [12:0]esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 ;
  input [12:0]esc_add_ln208_104_reg_8199_reg_12__0_418f127 ;
  input [12:0]esc_add_ln208_107_reg_8231_reg_12__0_575cc95 ;
  input [12:0]esc_add_ln208_110_reg_8263_reg_12__0_42182a4 ;
  input [12:0]esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 ;
  input [12:0]esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 ;
  input [12:0]esc_add_ln208_119_reg_8359_reg_12__0_63393ef ;
  input [12:0]esc_add_ln208_122_reg_8391_reg_12__0_cec336a ;
  input [12:0]esc_add_ln208_125_reg_8423_reg_12__0_5cba652 ;
  input [12:0]esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 ;
  input [12:0]esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 ;
  input [12:0]esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f ;
  input [13:0]esc_add_ln208_137_reg_8551_reg_13__0_215f155 ;
  input [13:0]esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 ;
  input [13:0]esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 ;
  input [13:0]esc_add_ln208_146_reg_8647_reg_13__0_24263ad ;
  input [13:0]esc_add_ln208_149_reg_8679_reg_13__0_b628b5d ;
  input [13:0]esc_add_ln208_152_reg_8711_reg_13_848699e ;
  input [13:0]esc_add_ln208_39_reg_8728_reg_15_81ea661 ;
  input ram0_reg;
  input ram0_reg_0;
  input ram0_reg_1;
  input ram0_reg_2;
  input ram0_reg_3;
  input ram0_reg_4;
  input [8:0]data42;
  input [10:0]ram0_reg_i_25;
  input [10:0]ram0_reg_i_25_0;
  input [7:0]ram0_reg_i_53;
  input ram0_reg_5;
  input [7:0]ram0_reg_6;
  input ram0_reg_7;
  input ram0_reg_8;
  input ram0_reg_9;
  input [1:0]ram0_reg_10;
  input ram0_reg_11;
  input ram0_reg_12;
  input ram0_reg_13;
  input ram0_reg_14;
  input ram0_reg_15;
  input ram0_reg_16;
  input ram0_reg_17;
  input ram0_reg_18;
  input ram0_reg_19;
  input ram0_reg_20;
  input ram0_reg_21;
  input ram0_reg_22;
  input ram0_reg_23;
  input ram0_reg_24;
  input ram0_reg_25;
  input ram0_reg_26;
  input ram0_reg_27;
  input ram0_reg_28;
  input [2:0]ram0_reg_29;
  input ram0_reg_30;
  input ap_enable_reg_pp1_iter0;
  input ram0_reg_31;
  input ram0_reg_32;
  input ram0_reg_33;
  input ram0_reg_34;
  input ram0_reg_35;
  input ram0_reg_36;
  input ram0_reg_37;
  input ap_enable_reg_pp0_iter1;
  input previous_blue_1_reg_6804;
  input ram0_reg_38;
  input [0:0]ap_phi_mux_y_2_phi_fu_2389_p4;
  input ram0_reg_39;
  input [0:0]mul_ln215_reg_6908;
  input ram0_reg_40;
  input ram0_reg_41;
  input ram0_reg_42;
  input ram0_reg_43;
  input ram0_reg_44;
  input ram0_reg_i_53_0;
  input ram0_reg_i_53_1;
  input ap_enable_reg_pp3_iter0;

  wire [8:0]D;
  wire [7:0]DOADO;
  wire [8:0]Q;
  wire [12:0]esc_add_ln208_101_reg_8167_reg_12_d11b77b ;
  wire [12:0]esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 ;
  wire [12:0]esc_add_ln208_104_reg_8199_reg_12_b9a1976 ;
  wire [12:0]esc_add_ln208_104_reg_8199_reg_12__0_418f127 ;
  wire [12:0]esc_add_ln208_107_reg_8231_reg_12_85508a2 ;
  wire [12:0]esc_add_ln208_107_reg_8231_reg_12__0_575cc95 ;
  wire [12:0]esc_add_ln208_110_reg_8263_reg_12_8c4af8a ;
  wire [12:0]esc_add_ln208_110_reg_8263_reg_12__0_42182a4 ;
  wire [12:0]esc_add_ln208_113_reg_8295_reg_12_525514a ;
  wire [12:0]esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 ;
  wire [12:0]esc_add_ln208_116_reg_8327_reg_12_e26cb33 ;
  wire [12:0]esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 ;
  wire [12:0]esc_add_ln208_119_reg_8359_reg_12_abf25fc ;
  wire [12:0]esc_add_ln208_119_reg_8359_reg_12__0_63393ef ;
  wire [12:0]esc_add_ln208_122_reg_8391_reg_12_c056c12 ;
  wire [12:0]esc_add_ln208_122_reg_8391_reg_12__0_cec336a ;
  wire [12:0]esc_add_ln208_125_reg_8423_reg_12_a546884 ;
  wire [12:0]esc_add_ln208_125_reg_8423_reg_12__0_5cba652 ;
  wire [12:0]esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 ;
  wire [12:0]esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 ;
  wire [13:0]esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 ;
  wire [12:0]esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 ;
  wire [13:0]esc_add_ln208_134_reg_8519_reg_13_79685f6 ;
  wire [12:0]esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f ;
  wire [13:0]esc_add_ln208_137_reg_8551_reg_13_711eea5 ;
  wire [13:0]esc_add_ln208_137_reg_8551_reg_13__0_215f155 ;
  wire [13:0]esc_add_ln208_140_reg_8583_reg_13_3a2afb7 ;
  wire [13:0]esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 ;
  wire [13:0]esc_add_ln208_143_reg_8615_reg_13_7ea25a2 ;
  wire [13:0]esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 ;
  wire [13:0]esc_add_ln208_146_reg_8647_reg_13_c285ab8 ;
  wire [13:0]esc_add_ln208_146_reg_8647_reg_13__0_24263ad ;
  wire [13:0]esc_add_ln208_149_reg_8679_reg_13_a787366 ;
  wire [13:0]esc_add_ln208_149_reg_8679_reg_13__0_b628b5d ;
  wire [13:0]esc_add_ln208_152_reg_8711_reg_13_848699e ;
  wire [13:0]esc_add_ln208_39_reg_8728_reg_15_81ea661 ;
  wire [9:0]esc_add_ln208_40_reg_7067_reg_8_4748565 ;
  wire [9:0]esc_add_ln208_44_reg_7119_reg_9_9449ba5 ;
  wire [10:0]esc_add_ln208_47_reg_7171_reg_9_5141771 ;
  wire [9:0]esc_add_ln208_47_reg_7171_reg_9__0_3783b12 ;
  wire [10:0]esc_add_ln208_50_reg_7223_reg_10_aa3bb5f ;
  wire [9:0]esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 ;
  wire [10:0]esc_add_ln208_53_reg_7275_reg_10_0754859 ;
  wire [10:0]esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 ;
  wire [10:0]esc_add_ln208_56_reg_7327_reg_10_b6e53dd ;
  wire [10:0]esc_add_ln208_56_reg_7327_reg_10__0_e100627 ;
  wire [11:0]esc_add_ln208_59_reg_7379_reg_10_8ef5260 ;
  wire [10:0]esc_add_ln208_59_reg_7379_reg_10__0_cb96932 ;
  wire [11:0]esc_add_ln208_62_reg_7431_reg_11_6ab2f6a ;
  wire [10:0]esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 ;
  wire [11:0]esc_add_ln208_65_reg_7483_reg_11_f154d09 ;
  wire [11:0]esc_add_ln208_65_reg_7483_reg_11__0_6caa48b ;
  wire [11:0]esc_add_ln208_68_reg_7535_reg_11_e9aafb9 ;
  wire [11:0]esc_add_ln208_68_reg_7535_reg_11__0_eeee088 ;
  wire [11:0]esc_add_ln208_71_reg_7587_reg_11_d2760f7 ;
  wire [11:0]esc_add_ln208_71_reg_7587_reg_11__0_248299a ;
  wire [11:0]esc_add_ln208_74_reg_7649_reg_11_23515cd ;
  wire [11:0]esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e ;
  wire [11:0]esc_add_ln208_77_reg_7711_reg_11_bc8d80b ;
  wire [11:0]esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 ;
  wire [11:0]esc_add_ln208_80_reg_7773_reg_11_d71fa1b ;
  wire [11:0]esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 ;
  wire [12:0]esc_add_ln208_83_reg_7835_reg_11_118cabd ;
  wire [11:0]esc_add_ln208_83_reg_7835_reg_11__0_741884e ;
  wire [11:0]esc_add_ln208_86_reg_7897_reg_11_897ebea ;
  wire [12:0]esc_add_ln208_86_reg_7897_reg_12_202b975 ;
  wire [12:0]esc_add_ln208_89_reg_7959_reg_12_637a141 ;
  wire [12:0]esc_add_ln208_89_reg_7959_reg_12__0_27a5822 ;
  wire [12:0]esc_add_ln208_92_reg_8021_reg_12_8f48385 ;
  wire [12:0]esc_add_ln208_92_reg_8021_reg_12__0_1f8120a ;
  wire [12:0]esc_add_ln208_95_reg_8083_reg_12_2d1a536 ;
  wire [12:0]esc_add_ln208_95_reg_8083_reg_12__0_30298fc ;
  wire [12:0]esc_add_ln208_98_reg_8125_reg_12_1367b81 ;
  wire [12:0]esc_add_ln208_98_reg_8125_reg_12__0_2065764 ;
  wire ap_clk;
  wire ap_enable_reg_pp0_iter1;
  wire ap_enable_reg_pp1_iter0;
  wire ap_enable_reg_pp1_iter1_reg;
  wire ap_enable_reg_pp3_iter0;
  wire [0:0]ap_phi_mux_y_2_phi_fu_2389_p4;
  wire blue_counts_ce0;
  wire [8:0]data42;
  wire [0:0]mul_ln215_reg_6908;
  wire esc_mul_ln215_reg_6908_reg_0_b3fe01c ;
  wire esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ;
  wire esc_mul_ln215_reg_6908_reg_0__1_55582ee ;
  wire previous_blue_1_reg_6804;
  wire ram0_reg;
  wire ram0_reg_0;
  wire ram0_reg_1;
  wire [1:0]ram0_reg_10;
  wire ram0_reg_11;
  wire ram0_reg_12;
  wire ram0_reg_13;
  wire ram0_reg_14;
  wire ram0_reg_15;
  wire ram0_reg_16;
  wire ram0_reg_17;
  wire ram0_reg_18;
  wire ram0_reg_19;
  wire ram0_reg_2;
  wire ram0_reg_20;
  wire ram0_reg_21;
  wire ram0_reg_22;
  wire ram0_reg_23;
  wire ram0_reg_24;
  wire ram0_reg_25;
  wire ram0_reg_26;
  wire ram0_reg_27;
  wire ram0_reg_28;
  wire [2:0]ram0_reg_29;
  wire ram0_reg_3;
  wire ram0_reg_30;
  wire ram0_reg_31;
  wire ram0_reg_32;
  wire ram0_reg_33;
  wire ram0_reg_34;
  wire ram0_reg_35;
  wire ram0_reg_36;
  wire ram0_reg_37;
  wire ram0_reg_38;
  wire ram0_reg_39;
  wire ram0_reg_4;
  wire ram0_reg_40;
  wire ram0_reg_41;
  wire ram0_reg_42;
  wire ram0_reg_43;
  wire ram0_reg_44;
  wire ram0_reg_5;
  wire [7:0]ram0_reg_6;
  wire ram0_reg_7;
  wire ram0_reg_8;
  wire ram0_reg_9;
  wire [10:0]ram0_reg_i_25;
  wire [10:0]ram0_reg_i_25_0;
  wire [7:0]ram0_reg_i_53;
  wire ram0_reg_i_53_0;
  wire ram0_reg_i_53_1;
  wire [13:0]zext_ln208_86_fu_5765_p1;

  system_blue_locator_packed_0_0_blue_locator_packed_blue_counts_ram_9 blue_locator_packed_blue_counts_ram_U
       (.D(D),
        .DOADO(DOADO),
        .Q(Q),
        .esc_add_ln208_101_reg_8167_reg_12_d11b77b (esc_add_ln208_101_reg_8167_reg_12_d11b77b ),
        .esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 (esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 ),
        .esc_add_ln208_104_reg_8199_reg_12_b9a1976 (esc_add_ln208_104_reg_8199_reg_12_b9a1976 ),
        .esc_add_ln208_104_reg_8199_reg_12__0_418f127 (esc_add_ln208_104_reg_8199_reg_12__0_418f127 ),
        .esc_add_ln208_107_reg_8231_reg_12_85508a2 (esc_add_ln208_107_reg_8231_reg_12_85508a2 ),
        .esc_add_ln208_107_reg_8231_reg_12__0_575cc95 (esc_add_ln208_107_reg_8231_reg_12__0_575cc95 ),
        .esc_add_ln208_110_reg_8263_reg_12_8c4af8a (esc_add_ln208_110_reg_8263_reg_12_8c4af8a ),
        .esc_add_ln208_110_reg_8263_reg_12__0_42182a4 (esc_add_ln208_110_reg_8263_reg_12__0_42182a4 ),
        .esc_add_ln208_113_reg_8295_reg_12_525514a (esc_add_ln208_113_reg_8295_reg_12_525514a ),
        .esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 (esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 ),
        .esc_add_ln208_116_reg_8327_reg_12_e26cb33 (esc_add_ln208_116_reg_8327_reg_12_e26cb33 ),
        .esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 (esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 ),
        .esc_add_ln208_119_reg_8359_reg_12_abf25fc (esc_add_ln208_119_reg_8359_reg_12_abf25fc ),
        .esc_add_ln208_119_reg_8359_reg_12__0_63393ef (esc_add_ln208_119_reg_8359_reg_12__0_63393ef ),
        .esc_add_ln208_122_reg_8391_reg_12_c056c12 (esc_add_ln208_122_reg_8391_reg_12_c056c12 ),
        .esc_add_ln208_122_reg_8391_reg_12__0_cec336a (esc_add_ln208_122_reg_8391_reg_12__0_cec336a ),
        .esc_add_ln208_125_reg_8423_reg_12_a546884 (esc_add_ln208_125_reg_8423_reg_12_a546884 ),
        .esc_add_ln208_125_reg_8423_reg_12__0_5cba652 (esc_add_ln208_125_reg_8423_reg_12__0_5cba652 ),
        .esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 (esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 ),
        .esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 (esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 ),
        .esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 (esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 ),
        .esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 (esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 ),
        .esc_add_ln208_134_reg_8519_reg_13_79685f6 (esc_add_ln208_134_reg_8519_reg_13_79685f6 ),
        .esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f (esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f ),
        .esc_add_ln208_137_reg_8551_reg_13_711eea5 (esc_add_ln208_137_reg_8551_reg_13_711eea5 ),
        .esc_add_ln208_137_reg_8551_reg_13__0_215f155 (esc_add_ln208_137_reg_8551_reg_13__0_215f155 ),
        .esc_add_ln208_140_reg_8583_reg_13_3a2afb7 (esc_add_ln208_140_reg_8583_reg_13_3a2afb7 ),
        .esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 (esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 ),
        .esc_add_ln208_143_reg_8615_reg_13_7ea25a2 (esc_add_ln208_143_reg_8615_reg_13_7ea25a2 ),
        .esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 (esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 ),
        .esc_add_ln208_146_reg_8647_reg_13_c285ab8 (esc_add_ln208_146_reg_8647_reg_13_c285ab8 ),
        .esc_add_ln208_146_reg_8647_reg_13__0_24263ad (esc_add_ln208_146_reg_8647_reg_13__0_24263ad ),
        .esc_add_ln208_149_reg_8679_reg_13_a787366 (esc_add_ln208_149_reg_8679_reg_13_a787366 ),
        .esc_add_ln208_149_reg_8679_reg_13__0_b628b5d (esc_add_ln208_149_reg_8679_reg_13__0_b628b5d ),
        .esc_add_ln208_152_reg_8711_reg_13_848699e (esc_add_ln208_152_reg_8711_reg_13_848699e ),
        .esc_add_ln208_39_reg_8728_reg_15_81ea661 (esc_add_ln208_39_reg_8728_reg_15_81ea661 ),
        .esc_add_ln208_40_reg_7067_reg_8_4748565 (esc_add_ln208_40_reg_7067_reg_8_4748565 ),
        .esc_add_ln208_44_reg_7119_reg_9_9449ba5 (esc_add_ln208_44_reg_7119_reg_9_9449ba5 ),
        .esc_add_ln208_47_reg_7171_reg_9_5141771 (esc_add_ln208_47_reg_7171_reg_9_5141771 ),
        .esc_add_ln208_47_reg_7171_reg_9__0_3783b12 (esc_add_ln208_47_reg_7171_reg_9__0_3783b12 ),
        .esc_add_ln208_50_reg_7223_reg_10_aa3bb5f (esc_add_ln208_50_reg_7223_reg_10_aa3bb5f ),
        .esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 (esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 ),
        .esc_add_ln208_53_reg_7275_reg_10_0754859 (esc_add_ln208_53_reg_7275_reg_10_0754859 ),
        .esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 (esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 ),
        .esc_add_ln208_56_reg_7327_reg_10_b6e53dd (esc_add_ln208_56_reg_7327_reg_10_b6e53dd ),
        .esc_add_ln208_56_reg_7327_reg_10__0_e100627 (esc_add_ln208_56_reg_7327_reg_10__0_e100627 ),
        .esc_add_ln208_59_reg_7379_reg_10_8ef5260 (esc_add_ln208_59_reg_7379_reg_10_8ef5260 ),
        .esc_add_ln208_59_reg_7379_reg_10__0_cb96932 (esc_add_ln208_59_reg_7379_reg_10__0_cb96932 ),
        .esc_add_ln208_62_reg_7431_reg_11_6ab2f6a (esc_add_ln208_62_reg_7431_reg_11_6ab2f6a ),
        .esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 (esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 ),
        .esc_add_ln208_65_reg_7483_reg_11_f154d09 (esc_add_ln208_65_reg_7483_reg_11_f154d09 ),
        .esc_add_ln208_65_reg_7483_reg_11__0_6caa48b (esc_add_ln208_65_reg_7483_reg_11__0_6caa48b ),
        .esc_add_ln208_68_reg_7535_reg_11_e9aafb9 (esc_add_ln208_68_reg_7535_reg_11_e9aafb9 ),
        .esc_add_ln208_68_reg_7535_reg_11__0_eeee088 (esc_add_ln208_68_reg_7535_reg_11__0_eeee088 ),
        .esc_add_ln208_71_reg_7587_reg_11_d2760f7 (esc_add_ln208_71_reg_7587_reg_11_d2760f7 ),
        .esc_add_ln208_71_reg_7587_reg_11__0_248299a (esc_add_ln208_71_reg_7587_reg_11__0_248299a ),
        .esc_add_ln208_74_reg_7649_reg_11_23515cd (esc_add_ln208_74_reg_7649_reg_11_23515cd ),
        .esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e (esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e ),
        .esc_add_ln208_77_reg_7711_reg_11_bc8d80b (esc_add_ln208_77_reg_7711_reg_11_bc8d80b ),
        .esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 (esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 ),
        .esc_add_ln208_80_reg_7773_reg_11_d71fa1b (esc_add_ln208_80_reg_7773_reg_11_d71fa1b ),
        .esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 (esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 ),
        .esc_add_ln208_83_reg_7835_reg_11_118cabd (esc_add_ln208_83_reg_7835_reg_11_118cabd ),
        .esc_add_ln208_83_reg_7835_reg_11__0_741884e (esc_add_ln208_83_reg_7835_reg_11__0_741884e ),
        .esc_add_ln208_86_reg_7897_reg_11_897ebea (esc_add_ln208_86_reg_7897_reg_11_897ebea ),
        .esc_add_ln208_86_reg_7897_reg_12_202b975 (esc_add_ln208_86_reg_7897_reg_12_202b975 ),
        .esc_add_ln208_89_reg_7959_reg_12_637a141 (esc_add_ln208_89_reg_7959_reg_12_637a141 ),
        .esc_add_ln208_89_reg_7959_reg_12__0_27a5822 (esc_add_ln208_89_reg_7959_reg_12__0_27a5822 ),
        .esc_add_ln208_92_reg_8021_reg_12_8f48385 (esc_add_ln208_92_reg_8021_reg_12_8f48385 ),
        .esc_add_ln208_92_reg_8021_reg_12__0_1f8120a (esc_add_ln208_92_reg_8021_reg_12__0_1f8120a ),
        .esc_add_ln208_95_reg_8083_reg_12_2d1a536 (esc_add_ln208_95_reg_8083_reg_12_2d1a536 ),
        .esc_add_ln208_95_reg_8083_reg_12__0_30298fc (esc_add_ln208_95_reg_8083_reg_12__0_30298fc ),
        .esc_add_ln208_98_reg_8125_reg_12_1367b81 (esc_add_ln208_98_reg_8125_reg_12_1367b81 ),
        .esc_add_ln208_98_reg_8125_reg_12__0_2065764 (esc_add_ln208_98_reg_8125_reg_12__0_2065764 ),
        .ap_clk(ap_clk),
        .ap_enable_reg_pp0_iter1(ap_enable_reg_pp0_iter1),
        .ap_enable_reg_pp1_iter0(ap_enable_reg_pp1_iter0),
        .ap_enable_reg_pp1_iter1_reg(ap_enable_reg_pp1_iter1_reg),
        .ap_enable_reg_pp3_iter0(ap_enable_reg_pp3_iter0),
        .ap_phi_mux_y_2_phi_fu_2389_p4(ap_phi_mux_y_2_phi_fu_2389_p4),
        .blue_counts_ce0(blue_counts_ce0),
        .data42(data42),
        .mul_ln215_reg_6908(mul_ln215_reg_6908),
        .esc_mul_ln215_reg_6908_reg_0_b3fe01c (esc_mul_ln215_reg_6908_reg_0_b3fe01c ),
        .esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd (esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ),
        .esc_mul_ln215_reg_6908_reg_0__1_55582ee (esc_mul_ln215_reg_6908_reg_0__1_55582ee ),
        .previous_blue_1_reg_6804(previous_blue_1_reg_6804),
        .ram0_reg_0(ram0_reg),
        .ram0_reg_1(ram0_reg_0),
        .ram0_reg_10(ram0_reg_9),
        .ram0_reg_11(ram0_reg_10),
        .ram0_reg_12(ram0_reg_11),
        .ram0_reg_13(ram0_reg_12),
        .ram0_reg_14(ram0_reg_13),
        .ram0_reg_15(ram0_reg_14),
        .ram0_reg_16(ram0_reg_15),
        .ram0_reg_17(ram0_reg_16),
        .ram0_reg_18(ram0_reg_17),
        .ram0_reg_19(ram0_reg_18),
        .ram0_reg_2(ram0_reg_1),
        .ram0_reg_20(ram0_reg_19),
        .ram0_reg_21(ram0_reg_20),
        .ram0_reg_22(ram0_reg_21),
        .ram0_reg_23(ram0_reg_22),
        .ram0_reg_24(ram0_reg_23),
        .ram0_reg_25(ram0_reg_24),
        .ram0_reg_26(ram0_reg_25),
        .ram0_reg_27(ram0_reg_26),
        .ram0_reg_28(ram0_reg_27),
        .ram0_reg_29(ram0_reg_28),
        .ram0_reg_3(ram0_reg_2),
        .ram0_reg_30(ram0_reg_29),
        .ram0_reg_31(ram0_reg_30),
        .ram0_reg_32(ram0_reg_31),
        .ram0_reg_33(ram0_reg_32),
        .ram0_reg_34(ram0_reg_33),
        .ram0_reg_35(ram0_reg_34),
        .ram0_reg_36(ram0_reg_35),
        .ram0_reg_37(ram0_reg_36),
        .ram0_reg_38(ram0_reg_37),
        .ram0_reg_39(ram0_reg_38),
        .ram0_reg_4(ram0_reg_3),
        .ram0_reg_40(ram0_reg_39),
        .ram0_reg_41(ram0_reg_40),
        .ram0_reg_42(ram0_reg_41),
        .ram0_reg_43(ram0_reg_42),
        .ram0_reg_44(ram0_reg_43),
        .ram0_reg_45(ram0_reg_44),
        .ram0_reg_5(ram0_reg_4),
        .ram0_reg_6(ram0_reg_5),
        .ram0_reg_7(ram0_reg_6),
        .ram0_reg_8(ram0_reg_7),
        .ram0_reg_9(ram0_reg_8),
        .ram0_reg_i_25_0(ram0_reg_i_25),
        .ram0_reg_i_25_1(ram0_reg_i_25_0),
        .ram0_reg_i_53_0(ram0_reg_i_53),
        .ram0_reg_i_53_1(ram0_reg_i_53_0),
        .ram0_reg_i_53_2(ram0_reg_i_53_1),
        .zext_ln208_86_fu_5765_p1(zext_ln208_86_fu_5765_p1));
endmodule

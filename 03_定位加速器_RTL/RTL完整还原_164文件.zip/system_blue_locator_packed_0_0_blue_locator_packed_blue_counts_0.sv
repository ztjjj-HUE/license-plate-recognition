// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_blue_counts_0
   (DOADO,
    D,
    CO,
    data42,
    ram0_reg,
    esc_add_ln208_42_reg_7073_reg_8_b2dae6f ,
    esc_add_ln208_45_reg_7125_reg_9_8959fd9 ,
    esc_add_ln208_48_reg_7177_reg_9_c78b76f ,
    esc_add_ln208_51_reg_7229_reg_10_08c463a ,
    esc_add_ln208_54_reg_7281_reg_10_5a808fe ,
    esc_add_ln208_57_reg_7333_reg_10_4817937 ,
    esc_add_ln208_60_reg_7385_reg_10_d918a34 ,
    esc_add_ln208_63_reg_7437_reg_11_9252a9b ,
    esc_add_ln208_66_reg_7489_reg_11_f470215 ,
    esc_add_ln208_69_reg_7541_reg_11_1ab4dac ,
    esc_add_ln208_72_reg_7593_reg_11_6fb0a9c ,
    esc_add_ln208_75_reg_7655_reg_11_3cc2dbe ,
    esc_add_ln208_78_reg_7717_reg_11_a25b5c3 ,
    esc_add_ln208_81_reg_7779_reg_11_758e45d ,
    esc_add_ln208_84_reg_7841_reg_11_3a19824 ,
    esc_add_ln208_87_reg_7903_reg_12_ebbbe3f ,
    esc_add_ln208_90_reg_7965_reg_12_6090767 ,
    esc_add_ln208_93_reg_8027_reg_12_0c8544f ,
    esc_add_ln208_96_reg_8089_reg_12_26fe0a4 ,
    esc_add_ln208_99_reg_8131_reg_12_287a134 ,
    esc_add_ln208_102_reg_8173_reg_12_c8013a3 ,
    esc_add_ln208_105_reg_8205_reg_12_4c8e965 ,
    esc_add_ln208_108_reg_8237_reg_12_b4010f2 ,
    esc_add_ln208_111_reg_8269_reg_12_37e6aa3 ,
    esc_add_ln208_114_reg_8301_reg_12_915e9df ,
    esc_add_ln208_117_reg_8333_reg_12_7252cfb ,
    esc_add_ln208_120_reg_8365_reg_12_09d1f79 ,
    esc_add_ln208_123_reg_8397_reg_12_99743e4 ,
    esc_add_ln208_126_reg_8429_reg_12_387655d ,
    esc_add_ln208_129_reg_8461_reg_12_33d91dc ,
    esc_add_ln208_132_reg_8493_reg_12_7e23985 ,
    esc_add_ln208_135_reg_8525_reg_13_7810c12 ,
    esc_add_ln208_138_reg_8557_reg_13_7e0af06 ,
    esc_add_ln208_141_reg_8589_reg_13_eb89c6f ,
    esc_add_ln208_144_reg_8621_reg_13_47c2a26 ,
    esc_add_ln208_147_reg_8653_reg_13_2be1b94 ,
    esc_add_ln208_150_reg_8685_reg_13_ba3a6fb ,
    zext_ln208_87_fu_5779_p1,
    ap_enable_reg_pp3_iter0_reg_rep,
    ap_enable_reg_pp3_iter0_reg_rep__2,
    esc_ap_CS_fsm_reg_17_dedac0c ,
    ap_enable_reg_pp1_iter0_reg,
    ap_enable_reg_pp1_iter1_reg,
    esc_add_ln74_reg_6855_reg_5_2a13e9b ,
    esc_mul_ln215_reg_6908_reg_0_b3fe01c ,
    esc_add_ln74_reg_6855_reg_5__0_2b6f97c ,
    esc_ap_CS_fsm_reg_17__0_3991a9e ,
    esc_ap_CS_fsm_reg_19_bd70f8c ,
    esc_add_ln74_reg_6855_reg_7_6b2f341 ,
    esc_add_ln74_reg_6855_reg_7__0_abb43a8 ,
    esc_add_ln74_reg_6855_reg_7__1_e9ac382 ,
    esc_add_ln68_reg_8723_reg_2_180a5a5 ,
    esc_add_ln74_reg_6855_reg_8_0e33662 ,
    esc_add_ln74_reg_6855_reg_8__0_dab2ff8 ,
    esc_add_ln74_reg_6855_reg_8__1_c9f6290 ,
    esc_add_ln74_reg_6855_reg_9_9c8c6ed ,
    esc_add_ln74_reg_6855_reg_9__0_2980795 ,
    esc_add_ln74_reg_6855_reg_9__1_9d031f6 ,
    esc_add_ln74_reg_6855_reg_10_52d2cb4 ,
    esc_mul_ln215_reg_6908_reg_1_09f3be8 ,
    esc_add_ln74_reg_6855_reg_10__0_d3d73fa ,
    esc_add_ln68_reg_8723_reg_4_ae92a68 ,
    esc_add_ln74_reg_6855_reg_6_25e4b8d ,
    esc_add_ln74_reg_6855_reg_6__0_8e7e51f ,
    esc_add_ln74_reg_6855_reg_6__1_a3a11c9 ,
    esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ,
    esc_mul_ln215_reg_6908_reg_1__0_292d7d8 ,
    esc_mul_ln215_reg_6908_reg_1__1_b396821 ,
    ap_enable_reg_pp3_iter0_reg,
    esc_ap_CS_fsm_reg_21_af57a65 ,
    ap_enable_reg_pp3_iter0_reg_0,
    esc_ap_CS_fsm_reg_48_486bf78 ,
    ap_enable_reg_pp3_iter0_reg_rep_0,
    esc_ap_CS_fsm_reg_16_2d815ec ,
    esc_ap_CS_fsm_reg_54_3d44ae7 ,
    esc_ap_CS_fsm_reg_48__0_0aa522c ,
    ap_enable_reg_pp3_iter0_reg_rep__2_0,
    ap_enable_reg_pp3_iter0_reg_rep__2_1,
    esc_ap_CS_fsm_reg_35_69cfbc2 ,
    esc_ap_CS_fsm_reg_1_637b98d ,
    esc_ap_CS_fsm_reg_46_ba5f378 ,
    esc_ap_CS_fsm_reg_29_d9f5eab ,
    esc_ap_CS_fsm_reg_35__0_74dd3b9 ,
    esc_ap_CS_fsm_reg_33_3728c13 ,
    esc_ap_CS_fsm_reg_35__1_673f736 ,
    esc_ap_CS_fsm_reg_23_edf6f2f ,
    esc_ap_CS_fsm_reg_26_bc9d1aa ,
    y_reg_22970,
    ap_clk,
    edge_counts_ce0,
    WEA,
    Q,
    esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc ,
    ram0_reg_i_108,
    ram0_reg_i_108_0,
    esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 ,
    esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 ,
    esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b ,
    esc_add_ln208_54_reg_7281_reg_10__0_56b943a ,
    esc_add_ln208_57_reg_7333_reg_10__0_06e9277 ,
    esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 ,
    esc_add_ln208_63_reg_7437_reg_11__0_5853d45 ,
    esc_add_ln208_66_reg_7489_reg_11__0_33e5672 ,
    esc_add_ln208_69_reg_7541_reg_11__0_0318481 ,
    esc_add_ln208_72_reg_7593_reg_11__0_87f0eda ,
    esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 ,
    esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 ,
    esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab ,
    esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 ,
    esc_add_ln208_87_reg_7903_reg_11_09bd1ec ,
    esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f ,
    esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 ,
    esc_add_ln208_96_reg_8089_reg_12__0_4851c79 ,
    esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e ,
    esc_add_ln208_102_reg_8173_reg_12__0_a64db1c ,
    esc_add_ln208_105_reg_8205_reg_12__0_1875a9f ,
    esc_add_ln208_108_reg_8237_reg_12__0_9171fbf ,
    esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 ,
    esc_add_ln208_114_reg_8301_reg_12__0_432a19c ,
    esc_add_ln208_117_reg_8333_reg_12__0_934ade3 ,
    esc_add_ln208_120_reg_8365_reg_12__0_26aac56 ,
    esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 ,
    esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 ,
    esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a ,
    esc_add_ln208_132_reg_8493_reg_12__0_1f22523 ,
    esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 ,
    esc_add_ln208_138_reg_8557_reg_13__0_862abfd ,
    esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 ,
    esc_add_ln208_144_reg_8621_reg_13__0_aba970f ,
    esc_add_ln208_147_reg_8653_reg_13__0_c9f027d ,
    esc_add_ln208_150_reg_8685_reg_13__0_8447d92 ,
    esc_add_ln208_153_reg_8717_reg_13_6aad7d7 ,
    esc_add_ln208_157_reg_8733_reg_15_b87abdb ,
    ram0_reg_0,
    ram0_reg_1,
    ram0_reg_2,
    ram0_reg_i_23__0,
    ap_phi_mux_y_2_phi_fu_2389_p4,
    zext_ln74_2_fu_2977_p1,
    ram0_reg_3,
    ram0_reg_4,
    ram0_reg_i_32,
    ram0_reg_i_32_0,
    mul_ln215_reg_6908,
    esc_y_2_reg_2385_reg_4_1138322 ,
    esc_y_2_reg_2385_reg_4__0_25a3d14 ,
    esc_y_2_reg_2385_reg_3_172fc4c ,
    ram0_reg_i_49,
    ram0_reg_5,
    esc_y_2_reg_2385_reg_3__0_c63e66d ,
    ram0_reg_6,
    ram0_reg_7,
    ap_enable_reg_pp3_iter0,
    ram0_reg_8,
    ram0_reg_9,
    ram0_reg_10,
    ram0_reg_i_62,
    ram0_reg_11,
    ram0_reg_12,
    ram0_reg_i_62_0,
    ram0_reg_13,
    ram0_reg_14,
    ram0_reg_15,
    ram0_reg_16,
    ram0_reg_17,
    ram0_reg_i_54,
    ram0_reg_i_54_0,
    ram0_reg_i_54_1,
    ram0_reg_i_54_2,
    ram0_reg_18,
    ram0_reg_19,
    ap_enable_reg_pp0_iter1,
    ram0_reg_20,
    ram0_reg_i_66,
    ram0_reg_i_66_0,
    ram0_reg_i_66_1,
    ram0_reg_i_66_2,
    ram0_reg_21,
    ram0_reg_i_23__0_0,
    ram0_reg_i_23__0_1,
    ram0_reg_22,
    ram0_reg_23,
    ap_enable_reg_pp1_iter0,
    ram0_reg_24,
    ram0_reg_25,
    ram0_reg_26,
    ram0_reg_27,
    ram0_reg_28,
    ram0_reg_29,
    ram0_reg_30,
    ram0_reg_31,
    ram0_reg_i_63,
    ram0_reg_i_63_0,
    ram0_reg_i_63_1,
    ram0_reg_i_131,
    esc_y_reg_2297_reg_0_8039ace ,
    ram_reg_i_373__0,
    esc_add_ln74_reg_6855_reg_7__2_c3111d6 ,
    esc_add_ln74_reg_6855_reg_6__2_76dcc1d ,
    ram0_reg_32,
    ram0_reg_i_53);
  output [7:0]DOADO;
  output [0:0]D;
  output [0:0]CO;
  output [3:0]data42;
  output [8:0]ram0_reg;
  output [9:0]esc_add_ln208_42_reg_7073_reg_8_b2dae6f ;
  output [9:0]esc_add_ln208_45_reg_7125_reg_9_8959fd9 ;
  output [10:0]esc_add_ln208_48_reg_7177_reg_9_c78b76f ;
  output [10:0]esc_add_ln208_51_reg_7229_reg_10_08c463a ;
  output [10:0]esc_add_ln208_54_reg_7281_reg_10_5a808fe ;
  output [10:0]esc_add_ln208_57_reg_7333_reg_10_4817937 ;
  output [11:0]esc_add_ln208_60_reg_7385_reg_10_d918a34 ;
  output [11:0]esc_add_ln208_63_reg_7437_reg_11_9252a9b ;
  output [11:0]esc_add_ln208_66_reg_7489_reg_11_f470215 ;
  output [11:0]esc_add_ln208_69_reg_7541_reg_11_1ab4dac ;
  output [11:0]esc_add_ln208_72_reg_7593_reg_11_6fb0a9c ;
  output [11:0]esc_add_ln208_75_reg_7655_reg_11_3cc2dbe ;
  output [11:0]esc_add_ln208_78_reg_7717_reg_11_a25b5c3 ;
  output [11:0]esc_add_ln208_81_reg_7779_reg_11_758e45d ;
  output [12:0]esc_add_ln208_84_reg_7841_reg_11_3a19824 ;
  output [12:0]esc_add_ln208_87_reg_7903_reg_12_ebbbe3f ;
  output [12:0]esc_add_ln208_90_reg_7965_reg_12_6090767 ;
  output [12:0]esc_add_ln208_93_reg_8027_reg_12_0c8544f ;
  output [12:0]esc_add_ln208_96_reg_8089_reg_12_26fe0a4 ;
  output [12:0]esc_add_ln208_99_reg_8131_reg_12_287a134 ;
  output [12:0]esc_add_ln208_102_reg_8173_reg_12_c8013a3 ;
  output [12:0]esc_add_ln208_105_reg_8205_reg_12_4c8e965 ;
  output [12:0]esc_add_ln208_108_reg_8237_reg_12_b4010f2 ;
  output [12:0]esc_add_ln208_111_reg_8269_reg_12_37e6aa3 ;
  output [12:0]esc_add_ln208_114_reg_8301_reg_12_915e9df ;
  output [12:0]esc_add_ln208_117_reg_8333_reg_12_7252cfb ;
  output [12:0]esc_add_ln208_120_reg_8365_reg_12_09d1f79 ;
  output [12:0]esc_add_ln208_123_reg_8397_reg_12_99743e4 ;
  output [12:0]esc_add_ln208_126_reg_8429_reg_12_387655d ;
  output [12:0]esc_add_ln208_129_reg_8461_reg_12_33d91dc ;
  output [13:0]esc_add_ln208_132_reg_8493_reg_12_7e23985 ;
  output [13:0]esc_add_ln208_135_reg_8525_reg_13_7810c12 ;
  output [13:0]esc_add_ln208_138_reg_8557_reg_13_7e0af06 ;
  output [13:0]esc_add_ln208_141_reg_8589_reg_13_eb89c6f ;
  output [13:0]esc_add_ln208_144_reg_8621_reg_13_47c2a26 ;
  output [13:0]esc_add_ln208_147_reg_8653_reg_13_2be1b94 ;
  output [13:0]esc_add_ln208_150_reg_8685_reg_13_ba3a6fb ;
  output [13:0]zext_ln208_87_fu_5779_p1;
  output ap_enable_reg_pp3_iter0_reg_rep;
  output ap_enable_reg_pp3_iter0_reg_rep__2;
  output esc_ap_CS_fsm_reg_17_dedac0c ;
  output ap_enable_reg_pp1_iter0_reg;
  output ap_enable_reg_pp1_iter1_reg;
  output esc_add_ln74_reg_6855_reg_5_2a13e9b ;
  output esc_mul_ln215_reg_6908_reg_0_b3fe01c ;
  output esc_add_ln74_reg_6855_reg_5__0_2b6f97c ;
  output esc_ap_CS_fsm_reg_17__0_3991a9e ;
  output esc_ap_CS_fsm_reg_19_bd70f8c ;
  output esc_add_ln74_reg_6855_reg_7_6b2f341 ;
  output esc_add_ln74_reg_6855_reg_7__0_abb43a8 ;
  output esc_add_ln74_reg_6855_reg_7__1_e9ac382 ;
  output [3:0]esc_add_ln68_reg_8723_reg_2_180a5a5 ;
  output esc_add_ln74_reg_6855_reg_8_0e33662 ;
  output esc_add_ln74_reg_6855_reg_8__0_dab2ff8 ;
  output esc_add_ln74_reg_6855_reg_8__1_c9f6290 ;
  output esc_add_ln74_reg_6855_reg_9_9c8c6ed ;
  output esc_add_ln74_reg_6855_reg_9__0_2980795 ;
  output esc_add_ln74_reg_6855_reg_9__1_9d031f6 ;
  output esc_add_ln74_reg_6855_reg_10_52d2cb4 ;
  output esc_mul_ln215_reg_6908_reg_1_09f3be8 ;
  output esc_add_ln74_reg_6855_reg_10__0_d3d73fa ;
  output [3:0]esc_add_ln68_reg_8723_reg_4_ae92a68 ;
  output esc_add_ln74_reg_6855_reg_6_25e4b8d ;
  output esc_add_ln74_reg_6855_reg_6__0_8e7e51f ;
  output esc_add_ln74_reg_6855_reg_6__1_a3a11c9 ;
  output esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ;
  output esc_mul_ln215_reg_6908_reg_1__0_292d7d8 ;
  output esc_mul_ln215_reg_6908_reg_1__1_b396821 ;
  output ap_enable_reg_pp3_iter0_reg;
  output esc_ap_CS_fsm_reg_21_af57a65 ;
  output ap_enable_reg_pp3_iter0_reg_0;
  output esc_ap_CS_fsm_reg_48_486bf78 ;
  output ap_enable_reg_pp3_iter0_reg_rep_0;
  output esc_ap_CS_fsm_reg_16_2d815ec ;
  output esc_ap_CS_fsm_reg_54_3d44ae7 ;
  output esc_ap_CS_fsm_reg_48__0_0aa522c ;
  output ap_enable_reg_pp3_iter0_reg_rep__2_0;
  output ap_enable_reg_pp3_iter0_reg_rep__2_1;
  output esc_ap_CS_fsm_reg_35_69cfbc2 ;
  output esc_ap_CS_fsm_reg_1_637b98d ;
  output esc_ap_CS_fsm_reg_46_ba5f378 ;
  output esc_ap_CS_fsm_reg_29_d9f5eab ;
  output esc_ap_CS_fsm_reg_35__0_74dd3b9 ;
  output esc_ap_CS_fsm_reg_33_3728c13 ;
  output esc_ap_CS_fsm_reg_35__1_673f736 ;
  output esc_ap_CS_fsm_reg_23_edf6f2f ;
  output esc_ap_CS_fsm_reg_26_bc9d1aa ;
  output y_reg_22970;
  input ap_clk;
  input edge_counts_ce0;
  input [0:0]WEA;
  input [0:0]Q;
  input [3:0]esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc ;
  input [2:0]ram0_reg_i_108;
  input [5:0]ram0_reg_i_108_0;
  input [8:0]esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 ;
  input [9:0]esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 ;
  input [9:0]esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b ;
  input [10:0]esc_add_ln208_54_reg_7281_reg_10__0_56b943a ;
  input [10:0]esc_add_ln208_57_reg_7333_reg_10__0_06e9277 ;
  input [10:0]esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 ;
  input [10:0]esc_add_ln208_63_reg_7437_reg_11__0_5853d45 ;
  input [11:0]esc_add_ln208_66_reg_7489_reg_11__0_33e5672 ;
  input [11:0]esc_add_ln208_69_reg_7541_reg_11__0_0318481 ;
  input [11:0]esc_add_ln208_72_reg_7593_reg_11__0_87f0eda ;
  input [11:0]esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 ;
  input [11:0]esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 ;
  input [11:0]esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab ;
  input [11:0]esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 ;
  input [11:0]esc_add_ln208_87_reg_7903_reg_11_09bd1ec ;
  input [12:0]esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f ;
  input [12:0]esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 ;
  input [12:0]esc_add_ln208_96_reg_8089_reg_12__0_4851c79 ;
  input [12:0]esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e ;
  input [12:0]esc_add_ln208_102_reg_8173_reg_12__0_a64db1c ;
  input [12:0]esc_add_ln208_105_reg_8205_reg_12__0_1875a9f ;
  input [12:0]esc_add_ln208_108_reg_8237_reg_12__0_9171fbf ;
  input [12:0]esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 ;
  input [12:0]esc_add_ln208_114_reg_8301_reg_12__0_432a19c ;
  input [12:0]esc_add_ln208_117_reg_8333_reg_12__0_934ade3 ;
  input [12:0]esc_add_ln208_120_reg_8365_reg_12__0_26aac56 ;
  input [12:0]esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 ;
  input [12:0]esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 ;
  input [12:0]esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a ;
  input [12:0]esc_add_ln208_132_reg_8493_reg_12__0_1f22523 ;
  input [12:0]esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 ;
  input [13:0]esc_add_ln208_138_reg_8557_reg_13__0_862abfd ;
  input [13:0]esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 ;
  input [13:0]esc_add_ln208_144_reg_8621_reg_13__0_aba970f ;
  input [13:0]esc_add_ln208_147_reg_8653_reg_13__0_c9f027d ;
  input [13:0]esc_add_ln208_150_reg_8685_reg_13__0_8447d92 ;
  input [13:0]esc_add_ln208_153_reg_8717_reg_13_6aad7d7 ;
  input [13:0]esc_add_ln208_157_reg_8733_reg_15_b87abdb ;
  input ram0_reg_0;
  input ram0_reg_1;
  input ram0_reg_2;
  input [10:0]ram0_reg_i_23__0;
  input [0:0]ap_phi_mux_y_2_phi_fu_2389_p4;
  input [1:0]zext_ln74_2_fu_2977_p1;
  input [5:0]ram0_reg_3;
  input ram0_reg_4;
  input ram0_reg_i_32;
  input ram0_reg_i_32_0;
  input [1:0]mul_ln215_reg_6908;
  input [4:0]esc_y_2_reg_2385_reg_4_1138322 ;
  input [4:0]esc_y_2_reg_2385_reg_4__0_25a3d14 ;
  input esc_y_2_reg_2385_reg_3_172fc4c ;
  input ram0_reg_i_49;
  input [39:0]ram0_reg_5;
  input esc_y_2_reg_2385_reg_3__0_c63e66d ;
  input ram0_reg_6;
  input ram0_reg_7;
  input ap_enable_reg_pp3_iter0;
  input ram0_reg_8;
  input ram0_reg_9;
  input ram0_reg_10;
  input ram0_reg_i_62;
  input ram0_reg_11;
  input ram0_reg_12;
  input ram0_reg_i_62_0;
  input ram0_reg_13;
  input ram0_reg_14;
  input ram0_reg_15;
  input ram0_reg_16;
  input ram0_reg_17;
  input ram0_reg_i_54;
  input ram0_reg_i_54_0;
  input ram0_reg_i_54_1;
  input ram0_reg_i_54_2;
  input ram0_reg_18;
  input ram0_reg_19;
  input ap_enable_reg_pp0_iter1;
  input ram0_reg_20;
  input ram0_reg_i_66;
  input ram0_reg_i_66_0;
  input ram0_reg_i_66_1;
  input ram0_reg_i_66_2;
  input ram0_reg_21;
  input [6:0]ram0_reg_i_23__0_0;
  input [4:0]ram0_reg_i_23__0_1;
  input ram0_reg_22;
  input [7:0]ram0_reg_23;
  input ap_enable_reg_pp1_iter0;
  input ram0_reg_24;
  input ram0_reg_25;
  input ram0_reg_26;
  input ram0_reg_27;
  input ram0_reg_28;
  input ram0_reg_29;
  input ram0_reg_30;
  input ram0_reg_31;
  input ram0_reg_i_63;
  input ram0_reg_i_63_0;
  input ram0_reg_i_63_1;
  input ram0_reg_i_131;
  input esc_y_reg_2297_reg_0_8039ace ;
  input ram_reg_i_373__0;
  input esc_add_ln74_reg_6855_reg_7__2_c3111d6 ;
  input esc_add_ln74_reg_6855_reg_6__2_76dcc1d ;
  input ram0_reg_32;
  input ram0_reg_i_53;

  wire [0:0]CO;
  wire [0:0]D;
  wire [7:0]DOADO;
  wire [0:0]Q;
  wire [0:0]WEA;
  wire [12:0]esc_add_ln208_102_reg_8173_reg_12_c8013a3 ;
  wire [12:0]esc_add_ln208_102_reg_8173_reg_12__0_a64db1c ;
  wire [12:0]esc_add_ln208_105_reg_8205_reg_12_4c8e965 ;
  wire [12:0]esc_add_ln208_105_reg_8205_reg_12__0_1875a9f ;
  wire [12:0]esc_add_ln208_108_reg_8237_reg_12_b4010f2 ;
  wire [12:0]esc_add_ln208_108_reg_8237_reg_12__0_9171fbf ;
  wire [12:0]esc_add_ln208_111_reg_8269_reg_12_37e6aa3 ;
  wire [12:0]esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 ;
  wire [12:0]esc_add_ln208_114_reg_8301_reg_12_915e9df ;
  wire [12:0]esc_add_ln208_114_reg_8301_reg_12__0_432a19c ;
  wire [12:0]esc_add_ln208_117_reg_8333_reg_12_7252cfb ;
  wire [12:0]esc_add_ln208_117_reg_8333_reg_12__0_934ade3 ;
  wire [12:0]esc_add_ln208_120_reg_8365_reg_12_09d1f79 ;
  wire [12:0]esc_add_ln208_120_reg_8365_reg_12__0_26aac56 ;
  wire [12:0]esc_add_ln208_123_reg_8397_reg_12_99743e4 ;
  wire [12:0]esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 ;
  wire [12:0]esc_add_ln208_126_reg_8429_reg_12_387655d ;
  wire [12:0]esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 ;
  wire [12:0]esc_add_ln208_129_reg_8461_reg_12_33d91dc ;
  wire [12:0]esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a ;
  wire [13:0]esc_add_ln208_132_reg_8493_reg_12_7e23985 ;
  wire [12:0]esc_add_ln208_132_reg_8493_reg_12__0_1f22523 ;
  wire [13:0]esc_add_ln208_135_reg_8525_reg_13_7810c12 ;
  wire [12:0]esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 ;
  wire [13:0]esc_add_ln208_138_reg_8557_reg_13_7e0af06 ;
  wire [13:0]esc_add_ln208_138_reg_8557_reg_13__0_862abfd ;
  wire [13:0]esc_add_ln208_141_reg_8589_reg_13_eb89c6f ;
  wire [13:0]esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 ;
  wire [13:0]esc_add_ln208_144_reg_8621_reg_13_47c2a26 ;
  wire [13:0]esc_add_ln208_144_reg_8621_reg_13__0_aba970f ;
  wire [13:0]esc_add_ln208_147_reg_8653_reg_13_2be1b94 ;
  wire [13:0]esc_add_ln208_147_reg_8653_reg_13__0_c9f027d ;
  wire [13:0]esc_add_ln208_150_reg_8685_reg_13_ba3a6fb ;
  wire [13:0]esc_add_ln208_150_reg_8685_reg_13__0_8447d92 ;
  wire [13:0]esc_add_ln208_153_reg_8717_reg_13_6aad7d7 ;
  wire [13:0]esc_add_ln208_157_reg_8733_reg_15_b87abdb ;
  wire [9:0]esc_add_ln208_42_reg_7073_reg_8_b2dae6f ;
  wire [9:0]esc_add_ln208_45_reg_7125_reg_9_8959fd9 ;
  wire [8:0]esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 ;
  wire [10:0]esc_add_ln208_48_reg_7177_reg_9_c78b76f ;
  wire [9:0]esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 ;
  wire [10:0]esc_add_ln208_51_reg_7229_reg_10_08c463a ;
  wire [9:0]esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b ;
  wire [10:0]esc_add_ln208_54_reg_7281_reg_10_5a808fe ;
  wire [10:0]esc_add_ln208_54_reg_7281_reg_10__0_56b943a ;
  wire [10:0]esc_add_ln208_57_reg_7333_reg_10_4817937 ;
  wire [10:0]esc_add_ln208_57_reg_7333_reg_10__0_06e9277 ;
  wire [11:0]esc_add_ln208_60_reg_7385_reg_10_d918a34 ;
  wire [10:0]esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 ;
  wire [11:0]esc_add_ln208_63_reg_7437_reg_11_9252a9b ;
  wire [10:0]esc_add_ln208_63_reg_7437_reg_11__0_5853d45 ;
  wire [11:0]esc_add_ln208_66_reg_7489_reg_11_f470215 ;
  wire [11:0]esc_add_ln208_66_reg_7489_reg_11__0_33e5672 ;
  wire [11:0]esc_add_ln208_69_reg_7541_reg_11_1ab4dac ;
  wire [11:0]esc_add_ln208_69_reg_7541_reg_11__0_0318481 ;
  wire [11:0]esc_add_ln208_72_reg_7593_reg_11_6fb0a9c ;
  wire [11:0]esc_add_ln208_72_reg_7593_reg_11__0_87f0eda ;
  wire [11:0]esc_add_ln208_75_reg_7655_reg_11_3cc2dbe ;
  wire [11:0]esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 ;
  wire [11:0]esc_add_ln208_78_reg_7717_reg_11_a25b5c3 ;
  wire [11:0]esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 ;
  wire [11:0]esc_add_ln208_81_reg_7779_reg_11_758e45d ;
  wire [11:0]esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab ;
  wire [12:0]esc_add_ln208_84_reg_7841_reg_11_3a19824 ;
  wire [11:0]esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 ;
  wire [11:0]esc_add_ln208_87_reg_7903_reg_11_09bd1ec ;
  wire [12:0]esc_add_ln208_87_reg_7903_reg_12_ebbbe3f ;
  wire [12:0]esc_add_ln208_90_reg_7965_reg_12_6090767 ;
  wire [12:0]esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f ;
  wire [12:0]esc_add_ln208_93_reg_8027_reg_12_0c8544f ;
  wire [12:0]esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 ;
  wire [12:0]esc_add_ln208_96_reg_8089_reg_12_26fe0a4 ;
  wire [12:0]esc_add_ln208_96_reg_8089_reg_12__0_4851c79 ;
  wire [12:0]esc_add_ln208_99_reg_8131_reg_12_287a134 ;
  wire [12:0]esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e ;
  wire [3:0]esc_add_ln68_reg_8723_reg_2_180a5a5 ;
  wire [3:0]esc_add_ln68_reg_8723_reg_4_ae92a68 ;
  wire esc_add_ln74_reg_6855_reg_10_52d2cb4 ;
  wire esc_add_ln74_reg_6855_reg_10__0_d3d73fa ;
  wire esc_add_ln74_reg_6855_reg_5_2a13e9b ;
  wire esc_add_ln74_reg_6855_reg_5__0_2b6f97c ;
  wire esc_add_ln74_reg_6855_reg_6_25e4b8d ;
  wire esc_add_ln74_reg_6855_reg_6__0_8e7e51f ;
  wire esc_add_ln74_reg_6855_reg_6__1_a3a11c9 ;
  wire esc_add_ln74_reg_6855_reg_6__2_76dcc1d ;
  wire esc_add_ln74_reg_6855_reg_7_6b2f341 ;
  wire esc_add_ln74_reg_6855_reg_7__0_abb43a8 ;
  wire esc_add_ln74_reg_6855_reg_7__1_e9ac382 ;
  wire esc_add_ln74_reg_6855_reg_7__2_c3111d6 ;
  wire esc_add_ln74_reg_6855_reg_8_0e33662 ;
  wire esc_add_ln74_reg_6855_reg_8__0_dab2ff8 ;
  wire esc_add_ln74_reg_6855_reg_8__1_c9f6290 ;
  wire esc_add_ln74_reg_6855_reg_9_9c8c6ed ;
  wire esc_add_ln74_reg_6855_reg_9__0_2980795 ;
  wire esc_add_ln74_reg_6855_reg_9__1_9d031f6 ;
  wire esc_ap_CS_fsm_reg_16_2d815ec ;
  wire esc_ap_CS_fsm_reg_17_dedac0c ;
  wire esc_ap_CS_fsm_reg_17__0_3991a9e ;
  wire esc_ap_CS_fsm_reg_19_bd70f8c ;
  wire esc_ap_CS_fsm_reg_1_637b98d ;
  wire esc_ap_CS_fsm_reg_21_af57a65 ;
  wire esc_ap_CS_fsm_reg_23_edf6f2f ;
  wire esc_ap_CS_fsm_reg_26_bc9d1aa ;
  wire esc_ap_CS_fsm_reg_29_d9f5eab ;
  wire esc_ap_CS_fsm_reg_33_3728c13 ;
  wire esc_ap_CS_fsm_reg_35_69cfbc2 ;
  wire esc_ap_CS_fsm_reg_35__0_74dd3b9 ;
  wire esc_ap_CS_fsm_reg_35__1_673f736 ;
  wire esc_ap_CS_fsm_reg_46_ba5f378 ;
  wire esc_ap_CS_fsm_reg_48_486bf78 ;
  wire esc_ap_CS_fsm_reg_48__0_0aa522c ;
  wire esc_ap_CS_fsm_reg_54_3d44ae7 ;
  wire ap_clk;
  wire ap_enable_reg_pp0_iter1;
  wire ap_enable_reg_pp1_iter0;
  wire ap_enable_reg_pp1_iter0_reg;
  wire ap_enable_reg_pp1_iter1_reg;
  wire ap_enable_reg_pp3_iter0;
  wire ap_enable_reg_pp3_iter0_reg;
  wire ap_enable_reg_pp3_iter0_reg_0;
  wire ap_enable_reg_pp3_iter0_reg_rep;
  wire ap_enable_reg_pp3_iter0_reg_rep_0;
  wire ap_enable_reg_pp3_iter0_reg_rep__2;
  wire ap_enable_reg_pp3_iter0_reg_rep__2_0;
  wire ap_enable_reg_pp3_iter0_reg_rep__2_1;
  wire [0:0]ap_phi_mux_y_2_phi_fu_2389_p4;
  wire [3:0]data42;
  wire [3:0]esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc ;
  wire edge_counts_ce0;
  wire [1:0]mul_ln215_reg_6908;
  wire esc_mul_ln215_reg_6908_reg_0_b3fe01c ;
  wire esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ;
  wire esc_mul_ln215_reg_6908_reg_1_09f3be8 ;
  wire esc_mul_ln215_reg_6908_reg_1__0_292d7d8 ;
  wire esc_mul_ln215_reg_6908_reg_1__1_b396821 ;
  wire [8:0]ram0_reg;
  wire ram0_reg_0;
  wire ram0_reg_1;
  wire ram0_reg_10;
  wire ram0_reg_11;
  wire ram0_reg_12;
  wire ram0_reg_13;
  wire ram0_reg_14;
  wire ram0_reg_15;
  wire ram0_reg_16;
  wire ram0_reg_17;
  wire ram0_reg_18;
  wire ram0_reg_19;
  wire ram0_reg_2;
  wire ram0_reg_20;
  wire ram0_reg_21;
  wire ram0_reg_22;
  wire [7:0]ram0_reg_23;
  wire ram0_reg_24;
  wire ram0_reg_25;
  wire ram0_reg_26;
  wire ram0_reg_27;
  wire ram0_reg_28;
  wire ram0_reg_29;
  wire [5:0]ram0_reg_3;
  wire ram0_reg_30;
  wire ram0_reg_31;
  wire ram0_reg_32;
  wire ram0_reg_4;
  wire [39:0]ram0_reg_5;
  wire ram0_reg_6;
  wire ram0_reg_7;
  wire ram0_reg_8;
  wire ram0_reg_9;
  wire [2:0]ram0_reg_i_108;
  wire [5:0]ram0_reg_i_108_0;
  wire ram0_reg_i_131;
  wire [10:0]ram0_reg_i_23__0;
  wire [6:0]ram0_reg_i_23__0_0;
  wire [4:0]ram0_reg_i_23__0_1;
  wire ram0_reg_i_32;
  wire ram0_reg_i_32_0;
  wire ram0_reg_i_49;
  wire ram0_reg_i_53;
  wire ram0_reg_i_54;
  wire ram0_reg_i_54_0;
  wire ram0_reg_i_54_1;
  wire ram0_reg_i_54_2;
  wire ram0_reg_i_62;
  wire ram0_reg_i_62_0;
  wire ram0_reg_i_63;
  wire ram0_reg_i_63_0;
  wire ram0_reg_i_63_1;
  wire ram0_reg_i_66;
  wire ram0_reg_i_66_0;
  wire ram0_reg_i_66_1;
  wire ram0_reg_i_66_2;
  wire ram_reg_i_373__0;
  wire esc_y_2_reg_2385_reg_3_172fc4c ;
  wire esc_y_2_reg_2385_reg_3__0_c63e66d ;
  wire [4:0]esc_y_2_reg_2385_reg_4_1138322 ;
  wire [4:0]esc_y_2_reg_2385_reg_4__0_25a3d14 ;
  wire y_reg_22970;
  wire esc_y_reg_2297_reg_0_8039ace ;
  wire [13:0]zext_ln208_87_fu_5779_p1;
  wire [1:0]zext_ln74_2_fu_2977_p1;

  system_blue_locator_packed_0_0_blue_locator_packed_blue_counts_ram blue_locator_packed_blue_counts_ram_U
       (.CO(CO),
        .D(D),
        .DOADO(DOADO),
        .Q(Q),
        .WEA(WEA),
        .esc_add_ln208_102_reg_8173_reg_12_c8013a3 (esc_add_ln208_102_reg_8173_reg_12_c8013a3 ),
        .esc_add_ln208_102_reg_8173_reg_12__0_a64db1c (esc_add_ln208_102_reg_8173_reg_12__0_a64db1c ),
        .esc_add_ln208_105_reg_8205_reg_12_4c8e965 (esc_add_ln208_105_reg_8205_reg_12_4c8e965 ),
        .esc_add_ln208_105_reg_8205_reg_12__0_1875a9f (esc_add_ln208_105_reg_8205_reg_12__0_1875a9f ),
        .esc_add_ln208_108_reg_8237_reg_12_b4010f2 (esc_add_ln208_108_reg_8237_reg_12_b4010f2 ),
        .esc_add_ln208_108_reg_8237_reg_12__0_9171fbf (esc_add_ln208_108_reg_8237_reg_12__0_9171fbf ),
        .esc_add_ln208_111_reg_8269_reg_12_37e6aa3 (esc_add_ln208_111_reg_8269_reg_12_37e6aa3 ),
        .esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 (esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 ),
        .esc_add_ln208_114_reg_8301_reg_12_915e9df (esc_add_ln208_114_reg_8301_reg_12_915e9df ),
        .esc_add_ln208_114_reg_8301_reg_12__0_432a19c (esc_add_ln208_114_reg_8301_reg_12__0_432a19c ),
        .esc_add_ln208_117_reg_8333_reg_12_7252cfb (esc_add_ln208_117_reg_8333_reg_12_7252cfb ),
        .esc_add_ln208_117_reg_8333_reg_12__0_934ade3 (esc_add_ln208_117_reg_8333_reg_12__0_934ade3 ),
        .esc_add_ln208_120_reg_8365_reg_12_09d1f79 (esc_add_ln208_120_reg_8365_reg_12_09d1f79 ),
        .esc_add_ln208_120_reg_8365_reg_12__0_26aac56 (esc_add_ln208_120_reg_8365_reg_12__0_26aac56 ),
        .esc_add_ln208_123_reg_8397_reg_12_99743e4 (esc_add_ln208_123_reg_8397_reg_12_99743e4 ),
        .esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 (esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 ),
        .esc_add_ln208_126_reg_8429_reg_12_387655d (esc_add_ln208_126_reg_8429_reg_12_387655d ),
        .esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 (esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 ),
        .esc_add_ln208_129_reg_8461_reg_12_33d91dc (esc_add_ln208_129_reg_8461_reg_12_33d91dc ),
        .esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a (esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a ),
        .esc_add_ln208_132_reg_8493_reg_12_7e23985 (esc_add_ln208_132_reg_8493_reg_12_7e23985 ),
        .esc_add_ln208_132_reg_8493_reg_12__0_1f22523 (esc_add_ln208_132_reg_8493_reg_12__0_1f22523 ),
        .esc_add_ln208_135_reg_8525_reg_13_7810c12 (esc_add_ln208_135_reg_8525_reg_13_7810c12 ),
        .esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 (esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 ),
        .esc_add_ln208_138_reg_8557_reg_13_7e0af06 (esc_add_ln208_138_reg_8557_reg_13_7e0af06 ),
        .esc_add_ln208_138_reg_8557_reg_13__0_862abfd (esc_add_ln208_138_reg_8557_reg_13__0_862abfd ),
        .esc_add_ln208_141_reg_8589_reg_13_eb89c6f (esc_add_ln208_141_reg_8589_reg_13_eb89c6f ),
        .esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 (esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 ),
        .esc_add_ln208_144_reg_8621_reg_13_47c2a26 (esc_add_ln208_144_reg_8621_reg_13_47c2a26 ),
        .esc_add_ln208_144_reg_8621_reg_13__0_aba970f (esc_add_ln208_144_reg_8621_reg_13__0_aba970f ),
        .esc_add_ln208_147_reg_8653_reg_13_2be1b94 (esc_add_ln208_147_reg_8653_reg_13_2be1b94 ),
        .esc_add_ln208_147_reg_8653_reg_13__0_c9f027d (esc_add_ln208_147_reg_8653_reg_13__0_c9f027d ),
        .esc_add_ln208_150_reg_8685_reg_13_ba3a6fb (esc_add_ln208_150_reg_8685_reg_13_ba3a6fb ),
        .esc_add_ln208_150_reg_8685_reg_13__0_8447d92 (esc_add_ln208_150_reg_8685_reg_13__0_8447d92 ),
        .esc_add_ln208_153_reg_8717_reg_13_6aad7d7 (esc_add_ln208_153_reg_8717_reg_13_6aad7d7 ),
        .esc_add_ln208_157_reg_8733_reg_15_b87abdb (esc_add_ln208_157_reg_8733_reg_15_b87abdb ),
        .esc_add_ln208_42_reg_7073_reg_8_b2dae6f (esc_add_ln208_42_reg_7073_reg_8_b2dae6f ),
        .esc_add_ln208_45_reg_7125_reg_9_8959fd9 (esc_add_ln208_45_reg_7125_reg_9_8959fd9 ),
        .esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 (esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 ),
        .esc_add_ln208_48_reg_7177_reg_9_c78b76f (esc_add_ln208_48_reg_7177_reg_9_c78b76f ),
        .esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 (esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 ),
        .esc_add_ln208_51_reg_7229_reg_10_08c463a (esc_add_ln208_51_reg_7229_reg_10_08c463a ),
        .esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b (esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b ),
        .esc_add_ln208_54_reg_7281_reg_10_5a808fe (esc_add_ln208_54_reg_7281_reg_10_5a808fe ),
        .esc_add_ln208_54_reg_7281_reg_10__0_56b943a (esc_add_ln208_54_reg_7281_reg_10__0_56b943a ),
        .esc_add_ln208_57_reg_7333_reg_10_4817937 (esc_add_ln208_57_reg_7333_reg_10_4817937 ),
        .esc_add_ln208_57_reg_7333_reg_10__0_06e9277 (esc_add_ln208_57_reg_7333_reg_10__0_06e9277 ),
        .esc_add_ln208_60_reg_7385_reg_10_d918a34 (esc_add_ln208_60_reg_7385_reg_10_d918a34 ),
        .esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 (esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 ),
        .esc_add_ln208_63_reg_7437_reg_11_9252a9b (esc_add_ln208_63_reg_7437_reg_11_9252a9b ),
        .esc_add_ln208_63_reg_7437_reg_11__0_5853d45 (esc_add_ln208_63_reg_7437_reg_11__0_5853d45 ),
        .esc_add_ln208_66_reg_7489_reg_11_f470215 (esc_add_ln208_66_reg_7489_reg_11_f470215 ),
        .esc_add_ln208_66_reg_7489_reg_11__0_33e5672 (esc_add_ln208_66_reg_7489_reg_11__0_33e5672 ),
        .esc_add_ln208_69_reg_7541_reg_11_1ab4dac (esc_add_ln208_69_reg_7541_reg_11_1ab4dac ),
        .esc_add_ln208_69_reg_7541_reg_11__0_0318481 (esc_add_ln208_69_reg_7541_reg_11__0_0318481 ),
        .esc_add_ln208_72_reg_7593_reg_11_6fb0a9c (esc_add_ln208_72_reg_7593_reg_11_6fb0a9c ),
        .esc_add_ln208_72_reg_7593_reg_11__0_87f0eda (esc_add_ln208_72_reg_7593_reg_11__0_87f0eda ),
        .esc_add_ln208_75_reg_7655_reg_11_3cc2dbe (esc_add_ln208_75_reg_7655_reg_11_3cc2dbe ),
        .esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 (esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 ),
        .esc_add_ln208_78_reg_7717_reg_11_a25b5c3 (esc_add_ln208_78_reg_7717_reg_11_a25b5c3 ),
        .esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 (esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 ),
        .esc_add_ln208_81_reg_7779_reg_11_758e45d (esc_add_ln208_81_reg_7779_reg_11_758e45d ),
        .esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab (esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab ),
        .esc_add_ln208_84_reg_7841_reg_11_3a19824 (esc_add_ln208_84_reg_7841_reg_11_3a19824 ),
        .esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 (esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 ),
        .esc_add_ln208_87_reg_7903_reg_11_09bd1ec (esc_add_ln208_87_reg_7903_reg_11_09bd1ec ),
        .esc_add_ln208_87_reg_7903_reg_12_ebbbe3f (esc_add_ln208_87_reg_7903_reg_12_ebbbe3f ),
        .esc_add_ln208_90_reg_7965_reg_12_6090767 (esc_add_ln208_90_reg_7965_reg_12_6090767 ),
        .esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f (esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f ),
        .esc_add_ln208_93_reg_8027_reg_12_0c8544f (esc_add_ln208_93_reg_8027_reg_12_0c8544f ),
        .esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 (esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 ),
        .esc_add_ln208_96_reg_8089_reg_12_26fe0a4 (esc_add_ln208_96_reg_8089_reg_12_26fe0a4 ),
        .esc_add_ln208_96_reg_8089_reg_12__0_4851c79 (esc_add_ln208_96_reg_8089_reg_12__0_4851c79 ),
        .esc_add_ln208_99_reg_8131_reg_12_287a134 (esc_add_ln208_99_reg_8131_reg_12_287a134 ),
        .esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e (esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e ),
        .esc_add_ln68_reg_8723_reg_1_d6e0e48 (esc_add_ln68_reg_8723_reg_4_ae92a68 [0]),
        .esc_add_ln68_reg_8723_reg_2_180a5a5 (esc_add_ln68_reg_8723_reg_2_180a5a5 ),
        .esc_add_ln68_reg_8723_reg_2__0_0488464 (esc_add_ln68_reg_8723_reg_4_ae92a68 [1]),
        .esc_add_ln68_reg_8723_reg_3_d7954e8 (esc_add_ln68_reg_8723_reg_4_ae92a68 [2]),
        .esc_add_ln68_reg_8723_reg_4_ae92a68 (esc_add_ln68_reg_8723_reg_4_ae92a68 [3]),
        .esc_add_ln74_reg_6855_reg_10_52d2cb4 (esc_add_ln74_reg_6855_reg_10_52d2cb4 ),
        .esc_add_ln74_reg_6855_reg_10__0_d3d73fa (esc_add_ln74_reg_6855_reg_10__0_d3d73fa ),
        .esc_add_ln74_reg_6855_reg_5_2a13e9b (esc_add_ln74_reg_6855_reg_5_2a13e9b ),
        .esc_add_ln74_reg_6855_reg_5__0_2b6f97c (esc_add_ln74_reg_6855_reg_5__0_2b6f97c ),
        .esc_add_ln74_reg_6855_reg_6_25e4b8d (esc_add_ln74_reg_6855_reg_6_25e4b8d ),
        .esc_add_ln74_reg_6855_reg_6__0_8e7e51f (esc_add_ln74_reg_6855_reg_6__0_8e7e51f ),
        .esc_add_ln74_reg_6855_reg_6__1_a3a11c9 (esc_add_ln74_reg_6855_reg_6__1_a3a11c9 ),
        .esc_add_ln74_reg_6855_reg_6__2_76dcc1d (esc_add_ln74_reg_6855_reg_6__2_76dcc1d ),
        .esc_add_ln74_reg_6855_reg_7_6b2f341 (esc_add_ln74_reg_6855_reg_7_6b2f341 ),
        .esc_add_ln74_reg_6855_reg_7__0_abb43a8 (esc_add_ln74_reg_6855_reg_7__0_abb43a8 ),
        .esc_add_ln74_reg_6855_reg_7__1_e9ac382 (esc_add_ln74_reg_6855_reg_7__1_e9ac382 ),
        .esc_add_ln74_reg_6855_reg_7__2_c3111d6 (esc_add_ln74_reg_6855_reg_7__2_c3111d6 ),
        .esc_add_ln74_reg_6855_reg_8_0e33662 (esc_add_ln74_reg_6855_reg_8_0e33662 ),
        .esc_add_ln74_reg_6855_reg_8__0_dab2ff8 (esc_add_ln74_reg_6855_reg_8__0_dab2ff8 ),
        .esc_add_ln74_reg_6855_reg_8__1_c9f6290 (esc_add_ln74_reg_6855_reg_8__1_c9f6290 ),
        .esc_add_ln74_reg_6855_reg_9_9c8c6ed (esc_add_ln74_reg_6855_reg_9_9c8c6ed ),
        .esc_add_ln74_reg_6855_reg_9__0_2980795 (esc_add_ln74_reg_6855_reg_9__0_2980795 ),
        .esc_add_ln74_reg_6855_reg_9__1_9d031f6 (esc_add_ln74_reg_6855_reg_9__1_9d031f6 ),
        .esc_ap_CS_fsm_reg_16_2d815ec (esc_ap_CS_fsm_reg_16_2d815ec ),
        .esc_ap_CS_fsm_reg_17_dedac0c (esc_ap_CS_fsm_reg_17_dedac0c ),
        .esc_ap_CS_fsm_reg_17__0_3991a9e (esc_ap_CS_fsm_reg_17__0_3991a9e ),
        .esc_ap_CS_fsm_reg_19_bd70f8c (esc_ap_CS_fsm_reg_19_bd70f8c ),
        .esc_ap_CS_fsm_reg_1_637b98d (esc_ap_CS_fsm_reg_1_637b98d ),
        .esc_ap_CS_fsm_reg_21_af57a65 (esc_ap_CS_fsm_reg_21_af57a65 ),
        .esc_ap_CS_fsm_reg_23_edf6f2f (esc_ap_CS_fsm_reg_23_edf6f2f ),
        .esc_ap_CS_fsm_reg_26_bc9d1aa (esc_ap_CS_fsm_reg_26_bc9d1aa ),
        .esc_ap_CS_fsm_reg_29_d9f5eab (esc_ap_CS_fsm_reg_29_d9f5eab ),
        .esc_ap_CS_fsm_reg_33_3728c13 (esc_ap_CS_fsm_reg_33_3728c13 ),
        .esc_ap_CS_fsm_reg_35_69cfbc2 (esc_ap_CS_fsm_reg_35_69cfbc2 ),
        .esc_ap_CS_fsm_reg_35__0_74dd3b9 (esc_ap_CS_fsm_reg_35__0_74dd3b9 ),
        .esc_ap_CS_fsm_reg_35__1_673f736 (esc_ap_CS_fsm_reg_35__1_673f736 ),
        .esc_ap_CS_fsm_reg_46_ba5f378 (esc_ap_CS_fsm_reg_46_ba5f378 ),
        .esc_ap_CS_fsm_reg_48_486bf78 (esc_ap_CS_fsm_reg_48_486bf78 ),
        .esc_ap_CS_fsm_reg_48__0_0aa522c (esc_ap_CS_fsm_reg_48__0_0aa522c ),
        .esc_ap_CS_fsm_reg_54_3d44ae7 (esc_ap_CS_fsm_reg_54_3d44ae7 ),
        .ap_clk(ap_clk),
        .ap_enable_reg_pp0_iter1(ap_enable_reg_pp0_iter1),
        .ap_enable_reg_pp1_iter0(ap_enable_reg_pp1_iter0),
        .ap_enable_reg_pp1_iter0_reg(ap_enable_reg_pp1_iter0_reg),
        .ap_enable_reg_pp1_iter1_reg(ap_enable_reg_pp1_iter1_reg),
        .ap_enable_reg_pp3_iter0(ap_enable_reg_pp3_iter0),
        .ap_enable_reg_pp3_iter0_reg(ap_enable_reg_pp3_iter0_reg),
        .ap_enable_reg_pp3_iter0_reg_0(ap_enable_reg_pp3_iter0_reg_0),
        .ap_enable_reg_pp3_iter0_reg_rep(ap_enable_reg_pp3_iter0_reg_rep),
        .ap_enable_reg_pp3_iter0_reg_rep_0(ap_enable_reg_pp3_iter0_reg_rep_0),
        .ap_enable_reg_pp3_iter0_reg_rep__2(ap_enable_reg_pp3_iter0_reg_rep__2),
        .ap_enable_reg_pp3_iter0_reg_rep__2_0(ap_enable_reg_pp3_iter0_reg_rep__2_0),
        .ap_enable_reg_pp3_iter0_reg_rep__2_1(ap_enable_reg_pp3_iter0_reg_rep__2_1),
        .ap_phi_mux_y_2_phi_fu_2389_p4(ap_phi_mux_y_2_phi_fu_2389_p4),
        .data42(data42),
        .esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc (esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc ),
        .edge_counts_ce0(edge_counts_ce0),
        .mul_ln215_reg_6908(mul_ln215_reg_6908),
        .esc_mul_ln215_reg_6908_reg_0_b3fe01c (esc_mul_ln215_reg_6908_reg_0_b3fe01c ),
        .esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd (esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ),
        .esc_mul_ln215_reg_6908_reg_1_09f3be8 (esc_mul_ln215_reg_6908_reg_1_09f3be8 ),
        .esc_mul_ln215_reg_6908_reg_1__0_292d7d8 (esc_mul_ln215_reg_6908_reg_1__0_292d7d8 ),
        .esc_mul_ln215_reg_6908_reg_1__1_b396821 (esc_mul_ln215_reg_6908_reg_1__1_b396821 ),
        .ram0_reg_0(ram0_reg),
        .ram0_reg_1(ram0_reg_0),
        .ram0_reg_10(ram0_reg_9),
        .ram0_reg_11(ram0_reg_10),
        .ram0_reg_12(ram0_reg_11),
        .ram0_reg_13(ram0_reg_12),
        .ram0_reg_14(ram0_reg_13),
        .ram0_reg_15(ram0_reg_14),
        .ram0_reg_16(ram0_reg_15),
        .ram0_reg_17(ram0_reg_16),
        .ram0_reg_18(ram0_reg_17),
        .ram0_reg_19(ram0_reg_18),
        .ram0_reg_2(ram0_reg_1),
        .ram0_reg_20(ram0_reg_19),
        .ram0_reg_21(ram0_reg_20),
        .ram0_reg_22(ram0_reg_21),
        .ram0_reg_23(ram0_reg_22),
        .ram0_reg_24(ram0_reg_23),
        .ram0_reg_25(ram0_reg_24),
        .ram0_reg_26(ram0_reg_25),
        .ram0_reg_27(ram0_reg_26),
        .ram0_reg_28(ram0_reg_27),
        .ram0_reg_29(ram0_reg_28),
        .ram0_reg_3(ram0_reg_2),
        .ram0_reg_30(ram0_reg_29),
        .ram0_reg_31(ram0_reg_30),
        .ram0_reg_32(ram0_reg_31),
        .ram0_reg_33(ram0_reg_32),
        .ram0_reg_4(ram0_reg_3),
        .ram0_reg_5(ram0_reg_4),
        .ram0_reg_6(ram0_reg_5),
        .ram0_reg_7(ram0_reg_6),
        .ram0_reg_8(ram0_reg_7),
        .ram0_reg_9(ram0_reg_8),
        .ram0_reg_i_108_0(ram0_reg_i_108),
        .ram0_reg_i_108_1(ram0_reg_i_108_0),
        .ram0_reg_i_131_0(ram0_reg_i_131),
        .ram0_reg_i_23__0_0(ram0_reg_i_23__0),
        .ram0_reg_i_23__0_1(ram0_reg_i_23__0_0),
        .ram0_reg_i_23__0_2(ram0_reg_i_23__0_1),
        .ram0_reg_i_32(ram0_reg_i_32),
        .ram0_reg_i_32_0(ram0_reg_i_32_0),
        .ram0_reg_i_49_0(ram0_reg_i_49),
        .ram0_reg_i_53(ram0_reg_i_53),
        .ram0_reg_i_54(ram0_reg_i_54),
        .ram0_reg_i_54_0(ram0_reg_i_54_0),
        .ram0_reg_i_54_1(ram0_reg_i_54_1),
        .ram0_reg_i_54_2(ram0_reg_i_54_2),
        .ram0_reg_i_62_0(ram0_reg_i_62),
        .ram0_reg_i_62_1(ram0_reg_i_62_0),
        .ram0_reg_i_63_0(ram0_reg_i_63),
        .ram0_reg_i_63_1(ram0_reg_i_63_0),
        .ram0_reg_i_63_2(ram0_reg_i_63_1),
        .ram0_reg_i_66_0(ram0_reg_i_66),
        .ram0_reg_i_66_1(ram0_reg_i_66_0),
        .ram0_reg_i_66_2(ram0_reg_i_66_1),
        .ram0_reg_i_66_3(ram0_reg_i_66_2),
        .ram_reg_i_373__0(ram_reg_i_373__0),
        .esc_y_2_reg_2385_reg_3_172fc4c (esc_y_2_reg_2385_reg_3_172fc4c ),
        .esc_y_2_reg_2385_reg_3__0_c63e66d (esc_y_2_reg_2385_reg_3__0_c63e66d ),
        .esc_y_2_reg_2385_reg_4_1138322 (esc_y_2_reg_2385_reg_4_1138322 ),
        .esc_y_2_reg_2385_reg_4__0_25a3d14 (esc_y_2_reg_2385_reg_4__0_25a3d14 ),
        .y_reg_22970(y_reg_22970),
        .esc_y_reg_2297_reg_0_8039ace (esc_y_reg_2297_reg_0_8039ace ),
        .zext_ln208_87_fu_5779_p1(zext_ln208_87_fu_5779_p1),
        .zext_ln74_2_fu_2977_p1(zext_ln74_2_fu_2977_p1));
endmodule

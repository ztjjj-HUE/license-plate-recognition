// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_blue_counts_ram
   (DOADO,
    D,
    CO,
    data42,
    ram0_reg_0,
    esc_add_ln208_42_reg_7073_reg_8_b2dae6f ,
    esc_add_ln208_45_reg_7125_reg_9_8959fd9 ,
    esc_add_ln208_48_reg_7177_reg_9_c78b76f ,
    esc_add_ln208_51_reg_7229_reg_10_08c463a ,
    esc_add_ln208_54_reg_7281_reg_10_5a808fe ,
    esc_add_ln208_57_reg_7333_reg_10_4817937 ,
    esc_add_ln208_60_reg_7385_reg_10_d918a34 ,
    esc_add_ln208_63_reg_7437_reg_11_9252a9b ,
    esc_add_ln208_66_reg_7489_reg_11_f470215 ,
    esc_add_ln208_69_reg_7541_reg_11_1ab4dac ,
    esc_add_ln208_72_reg_7593_reg_11_6fb0a9c ,
    esc_add_ln208_75_reg_7655_reg_11_3cc2dbe ,
    esc_add_ln208_78_reg_7717_reg_11_a25b5c3 ,
    esc_add_ln208_81_reg_7779_reg_11_758e45d ,
    esc_add_ln208_84_reg_7841_reg_11_3a19824 ,
    esc_add_ln208_87_reg_7903_reg_12_ebbbe3f ,
    esc_add_ln208_90_reg_7965_reg_12_6090767 ,
    esc_add_ln208_93_reg_8027_reg_12_0c8544f ,
    esc_add_ln208_96_reg_8089_reg_12_26fe0a4 ,
    esc_add_ln208_99_reg_8131_reg_12_287a134 ,
    esc_add_ln208_102_reg_8173_reg_12_c8013a3 ,
    esc_add_ln208_105_reg_8205_reg_12_4c8e965 ,
    esc_add_ln208_108_reg_8237_reg_12_b4010f2 ,
    esc_add_ln208_111_reg_8269_reg_12_37e6aa3 ,
    esc_add_ln208_114_reg_8301_reg_12_915e9df ,
    esc_add_ln208_117_reg_8333_reg_12_7252cfb ,
    esc_add_ln208_120_reg_8365_reg_12_09d1f79 ,
    esc_add_ln208_123_reg_8397_reg_12_99743e4 ,
    esc_add_ln208_126_reg_8429_reg_12_387655d ,
    esc_add_ln208_129_reg_8461_reg_12_33d91dc ,
    esc_add_ln208_132_reg_8493_reg_12_7e23985 ,
    esc_add_ln208_135_reg_8525_reg_13_7810c12 ,
    esc_add_ln208_138_reg_8557_reg_13_7e0af06 ,
    esc_add_ln208_141_reg_8589_reg_13_eb89c6f ,
    esc_add_ln208_144_reg_8621_reg_13_47c2a26 ,
    esc_add_ln208_147_reg_8653_reg_13_2be1b94 ,
    esc_add_ln208_150_reg_8685_reg_13_ba3a6fb ,
    zext_ln208_87_fu_5779_p1,
    ap_enable_reg_pp3_iter0_reg_rep,
    ap_enable_reg_pp3_iter0_reg_rep__2,
    esc_ap_CS_fsm_reg_17_dedac0c ,
    ap_enable_reg_pp1_iter0_reg,
    ap_enable_reg_pp1_iter1_reg,
    esc_add_ln74_reg_6855_reg_5_2a13e9b ,
    esc_mul_ln215_reg_6908_reg_0_b3fe01c ,
    esc_add_ln74_reg_6855_reg_5__0_2b6f97c ,
    esc_ap_CS_fsm_reg_17__0_3991a9e ,
    esc_ap_CS_fsm_reg_19_bd70f8c ,
    esc_add_ln74_reg_6855_reg_7_6b2f341 ,
    esc_add_ln74_reg_6855_reg_7__0_abb43a8 ,
    esc_add_ln74_reg_6855_reg_7__1_e9ac382 ,
    esc_add_ln68_reg_8723_reg_2_180a5a5 ,
    esc_add_ln74_reg_6855_reg_8_0e33662 ,
    esc_add_ln74_reg_6855_reg_8__0_dab2ff8 ,
    esc_add_ln74_reg_6855_reg_8__1_c9f6290 ,
    esc_add_ln74_reg_6855_reg_9_9c8c6ed ,
    esc_add_ln74_reg_6855_reg_9__0_2980795 ,
    esc_add_ln74_reg_6855_reg_9__1_9d031f6 ,
    esc_add_ln74_reg_6855_reg_10_52d2cb4 ,
    esc_mul_ln215_reg_6908_reg_1_09f3be8 ,
    esc_add_ln74_reg_6855_reg_10__0_d3d73fa ,
    esc_add_ln68_reg_8723_reg_2__0_0488464 ,
    esc_add_ln68_reg_8723_reg_1_d6e0e48 ,
    esc_add_ln68_reg_8723_reg_3_d7954e8 ,
    esc_add_ln68_reg_8723_reg_4_ae92a68 ,
    esc_add_ln74_reg_6855_reg_6_25e4b8d ,
    esc_add_ln74_reg_6855_reg_6__0_8e7e51f ,
    esc_add_ln74_reg_6855_reg_6__1_a3a11c9 ,
    esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ,
    esc_mul_ln215_reg_6908_reg_1__0_292d7d8 ,
    esc_mul_ln215_reg_6908_reg_1__1_b396821 ,
    ap_enable_reg_pp3_iter0_reg,
    esc_ap_CS_fsm_reg_21_af57a65 ,
    ap_enable_reg_pp3_iter0_reg_0,
    esc_ap_CS_fsm_reg_48_486bf78 ,
    ap_enable_reg_pp3_iter0_reg_rep_0,
    esc_ap_CS_fsm_reg_16_2d815ec ,
    esc_ap_CS_fsm_reg_54_3d44ae7 ,
    esc_ap_CS_fsm_reg_48__0_0aa522c ,
    ap_enable_reg_pp3_iter0_reg_rep__2_0,
    ap_enable_reg_pp3_iter0_reg_rep__2_1,
    esc_ap_CS_fsm_reg_35_69cfbc2 ,
    esc_ap_CS_fsm_reg_1_637b98d ,
    esc_ap_CS_fsm_reg_46_ba5f378 ,
    esc_ap_CS_fsm_reg_29_d9f5eab ,
    esc_ap_CS_fsm_reg_35__0_74dd3b9 ,
    esc_ap_CS_fsm_reg_33_3728c13 ,
    esc_ap_CS_fsm_reg_35__1_673f736 ,
    esc_ap_CS_fsm_reg_23_edf6f2f ,
    esc_ap_CS_fsm_reg_26_bc9d1aa ,
    y_reg_22970,
    ap_clk,
    edge_counts_ce0,
    WEA,
    Q,
    esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc ,
    ram0_reg_i_108_0,
    ram0_reg_i_108_1,
    esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 ,
    esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 ,
    esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b ,
    esc_add_ln208_54_reg_7281_reg_10__0_56b943a ,
    esc_add_ln208_57_reg_7333_reg_10__0_06e9277 ,
    esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 ,
    esc_add_ln208_63_reg_7437_reg_11__0_5853d45 ,
    esc_add_ln208_66_reg_7489_reg_11__0_33e5672 ,
    esc_add_ln208_69_reg_7541_reg_11__0_0318481 ,
    esc_add_ln208_72_reg_7593_reg_11__0_87f0eda ,
    esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 ,
    esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 ,
    esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab ,
    esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 ,
    esc_add_ln208_87_reg_7903_reg_11_09bd1ec ,
    esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f ,
    esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 ,
    esc_add_ln208_96_reg_8089_reg_12__0_4851c79 ,
    esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e ,
    esc_add_ln208_102_reg_8173_reg_12__0_a64db1c ,
    esc_add_ln208_105_reg_8205_reg_12__0_1875a9f ,
    esc_add_ln208_108_reg_8237_reg_12__0_9171fbf ,
    esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 ,
    esc_add_ln208_114_reg_8301_reg_12__0_432a19c ,
    esc_add_ln208_117_reg_8333_reg_12__0_934ade3 ,
    esc_add_ln208_120_reg_8365_reg_12__0_26aac56 ,
    esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 ,
    esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 ,
    esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a ,
    esc_add_ln208_132_reg_8493_reg_12__0_1f22523 ,
    esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 ,
    esc_add_ln208_138_reg_8557_reg_13__0_862abfd ,
    esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 ,
    esc_add_ln208_144_reg_8621_reg_13__0_aba970f ,
    esc_add_ln208_147_reg_8653_reg_13__0_c9f027d ,
    esc_add_ln208_150_reg_8685_reg_13__0_8447d92 ,
    esc_add_ln208_153_reg_8717_reg_13_6aad7d7 ,
    esc_add_ln208_157_reg_8733_reg_15_b87abdb ,
    ram0_reg_1,
    ram0_reg_2,
    ram0_reg_3,
    ram0_reg_i_23__0_0,
    ap_phi_mux_y_2_phi_fu_2389_p4,
    zext_ln74_2_fu_2977_p1,
    ram0_reg_4,
    ram0_reg_5,
    ram0_reg_i_32,
    ram0_reg_i_32_0,
    mul_ln215_reg_6908,
    esc_y_2_reg_2385_reg_4_1138322 ,
    esc_y_2_reg_2385_reg_4__0_25a3d14 ,
    esc_y_2_reg_2385_reg_3_172fc4c ,
    ram0_reg_i_49_0,
    ram0_reg_6,
    esc_y_2_reg_2385_reg_3__0_c63e66d ,
    ram0_reg_7,
    ram0_reg_8,
    ap_enable_reg_pp3_iter0,
    ram0_reg_9,
    ram0_reg_10,
    ram0_reg_11,
    ram0_reg_i_62_0,
    ram0_reg_12,
    ram0_reg_13,
    ram0_reg_i_62_1,
    ram0_reg_14,
    ram0_reg_15,
    ram0_reg_16,
    ram0_reg_17,
    ram0_reg_18,
    ram0_reg_i_54,
    ram0_reg_i_54_0,
    ram0_reg_i_54_1,
    ram0_reg_i_54_2,
    ram0_reg_19,
    ram0_reg_20,
    ap_enable_reg_pp0_iter1,
    ram0_reg_21,
    ram0_reg_i_66_0,
    ram0_reg_i_66_1,
    ram0_reg_i_66_2,
    ram0_reg_i_66_3,
    ram0_reg_22,
    ram0_reg_i_23__0_1,
    ram0_reg_i_23__0_2,
    ram0_reg_23,
    ram0_reg_24,
    ap_enable_reg_pp1_iter0,
    ram0_reg_25,
    ram0_reg_26,
    ram0_reg_27,
    ram0_reg_28,
    ram0_reg_29,
    ram0_reg_30,
    ram0_reg_31,
    ram0_reg_32,
    ram0_reg_i_63_0,
    ram0_reg_i_63_1,
    ram0_reg_i_63_2,
    ram0_reg_i_131_0,
    esc_y_reg_2297_reg_0_8039ace ,
    ram_reg_i_373__0,
    esc_add_ln74_reg_6855_reg_7__2_c3111d6 ,
    esc_add_ln74_reg_6855_reg_6__2_76dcc1d ,
    ram0_reg_33,
    ram0_reg_i_53);
  output [7:0]DOADO;
  output [0:0]D;
  output [0:0]CO;
  output [3:0]data42;
  output [8:0]ram0_reg_0;
  output [9:0]esc_add_ln208_42_reg_7073_reg_8_b2dae6f ;
  output [9:0]esc_add_ln208_45_reg_7125_reg_9_8959fd9 ;
  output [10:0]esc_add_ln208_48_reg_7177_reg_9_c78b76f ;
  output [10:0]esc_add_ln208_51_reg_7229_reg_10_08c463a ;
  output [10:0]esc_add_ln208_54_reg_7281_reg_10_5a808fe ;
  output [10:0]esc_add_ln208_57_reg_7333_reg_10_4817937 ;
  output [11:0]esc_add_ln208_60_reg_7385_reg_10_d918a34 ;
  output [11:0]esc_add_ln208_63_reg_7437_reg_11_9252a9b ;
  output [11:0]esc_add_ln208_66_reg_7489_reg_11_f470215 ;
  output [11:0]esc_add_ln208_69_reg_7541_reg_11_1ab4dac ;
  output [11:0]esc_add_ln208_72_reg_7593_reg_11_6fb0a9c ;
  output [11:0]esc_add_ln208_75_reg_7655_reg_11_3cc2dbe ;
  output [11:0]esc_add_ln208_78_reg_7717_reg_11_a25b5c3 ;
  output [11:0]esc_add_ln208_81_reg_7779_reg_11_758e45d ;
  output [12:0]esc_add_ln208_84_reg_7841_reg_11_3a19824 ;
  output [12:0]esc_add_ln208_87_reg_7903_reg_12_ebbbe3f ;
  output [12:0]esc_add_ln208_90_reg_7965_reg_12_6090767 ;
  output [12:0]esc_add_ln208_93_reg_8027_reg_12_0c8544f ;
  output [12:0]esc_add_ln208_96_reg_8089_reg_12_26fe0a4 ;
  output [12:0]esc_add_ln208_99_reg_8131_reg_12_287a134 ;
  output [12:0]esc_add_ln208_102_reg_8173_reg_12_c8013a3 ;
  output [12:0]esc_add_ln208_105_reg_8205_reg_12_4c8e965 ;
  output [12:0]esc_add_ln208_108_reg_8237_reg_12_b4010f2 ;
  output [12:0]esc_add_ln208_111_reg_8269_reg_12_37e6aa3 ;
  output [12:0]esc_add_ln208_114_reg_8301_reg_12_915e9df ;
  output [12:0]esc_add_ln208_117_reg_8333_reg_12_7252cfb ;
  output [12:0]esc_add_ln208_120_reg_8365_reg_12_09d1f79 ;
  output [12:0]esc_add_ln208_123_reg_8397_reg_12_99743e4 ;
  output [12:0]esc_add_ln208_126_reg_8429_reg_12_387655d ;
  output [12:0]esc_add_ln208_129_reg_8461_reg_12_33d91dc ;
  output [13:0]esc_add_ln208_132_reg_8493_reg_12_7e23985 ;
  output [13:0]esc_add_ln208_135_reg_8525_reg_13_7810c12 ;
  output [13:0]esc_add_ln208_138_reg_8557_reg_13_7e0af06 ;
  output [13:0]esc_add_ln208_141_reg_8589_reg_13_eb89c6f ;
  output [13:0]esc_add_ln208_144_reg_8621_reg_13_47c2a26 ;
  output [13:0]esc_add_ln208_147_reg_8653_reg_13_2be1b94 ;
  output [13:0]esc_add_ln208_150_reg_8685_reg_13_ba3a6fb ;
  output [13:0]zext_ln208_87_fu_5779_p1;
  output ap_enable_reg_pp3_iter0_reg_rep;
  output ap_enable_reg_pp3_iter0_reg_rep__2;
  output esc_ap_CS_fsm_reg_17_dedac0c ;
  output ap_enable_reg_pp1_iter0_reg;
  output ap_enable_reg_pp1_iter1_reg;
  output esc_add_ln74_reg_6855_reg_5_2a13e9b ;
  output esc_mul_ln215_reg_6908_reg_0_b3fe01c ;
  output esc_add_ln74_reg_6855_reg_5__0_2b6f97c ;
  output esc_ap_CS_fsm_reg_17__0_3991a9e ;
  output esc_ap_CS_fsm_reg_19_bd70f8c ;
  output esc_add_ln74_reg_6855_reg_7_6b2f341 ;
  output esc_add_ln74_reg_6855_reg_7__0_abb43a8 ;
  output esc_add_ln74_reg_6855_reg_7__1_e9ac382 ;
  output [3:0]esc_add_ln68_reg_8723_reg_2_180a5a5 ;
  output esc_add_ln74_reg_6855_reg_8_0e33662 ;
  output esc_add_ln74_reg_6855_reg_8__0_dab2ff8 ;
  output esc_add_ln74_reg_6855_reg_8__1_c9f6290 ;
  output esc_add_ln74_reg_6855_reg_9_9c8c6ed ;
  output esc_add_ln74_reg_6855_reg_9__0_2980795 ;
  output esc_add_ln74_reg_6855_reg_9__1_9d031f6 ;
  output esc_add_ln74_reg_6855_reg_10_52d2cb4 ;
  output esc_mul_ln215_reg_6908_reg_1_09f3be8 ;
  output esc_add_ln74_reg_6855_reg_10__0_d3d73fa ;
  output esc_add_ln68_reg_8723_reg_2__0_0488464 ;
  output esc_add_ln68_reg_8723_reg_1_d6e0e48 ;
  output esc_add_ln68_reg_8723_reg_3_d7954e8 ;
  output [0:0]esc_add_ln68_reg_8723_reg_4_ae92a68 ;
  output esc_add_ln74_reg_6855_reg_6_25e4b8d ;
  output esc_add_ln74_reg_6855_reg_6__0_8e7e51f ;
  output esc_add_ln74_reg_6855_reg_6__1_a3a11c9 ;
  output esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ;
  output esc_mul_ln215_reg_6908_reg_1__0_292d7d8 ;
  output esc_mul_ln215_reg_6908_reg_1__1_b396821 ;
  output ap_enable_reg_pp3_iter0_reg;
  output esc_ap_CS_fsm_reg_21_af57a65 ;
  output ap_enable_reg_pp3_iter0_reg_0;
  output esc_ap_CS_fsm_reg_48_486bf78 ;
  output ap_enable_reg_pp3_iter0_reg_rep_0;
  output esc_ap_CS_fsm_reg_16_2d815ec ;
  output esc_ap_CS_fsm_reg_54_3d44ae7 ;
  output esc_ap_CS_fsm_reg_48__0_0aa522c ;
  output ap_enable_reg_pp3_iter0_reg_rep__2_0;
  output ap_enable_reg_pp3_iter0_reg_rep__2_1;
  output esc_ap_CS_fsm_reg_35_69cfbc2 ;
  output esc_ap_CS_fsm_reg_1_637b98d ;
  output esc_ap_CS_fsm_reg_46_ba5f378 ;
  output esc_ap_CS_fsm_reg_29_d9f5eab ;
  output esc_ap_CS_fsm_reg_35__0_74dd3b9 ;
  output esc_ap_CS_fsm_reg_33_3728c13 ;
  output esc_ap_CS_fsm_reg_35__1_673f736 ;
  output esc_ap_CS_fsm_reg_23_edf6f2f ;
  output esc_ap_CS_fsm_reg_26_bc9d1aa ;
  output y_reg_22970;
  input ap_clk;
  input edge_counts_ce0;
  input [0:0]WEA;
  input [0:0]Q;
  input [3:0]esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc ;
  input [2:0]ram0_reg_i_108_0;
  input [5:0]ram0_reg_i_108_1;
  input [8:0]esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 ;
  input [9:0]esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 ;
  input [9:0]esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b ;
  input [10:0]esc_add_ln208_54_reg_7281_reg_10__0_56b943a ;
  input [10:0]esc_add_ln208_57_reg_7333_reg_10__0_06e9277 ;
  input [10:0]esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 ;
  input [10:0]esc_add_ln208_63_reg_7437_reg_11__0_5853d45 ;
  input [11:0]esc_add_ln208_66_reg_7489_reg_11__0_33e5672 ;
  input [11:0]esc_add_ln208_69_reg_7541_reg_11__0_0318481 ;
  input [11:0]esc_add_ln208_72_reg_7593_reg_11__0_87f0eda ;
  input [11:0]esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 ;
  input [11:0]esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 ;
  input [11:0]esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab ;
  input [11:0]esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 ;
  input [11:0]esc_add_ln208_87_reg_7903_reg_11_09bd1ec ;
  input [12:0]esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f ;
  input [12:0]esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 ;
  input [12:0]esc_add_ln208_96_reg_8089_reg_12__0_4851c79 ;
  input [12:0]esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e ;
  input [12:0]esc_add_ln208_102_reg_8173_reg_12__0_a64db1c ;
  input [12:0]esc_add_ln208_105_reg_8205_reg_12__0_1875a9f ;
  input [12:0]esc_add_ln208_108_reg_8237_reg_12__0_9171fbf ;
  input [12:0]esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 ;
  input [12:0]esc_add_ln208_114_reg_8301_reg_12__0_432a19c ;
  input [12:0]esc_add_ln208_117_reg_8333_reg_12__0_934ade3 ;
  input [12:0]esc_add_ln208_120_reg_8365_reg_12__0_26aac56 ;
  input [12:0]esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 ;
  input [12:0]esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 ;
  input [12:0]esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a ;
  input [12:0]esc_add_ln208_132_reg_8493_reg_12__0_1f22523 ;
  input [12:0]esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 ;
  input [13:0]esc_add_ln208_138_reg_8557_reg_13__0_862abfd ;
  input [13:0]esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 ;
  input [13:0]esc_add_ln208_144_reg_8621_reg_13__0_aba970f ;
  input [13:0]esc_add_ln208_147_reg_8653_reg_13__0_c9f027d ;
  input [13:0]esc_add_ln208_150_reg_8685_reg_13__0_8447d92 ;
  input [13:0]esc_add_ln208_153_reg_8717_reg_13_6aad7d7 ;
  input [13:0]esc_add_ln208_157_reg_8733_reg_15_b87abdb ;
  input ram0_reg_1;
  input ram0_reg_2;
  input ram0_reg_3;
  input [10:0]ram0_reg_i_23__0_0;
  input [0:0]ap_phi_mux_y_2_phi_fu_2389_p4;
  input [1:0]zext_ln74_2_fu_2977_p1;
  input [5:0]ram0_reg_4;
  input ram0_reg_5;
  input ram0_reg_i_32;
  input ram0_reg_i_32_0;
  input [1:0]mul_ln215_reg_6908;
  input [4:0]esc_y_2_reg_2385_reg_4_1138322 ;
  input [4:0]esc_y_2_reg_2385_reg_4__0_25a3d14 ;
  input esc_y_2_reg_2385_reg_3_172fc4c ;
  input ram0_reg_i_49_0;
  input [39:0]ram0_reg_6;
  input esc_y_2_reg_2385_reg_3__0_c63e66d ;
  input ram0_reg_7;
  input ram0_reg_8;
  input ap_enable_reg_pp3_iter0;
  input ram0_reg_9;
  input ram0_reg_10;
  input ram0_reg_11;
  input ram0_reg_i_62_0;
  input ram0_reg_12;
  input ram0_reg_13;
  input ram0_reg_i_62_1;
  input ram0_reg_14;
  input ram0_reg_15;
  input ram0_reg_16;
  input ram0_reg_17;
  input ram0_reg_18;
  input ram0_reg_i_54;
  input ram0_reg_i_54_0;
  input ram0_reg_i_54_1;
  input ram0_reg_i_54_2;
  input ram0_reg_19;
  input ram0_reg_20;
  input ap_enable_reg_pp0_iter1;
  input ram0_reg_21;
  input ram0_reg_i_66_0;
  input ram0_reg_i_66_1;
  input ram0_reg_i_66_2;
  input ram0_reg_i_66_3;
  input ram0_reg_22;
  input [6:0]ram0_reg_i_23__0_1;
  input [4:0]ram0_reg_i_23__0_2;
  input ram0_reg_23;
  input [7:0]ram0_reg_24;
  input ap_enable_reg_pp1_iter0;
  input ram0_reg_25;
  input ram0_reg_26;
  input ram0_reg_27;
  input ram0_reg_28;
  input ram0_reg_29;
  input ram0_reg_30;
  input ram0_reg_31;
  input ram0_reg_32;
  input ram0_reg_i_63_0;
  input ram0_reg_i_63_1;
  input ram0_reg_i_63_2;
  input ram0_reg_i_131_0;
  input esc_y_reg_2297_reg_0_8039ace ;
  input ram_reg_i_373__0;
  input esc_add_ln74_reg_6855_reg_7__2_c3111d6 ;
  input esc_add_ln74_reg_6855_reg_6__2_76dcc1d ;
  input ram0_reg_33;
  input ram0_reg_i_53;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]CO;
  wire [0:0]D;
  wire [7:0]DOADO;
  wire GND_2;
  wire [0:0]Q;
  wire [0:0]WEA;
  wire esc_add_ln208_102_reg_8173_3__i_2_n_0_b7342b8 ;
  wire esc_add_ln208_102_reg_8173_3__i_3_n_0_f901c72 ;
  wire esc_add_ln208_102_reg_8173_3__i_4_n_0_78f6028 ;
  wire esc_add_ln208_102_reg_8173_3__i_5_n_0_a3259ab ;
  wire esc_add_ln208_102_reg_8173_7__i_2_n_0_d913391 ;
  wire esc_add_ln208_102_reg_8173_7__i_3_n_0_809c38a ;
  wire esc_add_ln208_102_reg_8173_7__i_4_n_0_4101a58 ;
  wire esc_add_ln208_102_reg_8173_7__i_5_n_0_5e4cff2 ;
  wire esc_add_ln208_102_reg_8173_reg_11__i_1_n_0_ceab219 ;
  wire [12:0]esc_add_ln208_102_reg_8173_reg_12_c8013a3 ;
  wire [12:0]esc_add_ln208_102_reg_8173_reg_12__0_a64db1c ;
  wire esc_add_ln208_102_reg_8173_reg_3__i_1_n_0_0df6d63 ;
  wire esc_add_ln208_102_reg_8173_reg_7__i_1_n_0_a010009 ;
  wire esc_add_ln208_105_reg_8205_3__i_2_n_0_ecb0dcf ;
  wire esc_add_ln208_105_reg_8205_3__i_3_n_0_3d7f23c ;
  wire esc_add_ln208_105_reg_8205_3__i_4_n_0_69bdfbf ;
  wire esc_add_ln208_105_reg_8205_3__i_5_n_0_e364dd2 ;
  wire esc_add_ln208_105_reg_8205_7__i_2_n_0_3d5702b ;
  wire esc_add_ln208_105_reg_8205_7__i_3_n_0_d53c802 ;
  wire esc_add_ln208_105_reg_8205_7__i_4_n_0_efe3bfb ;
  wire esc_add_ln208_105_reg_8205_7__i_5_n_0_ab01214 ;
  wire esc_add_ln208_105_reg_8205_reg_11__i_1_n_0_1ca6d32 ;
  wire [12:0]esc_add_ln208_105_reg_8205_reg_12_4c8e965 ;
  wire [12:0]esc_add_ln208_105_reg_8205_reg_12__0_1875a9f ;
  wire esc_add_ln208_105_reg_8205_reg_3__i_1_n_0_09668d6 ;
  wire esc_add_ln208_105_reg_8205_reg_7__i_1_n_0_11af300 ;
  wire esc_add_ln208_108_reg_8237_3__i_2_n_0_2183c53 ;
  wire esc_add_ln208_108_reg_8237_3__i_3_n_0_ae14cb5 ;
  wire esc_add_ln208_108_reg_8237_3__i_4_n_0_82c7437 ;
  wire esc_add_ln208_108_reg_8237_3__i_5_n_0_236585d ;
  wire esc_add_ln208_108_reg_8237_7__i_2_n_0_efa8bea ;
  wire esc_add_ln208_108_reg_8237_7__i_3_n_0_e06b33c ;
  wire esc_add_ln208_108_reg_8237_7__i_4_n_0_5f920c5 ;
  wire esc_add_ln208_108_reg_8237_7__i_5_n_0_f62ea47 ;
  wire esc_add_ln208_108_reg_8237_reg_11__i_1_n_0_06a1ab2 ;
  wire [12:0]esc_add_ln208_108_reg_8237_reg_12_b4010f2 ;
  wire [12:0]esc_add_ln208_108_reg_8237_reg_12__0_9171fbf ;
  wire esc_add_ln208_108_reg_8237_reg_3__i_1_n_0_aa4ad88 ;
  wire esc_add_ln208_108_reg_8237_reg_7__i_1_n_0_6654862 ;
  wire esc_add_ln208_111_reg_8269_3__i_2_n_0_9cdc103 ;
  wire esc_add_ln208_111_reg_8269_3__i_3_n_0_df47d30 ;
  wire esc_add_ln208_111_reg_8269_3__i_4_n_0_8077490 ;
  wire esc_add_ln208_111_reg_8269_3__i_5_n_0_d404733 ;
  wire esc_add_ln208_111_reg_8269_7__i_2_n_0_38ed9c8 ;
  wire esc_add_ln208_111_reg_8269_7__i_3_n_0_170261a ;
  wire esc_add_ln208_111_reg_8269_7__i_4_n_0_d20b616 ;
  wire esc_add_ln208_111_reg_8269_7__i_5_n_0_503a74e ;
  wire esc_add_ln208_111_reg_8269_reg_11__i_1_n_0_323a719 ;
  wire [12:0]esc_add_ln208_111_reg_8269_reg_12_37e6aa3 ;
  wire [12:0]esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 ;
  wire esc_add_ln208_111_reg_8269_reg_3__i_1_n_0_6c5c2d1 ;
  wire esc_add_ln208_111_reg_8269_reg_7__i_1_n_0_9e6726b ;
  wire esc_add_ln208_114_reg_8301_3__i_2_n_0_3002f7a ;
  wire esc_add_ln208_114_reg_8301_3__i_3_n_0_50e2114 ;
  wire esc_add_ln208_114_reg_8301_3__i_4_n_0_5a1c062 ;
  wire esc_add_ln208_114_reg_8301_3__i_5_n_0_5f1d0bd ;
  wire esc_add_ln208_114_reg_8301_7__i_2_n_0_c6f7105 ;
  wire esc_add_ln208_114_reg_8301_7__i_3_n_0_145235f ;
  wire esc_add_ln208_114_reg_8301_7__i_4_n_0_b68ae06 ;
  wire esc_add_ln208_114_reg_8301_7__i_5_n_0_f92d99c ;
  wire esc_add_ln208_114_reg_8301_reg_11__i_1_n_0_d160ef8 ;
  wire [12:0]esc_add_ln208_114_reg_8301_reg_12_915e9df ;
  wire [12:0]esc_add_ln208_114_reg_8301_reg_12__0_432a19c ;
  wire esc_add_ln208_114_reg_8301_reg_3__i_1_n_0_419ad10 ;
  wire esc_add_ln208_114_reg_8301_reg_7__i_1_n_0_cbef687 ;
  wire esc_add_ln208_117_reg_8333_3__i_2_n_0_a46747c ;
  wire esc_add_ln208_117_reg_8333_3__i_3_n_0_6f6895d ;
  wire esc_add_ln208_117_reg_8333_3__i_4_n_0_7f298d8 ;
  wire esc_add_ln208_117_reg_8333_3__i_5_n_0_a313e45 ;
  wire esc_add_ln208_117_reg_8333_7__i_2_n_0_c2b85ec ;
  wire esc_add_ln208_117_reg_8333_7__i_3_n_0_ce6ec80 ;
  wire esc_add_ln208_117_reg_8333_7__i_4_n_0_cbac282 ;
  wire esc_add_ln208_117_reg_8333_7__i_5_n_0_6710aa9 ;
  wire esc_add_ln208_117_reg_8333_reg_11__i_1_n_0_46206d9 ;
  wire [12:0]esc_add_ln208_117_reg_8333_reg_12_7252cfb ;
  wire [12:0]esc_add_ln208_117_reg_8333_reg_12__0_934ade3 ;
  wire esc_add_ln208_117_reg_8333_reg_3__i_1_n_0_19a7bc9 ;
  wire esc_add_ln208_117_reg_8333_reg_7__i_1_n_0_746c324 ;
  wire esc_add_ln208_120_reg_8365_3__i_2_n_0_bd4ffd9 ;
  wire esc_add_ln208_120_reg_8365_3__i_3_n_0_916e4b1 ;
  wire esc_add_ln208_120_reg_8365_3__i_4_n_0_0f0b5d2 ;
  wire esc_add_ln208_120_reg_8365_3__i_5_n_0_220cee3 ;
  wire esc_add_ln208_120_reg_8365_7__i_2_n_0_7fc5329 ;
  wire esc_add_ln208_120_reg_8365_7__i_3_n_0_0123f46 ;
  wire esc_add_ln208_120_reg_8365_7__i_4_n_0_8a86106 ;
  wire esc_add_ln208_120_reg_8365_7__i_5_n_0_eb71344 ;
  wire esc_add_ln208_120_reg_8365_reg_11__i_1_n_0_cb0b6a1 ;
  wire [12:0]esc_add_ln208_120_reg_8365_reg_12_09d1f79 ;
  wire [12:0]esc_add_ln208_120_reg_8365_reg_12__0_26aac56 ;
  wire esc_add_ln208_120_reg_8365_reg_3__i_1_n_0_0947f49 ;
  wire esc_add_ln208_120_reg_8365_reg_7__i_1_n_0_0763155 ;
  wire esc_add_ln208_123_reg_8397_3__i_2_n_0_6bb69fe ;
  wire esc_add_ln208_123_reg_8397_3__i_3_n_0_aa929b4 ;
  wire esc_add_ln208_123_reg_8397_3__i_4_n_0_5716c26 ;
  wire esc_add_ln208_123_reg_8397_3__i_5_n_0_afce416 ;
  wire esc_add_ln208_123_reg_8397_7__i_2_n_0_506848a ;
  wire esc_add_ln208_123_reg_8397_7__i_3_n_0_63deae6 ;
  wire esc_add_ln208_123_reg_8397_7__i_4_n_0_3efddbf ;
  wire esc_add_ln208_123_reg_8397_7__i_5_n_0_a18e72d ;
  wire esc_add_ln208_123_reg_8397_reg_11__i_1_n_0_0a96fef ;
  wire [12:0]esc_add_ln208_123_reg_8397_reg_12_99743e4 ;
  wire [12:0]esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 ;
  wire esc_add_ln208_123_reg_8397_reg_3__i_1_n_0_d1a6613 ;
  wire esc_add_ln208_123_reg_8397_reg_7__i_1_n_0_0422039 ;
  wire esc_add_ln208_126_reg_8429_3__i_2_n_0_0d8f1b2 ;
  wire esc_add_ln208_126_reg_8429_3__i_3_n_0_a6b1e03 ;
  wire esc_add_ln208_126_reg_8429_3__i_4_n_0_5e9afd6 ;
  wire esc_add_ln208_126_reg_8429_3__i_5_n_0_c10242c ;
  wire esc_add_ln208_126_reg_8429_7__i_2_n_0_418989b ;
  wire esc_add_ln208_126_reg_8429_7__i_3_n_0_f5b0160 ;
  wire esc_add_ln208_126_reg_8429_7__i_4_n_0_cb39cdf ;
  wire esc_add_ln208_126_reg_8429_7__i_5_n_0_01a1dc5 ;
  wire esc_add_ln208_126_reg_8429_reg_11__i_1_n_0_420f351 ;
  wire [12:0]esc_add_ln208_126_reg_8429_reg_12_387655d ;
  wire [12:0]esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 ;
  wire esc_add_ln208_126_reg_8429_reg_3__i_1_n_0_18522ef ;
  wire esc_add_ln208_126_reg_8429_reg_7__i_1_n_0_9e83959 ;
  wire esc_add_ln208_129_reg_8461_3__i_2_n_0_64b5af6 ;
  wire esc_add_ln208_129_reg_8461_3__i_3_n_0_076f8c2 ;
  wire esc_add_ln208_129_reg_8461_3__i_4_n_0_9364254 ;
  wire esc_add_ln208_129_reg_8461_3__i_5_n_0_87bfb39 ;
  wire esc_add_ln208_129_reg_8461_7__i_2_n_0_2e159a7 ;
  wire esc_add_ln208_129_reg_8461_7__i_3_n_0_b6e1414 ;
  wire esc_add_ln208_129_reg_8461_7__i_4_n_0_c1b3b55 ;
  wire esc_add_ln208_129_reg_8461_7__i_5_n_0_63139f3 ;
  wire esc_add_ln208_129_reg_8461_reg_11__i_1_n_0_620c427 ;
  wire [12:0]esc_add_ln208_129_reg_8461_reg_12_33d91dc ;
  wire [12:0]esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a ;
  wire esc_add_ln208_129_reg_8461_reg_3__i_1_n_0_a33e088 ;
  wire esc_add_ln208_129_reg_8461_reg_7__i_1_n_0_23cb280 ;
  wire esc_add_ln208_132_reg_8493_3__i_2_n_0_cf4b28b ;
  wire esc_add_ln208_132_reg_8493_3__i_3_n_0_58d6e9f ;
  wire esc_add_ln208_132_reg_8493_3__i_4_n_0_184c09d ;
  wire esc_add_ln208_132_reg_8493_3__i_5_n_0_485ac66 ;
  wire esc_add_ln208_132_reg_8493_7__i_2_n_0_90ac4c2 ;
  wire esc_add_ln208_132_reg_8493_7__i_3_n_0_4f66507 ;
  wire esc_add_ln208_132_reg_8493_7__i_4_n_0_7cf72ea ;
  wire esc_add_ln208_132_reg_8493_7__i_5_n_0_b797ef2 ;
  wire esc_add_ln208_132_reg_8493_reg_11__i_1_n_0_0b984ec ;
  wire [13:0]esc_add_ln208_132_reg_8493_reg_12_7e23985 ;
  wire [12:0]esc_add_ln208_132_reg_8493_reg_12__0_1f22523 ;
  wire esc_add_ln208_132_reg_8493_reg_3__i_1_n_0_7a4606d ;
  wire esc_add_ln208_132_reg_8493_reg_7__i_1_n_0_cb5564e ;
  wire esc_add_ln208_135_reg_8525_3__i_2_n_0_a26cc01 ;
  wire esc_add_ln208_135_reg_8525_3__i_3_n_0_5c3ee2b ;
  wire esc_add_ln208_135_reg_8525_3__i_4_n_0_484ede1 ;
  wire esc_add_ln208_135_reg_8525_3__i_5_n_0_0c83946 ;
  wire esc_add_ln208_135_reg_8525_7__i_2_n_0_5bcd7b3 ;
  wire esc_add_ln208_135_reg_8525_7__i_3_n_0_7cc9628 ;
  wire esc_add_ln208_135_reg_8525_7__i_4_n_0_f4c6e57 ;
  wire esc_add_ln208_135_reg_8525_7__i_5_n_0_69f136b ;
  wire esc_add_ln208_135_reg_8525_reg_11__i_1_n_0_66514c1 ;
  wire [13:0]esc_add_ln208_135_reg_8525_reg_13_7810c12 ;
  wire [12:0]esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 ;
  wire esc_add_ln208_135_reg_8525_reg_3__i_1_n_0_170acf0 ;
  wire esc_add_ln208_135_reg_8525_reg_7__i_1_n_0_60dbe1f ;
  wire esc_add_ln208_138_reg_8557_3__i_2_n_0_ba5be80 ;
  wire esc_add_ln208_138_reg_8557_3__i_3_n_0_9d799da ;
  wire esc_add_ln208_138_reg_8557_3__i_4_n_0_c715d7c ;
  wire esc_add_ln208_138_reg_8557_3__i_5_n_0_3f73d01 ;
  wire esc_add_ln208_138_reg_8557_7__i_2_n_0_9ef0265 ;
  wire esc_add_ln208_138_reg_8557_7__i_3_n_0_dc36649 ;
  wire esc_add_ln208_138_reg_8557_7__i_4_n_0_639b026 ;
  wire esc_add_ln208_138_reg_8557_7__i_5_n_0_6eda6bb ;
  wire esc_add_ln208_138_reg_8557_reg_11__i_1_n_0_7ebbbf2 ;
  wire [13:0]esc_add_ln208_138_reg_8557_reg_13_7e0af06 ;
  wire [13:0]esc_add_ln208_138_reg_8557_reg_13__0_862abfd ;
  wire esc_add_ln208_138_reg_8557_reg_3__i_1_n_0_3285e94 ;
  wire esc_add_ln208_138_reg_8557_reg_7__i_1_n_0_fbe824d ;
  wire esc_add_ln208_141_reg_8589_3__i_2_n_0_42ac8a8 ;
  wire esc_add_ln208_141_reg_8589_3__i_3_n_0_fe1b613 ;
  wire esc_add_ln208_141_reg_8589_3__i_4_n_0_b721015 ;
  wire esc_add_ln208_141_reg_8589_3__i_5_n_0_8b403a6 ;
  wire esc_add_ln208_141_reg_8589_7__i_2_n_0_c2d81de ;
  wire esc_add_ln208_141_reg_8589_7__i_3_n_0_d4b62fc ;
  wire esc_add_ln208_141_reg_8589_7__i_4_n_0_86c4805 ;
  wire esc_add_ln208_141_reg_8589_7__i_5_n_0_4378a21 ;
  wire esc_add_ln208_141_reg_8589_reg_11__i_1_n_0_524a38b ;
  wire [13:0]esc_add_ln208_141_reg_8589_reg_13_eb89c6f ;
  wire [13:0]esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 ;
  wire esc_add_ln208_141_reg_8589_reg_3__i_1_n_0_edebe90 ;
  wire esc_add_ln208_141_reg_8589_reg_7__i_1_n_0_9e26169 ;
  wire esc_add_ln208_144_reg_8621_3__i_2_n_0_fa7792b ;
  wire esc_add_ln208_144_reg_8621_3__i_3_n_0_7aece36 ;
  wire esc_add_ln208_144_reg_8621_3__i_4_n_0_f2882d0 ;
  wire esc_add_ln208_144_reg_8621_3__i_5_n_0_6dec4db ;
  wire esc_add_ln208_144_reg_8621_7__i_2_n_0_8d40fdc ;
  wire esc_add_ln208_144_reg_8621_7__i_3_n_0_df3afd8 ;
  wire esc_add_ln208_144_reg_8621_7__i_4_n_0_dc899f7 ;
  wire esc_add_ln208_144_reg_8621_7__i_5_n_0_95db23d ;
  wire esc_add_ln208_144_reg_8621_reg_11__i_1_n_0_349f597 ;
  wire [13:0]esc_add_ln208_144_reg_8621_reg_13_47c2a26 ;
  wire [13:0]esc_add_ln208_144_reg_8621_reg_13__0_aba970f ;
  wire esc_add_ln208_144_reg_8621_reg_3__i_1_n_0_64fdd2c ;
  wire esc_add_ln208_144_reg_8621_reg_7__i_1_n_0_71154b8 ;
  wire esc_add_ln208_147_reg_8653_3__i_2_n_0_1f5280b ;
  wire esc_add_ln208_147_reg_8653_3__i_3_n_0_29cdd4d ;
  wire esc_add_ln208_147_reg_8653_3__i_4_n_0_bb6a6df ;
  wire esc_add_ln208_147_reg_8653_3__i_5_n_0_c5642f1 ;
  wire esc_add_ln208_147_reg_8653_7__i_2_n_0_8242b78 ;
  wire esc_add_ln208_147_reg_8653_7__i_3_n_0_69586a9 ;
  wire esc_add_ln208_147_reg_8653_7__i_4_n_0_bc1a00f ;
  wire esc_add_ln208_147_reg_8653_7__i_5_n_0_b85b122 ;
  wire esc_add_ln208_147_reg_8653_reg_11__i_1_n_0_76e88bd ;
  wire [13:0]esc_add_ln208_147_reg_8653_reg_13_2be1b94 ;
  wire [13:0]esc_add_ln208_147_reg_8653_reg_13__0_c9f027d ;
  wire esc_add_ln208_147_reg_8653_reg_3__i_1_n_0_7e472d4 ;
  wire esc_add_ln208_147_reg_8653_reg_7__i_1_n_0_6ed0515 ;
  wire esc_add_ln208_150_reg_8685_3__i_2_n_0_136e3b0 ;
  wire esc_add_ln208_150_reg_8685_3__i_3_n_0_3757d31 ;
  wire esc_add_ln208_150_reg_8685_3__i_4_n_0_9457665 ;
  wire esc_add_ln208_150_reg_8685_3__i_5_n_0_eaca254 ;
  wire esc_add_ln208_150_reg_8685_7__i_2_n_0_1622eec ;
  wire esc_add_ln208_150_reg_8685_7__i_3_n_0_ecf5b23 ;
  wire esc_add_ln208_150_reg_8685_7__i_4_n_0_d7978e2 ;
  wire esc_add_ln208_150_reg_8685_7__i_5_n_0_1303e55 ;
  wire esc_add_ln208_150_reg_8685_reg_11__i_1_n_0_50c387d ;
  wire [13:0]esc_add_ln208_150_reg_8685_reg_13_ba3a6fb ;
  wire [13:0]esc_add_ln208_150_reg_8685_reg_13__0_8447d92 ;
  wire esc_add_ln208_150_reg_8685_reg_3__i_1_n_0_48ffcef ;
  wire esc_add_ln208_150_reg_8685_reg_7__i_1_n_0_d7e94f5 ;
  wire esc_add_ln208_153_reg_8717_3__i_2_n_0_bef5723 ;
  wire esc_add_ln208_153_reg_8717_3__i_3_n_0_e68123a ;
  wire esc_add_ln208_153_reg_8717_3__i_4_n_0_0f499c8 ;
  wire esc_add_ln208_153_reg_8717_3__i_5_n_0_cf1ec89 ;
  wire esc_add_ln208_153_reg_8717_7__i_2_n_0_b313dc9 ;
  wire esc_add_ln208_153_reg_8717_7__i_3_n_0_3e58ad6 ;
  wire esc_add_ln208_153_reg_8717_7__i_4_n_0_151aeb5 ;
  wire esc_add_ln208_153_reg_8717_7__i_5_n_0_efb044e ;
  wire esc_add_ln208_153_reg_8717_reg_11__i_1_n_0_8515b46 ;
  wire [13:0]esc_add_ln208_153_reg_8717_reg_13_6aad7d7 ;
  wire esc_add_ln208_153_reg_8717_reg_3__i_1_n_0_147a85a ;
  wire esc_add_ln208_153_reg_8717_reg_7__i_1_n_0_e76998f ;
  wire esc_add_ln208_157_reg_8733_3__i_10_n_0_fe654b1 ;
  wire esc_add_ln208_157_reg_8733_3__i_7_n_0_8699c8f ;
  wire esc_add_ln208_157_reg_8733_3__i_8_n_0_977be48 ;
  wire esc_add_ln208_157_reg_8733_3__i_9_n_0_5320947 ;
  wire esc_add_ln208_157_reg_8733_7__i_10_n_0_d2d5e66 ;
  wire esc_add_ln208_157_reg_8733_7__i_7_n_0_bc5b8e7 ;
  wire esc_add_ln208_157_reg_8733_7__i_8_n_0_011168a ;
  wire esc_add_ln208_157_reg_8733_7__i_9_n_0_0f37152 ;
  wire esc_add_ln208_157_reg_8733_reg_11__i_2_n_0_fb34f2e ;
  wire [13:0]esc_add_ln208_157_reg_8733_reg_15_b87abdb ;
  wire esc_add_ln208_157_reg_8733_reg_3__i_2_n_0_b0bd9fc ;
  wire esc_add_ln208_157_reg_8733_reg_7__i_2_n_0_ea8cc3f ;
  wire esc_add_ln208_42_reg_7073_3__i_2_n_0_a835674 ;
  wire esc_add_ln208_42_reg_7073_3__i_3_n_0_17a625a ;
  wire esc_add_ln208_42_reg_7073_3__i_4_n_0_98a54f3 ;
  wire esc_add_ln208_42_reg_7073_3__i_5_n_0_9d71024 ;
  wire esc_add_ln208_42_reg_7073_7__i_2_n_0_3e83539 ;
  wire esc_add_ln208_42_reg_7073_7__i_3_n_0_85e06db ;
  wire esc_add_ln208_42_reg_7073_7__i_4_n_0_fb01aad ;
  wire esc_add_ln208_42_reg_7073_7__i_5_n_0_2306f9c ;
  wire esc_add_ln208_42_reg_7073_reg_3__i_1_n_0_595b7d0 ;
  wire esc_add_ln208_42_reg_7073_reg_7__i_1_n_0_312fed8 ;
  wire [9:0]esc_add_ln208_42_reg_7073_reg_8_b2dae6f ;
  wire esc_add_ln208_45_reg_7125_3__i_2_n_0_b581a8d ;
  wire esc_add_ln208_45_reg_7125_3__i_3_n_0_afe89d3 ;
  wire esc_add_ln208_45_reg_7125_3__i_4_n_0_32b3e9e ;
  wire esc_add_ln208_45_reg_7125_3__i_5_n_0_0f6b41a ;
  wire esc_add_ln208_45_reg_7125_7__i_2_n_0_518af43 ;
  wire esc_add_ln208_45_reg_7125_7__i_3_n_0_e296b1d ;
  wire esc_add_ln208_45_reg_7125_7__i_4_n_0_37cde2e ;
  wire esc_add_ln208_45_reg_7125_7__i_5_n_0_40b9c71 ;
  wire esc_add_ln208_45_reg_7125_reg_3__i_1_n_0_9ca58c1 ;
  wire esc_add_ln208_45_reg_7125_reg_7__i_1_n_0_e931a96 ;
  wire [9:0]esc_add_ln208_45_reg_7125_reg_9_8959fd9 ;
  wire [8:0]esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 ;
  wire esc_add_ln208_48_reg_7177_3__i_2_n_0_8c9f566 ;
  wire esc_add_ln208_48_reg_7177_3__i_3_n_0_7bc60e1 ;
  wire esc_add_ln208_48_reg_7177_3__i_4_n_0_e2e6a58 ;
  wire esc_add_ln208_48_reg_7177_3__i_5_n_0_d294376 ;
  wire esc_add_ln208_48_reg_7177_7__i_2_n_0_13c4a26 ;
  wire esc_add_ln208_48_reg_7177_7__i_3_n_0_6f19840 ;
  wire esc_add_ln208_48_reg_7177_7__i_4_n_0_38ca192 ;
  wire esc_add_ln208_48_reg_7177_7__i_5_n_0_77c59f6 ;
  wire esc_add_ln208_48_reg_7177_reg_3__i_1_n_0_cf94cb4 ;
  wire esc_add_ln208_48_reg_7177_reg_7__i_1_n_0_cae23a0 ;
  wire [10:0]esc_add_ln208_48_reg_7177_reg_9_c78b76f ;
  wire [9:0]esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 ;
  wire esc_add_ln208_51_reg_7229_3__i_2_n_0_4693b30 ;
  wire esc_add_ln208_51_reg_7229_3__i_3_n_0_3fe0616 ;
  wire esc_add_ln208_51_reg_7229_3__i_4_n_0_7dd75c8 ;
  wire esc_add_ln208_51_reg_7229_3__i_5_n_0_84e510e ;
  wire esc_add_ln208_51_reg_7229_7__i_2_n_0_f00b7af ;
  wire esc_add_ln208_51_reg_7229_7__i_3_n_0_70cce66 ;
  wire esc_add_ln208_51_reg_7229_7__i_4_n_0_29b6d46 ;
  wire esc_add_ln208_51_reg_7229_7__i_5_n_0_efcadb8 ;
  wire [10:0]esc_add_ln208_51_reg_7229_reg_10_08c463a ;
  wire [9:0]esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b ;
  wire esc_add_ln208_51_reg_7229_reg_3__i_1_n_0_ec89a1a ;
  wire esc_add_ln208_51_reg_7229_reg_7__i_1_n_0_3de2fbb ;
  wire esc_add_ln208_54_reg_7281_3__i_2_n_0_3b080d8 ;
  wire esc_add_ln208_54_reg_7281_3__i_3_n_0_8c93cb8 ;
  wire esc_add_ln208_54_reg_7281_3__i_4_n_0_c9fecec ;
  wire esc_add_ln208_54_reg_7281_3__i_5_n_0_cbad84d ;
  wire esc_add_ln208_54_reg_7281_7__i_2_n_0_acab14d ;
  wire esc_add_ln208_54_reg_7281_7__i_3_n_0_d03d681 ;
  wire esc_add_ln208_54_reg_7281_7__i_4_n_0_5a1ee75 ;
  wire esc_add_ln208_54_reg_7281_7__i_5_n_0_bb8dcfb ;
  wire [10:0]esc_add_ln208_54_reg_7281_reg_10_5a808fe ;
  wire [10:0]esc_add_ln208_54_reg_7281_reg_10__0_56b943a ;
  wire esc_add_ln208_54_reg_7281_reg_3__i_1_n_0_cd4f567 ;
  wire esc_add_ln208_54_reg_7281_reg_7__i_1_n_0_95a17ae ;
  wire esc_add_ln208_57_reg_7333_3__i_2_n_0_2becd2c ;
  wire esc_add_ln208_57_reg_7333_3__i_3_n_0_606e4d6 ;
  wire esc_add_ln208_57_reg_7333_3__i_4_n_0_279edcd ;
  wire esc_add_ln208_57_reg_7333_3__i_5_n_0_04c5953 ;
  wire esc_add_ln208_57_reg_7333_7__i_2_n_0_4f4834a ;
  wire esc_add_ln208_57_reg_7333_7__i_3_n_0_d130c79 ;
  wire esc_add_ln208_57_reg_7333_7__i_4_n_0_c1613c8 ;
  wire esc_add_ln208_57_reg_7333_7__i_5_n_0_4ebe9aa ;
  wire [10:0]esc_add_ln208_57_reg_7333_reg_10_4817937 ;
  wire [10:0]esc_add_ln208_57_reg_7333_reg_10__0_06e9277 ;
  wire esc_add_ln208_57_reg_7333_reg_3__i_1_n_0_f7dfc85 ;
  wire esc_add_ln208_57_reg_7333_reg_7__i_1_n_0_384af07 ;
  wire esc_add_ln208_60_reg_7385_3__i_2_n_0_4bc3aa4 ;
  wire esc_add_ln208_60_reg_7385_3__i_3_n_0_448e9b8 ;
  wire esc_add_ln208_60_reg_7385_3__i_4_n_0_8ab84cc ;
  wire esc_add_ln208_60_reg_7385_3__i_5_n_0_0dadd5d ;
  wire esc_add_ln208_60_reg_7385_7__i_2_n_0_b6404b5 ;
  wire esc_add_ln208_60_reg_7385_7__i_3_n_0_d6507a1 ;
  wire esc_add_ln208_60_reg_7385_7__i_4_n_0_3abb497 ;
  wire esc_add_ln208_60_reg_7385_7__i_5_n_0_a9e6e8b ;
  wire [11:0]esc_add_ln208_60_reg_7385_reg_10_d918a34 ;
  wire [10:0]esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 ;
  wire esc_add_ln208_60_reg_7385_reg_3__i_1_n_0_083dfec ;
  wire esc_add_ln208_60_reg_7385_reg_7__i_1_n_0_0eba9d8 ;
  wire esc_add_ln208_63_reg_7437_3__i_2_n_0_cc0b3c2 ;
  wire esc_add_ln208_63_reg_7437_3__i_3_n_0_077acfe ;
  wire esc_add_ln208_63_reg_7437_3__i_4_n_0_c4b93d5 ;
  wire esc_add_ln208_63_reg_7437_3__i_5_n_0_9b3ef72 ;
  wire esc_add_ln208_63_reg_7437_7__i_2_n_0_f5af5ea ;
  wire esc_add_ln208_63_reg_7437_7__i_3_n_0_4fbf927 ;
  wire esc_add_ln208_63_reg_7437_7__i_4_n_0_b8a71e4 ;
  wire esc_add_ln208_63_reg_7437_7__i_5_n_0_223c683 ;
  wire [11:0]esc_add_ln208_63_reg_7437_reg_11_9252a9b ;
  wire [10:0]esc_add_ln208_63_reg_7437_reg_11__0_5853d45 ;
  wire esc_add_ln208_63_reg_7437_reg_3__i_1_n_0_f2a6ade ;
  wire esc_add_ln208_63_reg_7437_reg_7__i_1_n_0_7b9fc63 ;
  wire esc_add_ln208_66_reg_7489_3__i_2_n_0_9169d4c ;
  wire esc_add_ln208_66_reg_7489_3__i_3_n_0_13837fb ;
  wire esc_add_ln208_66_reg_7489_3__i_4_n_0_86b92b2 ;
  wire esc_add_ln208_66_reg_7489_3__i_5_n_0_c334c93 ;
  wire esc_add_ln208_66_reg_7489_7__i_2_n_0_8a449cf ;
  wire esc_add_ln208_66_reg_7489_7__i_3_n_0_c836fb4 ;
  wire esc_add_ln208_66_reg_7489_7__i_4_n_0_403b0ee ;
  wire esc_add_ln208_66_reg_7489_7__i_5_n_0_b1d1a85 ;
  wire [11:0]esc_add_ln208_66_reg_7489_reg_11_f470215 ;
  wire [11:0]esc_add_ln208_66_reg_7489_reg_11__0_33e5672 ;
  wire esc_add_ln208_66_reg_7489_reg_3__i_1_n_0_f728505 ;
  wire esc_add_ln208_66_reg_7489_reg_7__i_1_n_0_16dabef ;
  wire esc_add_ln208_69_reg_7541_3__i_2_n_0_5fc8549 ;
  wire esc_add_ln208_69_reg_7541_3__i_3_n_0_eae363d ;
  wire esc_add_ln208_69_reg_7541_3__i_4_n_0_a99e682 ;
  wire esc_add_ln208_69_reg_7541_3__i_5_n_0_ac555ed ;
  wire esc_add_ln208_69_reg_7541_7__i_2_n_0_f38663c ;
  wire esc_add_ln208_69_reg_7541_7__i_3_n_0_a472f20 ;
  wire esc_add_ln208_69_reg_7541_7__i_4_n_0_712fefb ;
  wire esc_add_ln208_69_reg_7541_7__i_5_n_0_c583a91 ;
  wire [11:0]esc_add_ln208_69_reg_7541_reg_11_1ab4dac ;
  wire [11:0]esc_add_ln208_69_reg_7541_reg_11__0_0318481 ;
  wire esc_add_ln208_69_reg_7541_reg_3__i_1_n_0_91ac2a9 ;
  wire esc_add_ln208_69_reg_7541_reg_7__i_1_n_0_14a480a ;
  wire esc_add_ln208_72_reg_7593_3__i_2_n_0_9346212 ;
  wire esc_add_ln208_72_reg_7593_3__i_3_n_0_a7c035a ;
  wire esc_add_ln208_72_reg_7593_3__i_4_n_0_4c45321 ;
  wire esc_add_ln208_72_reg_7593_3__i_5_n_0_68ca72d ;
  wire esc_add_ln208_72_reg_7593_7__i_2_n_0_d513f76 ;
  wire esc_add_ln208_72_reg_7593_7__i_3_n_0_4769bbd ;
  wire esc_add_ln208_72_reg_7593_7__i_4_n_0_cbde428 ;
  wire esc_add_ln208_72_reg_7593_7__i_5_n_0_0bc2a1e ;
  wire [11:0]esc_add_ln208_72_reg_7593_reg_11_6fb0a9c ;
  wire [11:0]esc_add_ln208_72_reg_7593_reg_11__0_87f0eda ;
  wire esc_add_ln208_72_reg_7593_reg_3__i_1_n_0_3261274 ;
  wire esc_add_ln208_72_reg_7593_reg_7__i_1_n_0_8948c54 ;
  wire esc_add_ln208_75_reg_7655_3__i_2_n_0_dc909d2 ;
  wire esc_add_ln208_75_reg_7655_3__i_3_n_0_7609aba ;
  wire esc_add_ln208_75_reg_7655_3__i_4_n_0_5816a07 ;
  wire esc_add_ln208_75_reg_7655_3__i_5_n_0_7ae65fa ;
  wire esc_add_ln208_75_reg_7655_7__i_2_n_0_6389c0f ;
  wire esc_add_ln208_75_reg_7655_7__i_3_n_0_4d6af57 ;
  wire esc_add_ln208_75_reg_7655_7__i_4_n_0_296957f ;
  wire esc_add_ln208_75_reg_7655_7__i_5_n_0_af2cd68 ;
  wire [11:0]esc_add_ln208_75_reg_7655_reg_11_3cc2dbe ;
  wire [11:0]esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 ;
  wire esc_add_ln208_75_reg_7655_reg_3__i_1_n_0_2517216 ;
  wire esc_add_ln208_75_reg_7655_reg_7__i_1_n_0_0a0c4c9 ;
  wire esc_add_ln208_78_reg_7717_3__i_2_n_0_5a5a281 ;
  wire esc_add_ln208_78_reg_7717_3__i_3_n_0_e233b25 ;
  wire esc_add_ln208_78_reg_7717_3__i_4_n_0_aede86f ;
  wire esc_add_ln208_78_reg_7717_3__i_5_n_0_08c3dd1 ;
  wire esc_add_ln208_78_reg_7717_7__i_2_n_0_c1a4753 ;
  wire esc_add_ln208_78_reg_7717_7__i_3_n_0_5c0edec ;
  wire esc_add_ln208_78_reg_7717_7__i_4_n_0_d02834e ;
  wire esc_add_ln208_78_reg_7717_7__i_5_n_0_5766059 ;
  wire [11:0]esc_add_ln208_78_reg_7717_reg_11_a25b5c3 ;
  wire [11:0]esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 ;
  wire esc_add_ln208_78_reg_7717_reg_3__i_1_n_0_f330ec6 ;
  wire esc_add_ln208_78_reg_7717_reg_7__i_1_n_0_27fd15c ;
  wire esc_add_ln208_81_reg_7779_3__i_2_n_0_58ba4b0 ;
  wire esc_add_ln208_81_reg_7779_3__i_3_n_0_4cf4db4 ;
  wire esc_add_ln208_81_reg_7779_3__i_4_n_0_e0cfd1a ;
  wire esc_add_ln208_81_reg_7779_3__i_5_n_0_8983cde ;
  wire esc_add_ln208_81_reg_7779_7__i_2_n_0_212f4b2 ;
  wire esc_add_ln208_81_reg_7779_7__i_3_n_0_c6795e1 ;
  wire esc_add_ln208_81_reg_7779_7__i_4_n_0_3729c83 ;
  wire esc_add_ln208_81_reg_7779_7__i_5_n_0_97a227a ;
  wire [11:0]esc_add_ln208_81_reg_7779_reg_11_758e45d ;
  wire [11:0]esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab ;
  wire esc_add_ln208_81_reg_7779_reg_3__i_1_n_0_750ee82 ;
  wire esc_add_ln208_81_reg_7779_reg_7__i_1_n_0_4d12364 ;
  wire esc_add_ln208_84_reg_7841_3__i_2_n_0_434b45c ;
  wire esc_add_ln208_84_reg_7841_3__i_3_n_0_bc7c798 ;
  wire esc_add_ln208_84_reg_7841_3__i_4_n_0_1c74e94 ;
  wire esc_add_ln208_84_reg_7841_3__i_5_n_0_ce0eb92 ;
  wire esc_add_ln208_84_reg_7841_7__i_2_n_0_2c8ffc1 ;
  wire esc_add_ln208_84_reg_7841_7__i_3_n_0_7502281 ;
  wire esc_add_ln208_84_reg_7841_7__i_4_n_0_549000c ;
  wire esc_add_ln208_84_reg_7841_7__i_5_n_0_f886d10 ;
  wire [12:0]esc_add_ln208_84_reg_7841_reg_11_3a19824 ;
  wire [11:0]esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 ;
  wire esc_add_ln208_84_reg_7841_reg_3__i_1_n_0_1e15dfe ;
  wire esc_add_ln208_84_reg_7841_reg_7__i_1_n_0_99b0121 ;
  wire esc_add_ln208_87_reg_7903_3__i_2_n_0_f4c5497 ;
  wire esc_add_ln208_87_reg_7903_3__i_3_n_0_f75f161 ;
  wire esc_add_ln208_87_reg_7903_3__i_4_n_0_31afac7 ;
  wire esc_add_ln208_87_reg_7903_3__i_5_n_0_b99ead5 ;
  wire esc_add_ln208_87_reg_7903_7__i_2_n_0_45dd29a ;
  wire esc_add_ln208_87_reg_7903_7__i_3_n_0_e541aad ;
  wire esc_add_ln208_87_reg_7903_7__i_4_n_0_fd025e0 ;
  wire esc_add_ln208_87_reg_7903_7__i_5_n_0_71c0526 ;
  wire [11:0]esc_add_ln208_87_reg_7903_reg_11_09bd1ec ;
  wire esc_add_ln208_87_reg_7903_reg_11__i_1_n_0_2d0377b ;
  wire [12:0]esc_add_ln208_87_reg_7903_reg_12_ebbbe3f ;
  wire esc_add_ln208_87_reg_7903_reg_3__i_1_n_0_a1308bf ;
  wire esc_add_ln208_87_reg_7903_reg_7__i_1_n_0_7bf0612 ;
  wire esc_add_ln208_90_reg_7965_3__i_2_n_0_c89938d ;
  wire esc_add_ln208_90_reg_7965_3__i_3_n_0_dd333d1 ;
  wire esc_add_ln208_90_reg_7965_3__i_4_n_0_9824211 ;
  wire esc_add_ln208_90_reg_7965_3__i_5_n_0_bd69146 ;
  wire esc_add_ln208_90_reg_7965_7__i_2_n_0_3404232 ;
  wire esc_add_ln208_90_reg_7965_7__i_3_n_0_51c21ef ;
  wire esc_add_ln208_90_reg_7965_7__i_4_n_0_5d60749 ;
  wire esc_add_ln208_90_reg_7965_7__i_5_n_0_2bbdecf ;
  wire esc_add_ln208_90_reg_7965_reg_11__i_1_n_0_3bb84e0 ;
  wire [12:0]esc_add_ln208_90_reg_7965_reg_12_6090767 ;
  wire [12:0]esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f ;
  wire esc_add_ln208_90_reg_7965_reg_3__i_1_n_0_2590075 ;
  wire esc_add_ln208_90_reg_7965_reg_7__i_1_n_0_30f1e19 ;
  wire esc_add_ln208_93_reg_8027_3__i_2_n_0_b2a7e69 ;
  wire esc_add_ln208_93_reg_8027_3__i_3_n_0_bd66261 ;
  wire esc_add_ln208_93_reg_8027_3__i_4_n_0_58c00bd ;
  wire esc_add_ln208_93_reg_8027_3__i_5_n_0_c5edabf ;
  wire esc_add_ln208_93_reg_8027_7__i_2_n_0_9c53918 ;
  wire esc_add_ln208_93_reg_8027_7__i_3_n_0_09dcbb1 ;
  wire esc_add_ln208_93_reg_8027_7__i_4_n_0_87df4e3 ;
  wire esc_add_ln208_93_reg_8027_7__i_5_n_0_1ecc40f ;
  wire esc_add_ln208_93_reg_8027_reg_11__i_1_n_0_db54423 ;
  wire [12:0]esc_add_ln208_93_reg_8027_reg_12_0c8544f ;
  wire [12:0]esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 ;
  wire esc_add_ln208_93_reg_8027_reg_3__i_1_n_0_21dbeaa ;
  wire esc_add_ln208_93_reg_8027_reg_7__i_1_n_0_90631f4 ;
  wire esc_add_ln208_96_reg_8089_3__i_2_n_0_868016c ;
  wire esc_add_ln208_96_reg_8089_3__i_3_n_0_0538a8c ;
  wire esc_add_ln208_96_reg_8089_3__i_4_n_0_b591fc9 ;
  wire esc_add_ln208_96_reg_8089_3__i_5_n_0_492cab7 ;
  wire esc_add_ln208_96_reg_8089_7__i_2_n_0_ef85ea1 ;
  wire esc_add_ln208_96_reg_8089_7__i_3_n_0_3e79da8 ;
  wire esc_add_ln208_96_reg_8089_7__i_4_n_0_4c42276 ;
  wire esc_add_ln208_96_reg_8089_7__i_5_n_0_f4d6eae ;
  wire esc_add_ln208_96_reg_8089_reg_11__i_1_n_0_aab1676 ;
  wire [12:0]esc_add_ln208_96_reg_8089_reg_12_26fe0a4 ;
  wire [12:0]esc_add_ln208_96_reg_8089_reg_12__0_4851c79 ;
  wire esc_add_ln208_96_reg_8089_reg_3__i_1_n_0_c21d59c ;
  wire esc_add_ln208_96_reg_8089_reg_7__i_1_n_0_91916af ;
  wire esc_add_ln208_99_reg_8131_3__i_2_n_0_e87eeda ;
  wire esc_add_ln208_99_reg_8131_3__i_3_n_0_03aec61 ;
  wire esc_add_ln208_99_reg_8131_3__i_4_n_0_dea97e3 ;
  wire esc_add_ln208_99_reg_8131_3__i_5_n_0_d90a829 ;
  wire esc_add_ln208_99_reg_8131_7__i_2_n_0_cbda796 ;
  wire esc_add_ln208_99_reg_8131_7__i_3_n_0_c8dbe0f ;
  wire esc_add_ln208_99_reg_8131_7__i_4_n_0_53a4daf ;
  wire esc_add_ln208_99_reg_8131_7__i_5_n_0_ee5b030 ;
  wire esc_add_ln208_99_reg_8131_reg_11__i_1_n_0_ad9b987 ;
  wire [12:0]esc_add_ln208_99_reg_8131_reg_12_287a134 ;
  wire [12:0]esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e ;
  wire esc_add_ln208_99_reg_8131_reg_3__i_1_n_0_d594831 ;
  wire esc_add_ln208_99_reg_8131_reg_7__i_1_n_0_25a6e02 ;
  wire esc_add_ln68_reg_8723_reg_1_d6e0e48 ;
  wire [3:0]esc_add_ln68_reg_8723_reg_2_180a5a5 ;
  wire esc_add_ln68_reg_8723_reg_2__0_0488464 ;
  wire esc_add_ln68_reg_8723_reg_3_d7954e8 ;
  wire [0:0]esc_add_ln68_reg_8723_reg_4_ae92a68 ;
  wire esc_add_ln74_reg_6855_reg_10_52d2cb4 ;
  wire esc_add_ln74_reg_6855_reg_10__0_d3d73fa ;
  wire esc_add_ln74_reg_6855_reg_5_2a13e9b ;
  wire esc_add_ln74_reg_6855_reg_5__0_2b6f97c ;
  wire esc_add_ln74_reg_6855_reg_6_25e4b8d ;
  wire esc_add_ln74_reg_6855_reg_6__0_8e7e51f ;
  wire esc_add_ln74_reg_6855_reg_6__1_a3a11c9 ;
  wire esc_add_ln74_reg_6855_reg_6__2_76dcc1d ;
  wire esc_add_ln74_reg_6855_reg_7_6b2f341 ;
  wire esc_add_ln74_reg_6855_reg_7__0_abb43a8 ;
  wire esc_add_ln74_reg_6855_reg_7__1_e9ac382 ;
  wire esc_add_ln74_reg_6855_reg_7__2_c3111d6 ;
  wire esc_add_ln74_reg_6855_reg_8_0e33662 ;
  wire esc_add_ln74_reg_6855_reg_8__0_dab2ff8 ;
  wire esc_add_ln74_reg_6855_reg_8__1_c9f6290 ;
  wire esc_add_ln74_reg_6855_reg_9_9c8c6ed ;
  wire esc_add_ln74_reg_6855_reg_9__0_2980795 ;
  wire esc_add_ln74_reg_6855_reg_9__1_9d031f6 ;
  wire esc_ap_CS_fsm_reg_16_2d815ec ;
  wire esc_ap_CS_fsm_reg_17_dedac0c ;
  wire esc_ap_CS_fsm_reg_17__0_3991a9e ;
  wire esc_ap_CS_fsm_reg_19_bd70f8c ;
  wire esc_ap_CS_fsm_reg_1_637b98d ;
  wire esc_ap_CS_fsm_reg_21_af57a65 ;
  wire esc_ap_CS_fsm_reg_23_edf6f2f ;
  wire esc_ap_CS_fsm_reg_26_bc9d1aa ;
  wire esc_ap_CS_fsm_reg_29_d9f5eab ;
  wire esc_ap_CS_fsm_reg_33_3728c13 ;
  wire esc_ap_CS_fsm_reg_35_69cfbc2 ;
  wire esc_ap_CS_fsm_reg_35__0_74dd3b9 ;
  wire esc_ap_CS_fsm_reg_35__1_673f736 ;
  wire esc_ap_CS_fsm_reg_46_ba5f378 ;
  wire esc_ap_CS_fsm_reg_48_486bf78 ;
  wire esc_ap_CS_fsm_reg_48__0_0aa522c ;
  wire esc_ap_CS_fsm_reg_54_3d44ae7 ;
  wire ap_clk;
  wire ap_enable_reg_pp0_iter1;
  wire ap_enable_reg_pp1_iter0;
  wire ap_enable_reg_pp1_iter0_reg;
  wire ap_enable_reg_pp1_iter1_reg;
  wire ap_enable_reg_pp3_iter0;
  wire ap_enable_reg_pp3_iter0_reg;
  wire ap_enable_reg_pp3_iter0_reg_0;
  wire ap_enable_reg_pp3_iter0_reg_rep;
  wire ap_enable_reg_pp3_iter0_reg_rep_0;
  wire ap_enable_reg_pp3_iter0_reg_rep__2;
  wire ap_enable_reg_pp3_iter0_reg_rep__2_0;
  wire ap_enable_reg_pp3_iter0_reg_rep__2_1;
  wire [0:0]ap_phi_mux_y_2_phi_fu_2389_p4;
  wire [3:0]data42;
  wire [3:0]esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc ;
  wire edge_counts_ce0;
  wire [7:0]edge_counts_d0;
  wire [1:0]mul_ln215_reg_6908;
  wire esc_mul_ln215_reg_6908_reg_0_b3fe01c ;
  wire esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ;
  wire esc_mul_ln215_reg_6908_reg_1_09f3be8 ;
  wire esc_mul_ln215_reg_6908_reg_1__0_292d7d8 ;
  wire esc_mul_ln215_reg_6908_reg_1__1_b396821 ;
  wire [8:0]ram0_reg_0;
  wire ram0_reg_1;
  wire ram0_reg_10;
  wire ram0_reg_11;
  wire ram0_reg_12;
  wire ram0_reg_13;
  wire ram0_reg_14;
  wire ram0_reg_15;
  wire ram0_reg_16;
  wire ram0_reg_17;
  wire ram0_reg_18;
  wire ram0_reg_19;
  wire ram0_reg_2;
  wire ram0_reg_20;
  wire ram0_reg_21;
  wire ram0_reg_22;
  wire ram0_reg_23;
  wire [7:0]ram0_reg_24;
  wire ram0_reg_25;
  wire ram0_reg_26;
  wire ram0_reg_27;
  wire ram0_reg_28;
  wire ram0_reg_29;
  wire ram0_reg_3;
  wire ram0_reg_30;
  wire ram0_reg_31;
  wire ram0_reg_32;
  wire ram0_reg_33;
  wire [5:0]ram0_reg_4;
  wire ram0_reg_5;
  wire [39:0]ram0_reg_6;
  wire ram0_reg_7;
  wire ram0_reg_8;
  wire ram0_reg_9;
  wire ram0_reg_i_100_n_0;
  wire ram0_reg_i_107_n_0;
  wire [2:0]ram0_reg_i_108_0;
  wire [5:0]ram0_reg_i_108_1;
  wire ram0_reg_i_109_n_0;
  wire ram0_reg_i_10__0_n_0;
  wire ram0_reg_i_111_n_0;
  wire ram0_reg_i_11__0_n_0;
  wire ram0_reg_i_123_n_0;
  wire ram0_reg_i_124_n_0;
  wire ram0_reg_i_126_n_0;
  wire ram0_reg_i_127_n_0;
  wire ram0_reg_i_12__0_n_0;
  wire ram0_reg_i_131_0;
  wire ram0_reg_i_131_n_0;
  wire ram0_reg_i_132_n_0;
  wire ram0_reg_i_135_n_0;
  wire ram0_reg_i_14__0_n_0;
  wire ram0_reg_i_152_n_0;
  wire ram0_reg_i_153_n_0;
  wire ram0_reg_i_154_n_0;
  wire ram0_reg_i_157_n_0;
  wire ram0_reg_i_160_n_0;
  wire ram0_reg_i_161_n_0;
  wire [10:0]ram0_reg_i_23__0_0;
  wire [6:0]ram0_reg_i_23__0_1;
  wire [4:0]ram0_reg_i_23__0_2;
  wire ram0_reg_i_23__0_n_0;
  wire ram0_reg_i_24_n_0;
  wire ram0_reg_i_25__0_n_0;
  wire ram0_reg_i_26__0_n_0;
  wire ram0_reg_i_27__0_n_0;
  wire ram0_reg_i_28_n_0;
  wire ram0_reg_i_29__0_n_0;
  wire ram0_reg_i_2__0_n_0;
  wire ram0_reg_i_30_n_0;
  wire ram0_reg_i_31_n_0;
  wire ram0_reg_i_32;
  wire ram0_reg_i_32_0;
  wire ram0_reg_i_32__0_n_0;
  wire ram0_reg_i_33__0_n_0;
  wire ram0_reg_i_34__0_n_0;
  wire ram0_reg_i_35__0_n_0;
  wire ram0_reg_i_37_n_0;
  wire ram0_reg_i_38__0_n_0;
  wire ram0_reg_i_39__0_n_0;
  wire ram0_reg_i_3__0_n_0;
  wire ram0_reg_i_49_0;
  wire ram0_reg_i_4__0_n_0;
  wire ram0_reg_i_53;
  wire ram0_reg_i_54;
  wire ram0_reg_i_54_0;
  wire ram0_reg_i_54_1;
  wire ram0_reg_i_54_2;
  wire ram0_reg_i_5__0_n_0;
  wire ram0_reg_i_62_0;
  wire ram0_reg_i_62_1;
  wire ram0_reg_i_63_0;
  wire ram0_reg_i_63_1;
  wire ram0_reg_i_63_2;
  wire ram0_reg_i_66_0;
  wire ram0_reg_i_66_1;
  wire ram0_reg_i_66_2;
  wire ram0_reg_i_66_3;
  wire ram0_reg_i_6__0_n_0;
  wire ram0_reg_i_72_n_0;
  wire ram0_reg_i_73_n_0;
  wire ram0_reg_i_7__0_n_0;
  wire ram0_reg_i_81_n_0;
  wire ram0_reg_i_83_n_0;
  wire ram0_reg_i_84_n_0;
  wire ram0_reg_i_85_n_0;
  wire ram0_reg_i_86_n_0;
  wire ram0_reg_i_88_n_0;
  wire ram0_reg_i_8__0_n_0;
  wire ram0_reg_i_92_n_0;
  wire ram0_reg_i_93_n_0;
  wire ram0_reg_i_96_n_0;
  wire ram0_reg_i_98_n_0;
  wire ram0_reg_i_99_n_0;
  wire ram0_reg_i_9_n_0;
  wire ram_reg_i_373__0;
  wire esc_y_2_reg_2385_reg_3_172fc4c ;
  wire esc_y_2_reg_2385_reg_3__0_c63e66d ;
  wire [4:0]esc_y_2_reg_2385_reg_4_1138322 ;
  wire [4:0]esc_y_2_reg_2385_reg_4__0_25a3d14 ;
  wire y_reg_22970;
  wire esc_y_reg_2297_reg_0_8039ace ;
  wire [13:0]zext_ln208_87_fu_5779_p1;
  wire [1:0]zext_ln74_2_fu_2977_p1;
  wire [3:0]esc_NLW_add_ln208_102_reg_8173_reg_11__i_1_CO_UNCONNECTED_b61806c ;
  wire [3:0]esc_NLW_add_ln208_102_reg_8173_reg_3__i_1_CO_UNCONNECTED_5db2002 ;
  wire [3:0]esc_NLW_add_ln208_102_reg_8173_reg_7__i_1_CO_UNCONNECTED_639facc ;
  wire [3:0]esc_NLW_add_ln208_105_reg_8205_reg_11__i_1_CO_UNCONNECTED_6ba5f1f ;
  wire [3:0]esc_NLW_add_ln208_105_reg_8205_reg_3__i_1_CO_UNCONNECTED_ed859ba ;
  wire [3:0]esc_NLW_add_ln208_105_reg_8205_reg_7__i_1_CO_UNCONNECTED_115d3fd ;
  wire [3:0]esc_NLW_add_ln208_108_reg_8237_reg_11__i_1_CO_UNCONNECTED_b944c90 ;
  wire [3:0]esc_NLW_add_ln208_108_reg_8237_reg_3__i_1_CO_UNCONNECTED_3a0bd33 ;
  wire [3:0]esc_NLW_add_ln208_108_reg_8237_reg_7__i_1_CO_UNCONNECTED_168c511 ;
  wire [3:0]esc_NLW_add_ln208_111_reg_8269_reg_11__i_1_CO_UNCONNECTED_30be0d0 ;
  wire [3:0]esc_NLW_add_ln208_111_reg_8269_reg_3__i_1_CO_UNCONNECTED_c7833f2 ;
  wire [3:0]esc_NLW_add_ln208_111_reg_8269_reg_7__i_1_CO_UNCONNECTED_e84881f ;
  wire [3:0]esc_NLW_add_ln208_114_reg_8301_reg_11__i_1_CO_UNCONNECTED_fe919a8 ;
  wire [3:0]esc_NLW_add_ln208_114_reg_8301_reg_3__i_1_CO_UNCONNECTED_7adcb57 ;
  wire [3:0]esc_NLW_add_ln208_114_reg_8301_reg_7__i_1_CO_UNCONNECTED_dcfe1af ;
  wire [3:0]esc_NLW_add_ln208_117_reg_8333_reg_11__i_1_CO_UNCONNECTED_ea8afb7 ;
  wire [3:0]esc_NLW_add_ln208_117_reg_8333_reg_3__i_1_CO_UNCONNECTED_80a2d7e ;
  wire [3:0]esc_NLW_add_ln208_117_reg_8333_reg_7__i_1_CO_UNCONNECTED_c2724a1 ;
  wire [3:0]esc_NLW_add_ln208_120_reg_8365_reg_11__i_1_CO_UNCONNECTED_345b1cc ;
  wire [3:0]esc_NLW_add_ln208_120_reg_8365_reg_3__i_1_CO_UNCONNECTED_64f2693 ;
  wire [3:0]esc_NLW_add_ln208_120_reg_8365_reg_7__i_1_CO_UNCONNECTED_80cd018 ;
  wire [3:0]esc_NLW_add_ln208_123_reg_8397_reg_11__i_1_CO_UNCONNECTED_3c998bc ;
  wire [3:0]esc_NLW_add_ln208_123_reg_8397_reg_3__i_1_CO_UNCONNECTED_f5674c8 ;
  wire [3:0]esc_NLW_add_ln208_123_reg_8397_reg_7__i_1_CO_UNCONNECTED_a740cd9 ;
  wire [3:0]esc_NLW_add_ln208_126_reg_8429_reg_11__i_1_CO_UNCONNECTED_99cfc91 ;
  wire [3:0]esc_NLW_add_ln208_126_reg_8429_reg_3__i_1_CO_UNCONNECTED_7b2ce87 ;
  wire [3:0]esc_NLW_add_ln208_126_reg_8429_reg_7__i_1_CO_UNCONNECTED_9dcb955 ;
  wire [3:0]esc_NLW_add_ln208_129_reg_8461_reg_11__i_1_CO_UNCONNECTED_8b1937b ;
  wire [3:0]esc_NLW_add_ln208_129_reg_8461_reg_3__i_1_CO_UNCONNECTED_a8db01d ;
  wire [3:0]esc_NLW_add_ln208_129_reg_8461_reg_7__i_1_CO_UNCONNECTED_3fbe12e ;
  wire [3:0]esc_NLW_add_ln208_132_reg_8493_reg_11__i_1_CO_UNCONNECTED_41d00d3 ;
  wire [3:0]esc_NLW_add_ln208_132_reg_8493_reg_3__i_1_CO_UNCONNECTED_61d18af ;
  wire [3:0]esc_NLW_add_ln208_132_reg_8493_reg_7__i_1_CO_UNCONNECTED_bdcfd20 ;
  wire [3:0]esc_NLW_add_ln208_135_reg_8525_reg_11__i_1_CO_UNCONNECTED_f80f88b ;
  wire [3:0]esc_NLW_add_ln208_135_reg_8525_reg_13__i_1_CO_UNCONNECTED_99904a1 ;
  wire [3:0]esc_NLW_add_ln208_135_reg_8525_reg_3__i_1_CO_UNCONNECTED_78d520a ;
  wire [3:0]esc_NLW_add_ln208_135_reg_8525_reg_7__i_1_CO_UNCONNECTED_c9cf2f7 ;
  wire [3:0]esc_NLW_add_ln208_138_reg_8557_reg_11__i_1_CO_UNCONNECTED_9545c13 ;
  wire [3:0]esc_NLW_add_ln208_138_reg_8557_reg_3__i_1_CO_UNCONNECTED_1104100 ;
  wire [3:0]esc_NLW_add_ln208_138_reg_8557_reg_7__i_1_CO_UNCONNECTED_d60f5ba ;
  wire [3:0]esc_NLW_add_ln208_141_reg_8589_reg_11__i_1_CO_UNCONNECTED_6c4fea3 ;
  wire [3:0]esc_NLW_add_ln208_141_reg_8589_reg_3__i_1_CO_UNCONNECTED_d9cdde8 ;
  wire [3:0]esc_NLW_add_ln208_141_reg_8589_reg_7__i_1_CO_UNCONNECTED_305ac38 ;
  wire [3:0]esc_NLW_add_ln208_144_reg_8621_reg_11__i_1_CO_UNCONNECTED_16fc79d ;
  wire [3:0]esc_NLW_add_ln208_144_reg_8621_reg_3__i_1_CO_UNCONNECTED_fb02f91 ;
  wire [3:0]esc_NLW_add_ln208_144_reg_8621_reg_7__i_1_CO_UNCONNECTED_5937d68 ;
  wire [3:0]esc_NLW_add_ln208_147_reg_8653_reg_11__i_1_CO_UNCONNECTED_d4236d9 ;
  wire [3:0]esc_NLW_add_ln208_147_reg_8653_reg_3__i_1_CO_UNCONNECTED_6317f52 ;
  wire [3:0]esc_NLW_add_ln208_147_reg_8653_reg_7__i_1_CO_UNCONNECTED_9ef8391 ;
  wire [3:0]esc_NLW_add_ln208_150_reg_8685_reg_11__i_1_CO_UNCONNECTED_23c9537 ;
  wire [3:0]esc_NLW_add_ln208_150_reg_8685_reg_3__i_1_CO_UNCONNECTED_a46009e ;
  wire [3:0]esc_NLW_add_ln208_150_reg_8685_reg_7__i_1_CO_UNCONNECTED_b059143 ;
  wire [3:0]esc_NLW_add_ln208_153_reg_8717_reg_11__i_1_CO_UNCONNECTED_3834129 ;
  wire [3:0]esc_NLW_add_ln208_153_reg_8717_reg_3__i_1_CO_UNCONNECTED_494f1cd ;
  wire [3:0]esc_NLW_add_ln208_153_reg_8717_reg_7__i_1_CO_UNCONNECTED_fa5a1ea ;
  wire [3:0]esc_NLW_add_ln208_157_reg_8733_reg_11__i_2_CO_UNCONNECTED_99d723b ;
  wire [3:0]esc_NLW_add_ln208_157_reg_8733_reg_3__i_2_CO_UNCONNECTED_6b09c41 ;
  wire [3:0]esc_NLW_add_ln208_157_reg_8733_reg_7__i_2_CO_UNCONNECTED_aa77053 ;
  wire [3:0]esc_NLW_add_ln208_42_reg_7073_reg_3__i_1_CO_UNCONNECTED_2893d96 ;
  wire [3:0]esc_NLW_add_ln208_42_reg_7073_reg_7__i_1_CO_UNCONNECTED_e586fbf ;
  wire [3:0]esc_NLW_add_ln208_45_reg_7125_reg_3__i_1_CO_UNCONNECTED_0b863a0 ;
  wire [3:0]esc_NLW_add_ln208_45_reg_7125_reg_7__i_1_CO_UNCONNECTED_598fbdc ;
  wire [3:0]esc_NLW_add_ln208_45_reg_7125_reg_9__i_1_CO_UNCONNECTED_9eb3970 ;
  wire [3:0]esc_NLW_add_ln208_48_reg_7177_reg_3__i_1_CO_UNCONNECTED_53c59d1 ;
  wire [3:0]esc_NLW_add_ln208_48_reg_7177_reg_7__i_1_CO_UNCONNECTED_a414955 ;
  wire [3:0]esc_NLW_add_ln208_51_reg_7229_reg_10__i_1_CO_UNCONNECTED_ddf3e97 ;
  wire [3:0]esc_NLW_add_ln208_51_reg_7229_reg_3__i_1_CO_UNCONNECTED_e2160b3 ;
  wire [3:0]esc_NLW_add_ln208_51_reg_7229_reg_7__i_1_CO_UNCONNECTED_9fbbfa8 ;
  wire [3:0]esc_NLW_add_ln208_54_reg_7281_reg_3__i_1_CO_UNCONNECTED_2bf697f ;
  wire [3:0]esc_NLW_add_ln208_54_reg_7281_reg_7__i_1_CO_UNCONNECTED_7791604 ;
  wire [3:0]esc_NLW_add_ln208_57_reg_7333_reg_3__i_1_CO_UNCONNECTED_273e648 ;
  wire [3:0]esc_NLW_add_ln208_57_reg_7333_reg_7__i_1_CO_UNCONNECTED_fa273cf ;
  wire [3:0]esc_NLW_add_ln208_60_reg_7385_reg_3__i_1_CO_UNCONNECTED_b0fb7ff ;
  wire [3:0]esc_NLW_add_ln208_60_reg_7385_reg_7__i_1_CO_UNCONNECTED_cef90be ;
  wire [3:0]esc_NLW_add_ln208_63_reg_7437_reg_11__i_1_CO_UNCONNECTED_c6b0aab ;
  wire [3:0]esc_NLW_add_ln208_63_reg_7437_reg_3__i_1_CO_UNCONNECTED_037d0a7 ;
  wire [3:0]esc_NLW_add_ln208_63_reg_7437_reg_7__i_1_CO_UNCONNECTED_ee902fc ;
  wire [3:0]esc_NLW_add_ln208_66_reg_7489_reg_3__i_1_CO_UNCONNECTED_f27a538 ;
  wire [3:0]esc_NLW_add_ln208_66_reg_7489_reg_7__i_1_CO_UNCONNECTED_4e9cf72 ;
  wire [3:0]esc_NLW_add_ln208_69_reg_7541_reg_3__i_1_CO_UNCONNECTED_4367aba ;
  wire [3:0]esc_NLW_add_ln208_69_reg_7541_reg_7__i_1_CO_UNCONNECTED_c4e46d9 ;
  wire [3:0]esc_NLW_add_ln208_72_reg_7593_reg_3__i_1_CO_UNCONNECTED_eba40b0 ;
  wire [3:0]esc_NLW_add_ln208_72_reg_7593_reg_7__i_1_CO_UNCONNECTED_1b6b98d ;
  wire [3:0]esc_NLW_add_ln208_75_reg_7655_reg_3__i_1_CO_UNCONNECTED_45618a3 ;
  wire [3:0]esc_NLW_add_ln208_75_reg_7655_reg_7__i_1_CO_UNCONNECTED_f46de21 ;
  wire [3:0]esc_NLW_add_ln208_78_reg_7717_reg_3__i_1_CO_UNCONNECTED_a41eeb1 ;
  wire [3:0]esc_NLW_add_ln208_78_reg_7717_reg_7__i_1_CO_UNCONNECTED_1357d56 ;
  wire [3:0]esc_NLW_add_ln208_81_reg_7779_reg_3__i_1_CO_UNCONNECTED_a553593 ;
  wire [3:0]esc_NLW_add_ln208_81_reg_7779_reg_7__i_1_CO_UNCONNECTED_9825c22 ;
  wire [3:0]esc_NLW_add_ln208_84_reg_7841_reg_3__i_1_CO_UNCONNECTED_307b20f ;
  wire [3:0]esc_NLW_add_ln208_84_reg_7841_reg_7__i_1_CO_UNCONNECTED_da47d04 ;
  wire [3:0]esc_NLW_add_ln208_87_reg_7903_reg_11__i_1_CO_UNCONNECTED_7270aa1 ;
  wire [3:0]esc_NLW_add_ln208_87_reg_7903_reg_3__i_1_CO_UNCONNECTED_4d76354 ;
  wire [3:0]esc_NLW_add_ln208_87_reg_7903_reg_7__i_1_CO_UNCONNECTED_174dab5 ;
  wire [3:0]esc_NLW_add_ln208_90_reg_7965_reg_11__i_1_CO_UNCONNECTED_64db9cf ;
  wire [3:0]esc_NLW_add_ln208_90_reg_7965_reg_3__i_1_CO_UNCONNECTED_cc0073d ;
  wire [3:0]esc_NLW_add_ln208_90_reg_7965_reg_7__i_1_CO_UNCONNECTED_c7c8416 ;
  wire [3:0]esc_NLW_add_ln208_93_reg_8027_reg_11__i_1_CO_UNCONNECTED_081f578 ;
  wire [3:0]esc_NLW_add_ln208_93_reg_8027_reg_3__i_1_CO_UNCONNECTED_0bdb964 ;
  wire [3:0]esc_NLW_add_ln208_93_reg_8027_reg_7__i_1_CO_UNCONNECTED_2477b36 ;
  wire [3:0]esc_NLW_add_ln208_96_reg_8089_reg_11__i_1_CO_UNCONNECTED_2ea4a37 ;
  wire [3:0]esc_NLW_add_ln208_96_reg_8089_reg_3__i_1_CO_UNCONNECTED_cb9bff0 ;
  wire [3:0]esc_NLW_add_ln208_96_reg_8089_reg_7__i_1_CO_UNCONNECTED_efb9c12 ;
  wire [3:0]esc_NLW_add_ln208_99_reg_8131_reg_11__i_1_CO_UNCONNECTED_02acc8a ;
  wire [3:0]esc_NLW_add_ln208_99_reg_8131_reg_3__i_1_CO_UNCONNECTED_636af47 ;
  wire [3:0]esc_NLW_add_ln208_99_reg_8131_reg_7__i_1_CO_UNCONNECTED_239213a ;
  wire [3:0]NLW_ram0_reg_i_108_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed GND: GND_1
  assign GND_2 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT2: esc_add_ln208_102_reg_8173_3__i_2_a14a251
  assign esc_add_ln208_102_reg_8173_3__i_2_n_0_b7342b8 = ((DOADO[3]) ? (~(esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [3])) : (esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [3]));

  // Reconstructed LUT2: esc_add_ln208_102_reg_8173_3__i_3_69a9121
  assign esc_add_ln208_102_reg_8173_3__i_3_n_0_f901c72 = ((DOADO[2]) ? (~(esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [2])) : (esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [2]));

  // Reconstructed LUT2: esc_add_ln208_102_reg_8173_3__i_4_50972d3
  assign esc_add_ln208_102_reg_8173_3__i_4_n_0_78f6028 = ((DOADO[1]) ? (~(esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [1])) : (esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [1]));

  // Reconstructed LUT2: esc_add_ln208_102_reg_8173_3__i_5_5955904
  assign esc_add_ln208_102_reg_8173_3__i_5_n_0_a3259ab = ((DOADO[0]) ? (~(esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [0])) : (esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [0]));

  // Reconstructed LUT2: esc_add_ln208_102_reg_8173_7__i_2_45d0724
  assign esc_add_ln208_102_reg_8173_7__i_2_n_0_d913391 = ((DOADO[7]) ? (~(esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [7])) : (esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [7]));

  // Reconstructed LUT2: esc_add_ln208_102_reg_8173_7__i_3_504198a
  assign esc_add_ln208_102_reg_8173_7__i_3_n_0_809c38a = ((DOADO[6]) ? (~(esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [6])) : (esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [6]));

  // Reconstructed LUT2: esc_add_ln208_102_reg_8173_7__i_4_a22a00e
  assign esc_add_ln208_102_reg_8173_7__i_4_n_0_4101a58 = ((DOADO[5]) ? (~(esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [5])) : (esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [5]));

  // Reconstructed LUT2: esc_add_ln208_102_reg_8173_7__i_5_5418f49
  assign esc_add_ln208_102_reg_8173_7__i_5_n_0_5e4cff2 = ((DOADO[4]) ? (~(esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [4])) : (esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [4]));

  // Reconstructed CARRY4: esc_add_ln208_102_reg_8173_reg_11__i_1_15182c2
  wire [3:0] recovered_12_co, recovered_12_o, recovered_12_s, recovered_12_di;
  assign recovered_12_s = esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [11:8];
  assign recovered_12_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_12_ci = ((esc_add_ln208_102_reg_8173_reg_7__i_1_n_0_a010009) !== 1'bz) && (esc_add_ln208_102_reg_8173_reg_7__i_1_n_0_a010009);
  wire recovered_12_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_12_o[0] = recovered_12_s[0] ^ (recovered_12_ci || recovered_12_cy);
  assign recovered_12_co[0] = (recovered_12_s[0] & (recovered_12_ci || recovered_12_cy)) | (~recovered_12_s[0] & recovered_12_di[0]);
  assign recovered_12_o[1] = recovered_12_s[1] ^ recovered_12_co[0];
  assign recovered_12_co[1] = (recovered_12_s[1] & recovered_12_co[0]) | (~recovered_12_s[1] & recovered_12_di[1]);
  assign recovered_12_o[2] = recovered_12_s[2] ^ recovered_12_co[1];
  assign recovered_12_co[2] = (recovered_12_s[2] & recovered_12_co[1]) | (~recovered_12_s[2] & recovered_12_di[2]);
  assign recovered_12_o[3] = recovered_12_s[3] ^ recovered_12_co[2];
  assign recovered_12_co[3] = (recovered_12_s[3] & recovered_12_co[2]) | (~recovered_12_s[3] & recovered_12_di[3]);
  assign {esc_add_ln208_102_reg_8173_reg_11__i_1_n_0_ceab219 ,esc_NLW_add_ln208_102_reg_8173_reg_11__i_1_CO_UNCONNECTED_b61806c [2:0]} = recovered_12_co;
  assign esc_add_ln208_99_reg_8131_reg_12_287a134 [11:8] = recovered_12_o;

  // Reconstructed CARRY4: esc_add_ln208_102_reg_8173_reg_12__i_1_a06899c
  wire [3:0] recovered_13_co, recovered_13_o, recovered_13_s, recovered_13_di;
  assign recovered_13_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [12]};
  assign recovered_13_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_13_ci = ((esc_add_ln208_102_reg_8173_reg_11__i_1_n_0_ceab219) !== 1'bz) && (esc_add_ln208_102_reg_8173_reg_11__i_1_n_0_ceab219);
  wire recovered_13_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_13_o[0] = recovered_13_s[0] ^ (recovered_13_ci || recovered_13_cy);
  assign recovered_13_co[0] = (recovered_13_s[0] & (recovered_13_ci || recovered_13_cy)) | (~recovered_13_s[0] & recovered_13_di[0]);
  assign recovered_13_o[1] = recovered_13_s[1] ^ recovered_13_co[0];
  assign recovered_13_co[1] = (recovered_13_s[1] & recovered_13_co[0]) | (~recovered_13_s[1] & recovered_13_di[1]);
  assign recovered_13_o[2] = recovered_13_s[2] ^ recovered_13_co[1];
  assign recovered_13_co[2] = (recovered_13_s[2] & recovered_13_co[1]) | (~recovered_13_s[2] & recovered_13_di[2]);
  assign recovered_13_o[3] = recovered_13_s[3] ^ recovered_13_co[2];
  assign recovered_13_co[3] = (recovered_13_s[3] & recovered_13_co[2]) | (~recovered_13_s[3] & recovered_13_di[3]);
  assign esc_add_ln208_99_reg_8131_reg_12_287a134 [12] = recovered_13_o;

  // Reconstructed CARRY4: esc_add_ln208_102_reg_8173_reg_3__i_1_74a6dda
  wire [3:0] recovered_14_co, recovered_14_o, recovered_14_s, recovered_14_di;
  assign recovered_14_s = {esc_add_ln208_102_reg_8173_3__i_2_n_0_b7342b8 ,esc_add_ln208_102_reg_8173_3__i_3_n_0_f901c72 ,esc_add_ln208_102_reg_8173_3__i_4_n_0_78f6028 ,esc_add_ln208_102_reg_8173_3__i_5_n_0_a3259ab };
  assign recovered_14_di = esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [3:0];
  wire recovered_14_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_14_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_14_o[0] = recovered_14_s[0] ^ (recovered_14_ci || recovered_14_cy);
  assign recovered_14_co[0] = (recovered_14_s[0] & (recovered_14_ci || recovered_14_cy)) | (~recovered_14_s[0] & recovered_14_di[0]);
  assign recovered_14_o[1] = recovered_14_s[1] ^ recovered_14_co[0];
  assign recovered_14_co[1] = (recovered_14_s[1] & recovered_14_co[0]) | (~recovered_14_s[1] & recovered_14_di[1]);
  assign recovered_14_o[2] = recovered_14_s[2] ^ recovered_14_co[1];
  assign recovered_14_co[2] = (recovered_14_s[2] & recovered_14_co[1]) | (~recovered_14_s[2] & recovered_14_di[2]);
  assign recovered_14_o[3] = recovered_14_s[3] ^ recovered_14_co[2];
  assign recovered_14_co[3] = (recovered_14_s[3] & recovered_14_co[2]) | (~recovered_14_s[3] & recovered_14_di[3]);
  assign {esc_add_ln208_102_reg_8173_reg_3__i_1_n_0_0df6d63 ,esc_NLW_add_ln208_102_reg_8173_reg_3__i_1_CO_UNCONNECTED_5db2002 [2:0]} = recovered_14_co;
  assign esc_add_ln208_99_reg_8131_reg_12_287a134 [3:0] = recovered_14_o;

  // Reconstructed CARRY4: esc_add_ln208_102_reg_8173_reg_7__i_1_816d072
  wire [3:0] recovered_15_co, recovered_15_o, recovered_15_s, recovered_15_di;
  assign recovered_15_s = {esc_add_ln208_102_reg_8173_7__i_2_n_0_d913391 ,esc_add_ln208_102_reg_8173_7__i_3_n_0_809c38a ,esc_add_ln208_102_reg_8173_7__i_4_n_0_4101a58 ,esc_add_ln208_102_reg_8173_7__i_5_n_0_5e4cff2 };
  assign recovered_15_di = esc_add_ln208_102_reg_8173_reg_12__0_a64db1c [7:4];
  wire recovered_15_ci = ((esc_add_ln208_102_reg_8173_reg_3__i_1_n_0_0df6d63) !== 1'bz) && (esc_add_ln208_102_reg_8173_reg_3__i_1_n_0_0df6d63);
  wire recovered_15_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_15_o[0] = recovered_15_s[0] ^ (recovered_15_ci || recovered_15_cy);
  assign recovered_15_co[0] = (recovered_15_s[0] & (recovered_15_ci || recovered_15_cy)) | (~recovered_15_s[0] & recovered_15_di[0]);
  assign recovered_15_o[1] = recovered_15_s[1] ^ recovered_15_co[0];
  assign recovered_15_co[1] = (recovered_15_s[1] & recovered_15_co[0]) | (~recovered_15_s[1] & recovered_15_di[1]);
  assign recovered_15_o[2] = recovered_15_s[2] ^ recovered_15_co[1];
  assign recovered_15_co[2] = (recovered_15_s[2] & recovered_15_co[1]) | (~recovered_15_s[2] & recovered_15_di[2]);
  assign recovered_15_o[3] = recovered_15_s[3] ^ recovered_15_co[2];
  assign recovered_15_co[3] = (recovered_15_s[3] & recovered_15_co[2]) | (~recovered_15_s[3] & recovered_15_di[3]);
  assign {esc_add_ln208_102_reg_8173_reg_7__i_1_n_0_a010009 ,esc_NLW_add_ln208_102_reg_8173_reg_7__i_1_CO_UNCONNECTED_639facc [2:0]} = recovered_15_co;
  assign esc_add_ln208_99_reg_8131_reg_12_287a134 [7:4] = recovered_15_o;

  // Reconstructed LUT2: esc_add_ln208_105_reg_8205_3__i_2_4b50746
  assign esc_add_ln208_105_reg_8205_3__i_2_n_0_ecb0dcf = ((DOADO[3]) ? (~(esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [3])) : (esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [3]));

  // Reconstructed LUT2: esc_add_ln208_105_reg_8205_3__i_3_d3acc73
  assign esc_add_ln208_105_reg_8205_3__i_3_n_0_3d7f23c = ((DOADO[2]) ? (~(esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [2])) : (esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [2]));

  // Reconstructed LUT2: esc_add_ln208_105_reg_8205_3__i_4_c2bb50a
  assign esc_add_ln208_105_reg_8205_3__i_4_n_0_69bdfbf = ((DOADO[1]) ? (~(esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [1])) : (esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [1]));

  // Reconstructed LUT2: esc_add_ln208_105_reg_8205_3__i_5_f2d0efb
  assign esc_add_ln208_105_reg_8205_3__i_5_n_0_e364dd2 = ((DOADO[0]) ? (~(esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [0])) : (esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [0]));

  // Reconstructed LUT2: esc_add_ln208_105_reg_8205_7__i_2_b046d06
  assign esc_add_ln208_105_reg_8205_7__i_2_n_0_3d5702b = ((DOADO[7]) ? (~(esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [7])) : (esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [7]));

  // Reconstructed LUT2: esc_add_ln208_105_reg_8205_7__i_3_eedb313
  assign esc_add_ln208_105_reg_8205_7__i_3_n_0_d53c802 = ((DOADO[6]) ? (~(esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [6])) : (esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [6]));

  // Reconstructed LUT2: esc_add_ln208_105_reg_8205_7__i_4_341b6e2
  assign esc_add_ln208_105_reg_8205_7__i_4_n_0_efe3bfb = ((DOADO[5]) ? (~(esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [5])) : (esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [5]));

  // Reconstructed LUT2: esc_add_ln208_105_reg_8205_7__i_5_73cfb07
  assign esc_add_ln208_105_reg_8205_7__i_5_n_0_ab01214 = ((DOADO[4]) ? (~(esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [4])) : (esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [4]));

  // Reconstructed CARRY4: esc_add_ln208_105_reg_8205_reg_11__i_1_fd6ba9e
  wire [3:0] recovered_24_co, recovered_24_o, recovered_24_s, recovered_24_di;
  assign recovered_24_s = esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [11:8];
  assign recovered_24_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_24_ci = ((esc_add_ln208_105_reg_8205_reg_7__i_1_n_0_11af300) !== 1'bz) && (esc_add_ln208_105_reg_8205_reg_7__i_1_n_0_11af300);
  wire recovered_24_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_24_o[0] = recovered_24_s[0] ^ (recovered_24_ci || recovered_24_cy);
  assign recovered_24_co[0] = (recovered_24_s[0] & (recovered_24_ci || recovered_24_cy)) | (~recovered_24_s[0] & recovered_24_di[0]);
  assign recovered_24_o[1] = recovered_24_s[1] ^ recovered_24_co[0];
  assign recovered_24_co[1] = (recovered_24_s[1] & recovered_24_co[0]) | (~recovered_24_s[1] & recovered_24_di[1]);
  assign recovered_24_o[2] = recovered_24_s[2] ^ recovered_24_co[1];
  assign recovered_24_co[2] = (recovered_24_s[2] & recovered_24_co[1]) | (~recovered_24_s[2] & recovered_24_di[2]);
  assign recovered_24_o[3] = recovered_24_s[3] ^ recovered_24_co[2];
  assign recovered_24_co[3] = (recovered_24_s[3] & recovered_24_co[2]) | (~recovered_24_s[3] & recovered_24_di[3]);
  assign {esc_add_ln208_105_reg_8205_reg_11__i_1_n_0_1ca6d32 ,esc_NLW_add_ln208_105_reg_8205_reg_11__i_1_CO_UNCONNECTED_6ba5f1f [2:0]} = recovered_24_co;
  assign esc_add_ln208_102_reg_8173_reg_12_c8013a3 [11:8] = recovered_24_o;

  // Reconstructed CARRY4: esc_add_ln208_105_reg_8205_reg_12__i_1_0f81afc
  wire [3:0] recovered_25_co, recovered_25_o, recovered_25_s, recovered_25_di;
  assign recovered_25_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [12]};
  assign recovered_25_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_25_ci = ((esc_add_ln208_105_reg_8205_reg_11__i_1_n_0_1ca6d32) !== 1'bz) && (esc_add_ln208_105_reg_8205_reg_11__i_1_n_0_1ca6d32);
  wire recovered_25_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_25_o[0] = recovered_25_s[0] ^ (recovered_25_ci || recovered_25_cy);
  assign recovered_25_co[0] = (recovered_25_s[0] & (recovered_25_ci || recovered_25_cy)) | (~recovered_25_s[0] & recovered_25_di[0]);
  assign recovered_25_o[1] = recovered_25_s[1] ^ recovered_25_co[0];
  assign recovered_25_co[1] = (recovered_25_s[1] & recovered_25_co[0]) | (~recovered_25_s[1] & recovered_25_di[1]);
  assign recovered_25_o[2] = recovered_25_s[2] ^ recovered_25_co[1];
  assign recovered_25_co[2] = (recovered_25_s[2] & recovered_25_co[1]) | (~recovered_25_s[2] & recovered_25_di[2]);
  assign recovered_25_o[3] = recovered_25_s[3] ^ recovered_25_co[2];
  assign recovered_25_co[3] = (recovered_25_s[3] & recovered_25_co[2]) | (~recovered_25_s[3] & recovered_25_di[3]);
  assign esc_add_ln208_102_reg_8173_reg_12_c8013a3 [12] = recovered_25_o;

  // Reconstructed CARRY4: esc_add_ln208_105_reg_8205_reg_3__i_1_f7e8ae1
  wire [3:0] recovered_26_co, recovered_26_o, recovered_26_s, recovered_26_di;
  assign recovered_26_s = {esc_add_ln208_105_reg_8205_3__i_2_n_0_ecb0dcf ,esc_add_ln208_105_reg_8205_3__i_3_n_0_3d7f23c ,esc_add_ln208_105_reg_8205_3__i_4_n_0_69bdfbf ,esc_add_ln208_105_reg_8205_3__i_5_n_0_e364dd2 };
  assign recovered_26_di = esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [3:0];
  wire recovered_26_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_26_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_26_o[0] = recovered_26_s[0] ^ (recovered_26_ci || recovered_26_cy);
  assign recovered_26_co[0] = (recovered_26_s[0] & (recovered_26_ci || recovered_26_cy)) | (~recovered_26_s[0] & recovered_26_di[0]);
  assign recovered_26_o[1] = recovered_26_s[1] ^ recovered_26_co[0];
  assign recovered_26_co[1] = (recovered_26_s[1] & recovered_26_co[0]) | (~recovered_26_s[1] & recovered_26_di[1]);
  assign recovered_26_o[2] = recovered_26_s[2] ^ recovered_26_co[1];
  assign recovered_26_co[2] = (recovered_26_s[2] & recovered_26_co[1]) | (~recovered_26_s[2] & recovered_26_di[2]);
  assign recovered_26_o[3] = recovered_26_s[3] ^ recovered_26_co[2];
  assign recovered_26_co[3] = (recovered_26_s[3] & recovered_26_co[2]) | (~recovered_26_s[3] & recovered_26_di[3]);
  assign {esc_add_ln208_105_reg_8205_reg_3__i_1_n_0_09668d6 ,esc_NLW_add_ln208_105_reg_8205_reg_3__i_1_CO_UNCONNECTED_ed859ba [2:0]} = recovered_26_co;
  assign esc_add_ln208_102_reg_8173_reg_12_c8013a3 [3:0] = recovered_26_o;

  // Reconstructed CARRY4: esc_add_ln208_105_reg_8205_reg_7__i_1_f9752cc
  wire [3:0] recovered_27_co, recovered_27_o, recovered_27_s, recovered_27_di;
  assign recovered_27_s = {esc_add_ln208_105_reg_8205_7__i_2_n_0_3d5702b ,esc_add_ln208_105_reg_8205_7__i_3_n_0_d53c802 ,esc_add_ln208_105_reg_8205_7__i_4_n_0_efe3bfb ,esc_add_ln208_105_reg_8205_7__i_5_n_0_ab01214 };
  assign recovered_27_di = esc_add_ln208_105_reg_8205_reg_12__0_1875a9f [7:4];
  wire recovered_27_ci = ((esc_add_ln208_105_reg_8205_reg_3__i_1_n_0_09668d6) !== 1'bz) && (esc_add_ln208_105_reg_8205_reg_3__i_1_n_0_09668d6);
  wire recovered_27_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_27_o[0] = recovered_27_s[0] ^ (recovered_27_ci || recovered_27_cy);
  assign recovered_27_co[0] = (recovered_27_s[0] & (recovered_27_ci || recovered_27_cy)) | (~recovered_27_s[0] & recovered_27_di[0]);
  assign recovered_27_o[1] = recovered_27_s[1] ^ recovered_27_co[0];
  assign recovered_27_co[1] = (recovered_27_s[1] & recovered_27_co[0]) | (~recovered_27_s[1] & recovered_27_di[1]);
  assign recovered_27_o[2] = recovered_27_s[2] ^ recovered_27_co[1];
  assign recovered_27_co[2] = (recovered_27_s[2] & recovered_27_co[1]) | (~recovered_27_s[2] & recovered_27_di[2]);
  assign recovered_27_o[3] = recovered_27_s[3] ^ recovered_27_co[2];
  assign recovered_27_co[3] = (recovered_27_s[3] & recovered_27_co[2]) | (~recovered_27_s[3] & recovered_27_di[3]);
  assign {esc_add_ln208_105_reg_8205_reg_7__i_1_n_0_11af300 ,esc_NLW_add_ln208_105_reg_8205_reg_7__i_1_CO_UNCONNECTED_115d3fd [2:0]} = recovered_27_co;
  assign esc_add_ln208_102_reg_8173_reg_12_c8013a3 [7:4] = recovered_27_o;

  // Reconstructed LUT2: esc_add_ln208_108_reg_8237_3__i_2_994dfa2
  assign esc_add_ln208_108_reg_8237_3__i_2_n_0_2183c53 = ((DOADO[3]) ? (~(esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [3])) : (esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [3]));

  // Reconstructed LUT2: esc_add_ln208_108_reg_8237_3__i_3_4b49396
  assign esc_add_ln208_108_reg_8237_3__i_3_n_0_ae14cb5 = ((DOADO[2]) ? (~(esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [2])) : (esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [2]));

  // Reconstructed LUT2: esc_add_ln208_108_reg_8237_3__i_4_5e950b7
  assign esc_add_ln208_108_reg_8237_3__i_4_n_0_82c7437 = ((DOADO[1]) ? (~(esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [1])) : (esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [1]));

  // Reconstructed LUT2: esc_add_ln208_108_reg_8237_3__i_5_934cefe
  assign esc_add_ln208_108_reg_8237_3__i_5_n_0_236585d = ((DOADO[0]) ? (~(esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [0])) : (esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [0]));

  // Reconstructed LUT2: esc_add_ln208_108_reg_8237_7__i_2_8460ab8
  assign esc_add_ln208_108_reg_8237_7__i_2_n_0_efa8bea = ((DOADO[7]) ? (~(esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [7])) : (esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [7]));

  // Reconstructed LUT2: esc_add_ln208_108_reg_8237_7__i_3_b04163f
  assign esc_add_ln208_108_reg_8237_7__i_3_n_0_e06b33c = ((DOADO[6]) ? (~(esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [6])) : (esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [6]));

  // Reconstructed LUT2: esc_add_ln208_108_reg_8237_7__i_4_3d5a3cb
  assign esc_add_ln208_108_reg_8237_7__i_4_n_0_5f920c5 = ((DOADO[5]) ? (~(esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [5])) : (esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [5]));

  // Reconstructed LUT2: esc_add_ln208_108_reg_8237_7__i_5_8edd409
  assign esc_add_ln208_108_reg_8237_7__i_5_n_0_f62ea47 = ((DOADO[4]) ? (~(esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [4])) : (esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [4]));

  // Reconstructed CARRY4: esc_add_ln208_108_reg_8237_reg_11__i_1_fa83cfa
  wire [3:0] recovered_36_co, recovered_36_o, recovered_36_s, recovered_36_di;
  assign recovered_36_s = esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [11:8];
  assign recovered_36_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_36_ci = ((esc_add_ln208_108_reg_8237_reg_7__i_1_n_0_6654862) !== 1'bz) && (esc_add_ln208_108_reg_8237_reg_7__i_1_n_0_6654862);
  wire recovered_36_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_36_o[0] = recovered_36_s[0] ^ (recovered_36_ci || recovered_36_cy);
  assign recovered_36_co[0] = (recovered_36_s[0] & (recovered_36_ci || recovered_36_cy)) | (~recovered_36_s[0] & recovered_36_di[0]);
  assign recovered_36_o[1] = recovered_36_s[1] ^ recovered_36_co[0];
  assign recovered_36_co[1] = (recovered_36_s[1] & recovered_36_co[0]) | (~recovered_36_s[1] & recovered_36_di[1]);
  assign recovered_36_o[2] = recovered_36_s[2] ^ recovered_36_co[1];
  assign recovered_36_co[2] = (recovered_36_s[2] & recovered_36_co[1]) | (~recovered_36_s[2] & recovered_36_di[2]);
  assign recovered_36_o[3] = recovered_36_s[3] ^ recovered_36_co[2];
  assign recovered_36_co[3] = (recovered_36_s[3] & recovered_36_co[2]) | (~recovered_36_s[3] & recovered_36_di[3]);
  assign {esc_add_ln208_108_reg_8237_reg_11__i_1_n_0_06a1ab2 ,esc_NLW_add_ln208_108_reg_8237_reg_11__i_1_CO_UNCONNECTED_b944c90 [2:0]} = recovered_36_co;
  assign esc_add_ln208_105_reg_8205_reg_12_4c8e965 [11:8] = recovered_36_o;

  // Reconstructed CARRY4: esc_add_ln208_108_reg_8237_reg_12__i_1_e678fc5
  wire [3:0] recovered_37_co, recovered_37_o, recovered_37_s, recovered_37_di;
  assign recovered_37_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [12]};
  assign recovered_37_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_37_ci = ((esc_add_ln208_108_reg_8237_reg_11__i_1_n_0_06a1ab2) !== 1'bz) && (esc_add_ln208_108_reg_8237_reg_11__i_1_n_0_06a1ab2);
  wire recovered_37_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_37_o[0] = recovered_37_s[0] ^ (recovered_37_ci || recovered_37_cy);
  assign recovered_37_co[0] = (recovered_37_s[0] & (recovered_37_ci || recovered_37_cy)) | (~recovered_37_s[0] & recovered_37_di[0]);
  assign recovered_37_o[1] = recovered_37_s[1] ^ recovered_37_co[0];
  assign recovered_37_co[1] = (recovered_37_s[1] & recovered_37_co[0]) | (~recovered_37_s[1] & recovered_37_di[1]);
  assign recovered_37_o[2] = recovered_37_s[2] ^ recovered_37_co[1];
  assign recovered_37_co[2] = (recovered_37_s[2] & recovered_37_co[1]) | (~recovered_37_s[2] & recovered_37_di[2]);
  assign recovered_37_o[3] = recovered_37_s[3] ^ recovered_37_co[2];
  assign recovered_37_co[3] = (recovered_37_s[3] & recovered_37_co[2]) | (~recovered_37_s[3] & recovered_37_di[3]);
  assign esc_add_ln208_105_reg_8205_reg_12_4c8e965 [12] = recovered_37_o;

  // Reconstructed CARRY4: esc_add_ln208_108_reg_8237_reg_3__i_1_fdad7eb
  wire [3:0] recovered_38_co, recovered_38_o, recovered_38_s, recovered_38_di;
  assign recovered_38_s = {esc_add_ln208_108_reg_8237_3__i_2_n_0_2183c53 ,esc_add_ln208_108_reg_8237_3__i_3_n_0_ae14cb5 ,esc_add_ln208_108_reg_8237_3__i_4_n_0_82c7437 ,esc_add_ln208_108_reg_8237_3__i_5_n_0_236585d };
  assign recovered_38_di = esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [3:0];
  wire recovered_38_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_38_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_38_o[0] = recovered_38_s[0] ^ (recovered_38_ci || recovered_38_cy);
  assign recovered_38_co[0] = (recovered_38_s[0] & (recovered_38_ci || recovered_38_cy)) | (~recovered_38_s[0] & recovered_38_di[0]);
  assign recovered_38_o[1] = recovered_38_s[1] ^ recovered_38_co[0];
  assign recovered_38_co[1] = (recovered_38_s[1] & recovered_38_co[0]) | (~recovered_38_s[1] & recovered_38_di[1]);
  assign recovered_38_o[2] = recovered_38_s[2] ^ recovered_38_co[1];
  assign recovered_38_co[2] = (recovered_38_s[2] & recovered_38_co[1]) | (~recovered_38_s[2] & recovered_38_di[2]);
  assign recovered_38_o[3] = recovered_38_s[3] ^ recovered_38_co[2];
  assign recovered_38_co[3] = (recovered_38_s[3] & recovered_38_co[2]) | (~recovered_38_s[3] & recovered_38_di[3]);
  assign {esc_add_ln208_108_reg_8237_reg_3__i_1_n_0_aa4ad88 ,esc_NLW_add_ln208_108_reg_8237_reg_3__i_1_CO_UNCONNECTED_3a0bd33 [2:0]} = recovered_38_co;
  assign esc_add_ln208_105_reg_8205_reg_12_4c8e965 [3:0] = recovered_38_o;

  // Reconstructed CARRY4: esc_add_ln208_108_reg_8237_reg_7__i_1_dd45e9e
  wire [3:0] recovered_39_co, recovered_39_o, recovered_39_s, recovered_39_di;
  assign recovered_39_s = {esc_add_ln208_108_reg_8237_7__i_2_n_0_efa8bea ,esc_add_ln208_108_reg_8237_7__i_3_n_0_e06b33c ,esc_add_ln208_108_reg_8237_7__i_4_n_0_5f920c5 ,esc_add_ln208_108_reg_8237_7__i_5_n_0_f62ea47 };
  assign recovered_39_di = esc_add_ln208_108_reg_8237_reg_12__0_9171fbf [7:4];
  wire recovered_39_ci = ((esc_add_ln208_108_reg_8237_reg_3__i_1_n_0_aa4ad88) !== 1'bz) && (esc_add_ln208_108_reg_8237_reg_3__i_1_n_0_aa4ad88);
  wire recovered_39_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_39_o[0] = recovered_39_s[0] ^ (recovered_39_ci || recovered_39_cy);
  assign recovered_39_co[0] = (recovered_39_s[0] & (recovered_39_ci || recovered_39_cy)) | (~recovered_39_s[0] & recovered_39_di[0]);
  assign recovered_39_o[1] = recovered_39_s[1] ^ recovered_39_co[0];
  assign recovered_39_co[1] = (recovered_39_s[1] & recovered_39_co[0]) | (~recovered_39_s[1] & recovered_39_di[1]);
  assign recovered_39_o[2] = recovered_39_s[2] ^ recovered_39_co[1];
  assign recovered_39_co[2] = (recovered_39_s[2] & recovered_39_co[1]) | (~recovered_39_s[2] & recovered_39_di[2]);
  assign recovered_39_o[3] = recovered_39_s[3] ^ recovered_39_co[2];
  assign recovered_39_co[3] = (recovered_39_s[3] & recovered_39_co[2]) | (~recovered_39_s[3] & recovered_39_di[3]);
  assign {esc_add_ln208_108_reg_8237_reg_7__i_1_n_0_6654862 ,esc_NLW_add_ln208_108_reg_8237_reg_7__i_1_CO_UNCONNECTED_168c511 [2:0]} = recovered_39_co;
  assign esc_add_ln208_105_reg_8205_reg_12_4c8e965 [7:4] = recovered_39_o;

  // Reconstructed LUT2: esc_add_ln208_111_reg_8269_3__i_2_27004eb
  assign esc_add_ln208_111_reg_8269_3__i_2_n_0_9cdc103 = ((DOADO[3]) ? (~(esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [3])) : (esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [3]));

  // Reconstructed LUT2: esc_add_ln208_111_reg_8269_3__i_3_0cae80a
  assign esc_add_ln208_111_reg_8269_3__i_3_n_0_df47d30 = ((DOADO[2]) ? (~(esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [2])) : (esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [2]));

  // Reconstructed LUT2: esc_add_ln208_111_reg_8269_3__i_4_7215124
  assign esc_add_ln208_111_reg_8269_3__i_4_n_0_8077490 = ((DOADO[1]) ? (~(esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [1])) : (esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [1]));

  // Reconstructed LUT2: esc_add_ln208_111_reg_8269_3__i_5_6b1ee48
  assign esc_add_ln208_111_reg_8269_3__i_5_n_0_d404733 = ((DOADO[0]) ? (~(esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [0])) : (esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [0]));

  // Reconstructed LUT2: esc_add_ln208_111_reg_8269_7__i_2_1528e04
  assign esc_add_ln208_111_reg_8269_7__i_2_n_0_38ed9c8 = ((DOADO[7]) ? (~(esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [7])) : (esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [7]));

  // Reconstructed LUT2: esc_add_ln208_111_reg_8269_7__i_3_152f160
  assign esc_add_ln208_111_reg_8269_7__i_3_n_0_170261a = ((DOADO[6]) ? (~(esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [6])) : (esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [6]));

  // Reconstructed LUT2: esc_add_ln208_111_reg_8269_7__i_4_b601feb
  assign esc_add_ln208_111_reg_8269_7__i_4_n_0_d20b616 = ((DOADO[5]) ? (~(esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [5])) : (esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [5]));

  // Reconstructed LUT2: esc_add_ln208_111_reg_8269_7__i_5_12e1891
  assign esc_add_ln208_111_reg_8269_7__i_5_n_0_503a74e = ((DOADO[4]) ? (~(esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [4])) : (esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [4]));

  // Reconstructed CARRY4: esc_add_ln208_111_reg_8269_reg_11__i_1_97768f6
  wire [3:0] recovered_48_co, recovered_48_o, recovered_48_s, recovered_48_di;
  assign recovered_48_s = esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [11:8];
  assign recovered_48_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_48_ci = ((esc_add_ln208_111_reg_8269_reg_7__i_1_n_0_9e6726b) !== 1'bz) && (esc_add_ln208_111_reg_8269_reg_7__i_1_n_0_9e6726b);
  wire recovered_48_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_48_o[0] = recovered_48_s[0] ^ (recovered_48_ci || recovered_48_cy);
  assign recovered_48_co[0] = (recovered_48_s[0] & (recovered_48_ci || recovered_48_cy)) | (~recovered_48_s[0] & recovered_48_di[0]);
  assign recovered_48_o[1] = recovered_48_s[1] ^ recovered_48_co[0];
  assign recovered_48_co[1] = (recovered_48_s[1] & recovered_48_co[0]) | (~recovered_48_s[1] & recovered_48_di[1]);
  assign recovered_48_o[2] = recovered_48_s[2] ^ recovered_48_co[1];
  assign recovered_48_co[2] = (recovered_48_s[2] & recovered_48_co[1]) | (~recovered_48_s[2] & recovered_48_di[2]);
  assign recovered_48_o[3] = recovered_48_s[3] ^ recovered_48_co[2];
  assign recovered_48_co[3] = (recovered_48_s[3] & recovered_48_co[2]) | (~recovered_48_s[3] & recovered_48_di[3]);
  assign {esc_add_ln208_111_reg_8269_reg_11__i_1_n_0_323a719 ,esc_NLW_add_ln208_111_reg_8269_reg_11__i_1_CO_UNCONNECTED_30be0d0 [2:0]} = recovered_48_co;
  assign esc_add_ln208_108_reg_8237_reg_12_b4010f2 [11:8] = recovered_48_o;

  // Reconstructed CARRY4: esc_add_ln208_111_reg_8269_reg_12__i_1_d0cae9f
  wire [3:0] recovered_49_co, recovered_49_o, recovered_49_s, recovered_49_di;
  assign recovered_49_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [12]};
  assign recovered_49_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_49_ci = ((esc_add_ln208_111_reg_8269_reg_11__i_1_n_0_323a719) !== 1'bz) && (esc_add_ln208_111_reg_8269_reg_11__i_1_n_0_323a719);
  wire recovered_49_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_49_o[0] = recovered_49_s[0] ^ (recovered_49_ci || recovered_49_cy);
  assign recovered_49_co[0] = (recovered_49_s[0] & (recovered_49_ci || recovered_49_cy)) | (~recovered_49_s[0] & recovered_49_di[0]);
  assign recovered_49_o[1] = recovered_49_s[1] ^ recovered_49_co[0];
  assign recovered_49_co[1] = (recovered_49_s[1] & recovered_49_co[0]) | (~recovered_49_s[1] & recovered_49_di[1]);
  assign recovered_49_o[2] = recovered_49_s[2] ^ recovered_49_co[1];
  assign recovered_49_co[2] = (recovered_49_s[2] & recovered_49_co[1]) | (~recovered_49_s[2] & recovered_49_di[2]);
  assign recovered_49_o[3] = recovered_49_s[3] ^ recovered_49_co[2];
  assign recovered_49_co[3] = (recovered_49_s[3] & recovered_49_co[2]) | (~recovered_49_s[3] & recovered_49_di[3]);
  assign esc_add_ln208_108_reg_8237_reg_12_b4010f2 [12] = recovered_49_o;

  // Reconstructed CARRY4: esc_add_ln208_111_reg_8269_reg_3__i_1_a7a09e6
  wire [3:0] recovered_50_co, recovered_50_o, recovered_50_s, recovered_50_di;
  assign recovered_50_s = {esc_add_ln208_111_reg_8269_3__i_2_n_0_9cdc103 ,esc_add_ln208_111_reg_8269_3__i_3_n_0_df47d30 ,esc_add_ln208_111_reg_8269_3__i_4_n_0_8077490 ,esc_add_ln208_111_reg_8269_3__i_5_n_0_d404733 };
  assign recovered_50_di = esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [3:0];
  wire recovered_50_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_50_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_50_o[0] = recovered_50_s[0] ^ (recovered_50_ci || recovered_50_cy);
  assign recovered_50_co[0] = (recovered_50_s[0] & (recovered_50_ci || recovered_50_cy)) | (~recovered_50_s[0] & recovered_50_di[0]);
  assign recovered_50_o[1] = recovered_50_s[1] ^ recovered_50_co[0];
  assign recovered_50_co[1] = (recovered_50_s[1] & recovered_50_co[0]) | (~recovered_50_s[1] & recovered_50_di[1]);
  assign recovered_50_o[2] = recovered_50_s[2] ^ recovered_50_co[1];
  assign recovered_50_co[2] = (recovered_50_s[2] & recovered_50_co[1]) | (~recovered_50_s[2] & recovered_50_di[2]);
  assign recovered_50_o[3] = recovered_50_s[3] ^ recovered_50_co[2];
  assign recovered_50_co[3] = (recovered_50_s[3] & recovered_50_co[2]) | (~recovered_50_s[3] & recovered_50_di[3]);
  assign {esc_add_ln208_111_reg_8269_reg_3__i_1_n_0_6c5c2d1 ,esc_NLW_add_ln208_111_reg_8269_reg_3__i_1_CO_UNCONNECTED_c7833f2 [2:0]} = recovered_50_co;
  assign esc_add_ln208_108_reg_8237_reg_12_b4010f2 [3:0] = recovered_50_o;

  // Reconstructed CARRY4: esc_add_ln208_111_reg_8269_reg_7__i_1_593f4e5
  wire [3:0] recovered_51_co, recovered_51_o, recovered_51_s, recovered_51_di;
  assign recovered_51_s = {esc_add_ln208_111_reg_8269_7__i_2_n_0_38ed9c8 ,esc_add_ln208_111_reg_8269_7__i_3_n_0_170261a ,esc_add_ln208_111_reg_8269_7__i_4_n_0_d20b616 ,esc_add_ln208_111_reg_8269_7__i_5_n_0_503a74e };
  assign recovered_51_di = esc_add_ln208_111_reg_8269_reg_12__0_a3af0b1 [7:4];
  wire recovered_51_ci = ((esc_add_ln208_111_reg_8269_reg_3__i_1_n_0_6c5c2d1) !== 1'bz) && (esc_add_ln208_111_reg_8269_reg_3__i_1_n_0_6c5c2d1);
  wire recovered_51_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_51_o[0] = recovered_51_s[0] ^ (recovered_51_ci || recovered_51_cy);
  assign recovered_51_co[0] = (recovered_51_s[0] & (recovered_51_ci || recovered_51_cy)) | (~recovered_51_s[0] & recovered_51_di[0]);
  assign recovered_51_o[1] = recovered_51_s[1] ^ recovered_51_co[0];
  assign recovered_51_co[1] = (recovered_51_s[1] & recovered_51_co[0]) | (~recovered_51_s[1] & recovered_51_di[1]);
  assign recovered_51_o[2] = recovered_51_s[2] ^ recovered_51_co[1];
  assign recovered_51_co[2] = (recovered_51_s[2] & recovered_51_co[1]) | (~recovered_51_s[2] & recovered_51_di[2]);
  assign recovered_51_o[3] = recovered_51_s[3] ^ recovered_51_co[2];
  assign recovered_51_co[3] = (recovered_51_s[3] & recovered_51_co[2]) | (~recovered_51_s[3] & recovered_51_di[3]);
  assign {esc_add_ln208_111_reg_8269_reg_7__i_1_n_0_9e6726b ,esc_NLW_add_ln208_111_reg_8269_reg_7__i_1_CO_UNCONNECTED_e84881f [2:0]} = recovered_51_co;
  assign esc_add_ln208_108_reg_8237_reg_12_b4010f2 [7:4] = recovered_51_o;

  // Reconstructed LUT2: esc_add_ln208_114_reg_8301_3__i_2_aa1c599
  assign esc_add_ln208_114_reg_8301_3__i_2_n_0_3002f7a = ((DOADO[3]) ? (~(esc_add_ln208_114_reg_8301_reg_12__0_432a19c [3])) : (esc_add_ln208_114_reg_8301_reg_12__0_432a19c [3]));

  // Reconstructed LUT2: esc_add_ln208_114_reg_8301_3__i_3_41357fc
  assign esc_add_ln208_114_reg_8301_3__i_3_n_0_50e2114 = ((DOADO[2]) ? (~(esc_add_ln208_114_reg_8301_reg_12__0_432a19c [2])) : (esc_add_ln208_114_reg_8301_reg_12__0_432a19c [2]));

  // Reconstructed LUT2: esc_add_ln208_114_reg_8301_3__i_4_ec6bfd6
  assign esc_add_ln208_114_reg_8301_3__i_4_n_0_5a1c062 = ((DOADO[1]) ? (~(esc_add_ln208_114_reg_8301_reg_12__0_432a19c [1])) : (esc_add_ln208_114_reg_8301_reg_12__0_432a19c [1]));

  // Reconstructed LUT2: esc_add_ln208_114_reg_8301_3__i_5_07d1416
  assign esc_add_ln208_114_reg_8301_3__i_5_n_0_5f1d0bd = ((DOADO[0]) ? (~(esc_add_ln208_114_reg_8301_reg_12__0_432a19c [0])) : (esc_add_ln208_114_reg_8301_reg_12__0_432a19c [0]));

  // Reconstructed LUT2: esc_add_ln208_114_reg_8301_7__i_2_68e57a5
  assign esc_add_ln208_114_reg_8301_7__i_2_n_0_c6f7105 = ((DOADO[7]) ? (~(esc_add_ln208_114_reg_8301_reg_12__0_432a19c [7])) : (esc_add_ln208_114_reg_8301_reg_12__0_432a19c [7]));

  // Reconstructed LUT2: esc_add_ln208_114_reg_8301_7__i_3_e2340ff
  assign esc_add_ln208_114_reg_8301_7__i_3_n_0_145235f = ((DOADO[6]) ? (~(esc_add_ln208_114_reg_8301_reg_12__0_432a19c [6])) : (esc_add_ln208_114_reg_8301_reg_12__0_432a19c [6]));

  // Reconstructed LUT2: esc_add_ln208_114_reg_8301_7__i_4_41a88d7
  assign esc_add_ln208_114_reg_8301_7__i_4_n_0_b68ae06 = ((DOADO[5]) ? (~(esc_add_ln208_114_reg_8301_reg_12__0_432a19c [5])) : (esc_add_ln208_114_reg_8301_reg_12__0_432a19c [5]));

  // Reconstructed LUT2: esc_add_ln208_114_reg_8301_7__i_5_a6ce956
  assign esc_add_ln208_114_reg_8301_7__i_5_n_0_f92d99c = ((DOADO[4]) ? (~(esc_add_ln208_114_reg_8301_reg_12__0_432a19c [4])) : (esc_add_ln208_114_reg_8301_reg_12__0_432a19c [4]));

  // Reconstructed CARRY4: esc_add_ln208_114_reg_8301_reg_11__i_1_845abb0
  wire [3:0] recovered_60_co, recovered_60_o, recovered_60_s, recovered_60_di;
  assign recovered_60_s = esc_add_ln208_114_reg_8301_reg_12__0_432a19c [11:8];
  assign recovered_60_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_60_ci = ((esc_add_ln208_114_reg_8301_reg_7__i_1_n_0_cbef687) !== 1'bz) && (esc_add_ln208_114_reg_8301_reg_7__i_1_n_0_cbef687);
  wire recovered_60_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_60_o[0] = recovered_60_s[0] ^ (recovered_60_ci || recovered_60_cy);
  assign recovered_60_co[0] = (recovered_60_s[0] & (recovered_60_ci || recovered_60_cy)) | (~recovered_60_s[0] & recovered_60_di[0]);
  assign recovered_60_o[1] = recovered_60_s[1] ^ recovered_60_co[0];
  assign recovered_60_co[1] = (recovered_60_s[1] & recovered_60_co[0]) | (~recovered_60_s[1] & recovered_60_di[1]);
  assign recovered_60_o[2] = recovered_60_s[2] ^ recovered_60_co[1];
  assign recovered_60_co[2] = (recovered_60_s[2] & recovered_60_co[1]) | (~recovered_60_s[2] & recovered_60_di[2]);
  assign recovered_60_o[3] = recovered_60_s[3] ^ recovered_60_co[2];
  assign recovered_60_co[3] = (recovered_60_s[3] & recovered_60_co[2]) | (~recovered_60_s[3] & recovered_60_di[3]);
  assign {esc_add_ln208_114_reg_8301_reg_11__i_1_n_0_d160ef8 ,esc_NLW_add_ln208_114_reg_8301_reg_11__i_1_CO_UNCONNECTED_fe919a8 [2:0]} = recovered_60_co;
  assign esc_add_ln208_111_reg_8269_reg_12_37e6aa3 [11:8] = recovered_60_o;

  // Reconstructed CARRY4: esc_add_ln208_114_reg_8301_reg_12__i_1_c275e94
  wire [3:0] recovered_61_co, recovered_61_o, recovered_61_s, recovered_61_di;
  assign recovered_61_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_114_reg_8301_reg_12__0_432a19c [12]};
  assign recovered_61_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_61_ci = ((esc_add_ln208_114_reg_8301_reg_11__i_1_n_0_d160ef8) !== 1'bz) && (esc_add_ln208_114_reg_8301_reg_11__i_1_n_0_d160ef8);
  wire recovered_61_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_61_o[0] = recovered_61_s[0] ^ (recovered_61_ci || recovered_61_cy);
  assign recovered_61_co[0] = (recovered_61_s[0] & (recovered_61_ci || recovered_61_cy)) | (~recovered_61_s[0] & recovered_61_di[0]);
  assign recovered_61_o[1] = recovered_61_s[1] ^ recovered_61_co[0];
  assign recovered_61_co[1] = (recovered_61_s[1] & recovered_61_co[0]) | (~recovered_61_s[1] & recovered_61_di[1]);
  assign recovered_61_o[2] = recovered_61_s[2] ^ recovered_61_co[1];
  assign recovered_61_co[2] = (recovered_61_s[2] & recovered_61_co[1]) | (~recovered_61_s[2] & recovered_61_di[2]);
  assign recovered_61_o[3] = recovered_61_s[3] ^ recovered_61_co[2];
  assign recovered_61_co[3] = (recovered_61_s[3] & recovered_61_co[2]) | (~recovered_61_s[3] & recovered_61_di[3]);
  assign esc_add_ln208_111_reg_8269_reg_12_37e6aa3 [12] = recovered_61_o;

  // Reconstructed CARRY4: esc_add_ln208_114_reg_8301_reg_3__i_1_ad56303
  wire [3:0] recovered_62_co, recovered_62_o, recovered_62_s, recovered_62_di;
  assign recovered_62_s = {esc_add_ln208_114_reg_8301_3__i_2_n_0_3002f7a ,esc_add_ln208_114_reg_8301_3__i_3_n_0_50e2114 ,esc_add_ln208_114_reg_8301_3__i_4_n_0_5a1c062 ,esc_add_ln208_114_reg_8301_3__i_5_n_0_5f1d0bd };
  assign recovered_62_di = esc_add_ln208_114_reg_8301_reg_12__0_432a19c [3:0];
  wire recovered_62_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_62_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_62_o[0] = recovered_62_s[0] ^ (recovered_62_ci || recovered_62_cy);
  assign recovered_62_co[0] = (recovered_62_s[0] & (recovered_62_ci || recovered_62_cy)) | (~recovered_62_s[0] & recovered_62_di[0]);
  assign recovered_62_o[1] = recovered_62_s[1] ^ recovered_62_co[0];
  assign recovered_62_co[1] = (recovered_62_s[1] & recovered_62_co[0]) | (~recovered_62_s[1] & recovered_62_di[1]);
  assign recovered_62_o[2] = recovered_62_s[2] ^ recovered_62_co[1];
  assign recovered_62_co[2] = (recovered_62_s[2] & recovered_62_co[1]) | (~recovered_62_s[2] & recovered_62_di[2]);
  assign recovered_62_o[3] = recovered_62_s[3] ^ recovered_62_co[2];
  assign recovered_62_co[3] = (recovered_62_s[3] & recovered_62_co[2]) | (~recovered_62_s[3] & recovered_62_di[3]);
  assign {esc_add_ln208_114_reg_8301_reg_3__i_1_n_0_419ad10 ,esc_NLW_add_ln208_114_reg_8301_reg_3__i_1_CO_UNCONNECTED_7adcb57 [2:0]} = recovered_62_co;
  assign esc_add_ln208_111_reg_8269_reg_12_37e6aa3 [3:0] = recovered_62_o;

  // Reconstructed CARRY4: esc_add_ln208_114_reg_8301_reg_7__i_1_d90484a
  wire [3:0] recovered_63_co, recovered_63_o, recovered_63_s, recovered_63_di;
  assign recovered_63_s = {esc_add_ln208_114_reg_8301_7__i_2_n_0_c6f7105 ,esc_add_ln208_114_reg_8301_7__i_3_n_0_145235f ,esc_add_ln208_114_reg_8301_7__i_4_n_0_b68ae06 ,esc_add_ln208_114_reg_8301_7__i_5_n_0_f92d99c };
  assign recovered_63_di = esc_add_ln208_114_reg_8301_reg_12__0_432a19c [7:4];
  wire recovered_63_ci = ((esc_add_ln208_114_reg_8301_reg_3__i_1_n_0_419ad10) !== 1'bz) && (esc_add_ln208_114_reg_8301_reg_3__i_1_n_0_419ad10);
  wire recovered_63_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_63_o[0] = recovered_63_s[0] ^ (recovered_63_ci || recovered_63_cy);
  assign recovered_63_co[0] = (recovered_63_s[0] & (recovered_63_ci || recovered_63_cy)) | (~recovered_63_s[0] & recovered_63_di[0]);
  assign recovered_63_o[1] = recovered_63_s[1] ^ recovered_63_co[0];
  assign recovered_63_co[1] = (recovered_63_s[1] & recovered_63_co[0]) | (~recovered_63_s[1] & recovered_63_di[1]);
  assign recovered_63_o[2] = recovered_63_s[2] ^ recovered_63_co[1];
  assign recovered_63_co[2] = (recovered_63_s[2] & recovered_63_co[1]) | (~recovered_63_s[2] & recovered_63_di[2]);
  assign recovered_63_o[3] = recovered_63_s[3] ^ recovered_63_co[2];
  assign recovered_63_co[3] = (recovered_63_s[3] & recovered_63_co[2]) | (~recovered_63_s[3] & recovered_63_di[3]);
  assign {esc_add_ln208_114_reg_8301_reg_7__i_1_n_0_cbef687 ,esc_NLW_add_ln208_114_reg_8301_reg_7__i_1_CO_UNCONNECTED_dcfe1af [2:0]} = recovered_63_co;
  assign esc_add_ln208_111_reg_8269_reg_12_37e6aa3 [7:4] = recovered_63_o;

  // Reconstructed LUT2: esc_add_ln208_117_reg_8333_3__i_2_c2cae3e
  assign esc_add_ln208_117_reg_8333_3__i_2_n_0_a46747c = ((DOADO[3]) ? (~(esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [3])) : (esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [3]));

  // Reconstructed LUT2: esc_add_ln208_117_reg_8333_3__i_3_55f084b
  assign esc_add_ln208_117_reg_8333_3__i_3_n_0_6f6895d = ((DOADO[2]) ? (~(esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [2])) : (esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [2]));

  // Reconstructed LUT2: esc_add_ln208_117_reg_8333_3__i_4_56f6ecd
  assign esc_add_ln208_117_reg_8333_3__i_4_n_0_7f298d8 = ((DOADO[1]) ? (~(esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [1])) : (esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [1]));

  // Reconstructed LUT2: esc_add_ln208_117_reg_8333_3__i_5_aa8f8ad
  assign esc_add_ln208_117_reg_8333_3__i_5_n_0_a313e45 = ((DOADO[0]) ? (~(esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [0])) : (esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [0]));

  // Reconstructed LUT2: esc_add_ln208_117_reg_8333_7__i_2_4d929be
  assign esc_add_ln208_117_reg_8333_7__i_2_n_0_c2b85ec = ((DOADO[7]) ? (~(esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [7])) : (esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [7]));

  // Reconstructed LUT2: esc_add_ln208_117_reg_8333_7__i_3_d9c8239
  assign esc_add_ln208_117_reg_8333_7__i_3_n_0_ce6ec80 = ((DOADO[6]) ? (~(esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [6])) : (esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [6]));

  // Reconstructed LUT2: esc_add_ln208_117_reg_8333_7__i_4_7ac9d71
  assign esc_add_ln208_117_reg_8333_7__i_4_n_0_cbac282 = ((DOADO[5]) ? (~(esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [5])) : (esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [5]));

  // Reconstructed LUT2: esc_add_ln208_117_reg_8333_7__i_5_8198d02
  assign esc_add_ln208_117_reg_8333_7__i_5_n_0_6710aa9 = ((DOADO[4]) ? (~(esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [4])) : (esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [4]));

  // Reconstructed CARRY4: esc_add_ln208_117_reg_8333_reg_11__i_1_e672543
  wire [3:0] recovered_72_co, recovered_72_o, recovered_72_s, recovered_72_di;
  assign recovered_72_s = esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [11:8];
  assign recovered_72_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_72_ci = ((esc_add_ln208_117_reg_8333_reg_7__i_1_n_0_746c324) !== 1'bz) && (esc_add_ln208_117_reg_8333_reg_7__i_1_n_0_746c324);
  wire recovered_72_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_72_o[0] = recovered_72_s[0] ^ (recovered_72_ci || recovered_72_cy);
  assign recovered_72_co[0] = (recovered_72_s[0] & (recovered_72_ci || recovered_72_cy)) | (~recovered_72_s[0] & recovered_72_di[0]);
  assign recovered_72_o[1] = recovered_72_s[1] ^ recovered_72_co[0];
  assign recovered_72_co[1] = (recovered_72_s[1] & recovered_72_co[0]) | (~recovered_72_s[1] & recovered_72_di[1]);
  assign recovered_72_o[2] = recovered_72_s[2] ^ recovered_72_co[1];
  assign recovered_72_co[2] = (recovered_72_s[2] & recovered_72_co[1]) | (~recovered_72_s[2] & recovered_72_di[2]);
  assign recovered_72_o[3] = recovered_72_s[3] ^ recovered_72_co[2];
  assign recovered_72_co[3] = (recovered_72_s[3] & recovered_72_co[2]) | (~recovered_72_s[3] & recovered_72_di[3]);
  assign {esc_add_ln208_117_reg_8333_reg_11__i_1_n_0_46206d9 ,esc_NLW_add_ln208_117_reg_8333_reg_11__i_1_CO_UNCONNECTED_ea8afb7 [2:0]} = recovered_72_co;
  assign esc_add_ln208_114_reg_8301_reg_12_915e9df [11:8] = recovered_72_o;

  // Reconstructed CARRY4: esc_add_ln208_117_reg_8333_reg_12__i_1_38852e6
  wire [3:0] recovered_73_co, recovered_73_o, recovered_73_s, recovered_73_di;
  assign recovered_73_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [12]};
  assign recovered_73_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_73_ci = ((esc_add_ln208_117_reg_8333_reg_11__i_1_n_0_46206d9) !== 1'bz) && (esc_add_ln208_117_reg_8333_reg_11__i_1_n_0_46206d9);
  wire recovered_73_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_73_o[0] = recovered_73_s[0] ^ (recovered_73_ci || recovered_73_cy);
  assign recovered_73_co[0] = (recovered_73_s[0] & (recovered_73_ci || recovered_73_cy)) | (~recovered_73_s[0] & recovered_73_di[0]);
  assign recovered_73_o[1] = recovered_73_s[1] ^ recovered_73_co[0];
  assign recovered_73_co[1] = (recovered_73_s[1] & recovered_73_co[0]) | (~recovered_73_s[1] & recovered_73_di[1]);
  assign recovered_73_o[2] = recovered_73_s[2] ^ recovered_73_co[1];
  assign recovered_73_co[2] = (recovered_73_s[2] & recovered_73_co[1]) | (~recovered_73_s[2] & recovered_73_di[2]);
  assign recovered_73_o[3] = recovered_73_s[3] ^ recovered_73_co[2];
  assign recovered_73_co[3] = (recovered_73_s[3] & recovered_73_co[2]) | (~recovered_73_s[3] & recovered_73_di[3]);
  assign esc_add_ln208_114_reg_8301_reg_12_915e9df [12] = recovered_73_o;

  // Reconstructed CARRY4: esc_add_ln208_117_reg_8333_reg_3__i_1_94b6919
  wire [3:0] recovered_74_co, recovered_74_o, recovered_74_s, recovered_74_di;
  assign recovered_74_s = {esc_add_ln208_117_reg_8333_3__i_2_n_0_a46747c ,esc_add_ln208_117_reg_8333_3__i_3_n_0_6f6895d ,esc_add_ln208_117_reg_8333_3__i_4_n_0_7f298d8 ,esc_add_ln208_117_reg_8333_3__i_5_n_0_a313e45 };
  assign recovered_74_di = esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [3:0];
  wire recovered_74_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_74_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_74_o[0] = recovered_74_s[0] ^ (recovered_74_ci || recovered_74_cy);
  assign recovered_74_co[0] = (recovered_74_s[0] & (recovered_74_ci || recovered_74_cy)) | (~recovered_74_s[0] & recovered_74_di[0]);
  assign recovered_74_o[1] = recovered_74_s[1] ^ recovered_74_co[0];
  assign recovered_74_co[1] = (recovered_74_s[1] & recovered_74_co[0]) | (~recovered_74_s[1] & recovered_74_di[1]);
  assign recovered_74_o[2] = recovered_74_s[2] ^ recovered_74_co[1];
  assign recovered_74_co[2] = (recovered_74_s[2] & recovered_74_co[1]) | (~recovered_74_s[2] & recovered_74_di[2]);
  assign recovered_74_o[3] = recovered_74_s[3] ^ recovered_74_co[2];
  assign recovered_74_co[3] = (recovered_74_s[3] & recovered_74_co[2]) | (~recovered_74_s[3] & recovered_74_di[3]);
  assign {esc_add_ln208_117_reg_8333_reg_3__i_1_n_0_19a7bc9 ,esc_NLW_add_ln208_117_reg_8333_reg_3__i_1_CO_UNCONNECTED_80a2d7e [2:0]} = recovered_74_co;
  assign esc_add_ln208_114_reg_8301_reg_12_915e9df [3:0] = recovered_74_o;

  // Reconstructed CARRY4: esc_add_ln208_117_reg_8333_reg_7__i_1_162e4e4
  wire [3:0] recovered_75_co, recovered_75_o, recovered_75_s, recovered_75_di;
  assign recovered_75_s = {esc_add_ln208_117_reg_8333_7__i_2_n_0_c2b85ec ,esc_add_ln208_117_reg_8333_7__i_3_n_0_ce6ec80 ,esc_add_ln208_117_reg_8333_7__i_4_n_0_cbac282 ,esc_add_ln208_117_reg_8333_7__i_5_n_0_6710aa9 };
  assign recovered_75_di = esc_add_ln208_117_reg_8333_reg_12__0_934ade3 [7:4];
  wire recovered_75_ci = ((esc_add_ln208_117_reg_8333_reg_3__i_1_n_0_19a7bc9) !== 1'bz) && (esc_add_ln208_117_reg_8333_reg_3__i_1_n_0_19a7bc9);
  wire recovered_75_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_75_o[0] = recovered_75_s[0] ^ (recovered_75_ci || recovered_75_cy);
  assign recovered_75_co[0] = (recovered_75_s[0] & (recovered_75_ci || recovered_75_cy)) | (~recovered_75_s[0] & recovered_75_di[0]);
  assign recovered_75_o[1] = recovered_75_s[1] ^ recovered_75_co[0];
  assign recovered_75_co[1] = (recovered_75_s[1] & recovered_75_co[0]) | (~recovered_75_s[1] & recovered_75_di[1]);
  assign recovered_75_o[2] = recovered_75_s[2] ^ recovered_75_co[1];
  assign recovered_75_co[2] = (recovered_75_s[2] & recovered_75_co[1]) | (~recovered_75_s[2] & recovered_75_di[2]);
  assign recovered_75_o[3] = recovered_75_s[3] ^ recovered_75_co[2];
  assign recovered_75_co[3] = (recovered_75_s[3] & recovered_75_co[2]) | (~recovered_75_s[3] & recovered_75_di[3]);
  assign {esc_add_ln208_117_reg_8333_reg_7__i_1_n_0_746c324 ,esc_NLW_add_ln208_117_reg_8333_reg_7__i_1_CO_UNCONNECTED_c2724a1 [2:0]} = recovered_75_co;
  assign esc_add_ln208_114_reg_8301_reg_12_915e9df [7:4] = recovered_75_o;

  // Reconstructed LUT2: esc_add_ln208_120_reg_8365_3__i_2_76db0ae
  assign esc_add_ln208_120_reg_8365_3__i_2_n_0_bd4ffd9 = ((DOADO[3]) ? (~(esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [3])) : (esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [3]));

  // Reconstructed LUT2: esc_add_ln208_120_reg_8365_3__i_3_075a8d2
  assign esc_add_ln208_120_reg_8365_3__i_3_n_0_916e4b1 = ((DOADO[2]) ? (~(esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [2])) : (esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [2]));

  // Reconstructed LUT2: esc_add_ln208_120_reg_8365_3__i_4_6bf4b97
  assign esc_add_ln208_120_reg_8365_3__i_4_n_0_0f0b5d2 = ((DOADO[1]) ? (~(esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [1])) : (esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [1]));

  // Reconstructed LUT2: esc_add_ln208_120_reg_8365_3__i_5_68ced07
  assign esc_add_ln208_120_reg_8365_3__i_5_n_0_220cee3 = ((DOADO[0]) ? (~(esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [0])) : (esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [0]));

  // Reconstructed LUT2: esc_add_ln208_120_reg_8365_7__i_2_5b5484c
  assign esc_add_ln208_120_reg_8365_7__i_2_n_0_7fc5329 = ((DOADO[7]) ? (~(esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [7])) : (esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [7]));

  // Reconstructed LUT2: esc_add_ln208_120_reg_8365_7__i_3_9bfee4b
  assign esc_add_ln208_120_reg_8365_7__i_3_n_0_0123f46 = ((DOADO[6]) ? (~(esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [6])) : (esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [6]));

  // Reconstructed LUT2: esc_add_ln208_120_reg_8365_7__i_4_1ee34be
  assign esc_add_ln208_120_reg_8365_7__i_4_n_0_8a86106 = ((DOADO[5]) ? (~(esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [5])) : (esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [5]));

  // Reconstructed LUT2: esc_add_ln208_120_reg_8365_7__i_5_7712614
  assign esc_add_ln208_120_reg_8365_7__i_5_n_0_eb71344 = ((DOADO[4]) ? (~(esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [4])) : (esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [4]));

  // Reconstructed CARRY4: esc_add_ln208_120_reg_8365_reg_11__i_1_8029821
  wire [3:0] recovered_84_co, recovered_84_o, recovered_84_s, recovered_84_di;
  assign recovered_84_s = esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [11:8];
  assign recovered_84_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_84_ci = ((esc_add_ln208_120_reg_8365_reg_7__i_1_n_0_0763155) !== 1'bz) && (esc_add_ln208_120_reg_8365_reg_7__i_1_n_0_0763155);
  wire recovered_84_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_84_o[0] = recovered_84_s[0] ^ (recovered_84_ci || recovered_84_cy);
  assign recovered_84_co[0] = (recovered_84_s[0] & (recovered_84_ci || recovered_84_cy)) | (~recovered_84_s[0] & recovered_84_di[0]);
  assign recovered_84_o[1] = recovered_84_s[1] ^ recovered_84_co[0];
  assign recovered_84_co[1] = (recovered_84_s[1] & recovered_84_co[0]) | (~recovered_84_s[1] & recovered_84_di[1]);
  assign recovered_84_o[2] = recovered_84_s[2] ^ recovered_84_co[1];
  assign recovered_84_co[2] = (recovered_84_s[2] & recovered_84_co[1]) | (~recovered_84_s[2] & recovered_84_di[2]);
  assign recovered_84_o[3] = recovered_84_s[3] ^ recovered_84_co[2];
  assign recovered_84_co[3] = (recovered_84_s[3] & recovered_84_co[2]) | (~recovered_84_s[3] & recovered_84_di[3]);
  assign {esc_add_ln208_120_reg_8365_reg_11__i_1_n_0_cb0b6a1 ,esc_NLW_add_ln208_120_reg_8365_reg_11__i_1_CO_UNCONNECTED_345b1cc [2:0]} = recovered_84_co;
  assign esc_add_ln208_117_reg_8333_reg_12_7252cfb [11:8] = recovered_84_o;

  // Reconstructed CARRY4: esc_add_ln208_120_reg_8365_reg_12__i_1_35d647c
  wire [3:0] recovered_85_co, recovered_85_o, recovered_85_s, recovered_85_di;
  assign recovered_85_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [12]};
  assign recovered_85_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_85_ci = ((esc_add_ln208_120_reg_8365_reg_11__i_1_n_0_cb0b6a1) !== 1'bz) && (esc_add_ln208_120_reg_8365_reg_11__i_1_n_0_cb0b6a1);
  wire recovered_85_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_85_o[0] = recovered_85_s[0] ^ (recovered_85_ci || recovered_85_cy);
  assign recovered_85_co[0] = (recovered_85_s[0] & (recovered_85_ci || recovered_85_cy)) | (~recovered_85_s[0] & recovered_85_di[0]);
  assign recovered_85_o[1] = recovered_85_s[1] ^ recovered_85_co[0];
  assign recovered_85_co[1] = (recovered_85_s[1] & recovered_85_co[0]) | (~recovered_85_s[1] & recovered_85_di[1]);
  assign recovered_85_o[2] = recovered_85_s[2] ^ recovered_85_co[1];
  assign recovered_85_co[2] = (recovered_85_s[2] & recovered_85_co[1]) | (~recovered_85_s[2] & recovered_85_di[2]);
  assign recovered_85_o[3] = recovered_85_s[3] ^ recovered_85_co[2];
  assign recovered_85_co[3] = (recovered_85_s[3] & recovered_85_co[2]) | (~recovered_85_s[3] & recovered_85_di[3]);
  assign esc_add_ln208_117_reg_8333_reg_12_7252cfb [12] = recovered_85_o;

  // Reconstructed CARRY4: esc_add_ln208_120_reg_8365_reg_3__i_1_81a0db6
  wire [3:0] recovered_86_co, recovered_86_o, recovered_86_s, recovered_86_di;
  assign recovered_86_s = {esc_add_ln208_120_reg_8365_3__i_2_n_0_bd4ffd9 ,esc_add_ln208_120_reg_8365_3__i_3_n_0_916e4b1 ,esc_add_ln208_120_reg_8365_3__i_4_n_0_0f0b5d2 ,esc_add_ln208_120_reg_8365_3__i_5_n_0_220cee3 };
  assign recovered_86_di = esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [3:0];
  wire recovered_86_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_86_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_86_o[0] = recovered_86_s[0] ^ (recovered_86_ci || recovered_86_cy);
  assign recovered_86_co[0] = (recovered_86_s[0] & (recovered_86_ci || recovered_86_cy)) | (~recovered_86_s[0] & recovered_86_di[0]);
  assign recovered_86_o[1] = recovered_86_s[1] ^ recovered_86_co[0];
  assign recovered_86_co[1] = (recovered_86_s[1] & recovered_86_co[0]) | (~recovered_86_s[1] & recovered_86_di[1]);
  assign recovered_86_o[2] = recovered_86_s[2] ^ recovered_86_co[1];
  assign recovered_86_co[2] = (recovered_86_s[2] & recovered_86_co[1]) | (~recovered_86_s[2] & recovered_86_di[2]);
  assign recovered_86_o[3] = recovered_86_s[3] ^ recovered_86_co[2];
  assign recovered_86_co[3] = (recovered_86_s[3] & recovered_86_co[2]) | (~recovered_86_s[3] & recovered_86_di[3]);
  assign {esc_add_ln208_120_reg_8365_reg_3__i_1_n_0_0947f49 ,esc_NLW_add_ln208_120_reg_8365_reg_3__i_1_CO_UNCONNECTED_64f2693 [2:0]} = recovered_86_co;
  assign esc_add_ln208_117_reg_8333_reg_12_7252cfb [3:0] = recovered_86_o;

  // Reconstructed CARRY4: esc_add_ln208_120_reg_8365_reg_7__i_1_f536c51
  wire [3:0] recovered_87_co, recovered_87_o, recovered_87_s, recovered_87_di;
  assign recovered_87_s = {esc_add_ln208_120_reg_8365_7__i_2_n_0_7fc5329 ,esc_add_ln208_120_reg_8365_7__i_3_n_0_0123f46 ,esc_add_ln208_120_reg_8365_7__i_4_n_0_8a86106 ,esc_add_ln208_120_reg_8365_7__i_5_n_0_eb71344 };
  assign recovered_87_di = esc_add_ln208_120_reg_8365_reg_12__0_26aac56 [7:4];
  wire recovered_87_ci = ((esc_add_ln208_120_reg_8365_reg_3__i_1_n_0_0947f49) !== 1'bz) && (esc_add_ln208_120_reg_8365_reg_3__i_1_n_0_0947f49);
  wire recovered_87_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_87_o[0] = recovered_87_s[0] ^ (recovered_87_ci || recovered_87_cy);
  assign recovered_87_co[0] = (recovered_87_s[0] & (recovered_87_ci || recovered_87_cy)) | (~recovered_87_s[0] & recovered_87_di[0]);
  assign recovered_87_o[1] = recovered_87_s[1] ^ recovered_87_co[0];
  assign recovered_87_co[1] = (recovered_87_s[1] & recovered_87_co[0]) | (~recovered_87_s[1] & recovered_87_di[1]);
  assign recovered_87_o[2] = recovered_87_s[2] ^ recovered_87_co[1];
  assign recovered_87_co[2] = (recovered_87_s[2] & recovered_87_co[1]) | (~recovered_87_s[2] & recovered_87_di[2]);
  assign recovered_87_o[3] = recovered_87_s[3] ^ recovered_87_co[2];
  assign recovered_87_co[3] = (recovered_87_s[3] & recovered_87_co[2]) | (~recovered_87_s[3] & recovered_87_di[3]);
  assign {esc_add_ln208_120_reg_8365_reg_7__i_1_n_0_0763155 ,esc_NLW_add_ln208_120_reg_8365_reg_7__i_1_CO_UNCONNECTED_80cd018 [2:0]} = recovered_87_co;
  assign esc_add_ln208_117_reg_8333_reg_12_7252cfb [7:4] = recovered_87_o;

  // Reconstructed LUT2: esc_add_ln208_123_reg_8397_3__i_2_9176da3
  assign esc_add_ln208_123_reg_8397_3__i_2_n_0_6bb69fe = ((DOADO[3]) ? (~(esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [3])) : (esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [3]));

  // Reconstructed LUT2: esc_add_ln208_123_reg_8397_3__i_3_c2b1b55
  assign esc_add_ln208_123_reg_8397_3__i_3_n_0_aa929b4 = ((DOADO[2]) ? (~(esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [2])) : (esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [2]));

  // Reconstructed LUT2: esc_add_ln208_123_reg_8397_3__i_4_d5c610f
  assign esc_add_ln208_123_reg_8397_3__i_4_n_0_5716c26 = ((DOADO[1]) ? (~(esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [1])) : (esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [1]));

  // Reconstructed LUT2: esc_add_ln208_123_reg_8397_3__i_5_14e533d
  assign esc_add_ln208_123_reg_8397_3__i_5_n_0_afce416 = ((DOADO[0]) ? (~(esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [0])) : (esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [0]));

  // Reconstructed LUT2: esc_add_ln208_123_reg_8397_7__i_2_325d061
  assign esc_add_ln208_123_reg_8397_7__i_2_n_0_506848a = ((DOADO[7]) ? (~(esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [7])) : (esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [7]));

  // Reconstructed LUT2: esc_add_ln208_123_reg_8397_7__i_3_78d2620
  assign esc_add_ln208_123_reg_8397_7__i_3_n_0_63deae6 = ((DOADO[6]) ? (~(esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [6])) : (esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [6]));

  // Reconstructed LUT2: esc_add_ln208_123_reg_8397_7__i_4_9d3034b
  assign esc_add_ln208_123_reg_8397_7__i_4_n_0_3efddbf = ((DOADO[5]) ? (~(esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [5])) : (esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [5]));

  // Reconstructed LUT2: esc_add_ln208_123_reg_8397_7__i_5_213e06b
  assign esc_add_ln208_123_reg_8397_7__i_5_n_0_a18e72d = ((DOADO[4]) ? (~(esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [4])) : (esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [4]));

  // Reconstructed CARRY4: esc_add_ln208_123_reg_8397_reg_11__i_1_dae033a
  wire [3:0] recovered_96_co, recovered_96_o, recovered_96_s, recovered_96_di;
  assign recovered_96_s = esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [11:8];
  assign recovered_96_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_96_ci = ((esc_add_ln208_123_reg_8397_reg_7__i_1_n_0_0422039) !== 1'bz) && (esc_add_ln208_123_reg_8397_reg_7__i_1_n_0_0422039);
  wire recovered_96_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_96_o[0] = recovered_96_s[0] ^ (recovered_96_ci || recovered_96_cy);
  assign recovered_96_co[0] = (recovered_96_s[0] & (recovered_96_ci || recovered_96_cy)) | (~recovered_96_s[0] & recovered_96_di[0]);
  assign recovered_96_o[1] = recovered_96_s[1] ^ recovered_96_co[0];
  assign recovered_96_co[1] = (recovered_96_s[1] & recovered_96_co[0]) | (~recovered_96_s[1] & recovered_96_di[1]);
  assign recovered_96_o[2] = recovered_96_s[2] ^ recovered_96_co[1];
  assign recovered_96_co[2] = (recovered_96_s[2] & recovered_96_co[1]) | (~recovered_96_s[2] & recovered_96_di[2]);
  assign recovered_96_o[3] = recovered_96_s[3] ^ recovered_96_co[2];
  assign recovered_96_co[3] = (recovered_96_s[3] & recovered_96_co[2]) | (~recovered_96_s[3] & recovered_96_di[3]);
  assign {esc_add_ln208_123_reg_8397_reg_11__i_1_n_0_0a96fef ,esc_NLW_add_ln208_123_reg_8397_reg_11__i_1_CO_UNCONNECTED_3c998bc [2:0]} = recovered_96_co;
  assign esc_add_ln208_120_reg_8365_reg_12_09d1f79 [11:8] = recovered_96_o;

  // Reconstructed CARRY4: esc_add_ln208_123_reg_8397_reg_12__i_1_dc117d4
  wire [3:0] recovered_97_co, recovered_97_o, recovered_97_s, recovered_97_di;
  assign recovered_97_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [12]};
  assign recovered_97_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_97_ci = ((esc_add_ln208_123_reg_8397_reg_11__i_1_n_0_0a96fef) !== 1'bz) && (esc_add_ln208_123_reg_8397_reg_11__i_1_n_0_0a96fef);
  wire recovered_97_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_97_o[0] = recovered_97_s[0] ^ (recovered_97_ci || recovered_97_cy);
  assign recovered_97_co[0] = (recovered_97_s[0] & (recovered_97_ci || recovered_97_cy)) | (~recovered_97_s[0] & recovered_97_di[0]);
  assign recovered_97_o[1] = recovered_97_s[1] ^ recovered_97_co[0];
  assign recovered_97_co[1] = (recovered_97_s[1] & recovered_97_co[0]) | (~recovered_97_s[1] & recovered_97_di[1]);
  assign recovered_97_o[2] = recovered_97_s[2] ^ recovered_97_co[1];
  assign recovered_97_co[2] = (recovered_97_s[2] & recovered_97_co[1]) | (~recovered_97_s[2] & recovered_97_di[2]);
  assign recovered_97_o[3] = recovered_97_s[3] ^ recovered_97_co[2];
  assign recovered_97_co[3] = (recovered_97_s[3] & recovered_97_co[2]) | (~recovered_97_s[3] & recovered_97_di[3]);
  assign esc_add_ln208_120_reg_8365_reg_12_09d1f79 [12] = recovered_97_o;

  // Reconstructed CARRY4: esc_add_ln208_123_reg_8397_reg_3__i_1_92e20f5
  wire [3:0] recovered_98_co, recovered_98_o, recovered_98_s, recovered_98_di;
  assign recovered_98_s = {esc_add_ln208_123_reg_8397_3__i_2_n_0_6bb69fe ,esc_add_ln208_123_reg_8397_3__i_3_n_0_aa929b4 ,esc_add_ln208_123_reg_8397_3__i_4_n_0_5716c26 ,esc_add_ln208_123_reg_8397_3__i_5_n_0_afce416 };
  assign recovered_98_di = esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [3:0];
  wire recovered_98_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_98_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_98_o[0] = recovered_98_s[0] ^ (recovered_98_ci || recovered_98_cy);
  assign recovered_98_co[0] = (recovered_98_s[0] & (recovered_98_ci || recovered_98_cy)) | (~recovered_98_s[0] & recovered_98_di[0]);
  assign recovered_98_o[1] = recovered_98_s[1] ^ recovered_98_co[0];
  assign recovered_98_co[1] = (recovered_98_s[1] & recovered_98_co[0]) | (~recovered_98_s[1] & recovered_98_di[1]);
  assign recovered_98_o[2] = recovered_98_s[2] ^ recovered_98_co[1];
  assign recovered_98_co[2] = (recovered_98_s[2] & recovered_98_co[1]) | (~recovered_98_s[2] & recovered_98_di[2]);
  assign recovered_98_o[3] = recovered_98_s[3] ^ recovered_98_co[2];
  assign recovered_98_co[3] = (recovered_98_s[3] & recovered_98_co[2]) | (~recovered_98_s[3] & recovered_98_di[3]);
  assign {esc_add_ln208_123_reg_8397_reg_3__i_1_n_0_d1a6613 ,esc_NLW_add_ln208_123_reg_8397_reg_3__i_1_CO_UNCONNECTED_f5674c8 [2:0]} = recovered_98_co;
  assign esc_add_ln208_120_reg_8365_reg_12_09d1f79 [3:0] = recovered_98_o;

  // Reconstructed CARRY4: esc_add_ln208_123_reg_8397_reg_7__i_1_73c6bcf
  wire [3:0] recovered_99_co, recovered_99_o, recovered_99_s, recovered_99_di;
  assign recovered_99_s = {esc_add_ln208_123_reg_8397_7__i_2_n_0_506848a ,esc_add_ln208_123_reg_8397_7__i_3_n_0_63deae6 ,esc_add_ln208_123_reg_8397_7__i_4_n_0_3efddbf ,esc_add_ln208_123_reg_8397_7__i_5_n_0_a18e72d };
  assign recovered_99_di = esc_add_ln208_123_reg_8397_reg_12__0_ef529a0 [7:4];
  wire recovered_99_ci = ((esc_add_ln208_123_reg_8397_reg_3__i_1_n_0_d1a6613) !== 1'bz) && (esc_add_ln208_123_reg_8397_reg_3__i_1_n_0_d1a6613);
  wire recovered_99_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_99_o[0] = recovered_99_s[0] ^ (recovered_99_ci || recovered_99_cy);
  assign recovered_99_co[0] = (recovered_99_s[0] & (recovered_99_ci || recovered_99_cy)) | (~recovered_99_s[0] & recovered_99_di[0]);
  assign recovered_99_o[1] = recovered_99_s[1] ^ recovered_99_co[0];
  assign recovered_99_co[1] = (recovered_99_s[1] & recovered_99_co[0]) | (~recovered_99_s[1] & recovered_99_di[1]);
  assign recovered_99_o[2] = recovered_99_s[2] ^ recovered_99_co[1];
  assign recovered_99_co[2] = (recovered_99_s[2] & recovered_99_co[1]) | (~recovered_99_s[2] & recovered_99_di[2]);
  assign recovered_99_o[3] = recovered_99_s[3] ^ recovered_99_co[2];
  assign recovered_99_co[3] = (recovered_99_s[3] & recovered_99_co[2]) | (~recovered_99_s[3] & recovered_99_di[3]);
  assign {esc_add_ln208_123_reg_8397_reg_7__i_1_n_0_0422039 ,esc_NLW_add_ln208_123_reg_8397_reg_7__i_1_CO_UNCONNECTED_a740cd9 [2:0]} = recovered_99_co;
  assign esc_add_ln208_120_reg_8365_reg_12_09d1f79 [7:4] = recovered_99_o;

  // Reconstructed LUT2: esc_add_ln208_126_reg_8429_3__i_2_fc7d141
  assign esc_add_ln208_126_reg_8429_3__i_2_n_0_0d8f1b2 = ((DOADO[3]) ? (~(esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [3])) : (esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [3]));

  // Reconstructed LUT2: esc_add_ln208_126_reg_8429_3__i_3_9b4b01d
  assign esc_add_ln208_126_reg_8429_3__i_3_n_0_a6b1e03 = ((DOADO[2]) ? (~(esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [2])) : (esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [2]));

  // Reconstructed LUT2: esc_add_ln208_126_reg_8429_3__i_4_4ec3570
  assign esc_add_ln208_126_reg_8429_3__i_4_n_0_5e9afd6 = ((DOADO[1]) ? (~(esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [1])) : (esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [1]));

  // Reconstructed LUT2: esc_add_ln208_126_reg_8429_3__i_5_b919569
  assign esc_add_ln208_126_reg_8429_3__i_5_n_0_c10242c = ((DOADO[0]) ? (~(esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [0])) : (esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [0]));

  // Reconstructed LUT2: esc_add_ln208_126_reg_8429_7__i_2_2bff0b3
  assign esc_add_ln208_126_reg_8429_7__i_2_n_0_418989b = ((DOADO[7]) ? (~(esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [7])) : (esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [7]));

  // Reconstructed LUT2: esc_add_ln208_126_reg_8429_7__i_3_de79dcf
  assign esc_add_ln208_126_reg_8429_7__i_3_n_0_f5b0160 = ((DOADO[6]) ? (~(esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [6])) : (esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [6]));

  // Reconstructed LUT2: esc_add_ln208_126_reg_8429_7__i_4_9bea7bd
  assign esc_add_ln208_126_reg_8429_7__i_4_n_0_cb39cdf = ((DOADO[5]) ? (~(esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [5])) : (esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [5]));

  // Reconstructed LUT2: esc_add_ln208_126_reg_8429_7__i_5_fc50407
  assign esc_add_ln208_126_reg_8429_7__i_5_n_0_01a1dc5 = ((DOADO[4]) ? (~(esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [4])) : (esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [4]));

  // Reconstructed CARRY4: esc_add_ln208_126_reg_8429_reg_11__i_1_0c81a05
  wire [3:0] recovered_108_co, recovered_108_o, recovered_108_s, recovered_108_di;
  assign recovered_108_s = esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [11:8];
  assign recovered_108_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_108_ci = ((esc_add_ln208_126_reg_8429_reg_7__i_1_n_0_9e83959) !== 1'bz) && (esc_add_ln208_126_reg_8429_reg_7__i_1_n_0_9e83959);
  wire recovered_108_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_108_o[0] = recovered_108_s[0] ^ (recovered_108_ci || recovered_108_cy);
  assign recovered_108_co[0] = (recovered_108_s[0] & (recovered_108_ci || recovered_108_cy)) | (~recovered_108_s[0] & recovered_108_di[0]);
  assign recovered_108_o[1] = recovered_108_s[1] ^ recovered_108_co[0];
  assign recovered_108_co[1] = (recovered_108_s[1] & recovered_108_co[0]) | (~recovered_108_s[1] & recovered_108_di[1]);
  assign recovered_108_o[2] = recovered_108_s[2] ^ recovered_108_co[1];
  assign recovered_108_co[2] = (recovered_108_s[2] & recovered_108_co[1]) | (~recovered_108_s[2] & recovered_108_di[2]);
  assign recovered_108_o[3] = recovered_108_s[3] ^ recovered_108_co[2];
  assign recovered_108_co[3] = (recovered_108_s[3] & recovered_108_co[2]) | (~recovered_108_s[3] & recovered_108_di[3]);
  assign {esc_add_ln208_126_reg_8429_reg_11__i_1_n_0_420f351 ,esc_NLW_add_ln208_126_reg_8429_reg_11__i_1_CO_UNCONNECTED_99cfc91 [2:0]} = recovered_108_co;
  assign esc_add_ln208_123_reg_8397_reg_12_99743e4 [11:8] = recovered_108_o;

  // Reconstructed CARRY4: esc_add_ln208_126_reg_8429_reg_12__i_1_3ec20b9
  wire [3:0] recovered_109_co, recovered_109_o, recovered_109_s, recovered_109_di;
  assign recovered_109_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [12]};
  assign recovered_109_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_109_ci = ((esc_add_ln208_126_reg_8429_reg_11__i_1_n_0_420f351) !== 1'bz) && (esc_add_ln208_126_reg_8429_reg_11__i_1_n_0_420f351);
  wire recovered_109_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_109_o[0] = recovered_109_s[0] ^ (recovered_109_ci || recovered_109_cy);
  assign recovered_109_co[0] = (recovered_109_s[0] & (recovered_109_ci || recovered_109_cy)) | (~recovered_109_s[0] & recovered_109_di[0]);
  assign recovered_109_o[1] = recovered_109_s[1] ^ recovered_109_co[0];
  assign recovered_109_co[1] = (recovered_109_s[1] & recovered_109_co[0]) | (~recovered_109_s[1] & recovered_109_di[1]);
  assign recovered_109_o[2] = recovered_109_s[2] ^ recovered_109_co[1];
  assign recovered_109_co[2] = (recovered_109_s[2] & recovered_109_co[1]) | (~recovered_109_s[2] & recovered_109_di[2]);
  assign recovered_109_o[3] = recovered_109_s[3] ^ recovered_109_co[2];
  assign recovered_109_co[3] = (recovered_109_s[3] & recovered_109_co[2]) | (~recovered_109_s[3] & recovered_109_di[3]);
  assign esc_add_ln208_123_reg_8397_reg_12_99743e4 [12] = recovered_109_o;

  // Reconstructed CARRY4: esc_add_ln208_126_reg_8429_reg_3__i_1_c306112
  wire [3:0] recovered_110_co, recovered_110_o, recovered_110_s, recovered_110_di;
  assign recovered_110_s = {esc_add_ln208_126_reg_8429_3__i_2_n_0_0d8f1b2 ,esc_add_ln208_126_reg_8429_3__i_3_n_0_a6b1e03 ,esc_add_ln208_126_reg_8429_3__i_4_n_0_5e9afd6 ,esc_add_ln208_126_reg_8429_3__i_5_n_0_c10242c };
  assign recovered_110_di = esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [3:0];
  wire recovered_110_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_110_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_110_o[0] = recovered_110_s[0] ^ (recovered_110_ci || recovered_110_cy);
  assign recovered_110_co[0] = (recovered_110_s[0] & (recovered_110_ci || recovered_110_cy)) | (~recovered_110_s[0] & recovered_110_di[0]);
  assign recovered_110_o[1] = recovered_110_s[1] ^ recovered_110_co[0];
  assign recovered_110_co[1] = (recovered_110_s[1] & recovered_110_co[0]) | (~recovered_110_s[1] & recovered_110_di[1]);
  assign recovered_110_o[2] = recovered_110_s[2] ^ recovered_110_co[1];
  assign recovered_110_co[2] = (recovered_110_s[2] & recovered_110_co[1]) | (~recovered_110_s[2] & recovered_110_di[2]);
  assign recovered_110_o[3] = recovered_110_s[3] ^ recovered_110_co[2];
  assign recovered_110_co[3] = (recovered_110_s[3] & recovered_110_co[2]) | (~recovered_110_s[3] & recovered_110_di[3]);
  assign {esc_add_ln208_126_reg_8429_reg_3__i_1_n_0_18522ef ,esc_NLW_add_ln208_126_reg_8429_reg_3__i_1_CO_UNCONNECTED_7b2ce87 [2:0]} = recovered_110_co;
  assign esc_add_ln208_123_reg_8397_reg_12_99743e4 [3:0] = recovered_110_o;

  // Reconstructed CARRY4: esc_add_ln208_126_reg_8429_reg_7__i_1_3f6bc0a
  wire [3:0] recovered_111_co, recovered_111_o, recovered_111_s, recovered_111_di;
  assign recovered_111_s = {esc_add_ln208_126_reg_8429_7__i_2_n_0_418989b ,esc_add_ln208_126_reg_8429_7__i_3_n_0_f5b0160 ,esc_add_ln208_126_reg_8429_7__i_4_n_0_cb39cdf ,esc_add_ln208_126_reg_8429_7__i_5_n_0_01a1dc5 };
  assign recovered_111_di = esc_add_ln208_126_reg_8429_reg_12__0_aad4ae6 [7:4];
  wire recovered_111_ci = ((esc_add_ln208_126_reg_8429_reg_3__i_1_n_0_18522ef) !== 1'bz) && (esc_add_ln208_126_reg_8429_reg_3__i_1_n_0_18522ef);
  wire recovered_111_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_111_o[0] = recovered_111_s[0] ^ (recovered_111_ci || recovered_111_cy);
  assign recovered_111_co[0] = (recovered_111_s[0] & (recovered_111_ci || recovered_111_cy)) | (~recovered_111_s[0] & recovered_111_di[0]);
  assign recovered_111_o[1] = recovered_111_s[1] ^ recovered_111_co[0];
  assign recovered_111_co[1] = (recovered_111_s[1] & recovered_111_co[0]) | (~recovered_111_s[1] & recovered_111_di[1]);
  assign recovered_111_o[2] = recovered_111_s[2] ^ recovered_111_co[1];
  assign recovered_111_co[2] = (recovered_111_s[2] & recovered_111_co[1]) | (~recovered_111_s[2] & recovered_111_di[2]);
  assign recovered_111_o[3] = recovered_111_s[3] ^ recovered_111_co[2];
  assign recovered_111_co[3] = (recovered_111_s[3] & recovered_111_co[2]) | (~recovered_111_s[3] & recovered_111_di[3]);
  assign {esc_add_ln208_126_reg_8429_reg_7__i_1_n_0_9e83959 ,esc_NLW_add_ln208_126_reg_8429_reg_7__i_1_CO_UNCONNECTED_9dcb955 [2:0]} = recovered_111_co;
  assign esc_add_ln208_123_reg_8397_reg_12_99743e4 [7:4] = recovered_111_o;

  // Reconstructed LUT2: esc_add_ln208_129_reg_8461_3__i_2_1a1f9d7
  assign esc_add_ln208_129_reg_8461_3__i_2_n_0_64b5af6 = ((DOADO[3]) ? (~(esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [3])) : (esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [3]));

  // Reconstructed LUT2: esc_add_ln208_129_reg_8461_3__i_3_f030bee
  assign esc_add_ln208_129_reg_8461_3__i_3_n_0_076f8c2 = ((DOADO[2]) ? (~(esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [2])) : (esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [2]));

  // Reconstructed LUT2: esc_add_ln208_129_reg_8461_3__i_4_79db897
  assign esc_add_ln208_129_reg_8461_3__i_4_n_0_9364254 = ((DOADO[1]) ? (~(esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [1])) : (esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [1]));

  // Reconstructed LUT2: esc_add_ln208_129_reg_8461_3__i_5_09f6725
  assign esc_add_ln208_129_reg_8461_3__i_5_n_0_87bfb39 = ((DOADO[0]) ? (~(esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [0])) : (esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [0]));

  // Reconstructed LUT2: esc_add_ln208_129_reg_8461_7__i_2_12cfee1
  assign esc_add_ln208_129_reg_8461_7__i_2_n_0_2e159a7 = ((DOADO[7]) ? (~(esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [7])) : (esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [7]));

  // Reconstructed LUT2: esc_add_ln208_129_reg_8461_7__i_3_7281df8
  assign esc_add_ln208_129_reg_8461_7__i_3_n_0_b6e1414 = ((DOADO[6]) ? (~(esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [6])) : (esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [6]));

  // Reconstructed LUT2: esc_add_ln208_129_reg_8461_7__i_4_6e73367
  assign esc_add_ln208_129_reg_8461_7__i_4_n_0_c1b3b55 = ((DOADO[5]) ? (~(esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [5])) : (esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [5]));

  // Reconstructed LUT2: esc_add_ln208_129_reg_8461_7__i_5_825767c
  assign esc_add_ln208_129_reg_8461_7__i_5_n_0_63139f3 = ((DOADO[4]) ? (~(esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [4])) : (esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [4]));

  // Reconstructed CARRY4: esc_add_ln208_129_reg_8461_reg_11__i_1_3b1bb1f
  wire [3:0] recovered_120_co, recovered_120_o, recovered_120_s, recovered_120_di;
  assign recovered_120_s = esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [11:8];
  assign recovered_120_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_120_ci = ((esc_add_ln208_129_reg_8461_reg_7__i_1_n_0_23cb280) !== 1'bz) && (esc_add_ln208_129_reg_8461_reg_7__i_1_n_0_23cb280);
  wire recovered_120_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_120_o[0] = recovered_120_s[0] ^ (recovered_120_ci || recovered_120_cy);
  assign recovered_120_co[0] = (recovered_120_s[0] & (recovered_120_ci || recovered_120_cy)) | (~recovered_120_s[0] & recovered_120_di[0]);
  assign recovered_120_o[1] = recovered_120_s[1] ^ recovered_120_co[0];
  assign recovered_120_co[1] = (recovered_120_s[1] & recovered_120_co[0]) | (~recovered_120_s[1] & recovered_120_di[1]);
  assign recovered_120_o[2] = recovered_120_s[2] ^ recovered_120_co[1];
  assign recovered_120_co[2] = (recovered_120_s[2] & recovered_120_co[1]) | (~recovered_120_s[2] & recovered_120_di[2]);
  assign recovered_120_o[3] = recovered_120_s[3] ^ recovered_120_co[2];
  assign recovered_120_co[3] = (recovered_120_s[3] & recovered_120_co[2]) | (~recovered_120_s[3] & recovered_120_di[3]);
  assign {esc_add_ln208_129_reg_8461_reg_11__i_1_n_0_620c427 ,esc_NLW_add_ln208_129_reg_8461_reg_11__i_1_CO_UNCONNECTED_8b1937b [2:0]} = recovered_120_co;
  assign esc_add_ln208_126_reg_8429_reg_12_387655d [11:8] = recovered_120_o;

  // Reconstructed CARRY4: esc_add_ln208_129_reg_8461_reg_12__i_1_388edae
  wire [3:0] recovered_121_co, recovered_121_o, recovered_121_s, recovered_121_di;
  assign recovered_121_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [12]};
  assign recovered_121_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_121_ci = ((esc_add_ln208_129_reg_8461_reg_11__i_1_n_0_620c427) !== 1'bz) && (esc_add_ln208_129_reg_8461_reg_11__i_1_n_0_620c427);
  wire recovered_121_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_121_o[0] = recovered_121_s[0] ^ (recovered_121_ci || recovered_121_cy);
  assign recovered_121_co[0] = (recovered_121_s[0] & (recovered_121_ci || recovered_121_cy)) | (~recovered_121_s[0] & recovered_121_di[0]);
  assign recovered_121_o[1] = recovered_121_s[1] ^ recovered_121_co[0];
  assign recovered_121_co[1] = (recovered_121_s[1] & recovered_121_co[0]) | (~recovered_121_s[1] & recovered_121_di[1]);
  assign recovered_121_o[2] = recovered_121_s[2] ^ recovered_121_co[1];
  assign recovered_121_co[2] = (recovered_121_s[2] & recovered_121_co[1]) | (~recovered_121_s[2] & recovered_121_di[2]);
  assign recovered_121_o[3] = recovered_121_s[3] ^ recovered_121_co[2];
  assign recovered_121_co[3] = (recovered_121_s[3] & recovered_121_co[2]) | (~recovered_121_s[3] & recovered_121_di[3]);
  assign esc_add_ln208_126_reg_8429_reg_12_387655d [12] = recovered_121_o;

  // Reconstructed CARRY4: esc_add_ln208_129_reg_8461_reg_3__i_1_8ea0349
  wire [3:0] recovered_122_co, recovered_122_o, recovered_122_s, recovered_122_di;
  assign recovered_122_s = {esc_add_ln208_129_reg_8461_3__i_2_n_0_64b5af6 ,esc_add_ln208_129_reg_8461_3__i_3_n_0_076f8c2 ,esc_add_ln208_129_reg_8461_3__i_4_n_0_9364254 ,esc_add_ln208_129_reg_8461_3__i_5_n_0_87bfb39 };
  assign recovered_122_di = esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [3:0];
  wire recovered_122_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_122_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_122_o[0] = recovered_122_s[0] ^ (recovered_122_ci || recovered_122_cy);
  assign recovered_122_co[0] = (recovered_122_s[0] & (recovered_122_ci || recovered_122_cy)) | (~recovered_122_s[0] & recovered_122_di[0]);
  assign recovered_122_o[1] = recovered_122_s[1] ^ recovered_122_co[0];
  assign recovered_122_co[1] = (recovered_122_s[1] & recovered_122_co[0]) | (~recovered_122_s[1] & recovered_122_di[1]);
  assign recovered_122_o[2] = recovered_122_s[2] ^ recovered_122_co[1];
  assign recovered_122_co[2] = (recovered_122_s[2] & recovered_122_co[1]) | (~recovered_122_s[2] & recovered_122_di[2]);
  assign recovered_122_o[3] = recovered_122_s[3] ^ recovered_122_co[2];
  assign recovered_122_co[3] = (recovered_122_s[3] & recovered_122_co[2]) | (~recovered_122_s[3] & recovered_122_di[3]);
  assign {esc_add_ln208_129_reg_8461_reg_3__i_1_n_0_a33e088 ,esc_NLW_add_ln208_129_reg_8461_reg_3__i_1_CO_UNCONNECTED_a8db01d [2:0]} = recovered_122_co;
  assign esc_add_ln208_126_reg_8429_reg_12_387655d [3:0] = recovered_122_o;

  // Reconstructed CARRY4: esc_add_ln208_129_reg_8461_reg_7__i_1_0bb1677
  wire [3:0] recovered_123_co, recovered_123_o, recovered_123_s, recovered_123_di;
  assign recovered_123_s = {esc_add_ln208_129_reg_8461_7__i_2_n_0_2e159a7 ,esc_add_ln208_129_reg_8461_7__i_3_n_0_b6e1414 ,esc_add_ln208_129_reg_8461_7__i_4_n_0_c1b3b55 ,esc_add_ln208_129_reg_8461_7__i_5_n_0_63139f3 };
  assign recovered_123_di = esc_add_ln208_129_reg_8461_reg_12__0_c1f8f3a [7:4];
  wire recovered_123_ci = ((esc_add_ln208_129_reg_8461_reg_3__i_1_n_0_a33e088) !== 1'bz) && (esc_add_ln208_129_reg_8461_reg_3__i_1_n_0_a33e088);
  wire recovered_123_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_123_o[0] = recovered_123_s[0] ^ (recovered_123_ci || recovered_123_cy);
  assign recovered_123_co[0] = (recovered_123_s[0] & (recovered_123_ci || recovered_123_cy)) | (~recovered_123_s[0] & recovered_123_di[0]);
  assign recovered_123_o[1] = recovered_123_s[1] ^ recovered_123_co[0];
  assign recovered_123_co[1] = (recovered_123_s[1] & recovered_123_co[0]) | (~recovered_123_s[1] & recovered_123_di[1]);
  assign recovered_123_o[2] = recovered_123_s[2] ^ recovered_123_co[1];
  assign recovered_123_co[2] = (recovered_123_s[2] & recovered_123_co[1]) | (~recovered_123_s[2] & recovered_123_di[2]);
  assign recovered_123_o[3] = recovered_123_s[3] ^ recovered_123_co[2];
  assign recovered_123_co[3] = (recovered_123_s[3] & recovered_123_co[2]) | (~recovered_123_s[3] & recovered_123_di[3]);
  assign {esc_add_ln208_129_reg_8461_reg_7__i_1_n_0_23cb280 ,esc_NLW_add_ln208_129_reg_8461_reg_7__i_1_CO_UNCONNECTED_3fbe12e [2:0]} = recovered_123_co;
  assign esc_add_ln208_126_reg_8429_reg_12_387655d [7:4] = recovered_123_o;

  // Reconstructed LUT2: esc_add_ln208_132_reg_8493_3__i_2_ddc3f6f
  assign esc_add_ln208_132_reg_8493_3__i_2_n_0_cf4b28b = ((DOADO[3]) ? (~(esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [3])) : (esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [3]));

  // Reconstructed LUT2: esc_add_ln208_132_reg_8493_3__i_3_5034e67
  assign esc_add_ln208_132_reg_8493_3__i_3_n_0_58d6e9f = ((DOADO[2]) ? (~(esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [2])) : (esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [2]));

  // Reconstructed LUT2: esc_add_ln208_132_reg_8493_3__i_4_d2b1649
  assign esc_add_ln208_132_reg_8493_3__i_4_n_0_184c09d = ((DOADO[1]) ? (~(esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [1])) : (esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [1]));

  // Reconstructed LUT2: esc_add_ln208_132_reg_8493_3__i_5_975d311
  assign esc_add_ln208_132_reg_8493_3__i_5_n_0_485ac66 = ((DOADO[0]) ? (~(esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [0])) : (esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [0]));

  // Reconstructed LUT2: esc_add_ln208_132_reg_8493_7__i_2_4193fae
  assign esc_add_ln208_132_reg_8493_7__i_2_n_0_90ac4c2 = ((DOADO[7]) ? (~(esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [7])) : (esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [7]));

  // Reconstructed LUT2: esc_add_ln208_132_reg_8493_7__i_3_5f92daf
  assign esc_add_ln208_132_reg_8493_7__i_3_n_0_4f66507 = ((DOADO[6]) ? (~(esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [6])) : (esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [6]));

  // Reconstructed LUT2: esc_add_ln208_132_reg_8493_7__i_4_5ddc4c0
  assign esc_add_ln208_132_reg_8493_7__i_4_n_0_7cf72ea = ((DOADO[5]) ? (~(esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [5])) : (esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [5]));

  // Reconstructed LUT2: esc_add_ln208_132_reg_8493_7__i_5_41f03bd
  assign esc_add_ln208_132_reg_8493_7__i_5_n_0_b797ef2 = ((DOADO[4]) ? (~(esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [4])) : (esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [4]));

  // Reconstructed CARRY4: esc_add_ln208_132_reg_8493_reg_11__i_1_2921fd0
  wire [3:0] recovered_132_co, recovered_132_o, recovered_132_s, recovered_132_di;
  assign recovered_132_s = esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [11:8];
  assign recovered_132_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_132_ci = ((esc_add_ln208_132_reg_8493_reg_7__i_1_n_0_cb5564e) !== 1'bz) && (esc_add_ln208_132_reg_8493_reg_7__i_1_n_0_cb5564e);
  wire recovered_132_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_132_o[0] = recovered_132_s[0] ^ (recovered_132_ci || recovered_132_cy);
  assign recovered_132_co[0] = (recovered_132_s[0] & (recovered_132_ci || recovered_132_cy)) | (~recovered_132_s[0] & recovered_132_di[0]);
  assign recovered_132_o[1] = recovered_132_s[1] ^ recovered_132_co[0];
  assign recovered_132_co[1] = (recovered_132_s[1] & recovered_132_co[0]) | (~recovered_132_s[1] & recovered_132_di[1]);
  assign recovered_132_o[2] = recovered_132_s[2] ^ recovered_132_co[1];
  assign recovered_132_co[2] = (recovered_132_s[2] & recovered_132_co[1]) | (~recovered_132_s[2] & recovered_132_di[2]);
  assign recovered_132_o[3] = recovered_132_s[3] ^ recovered_132_co[2];
  assign recovered_132_co[3] = (recovered_132_s[3] & recovered_132_co[2]) | (~recovered_132_s[3] & recovered_132_di[3]);
  assign {esc_add_ln208_132_reg_8493_reg_11__i_1_n_0_0b984ec ,esc_NLW_add_ln208_132_reg_8493_reg_11__i_1_CO_UNCONNECTED_41d00d3 [2:0]} = recovered_132_co;
  assign esc_add_ln208_129_reg_8461_reg_12_33d91dc [11:8] = recovered_132_o;

  // Reconstructed CARRY4: esc_add_ln208_132_reg_8493_reg_12__i_1_9fb7a6c
  wire [3:0] recovered_133_co, recovered_133_o, recovered_133_s, recovered_133_di;
  assign recovered_133_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [12]};
  assign recovered_133_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_133_ci = ((esc_add_ln208_132_reg_8493_reg_11__i_1_n_0_0b984ec) !== 1'bz) && (esc_add_ln208_132_reg_8493_reg_11__i_1_n_0_0b984ec);
  wire recovered_133_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_133_o[0] = recovered_133_s[0] ^ (recovered_133_ci || recovered_133_cy);
  assign recovered_133_co[0] = (recovered_133_s[0] & (recovered_133_ci || recovered_133_cy)) | (~recovered_133_s[0] & recovered_133_di[0]);
  assign recovered_133_o[1] = recovered_133_s[1] ^ recovered_133_co[0];
  assign recovered_133_co[1] = (recovered_133_s[1] & recovered_133_co[0]) | (~recovered_133_s[1] & recovered_133_di[1]);
  assign recovered_133_o[2] = recovered_133_s[2] ^ recovered_133_co[1];
  assign recovered_133_co[2] = (recovered_133_s[2] & recovered_133_co[1]) | (~recovered_133_s[2] & recovered_133_di[2]);
  assign recovered_133_o[3] = recovered_133_s[3] ^ recovered_133_co[2];
  assign recovered_133_co[3] = (recovered_133_s[3] & recovered_133_co[2]) | (~recovered_133_s[3] & recovered_133_di[3]);
  assign esc_add_ln208_129_reg_8461_reg_12_33d91dc [12] = recovered_133_o;

  // Reconstructed CARRY4: esc_add_ln208_132_reg_8493_reg_3__i_1_2b4e8f0
  wire [3:0] recovered_134_co, recovered_134_o, recovered_134_s, recovered_134_di;
  assign recovered_134_s = {esc_add_ln208_132_reg_8493_3__i_2_n_0_cf4b28b ,esc_add_ln208_132_reg_8493_3__i_3_n_0_58d6e9f ,esc_add_ln208_132_reg_8493_3__i_4_n_0_184c09d ,esc_add_ln208_132_reg_8493_3__i_5_n_0_485ac66 };
  assign recovered_134_di = esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [3:0];
  wire recovered_134_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_134_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_134_o[0] = recovered_134_s[0] ^ (recovered_134_ci || recovered_134_cy);
  assign recovered_134_co[0] = (recovered_134_s[0] & (recovered_134_ci || recovered_134_cy)) | (~recovered_134_s[0] & recovered_134_di[0]);
  assign recovered_134_o[1] = recovered_134_s[1] ^ recovered_134_co[0];
  assign recovered_134_co[1] = (recovered_134_s[1] & recovered_134_co[0]) | (~recovered_134_s[1] & recovered_134_di[1]);
  assign recovered_134_o[2] = recovered_134_s[2] ^ recovered_134_co[1];
  assign recovered_134_co[2] = (recovered_134_s[2] & recovered_134_co[1]) | (~recovered_134_s[2] & recovered_134_di[2]);
  assign recovered_134_o[3] = recovered_134_s[3] ^ recovered_134_co[2];
  assign recovered_134_co[3] = (recovered_134_s[3] & recovered_134_co[2]) | (~recovered_134_s[3] & recovered_134_di[3]);
  assign {esc_add_ln208_132_reg_8493_reg_3__i_1_n_0_7a4606d ,esc_NLW_add_ln208_132_reg_8493_reg_3__i_1_CO_UNCONNECTED_61d18af [2:0]} = recovered_134_co;
  assign esc_add_ln208_129_reg_8461_reg_12_33d91dc [3:0] = recovered_134_o;

  // Reconstructed CARRY4: esc_add_ln208_132_reg_8493_reg_7__i_1_ac21dff
  wire [3:0] recovered_135_co, recovered_135_o, recovered_135_s, recovered_135_di;
  assign recovered_135_s = {esc_add_ln208_132_reg_8493_7__i_2_n_0_90ac4c2 ,esc_add_ln208_132_reg_8493_7__i_3_n_0_4f66507 ,esc_add_ln208_132_reg_8493_7__i_4_n_0_7cf72ea ,esc_add_ln208_132_reg_8493_7__i_5_n_0_b797ef2 };
  assign recovered_135_di = esc_add_ln208_132_reg_8493_reg_12__0_1f22523 [7:4];
  wire recovered_135_ci = ((esc_add_ln208_132_reg_8493_reg_3__i_1_n_0_7a4606d) !== 1'bz) && (esc_add_ln208_132_reg_8493_reg_3__i_1_n_0_7a4606d);
  wire recovered_135_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_135_o[0] = recovered_135_s[0] ^ (recovered_135_ci || recovered_135_cy);
  assign recovered_135_co[0] = (recovered_135_s[0] & (recovered_135_ci || recovered_135_cy)) | (~recovered_135_s[0] & recovered_135_di[0]);
  assign recovered_135_o[1] = recovered_135_s[1] ^ recovered_135_co[0];
  assign recovered_135_co[1] = (recovered_135_s[1] & recovered_135_co[0]) | (~recovered_135_s[1] & recovered_135_di[1]);
  assign recovered_135_o[2] = recovered_135_s[2] ^ recovered_135_co[1];
  assign recovered_135_co[2] = (recovered_135_s[2] & recovered_135_co[1]) | (~recovered_135_s[2] & recovered_135_di[2]);
  assign recovered_135_o[3] = recovered_135_s[3] ^ recovered_135_co[2];
  assign recovered_135_co[3] = (recovered_135_s[3] & recovered_135_co[2]) | (~recovered_135_s[3] & recovered_135_di[3]);
  assign {esc_add_ln208_132_reg_8493_reg_7__i_1_n_0_cb5564e ,esc_NLW_add_ln208_132_reg_8493_reg_7__i_1_CO_UNCONNECTED_bdcfd20 [2:0]} = recovered_135_co;
  assign esc_add_ln208_129_reg_8461_reg_12_33d91dc [7:4] = recovered_135_o;

  // Reconstructed LUT2: esc_add_ln208_135_reg_8525_3__i_2_182e761
  assign esc_add_ln208_135_reg_8525_3__i_2_n_0_a26cc01 = ((DOADO[3]) ? (~(esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [3])) : (esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [3]));

  // Reconstructed LUT2: esc_add_ln208_135_reg_8525_3__i_3_9c9f17c
  assign esc_add_ln208_135_reg_8525_3__i_3_n_0_5c3ee2b = ((DOADO[2]) ? (~(esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [2])) : (esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [2]));

  // Reconstructed LUT2: esc_add_ln208_135_reg_8525_3__i_4_27b4883
  assign esc_add_ln208_135_reg_8525_3__i_4_n_0_484ede1 = ((DOADO[1]) ? (~(esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [1])) : (esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [1]));

  // Reconstructed LUT2: esc_add_ln208_135_reg_8525_3__i_5_f6caf22
  assign esc_add_ln208_135_reg_8525_3__i_5_n_0_0c83946 = ((DOADO[0]) ? (~(esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [0])) : (esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [0]));

  // Reconstructed LUT2: esc_add_ln208_135_reg_8525_7__i_2_b17c15c
  assign esc_add_ln208_135_reg_8525_7__i_2_n_0_5bcd7b3 = ((DOADO[7]) ? (~(esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [7])) : (esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [7]));

  // Reconstructed LUT2: esc_add_ln208_135_reg_8525_7__i_3_81f4663
  assign esc_add_ln208_135_reg_8525_7__i_3_n_0_7cc9628 = ((DOADO[6]) ? (~(esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [6])) : (esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [6]));

  // Reconstructed LUT2: esc_add_ln208_135_reg_8525_7__i_4_bfd4322
  assign esc_add_ln208_135_reg_8525_7__i_4_n_0_f4c6e57 = ((DOADO[5]) ? (~(esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [5])) : (esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [5]));

  // Reconstructed LUT2: esc_add_ln208_135_reg_8525_7__i_5_f8547f7
  assign esc_add_ln208_135_reg_8525_7__i_5_n_0_69f136b = ((DOADO[4]) ? (~(esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [4])) : (esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [4]));

  // Reconstructed CARRY4: esc_add_ln208_135_reg_8525_reg_11__i_1_6765753
  wire [3:0] recovered_144_co, recovered_144_o, recovered_144_s, recovered_144_di;
  assign recovered_144_s = esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [11:8];
  assign recovered_144_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_144_ci = ((esc_add_ln208_135_reg_8525_reg_7__i_1_n_0_60dbe1f) !== 1'bz) && (esc_add_ln208_135_reg_8525_reg_7__i_1_n_0_60dbe1f);
  wire recovered_144_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_144_o[0] = recovered_144_s[0] ^ (recovered_144_ci || recovered_144_cy);
  assign recovered_144_co[0] = (recovered_144_s[0] & (recovered_144_ci || recovered_144_cy)) | (~recovered_144_s[0] & recovered_144_di[0]);
  assign recovered_144_o[1] = recovered_144_s[1] ^ recovered_144_co[0];
  assign recovered_144_co[1] = (recovered_144_s[1] & recovered_144_co[0]) | (~recovered_144_s[1] & recovered_144_di[1]);
  assign recovered_144_o[2] = recovered_144_s[2] ^ recovered_144_co[1];
  assign recovered_144_co[2] = (recovered_144_s[2] & recovered_144_co[1]) | (~recovered_144_s[2] & recovered_144_di[2]);
  assign recovered_144_o[3] = recovered_144_s[3] ^ recovered_144_co[2];
  assign recovered_144_co[3] = (recovered_144_s[3] & recovered_144_co[2]) | (~recovered_144_s[3] & recovered_144_di[3]);
  assign {esc_add_ln208_135_reg_8525_reg_11__i_1_n_0_66514c1 ,esc_NLW_add_ln208_135_reg_8525_reg_11__i_1_CO_UNCONNECTED_f80f88b [2:0]} = recovered_144_co;
  assign esc_add_ln208_132_reg_8493_reg_12_7e23985 [11:8] = recovered_144_o;

  // Reconstructed CARRY4: esc_add_ln208_135_reg_8525_reg_13__i_1_3fb1d78
  wire [3:0] recovered_145_co, recovered_145_o, recovered_145_s, recovered_145_di;
  assign recovered_145_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 ,esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [12]};
  assign recovered_145_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_145_ci = ((esc_add_ln208_135_reg_8525_reg_11__i_1_n_0_66514c1) !== 1'bz) && (esc_add_ln208_135_reg_8525_reg_11__i_1_n_0_66514c1);
  wire recovered_145_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_145_o[0] = recovered_145_s[0] ^ (recovered_145_ci || recovered_145_cy);
  assign recovered_145_co[0] = (recovered_145_s[0] & (recovered_145_ci || recovered_145_cy)) | (~recovered_145_s[0] & recovered_145_di[0]);
  assign recovered_145_o[1] = recovered_145_s[1] ^ recovered_145_co[0];
  assign recovered_145_co[1] = (recovered_145_s[1] & recovered_145_co[0]) | (~recovered_145_s[1] & recovered_145_di[1]);
  assign recovered_145_o[2] = recovered_145_s[2] ^ recovered_145_co[1];
  assign recovered_145_co[2] = (recovered_145_s[2] & recovered_145_co[1]) | (~recovered_145_s[2] & recovered_145_di[2]);
  assign recovered_145_o[3] = recovered_145_s[3] ^ recovered_145_co[2];
  assign recovered_145_co[3] = (recovered_145_s[3] & recovered_145_co[2]) | (~recovered_145_s[3] & recovered_145_di[3]);
  assign {esc_add_ln208_132_reg_8493_reg_12_7e23985 [13],esc_NLW_add_ln208_135_reg_8525_reg_13__i_1_CO_UNCONNECTED_99904a1 [0]} = recovered_145_co;
  assign esc_add_ln208_132_reg_8493_reg_12_7e23985 [12] = recovered_145_o;

  // Reconstructed CARRY4: esc_add_ln208_135_reg_8525_reg_3__i_1_cad59ca
  wire [3:0] recovered_146_co, recovered_146_o, recovered_146_s, recovered_146_di;
  assign recovered_146_s = {esc_add_ln208_135_reg_8525_3__i_2_n_0_a26cc01 ,esc_add_ln208_135_reg_8525_3__i_3_n_0_5c3ee2b ,esc_add_ln208_135_reg_8525_3__i_4_n_0_484ede1 ,esc_add_ln208_135_reg_8525_3__i_5_n_0_0c83946 };
  assign recovered_146_di = esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [3:0];
  wire recovered_146_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_146_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_146_o[0] = recovered_146_s[0] ^ (recovered_146_ci || recovered_146_cy);
  assign recovered_146_co[0] = (recovered_146_s[0] & (recovered_146_ci || recovered_146_cy)) | (~recovered_146_s[0] & recovered_146_di[0]);
  assign recovered_146_o[1] = recovered_146_s[1] ^ recovered_146_co[0];
  assign recovered_146_co[1] = (recovered_146_s[1] & recovered_146_co[0]) | (~recovered_146_s[1] & recovered_146_di[1]);
  assign recovered_146_o[2] = recovered_146_s[2] ^ recovered_146_co[1];
  assign recovered_146_co[2] = (recovered_146_s[2] & recovered_146_co[1]) | (~recovered_146_s[2] & recovered_146_di[2]);
  assign recovered_146_o[3] = recovered_146_s[3] ^ recovered_146_co[2];
  assign recovered_146_co[3] = (recovered_146_s[3] & recovered_146_co[2]) | (~recovered_146_s[3] & recovered_146_di[3]);
  assign {esc_add_ln208_135_reg_8525_reg_3__i_1_n_0_170acf0 ,esc_NLW_add_ln208_135_reg_8525_reg_3__i_1_CO_UNCONNECTED_78d520a [2:0]} = recovered_146_co;
  assign esc_add_ln208_132_reg_8493_reg_12_7e23985 [3:0] = recovered_146_o;

  // Reconstructed CARRY4: esc_add_ln208_135_reg_8525_reg_7__i_1_c6660c9
  wire [3:0] recovered_147_co, recovered_147_o, recovered_147_s, recovered_147_di;
  assign recovered_147_s = {esc_add_ln208_135_reg_8525_7__i_2_n_0_5bcd7b3 ,esc_add_ln208_135_reg_8525_7__i_3_n_0_7cc9628 ,esc_add_ln208_135_reg_8525_7__i_4_n_0_f4c6e57 ,esc_add_ln208_135_reg_8525_7__i_5_n_0_69f136b };
  assign recovered_147_di = esc_add_ln208_135_reg_8525_reg_13__0_a12ba46 [7:4];
  wire recovered_147_ci = ((esc_add_ln208_135_reg_8525_reg_3__i_1_n_0_170acf0) !== 1'bz) && (esc_add_ln208_135_reg_8525_reg_3__i_1_n_0_170acf0);
  wire recovered_147_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_147_o[0] = recovered_147_s[0] ^ (recovered_147_ci || recovered_147_cy);
  assign recovered_147_co[0] = (recovered_147_s[0] & (recovered_147_ci || recovered_147_cy)) | (~recovered_147_s[0] & recovered_147_di[0]);
  assign recovered_147_o[1] = recovered_147_s[1] ^ recovered_147_co[0];
  assign recovered_147_co[1] = (recovered_147_s[1] & recovered_147_co[0]) | (~recovered_147_s[1] & recovered_147_di[1]);
  assign recovered_147_o[2] = recovered_147_s[2] ^ recovered_147_co[1];
  assign recovered_147_co[2] = (recovered_147_s[2] & recovered_147_co[1]) | (~recovered_147_s[2] & recovered_147_di[2]);
  assign recovered_147_o[3] = recovered_147_s[3] ^ recovered_147_co[2];
  assign recovered_147_co[3] = (recovered_147_s[3] & recovered_147_co[2]) | (~recovered_147_s[3] & recovered_147_di[3]);
  assign {esc_add_ln208_135_reg_8525_reg_7__i_1_n_0_60dbe1f ,esc_NLW_add_ln208_135_reg_8525_reg_7__i_1_CO_UNCONNECTED_c9cf2f7 [2:0]} = recovered_147_co;
  assign esc_add_ln208_132_reg_8493_reg_12_7e23985 [7:4] = recovered_147_o;

  // Reconstructed LUT2: esc_add_ln208_138_reg_8557_3__i_2_25aa2ba
  assign esc_add_ln208_138_reg_8557_3__i_2_n_0_ba5be80 = ((DOADO[3]) ? (~(esc_add_ln208_138_reg_8557_reg_13__0_862abfd [3])) : (esc_add_ln208_138_reg_8557_reg_13__0_862abfd [3]));

  // Reconstructed LUT2: esc_add_ln208_138_reg_8557_3__i_3_a0abc99
  assign esc_add_ln208_138_reg_8557_3__i_3_n_0_9d799da = ((DOADO[2]) ? (~(esc_add_ln208_138_reg_8557_reg_13__0_862abfd [2])) : (esc_add_ln208_138_reg_8557_reg_13__0_862abfd [2]));

  // Reconstructed LUT2: esc_add_ln208_138_reg_8557_3__i_4_6cdc037
  assign esc_add_ln208_138_reg_8557_3__i_4_n_0_c715d7c = ((DOADO[1]) ? (~(esc_add_ln208_138_reg_8557_reg_13__0_862abfd [1])) : (esc_add_ln208_138_reg_8557_reg_13__0_862abfd [1]));

  // Reconstructed LUT2: esc_add_ln208_138_reg_8557_3__i_5_225bf43
  assign esc_add_ln208_138_reg_8557_3__i_5_n_0_3f73d01 = ((DOADO[0]) ? (~(esc_add_ln208_138_reg_8557_reg_13__0_862abfd [0])) : (esc_add_ln208_138_reg_8557_reg_13__0_862abfd [0]));

  // Reconstructed LUT2: esc_add_ln208_138_reg_8557_7__i_2_8c00ff0
  assign esc_add_ln208_138_reg_8557_7__i_2_n_0_9ef0265 = ((DOADO[7]) ? (~(esc_add_ln208_138_reg_8557_reg_13__0_862abfd [7])) : (esc_add_ln208_138_reg_8557_reg_13__0_862abfd [7]));

  // Reconstructed LUT2: esc_add_ln208_138_reg_8557_7__i_3_d638a71
  assign esc_add_ln208_138_reg_8557_7__i_3_n_0_dc36649 = ((DOADO[6]) ? (~(esc_add_ln208_138_reg_8557_reg_13__0_862abfd [6])) : (esc_add_ln208_138_reg_8557_reg_13__0_862abfd [6]));

  // Reconstructed LUT2: esc_add_ln208_138_reg_8557_7__i_4_cf4ad1a
  assign esc_add_ln208_138_reg_8557_7__i_4_n_0_639b026 = ((DOADO[5]) ? (~(esc_add_ln208_138_reg_8557_reg_13__0_862abfd [5])) : (esc_add_ln208_138_reg_8557_reg_13__0_862abfd [5]));

  // Reconstructed LUT2: esc_add_ln208_138_reg_8557_7__i_5_1b0294d
  assign esc_add_ln208_138_reg_8557_7__i_5_n_0_6eda6bb = ((DOADO[4]) ? (~(esc_add_ln208_138_reg_8557_reg_13__0_862abfd [4])) : (esc_add_ln208_138_reg_8557_reg_13__0_862abfd [4]));

  // Reconstructed CARRY4: esc_add_ln208_138_reg_8557_reg_11__i_1_07adcd7
  wire [3:0] recovered_156_co, recovered_156_o, recovered_156_s, recovered_156_di;
  assign recovered_156_s = esc_add_ln208_138_reg_8557_reg_13__0_862abfd [11:8];
  assign recovered_156_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_156_ci = ((esc_add_ln208_138_reg_8557_reg_7__i_1_n_0_fbe824d) !== 1'bz) && (esc_add_ln208_138_reg_8557_reg_7__i_1_n_0_fbe824d);
  wire recovered_156_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_156_o[0] = recovered_156_s[0] ^ (recovered_156_ci || recovered_156_cy);
  assign recovered_156_co[0] = (recovered_156_s[0] & (recovered_156_ci || recovered_156_cy)) | (~recovered_156_s[0] & recovered_156_di[0]);
  assign recovered_156_o[1] = recovered_156_s[1] ^ recovered_156_co[0];
  assign recovered_156_co[1] = (recovered_156_s[1] & recovered_156_co[0]) | (~recovered_156_s[1] & recovered_156_di[1]);
  assign recovered_156_o[2] = recovered_156_s[2] ^ recovered_156_co[1];
  assign recovered_156_co[2] = (recovered_156_s[2] & recovered_156_co[1]) | (~recovered_156_s[2] & recovered_156_di[2]);
  assign recovered_156_o[3] = recovered_156_s[3] ^ recovered_156_co[2];
  assign recovered_156_co[3] = (recovered_156_s[3] & recovered_156_co[2]) | (~recovered_156_s[3] & recovered_156_di[3]);
  assign {esc_add_ln208_138_reg_8557_reg_11__i_1_n_0_7ebbbf2 ,esc_NLW_add_ln208_138_reg_8557_reg_11__i_1_CO_UNCONNECTED_9545c13 [2:0]} = recovered_156_co;
  assign esc_add_ln208_135_reg_8525_reg_13_7810c12 [11:8] = recovered_156_o;

  // Reconstructed CARRY4: esc_add_ln208_138_reg_8557_reg_13__i_1_68344f0
  wire [3:0] recovered_157_co, recovered_157_o, recovered_157_s, recovered_157_di;
  assign recovered_157_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_138_reg_8557_reg_13__0_862abfd [13:12]};
  assign recovered_157_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_157_ci = ((esc_add_ln208_138_reg_8557_reg_11__i_1_n_0_7ebbbf2) !== 1'bz) && (esc_add_ln208_138_reg_8557_reg_11__i_1_n_0_7ebbbf2);
  wire recovered_157_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_157_o[0] = recovered_157_s[0] ^ (recovered_157_ci || recovered_157_cy);
  assign recovered_157_co[0] = (recovered_157_s[0] & (recovered_157_ci || recovered_157_cy)) | (~recovered_157_s[0] & recovered_157_di[0]);
  assign recovered_157_o[1] = recovered_157_s[1] ^ recovered_157_co[0];
  assign recovered_157_co[1] = (recovered_157_s[1] & recovered_157_co[0]) | (~recovered_157_s[1] & recovered_157_di[1]);
  assign recovered_157_o[2] = recovered_157_s[2] ^ recovered_157_co[1];
  assign recovered_157_co[2] = (recovered_157_s[2] & recovered_157_co[1]) | (~recovered_157_s[2] & recovered_157_di[2]);
  assign recovered_157_o[3] = recovered_157_s[3] ^ recovered_157_co[2];
  assign recovered_157_co[3] = (recovered_157_s[3] & recovered_157_co[2]) | (~recovered_157_s[3] & recovered_157_di[3]);
  assign esc_add_ln208_135_reg_8525_reg_13_7810c12 [13:12] = recovered_157_o;

  // Reconstructed CARRY4: esc_add_ln208_138_reg_8557_reg_3__i_1_fe4dc6a
  wire [3:0] recovered_158_co, recovered_158_o, recovered_158_s, recovered_158_di;
  assign recovered_158_s = {esc_add_ln208_138_reg_8557_3__i_2_n_0_ba5be80 ,esc_add_ln208_138_reg_8557_3__i_3_n_0_9d799da ,esc_add_ln208_138_reg_8557_3__i_4_n_0_c715d7c ,esc_add_ln208_138_reg_8557_3__i_5_n_0_3f73d01 };
  assign recovered_158_di = esc_add_ln208_138_reg_8557_reg_13__0_862abfd [3:0];
  wire recovered_158_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_158_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_158_o[0] = recovered_158_s[0] ^ (recovered_158_ci || recovered_158_cy);
  assign recovered_158_co[0] = (recovered_158_s[0] & (recovered_158_ci || recovered_158_cy)) | (~recovered_158_s[0] & recovered_158_di[0]);
  assign recovered_158_o[1] = recovered_158_s[1] ^ recovered_158_co[0];
  assign recovered_158_co[1] = (recovered_158_s[1] & recovered_158_co[0]) | (~recovered_158_s[1] & recovered_158_di[1]);
  assign recovered_158_o[2] = recovered_158_s[2] ^ recovered_158_co[1];
  assign recovered_158_co[2] = (recovered_158_s[2] & recovered_158_co[1]) | (~recovered_158_s[2] & recovered_158_di[2]);
  assign recovered_158_o[3] = recovered_158_s[3] ^ recovered_158_co[2];
  assign recovered_158_co[3] = (recovered_158_s[3] & recovered_158_co[2]) | (~recovered_158_s[3] & recovered_158_di[3]);
  assign {esc_add_ln208_138_reg_8557_reg_3__i_1_n_0_3285e94 ,esc_NLW_add_ln208_138_reg_8557_reg_3__i_1_CO_UNCONNECTED_1104100 [2:0]} = recovered_158_co;
  assign esc_add_ln208_135_reg_8525_reg_13_7810c12 [3:0] = recovered_158_o;

  // Reconstructed CARRY4: esc_add_ln208_138_reg_8557_reg_7__i_1_d12d970
  wire [3:0] recovered_159_co, recovered_159_o, recovered_159_s, recovered_159_di;
  assign recovered_159_s = {esc_add_ln208_138_reg_8557_7__i_2_n_0_9ef0265 ,esc_add_ln208_138_reg_8557_7__i_3_n_0_dc36649 ,esc_add_ln208_138_reg_8557_7__i_4_n_0_639b026 ,esc_add_ln208_138_reg_8557_7__i_5_n_0_6eda6bb };
  assign recovered_159_di = esc_add_ln208_138_reg_8557_reg_13__0_862abfd [7:4];
  wire recovered_159_ci = ((esc_add_ln208_138_reg_8557_reg_3__i_1_n_0_3285e94) !== 1'bz) && (esc_add_ln208_138_reg_8557_reg_3__i_1_n_0_3285e94);
  wire recovered_159_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_159_o[0] = recovered_159_s[0] ^ (recovered_159_ci || recovered_159_cy);
  assign recovered_159_co[0] = (recovered_159_s[0] & (recovered_159_ci || recovered_159_cy)) | (~recovered_159_s[0] & recovered_159_di[0]);
  assign recovered_159_o[1] = recovered_159_s[1] ^ recovered_159_co[0];
  assign recovered_159_co[1] = (recovered_159_s[1] & recovered_159_co[0]) | (~recovered_159_s[1] & recovered_159_di[1]);
  assign recovered_159_o[2] = recovered_159_s[2] ^ recovered_159_co[1];
  assign recovered_159_co[2] = (recovered_159_s[2] & recovered_159_co[1]) | (~recovered_159_s[2] & recovered_159_di[2]);
  assign recovered_159_o[3] = recovered_159_s[3] ^ recovered_159_co[2];
  assign recovered_159_co[3] = (recovered_159_s[3] & recovered_159_co[2]) | (~recovered_159_s[3] & recovered_159_di[3]);
  assign {esc_add_ln208_138_reg_8557_reg_7__i_1_n_0_fbe824d ,esc_NLW_add_ln208_138_reg_8557_reg_7__i_1_CO_UNCONNECTED_d60f5ba [2:0]} = recovered_159_co;
  assign esc_add_ln208_135_reg_8525_reg_13_7810c12 [7:4] = recovered_159_o;

  // Reconstructed LUT2: esc_add_ln208_141_reg_8589_3__i_2_68bdd3b
  assign esc_add_ln208_141_reg_8589_3__i_2_n_0_42ac8a8 = ((DOADO[3]) ? (~(esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [3])) : (esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [3]));

  // Reconstructed LUT2: esc_add_ln208_141_reg_8589_3__i_3_423d8a4
  assign esc_add_ln208_141_reg_8589_3__i_3_n_0_fe1b613 = ((DOADO[2]) ? (~(esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [2])) : (esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [2]));

  // Reconstructed LUT2: esc_add_ln208_141_reg_8589_3__i_4_96d2c45
  assign esc_add_ln208_141_reg_8589_3__i_4_n_0_b721015 = ((DOADO[1]) ? (~(esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [1])) : (esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [1]));

  // Reconstructed LUT2: esc_add_ln208_141_reg_8589_3__i_5_11888a9
  assign esc_add_ln208_141_reg_8589_3__i_5_n_0_8b403a6 = ((DOADO[0]) ? (~(esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [0])) : (esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [0]));

  // Reconstructed LUT2: esc_add_ln208_141_reg_8589_7__i_2_7a54a14
  assign esc_add_ln208_141_reg_8589_7__i_2_n_0_c2d81de = ((DOADO[7]) ? (~(esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [7])) : (esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [7]));

  // Reconstructed LUT2: esc_add_ln208_141_reg_8589_7__i_3_ea99a88
  assign esc_add_ln208_141_reg_8589_7__i_3_n_0_d4b62fc = ((DOADO[6]) ? (~(esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [6])) : (esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [6]));

  // Reconstructed LUT2: esc_add_ln208_141_reg_8589_7__i_4_5dc85d2
  assign esc_add_ln208_141_reg_8589_7__i_4_n_0_86c4805 = ((DOADO[5]) ? (~(esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [5])) : (esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [5]));

  // Reconstructed LUT2: esc_add_ln208_141_reg_8589_7__i_5_5400aa9
  assign esc_add_ln208_141_reg_8589_7__i_5_n_0_4378a21 = ((DOADO[4]) ? (~(esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [4])) : (esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [4]));

  // Reconstructed CARRY4: esc_add_ln208_141_reg_8589_reg_11__i_1_62f2a69
  wire [3:0] recovered_168_co, recovered_168_o, recovered_168_s, recovered_168_di;
  assign recovered_168_s = esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [11:8];
  assign recovered_168_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_168_ci = ((esc_add_ln208_141_reg_8589_reg_7__i_1_n_0_9e26169) !== 1'bz) && (esc_add_ln208_141_reg_8589_reg_7__i_1_n_0_9e26169);
  wire recovered_168_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_168_o[0] = recovered_168_s[0] ^ (recovered_168_ci || recovered_168_cy);
  assign recovered_168_co[0] = (recovered_168_s[0] & (recovered_168_ci || recovered_168_cy)) | (~recovered_168_s[0] & recovered_168_di[0]);
  assign recovered_168_o[1] = recovered_168_s[1] ^ recovered_168_co[0];
  assign recovered_168_co[1] = (recovered_168_s[1] & recovered_168_co[0]) | (~recovered_168_s[1] & recovered_168_di[1]);
  assign recovered_168_o[2] = recovered_168_s[2] ^ recovered_168_co[1];
  assign recovered_168_co[2] = (recovered_168_s[2] & recovered_168_co[1]) | (~recovered_168_s[2] & recovered_168_di[2]);
  assign recovered_168_o[3] = recovered_168_s[3] ^ recovered_168_co[2];
  assign recovered_168_co[3] = (recovered_168_s[3] & recovered_168_co[2]) | (~recovered_168_s[3] & recovered_168_di[3]);
  assign {esc_add_ln208_141_reg_8589_reg_11__i_1_n_0_524a38b ,esc_NLW_add_ln208_141_reg_8589_reg_11__i_1_CO_UNCONNECTED_6c4fea3 [2:0]} = recovered_168_co;
  assign esc_add_ln208_138_reg_8557_reg_13_7e0af06 [11:8] = recovered_168_o;

  // Reconstructed CARRY4: esc_add_ln208_141_reg_8589_reg_13__i_1_4f15a16
  wire [3:0] recovered_169_co, recovered_169_o, recovered_169_s, recovered_169_di;
  assign recovered_169_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [13:12]};
  assign recovered_169_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_169_ci = ((esc_add_ln208_141_reg_8589_reg_11__i_1_n_0_524a38b) !== 1'bz) && (esc_add_ln208_141_reg_8589_reg_11__i_1_n_0_524a38b);
  wire recovered_169_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_169_o[0] = recovered_169_s[0] ^ (recovered_169_ci || recovered_169_cy);
  assign recovered_169_co[0] = (recovered_169_s[0] & (recovered_169_ci || recovered_169_cy)) | (~recovered_169_s[0] & recovered_169_di[0]);
  assign recovered_169_o[1] = recovered_169_s[1] ^ recovered_169_co[0];
  assign recovered_169_co[1] = (recovered_169_s[1] & recovered_169_co[0]) | (~recovered_169_s[1] & recovered_169_di[1]);
  assign recovered_169_o[2] = recovered_169_s[2] ^ recovered_169_co[1];
  assign recovered_169_co[2] = (recovered_169_s[2] & recovered_169_co[1]) | (~recovered_169_s[2] & recovered_169_di[2]);
  assign recovered_169_o[3] = recovered_169_s[3] ^ recovered_169_co[2];
  assign recovered_169_co[3] = (recovered_169_s[3] & recovered_169_co[2]) | (~recovered_169_s[3] & recovered_169_di[3]);
  assign esc_add_ln208_138_reg_8557_reg_13_7e0af06 [13:12] = recovered_169_o;

  // Reconstructed CARRY4: esc_add_ln208_141_reg_8589_reg_3__i_1_24c7cd5
  wire [3:0] recovered_170_co, recovered_170_o, recovered_170_s, recovered_170_di;
  assign recovered_170_s = {esc_add_ln208_141_reg_8589_3__i_2_n_0_42ac8a8 ,esc_add_ln208_141_reg_8589_3__i_3_n_0_fe1b613 ,esc_add_ln208_141_reg_8589_3__i_4_n_0_b721015 ,esc_add_ln208_141_reg_8589_3__i_5_n_0_8b403a6 };
  assign recovered_170_di = esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [3:0];
  wire recovered_170_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_170_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_170_o[0] = recovered_170_s[0] ^ (recovered_170_ci || recovered_170_cy);
  assign recovered_170_co[0] = (recovered_170_s[0] & (recovered_170_ci || recovered_170_cy)) | (~recovered_170_s[0] & recovered_170_di[0]);
  assign recovered_170_o[1] = recovered_170_s[1] ^ recovered_170_co[0];
  assign recovered_170_co[1] = (recovered_170_s[1] & recovered_170_co[0]) | (~recovered_170_s[1] & recovered_170_di[1]);
  assign recovered_170_o[2] = recovered_170_s[2] ^ recovered_170_co[1];
  assign recovered_170_co[2] = (recovered_170_s[2] & recovered_170_co[1]) | (~recovered_170_s[2] & recovered_170_di[2]);
  assign recovered_170_o[3] = recovered_170_s[3] ^ recovered_170_co[2];
  assign recovered_170_co[3] = (recovered_170_s[3] & recovered_170_co[2]) | (~recovered_170_s[3] & recovered_170_di[3]);
  assign {esc_add_ln208_141_reg_8589_reg_3__i_1_n_0_edebe90 ,esc_NLW_add_ln208_141_reg_8589_reg_3__i_1_CO_UNCONNECTED_d9cdde8 [2:0]} = recovered_170_co;
  assign esc_add_ln208_138_reg_8557_reg_13_7e0af06 [3:0] = recovered_170_o;

  // Reconstructed CARRY4: esc_add_ln208_141_reg_8589_reg_7__i_1_3a24183
  wire [3:0] recovered_171_co, recovered_171_o, recovered_171_s, recovered_171_di;
  assign recovered_171_s = {esc_add_ln208_141_reg_8589_7__i_2_n_0_c2d81de ,esc_add_ln208_141_reg_8589_7__i_3_n_0_d4b62fc ,esc_add_ln208_141_reg_8589_7__i_4_n_0_86c4805 ,esc_add_ln208_141_reg_8589_7__i_5_n_0_4378a21 };
  assign recovered_171_di = esc_add_ln208_141_reg_8589_reg_13__0_a0d0757 [7:4];
  wire recovered_171_ci = ((esc_add_ln208_141_reg_8589_reg_3__i_1_n_0_edebe90) !== 1'bz) && (esc_add_ln208_141_reg_8589_reg_3__i_1_n_0_edebe90);
  wire recovered_171_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_171_o[0] = recovered_171_s[0] ^ (recovered_171_ci || recovered_171_cy);
  assign recovered_171_co[0] = (recovered_171_s[0] & (recovered_171_ci || recovered_171_cy)) | (~recovered_171_s[0] & recovered_171_di[0]);
  assign recovered_171_o[1] = recovered_171_s[1] ^ recovered_171_co[0];
  assign recovered_171_co[1] = (recovered_171_s[1] & recovered_171_co[0]) | (~recovered_171_s[1] & recovered_171_di[1]);
  assign recovered_171_o[2] = recovered_171_s[2] ^ recovered_171_co[1];
  assign recovered_171_co[2] = (recovered_171_s[2] & recovered_171_co[1]) | (~recovered_171_s[2] & recovered_171_di[2]);
  assign recovered_171_o[3] = recovered_171_s[3] ^ recovered_171_co[2];
  assign recovered_171_co[3] = (recovered_171_s[3] & recovered_171_co[2]) | (~recovered_171_s[3] & recovered_171_di[3]);
  assign {esc_add_ln208_141_reg_8589_reg_7__i_1_n_0_9e26169 ,esc_NLW_add_ln208_141_reg_8589_reg_7__i_1_CO_UNCONNECTED_305ac38 [2:0]} = recovered_171_co;
  assign esc_add_ln208_138_reg_8557_reg_13_7e0af06 [7:4] = recovered_171_o;

  // Reconstructed LUT2: esc_add_ln208_144_reg_8621_3__i_2_52d1143
  assign esc_add_ln208_144_reg_8621_3__i_2_n_0_fa7792b = ((DOADO[3]) ? (~(esc_add_ln208_144_reg_8621_reg_13__0_aba970f [3])) : (esc_add_ln208_144_reg_8621_reg_13__0_aba970f [3]));

  // Reconstructed LUT2: esc_add_ln208_144_reg_8621_3__i_3_155251b
  assign esc_add_ln208_144_reg_8621_3__i_3_n_0_7aece36 = ((DOADO[2]) ? (~(esc_add_ln208_144_reg_8621_reg_13__0_aba970f [2])) : (esc_add_ln208_144_reg_8621_reg_13__0_aba970f [2]));

  // Reconstructed LUT2: esc_add_ln208_144_reg_8621_3__i_4_c579709
  assign esc_add_ln208_144_reg_8621_3__i_4_n_0_f2882d0 = ((DOADO[1]) ? (~(esc_add_ln208_144_reg_8621_reg_13__0_aba970f [1])) : (esc_add_ln208_144_reg_8621_reg_13__0_aba970f [1]));

  // Reconstructed LUT2: esc_add_ln208_144_reg_8621_3__i_5_ab50226
  assign esc_add_ln208_144_reg_8621_3__i_5_n_0_6dec4db = ((DOADO[0]) ? (~(esc_add_ln208_144_reg_8621_reg_13__0_aba970f [0])) : (esc_add_ln208_144_reg_8621_reg_13__0_aba970f [0]));

  // Reconstructed LUT2: esc_add_ln208_144_reg_8621_7__i_2_385d376
  assign esc_add_ln208_144_reg_8621_7__i_2_n_0_8d40fdc = ((DOADO[7]) ? (~(esc_add_ln208_144_reg_8621_reg_13__0_aba970f [7])) : (esc_add_ln208_144_reg_8621_reg_13__0_aba970f [7]));

  // Reconstructed LUT2: esc_add_ln208_144_reg_8621_7__i_3_329edbf
  assign esc_add_ln208_144_reg_8621_7__i_3_n_0_df3afd8 = ((DOADO[6]) ? (~(esc_add_ln208_144_reg_8621_reg_13__0_aba970f [6])) : (esc_add_ln208_144_reg_8621_reg_13__0_aba970f [6]));

  // Reconstructed LUT2: esc_add_ln208_144_reg_8621_7__i_4_a69b19a
  assign esc_add_ln208_144_reg_8621_7__i_4_n_0_dc899f7 = ((DOADO[5]) ? (~(esc_add_ln208_144_reg_8621_reg_13__0_aba970f [5])) : (esc_add_ln208_144_reg_8621_reg_13__0_aba970f [5]));

  // Reconstructed LUT2: esc_add_ln208_144_reg_8621_7__i_5_124446a
  assign esc_add_ln208_144_reg_8621_7__i_5_n_0_95db23d = ((DOADO[4]) ? (~(esc_add_ln208_144_reg_8621_reg_13__0_aba970f [4])) : (esc_add_ln208_144_reg_8621_reg_13__0_aba970f [4]));

  // Reconstructed CARRY4: esc_add_ln208_144_reg_8621_reg_11__i_1_3ca577b
  wire [3:0] recovered_180_co, recovered_180_o, recovered_180_s, recovered_180_di;
  assign recovered_180_s = esc_add_ln208_144_reg_8621_reg_13__0_aba970f [11:8];
  assign recovered_180_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_180_ci = ((esc_add_ln208_144_reg_8621_reg_7__i_1_n_0_71154b8) !== 1'bz) && (esc_add_ln208_144_reg_8621_reg_7__i_1_n_0_71154b8);
  wire recovered_180_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_180_o[0] = recovered_180_s[0] ^ (recovered_180_ci || recovered_180_cy);
  assign recovered_180_co[0] = (recovered_180_s[0] & (recovered_180_ci || recovered_180_cy)) | (~recovered_180_s[0] & recovered_180_di[0]);
  assign recovered_180_o[1] = recovered_180_s[1] ^ recovered_180_co[0];
  assign recovered_180_co[1] = (recovered_180_s[1] & recovered_180_co[0]) | (~recovered_180_s[1] & recovered_180_di[1]);
  assign recovered_180_o[2] = recovered_180_s[2] ^ recovered_180_co[1];
  assign recovered_180_co[2] = (recovered_180_s[2] & recovered_180_co[1]) | (~recovered_180_s[2] & recovered_180_di[2]);
  assign recovered_180_o[3] = recovered_180_s[3] ^ recovered_180_co[2];
  assign recovered_180_co[3] = (recovered_180_s[3] & recovered_180_co[2]) | (~recovered_180_s[3] & recovered_180_di[3]);
  assign {esc_add_ln208_144_reg_8621_reg_11__i_1_n_0_349f597 ,esc_NLW_add_ln208_144_reg_8621_reg_11__i_1_CO_UNCONNECTED_16fc79d [2:0]} = recovered_180_co;
  assign esc_add_ln208_141_reg_8589_reg_13_eb89c6f [11:8] = recovered_180_o;

  // Reconstructed CARRY4: esc_add_ln208_144_reg_8621_reg_13__i_1_60af264
  wire [3:0] recovered_181_co, recovered_181_o, recovered_181_s, recovered_181_di;
  assign recovered_181_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_144_reg_8621_reg_13__0_aba970f [13:12]};
  assign recovered_181_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_181_ci = ((esc_add_ln208_144_reg_8621_reg_11__i_1_n_0_349f597) !== 1'bz) && (esc_add_ln208_144_reg_8621_reg_11__i_1_n_0_349f597);
  wire recovered_181_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_181_o[0] = recovered_181_s[0] ^ (recovered_181_ci || recovered_181_cy);
  assign recovered_181_co[0] = (recovered_181_s[0] & (recovered_181_ci || recovered_181_cy)) | (~recovered_181_s[0] & recovered_181_di[0]);
  assign recovered_181_o[1] = recovered_181_s[1] ^ recovered_181_co[0];
  assign recovered_181_co[1] = (recovered_181_s[1] & recovered_181_co[0]) | (~recovered_181_s[1] & recovered_181_di[1]);
  assign recovered_181_o[2] = recovered_181_s[2] ^ recovered_181_co[1];
  assign recovered_181_co[2] = (recovered_181_s[2] & recovered_181_co[1]) | (~recovered_181_s[2] & recovered_181_di[2]);
  assign recovered_181_o[3] = recovered_181_s[3] ^ recovered_181_co[2];
  assign recovered_181_co[3] = (recovered_181_s[3] & recovered_181_co[2]) | (~recovered_181_s[3] & recovered_181_di[3]);
  assign esc_add_ln208_141_reg_8589_reg_13_eb89c6f [13:12] = recovered_181_o;

  // Reconstructed CARRY4: esc_add_ln208_144_reg_8621_reg_3__i_1_92d24d2
  wire [3:0] recovered_182_co, recovered_182_o, recovered_182_s, recovered_182_di;
  assign recovered_182_s = {esc_add_ln208_144_reg_8621_3__i_2_n_0_fa7792b ,esc_add_ln208_144_reg_8621_3__i_3_n_0_7aece36 ,esc_add_ln208_144_reg_8621_3__i_4_n_0_f2882d0 ,esc_add_ln208_144_reg_8621_3__i_5_n_0_6dec4db };
  assign recovered_182_di = esc_add_ln208_144_reg_8621_reg_13__0_aba970f [3:0];
  wire recovered_182_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_182_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_182_o[0] = recovered_182_s[0] ^ (recovered_182_ci || recovered_182_cy);
  assign recovered_182_co[0] = (recovered_182_s[0] & (recovered_182_ci || recovered_182_cy)) | (~recovered_182_s[0] & recovered_182_di[0]);
  assign recovered_182_o[1] = recovered_182_s[1] ^ recovered_182_co[0];
  assign recovered_182_co[1] = (recovered_182_s[1] & recovered_182_co[0]) | (~recovered_182_s[1] & recovered_182_di[1]);
  assign recovered_182_o[2] = recovered_182_s[2] ^ recovered_182_co[1];
  assign recovered_182_co[2] = (recovered_182_s[2] & recovered_182_co[1]) | (~recovered_182_s[2] & recovered_182_di[2]);
  assign recovered_182_o[3] = recovered_182_s[3] ^ recovered_182_co[2];
  assign recovered_182_co[3] = (recovered_182_s[3] & recovered_182_co[2]) | (~recovered_182_s[3] & recovered_182_di[3]);
  assign {esc_add_ln208_144_reg_8621_reg_3__i_1_n_0_64fdd2c ,esc_NLW_add_ln208_144_reg_8621_reg_3__i_1_CO_UNCONNECTED_fb02f91 [2:0]} = recovered_182_co;
  assign esc_add_ln208_141_reg_8589_reg_13_eb89c6f [3:0] = recovered_182_o;

  // Reconstructed CARRY4: esc_add_ln208_144_reg_8621_reg_7__i_1_6c7d595
  wire [3:0] recovered_183_co, recovered_183_o, recovered_183_s, recovered_183_di;
  assign recovered_183_s = {esc_add_ln208_144_reg_8621_7__i_2_n_0_8d40fdc ,esc_add_ln208_144_reg_8621_7__i_3_n_0_df3afd8 ,esc_add_ln208_144_reg_8621_7__i_4_n_0_dc899f7 ,esc_add_ln208_144_reg_8621_7__i_5_n_0_95db23d };
  assign recovered_183_di = esc_add_ln208_144_reg_8621_reg_13__0_aba970f [7:4];
  wire recovered_183_ci = ((esc_add_ln208_144_reg_8621_reg_3__i_1_n_0_64fdd2c) !== 1'bz) && (esc_add_ln208_144_reg_8621_reg_3__i_1_n_0_64fdd2c);
  wire recovered_183_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_183_o[0] = recovered_183_s[0] ^ (recovered_183_ci || recovered_183_cy);
  assign recovered_183_co[0] = (recovered_183_s[0] & (recovered_183_ci || recovered_183_cy)) | (~recovered_183_s[0] & recovered_183_di[0]);
  assign recovered_183_o[1] = recovered_183_s[1] ^ recovered_183_co[0];
  assign recovered_183_co[1] = (recovered_183_s[1] & recovered_183_co[0]) | (~recovered_183_s[1] & recovered_183_di[1]);
  assign recovered_183_o[2] = recovered_183_s[2] ^ recovered_183_co[1];
  assign recovered_183_co[2] = (recovered_183_s[2] & recovered_183_co[1]) | (~recovered_183_s[2] & recovered_183_di[2]);
  assign recovered_183_o[3] = recovered_183_s[3] ^ recovered_183_co[2];
  assign recovered_183_co[3] = (recovered_183_s[3] & recovered_183_co[2]) | (~recovered_183_s[3] & recovered_183_di[3]);
  assign {esc_add_ln208_144_reg_8621_reg_7__i_1_n_0_71154b8 ,esc_NLW_add_ln208_144_reg_8621_reg_7__i_1_CO_UNCONNECTED_5937d68 [2:0]} = recovered_183_co;
  assign esc_add_ln208_141_reg_8589_reg_13_eb89c6f [7:4] = recovered_183_o;

  // Reconstructed LUT2: esc_add_ln208_147_reg_8653_3__i_2_0093d90
  assign esc_add_ln208_147_reg_8653_3__i_2_n_0_1f5280b = ((DOADO[3]) ? (~(esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [3])) : (esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [3]));

  // Reconstructed LUT2: esc_add_ln208_147_reg_8653_3__i_3_cd797e7
  assign esc_add_ln208_147_reg_8653_3__i_3_n_0_29cdd4d = ((DOADO[2]) ? (~(esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [2])) : (esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [2]));

  // Reconstructed LUT2: esc_add_ln208_147_reg_8653_3__i_4_5df7541
  assign esc_add_ln208_147_reg_8653_3__i_4_n_0_bb6a6df = ((DOADO[1]) ? (~(esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [1])) : (esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [1]));

  // Reconstructed LUT2: esc_add_ln208_147_reg_8653_3__i_5_de2c64e
  assign esc_add_ln208_147_reg_8653_3__i_5_n_0_c5642f1 = ((DOADO[0]) ? (~(esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [0])) : (esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [0]));

  // Reconstructed LUT2: esc_add_ln208_147_reg_8653_7__i_2_274ec75
  assign esc_add_ln208_147_reg_8653_7__i_2_n_0_8242b78 = ((DOADO[7]) ? (~(esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [7])) : (esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [7]));

  // Reconstructed LUT2: esc_add_ln208_147_reg_8653_7__i_3_f8ef91a
  assign esc_add_ln208_147_reg_8653_7__i_3_n_0_69586a9 = ((DOADO[6]) ? (~(esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [6])) : (esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [6]));

  // Reconstructed LUT2: esc_add_ln208_147_reg_8653_7__i_4_7c686da
  assign esc_add_ln208_147_reg_8653_7__i_4_n_0_bc1a00f = ((DOADO[5]) ? (~(esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [5])) : (esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [5]));

  // Reconstructed LUT2: esc_add_ln208_147_reg_8653_7__i_5_32ab99b
  assign esc_add_ln208_147_reg_8653_7__i_5_n_0_b85b122 = ((DOADO[4]) ? (~(esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [4])) : (esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [4]));

  // Reconstructed CARRY4: esc_add_ln208_147_reg_8653_reg_11__i_1_fc09833
  wire [3:0] recovered_192_co, recovered_192_o, recovered_192_s, recovered_192_di;
  assign recovered_192_s = esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [11:8];
  assign recovered_192_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_192_ci = ((esc_add_ln208_147_reg_8653_reg_7__i_1_n_0_6ed0515) !== 1'bz) && (esc_add_ln208_147_reg_8653_reg_7__i_1_n_0_6ed0515);
  wire recovered_192_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_192_o[0] = recovered_192_s[0] ^ (recovered_192_ci || recovered_192_cy);
  assign recovered_192_co[0] = (recovered_192_s[0] & (recovered_192_ci || recovered_192_cy)) | (~recovered_192_s[0] & recovered_192_di[0]);
  assign recovered_192_o[1] = recovered_192_s[1] ^ recovered_192_co[0];
  assign recovered_192_co[1] = (recovered_192_s[1] & recovered_192_co[0]) | (~recovered_192_s[1] & recovered_192_di[1]);
  assign recovered_192_o[2] = recovered_192_s[2] ^ recovered_192_co[1];
  assign recovered_192_co[2] = (recovered_192_s[2] & recovered_192_co[1]) | (~recovered_192_s[2] & recovered_192_di[2]);
  assign recovered_192_o[3] = recovered_192_s[3] ^ recovered_192_co[2];
  assign recovered_192_co[3] = (recovered_192_s[3] & recovered_192_co[2]) | (~recovered_192_s[3] & recovered_192_di[3]);
  assign {esc_add_ln208_147_reg_8653_reg_11__i_1_n_0_76e88bd ,esc_NLW_add_ln208_147_reg_8653_reg_11__i_1_CO_UNCONNECTED_d4236d9 [2:0]} = recovered_192_co;
  assign esc_add_ln208_144_reg_8621_reg_13_47c2a26 [11:8] = recovered_192_o;

  // Reconstructed CARRY4: esc_add_ln208_147_reg_8653_reg_13__i_1_a3a39d9
  wire [3:0] recovered_193_co, recovered_193_o, recovered_193_s, recovered_193_di;
  assign recovered_193_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [13:12]};
  assign recovered_193_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_193_ci = ((esc_add_ln208_147_reg_8653_reg_11__i_1_n_0_76e88bd) !== 1'bz) && (esc_add_ln208_147_reg_8653_reg_11__i_1_n_0_76e88bd);
  wire recovered_193_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_193_o[0] = recovered_193_s[0] ^ (recovered_193_ci || recovered_193_cy);
  assign recovered_193_co[0] = (recovered_193_s[0] & (recovered_193_ci || recovered_193_cy)) | (~recovered_193_s[0] & recovered_193_di[0]);
  assign recovered_193_o[1] = recovered_193_s[1] ^ recovered_193_co[0];
  assign recovered_193_co[1] = (recovered_193_s[1] & recovered_193_co[0]) | (~recovered_193_s[1] & recovered_193_di[1]);
  assign recovered_193_o[2] = recovered_193_s[2] ^ recovered_193_co[1];
  assign recovered_193_co[2] = (recovered_193_s[2] & recovered_193_co[1]) | (~recovered_193_s[2] & recovered_193_di[2]);
  assign recovered_193_o[3] = recovered_193_s[3] ^ recovered_193_co[2];
  assign recovered_193_co[3] = (recovered_193_s[3] & recovered_193_co[2]) | (~recovered_193_s[3] & recovered_193_di[3]);
  assign esc_add_ln208_144_reg_8621_reg_13_47c2a26 [13:12] = recovered_193_o;

  // Reconstructed CARRY4: esc_add_ln208_147_reg_8653_reg_3__i_1_00b8953
  wire [3:0] recovered_194_co, recovered_194_o, recovered_194_s, recovered_194_di;
  assign recovered_194_s = {esc_add_ln208_147_reg_8653_3__i_2_n_0_1f5280b ,esc_add_ln208_147_reg_8653_3__i_3_n_0_29cdd4d ,esc_add_ln208_147_reg_8653_3__i_4_n_0_bb6a6df ,esc_add_ln208_147_reg_8653_3__i_5_n_0_c5642f1 };
  assign recovered_194_di = esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [3:0];
  wire recovered_194_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_194_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_194_o[0] = recovered_194_s[0] ^ (recovered_194_ci || recovered_194_cy);
  assign recovered_194_co[0] = (recovered_194_s[0] & (recovered_194_ci || recovered_194_cy)) | (~recovered_194_s[0] & recovered_194_di[0]);
  assign recovered_194_o[1] = recovered_194_s[1] ^ recovered_194_co[0];
  assign recovered_194_co[1] = (recovered_194_s[1] & recovered_194_co[0]) | (~recovered_194_s[1] & recovered_194_di[1]);
  assign recovered_194_o[2] = recovered_194_s[2] ^ recovered_194_co[1];
  assign recovered_194_co[2] = (recovered_194_s[2] & recovered_194_co[1]) | (~recovered_194_s[2] & recovered_194_di[2]);
  assign recovered_194_o[3] = recovered_194_s[3] ^ recovered_194_co[2];
  assign recovered_194_co[3] = (recovered_194_s[3] & recovered_194_co[2]) | (~recovered_194_s[3] & recovered_194_di[3]);
  assign {esc_add_ln208_147_reg_8653_reg_3__i_1_n_0_7e472d4 ,esc_NLW_add_ln208_147_reg_8653_reg_3__i_1_CO_UNCONNECTED_6317f52 [2:0]} = recovered_194_co;
  assign esc_add_ln208_144_reg_8621_reg_13_47c2a26 [3:0] = recovered_194_o;

  // Reconstructed CARRY4: esc_add_ln208_147_reg_8653_reg_7__i_1_b3bb799
  wire [3:0] recovered_195_co, recovered_195_o, recovered_195_s, recovered_195_di;
  assign recovered_195_s = {esc_add_ln208_147_reg_8653_7__i_2_n_0_8242b78 ,esc_add_ln208_147_reg_8653_7__i_3_n_0_69586a9 ,esc_add_ln208_147_reg_8653_7__i_4_n_0_bc1a00f ,esc_add_ln208_147_reg_8653_7__i_5_n_0_b85b122 };
  assign recovered_195_di = esc_add_ln208_147_reg_8653_reg_13__0_c9f027d [7:4];
  wire recovered_195_ci = ((esc_add_ln208_147_reg_8653_reg_3__i_1_n_0_7e472d4) !== 1'bz) && (esc_add_ln208_147_reg_8653_reg_3__i_1_n_0_7e472d4);
  wire recovered_195_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_195_o[0] = recovered_195_s[0] ^ (recovered_195_ci || recovered_195_cy);
  assign recovered_195_co[0] = (recovered_195_s[0] & (recovered_195_ci || recovered_195_cy)) | (~recovered_195_s[0] & recovered_195_di[0]);
  assign recovered_195_o[1] = recovered_195_s[1] ^ recovered_195_co[0];
  assign recovered_195_co[1] = (recovered_195_s[1] & recovered_195_co[0]) | (~recovered_195_s[1] & recovered_195_di[1]);
  assign recovered_195_o[2] = recovered_195_s[2] ^ recovered_195_co[1];
  assign recovered_195_co[2] = (recovered_195_s[2] & recovered_195_co[1]) | (~recovered_195_s[2] & recovered_195_di[2]);
  assign recovered_195_o[3] = recovered_195_s[3] ^ recovered_195_co[2];
  assign recovered_195_co[3] = (recovered_195_s[3] & recovered_195_co[2]) | (~recovered_195_s[3] & recovered_195_di[3]);
  assign {esc_add_ln208_147_reg_8653_reg_7__i_1_n_0_6ed0515 ,esc_NLW_add_ln208_147_reg_8653_reg_7__i_1_CO_UNCONNECTED_9ef8391 [2:0]} = recovered_195_co;
  assign esc_add_ln208_144_reg_8621_reg_13_47c2a26 [7:4] = recovered_195_o;

  // Reconstructed LUT2: esc_add_ln208_150_reg_8685_3__i_2_ab20ddd
  assign esc_add_ln208_150_reg_8685_3__i_2_n_0_136e3b0 = ((DOADO[3]) ? (~(esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [3])) : (esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [3]));

  // Reconstructed LUT2: esc_add_ln208_150_reg_8685_3__i_3_befb42e
  assign esc_add_ln208_150_reg_8685_3__i_3_n_0_3757d31 = ((DOADO[2]) ? (~(esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [2])) : (esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [2]));

  // Reconstructed LUT2: esc_add_ln208_150_reg_8685_3__i_4_8cf9e46
  assign esc_add_ln208_150_reg_8685_3__i_4_n_0_9457665 = ((DOADO[1]) ? (~(esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [1])) : (esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [1]));

  // Reconstructed LUT2: esc_add_ln208_150_reg_8685_3__i_5_31c99e9
  assign esc_add_ln208_150_reg_8685_3__i_5_n_0_eaca254 = ((DOADO[0]) ? (~(esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [0])) : (esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [0]));

  // Reconstructed LUT2: esc_add_ln208_150_reg_8685_7__i_2_bfc024a
  assign esc_add_ln208_150_reg_8685_7__i_2_n_0_1622eec = ((DOADO[7]) ? (~(esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [7])) : (esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [7]));

  // Reconstructed LUT2: esc_add_ln208_150_reg_8685_7__i_3_6e80e5e
  assign esc_add_ln208_150_reg_8685_7__i_3_n_0_ecf5b23 = ((DOADO[6]) ? (~(esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [6])) : (esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [6]));

  // Reconstructed LUT2: esc_add_ln208_150_reg_8685_7__i_4_1ed99e3
  assign esc_add_ln208_150_reg_8685_7__i_4_n_0_d7978e2 = ((DOADO[5]) ? (~(esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [5])) : (esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [5]));

  // Reconstructed LUT2: esc_add_ln208_150_reg_8685_7__i_5_cce27d7
  assign esc_add_ln208_150_reg_8685_7__i_5_n_0_1303e55 = ((DOADO[4]) ? (~(esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [4])) : (esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [4]));

  // Reconstructed CARRY4: esc_add_ln208_150_reg_8685_reg_11__i_1_c405801
  wire [3:0] recovered_204_co, recovered_204_o, recovered_204_s, recovered_204_di;
  assign recovered_204_s = esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [11:8];
  assign recovered_204_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_204_ci = ((esc_add_ln208_150_reg_8685_reg_7__i_1_n_0_d7e94f5) !== 1'bz) && (esc_add_ln208_150_reg_8685_reg_7__i_1_n_0_d7e94f5);
  wire recovered_204_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_204_o[0] = recovered_204_s[0] ^ (recovered_204_ci || recovered_204_cy);
  assign recovered_204_co[0] = (recovered_204_s[0] & (recovered_204_ci || recovered_204_cy)) | (~recovered_204_s[0] & recovered_204_di[0]);
  assign recovered_204_o[1] = recovered_204_s[1] ^ recovered_204_co[0];
  assign recovered_204_co[1] = (recovered_204_s[1] & recovered_204_co[0]) | (~recovered_204_s[1] & recovered_204_di[1]);
  assign recovered_204_o[2] = recovered_204_s[2] ^ recovered_204_co[1];
  assign recovered_204_co[2] = (recovered_204_s[2] & recovered_204_co[1]) | (~recovered_204_s[2] & recovered_204_di[2]);
  assign recovered_204_o[3] = recovered_204_s[3] ^ recovered_204_co[2];
  assign recovered_204_co[3] = (recovered_204_s[3] & recovered_204_co[2]) | (~recovered_204_s[3] & recovered_204_di[3]);
  assign {esc_add_ln208_150_reg_8685_reg_11__i_1_n_0_50c387d ,esc_NLW_add_ln208_150_reg_8685_reg_11__i_1_CO_UNCONNECTED_23c9537 [2:0]} = recovered_204_co;
  assign esc_add_ln208_147_reg_8653_reg_13_2be1b94 [11:8] = recovered_204_o;

  // Reconstructed CARRY4: esc_add_ln208_150_reg_8685_reg_13__i_1_ca5c3a4
  wire [3:0] recovered_205_co, recovered_205_o, recovered_205_s, recovered_205_di;
  assign recovered_205_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [13:12]};
  assign recovered_205_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_205_ci = ((esc_add_ln208_150_reg_8685_reg_11__i_1_n_0_50c387d) !== 1'bz) && (esc_add_ln208_150_reg_8685_reg_11__i_1_n_0_50c387d);
  wire recovered_205_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_205_o[0] = recovered_205_s[0] ^ (recovered_205_ci || recovered_205_cy);
  assign recovered_205_co[0] = (recovered_205_s[0] & (recovered_205_ci || recovered_205_cy)) | (~recovered_205_s[0] & recovered_205_di[0]);
  assign recovered_205_o[1] = recovered_205_s[1] ^ recovered_205_co[0];
  assign recovered_205_co[1] = (recovered_205_s[1] & recovered_205_co[0]) | (~recovered_205_s[1] & recovered_205_di[1]);
  assign recovered_205_o[2] = recovered_205_s[2] ^ recovered_205_co[1];
  assign recovered_205_co[2] = (recovered_205_s[2] & recovered_205_co[1]) | (~recovered_205_s[2] & recovered_205_di[2]);
  assign recovered_205_o[3] = recovered_205_s[3] ^ recovered_205_co[2];
  assign recovered_205_co[3] = (recovered_205_s[3] & recovered_205_co[2]) | (~recovered_205_s[3] & recovered_205_di[3]);
  assign esc_add_ln208_147_reg_8653_reg_13_2be1b94 [13:12] = recovered_205_o;

  // Reconstructed CARRY4: esc_add_ln208_150_reg_8685_reg_3__i_1_cb05bf2
  wire [3:0] recovered_206_co, recovered_206_o, recovered_206_s, recovered_206_di;
  assign recovered_206_s = {esc_add_ln208_150_reg_8685_3__i_2_n_0_136e3b0 ,esc_add_ln208_150_reg_8685_3__i_3_n_0_3757d31 ,esc_add_ln208_150_reg_8685_3__i_4_n_0_9457665 ,esc_add_ln208_150_reg_8685_3__i_5_n_0_eaca254 };
  assign recovered_206_di = esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [3:0];
  wire recovered_206_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_206_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_206_o[0] = recovered_206_s[0] ^ (recovered_206_ci || recovered_206_cy);
  assign recovered_206_co[0] = (recovered_206_s[0] & (recovered_206_ci || recovered_206_cy)) | (~recovered_206_s[0] & recovered_206_di[0]);
  assign recovered_206_o[1] = recovered_206_s[1] ^ recovered_206_co[0];
  assign recovered_206_co[1] = (recovered_206_s[1] & recovered_206_co[0]) | (~recovered_206_s[1] & recovered_206_di[1]);
  assign recovered_206_o[2] = recovered_206_s[2] ^ recovered_206_co[1];
  assign recovered_206_co[2] = (recovered_206_s[2] & recovered_206_co[1]) | (~recovered_206_s[2] & recovered_206_di[2]);
  assign recovered_206_o[3] = recovered_206_s[3] ^ recovered_206_co[2];
  assign recovered_206_co[3] = (recovered_206_s[3] & recovered_206_co[2]) | (~recovered_206_s[3] & recovered_206_di[3]);
  assign {esc_add_ln208_150_reg_8685_reg_3__i_1_n_0_48ffcef ,esc_NLW_add_ln208_150_reg_8685_reg_3__i_1_CO_UNCONNECTED_a46009e [2:0]} = recovered_206_co;
  assign esc_add_ln208_147_reg_8653_reg_13_2be1b94 [3:0] = recovered_206_o;

  // Reconstructed CARRY4: esc_add_ln208_150_reg_8685_reg_7__i_1_07b86e2
  wire [3:0] recovered_207_co, recovered_207_o, recovered_207_s, recovered_207_di;
  assign recovered_207_s = {esc_add_ln208_150_reg_8685_7__i_2_n_0_1622eec ,esc_add_ln208_150_reg_8685_7__i_3_n_0_ecf5b23 ,esc_add_ln208_150_reg_8685_7__i_4_n_0_d7978e2 ,esc_add_ln208_150_reg_8685_7__i_5_n_0_1303e55 };
  assign recovered_207_di = esc_add_ln208_150_reg_8685_reg_13__0_8447d92 [7:4];
  wire recovered_207_ci = ((esc_add_ln208_150_reg_8685_reg_3__i_1_n_0_48ffcef) !== 1'bz) && (esc_add_ln208_150_reg_8685_reg_3__i_1_n_0_48ffcef);
  wire recovered_207_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_207_o[0] = recovered_207_s[0] ^ (recovered_207_ci || recovered_207_cy);
  assign recovered_207_co[0] = (recovered_207_s[0] & (recovered_207_ci || recovered_207_cy)) | (~recovered_207_s[0] & recovered_207_di[0]);
  assign recovered_207_o[1] = recovered_207_s[1] ^ recovered_207_co[0];
  assign recovered_207_co[1] = (recovered_207_s[1] & recovered_207_co[0]) | (~recovered_207_s[1] & recovered_207_di[1]);
  assign recovered_207_o[2] = recovered_207_s[2] ^ recovered_207_co[1];
  assign recovered_207_co[2] = (recovered_207_s[2] & recovered_207_co[1]) | (~recovered_207_s[2] & recovered_207_di[2]);
  assign recovered_207_o[3] = recovered_207_s[3] ^ recovered_207_co[2];
  assign recovered_207_co[3] = (recovered_207_s[3] & recovered_207_co[2]) | (~recovered_207_s[3] & recovered_207_di[3]);
  assign {esc_add_ln208_150_reg_8685_reg_7__i_1_n_0_d7e94f5 ,esc_NLW_add_ln208_150_reg_8685_reg_7__i_1_CO_UNCONNECTED_b059143 [2:0]} = recovered_207_co;
  assign esc_add_ln208_147_reg_8653_reg_13_2be1b94 [7:4] = recovered_207_o;

  // Reconstructed LUT2: esc_add_ln208_153_reg_8717_3__i_2_ed7e23a
  assign esc_add_ln208_153_reg_8717_3__i_2_n_0_bef5723 = ((DOADO[3]) ? (~(esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [3])) : (esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [3]));

  // Reconstructed LUT2: esc_add_ln208_153_reg_8717_3__i_3_9db755a
  assign esc_add_ln208_153_reg_8717_3__i_3_n_0_e68123a = ((DOADO[2]) ? (~(esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [2])) : (esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [2]));

  // Reconstructed LUT2: esc_add_ln208_153_reg_8717_3__i_4_37b091c
  assign esc_add_ln208_153_reg_8717_3__i_4_n_0_0f499c8 = ((DOADO[1]) ? (~(esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [1])) : (esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [1]));

  // Reconstructed LUT2: esc_add_ln208_153_reg_8717_3__i_5_8e2d0ec
  assign esc_add_ln208_153_reg_8717_3__i_5_n_0_cf1ec89 = ((DOADO[0]) ? (~(esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [0])) : (esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [0]));

  // Reconstructed LUT2: esc_add_ln208_153_reg_8717_7__i_2_7af509e
  assign esc_add_ln208_153_reg_8717_7__i_2_n_0_b313dc9 = ((DOADO[7]) ? (~(esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [7])) : (esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [7]));

  // Reconstructed LUT2: esc_add_ln208_153_reg_8717_7__i_3_680d64b
  assign esc_add_ln208_153_reg_8717_7__i_3_n_0_3e58ad6 = ((DOADO[6]) ? (~(esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [6])) : (esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [6]));

  // Reconstructed LUT2: esc_add_ln208_153_reg_8717_7__i_4_cadb92f
  assign esc_add_ln208_153_reg_8717_7__i_4_n_0_151aeb5 = ((DOADO[5]) ? (~(esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [5])) : (esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [5]));

  // Reconstructed LUT2: esc_add_ln208_153_reg_8717_7__i_5_d8ded6b
  assign esc_add_ln208_153_reg_8717_7__i_5_n_0_efb044e = ((DOADO[4]) ? (~(esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [4])) : (esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [4]));

  // Reconstructed CARRY4: esc_add_ln208_153_reg_8717_reg_11__i_1_6f4ea40
  wire [3:0] recovered_216_co, recovered_216_o, recovered_216_s, recovered_216_di;
  assign recovered_216_s = esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [11:8];
  assign recovered_216_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_216_ci = ((esc_add_ln208_153_reg_8717_reg_7__i_1_n_0_e76998f) !== 1'bz) && (esc_add_ln208_153_reg_8717_reg_7__i_1_n_0_e76998f);
  wire recovered_216_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_216_o[0] = recovered_216_s[0] ^ (recovered_216_ci || recovered_216_cy);
  assign recovered_216_co[0] = (recovered_216_s[0] & (recovered_216_ci || recovered_216_cy)) | (~recovered_216_s[0] & recovered_216_di[0]);
  assign recovered_216_o[1] = recovered_216_s[1] ^ recovered_216_co[0];
  assign recovered_216_co[1] = (recovered_216_s[1] & recovered_216_co[0]) | (~recovered_216_s[1] & recovered_216_di[1]);
  assign recovered_216_o[2] = recovered_216_s[2] ^ recovered_216_co[1];
  assign recovered_216_co[2] = (recovered_216_s[2] & recovered_216_co[1]) | (~recovered_216_s[2] & recovered_216_di[2]);
  assign recovered_216_o[3] = recovered_216_s[3] ^ recovered_216_co[2];
  assign recovered_216_co[3] = (recovered_216_s[3] & recovered_216_co[2]) | (~recovered_216_s[3] & recovered_216_di[3]);
  assign {esc_add_ln208_153_reg_8717_reg_11__i_1_n_0_8515b46 ,esc_NLW_add_ln208_153_reg_8717_reg_11__i_1_CO_UNCONNECTED_3834129 [2:0]} = recovered_216_co;
  assign esc_add_ln208_150_reg_8685_reg_13_ba3a6fb [11:8] = recovered_216_o;

  // Reconstructed CARRY4: esc_add_ln208_153_reg_8717_reg_13__i_1_c845f7c
  wire [3:0] recovered_217_co, recovered_217_o, recovered_217_s, recovered_217_di;
  assign recovered_217_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [13:12]};
  assign recovered_217_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_217_ci = ((esc_add_ln208_153_reg_8717_reg_11__i_1_n_0_8515b46) !== 1'bz) && (esc_add_ln208_153_reg_8717_reg_11__i_1_n_0_8515b46);
  wire recovered_217_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_217_o[0] = recovered_217_s[0] ^ (recovered_217_ci || recovered_217_cy);
  assign recovered_217_co[0] = (recovered_217_s[0] & (recovered_217_ci || recovered_217_cy)) | (~recovered_217_s[0] & recovered_217_di[0]);
  assign recovered_217_o[1] = recovered_217_s[1] ^ recovered_217_co[0];
  assign recovered_217_co[1] = (recovered_217_s[1] & recovered_217_co[0]) | (~recovered_217_s[1] & recovered_217_di[1]);
  assign recovered_217_o[2] = recovered_217_s[2] ^ recovered_217_co[1];
  assign recovered_217_co[2] = (recovered_217_s[2] & recovered_217_co[1]) | (~recovered_217_s[2] & recovered_217_di[2]);
  assign recovered_217_o[3] = recovered_217_s[3] ^ recovered_217_co[2];
  assign recovered_217_co[3] = (recovered_217_s[3] & recovered_217_co[2]) | (~recovered_217_s[3] & recovered_217_di[3]);
  assign esc_add_ln208_150_reg_8685_reg_13_ba3a6fb [13:12] = recovered_217_o;

  // Reconstructed CARRY4: esc_add_ln208_153_reg_8717_reg_3__i_1_bb5262b
  wire [3:0] recovered_218_co, recovered_218_o, recovered_218_s, recovered_218_di;
  assign recovered_218_s = {esc_add_ln208_153_reg_8717_3__i_2_n_0_bef5723 ,esc_add_ln208_153_reg_8717_3__i_3_n_0_e68123a ,esc_add_ln208_153_reg_8717_3__i_4_n_0_0f499c8 ,esc_add_ln208_153_reg_8717_3__i_5_n_0_cf1ec89 };
  assign recovered_218_di = esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [3:0];
  wire recovered_218_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_218_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_218_o[0] = recovered_218_s[0] ^ (recovered_218_ci || recovered_218_cy);
  assign recovered_218_co[0] = (recovered_218_s[0] & (recovered_218_ci || recovered_218_cy)) | (~recovered_218_s[0] & recovered_218_di[0]);
  assign recovered_218_o[1] = recovered_218_s[1] ^ recovered_218_co[0];
  assign recovered_218_co[1] = (recovered_218_s[1] & recovered_218_co[0]) | (~recovered_218_s[1] & recovered_218_di[1]);
  assign recovered_218_o[2] = recovered_218_s[2] ^ recovered_218_co[1];
  assign recovered_218_co[2] = (recovered_218_s[2] & recovered_218_co[1]) | (~recovered_218_s[2] & recovered_218_di[2]);
  assign recovered_218_o[3] = recovered_218_s[3] ^ recovered_218_co[2];
  assign recovered_218_co[3] = (recovered_218_s[3] & recovered_218_co[2]) | (~recovered_218_s[3] & recovered_218_di[3]);
  assign {esc_add_ln208_153_reg_8717_reg_3__i_1_n_0_147a85a ,esc_NLW_add_ln208_153_reg_8717_reg_3__i_1_CO_UNCONNECTED_494f1cd [2:0]} = recovered_218_co;
  assign esc_add_ln208_150_reg_8685_reg_13_ba3a6fb [3:0] = recovered_218_o;

  // Reconstructed CARRY4: esc_add_ln208_153_reg_8717_reg_7__i_1_0f7e361
  wire [3:0] recovered_219_co, recovered_219_o, recovered_219_s, recovered_219_di;
  assign recovered_219_s = {esc_add_ln208_153_reg_8717_7__i_2_n_0_b313dc9 ,esc_add_ln208_153_reg_8717_7__i_3_n_0_3e58ad6 ,esc_add_ln208_153_reg_8717_7__i_4_n_0_151aeb5 ,esc_add_ln208_153_reg_8717_7__i_5_n_0_efb044e };
  assign recovered_219_di = esc_add_ln208_153_reg_8717_reg_13_6aad7d7 [7:4];
  wire recovered_219_ci = ((esc_add_ln208_153_reg_8717_reg_3__i_1_n_0_147a85a) !== 1'bz) && (esc_add_ln208_153_reg_8717_reg_3__i_1_n_0_147a85a);
  wire recovered_219_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_219_o[0] = recovered_219_s[0] ^ (recovered_219_ci || recovered_219_cy);
  assign recovered_219_co[0] = (recovered_219_s[0] & (recovered_219_ci || recovered_219_cy)) | (~recovered_219_s[0] & recovered_219_di[0]);
  assign recovered_219_o[1] = recovered_219_s[1] ^ recovered_219_co[0];
  assign recovered_219_co[1] = (recovered_219_s[1] & recovered_219_co[0]) | (~recovered_219_s[1] & recovered_219_di[1]);
  assign recovered_219_o[2] = recovered_219_s[2] ^ recovered_219_co[1];
  assign recovered_219_co[2] = (recovered_219_s[2] & recovered_219_co[1]) | (~recovered_219_s[2] & recovered_219_di[2]);
  assign recovered_219_o[3] = recovered_219_s[3] ^ recovered_219_co[2];
  assign recovered_219_co[3] = (recovered_219_s[3] & recovered_219_co[2]) | (~recovered_219_s[3] & recovered_219_di[3]);
  assign {esc_add_ln208_153_reg_8717_reg_7__i_1_n_0_e76998f ,esc_NLW_add_ln208_153_reg_8717_reg_7__i_1_CO_UNCONNECTED_fa5a1ea [2:0]} = recovered_219_co;
  assign esc_add_ln208_150_reg_8685_reg_13_ba3a6fb [7:4] = recovered_219_o;

  // Reconstructed LUT2: esc_add_ln208_157_reg_8733_3__i_10_4a8418d
  assign esc_add_ln208_157_reg_8733_3__i_10_n_0_fe654b1 = ((DOADO[0]) ? (~(esc_add_ln208_157_reg_8733_reg_15_b87abdb [0])) : (esc_add_ln208_157_reg_8733_reg_15_b87abdb [0]));

  // Reconstructed LUT2: esc_add_ln208_157_reg_8733_3__i_7_ed0cba4
  assign esc_add_ln208_157_reg_8733_3__i_7_n_0_8699c8f = ((DOADO[3]) ? (~(esc_add_ln208_157_reg_8733_reg_15_b87abdb [3])) : (esc_add_ln208_157_reg_8733_reg_15_b87abdb [3]));

  // Reconstructed LUT2: esc_add_ln208_157_reg_8733_3__i_8_429fa43
  assign esc_add_ln208_157_reg_8733_3__i_8_n_0_977be48 = ((DOADO[2]) ? (~(esc_add_ln208_157_reg_8733_reg_15_b87abdb [2])) : (esc_add_ln208_157_reg_8733_reg_15_b87abdb [2]));

  // Reconstructed LUT2: esc_add_ln208_157_reg_8733_3__i_9_9f8b115
  assign esc_add_ln208_157_reg_8733_3__i_9_n_0_5320947 = ((DOADO[1]) ? (~(esc_add_ln208_157_reg_8733_reg_15_b87abdb [1])) : (esc_add_ln208_157_reg_8733_reg_15_b87abdb [1]));

  // Reconstructed LUT2: esc_add_ln208_157_reg_8733_7__i_10_26530f6
  assign esc_add_ln208_157_reg_8733_7__i_10_n_0_d2d5e66 = ((DOADO[4]) ? (~(esc_add_ln208_157_reg_8733_reg_15_b87abdb [4])) : (esc_add_ln208_157_reg_8733_reg_15_b87abdb [4]));

  // Reconstructed LUT2: esc_add_ln208_157_reg_8733_7__i_7_fcedc99
  assign esc_add_ln208_157_reg_8733_7__i_7_n_0_bc5b8e7 = ((DOADO[7]) ? (~(esc_add_ln208_157_reg_8733_reg_15_b87abdb [7])) : (esc_add_ln208_157_reg_8733_reg_15_b87abdb [7]));

  // Reconstructed LUT2: esc_add_ln208_157_reg_8733_7__i_8_1137123
  assign esc_add_ln208_157_reg_8733_7__i_8_n_0_011168a = ((DOADO[6]) ? (~(esc_add_ln208_157_reg_8733_reg_15_b87abdb [6])) : (esc_add_ln208_157_reg_8733_reg_15_b87abdb [6]));

  // Reconstructed LUT2: esc_add_ln208_157_reg_8733_7__i_9_157e3ed
  assign esc_add_ln208_157_reg_8733_7__i_9_n_0_0f37152 = ((DOADO[5]) ? (~(esc_add_ln208_157_reg_8733_reg_15_b87abdb [5])) : (esc_add_ln208_157_reg_8733_reg_15_b87abdb [5]));

  // Reconstructed CARRY4: esc_add_ln208_157_reg_8733_reg_11__i_2_096c7ff
  wire [3:0] recovered_228_co, recovered_228_o, recovered_228_s, recovered_228_di;
  assign recovered_228_s = esc_add_ln208_157_reg_8733_reg_15_b87abdb [11:8];
  assign recovered_228_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_228_ci = ((esc_add_ln208_157_reg_8733_reg_7__i_2_n_0_ea8cc3f) !== 1'bz) && (esc_add_ln208_157_reg_8733_reg_7__i_2_n_0_ea8cc3f);
  wire recovered_228_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_228_o[0] = recovered_228_s[0] ^ (recovered_228_ci || recovered_228_cy);
  assign recovered_228_co[0] = (recovered_228_s[0] & (recovered_228_ci || recovered_228_cy)) | (~recovered_228_s[0] & recovered_228_di[0]);
  assign recovered_228_o[1] = recovered_228_s[1] ^ recovered_228_co[0];
  assign recovered_228_co[1] = (recovered_228_s[1] & recovered_228_co[0]) | (~recovered_228_s[1] & recovered_228_di[1]);
  assign recovered_228_o[2] = recovered_228_s[2] ^ recovered_228_co[1];
  assign recovered_228_co[2] = (recovered_228_s[2] & recovered_228_co[1]) | (~recovered_228_s[2] & recovered_228_di[2]);
  assign recovered_228_o[3] = recovered_228_s[3] ^ recovered_228_co[2];
  assign recovered_228_co[3] = (recovered_228_s[3] & recovered_228_co[2]) | (~recovered_228_s[3] & recovered_228_di[3]);
  assign {esc_add_ln208_157_reg_8733_reg_11__i_2_n_0_fb34f2e ,esc_NLW_add_ln208_157_reg_8733_reg_11__i_2_CO_UNCONNECTED_99d723b [2:0]} = recovered_228_co;
  assign zext_ln208_87_fu_5779_p1[11:8] = recovered_228_o;

  // Reconstructed CARRY4: esc_add_ln208_157_reg_8733_reg_15__i_2_64bb49a
  wire [3:0] recovered_229_co, recovered_229_o, recovered_229_s, recovered_229_di;
  assign recovered_229_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_157_reg_8733_reg_15_b87abdb [13:12]};
  assign recovered_229_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_229_ci = ((esc_add_ln208_157_reg_8733_reg_11__i_2_n_0_fb34f2e) !== 1'bz) && (esc_add_ln208_157_reg_8733_reg_11__i_2_n_0_fb34f2e);
  wire recovered_229_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_229_o[0] = recovered_229_s[0] ^ (recovered_229_ci || recovered_229_cy);
  assign recovered_229_co[0] = (recovered_229_s[0] & (recovered_229_ci || recovered_229_cy)) | (~recovered_229_s[0] & recovered_229_di[0]);
  assign recovered_229_o[1] = recovered_229_s[1] ^ recovered_229_co[0];
  assign recovered_229_co[1] = (recovered_229_s[1] & recovered_229_co[0]) | (~recovered_229_s[1] & recovered_229_di[1]);
  assign recovered_229_o[2] = recovered_229_s[2] ^ recovered_229_co[1];
  assign recovered_229_co[2] = (recovered_229_s[2] & recovered_229_co[1]) | (~recovered_229_s[2] & recovered_229_di[2]);
  assign recovered_229_o[3] = recovered_229_s[3] ^ recovered_229_co[2];
  assign recovered_229_co[3] = (recovered_229_s[3] & recovered_229_co[2]) | (~recovered_229_s[3] & recovered_229_di[3]);
  assign zext_ln208_87_fu_5779_p1[13:12] = recovered_229_o;

  // Reconstructed CARRY4: esc_add_ln208_157_reg_8733_reg_3__i_2_c4e9bfe
  wire [3:0] recovered_230_co, recovered_230_o, recovered_230_s, recovered_230_di;
  assign recovered_230_s = {esc_add_ln208_157_reg_8733_3__i_7_n_0_8699c8f ,esc_add_ln208_157_reg_8733_3__i_8_n_0_977be48 ,esc_add_ln208_157_reg_8733_3__i_9_n_0_5320947 ,esc_add_ln208_157_reg_8733_3__i_10_n_0_fe654b1 };
  assign recovered_230_di = esc_add_ln208_157_reg_8733_reg_15_b87abdb [3:0];
  wire recovered_230_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_230_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_230_o[0] = recovered_230_s[0] ^ (recovered_230_ci || recovered_230_cy);
  assign recovered_230_co[0] = (recovered_230_s[0] & (recovered_230_ci || recovered_230_cy)) | (~recovered_230_s[0] & recovered_230_di[0]);
  assign recovered_230_o[1] = recovered_230_s[1] ^ recovered_230_co[0];
  assign recovered_230_co[1] = (recovered_230_s[1] & recovered_230_co[0]) | (~recovered_230_s[1] & recovered_230_di[1]);
  assign recovered_230_o[2] = recovered_230_s[2] ^ recovered_230_co[1];
  assign recovered_230_co[2] = (recovered_230_s[2] & recovered_230_co[1]) | (~recovered_230_s[2] & recovered_230_di[2]);
  assign recovered_230_o[3] = recovered_230_s[3] ^ recovered_230_co[2];
  assign recovered_230_co[3] = (recovered_230_s[3] & recovered_230_co[2]) | (~recovered_230_s[3] & recovered_230_di[3]);
  assign {esc_add_ln208_157_reg_8733_reg_3__i_2_n_0_b0bd9fc ,esc_NLW_add_ln208_157_reg_8733_reg_3__i_2_CO_UNCONNECTED_6b09c41 [2:0]} = recovered_230_co;
  assign zext_ln208_87_fu_5779_p1[3:0] = recovered_230_o;

  // Reconstructed CARRY4: esc_add_ln208_157_reg_8733_reg_7__i_2_a987b58
  wire [3:0] recovered_231_co, recovered_231_o, recovered_231_s, recovered_231_di;
  assign recovered_231_s = {esc_add_ln208_157_reg_8733_7__i_7_n_0_bc5b8e7 ,esc_add_ln208_157_reg_8733_7__i_8_n_0_011168a ,esc_add_ln208_157_reg_8733_7__i_9_n_0_0f37152 ,esc_add_ln208_157_reg_8733_7__i_10_n_0_d2d5e66 };
  assign recovered_231_di = esc_add_ln208_157_reg_8733_reg_15_b87abdb [7:4];
  wire recovered_231_ci = ((esc_add_ln208_157_reg_8733_reg_3__i_2_n_0_b0bd9fc) !== 1'bz) && (esc_add_ln208_157_reg_8733_reg_3__i_2_n_0_b0bd9fc);
  wire recovered_231_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_231_o[0] = recovered_231_s[0] ^ (recovered_231_ci || recovered_231_cy);
  assign recovered_231_co[0] = (recovered_231_s[0] & (recovered_231_ci || recovered_231_cy)) | (~recovered_231_s[0] & recovered_231_di[0]);
  assign recovered_231_o[1] = recovered_231_s[1] ^ recovered_231_co[0];
  assign recovered_231_co[1] = (recovered_231_s[1] & recovered_231_co[0]) | (~recovered_231_s[1] & recovered_231_di[1]);
  assign recovered_231_o[2] = recovered_231_s[2] ^ recovered_231_co[1];
  assign recovered_231_co[2] = (recovered_231_s[2] & recovered_231_co[1]) | (~recovered_231_s[2] & recovered_231_di[2]);
  assign recovered_231_o[3] = recovered_231_s[3] ^ recovered_231_co[2];
  assign recovered_231_co[3] = (recovered_231_s[3] & recovered_231_co[2]) | (~recovered_231_s[3] & recovered_231_di[3]);
  assign {esc_add_ln208_157_reg_8733_reg_7__i_2_n_0_ea8cc3f ,esc_NLW_add_ln208_157_reg_8733_reg_7__i_2_CO_UNCONNECTED_aa77053 [2:0]} = recovered_231_co;
  assign zext_ln208_87_fu_5779_p1[7:4] = recovered_231_o;

  // Reconstructed LUT2: esc_add_ln208_42_reg_7073_3__i_2_e4f72d3
  assign esc_add_ln208_42_reg_7073_3__i_2_n_0_a835674 = ((ram0_reg_24[3]) ? (~(DOADO[3])) : (DOADO[3]));

  // Reconstructed LUT2: esc_add_ln208_42_reg_7073_3__i_3_d853951
  assign esc_add_ln208_42_reg_7073_3__i_3_n_0_17a625a = ((ram0_reg_24[2]) ? (~(DOADO[2])) : (DOADO[2]));

  // Reconstructed LUT2: esc_add_ln208_42_reg_7073_3__i_4_a62c683
  assign esc_add_ln208_42_reg_7073_3__i_4_n_0_98a54f3 = ((ram0_reg_24[1]) ? (~(DOADO[1])) : (DOADO[1]));

  // Reconstructed LUT2: esc_add_ln208_42_reg_7073_3__i_5_a3f8722
  assign esc_add_ln208_42_reg_7073_3__i_5_n_0_9d71024 = ((ram0_reg_24[0]) ? (~(DOADO[0])) : (DOADO[0]));

  // Reconstructed LUT2: esc_add_ln208_42_reg_7073_7__i_2_e88e2bc
  assign esc_add_ln208_42_reg_7073_7__i_2_n_0_3e83539 = ((ram0_reg_24[7]) ? (~(DOADO[7])) : (DOADO[7]));

  // Reconstructed LUT2: esc_add_ln208_42_reg_7073_7__i_3_be7fc51
  assign esc_add_ln208_42_reg_7073_7__i_3_n_0_85e06db = ((ram0_reg_24[6]) ? (~(DOADO[6])) : (DOADO[6]));

  // Reconstructed LUT2: esc_add_ln208_42_reg_7073_7__i_4_dc05df1
  assign esc_add_ln208_42_reg_7073_7__i_4_n_0_fb01aad = ((ram0_reg_24[5]) ? (~(DOADO[5])) : (DOADO[5]));

  // Reconstructed LUT2: esc_add_ln208_42_reg_7073_7__i_5_260f93c
  assign esc_add_ln208_42_reg_7073_7__i_5_n_0_2306f9c = ((ram0_reg_24[4]) ? (~(DOADO[4])) : (DOADO[4]));

  // Reconstructed CARRY4: esc_add_ln208_42_reg_7073_reg_3__i_1_9e78bcb
  wire [3:0] recovered_240_co, recovered_240_o, recovered_240_s, recovered_240_di;
  assign recovered_240_s = {esc_add_ln208_42_reg_7073_3__i_2_n_0_a835674 ,esc_add_ln208_42_reg_7073_3__i_3_n_0_17a625a ,esc_add_ln208_42_reg_7073_3__i_4_n_0_98a54f3 ,esc_add_ln208_42_reg_7073_3__i_5_n_0_9d71024 };
  assign recovered_240_di = DOADO[3:0];
  wire recovered_240_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_240_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_240_o[0] = recovered_240_s[0] ^ (recovered_240_ci || recovered_240_cy);
  assign recovered_240_co[0] = (recovered_240_s[0] & (recovered_240_ci || recovered_240_cy)) | (~recovered_240_s[0] & recovered_240_di[0]);
  assign recovered_240_o[1] = recovered_240_s[1] ^ recovered_240_co[0];
  assign recovered_240_co[1] = (recovered_240_s[1] & recovered_240_co[0]) | (~recovered_240_s[1] & recovered_240_di[1]);
  assign recovered_240_o[2] = recovered_240_s[2] ^ recovered_240_co[1];
  assign recovered_240_co[2] = (recovered_240_s[2] & recovered_240_co[1]) | (~recovered_240_s[2] & recovered_240_di[2]);
  assign recovered_240_o[3] = recovered_240_s[3] ^ recovered_240_co[2];
  assign recovered_240_co[3] = (recovered_240_s[3] & recovered_240_co[2]) | (~recovered_240_s[3] & recovered_240_di[3]);
  assign {esc_add_ln208_42_reg_7073_reg_3__i_1_n_0_595b7d0 ,esc_NLW_add_ln208_42_reg_7073_reg_3__i_1_CO_UNCONNECTED_2893d96 [2:0]} = recovered_240_co;
  assign ram0_reg_0[3:0] = recovered_240_o;

  // Reconstructed CARRY4: esc_add_ln208_42_reg_7073_reg_7__i_1_c65c5da
  wire [3:0] recovered_241_co, recovered_241_o, recovered_241_s, recovered_241_di;
  assign recovered_241_s = {esc_add_ln208_42_reg_7073_7__i_2_n_0_3e83539 ,esc_add_ln208_42_reg_7073_7__i_3_n_0_85e06db ,esc_add_ln208_42_reg_7073_7__i_4_n_0_fb01aad ,esc_add_ln208_42_reg_7073_7__i_5_n_0_2306f9c };
  assign recovered_241_di = DOADO[7:4];
  wire recovered_241_ci = ((esc_add_ln208_42_reg_7073_reg_3__i_1_n_0_595b7d0) !== 1'bz) && (esc_add_ln208_42_reg_7073_reg_3__i_1_n_0_595b7d0);
  wire recovered_241_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_241_o[0] = recovered_241_s[0] ^ (recovered_241_ci || recovered_241_cy);
  assign recovered_241_co[0] = (recovered_241_s[0] & (recovered_241_ci || recovered_241_cy)) | (~recovered_241_s[0] & recovered_241_di[0]);
  assign recovered_241_o[1] = recovered_241_s[1] ^ recovered_241_co[0];
  assign recovered_241_co[1] = (recovered_241_s[1] & recovered_241_co[0]) | (~recovered_241_s[1] & recovered_241_di[1]);
  assign recovered_241_o[2] = recovered_241_s[2] ^ recovered_241_co[1];
  assign recovered_241_co[2] = (recovered_241_s[2] & recovered_241_co[1]) | (~recovered_241_s[2] & recovered_241_di[2]);
  assign recovered_241_o[3] = recovered_241_s[3] ^ recovered_241_co[2];
  assign recovered_241_co[3] = (recovered_241_s[3] & recovered_241_co[2]) | (~recovered_241_s[3] & recovered_241_di[3]);
  assign {esc_add_ln208_42_reg_7073_reg_7__i_1_n_0_312fed8 ,esc_NLW_add_ln208_42_reg_7073_reg_7__i_1_CO_UNCONNECTED_e586fbf [2:0]} = recovered_241_co;
  assign ram0_reg_0[7:4] = recovered_241_o;

  // Reconstructed CARRY4: esc_add_ln208_42_reg_7073_reg_8__i_1_c850d71
  wire [3:0] recovered_242_co, recovered_242_o, recovered_242_s, recovered_242_di;
  assign recovered_242_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 };
  assign recovered_242_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_242_ci = ((esc_add_ln208_42_reg_7073_reg_7__i_1_n_0_312fed8) !== 1'bz) && (esc_add_ln208_42_reg_7073_reg_7__i_1_n_0_312fed8);
  wire recovered_242_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_242_o[0] = recovered_242_s[0] ^ (recovered_242_ci || recovered_242_cy);
  assign recovered_242_co[0] = (recovered_242_s[0] & (recovered_242_ci || recovered_242_cy)) | (~recovered_242_s[0] & recovered_242_di[0]);
  assign recovered_242_o[1] = recovered_242_s[1] ^ recovered_242_co[0];
  assign recovered_242_co[1] = (recovered_242_s[1] & recovered_242_co[0]) | (~recovered_242_s[1] & recovered_242_di[1]);
  assign recovered_242_o[2] = recovered_242_s[2] ^ recovered_242_co[1];
  assign recovered_242_co[2] = (recovered_242_s[2] & recovered_242_co[1]) | (~recovered_242_s[2] & recovered_242_di[2]);
  assign recovered_242_o[3] = recovered_242_s[3] ^ recovered_242_co[2];
  assign recovered_242_co[3] = (recovered_242_s[3] & recovered_242_co[2]) | (~recovered_242_s[3] & recovered_242_di[3]);
  assign ram0_reg_0[8] = recovered_242_co;

  // Reconstructed LUT2: esc_add_ln208_45_reg_7125_3__i_2_6f4b1af
  assign esc_add_ln208_45_reg_7125_3__i_2_n_0_b581a8d = ((DOADO[3]) ? (~(esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [3])) : (esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [3]));

  // Reconstructed LUT2: esc_add_ln208_45_reg_7125_3__i_3_12584ff
  assign esc_add_ln208_45_reg_7125_3__i_3_n_0_afe89d3 = ((DOADO[2]) ? (~(esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [2])) : (esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [2]));

  // Reconstructed LUT2: esc_add_ln208_45_reg_7125_3__i_4_7f814f3
  assign esc_add_ln208_45_reg_7125_3__i_4_n_0_32b3e9e = ((DOADO[1]) ? (~(esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [1])) : (esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [1]));

  // Reconstructed LUT2: esc_add_ln208_45_reg_7125_3__i_5_ebbc74a
  assign esc_add_ln208_45_reg_7125_3__i_5_n_0_0f6b41a = ((DOADO[0]) ? (~(esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [0])) : (esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [0]));

  // Reconstructed LUT2: esc_add_ln208_45_reg_7125_7__i_2_a2aa05f
  assign esc_add_ln208_45_reg_7125_7__i_2_n_0_518af43 = ((DOADO[7]) ? (~(esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [7])) : (esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [7]));

  // Reconstructed LUT2: esc_add_ln208_45_reg_7125_7__i_3_765815b
  assign esc_add_ln208_45_reg_7125_7__i_3_n_0_e296b1d = ((DOADO[6]) ? (~(esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [6])) : (esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [6]));

  // Reconstructed LUT2: esc_add_ln208_45_reg_7125_7__i_4_8c373bf
  assign esc_add_ln208_45_reg_7125_7__i_4_n_0_37cde2e = ((DOADO[5]) ? (~(esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [5])) : (esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [5]));

  // Reconstructed LUT2: esc_add_ln208_45_reg_7125_7__i_5_349f202
  assign esc_add_ln208_45_reg_7125_7__i_5_n_0_40b9c71 = ((DOADO[4]) ? (~(esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [4])) : (esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [4]));

  // Reconstructed CARRY4: esc_add_ln208_45_reg_7125_reg_3__i_1_3d49336
  wire [3:0] recovered_251_co, recovered_251_o, recovered_251_s, recovered_251_di;
  assign recovered_251_s = {esc_add_ln208_45_reg_7125_3__i_2_n_0_b581a8d ,esc_add_ln208_45_reg_7125_3__i_3_n_0_afe89d3 ,esc_add_ln208_45_reg_7125_3__i_4_n_0_32b3e9e ,esc_add_ln208_45_reg_7125_3__i_5_n_0_0f6b41a };
  assign recovered_251_di = esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [3:0];
  wire recovered_251_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_251_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_251_o[0] = recovered_251_s[0] ^ (recovered_251_ci || recovered_251_cy);
  assign recovered_251_co[0] = (recovered_251_s[0] & (recovered_251_ci || recovered_251_cy)) | (~recovered_251_s[0] & recovered_251_di[0]);
  assign recovered_251_o[1] = recovered_251_s[1] ^ recovered_251_co[0];
  assign recovered_251_co[1] = (recovered_251_s[1] & recovered_251_co[0]) | (~recovered_251_s[1] & recovered_251_di[1]);
  assign recovered_251_o[2] = recovered_251_s[2] ^ recovered_251_co[1];
  assign recovered_251_co[2] = (recovered_251_s[2] & recovered_251_co[1]) | (~recovered_251_s[2] & recovered_251_di[2]);
  assign recovered_251_o[3] = recovered_251_s[3] ^ recovered_251_co[2];
  assign recovered_251_co[3] = (recovered_251_s[3] & recovered_251_co[2]) | (~recovered_251_s[3] & recovered_251_di[3]);
  assign {esc_add_ln208_45_reg_7125_reg_3__i_1_n_0_9ca58c1 ,esc_NLW_add_ln208_45_reg_7125_reg_3__i_1_CO_UNCONNECTED_0b863a0 [2:0]} = recovered_251_co;
  assign esc_add_ln208_42_reg_7073_reg_8_b2dae6f [3:0] = recovered_251_o;

  // Reconstructed CARRY4: esc_add_ln208_45_reg_7125_reg_7__i_1_830a934
  wire [3:0] recovered_252_co, recovered_252_o, recovered_252_s, recovered_252_di;
  assign recovered_252_s = {esc_add_ln208_45_reg_7125_7__i_2_n_0_518af43 ,esc_add_ln208_45_reg_7125_7__i_3_n_0_e296b1d ,esc_add_ln208_45_reg_7125_7__i_4_n_0_37cde2e ,esc_add_ln208_45_reg_7125_7__i_5_n_0_40b9c71 };
  assign recovered_252_di = esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [7:4];
  wire recovered_252_ci = ((esc_add_ln208_45_reg_7125_reg_3__i_1_n_0_9ca58c1) !== 1'bz) && (esc_add_ln208_45_reg_7125_reg_3__i_1_n_0_9ca58c1);
  wire recovered_252_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_252_o[0] = recovered_252_s[0] ^ (recovered_252_ci || recovered_252_cy);
  assign recovered_252_co[0] = (recovered_252_s[0] & (recovered_252_ci || recovered_252_cy)) | (~recovered_252_s[0] & recovered_252_di[0]);
  assign recovered_252_o[1] = recovered_252_s[1] ^ recovered_252_co[0];
  assign recovered_252_co[1] = (recovered_252_s[1] & recovered_252_co[0]) | (~recovered_252_s[1] & recovered_252_di[1]);
  assign recovered_252_o[2] = recovered_252_s[2] ^ recovered_252_co[1];
  assign recovered_252_co[2] = (recovered_252_s[2] & recovered_252_co[1]) | (~recovered_252_s[2] & recovered_252_di[2]);
  assign recovered_252_o[3] = recovered_252_s[3] ^ recovered_252_co[2];
  assign recovered_252_co[3] = (recovered_252_s[3] & recovered_252_co[2]) | (~recovered_252_s[3] & recovered_252_di[3]);
  assign {esc_add_ln208_45_reg_7125_reg_7__i_1_n_0_e931a96 ,esc_NLW_add_ln208_45_reg_7125_reg_7__i_1_CO_UNCONNECTED_598fbdc [2:0]} = recovered_252_co;
  assign esc_add_ln208_42_reg_7073_reg_8_b2dae6f [7:4] = recovered_252_o;

  // Reconstructed CARRY4: esc_add_ln208_45_reg_7125_reg_9__i_1_eb4f951
  wire [3:0] recovered_253_co, recovered_253_o, recovered_253_s, recovered_253_di;
  assign recovered_253_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 ,esc_add_ln208_45_reg_7125_reg_9__0_c1c5610 [8]};
  assign recovered_253_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_253_ci = ((esc_add_ln208_45_reg_7125_reg_7__i_1_n_0_e931a96) !== 1'bz) && (esc_add_ln208_45_reg_7125_reg_7__i_1_n_0_e931a96);
  wire recovered_253_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_253_o[0] = recovered_253_s[0] ^ (recovered_253_ci || recovered_253_cy);
  assign recovered_253_co[0] = (recovered_253_s[0] & (recovered_253_ci || recovered_253_cy)) | (~recovered_253_s[0] & recovered_253_di[0]);
  assign recovered_253_o[1] = recovered_253_s[1] ^ recovered_253_co[0];
  assign recovered_253_co[1] = (recovered_253_s[1] & recovered_253_co[0]) | (~recovered_253_s[1] & recovered_253_di[1]);
  assign recovered_253_o[2] = recovered_253_s[2] ^ recovered_253_co[1];
  assign recovered_253_co[2] = (recovered_253_s[2] & recovered_253_co[1]) | (~recovered_253_s[2] & recovered_253_di[2]);
  assign recovered_253_o[3] = recovered_253_s[3] ^ recovered_253_co[2];
  assign recovered_253_co[3] = (recovered_253_s[3] & recovered_253_co[2]) | (~recovered_253_s[3] & recovered_253_di[3]);
  assign {esc_add_ln208_42_reg_7073_reg_8_b2dae6f [9],esc_NLW_add_ln208_45_reg_7125_reg_9__i_1_CO_UNCONNECTED_9eb3970 [0]} = recovered_253_co;
  assign esc_add_ln208_42_reg_7073_reg_8_b2dae6f [8] = recovered_253_o;

  // Reconstructed LUT2: esc_add_ln208_48_reg_7177_3__i_2_0156e50
  assign esc_add_ln208_48_reg_7177_3__i_2_n_0_8c9f566 = ((DOADO[3]) ? (~(esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [3])) : (esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [3]));

  // Reconstructed LUT2: esc_add_ln208_48_reg_7177_3__i_3_1af8c39
  assign esc_add_ln208_48_reg_7177_3__i_3_n_0_7bc60e1 = ((DOADO[2]) ? (~(esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [2])) : (esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [2]));

  // Reconstructed LUT2: esc_add_ln208_48_reg_7177_3__i_4_a6527f1
  assign esc_add_ln208_48_reg_7177_3__i_4_n_0_e2e6a58 = ((DOADO[1]) ? (~(esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [1])) : (esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [1]));

  // Reconstructed LUT2: esc_add_ln208_48_reg_7177_3__i_5_c95d594
  assign esc_add_ln208_48_reg_7177_3__i_5_n_0_d294376 = ((DOADO[0]) ? (~(esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [0])) : (esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [0]));

  // Reconstructed LUT2: esc_add_ln208_48_reg_7177_7__i_2_df6e7d1
  assign esc_add_ln208_48_reg_7177_7__i_2_n_0_13c4a26 = ((DOADO[7]) ? (~(esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [7])) : (esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [7]));

  // Reconstructed LUT2: esc_add_ln208_48_reg_7177_7__i_3_eacb772
  assign esc_add_ln208_48_reg_7177_7__i_3_n_0_6f19840 = ((DOADO[6]) ? (~(esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [6])) : (esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [6]));

  // Reconstructed LUT2: esc_add_ln208_48_reg_7177_7__i_4_081162e
  assign esc_add_ln208_48_reg_7177_7__i_4_n_0_38ca192 = ((DOADO[5]) ? (~(esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [5])) : (esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [5]));

  // Reconstructed LUT2: esc_add_ln208_48_reg_7177_7__i_5_ede57d8
  assign esc_add_ln208_48_reg_7177_7__i_5_n_0_77c59f6 = ((DOADO[4]) ? (~(esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [4])) : (esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [4]));

  // Reconstructed CARRY4: esc_add_ln208_48_reg_7177_reg_3__i_1_96d6351
  wire [3:0] recovered_262_co, recovered_262_o, recovered_262_s, recovered_262_di;
  assign recovered_262_s = {esc_add_ln208_48_reg_7177_3__i_2_n_0_8c9f566 ,esc_add_ln208_48_reg_7177_3__i_3_n_0_7bc60e1 ,esc_add_ln208_48_reg_7177_3__i_4_n_0_e2e6a58 ,esc_add_ln208_48_reg_7177_3__i_5_n_0_d294376 };
  assign recovered_262_di = esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [3:0];
  wire recovered_262_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_262_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_262_o[0] = recovered_262_s[0] ^ (recovered_262_ci || recovered_262_cy);
  assign recovered_262_co[0] = (recovered_262_s[0] & (recovered_262_ci || recovered_262_cy)) | (~recovered_262_s[0] & recovered_262_di[0]);
  assign recovered_262_o[1] = recovered_262_s[1] ^ recovered_262_co[0];
  assign recovered_262_co[1] = (recovered_262_s[1] & recovered_262_co[0]) | (~recovered_262_s[1] & recovered_262_di[1]);
  assign recovered_262_o[2] = recovered_262_s[2] ^ recovered_262_co[1];
  assign recovered_262_co[2] = (recovered_262_s[2] & recovered_262_co[1]) | (~recovered_262_s[2] & recovered_262_di[2]);
  assign recovered_262_o[3] = recovered_262_s[3] ^ recovered_262_co[2];
  assign recovered_262_co[3] = (recovered_262_s[3] & recovered_262_co[2]) | (~recovered_262_s[3] & recovered_262_di[3]);
  assign {esc_add_ln208_48_reg_7177_reg_3__i_1_n_0_cf94cb4 ,esc_NLW_add_ln208_48_reg_7177_reg_3__i_1_CO_UNCONNECTED_53c59d1 [2:0]} = recovered_262_co;
  assign esc_add_ln208_45_reg_7125_reg_9_8959fd9 [3:0] = recovered_262_o;

  // Reconstructed CARRY4: esc_add_ln208_48_reg_7177_reg_7__i_1_e7f8ce7
  wire [3:0] recovered_263_co, recovered_263_o, recovered_263_s, recovered_263_di;
  assign recovered_263_s = {esc_add_ln208_48_reg_7177_7__i_2_n_0_13c4a26 ,esc_add_ln208_48_reg_7177_7__i_3_n_0_6f19840 ,esc_add_ln208_48_reg_7177_7__i_4_n_0_38ca192 ,esc_add_ln208_48_reg_7177_7__i_5_n_0_77c59f6 };
  assign recovered_263_di = esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [7:4];
  wire recovered_263_ci = ((esc_add_ln208_48_reg_7177_reg_3__i_1_n_0_cf94cb4) !== 1'bz) && (esc_add_ln208_48_reg_7177_reg_3__i_1_n_0_cf94cb4);
  wire recovered_263_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_263_o[0] = recovered_263_s[0] ^ (recovered_263_ci || recovered_263_cy);
  assign recovered_263_co[0] = (recovered_263_s[0] & (recovered_263_ci || recovered_263_cy)) | (~recovered_263_s[0] & recovered_263_di[0]);
  assign recovered_263_o[1] = recovered_263_s[1] ^ recovered_263_co[0];
  assign recovered_263_co[1] = (recovered_263_s[1] & recovered_263_co[0]) | (~recovered_263_s[1] & recovered_263_di[1]);
  assign recovered_263_o[2] = recovered_263_s[2] ^ recovered_263_co[1];
  assign recovered_263_co[2] = (recovered_263_s[2] & recovered_263_co[1]) | (~recovered_263_s[2] & recovered_263_di[2]);
  assign recovered_263_o[3] = recovered_263_s[3] ^ recovered_263_co[2];
  assign recovered_263_co[3] = (recovered_263_s[3] & recovered_263_co[2]) | (~recovered_263_s[3] & recovered_263_di[3]);
  assign {esc_add_ln208_48_reg_7177_reg_7__i_1_n_0_cae23a0 ,esc_NLW_add_ln208_48_reg_7177_reg_7__i_1_CO_UNCONNECTED_a414955 [2:0]} = recovered_263_co;
  assign esc_add_ln208_45_reg_7125_reg_9_8959fd9 [7:4] = recovered_263_o;

  // Reconstructed CARRY4: esc_add_ln208_48_reg_7177_reg_9__i_1_4c5f8d4
  wire [3:0] recovered_264_co, recovered_264_o, recovered_264_s, recovered_264_di;
  assign recovered_264_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_48_reg_7177_reg_9__0_b5815e9 [9:8]};
  assign recovered_264_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_264_ci = ((esc_add_ln208_48_reg_7177_reg_7__i_1_n_0_cae23a0) !== 1'bz) && (esc_add_ln208_48_reg_7177_reg_7__i_1_n_0_cae23a0);
  wire recovered_264_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_264_o[0] = recovered_264_s[0] ^ (recovered_264_ci || recovered_264_cy);
  assign recovered_264_co[0] = (recovered_264_s[0] & (recovered_264_ci || recovered_264_cy)) | (~recovered_264_s[0] & recovered_264_di[0]);
  assign recovered_264_o[1] = recovered_264_s[1] ^ recovered_264_co[0];
  assign recovered_264_co[1] = (recovered_264_s[1] & recovered_264_co[0]) | (~recovered_264_s[1] & recovered_264_di[1]);
  assign recovered_264_o[2] = recovered_264_s[2] ^ recovered_264_co[1];
  assign recovered_264_co[2] = (recovered_264_s[2] & recovered_264_co[1]) | (~recovered_264_s[2] & recovered_264_di[2]);
  assign recovered_264_o[3] = recovered_264_s[3] ^ recovered_264_co[2];
  assign recovered_264_co[3] = (recovered_264_s[3] & recovered_264_co[2]) | (~recovered_264_s[3] & recovered_264_di[3]);
  assign esc_add_ln208_45_reg_7125_reg_9_8959fd9 [9:8] = recovered_264_o;

  // Reconstructed LUT2: esc_add_ln208_51_reg_7229_3__i_2_a30d1c5
  assign esc_add_ln208_51_reg_7229_3__i_2_n_0_4693b30 = ((DOADO[3]) ? (~(esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [3])) : (esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [3]));

  // Reconstructed LUT2: esc_add_ln208_51_reg_7229_3__i_3_461ee77
  assign esc_add_ln208_51_reg_7229_3__i_3_n_0_3fe0616 = ((DOADO[2]) ? (~(esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [2])) : (esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [2]));

  // Reconstructed LUT2: esc_add_ln208_51_reg_7229_3__i_4_3da8779
  assign esc_add_ln208_51_reg_7229_3__i_4_n_0_7dd75c8 = ((DOADO[1]) ? (~(esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [1])) : (esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [1]));

  // Reconstructed LUT2: esc_add_ln208_51_reg_7229_3__i_5_5eb686f
  assign esc_add_ln208_51_reg_7229_3__i_5_n_0_84e510e = ((DOADO[0]) ? (~(esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [0])) : (esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [0]));

  // Reconstructed LUT2: esc_add_ln208_51_reg_7229_7__i_2_0dd4d9c
  assign esc_add_ln208_51_reg_7229_7__i_2_n_0_f00b7af = ((DOADO[7]) ? (~(esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [7])) : (esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [7]));

  // Reconstructed LUT2: esc_add_ln208_51_reg_7229_7__i_3_037b336
  assign esc_add_ln208_51_reg_7229_7__i_3_n_0_70cce66 = ((DOADO[6]) ? (~(esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [6])) : (esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [6]));

  // Reconstructed LUT2: esc_add_ln208_51_reg_7229_7__i_4_786039c
  assign esc_add_ln208_51_reg_7229_7__i_4_n_0_29b6d46 = ((DOADO[5]) ? (~(esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [5])) : (esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [5]));

  // Reconstructed LUT2: esc_add_ln208_51_reg_7229_7__i_5_fafeedf
  assign esc_add_ln208_51_reg_7229_7__i_5_n_0_efcadb8 = ((DOADO[4]) ? (~(esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [4])) : (esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [4]));

  // Reconstructed CARRY4: esc_add_ln208_51_reg_7229_reg_10__i_1_04276a8
  wire [3:0] recovered_273_co, recovered_273_o, recovered_273_s, recovered_273_di;
  assign recovered_273_s = {esc_const0_a0cf646 ,esc_const1_c064970 ,esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [9:8]};
  assign recovered_273_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_273_ci = ((esc_add_ln208_51_reg_7229_reg_7__i_1_n_0_3de2fbb) !== 1'bz) && (esc_add_ln208_51_reg_7229_reg_7__i_1_n_0_3de2fbb);
  wire recovered_273_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_273_o[0] = recovered_273_s[0] ^ (recovered_273_ci || recovered_273_cy);
  assign recovered_273_co[0] = (recovered_273_s[0] & (recovered_273_ci || recovered_273_cy)) | (~recovered_273_s[0] & recovered_273_di[0]);
  assign recovered_273_o[1] = recovered_273_s[1] ^ recovered_273_co[0];
  assign recovered_273_co[1] = (recovered_273_s[1] & recovered_273_co[0]) | (~recovered_273_s[1] & recovered_273_di[1]);
  assign recovered_273_o[2] = recovered_273_s[2] ^ recovered_273_co[1];
  assign recovered_273_co[2] = (recovered_273_s[2] & recovered_273_co[1]) | (~recovered_273_s[2] & recovered_273_di[2]);
  assign recovered_273_o[3] = recovered_273_s[3] ^ recovered_273_co[2];
  assign recovered_273_co[3] = (recovered_273_s[3] & recovered_273_co[2]) | (~recovered_273_s[3] & recovered_273_di[3]);
  assign {esc_add_ln208_48_reg_7177_reg_9_c78b76f [10],esc_NLW_add_ln208_51_reg_7229_reg_10__i_1_CO_UNCONNECTED_ddf3e97 [1:0]} = recovered_273_co;
  assign esc_add_ln208_48_reg_7177_reg_9_c78b76f [9:8] = recovered_273_o;

  // Reconstructed CARRY4: esc_add_ln208_51_reg_7229_reg_3__i_1_ad84225
  wire [3:0] recovered_274_co, recovered_274_o, recovered_274_s, recovered_274_di;
  assign recovered_274_s = {esc_add_ln208_51_reg_7229_3__i_2_n_0_4693b30 ,esc_add_ln208_51_reg_7229_3__i_3_n_0_3fe0616 ,esc_add_ln208_51_reg_7229_3__i_4_n_0_7dd75c8 ,esc_add_ln208_51_reg_7229_3__i_5_n_0_84e510e };
  assign recovered_274_di = esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [3:0];
  wire recovered_274_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_274_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_274_o[0] = recovered_274_s[0] ^ (recovered_274_ci || recovered_274_cy);
  assign recovered_274_co[0] = (recovered_274_s[0] & (recovered_274_ci || recovered_274_cy)) | (~recovered_274_s[0] & recovered_274_di[0]);
  assign recovered_274_o[1] = recovered_274_s[1] ^ recovered_274_co[0];
  assign recovered_274_co[1] = (recovered_274_s[1] & recovered_274_co[0]) | (~recovered_274_s[1] & recovered_274_di[1]);
  assign recovered_274_o[2] = recovered_274_s[2] ^ recovered_274_co[1];
  assign recovered_274_co[2] = (recovered_274_s[2] & recovered_274_co[1]) | (~recovered_274_s[2] & recovered_274_di[2]);
  assign recovered_274_o[3] = recovered_274_s[3] ^ recovered_274_co[2];
  assign recovered_274_co[3] = (recovered_274_s[3] & recovered_274_co[2]) | (~recovered_274_s[3] & recovered_274_di[3]);
  assign {esc_add_ln208_51_reg_7229_reg_3__i_1_n_0_ec89a1a ,esc_NLW_add_ln208_51_reg_7229_reg_3__i_1_CO_UNCONNECTED_e2160b3 [2:0]} = recovered_274_co;
  assign esc_add_ln208_48_reg_7177_reg_9_c78b76f [3:0] = recovered_274_o;

  // Reconstructed CARRY4: esc_add_ln208_51_reg_7229_reg_7__i_1_f7ff13f
  wire [3:0] recovered_275_co, recovered_275_o, recovered_275_s, recovered_275_di;
  assign recovered_275_s = {esc_add_ln208_51_reg_7229_7__i_2_n_0_f00b7af ,esc_add_ln208_51_reg_7229_7__i_3_n_0_70cce66 ,esc_add_ln208_51_reg_7229_7__i_4_n_0_29b6d46 ,esc_add_ln208_51_reg_7229_7__i_5_n_0_efcadb8 };
  assign recovered_275_di = esc_add_ln208_51_reg_7229_reg_10__0_bbe5c4b [7:4];
  wire recovered_275_ci = ((esc_add_ln208_51_reg_7229_reg_3__i_1_n_0_ec89a1a) !== 1'bz) && (esc_add_ln208_51_reg_7229_reg_3__i_1_n_0_ec89a1a);
  wire recovered_275_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_275_o[0] = recovered_275_s[0] ^ (recovered_275_ci || recovered_275_cy);
  assign recovered_275_co[0] = (recovered_275_s[0] & (recovered_275_ci || recovered_275_cy)) | (~recovered_275_s[0] & recovered_275_di[0]);
  assign recovered_275_o[1] = recovered_275_s[1] ^ recovered_275_co[0];
  assign recovered_275_co[1] = (recovered_275_s[1] & recovered_275_co[0]) | (~recovered_275_s[1] & recovered_275_di[1]);
  assign recovered_275_o[2] = recovered_275_s[2] ^ recovered_275_co[1];
  assign recovered_275_co[2] = (recovered_275_s[2] & recovered_275_co[1]) | (~recovered_275_s[2] & recovered_275_di[2]);
  assign recovered_275_o[3] = recovered_275_s[3] ^ recovered_275_co[2];
  assign recovered_275_co[3] = (recovered_275_s[3] & recovered_275_co[2]) | (~recovered_275_s[3] & recovered_275_di[3]);
  assign {esc_add_ln208_51_reg_7229_reg_7__i_1_n_0_3de2fbb ,esc_NLW_add_ln208_51_reg_7229_reg_7__i_1_CO_UNCONNECTED_9fbbfa8 [2:0]} = recovered_275_co;
  assign esc_add_ln208_48_reg_7177_reg_9_c78b76f [7:4] = recovered_275_o;

  // Reconstructed LUT2: esc_add_ln208_54_reg_7281_3__i_2_13deb79
  assign esc_add_ln208_54_reg_7281_3__i_2_n_0_3b080d8 = ((DOADO[3]) ? (~(esc_add_ln208_54_reg_7281_reg_10__0_56b943a [3])) : (esc_add_ln208_54_reg_7281_reg_10__0_56b943a [3]));

  // Reconstructed LUT2: esc_add_ln208_54_reg_7281_3__i_3_d36c52d
  assign esc_add_ln208_54_reg_7281_3__i_3_n_0_8c93cb8 = ((DOADO[2]) ? (~(esc_add_ln208_54_reg_7281_reg_10__0_56b943a [2])) : (esc_add_ln208_54_reg_7281_reg_10__0_56b943a [2]));

  // Reconstructed LUT2: esc_add_ln208_54_reg_7281_3__i_4_2dbfba8
  assign esc_add_ln208_54_reg_7281_3__i_4_n_0_c9fecec = ((DOADO[1]) ? (~(esc_add_ln208_54_reg_7281_reg_10__0_56b943a [1])) : (esc_add_ln208_54_reg_7281_reg_10__0_56b943a [1]));

  // Reconstructed LUT2: esc_add_ln208_54_reg_7281_3__i_5_a18cad9
  assign esc_add_ln208_54_reg_7281_3__i_5_n_0_cbad84d = ((DOADO[0]) ? (~(esc_add_ln208_54_reg_7281_reg_10__0_56b943a [0])) : (esc_add_ln208_54_reg_7281_reg_10__0_56b943a [0]));

  // Reconstructed LUT2: esc_add_ln208_54_reg_7281_7__i_2_90fe83a
  assign esc_add_ln208_54_reg_7281_7__i_2_n_0_acab14d = ((DOADO[7]) ? (~(esc_add_ln208_54_reg_7281_reg_10__0_56b943a [7])) : (esc_add_ln208_54_reg_7281_reg_10__0_56b943a [7]));

  // Reconstructed LUT2: esc_add_ln208_54_reg_7281_7__i_3_c1ef190
  assign esc_add_ln208_54_reg_7281_7__i_3_n_0_d03d681 = ((DOADO[6]) ? (~(esc_add_ln208_54_reg_7281_reg_10__0_56b943a [6])) : (esc_add_ln208_54_reg_7281_reg_10__0_56b943a [6]));

  // Reconstructed LUT2: esc_add_ln208_54_reg_7281_7__i_4_cc340f0
  assign esc_add_ln208_54_reg_7281_7__i_4_n_0_5a1ee75 = ((DOADO[5]) ? (~(esc_add_ln208_54_reg_7281_reg_10__0_56b943a [5])) : (esc_add_ln208_54_reg_7281_reg_10__0_56b943a [5]));

  // Reconstructed LUT2: esc_add_ln208_54_reg_7281_7__i_5_c6a9a5f
  assign esc_add_ln208_54_reg_7281_7__i_5_n_0_bb8dcfb = ((DOADO[4]) ? (~(esc_add_ln208_54_reg_7281_reg_10__0_56b943a [4])) : (esc_add_ln208_54_reg_7281_reg_10__0_56b943a [4]));

  // Reconstructed CARRY4: esc_add_ln208_54_reg_7281_reg_10__i_1_2981e56
  wire [3:0] recovered_284_co, recovered_284_o, recovered_284_s, recovered_284_di;
  assign recovered_284_s = {esc_const0_a0cf646 ,esc_add_ln208_54_reg_7281_reg_10__0_56b943a [10:8]};
  assign recovered_284_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_284_ci = ((esc_add_ln208_54_reg_7281_reg_7__i_1_n_0_95a17ae) !== 1'bz) && (esc_add_ln208_54_reg_7281_reg_7__i_1_n_0_95a17ae);
  wire recovered_284_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_284_o[0] = recovered_284_s[0] ^ (recovered_284_ci || recovered_284_cy);
  assign recovered_284_co[0] = (recovered_284_s[0] & (recovered_284_ci || recovered_284_cy)) | (~recovered_284_s[0] & recovered_284_di[0]);
  assign recovered_284_o[1] = recovered_284_s[1] ^ recovered_284_co[0];
  assign recovered_284_co[1] = (recovered_284_s[1] & recovered_284_co[0]) | (~recovered_284_s[1] & recovered_284_di[1]);
  assign recovered_284_o[2] = recovered_284_s[2] ^ recovered_284_co[1];
  assign recovered_284_co[2] = (recovered_284_s[2] & recovered_284_co[1]) | (~recovered_284_s[2] & recovered_284_di[2]);
  assign recovered_284_o[3] = recovered_284_s[3] ^ recovered_284_co[2];
  assign recovered_284_co[3] = (recovered_284_s[3] & recovered_284_co[2]) | (~recovered_284_s[3] & recovered_284_di[3]);
  assign esc_add_ln208_51_reg_7229_reg_10_08c463a [10:8] = recovered_284_o;

  // Reconstructed CARRY4: esc_add_ln208_54_reg_7281_reg_3__i_1_6c77f6d
  wire [3:0] recovered_285_co, recovered_285_o, recovered_285_s, recovered_285_di;
  assign recovered_285_s = {esc_add_ln208_54_reg_7281_3__i_2_n_0_3b080d8 ,esc_add_ln208_54_reg_7281_3__i_3_n_0_8c93cb8 ,esc_add_ln208_54_reg_7281_3__i_4_n_0_c9fecec ,esc_add_ln208_54_reg_7281_3__i_5_n_0_cbad84d };
  assign recovered_285_di = esc_add_ln208_54_reg_7281_reg_10__0_56b943a [3:0];
  wire recovered_285_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_285_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_285_o[0] = recovered_285_s[0] ^ (recovered_285_ci || recovered_285_cy);
  assign recovered_285_co[0] = (recovered_285_s[0] & (recovered_285_ci || recovered_285_cy)) | (~recovered_285_s[0] & recovered_285_di[0]);
  assign recovered_285_o[1] = recovered_285_s[1] ^ recovered_285_co[0];
  assign recovered_285_co[1] = (recovered_285_s[1] & recovered_285_co[0]) | (~recovered_285_s[1] & recovered_285_di[1]);
  assign recovered_285_o[2] = recovered_285_s[2] ^ recovered_285_co[1];
  assign recovered_285_co[2] = (recovered_285_s[2] & recovered_285_co[1]) | (~recovered_285_s[2] & recovered_285_di[2]);
  assign recovered_285_o[3] = recovered_285_s[3] ^ recovered_285_co[2];
  assign recovered_285_co[3] = (recovered_285_s[3] & recovered_285_co[2]) | (~recovered_285_s[3] & recovered_285_di[3]);
  assign {esc_add_ln208_54_reg_7281_reg_3__i_1_n_0_cd4f567 ,esc_NLW_add_ln208_54_reg_7281_reg_3__i_1_CO_UNCONNECTED_2bf697f [2:0]} = recovered_285_co;
  assign esc_add_ln208_51_reg_7229_reg_10_08c463a [3:0] = recovered_285_o;

  // Reconstructed CARRY4: esc_add_ln208_54_reg_7281_reg_7__i_1_19ad9d8
  wire [3:0] recovered_286_co, recovered_286_o, recovered_286_s, recovered_286_di;
  assign recovered_286_s = {esc_add_ln208_54_reg_7281_7__i_2_n_0_acab14d ,esc_add_ln208_54_reg_7281_7__i_3_n_0_d03d681 ,esc_add_ln208_54_reg_7281_7__i_4_n_0_5a1ee75 ,esc_add_ln208_54_reg_7281_7__i_5_n_0_bb8dcfb };
  assign recovered_286_di = esc_add_ln208_54_reg_7281_reg_10__0_56b943a [7:4];
  wire recovered_286_ci = ((esc_add_ln208_54_reg_7281_reg_3__i_1_n_0_cd4f567) !== 1'bz) && (esc_add_ln208_54_reg_7281_reg_3__i_1_n_0_cd4f567);
  wire recovered_286_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_286_o[0] = recovered_286_s[0] ^ (recovered_286_ci || recovered_286_cy);
  assign recovered_286_co[0] = (recovered_286_s[0] & (recovered_286_ci || recovered_286_cy)) | (~recovered_286_s[0] & recovered_286_di[0]);
  assign recovered_286_o[1] = recovered_286_s[1] ^ recovered_286_co[0];
  assign recovered_286_co[1] = (recovered_286_s[1] & recovered_286_co[0]) | (~recovered_286_s[1] & recovered_286_di[1]);
  assign recovered_286_o[2] = recovered_286_s[2] ^ recovered_286_co[1];
  assign recovered_286_co[2] = (recovered_286_s[2] & recovered_286_co[1]) | (~recovered_286_s[2] & recovered_286_di[2]);
  assign recovered_286_o[3] = recovered_286_s[3] ^ recovered_286_co[2];
  assign recovered_286_co[3] = (recovered_286_s[3] & recovered_286_co[2]) | (~recovered_286_s[3] & recovered_286_di[3]);
  assign {esc_add_ln208_54_reg_7281_reg_7__i_1_n_0_95a17ae ,esc_NLW_add_ln208_54_reg_7281_reg_7__i_1_CO_UNCONNECTED_7791604 [2:0]} = recovered_286_co;
  assign esc_add_ln208_51_reg_7229_reg_10_08c463a [7:4] = recovered_286_o;

  // Reconstructed LUT2: esc_add_ln208_57_reg_7333_3__i_2_0633458
  assign esc_add_ln208_57_reg_7333_3__i_2_n_0_2becd2c = ((DOADO[3]) ? (~(esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [3])) : (esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [3]));

  // Reconstructed LUT2: esc_add_ln208_57_reg_7333_3__i_3_c720d97
  assign esc_add_ln208_57_reg_7333_3__i_3_n_0_606e4d6 = ((DOADO[2]) ? (~(esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [2])) : (esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [2]));

  // Reconstructed LUT2: esc_add_ln208_57_reg_7333_3__i_4_1e24710
  assign esc_add_ln208_57_reg_7333_3__i_4_n_0_279edcd = ((DOADO[1]) ? (~(esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [1])) : (esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [1]));

  // Reconstructed LUT2: esc_add_ln208_57_reg_7333_3__i_5_80f962f
  assign esc_add_ln208_57_reg_7333_3__i_5_n_0_04c5953 = ((DOADO[0]) ? (~(esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [0])) : (esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [0]));

  // Reconstructed LUT2: esc_add_ln208_57_reg_7333_7__i_2_5f9e116
  assign esc_add_ln208_57_reg_7333_7__i_2_n_0_4f4834a = ((DOADO[7]) ? (~(esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [7])) : (esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [7]));

  // Reconstructed LUT2: esc_add_ln208_57_reg_7333_7__i_3_bfaa829
  assign esc_add_ln208_57_reg_7333_7__i_3_n_0_d130c79 = ((DOADO[6]) ? (~(esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [6])) : (esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [6]));

  // Reconstructed LUT2: esc_add_ln208_57_reg_7333_7__i_4_cb720ba
  assign esc_add_ln208_57_reg_7333_7__i_4_n_0_c1613c8 = ((DOADO[5]) ? (~(esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [5])) : (esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [5]));

  // Reconstructed LUT2: esc_add_ln208_57_reg_7333_7__i_5_7820a79
  assign esc_add_ln208_57_reg_7333_7__i_5_n_0_4ebe9aa = ((DOADO[4]) ? (~(esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [4])) : (esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [4]));

  // Reconstructed CARRY4: esc_add_ln208_57_reg_7333_reg_10__i_1_d0a9fb2
  wire [3:0] recovered_295_co, recovered_295_o, recovered_295_s, recovered_295_di;
  assign recovered_295_s = {esc_const0_a0cf646 ,esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [10:8]};
  assign recovered_295_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_295_ci = ((esc_add_ln208_57_reg_7333_reg_7__i_1_n_0_384af07) !== 1'bz) && (esc_add_ln208_57_reg_7333_reg_7__i_1_n_0_384af07);
  wire recovered_295_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_295_o[0] = recovered_295_s[0] ^ (recovered_295_ci || recovered_295_cy);
  assign recovered_295_co[0] = (recovered_295_s[0] & (recovered_295_ci || recovered_295_cy)) | (~recovered_295_s[0] & recovered_295_di[0]);
  assign recovered_295_o[1] = recovered_295_s[1] ^ recovered_295_co[0];
  assign recovered_295_co[1] = (recovered_295_s[1] & recovered_295_co[0]) | (~recovered_295_s[1] & recovered_295_di[1]);
  assign recovered_295_o[2] = recovered_295_s[2] ^ recovered_295_co[1];
  assign recovered_295_co[2] = (recovered_295_s[2] & recovered_295_co[1]) | (~recovered_295_s[2] & recovered_295_di[2]);
  assign recovered_295_o[3] = recovered_295_s[3] ^ recovered_295_co[2];
  assign recovered_295_co[3] = (recovered_295_s[3] & recovered_295_co[2]) | (~recovered_295_s[3] & recovered_295_di[3]);
  assign esc_add_ln208_54_reg_7281_reg_10_5a808fe [10:8] = recovered_295_o;

  // Reconstructed CARRY4: esc_add_ln208_57_reg_7333_reg_3__i_1_3e37c4e
  wire [3:0] recovered_296_co, recovered_296_o, recovered_296_s, recovered_296_di;
  assign recovered_296_s = {esc_add_ln208_57_reg_7333_3__i_2_n_0_2becd2c ,esc_add_ln208_57_reg_7333_3__i_3_n_0_606e4d6 ,esc_add_ln208_57_reg_7333_3__i_4_n_0_279edcd ,esc_add_ln208_57_reg_7333_3__i_5_n_0_04c5953 };
  assign recovered_296_di = esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [3:0];
  wire recovered_296_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_296_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_296_o[0] = recovered_296_s[0] ^ (recovered_296_ci || recovered_296_cy);
  assign recovered_296_co[0] = (recovered_296_s[0] & (recovered_296_ci || recovered_296_cy)) | (~recovered_296_s[0] & recovered_296_di[0]);
  assign recovered_296_o[1] = recovered_296_s[1] ^ recovered_296_co[0];
  assign recovered_296_co[1] = (recovered_296_s[1] & recovered_296_co[0]) | (~recovered_296_s[1] & recovered_296_di[1]);
  assign recovered_296_o[2] = recovered_296_s[2] ^ recovered_296_co[1];
  assign recovered_296_co[2] = (recovered_296_s[2] & recovered_296_co[1]) | (~recovered_296_s[2] & recovered_296_di[2]);
  assign recovered_296_o[3] = recovered_296_s[3] ^ recovered_296_co[2];
  assign recovered_296_co[3] = (recovered_296_s[3] & recovered_296_co[2]) | (~recovered_296_s[3] & recovered_296_di[3]);
  assign {esc_add_ln208_57_reg_7333_reg_3__i_1_n_0_f7dfc85 ,esc_NLW_add_ln208_57_reg_7333_reg_3__i_1_CO_UNCONNECTED_273e648 [2:0]} = recovered_296_co;
  assign esc_add_ln208_54_reg_7281_reg_10_5a808fe [3:0] = recovered_296_o;

  // Reconstructed CARRY4: esc_add_ln208_57_reg_7333_reg_7__i_1_4d4c749
  wire [3:0] recovered_297_co, recovered_297_o, recovered_297_s, recovered_297_di;
  assign recovered_297_s = {esc_add_ln208_57_reg_7333_7__i_2_n_0_4f4834a ,esc_add_ln208_57_reg_7333_7__i_3_n_0_d130c79 ,esc_add_ln208_57_reg_7333_7__i_4_n_0_c1613c8 ,esc_add_ln208_57_reg_7333_7__i_5_n_0_4ebe9aa };
  assign recovered_297_di = esc_add_ln208_57_reg_7333_reg_10__0_06e9277 [7:4];
  wire recovered_297_ci = ((esc_add_ln208_57_reg_7333_reg_3__i_1_n_0_f7dfc85) !== 1'bz) && (esc_add_ln208_57_reg_7333_reg_3__i_1_n_0_f7dfc85);
  wire recovered_297_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_297_o[0] = recovered_297_s[0] ^ (recovered_297_ci || recovered_297_cy);
  assign recovered_297_co[0] = (recovered_297_s[0] & (recovered_297_ci || recovered_297_cy)) | (~recovered_297_s[0] & recovered_297_di[0]);
  assign recovered_297_o[1] = recovered_297_s[1] ^ recovered_297_co[0];
  assign recovered_297_co[1] = (recovered_297_s[1] & recovered_297_co[0]) | (~recovered_297_s[1] & recovered_297_di[1]);
  assign recovered_297_o[2] = recovered_297_s[2] ^ recovered_297_co[1];
  assign recovered_297_co[2] = (recovered_297_s[2] & recovered_297_co[1]) | (~recovered_297_s[2] & recovered_297_di[2]);
  assign recovered_297_o[3] = recovered_297_s[3] ^ recovered_297_co[2];
  assign recovered_297_co[3] = (recovered_297_s[3] & recovered_297_co[2]) | (~recovered_297_s[3] & recovered_297_di[3]);
  assign {esc_add_ln208_57_reg_7333_reg_7__i_1_n_0_384af07 ,esc_NLW_add_ln208_57_reg_7333_reg_7__i_1_CO_UNCONNECTED_fa273cf [2:0]} = recovered_297_co;
  assign esc_add_ln208_54_reg_7281_reg_10_5a808fe [7:4] = recovered_297_o;

  // Reconstructed LUT2: esc_add_ln208_60_reg_7385_3__i_2_4827521
  assign esc_add_ln208_60_reg_7385_3__i_2_n_0_4bc3aa4 = ((DOADO[3]) ? (~(esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [3])) : (esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [3]));

  // Reconstructed LUT2: esc_add_ln208_60_reg_7385_3__i_3_f23ea33
  assign esc_add_ln208_60_reg_7385_3__i_3_n_0_448e9b8 = ((DOADO[2]) ? (~(esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [2])) : (esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [2]));

  // Reconstructed LUT2: esc_add_ln208_60_reg_7385_3__i_4_0b20ade
  assign esc_add_ln208_60_reg_7385_3__i_4_n_0_8ab84cc = ((DOADO[1]) ? (~(esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [1])) : (esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [1]));

  // Reconstructed LUT2: esc_add_ln208_60_reg_7385_3__i_5_c088145
  assign esc_add_ln208_60_reg_7385_3__i_5_n_0_0dadd5d = ((DOADO[0]) ? (~(esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [0])) : (esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [0]));

  // Reconstructed LUT2: esc_add_ln208_60_reg_7385_7__i_2_2927bcd
  assign esc_add_ln208_60_reg_7385_7__i_2_n_0_b6404b5 = ((DOADO[7]) ? (~(esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [7])) : (esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [7]));

  // Reconstructed LUT2: esc_add_ln208_60_reg_7385_7__i_3_8f093c0
  assign esc_add_ln208_60_reg_7385_7__i_3_n_0_d6507a1 = ((DOADO[6]) ? (~(esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [6])) : (esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [6]));

  // Reconstructed LUT2: esc_add_ln208_60_reg_7385_7__i_4_ea9eb72
  assign esc_add_ln208_60_reg_7385_7__i_4_n_0_3abb497 = ((DOADO[5]) ? (~(esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [5])) : (esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [5]));

  // Reconstructed LUT2: esc_add_ln208_60_reg_7385_7__i_5_1c6f3a7
  assign esc_add_ln208_60_reg_7385_7__i_5_n_0_a9e6e8b = ((DOADO[4]) ? (~(esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [4])) : (esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [4]));

  // Reconstructed CARRY4: esc_add_ln208_60_reg_7385_reg_10__i_1_2191541
  wire [3:0] recovered_306_co, recovered_306_o, recovered_306_s, recovered_306_di;
  assign recovered_306_s = {esc_const0_a0cf646 ,esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [10:8]};
  assign recovered_306_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_306_ci = ((esc_add_ln208_60_reg_7385_reg_7__i_1_n_0_0eba9d8) !== 1'bz) && (esc_add_ln208_60_reg_7385_reg_7__i_1_n_0_0eba9d8);
  wire recovered_306_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_306_o[0] = recovered_306_s[0] ^ (recovered_306_ci || recovered_306_cy);
  assign recovered_306_co[0] = (recovered_306_s[0] & (recovered_306_ci || recovered_306_cy)) | (~recovered_306_s[0] & recovered_306_di[0]);
  assign recovered_306_o[1] = recovered_306_s[1] ^ recovered_306_co[0];
  assign recovered_306_co[1] = (recovered_306_s[1] & recovered_306_co[0]) | (~recovered_306_s[1] & recovered_306_di[1]);
  assign recovered_306_o[2] = recovered_306_s[2] ^ recovered_306_co[1];
  assign recovered_306_co[2] = (recovered_306_s[2] & recovered_306_co[1]) | (~recovered_306_s[2] & recovered_306_di[2]);
  assign recovered_306_o[3] = recovered_306_s[3] ^ recovered_306_co[2];
  assign recovered_306_co[3] = (recovered_306_s[3] & recovered_306_co[2]) | (~recovered_306_s[3] & recovered_306_di[3]);
  assign esc_add_ln208_57_reg_7333_reg_10_4817937 [10:8] = recovered_306_o;

  // Reconstructed CARRY4: esc_add_ln208_60_reg_7385_reg_3__i_1_3895e69
  wire [3:0] recovered_307_co, recovered_307_o, recovered_307_s, recovered_307_di;
  assign recovered_307_s = {esc_add_ln208_60_reg_7385_3__i_2_n_0_4bc3aa4 ,esc_add_ln208_60_reg_7385_3__i_3_n_0_448e9b8 ,esc_add_ln208_60_reg_7385_3__i_4_n_0_8ab84cc ,esc_add_ln208_60_reg_7385_3__i_5_n_0_0dadd5d };
  assign recovered_307_di = esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [3:0];
  wire recovered_307_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_307_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_307_o[0] = recovered_307_s[0] ^ (recovered_307_ci || recovered_307_cy);
  assign recovered_307_co[0] = (recovered_307_s[0] & (recovered_307_ci || recovered_307_cy)) | (~recovered_307_s[0] & recovered_307_di[0]);
  assign recovered_307_o[1] = recovered_307_s[1] ^ recovered_307_co[0];
  assign recovered_307_co[1] = (recovered_307_s[1] & recovered_307_co[0]) | (~recovered_307_s[1] & recovered_307_di[1]);
  assign recovered_307_o[2] = recovered_307_s[2] ^ recovered_307_co[1];
  assign recovered_307_co[2] = (recovered_307_s[2] & recovered_307_co[1]) | (~recovered_307_s[2] & recovered_307_di[2]);
  assign recovered_307_o[3] = recovered_307_s[3] ^ recovered_307_co[2];
  assign recovered_307_co[3] = (recovered_307_s[3] & recovered_307_co[2]) | (~recovered_307_s[3] & recovered_307_di[3]);
  assign {esc_add_ln208_60_reg_7385_reg_3__i_1_n_0_083dfec ,esc_NLW_add_ln208_60_reg_7385_reg_3__i_1_CO_UNCONNECTED_b0fb7ff [2:0]} = recovered_307_co;
  assign esc_add_ln208_57_reg_7333_reg_10_4817937 [3:0] = recovered_307_o;

  // Reconstructed CARRY4: esc_add_ln208_60_reg_7385_reg_7__i_1_2b07fa4
  wire [3:0] recovered_308_co, recovered_308_o, recovered_308_s, recovered_308_di;
  assign recovered_308_s = {esc_add_ln208_60_reg_7385_7__i_2_n_0_b6404b5 ,esc_add_ln208_60_reg_7385_7__i_3_n_0_d6507a1 ,esc_add_ln208_60_reg_7385_7__i_4_n_0_3abb497 ,esc_add_ln208_60_reg_7385_7__i_5_n_0_a9e6e8b };
  assign recovered_308_di = esc_add_ln208_60_reg_7385_reg_10__0_c55eca4 [7:4];
  wire recovered_308_ci = ((esc_add_ln208_60_reg_7385_reg_3__i_1_n_0_083dfec) !== 1'bz) && (esc_add_ln208_60_reg_7385_reg_3__i_1_n_0_083dfec);
  wire recovered_308_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_308_o[0] = recovered_308_s[0] ^ (recovered_308_ci || recovered_308_cy);
  assign recovered_308_co[0] = (recovered_308_s[0] & (recovered_308_ci || recovered_308_cy)) | (~recovered_308_s[0] & recovered_308_di[0]);
  assign recovered_308_o[1] = recovered_308_s[1] ^ recovered_308_co[0];
  assign recovered_308_co[1] = (recovered_308_s[1] & recovered_308_co[0]) | (~recovered_308_s[1] & recovered_308_di[1]);
  assign recovered_308_o[2] = recovered_308_s[2] ^ recovered_308_co[1];
  assign recovered_308_co[2] = (recovered_308_s[2] & recovered_308_co[1]) | (~recovered_308_s[2] & recovered_308_di[2]);
  assign recovered_308_o[3] = recovered_308_s[3] ^ recovered_308_co[2];
  assign recovered_308_co[3] = (recovered_308_s[3] & recovered_308_co[2]) | (~recovered_308_s[3] & recovered_308_di[3]);
  assign {esc_add_ln208_60_reg_7385_reg_7__i_1_n_0_0eba9d8 ,esc_NLW_add_ln208_60_reg_7385_reg_7__i_1_CO_UNCONNECTED_cef90be [2:0]} = recovered_308_co;
  assign esc_add_ln208_57_reg_7333_reg_10_4817937 [7:4] = recovered_308_o;

  // Reconstructed LUT2: esc_add_ln208_63_reg_7437_3__i_2_3efccbe
  assign esc_add_ln208_63_reg_7437_3__i_2_n_0_cc0b3c2 = ((DOADO[3]) ? (~(esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [3])) : (esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [3]));

  // Reconstructed LUT2: esc_add_ln208_63_reg_7437_3__i_3_cc927ea
  assign esc_add_ln208_63_reg_7437_3__i_3_n_0_077acfe = ((DOADO[2]) ? (~(esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [2])) : (esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [2]));

  // Reconstructed LUT2: esc_add_ln208_63_reg_7437_3__i_4_1bfce3b
  assign esc_add_ln208_63_reg_7437_3__i_4_n_0_c4b93d5 = ((DOADO[1]) ? (~(esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [1])) : (esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [1]));

  // Reconstructed LUT2: esc_add_ln208_63_reg_7437_3__i_5_fd4c4c6
  assign esc_add_ln208_63_reg_7437_3__i_5_n_0_9b3ef72 = ((DOADO[0]) ? (~(esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [0])) : (esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [0]));

  // Reconstructed LUT2: esc_add_ln208_63_reg_7437_7__i_2_ec5fde3
  assign esc_add_ln208_63_reg_7437_7__i_2_n_0_f5af5ea = ((DOADO[7]) ? (~(esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [7])) : (esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [7]));

  // Reconstructed LUT2: esc_add_ln208_63_reg_7437_7__i_3_f083b5a
  assign esc_add_ln208_63_reg_7437_7__i_3_n_0_4fbf927 = ((DOADO[6]) ? (~(esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [6])) : (esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [6]));

  // Reconstructed LUT2: esc_add_ln208_63_reg_7437_7__i_4_3a18ee5
  assign esc_add_ln208_63_reg_7437_7__i_4_n_0_b8a71e4 = ((DOADO[5]) ? (~(esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [5])) : (esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [5]));

  // Reconstructed LUT2: esc_add_ln208_63_reg_7437_7__i_5_d661446
  assign esc_add_ln208_63_reg_7437_7__i_5_n_0_223c683 = ((DOADO[4]) ? (~(esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [4])) : (esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [4]));

  // Reconstructed CARRY4: esc_add_ln208_63_reg_7437_reg_11__i_1_33f59b1
  wire [3:0] recovered_317_co, recovered_317_o, recovered_317_s, recovered_317_di;
  assign recovered_317_s = {esc_const1_c064970 ,esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [10:8]};
  assign recovered_317_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_317_ci = ((esc_add_ln208_63_reg_7437_reg_7__i_1_n_0_7b9fc63) !== 1'bz) && (esc_add_ln208_63_reg_7437_reg_7__i_1_n_0_7b9fc63);
  wire recovered_317_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_317_o[0] = recovered_317_s[0] ^ (recovered_317_ci || recovered_317_cy);
  assign recovered_317_co[0] = (recovered_317_s[0] & (recovered_317_ci || recovered_317_cy)) | (~recovered_317_s[0] & recovered_317_di[0]);
  assign recovered_317_o[1] = recovered_317_s[1] ^ recovered_317_co[0];
  assign recovered_317_co[1] = (recovered_317_s[1] & recovered_317_co[0]) | (~recovered_317_s[1] & recovered_317_di[1]);
  assign recovered_317_o[2] = recovered_317_s[2] ^ recovered_317_co[1];
  assign recovered_317_co[2] = (recovered_317_s[2] & recovered_317_co[1]) | (~recovered_317_s[2] & recovered_317_di[2]);
  assign recovered_317_o[3] = recovered_317_s[3] ^ recovered_317_co[2];
  assign recovered_317_co[3] = (recovered_317_s[3] & recovered_317_co[2]) | (~recovered_317_s[3] & recovered_317_di[3]);
  assign {esc_add_ln208_60_reg_7385_reg_10_d918a34 [11],esc_NLW_add_ln208_63_reg_7437_reg_11__i_1_CO_UNCONNECTED_c6b0aab [2:0]} = recovered_317_co;
  assign esc_add_ln208_60_reg_7385_reg_10_d918a34 [10:8] = recovered_317_o;

  // Reconstructed CARRY4: esc_add_ln208_63_reg_7437_reg_3__i_1_f4c2c5b
  wire [3:0] recovered_318_co, recovered_318_o, recovered_318_s, recovered_318_di;
  assign recovered_318_s = {esc_add_ln208_63_reg_7437_3__i_2_n_0_cc0b3c2 ,esc_add_ln208_63_reg_7437_3__i_3_n_0_077acfe ,esc_add_ln208_63_reg_7437_3__i_4_n_0_c4b93d5 ,esc_add_ln208_63_reg_7437_3__i_5_n_0_9b3ef72 };
  assign recovered_318_di = esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [3:0];
  wire recovered_318_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_318_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_318_o[0] = recovered_318_s[0] ^ (recovered_318_ci || recovered_318_cy);
  assign recovered_318_co[0] = (recovered_318_s[0] & (recovered_318_ci || recovered_318_cy)) | (~recovered_318_s[0] & recovered_318_di[0]);
  assign recovered_318_o[1] = recovered_318_s[1] ^ recovered_318_co[0];
  assign recovered_318_co[1] = (recovered_318_s[1] & recovered_318_co[0]) | (~recovered_318_s[1] & recovered_318_di[1]);
  assign recovered_318_o[2] = recovered_318_s[2] ^ recovered_318_co[1];
  assign recovered_318_co[2] = (recovered_318_s[2] & recovered_318_co[1]) | (~recovered_318_s[2] & recovered_318_di[2]);
  assign recovered_318_o[3] = recovered_318_s[3] ^ recovered_318_co[2];
  assign recovered_318_co[3] = (recovered_318_s[3] & recovered_318_co[2]) | (~recovered_318_s[3] & recovered_318_di[3]);
  assign {esc_add_ln208_63_reg_7437_reg_3__i_1_n_0_f2a6ade ,esc_NLW_add_ln208_63_reg_7437_reg_3__i_1_CO_UNCONNECTED_037d0a7 [2:0]} = recovered_318_co;
  assign esc_add_ln208_60_reg_7385_reg_10_d918a34 [3:0] = recovered_318_o;

  // Reconstructed CARRY4: esc_add_ln208_63_reg_7437_reg_7__i_1_9559f7d
  wire [3:0] recovered_319_co, recovered_319_o, recovered_319_s, recovered_319_di;
  assign recovered_319_s = {esc_add_ln208_63_reg_7437_7__i_2_n_0_f5af5ea ,esc_add_ln208_63_reg_7437_7__i_3_n_0_4fbf927 ,esc_add_ln208_63_reg_7437_7__i_4_n_0_b8a71e4 ,esc_add_ln208_63_reg_7437_7__i_5_n_0_223c683 };
  assign recovered_319_di = esc_add_ln208_63_reg_7437_reg_11__0_5853d45 [7:4];
  wire recovered_319_ci = ((esc_add_ln208_63_reg_7437_reg_3__i_1_n_0_f2a6ade) !== 1'bz) && (esc_add_ln208_63_reg_7437_reg_3__i_1_n_0_f2a6ade);
  wire recovered_319_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_319_o[0] = recovered_319_s[0] ^ (recovered_319_ci || recovered_319_cy);
  assign recovered_319_co[0] = (recovered_319_s[0] & (recovered_319_ci || recovered_319_cy)) | (~recovered_319_s[0] & recovered_319_di[0]);
  assign recovered_319_o[1] = recovered_319_s[1] ^ recovered_319_co[0];
  assign recovered_319_co[1] = (recovered_319_s[1] & recovered_319_co[0]) | (~recovered_319_s[1] & recovered_319_di[1]);
  assign recovered_319_o[2] = recovered_319_s[2] ^ recovered_319_co[1];
  assign recovered_319_co[2] = (recovered_319_s[2] & recovered_319_co[1]) | (~recovered_319_s[2] & recovered_319_di[2]);
  assign recovered_319_o[3] = recovered_319_s[3] ^ recovered_319_co[2];
  assign recovered_319_co[3] = (recovered_319_s[3] & recovered_319_co[2]) | (~recovered_319_s[3] & recovered_319_di[3]);
  assign {esc_add_ln208_63_reg_7437_reg_7__i_1_n_0_7b9fc63 ,esc_NLW_add_ln208_63_reg_7437_reg_7__i_1_CO_UNCONNECTED_ee902fc [2:0]} = recovered_319_co;
  assign esc_add_ln208_60_reg_7385_reg_10_d918a34 [7:4] = recovered_319_o;

  // Reconstructed LUT2: esc_add_ln208_66_reg_7489_3__i_2_9f5806d
  assign esc_add_ln208_66_reg_7489_3__i_2_n_0_9169d4c = ((DOADO[3]) ? (~(esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [3])) : (esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [3]));

  // Reconstructed LUT2: esc_add_ln208_66_reg_7489_3__i_3_606c1b8
  assign esc_add_ln208_66_reg_7489_3__i_3_n_0_13837fb = ((DOADO[2]) ? (~(esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [2])) : (esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [2]));

  // Reconstructed LUT2: esc_add_ln208_66_reg_7489_3__i_4_782163f
  assign esc_add_ln208_66_reg_7489_3__i_4_n_0_86b92b2 = ((DOADO[1]) ? (~(esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [1])) : (esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [1]));

  // Reconstructed LUT2: esc_add_ln208_66_reg_7489_3__i_5_9886689
  assign esc_add_ln208_66_reg_7489_3__i_5_n_0_c334c93 = ((DOADO[0]) ? (~(esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [0])) : (esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [0]));

  // Reconstructed LUT2: esc_add_ln208_66_reg_7489_7__i_2_5fbd173
  assign esc_add_ln208_66_reg_7489_7__i_2_n_0_8a449cf = ((DOADO[7]) ? (~(esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [7])) : (esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [7]));

  // Reconstructed LUT2: esc_add_ln208_66_reg_7489_7__i_3_7de335b
  assign esc_add_ln208_66_reg_7489_7__i_3_n_0_c836fb4 = ((DOADO[6]) ? (~(esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [6])) : (esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [6]));

  // Reconstructed LUT2: esc_add_ln208_66_reg_7489_7__i_4_a646e3f
  assign esc_add_ln208_66_reg_7489_7__i_4_n_0_403b0ee = ((DOADO[5]) ? (~(esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [5])) : (esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [5]));

  // Reconstructed LUT2: esc_add_ln208_66_reg_7489_7__i_5_56769e1
  assign esc_add_ln208_66_reg_7489_7__i_5_n_0_b1d1a85 = ((DOADO[4]) ? (~(esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [4])) : (esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [4]));

  // Reconstructed CARRY4: esc_add_ln208_66_reg_7489_reg_11__i_1_c9594f9
  wire [3:0] recovered_328_co, recovered_328_o, recovered_328_s, recovered_328_di;
  assign recovered_328_s = esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [11:8];
  assign recovered_328_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_328_ci = ((esc_add_ln208_66_reg_7489_reg_7__i_1_n_0_16dabef) !== 1'bz) && (esc_add_ln208_66_reg_7489_reg_7__i_1_n_0_16dabef);
  wire recovered_328_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_328_o[0] = recovered_328_s[0] ^ (recovered_328_ci || recovered_328_cy);
  assign recovered_328_co[0] = (recovered_328_s[0] & (recovered_328_ci || recovered_328_cy)) | (~recovered_328_s[0] & recovered_328_di[0]);
  assign recovered_328_o[1] = recovered_328_s[1] ^ recovered_328_co[0];
  assign recovered_328_co[1] = (recovered_328_s[1] & recovered_328_co[0]) | (~recovered_328_s[1] & recovered_328_di[1]);
  assign recovered_328_o[2] = recovered_328_s[2] ^ recovered_328_co[1];
  assign recovered_328_co[2] = (recovered_328_s[2] & recovered_328_co[1]) | (~recovered_328_s[2] & recovered_328_di[2]);
  assign recovered_328_o[3] = recovered_328_s[3] ^ recovered_328_co[2];
  assign recovered_328_co[3] = (recovered_328_s[3] & recovered_328_co[2]) | (~recovered_328_s[3] & recovered_328_di[3]);
  assign esc_add_ln208_63_reg_7437_reg_11_9252a9b [11:8] = recovered_328_o;

  // Reconstructed CARRY4: esc_add_ln208_66_reg_7489_reg_3__i_1_517323e
  wire [3:0] recovered_329_co, recovered_329_o, recovered_329_s, recovered_329_di;
  assign recovered_329_s = {esc_add_ln208_66_reg_7489_3__i_2_n_0_9169d4c ,esc_add_ln208_66_reg_7489_3__i_3_n_0_13837fb ,esc_add_ln208_66_reg_7489_3__i_4_n_0_86b92b2 ,esc_add_ln208_66_reg_7489_3__i_5_n_0_c334c93 };
  assign recovered_329_di = esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [3:0];
  wire recovered_329_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_329_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_329_o[0] = recovered_329_s[0] ^ (recovered_329_ci || recovered_329_cy);
  assign recovered_329_co[0] = (recovered_329_s[0] & (recovered_329_ci || recovered_329_cy)) | (~recovered_329_s[0] & recovered_329_di[0]);
  assign recovered_329_o[1] = recovered_329_s[1] ^ recovered_329_co[0];
  assign recovered_329_co[1] = (recovered_329_s[1] & recovered_329_co[0]) | (~recovered_329_s[1] & recovered_329_di[1]);
  assign recovered_329_o[2] = recovered_329_s[2] ^ recovered_329_co[1];
  assign recovered_329_co[2] = (recovered_329_s[2] & recovered_329_co[1]) | (~recovered_329_s[2] & recovered_329_di[2]);
  assign recovered_329_o[3] = recovered_329_s[3] ^ recovered_329_co[2];
  assign recovered_329_co[3] = (recovered_329_s[3] & recovered_329_co[2]) | (~recovered_329_s[3] & recovered_329_di[3]);
  assign {esc_add_ln208_66_reg_7489_reg_3__i_1_n_0_f728505 ,esc_NLW_add_ln208_66_reg_7489_reg_3__i_1_CO_UNCONNECTED_f27a538 [2:0]} = recovered_329_co;
  assign esc_add_ln208_63_reg_7437_reg_11_9252a9b [3:0] = recovered_329_o;

  // Reconstructed CARRY4: esc_add_ln208_66_reg_7489_reg_7__i_1_67fe69a
  wire [3:0] recovered_330_co, recovered_330_o, recovered_330_s, recovered_330_di;
  assign recovered_330_s = {esc_add_ln208_66_reg_7489_7__i_2_n_0_8a449cf ,esc_add_ln208_66_reg_7489_7__i_3_n_0_c836fb4 ,esc_add_ln208_66_reg_7489_7__i_4_n_0_403b0ee ,esc_add_ln208_66_reg_7489_7__i_5_n_0_b1d1a85 };
  assign recovered_330_di = esc_add_ln208_66_reg_7489_reg_11__0_33e5672 [7:4];
  wire recovered_330_ci = ((esc_add_ln208_66_reg_7489_reg_3__i_1_n_0_f728505) !== 1'bz) && (esc_add_ln208_66_reg_7489_reg_3__i_1_n_0_f728505);
  wire recovered_330_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_330_o[0] = recovered_330_s[0] ^ (recovered_330_ci || recovered_330_cy);
  assign recovered_330_co[0] = (recovered_330_s[0] & (recovered_330_ci || recovered_330_cy)) | (~recovered_330_s[0] & recovered_330_di[0]);
  assign recovered_330_o[1] = recovered_330_s[1] ^ recovered_330_co[0];
  assign recovered_330_co[1] = (recovered_330_s[1] & recovered_330_co[0]) | (~recovered_330_s[1] & recovered_330_di[1]);
  assign recovered_330_o[2] = recovered_330_s[2] ^ recovered_330_co[1];
  assign recovered_330_co[2] = (recovered_330_s[2] & recovered_330_co[1]) | (~recovered_330_s[2] & recovered_330_di[2]);
  assign recovered_330_o[3] = recovered_330_s[3] ^ recovered_330_co[2];
  assign recovered_330_co[3] = (recovered_330_s[3] & recovered_330_co[2]) | (~recovered_330_s[3] & recovered_330_di[3]);
  assign {esc_add_ln208_66_reg_7489_reg_7__i_1_n_0_16dabef ,esc_NLW_add_ln208_66_reg_7489_reg_7__i_1_CO_UNCONNECTED_4e9cf72 [2:0]} = recovered_330_co;
  assign esc_add_ln208_63_reg_7437_reg_11_9252a9b [7:4] = recovered_330_o;

  // Reconstructed LUT2: esc_add_ln208_69_reg_7541_3__i_2_6dedfb1
  assign esc_add_ln208_69_reg_7541_3__i_2_n_0_5fc8549 = ((DOADO[3]) ? (~(esc_add_ln208_69_reg_7541_reg_11__0_0318481 [3])) : (esc_add_ln208_69_reg_7541_reg_11__0_0318481 [3]));

  // Reconstructed LUT2: esc_add_ln208_69_reg_7541_3__i_3_9dc13c7
  assign esc_add_ln208_69_reg_7541_3__i_3_n_0_eae363d = ((DOADO[2]) ? (~(esc_add_ln208_69_reg_7541_reg_11__0_0318481 [2])) : (esc_add_ln208_69_reg_7541_reg_11__0_0318481 [2]));

  // Reconstructed LUT2: esc_add_ln208_69_reg_7541_3__i_4_29a115e
  assign esc_add_ln208_69_reg_7541_3__i_4_n_0_a99e682 = ((DOADO[1]) ? (~(esc_add_ln208_69_reg_7541_reg_11__0_0318481 [1])) : (esc_add_ln208_69_reg_7541_reg_11__0_0318481 [1]));

  // Reconstructed LUT2: esc_add_ln208_69_reg_7541_3__i_5_be0c1bb
  assign esc_add_ln208_69_reg_7541_3__i_5_n_0_ac555ed = ((DOADO[0]) ? (~(esc_add_ln208_69_reg_7541_reg_11__0_0318481 [0])) : (esc_add_ln208_69_reg_7541_reg_11__0_0318481 [0]));

  // Reconstructed LUT2: esc_add_ln208_69_reg_7541_7__i_2_82b07ac
  assign esc_add_ln208_69_reg_7541_7__i_2_n_0_f38663c = ((DOADO[7]) ? (~(esc_add_ln208_69_reg_7541_reg_11__0_0318481 [7])) : (esc_add_ln208_69_reg_7541_reg_11__0_0318481 [7]));

  // Reconstructed LUT2: esc_add_ln208_69_reg_7541_7__i_3_1fc3f09
  assign esc_add_ln208_69_reg_7541_7__i_3_n_0_a472f20 = ((DOADO[6]) ? (~(esc_add_ln208_69_reg_7541_reg_11__0_0318481 [6])) : (esc_add_ln208_69_reg_7541_reg_11__0_0318481 [6]));

  // Reconstructed LUT2: esc_add_ln208_69_reg_7541_7__i_4_935036f
  assign esc_add_ln208_69_reg_7541_7__i_4_n_0_712fefb = ((DOADO[5]) ? (~(esc_add_ln208_69_reg_7541_reg_11__0_0318481 [5])) : (esc_add_ln208_69_reg_7541_reg_11__0_0318481 [5]));

  // Reconstructed LUT2: esc_add_ln208_69_reg_7541_7__i_5_55d1150
  assign esc_add_ln208_69_reg_7541_7__i_5_n_0_c583a91 = ((DOADO[4]) ? (~(esc_add_ln208_69_reg_7541_reg_11__0_0318481 [4])) : (esc_add_ln208_69_reg_7541_reg_11__0_0318481 [4]));

  // Reconstructed CARRY4: esc_add_ln208_69_reg_7541_reg_11__i_1_a8613c7
  wire [3:0] recovered_339_co, recovered_339_o, recovered_339_s, recovered_339_di;
  assign recovered_339_s = esc_add_ln208_69_reg_7541_reg_11__0_0318481 [11:8];
  assign recovered_339_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_339_ci = ((esc_add_ln208_69_reg_7541_reg_7__i_1_n_0_14a480a) !== 1'bz) && (esc_add_ln208_69_reg_7541_reg_7__i_1_n_0_14a480a);
  wire recovered_339_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_339_o[0] = recovered_339_s[0] ^ (recovered_339_ci || recovered_339_cy);
  assign recovered_339_co[0] = (recovered_339_s[0] & (recovered_339_ci || recovered_339_cy)) | (~recovered_339_s[0] & recovered_339_di[0]);
  assign recovered_339_o[1] = recovered_339_s[1] ^ recovered_339_co[0];
  assign recovered_339_co[1] = (recovered_339_s[1] & recovered_339_co[0]) | (~recovered_339_s[1] & recovered_339_di[1]);
  assign recovered_339_o[2] = recovered_339_s[2] ^ recovered_339_co[1];
  assign recovered_339_co[2] = (recovered_339_s[2] & recovered_339_co[1]) | (~recovered_339_s[2] & recovered_339_di[2]);
  assign recovered_339_o[3] = recovered_339_s[3] ^ recovered_339_co[2];
  assign recovered_339_co[3] = (recovered_339_s[3] & recovered_339_co[2]) | (~recovered_339_s[3] & recovered_339_di[3]);
  assign esc_add_ln208_66_reg_7489_reg_11_f470215 [11:8] = recovered_339_o;

  // Reconstructed CARRY4: esc_add_ln208_69_reg_7541_reg_3__i_1_b26fe2a
  wire [3:0] recovered_340_co, recovered_340_o, recovered_340_s, recovered_340_di;
  assign recovered_340_s = {esc_add_ln208_69_reg_7541_3__i_2_n_0_5fc8549 ,esc_add_ln208_69_reg_7541_3__i_3_n_0_eae363d ,esc_add_ln208_69_reg_7541_3__i_4_n_0_a99e682 ,esc_add_ln208_69_reg_7541_3__i_5_n_0_ac555ed };
  assign recovered_340_di = esc_add_ln208_69_reg_7541_reg_11__0_0318481 [3:0];
  wire recovered_340_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_340_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_340_o[0] = recovered_340_s[0] ^ (recovered_340_ci || recovered_340_cy);
  assign recovered_340_co[0] = (recovered_340_s[0] & (recovered_340_ci || recovered_340_cy)) | (~recovered_340_s[0] & recovered_340_di[0]);
  assign recovered_340_o[1] = recovered_340_s[1] ^ recovered_340_co[0];
  assign recovered_340_co[1] = (recovered_340_s[1] & recovered_340_co[0]) | (~recovered_340_s[1] & recovered_340_di[1]);
  assign recovered_340_o[2] = recovered_340_s[2] ^ recovered_340_co[1];
  assign recovered_340_co[2] = (recovered_340_s[2] & recovered_340_co[1]) | (~recovered_340_s[2] & recovered_340_di[2]);
  assign recovered_340_o[3] = recovered_340_s[3] ^ recovered_340_co[2];
  assign recovered_340_co[3] = (recovered_340_s[3] & recovered_340_co[2]) | (~recovered_340_s[3] & recovered_340_di[3]);
  assign {esc_add_ln208_69_reg_7541_reg_3__i_1_n_0_91ac2a9 ,esc_NLW_add_ln208_69_reg_7541_reg_3__i_1_CO_UNCONNECTED_4367aba [2:0]} = recovered_340_co;
  assign esc_add_ln208_66_reg_7489_reg_11_f470215 [3:0] = recovered_340_o;

  // Reconstructed CARRY4: esc_add_ln208_69_reg_7541_reg_7__i_1_111bf5b
  wire [3:0] recovered_341_co, recovered_341_o, recovered_341_s, recovered_341_di;
  assign recovered_341_s = {esc_add_ln208_69_reg_7541_7__i_2_n_0_f38663c ,esc_add_ln208_69_reg_7541_7__i_3_n_0_a472f20 ,esc_add_ln208_69_reg_7541_7__i_4_n_0_712fefb ,esc_add_ln208_69_reg_7541_7__i_5_n_0_c583a91 };
  assign recovered_341_di = esc_add_ln208_69_reg_7541_reg_11__0_0318481 [7:4];
  wire recovered_341_ci = ((esc_add_ln208_69_reg_7541_reg_3__i_1_n_0_91ac2a9) !== 1'bz) && (esc_add_ln208_69_reg_7541_reg_3__i_1_n_0_91ac2a9);
  wire recovered_341_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_341_o[0] = recovered_341_s[0] ^ (recovered_341_ci || recovered_341_cy);
  assign recovered_341_co[0] = (recovered_341_s[0] & (recovered_341_ci || recovered_341_cy)) | (~recovered_341_s[0] & recovered_341_di[0]);
  assign recovered_341_o[1] = recovered_341_s[1] ^ recovered_341_co[0];
  assign recovered_341_co[1] = (recovered_341_s[1] & recovered_341_co[0]) | (~recovered_341_s[1] & recovered_341_di[1]);
  assign recovered_341_o[2] = recovered_341_s[2] ^ recovered_341_co[1];
  assign recovered_341_co[2] = (recovered_341_s[2] & recovered_341_co[1]) | (~recovered_341_s[2] & recovered_341_di[2]);
  assign recovered_341_o[3] = recovered_341_s[3] ^ recovered_341_co[2];
  assign recovered_341_co[3] = (recovered_341_s[3] & recovered_341_co[2]) | (~recovered_341_s[3] & recovered_341_di[3]);
  assign {esc_add_ln208_69_reg_7541_reg_7__i_1_n_0_14a480a ,esc_NLW_add_ln208_69_reg_7541_reg_7__i_1_CO_UNCONNECTED_c4e46d9 [2:0]} = recovered_341_co;
  assign esc_add_ln208_66_reg_7489_reg_11_f470215 [7:4] = recovered_341_o;

  // Reconstructed LUT2: esc_add_ln208_72_reg_7593_3__i_2_c5f7af0
  assign esc_add_ln208_72_reg_7593_3__i_2_n_0_9346212 = ((DOADO[3]) ? (~(esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [3])) : (esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [3]));

  // Reconstructed LUT2: esc_add_ln208_72_reg_7593_3__i_3_59529b4
  assign esc_add_ln208_72_reg_7593_3__i_3_n_0_a7c035a = ((DOADO[2]) ? (~(esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [2])) : (esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [2]));

  // Reconstructed LUT2: esc_add_ln208_72_reg_7593_3__i_4_67fd14b
  assign esc_add_ln208_72_reg_7593_3__i_4_n_0_4c45321 = ((DOADO[1]) ? (~(esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [1])) : (esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [1]));

  // Reconstructed LUT2: esc_add_ln208_72_reg_7593_3__i_5_a0efb54
  assign esc_add_ln208_72_reg_7593_3__i_5_n_0_68ca72d = ((DOADO[0]) ? (~(esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [0])) : (esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [0]));

  // Reconstructed LUT2: esc_add_ln208_72_reg_7593_7__i_2_e3fe7df
  assign esc_add_ln208_72_reg_7593_7__i_2_n_0_d513f76 = ((DOADO[7]) ? (~(esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [7])) : (esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [7]));

  // Reconstructed LUT2: esc_add_ln208_72_reg_7593_7__i_3_da23d07
  assign esc_add_ln208_72_reg_7593_7__i_3_n_0_4769bbd = ((DOADO[6]) ? (~(esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [6])) : (esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [6]));

  // Reconstructed LUT2: esc_add_ln208_72_reg_7593_7__i_4_9e7397a
  assign esc_add_ln208_72_reg_7593_7__i_4_n_0_cbde428 = ((DOADO[5]) ? (~(esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [5])) : (esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [5]));

  // Reconstructed LUT2: esc_add_ln208_72_reg_7593_7__i_5_6da0b66
  assign esc_add_ln208_72_reg_7593_7__i_5_n_0_0bc2a1e = ((DOADO[4]) ? (~(esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [4])) : (esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [4]));

  // Reconstructed CARRY4: esc_add_ln208_72_reg_7593_reg_11__i_1_c1bdb8c
  wire [3:0] recovered_350_co, recovered_350_o, recovered_350_s, recovered_350_di;
  assign recovered_350_s = esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [11:8];
  assign recovered_350_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_350_ci = ((esc_add_ln208_72_reg_7593_reg_7__i_1_n_0_8948c54) !== 1'bz) && (esc_add_ln208_72_reg_7593_reg_7__i_1_n_0_8948c54);
  wire recovered_350_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_350_o[0] = recovered_350_s[0] ^ (recovered_350_ci || recovered_350_cy);
  assign recovered_350_co[0] = (recovered_350_s[0] & (recovered_350_ci || recovered_350_cy)) | (~recovered_350_s[0] & recovered_350_di[0]);
  assign recovered_350_o[1] = recovered_350_s[1] ^ recovered_350_co[0];
  assign recovered_350_co[1] = (recovered_350_s[1] & recovered_350_co[0]) | (~recovered_350_s[1] & recovered_350_di[1]);
  assign recovered_350_o[2] = recovered_350_s[2] ^ recovered_350_co[1];
  assign recovered_350_co[2] = (recovered_350_s[2] & recovered_350_co[1]) | (~recovered_350_s[2] & recovered_350_di[2]);
  assign recovered_350_o[3] = recovered_350_s[3] ^ recovered_350_co[2];
  assign recovered_350_co[3] = (recovered_350_s[3] & recovered_350_co[2]) | (~recovered_350_s[3] & recovered_350_di[3]);
  assign esc_add_ln208_69_reg_7541_reg_11_1ab4dac [11:8] = recovered_350_o;

  // Reconstructed CARRY4: esc_add_ln208_72_reg_7593_reg_3__i_1_db78136
  wire [3:0] recovered_351_co, recovered_351_o, recovered_351_s, recovered_351_di;
  assign recovered_351_s = {esc_add_ln208_72_reg_7593_3__i_2_n_0_9346212 ,esc_add_ln208_72_reg_7593_3__i_3_n_0_a7c035a ,esc_add_ln208_72_reg_7593_3__i_4_n_0_4c45321 ,esc_add_ln208_72_reg_7593_3__i_5_n_0_68ca72d };
  assign recovered_351_di = esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [3:0];
  wire recovered_351_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_351_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_351_o[0] = recovered_351_s[0] ^ (recovered_351_ci || recovered_351_cy);
  assign recovered_351_co[0] = (recovered_351_s[0] & (recovered_351_ci || recovered_351_cy)) | (~recovered_351_s[0] & recovered_351_di[0]);
  assign recovered_351_o[1] = recovered_351_s[1] ^ recovered_351_co[0];
  assign recovered_351_co[1] = (recovered_351_s[1] & recovered_351_co[0]) | (~recovered_351_s[1] & recovered_351_di[1]);
  assign recovered_351_o[2] = recovered_351_s[2] ^ recovered_351_co[1];
  assign recovered_351_co[2] = (recovered_351_s[2] & recovered_351_co[1]) | (~recovered_351_s[2] & recovered_351_di[2]);
  assign recovered_351_o[3] = recovered_351_s[3] ^ recovered_351_co[2];
  assign recovered_351_co[3] = (recovered_351_s[3] & recovered_351_co[2]) | (~recovered_351_s[3] & recovered_351_di[3]);
  assign {esc_add_ln208_72_reg_7593_reg_3__i_1_n_0_3261274 ,esc_NLW_add_ln208_72_reg_7593_reg_3__i_1_CO_UNCONNECTED_eba40b0 [2:0]} = recovered_351_co;
  assign esc_add_ln208_69_reg_7541_reg_11_1ab4dac [3:0] = recovered_351_o;

  // Reconstructed CARRY4: esc_add_ln208_72_reg_7593_reg_7__i_1_05f814a
  wire [3:0] recovered_352_co, recovered_352_o, recovered_352_s, recovered_352_di;
  assign recovered_352_s = {esc_add_ln208_72_reg_7593_7__i_2_n_0_d513f76 ,esc_add_ln208_72_reg_7593_7__i_3_n_0_4769bbd ,esc_add_ln208_72_reg_7593_7__i_4_n_0_cbde428 ,esc_add_ln208_72_reg_7593_7__i_5_n_0_0bc2a1e };
  assign recovered_352_di = esc_add_ln208_72_reg_7593_reg_11__0_87f0eda [7:4];
  wire recovered_352_ci = ((esc_add_ln208_72_reg_7593_reg_3__i_1_n_0_3261274) !== 1'bz) && (esc_add_ln208_72_reg_7593_reg_3__i_1_n_0_3261274);
  wire recovered_352_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_352_o[0] = recovered_352_s[0] ^ (recovered_352_ci || recovered_352_cy);
  assign recovered_352_co[0] = (recovered_352_s[0] & (recovered_352_ci || recovered_352_cy)) | (~recovered_352_s[0] & recovered_352_di[0]);
  assign recovered_352_o[1] = recovered_352_s[1] ^ recovered_352_co[0];
  assign recovered_352_co[1] = (recovered_352_s[1] & recovered_352_co[0]) | (~recovered_352_s[1] & recovered_352_di[1]);
  assign recovered_352_o[2] = recovered_352_s[2] ^ recovered_352_co[1];
  assign recovered_352_co[2] = (recovered_352_s[2] & recovered_352_co[1]) | (~recovered_352_s[2] & recovered_352_di[2]);
  assign recovered_352_o[3] = recovered_352_s[3] ^ recovered_352_co[2];
  assign recovered_352_co[3] = (recovered_352_s[3] & recovered_352_co[2]) | (~recovered_352_s[3] & recovered_352_di[3]);
  assign {esc_add_ln208_72_reg_7593_reg_7__i_1_n_0_8948c54 ,esc_NLW_add_ln208_72_reg_7593_reg_7__i_1_CO_UNCONNECTED_1b6b98d [2:0]} = recovered_352_co;
  assign esc_add_ln208_69_reg_7541_reg_11_1ab4dac [7:4] = recovered_352_o;

  // Reconstructed LUT2: esc_add_ln208_75_reg_7655_3__i_2_5770b03
  assign esc_add_ln208_75_reg_7655_3__i_2_n_0_dc909d2 = ((DOADO[3]) ? (~(esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [3])) : (esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [3]));

  // Reconstructed LUT2: esc_add_ln208_75_reg_7655_3__i_3_0ce4928
  assign esc_add_ln208_75_reg_7655_3__i_3_n_0_7609aba = ((DOADO[2]) ? (~(esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [2])) : (esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [2]));

  // Reconstructed LUT2: esc_add_ln208_75_reg_7655_3__i_4_70508e4
  assign esc_add_ln208_75_reg_7655_3__i_4_n_0_5816a07 = ((DOADO[1]) ? (~(esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [1])) : (esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [1]));

  // Reconstructed LUT2: esc_add_ln208_75_reg_7655_3__i_5_0af22a9
  assign esc_add_ln208_75_reg_7655_3__i_5_n_0_7ae65fa = ((DOADO[0]) ? (~(esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [0])) : (esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [0]));

  // Reconstructed LUT2: esc_add_ln208_75_reg_7655_7__i_2_ce11329
  assign esc_add_ln208_75_reg_7655_7__i_2_n_0_6389c0f = ((DOADO[7]) ? (~(esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [7])) : (esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [7]));

  // Reconstructed LUT2: esc_add_ln208_75_reg_7655_7__i_3_7c6c8ba
  assign esc_add_ln208_75_reg_7655_7__i_3_n_0_4d6af57 = ((DOADO[6]) ? (~(esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [6])) : (esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [6]));

  // Reconstructed LUT2: esc_add_ln208_75_reg_7655_7__i_4_56273cb
  assign esc_add_ln208_75_reg_7655_7__i_4_n_0_296957f = ((DOADO[5]) ? (~(esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [5])) : (esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [5]));

  // Reconstructed LUT2: esc_add_ln208_75_reg_7655_7__i_5_d3e8ea5
  assign esc_add_ln208_75_reg_7655_7__i_5_n_0_af2cd68 = ((DOADO[4]) ? (~(esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [4])) : (esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [4]));

  // Reconstructed CARRY4: esc_add_ln208_75_reg_7655_reg_11__i_1_af9b037
  wire [3:0] recovered_361_co, recovered_361_o, recovered_361_s, recovered_361_di;
  assign recovered_361_s = esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [11:8];
  assign recovered_361_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_361_ci = ((esc_add_ln208_75_reg_7655_reg_7__i_1_n_0_0a0c4c9) !== 1'bz) && (esc_add_ln208_75_reg_7655_reg_7__i_1_n_0_0a0c4c9);
  wire recovered_361_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_361_o[0] = recovered_361_s[0] ^ (recovered_361_ci || recovered_361_cy);
  assign recovered_361_co[0] = (recovered_361_s[0] & (recovered_361_ci || recovered_361_cy)) | (~recovered_361_s[0] & recovered_361_di[0]);
  assign recovered_361_o[1] = recovered_361_s[1] ^ recovered_361_co[0];
  assign recovered_361_co[1] = (recovered_361_s[1] & recovered_361_co[0]) | (~recovered_361_s[1] & recovered_361_di[1]);
  assign recovered_361_o[2] = recovered_361_s[2] ^ recovered_361_co[1];
  assign recovered_361_co[2] = (recovered_361_s[2] & recovered_361_co[1]) | (~recovered_361_s[2] & recovered_361_di[2]);
  assign recovered_361_o[3] = recovered_361_s[3] ^ recovered_361_co[2];
  assign recovered_361_co[3] = (recovered_361_s[3] & recovered_361_co[2]) | (~recovered_361_s[3] & recovered_361_di[3]);
  assign esc_add_ln208_72_reg_7593_reg_11_6fb0a9c [11:8] = recovered_361_o;

  // Reconstructed CARRY4: esc_add_ln208_75_reg_7655_reg_3__i_1_ab988fe
  wire [3:0] recovered_362_co, recovered_362_o, recovered_362_s, recovered_362_di;
  assign recovered_362_s = {esc_add_ln208_75_reg_7655_3__i_2_n_0_dc909d2 ,esc_add_ln208_75_reg_7655_3__i_3_n_0_7609aba ,esc_add_ln208_75_reg_7655_3__i_4_n_0_5816a07 ,esc_add_ln208_75_reg_7655_3__i_5_n_0_7ae65fa };
  assign recovered_362_di = esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [3:0];
  wire recovered_362_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_362_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_362_o[0] = recovered_362_s[0] ^ (recovered_362_ci || recovered_362_cy);
  assign recovered_362_co[0] = (recovered_362_s[0] & (recovered_362_ci || recovered_362_cy)) | (~recovered_362_s[0] & recovered_362_di[0]);
  assign recovered_362_o[1] = recovered_362_s[1] ^ recovered_362_co[0];
  assign recovered_362_co[1] = (recovered_362_s[1] & recovered_362_co[0]) | (~recovered_362_s[1] & recovered_362_di[1]);
  assign recovered_362_o[2] = recovered_362_s[2] ^ recovered_362_co[1];
  assign recovered_362_co[2] = (recovered_362_s[2] & recovered_362_co[1]) | (~recovered_362_s[2] & recovered_362_di[2]);
  assign recovered_362_o[3] = recovered_362_s[3] ^ recovered_362_co[2];
  assign recovered_362_co[3] = (recovered_362_s[3] & recovered_362_co[2]) | (~recovered_362_s[3] & recovered_362_di[3]);
  assign {esc_add_ln208_75_reg_7655_reg_3__i_1_n_0_2517216 ,esc_NLW_add_ln208_75_reg_7655_reg_3__i_1_CO_UNCONNECTED_45618a3 [2:0]} = recovered_362_co;
  assign esc_add_ln208_72_reg_7593_reg_11_6fb0a9c [3:0] = recovered_362_o;

  // Reconstructed CARRY4: esc_add_ln208_75_reg_7655_reg_7__i_1_d1e5a63
  wire [3:0] recovered_363_co, recovered_363_o, recovered_363_s, recovered_363_di;
  assign recovered_363_s = {esc_add_ln208_75_reg_7655_7__i_2_n_0_6389c0f ,esc_add_ln208_75_reg_7655_7__i_3_n_0_4d6af57 ,esc_add_ln208_75_reg_7655_7__i_4_n_0_296957f ,esc_add_ln208_75_reg_7655_7__i_5_n_0_af2cd68 };
  assign recovered_363_di = esc_add_ln208_75_reg_7655_reg_11__0_7ad6c21 [7:4];
  wire recovered_363_ci = ((esc_add_ln208_75_reg_7655_reg_3__i_1_n_0_2517216) !== 1'bz) && (esc_add_ln208_75_reg_7655_reg_3__i_1_n_0_2517216);
  wire recovered_363_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_363_o[0] = recovered_363_s[0] ^ (recovered_363_ci || recovered_363_cy);
  assign recovered_363_co[0] = (recovered_363_s[0] & (recovered_363_ci || recovered_363_cy)) | (~recovered_363_s[0] & recovered_363_di[0]);
  assign recovered_363_o[1] = recovered_363_s[1] ^ recovered_363_co[0];
  assign recovered_363_co[1] = (recovered_363_s[1] & recovered_363_co[0]) | (~recovered_363_s[1] & recovered_363_di[1]);
  assign recovered_363_o[2] = recovered_363_s[2] ^ recovered_363_co[1];
  assign recovered_363_co[2] = (recovered_363_s[2] & recovered_363_co[1]) | (~recovered_363_s[2] & recovered_363_di[2]);
  assign recovered_363_o[3] = recovered_363_s[3] ^ recovered_363_co[2];
  assign recovered_363_co[3] = (recovered_363_s[3] & recovered_363_co[2]) | (~recovered_363_s[3] & recovered_363_di[3]);
  assign {esc_add_ln208_75_reg_7655_reg_7__i_1_n_0_0a0c4c9 ,esc_NLW_add_ln208_75_reg_7655_reg_7__i_1_CO_UNCONNECTED_f46de21 [2:0]} = recovered_363_co;
  assign esc_add_ln208_72_reg_7593_reg_11_6fb0a9c [7:4] = recovered_363_o;

  // Reconstructed LUT2: esc_add_ln208_78_reg_7717_3__i_2_a82ca8c
  assign esc_add_ln208_78_reg_7717_3__i_2_n_0_5a5a281 = ((DOADO[3]) ? (~(esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [3])) : (esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [3]));

  // Reconstructed LUT2: esc_add_ln208_78_reg_7717_3__i_3_1fec5db
  assign esc_add_ln208_78_reg_7717_3__i_3_n_0_e233b25 = ((DOADO[2]) ? (~(esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [2])) : (esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [2]));

  // Reconstructed LUT2: esc_add_ln208_78_reg_7717_3__i_4_32030a0
  assign esc_add_ln208_78_reg_7717_3__i_4_n_0_aede86f = ((DOADO[1]) ? (~(esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [1])) : (esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [1]));

  // Reconstructed LUT2: esc_add_ln208_78_reg_7717_3__i_5_9c377b5
  assign esc_add_ln208_78_reg_7717_3__i_5_n_0_08c3dd1 = ((DOADO[0]) ? (~(esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [0])) : (esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [0]));

  // Reconstructed LUT2: esc_add_ln208_78_reg_7717_7__i_2_03faf28
  assign esc_add_ln208_78_reg_7717_7__i_2_n_0_c1a4753 = ((DOADO[7]) ? (~(esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [7])) : (esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [7]));

  // Reconstructed LUT2: esc_add_ln208_78_reg_7717_7__i_3_525943f
  assign esc_add_ln208_78_reg_7717_7__i_3_n_0_5c0edec = ((DOADO[6]) ? (~(esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [6])) : (esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [6]));

  // Reconstructed LUT2: esc_add_ln208_78_reg_7717_7__i_4_0d5beb9
  assign esc_add_ln208_78_reg_7717_7__i_4_n_0_d02834e = ((DOADO[5]) ? (~(esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [5])) : (esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [5]));

  // Reconstructed LUT2: esc_add_ln208_78_reg_7717_7__i_5_2bccece
  assign esc_add_ln208_78_reg_7717_7__i_5_n_0_5766059 = ((DOADO[4]) ? (~(esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [4])) : (esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [4]));

  // Reconstructed CARRY4: esc_add_ln208_78_reg_7717_reg_11__i_1_1e922b3
  wire [3:0] recovered_372_co, recovered_372_o, recovered_372_s, recovered_372_di;
  assign recovered_372_s = esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [11:8];
  assign recovered_372_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_372_ci = ((esc_add_ln208_78_reg_7717_reg_7__i_1_n_0_27fd15c) !== 1'bz) && (esc_add_ln208_78_reg_7717_reg_7__i_1_n_0_27fd15c);
  wire recovered_372_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_372_o[0] = recovered_372_s[0] ^ (recovered_372_ci || recovered_372_cy);
  assign recovered_372_co[0] = (recovered_372_s[0] & (recovered_372_ci || recovered_372_cy)) | (~recovered_372_s[0] & recovered_372_di[0]);
  assign recovered_372_o[1] = recovered_372_s[1] ^ recovered_372_co[0];
  assign recovered_372_co[1] = (recovered_372_s[1] & recovered_372_co[0]) | (~recovered_372_s[1] & recovered_372_di[1]);
  assign recovered_372_o[2] = recovered_372_s[2] ^ recovered_372_co[1];
  assign recovered_372_co[2] = (recovered_372_s[2] & recovered_372_co[1]) | (~recovered_372_s[2] & recovered_372_di[2]);
  assign recovered_372_o[3] = recovered_372_s[3] ^ recovered_372_co[2];
  assign recovered_372_co[3] = (recovered_372_s[3] & recovered_372_co[2]) | (~recovered_372_s[3] & recovered_372_di[3]);
  assign esc_add_ln208_75_reg_7655_reg_11_3cc2dbe [11:8] = recovered_372_o;

  // Reconstructed CARRY4: esc_add_ln208_78_reg_7717_reg_3__i_1_2276b69
  wire [3:0] recovered_373_co, recovered_373_o, recovered_373_s, recovered_373_di;
  assign recovered_373_s = {esc_add_ln208_78_reg_7717_3__i_2_n_0_5a5a281 ,esc_add_ln208_78_reg_7717_3__i_3_n_0_e233b25 ,esc_add_ln208_78_reg_7717_3__i_4_n_0_aede86f ,esc_add_ln208_78_reg_7717_3__i_5_n_0_08c3dd1 };
  assign recovered_373_di = esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [3:0];
  wire recovered_373_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_373_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_373_o[0] = recovered_373_s[0] ^ (recovered_373_ci || recovered_373_cy);
  assign recovered_373_co[0] = (recovered_373_s[0] & (recovered_373_ci || recovered_373_cy)) | (~recovered_373_s[0] & recovered_373_di[0]);
  assign recovered_373_o[1] = recovered_373_s[1] ^ recovered_373_co[0];
  assign recovered_373_co[1] = (recovered_373_s[1] & recovered_373_co[0]) | (~recovered_373_s[1] & recovered_373_di[1]);
  assign recovered_373_o[2] = recovered_373_s[2] ^ recovered_373_co[1];
  assign recovered_373_co[2] = (recovered_373_s[2] & recovered_373_co[1]) | (~recovered_373_s[2] & recovered_373_di[2]);
  assign recovered_373_o[3] = recovered_373_s[3] ^ recovered_373_co[2];
  assign recovered_373_co[3] = (recovered_373_s[3] & recovered_373_co[2]) | (~recovered_373_s[3] & recovered_373_di[3]);
  assign {esc_add_ln208_78_reg_7717_reg_3__i_1_n_0_f330ec6 ,esc_NLW_add_ln208_78_reg_7717_reg_3__i_1_CO_UNCONNECTED_a41eeb1 [2:0]} = recovered_373_co;
  assign esc_add_ln208_75_reg_7655_reg_11_3cc2dbe [3:0] = recovered_373_o;

  // Reconstructed CARRY4: esc_add_ln208_78_reg_7717_reg_7__i_1_8cbcfc4
  wire [3:0] recovered_374_co, recovered_374_o, recovered_374_s, recovered_374_di;
  assign recovered_374_s = {esc_add_ln208_78_reg_7717_7__i_2_n_0_c1a4753 ,esc_add_ln208_78_reg_7717_7__i_3_n_0_5c0edec ,esc_add_ln208_78_reg_7717_7__i_4_n_0_d02834e ,esc_add_ln208_78_reg_7717_7__i_5_n_0_5766059 };
  assign recovered_374_di = esc_add_ln208_78_reg_7717_reg_11__0_7aab1d3 [7:4];
  wire recovered_374_ci = ((esc_add_ln208_78_reg_7717_reg_3__i_1_n_0_f330ec6) !== 1'bz) && (esc_add_ln208_78_reg_7717_reg_3__i_1_n_0_f330ec6);
  wire recovered_374_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_374_o[0] = recovered_374_s[0] ^ (recovered_374_ci || recovered_374_cy);
  assign recovered_374_co[0] = (recovered_374_s[0] & (recovered_374_ci || recovered_374_cy)) | (~recovered_374_s[0] & recovered_374_di[0]);
  assign recovered_374_o[1] = recovered_374_s[1] ^ recovered_374_co[0];
  assign recovered_374_co[1] = (recovered_374_s[1] & recovered_374_co[0]) | (~recovered_374_s[1] & recovered_374_di[1]);
  assign recovered_374_o[2] = recovered_374_s[2] ^ recovered_374_co[1];
  assign recovered_374_co[2] = (recovered_374_s[2] & recovered_374_co[1]) | (~recovered_374_s[2] & recovered_374_di[2]);
  assign recovered_374_o[3] = recovered_374_s[3] ^ recovered_374_co[2];
  assign recovered_374_co[3] = (recovered_374_s[3] & recovered_374_co[2]) | (~recovered_374_s[3] & recovered_374_di[3]);
  assign {esc_add_ln208_78_reg_7717_reg_7__i_1_n_0_27fd15c ,esc_NLW_add_ln208_78_reg_7717_reg_7__i_1_CO_UNCONNECTED_1357d56 [2:0]} = recovered_374_co;
  assign esc_add_ln208_75_reg_7655_reg_11_3cc2dbe [7:4] = recovered_374_o;

  // Reconstructed LUT2: esc_add_ln208_81_reg_7779_3__i_2_2027ce8
  assign esc_add_ln208_81_reg_7779_3__i_2_n_0_58ba4b0 = ((DOADO[3]) ? (~(esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [3])) : (esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [3]));

  // Reconstructed LUT2: esc_add_ln208_81_reg_7779_3__i_3_60467ed
  assign esc_add_ln208_81_reg_7779_3__i_3_n_0_4cf4db4 = ((DOADO[2]) ? (~(esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [2])) : (esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [2]));

  // Reconstructed LUT2: esc_add_ln208_81_reg_7779_3__i_4_d7125e7
  assign esc_add_ln208_81_reg_7779_3__i_4_n_0_e0cfd1a = ((DOADO[1]) ? (~(esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [1])) : (esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [1]));

  // Reconstructed LUT2: esc_add_ln208_81_reg_7779_3__i_5_730e828
  assign esc_add_ln208_81_reg_7779_3__i_5_n_0_8983cde = ((DOADO[0]) ? (~(esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [0])) : (esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [0]));

  // Reconstructed LUT2: esc_add_ln208_81_reg_7779_7__i_2_8637e5c
  assign esc_add_ln208_81_reg_7779_7__i_2_n_0_212f4b2 = ((DOADO[7]) ? (~(esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [7])) : (esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [7]));

  // Reconstructed LUT2: esc_add_ln208_81_reg_7779_7__i_3_65cb374
  assign esc_add_ln208_81_reg_7779_7__i_3_n_0_c6795e1 = ((DOADO[6]) ? (~(esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [6])) : (esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [6]));

  // Reconstructed LUT2: esc_add_ln208_81_reg_7779_7__i_4_b70087c
  assign esc_add_ln208_81_reg_7779_7__i_4_n_0_3729c83 = ((DOADO[5]) ? (~(esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [5])) : (esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [5]));

  // Reconstructed LUT2: esc_add_ln208_81_reg_7779_7__i_5_9f344d8
  assign esc_add_ln208_81_reg_7779_7__i_5_n_0_97a227a = ((DOADO[4]) ? (~(esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [4])) : (esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [4]));

  // Reconstructed CARRY4: esc_add_ln208_81_reg_7779_reg_11__i_1_b3e3675
  wire [3:0] recovered_383_co, recovered_383_o, recovered_383_s, recovered_383_di;
  assign recovered_383_s = esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [11:8];
  assign recovered_383_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_383_ci = ((esc_add_ln208_81_reg_7779_reg_7__i_1_n_0_4d12364) !== 1'bz) && (esc_add_ln208_81_reg_7779_reg_7__i_1_n_0_4d12364);
  wire recovered_383_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_383_o[0] = recovered_383_s[0] ^ (recovered_383_ci || recovered_383_cy);
  assign recovered_383_co[0] = (recovered_383_s[0] & (recovered_383_ci || recovered_383_cy)) | (~recovered_383_s[0] & recovered_383_di[0]);
  assign recovered_383_o[1] = recovered_383_s[1] ^ recovered_383_co[0];
  assign recovered_383_co[1] = (recovered_383_s[1] & recovered_383_co[0]) | (~recovered_383_s[1] & recovered_383_di[1]);
  assign recovered_383_o[2] = recovered_383_s[2] ^ recovered_383_co[1];
  assign recovered_383_co[2] = (recovered_383_s[2] & recovered_383_co[1]) | (~recovered_383_s[2] & recovered_383_di[2]);
  assign recovered_383_o[3] = recovered_383_s[3] ^ recovered_383_co[2];
  assign recovered_383_co[3] = (recovered_383_s[3] & recovered_383_co[2]) | (~recovered_383_s[3] & recovered_383_di[3]);
  assign esc_add_ln208_78_reg_7717_reg_11_a25b5c3 [11:8] = recovered_383_o;

  // Reconstructed CARRY4: esc_add_ln208_81_reg_7779_reg_3__i_1_cdffae1
  wire [3:0] recovered_384_co, recovered_384_o, recovered_384_s, recovered_384_di;
  assign recovered_384_s = {esc_add_ln208_81_reg_7779_3__i_2_n_0_58ba4b0 ,esc_add_ln208_81_reg_7779_3__i_3_n_0_4cf4db4 ,esc_add_ln208_81_reg_7779_3__i_4_n_0_e0cfd1a ,esc_add_ln208_81_reg_7779_3__i_5_n_0_8983cde };
  assign recovered_384_di = esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [3:0];
  wire recovered_384_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_384_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_384_o[0] = recovered_384_s[0] ^ (recovered_384_ci || recovered_384_cy);
  assign recovered_384_co[0] = (recovered_384_s[0] & (recovered_384_ci || recovered_384_cy)) | (~recovered_384_s[0] & recovered_384_di[0]);
  assign recovered_384_o[1] = recovered_384_s[1] ^ recovered_384_co[0];
  assign recovered_384_co[1] = (recovered_384_s[1] & recovered_384_co[0]) | (~recovered_384_s[1] & recovered_384_di[1]);
  assign recovered_384_o[2] = recovered_384_s[2] ^ recovered_384_co[1];
  assign recovered_384_co[2] = (recovered_384_s[2] & recovered_384_co[1]) | (~recovered_384_s[2] & recovered_384_di[2]);
  assign recovered_384_o[3] = recovered_384_s[3] ^ recovered_384_co[2];
  assign recovered_384_co[3] = (recovered_384_s[3] & recovered_384_co[2]) | (~recovered_384_s[3] & recovered_384_di[3]);
  assign {esc_add_ln208_81_reg_7779_reg_3__i_1_n_0_750ee82 ,esc_NLW_add_ln208_81_reg_7779_reg_3__i_1_CO_UNCONNECTED_a553593 [2:0]} = recovered_384_co;
  assign esc_add_ln208_78_reg_7717_reg_11_a25b5c3 [3:0] = recovered_384_o;

  // Reconstructed CARRY4: esc_add_ln208_81_reg_7779_reg_7__i_1_46f1fa3
  wire [3:0] recovered_385_co, recovered_385_o, recovered_385_s, recovered_385_di;
  assign recovered_385_s = {esc_add_ln208_81_reg_7779_7__i_2_n_0_212f4b2 ,esc_add_ln208_81_reg_7779_7__i_3_n_0_c6795e1 ,esc_add_ln208_81_reg_7779_7__i_4_n_0_3729c83 ,esc_add_ln208_81_reg_7779_7__i_5_n_0_97a227a };
  assign recovered_385_di = esc_add_ln208_81_reg_7779_reg_11__0_8cb72ab [7:4];
  wire recovered_385_ci = ((esc_add_ln208_81_reg_7779_reg_3__i_1_n_0_750ee82) !== 1'bz) && (esc_add_ln208_81_reg_7779_reg_3__i_1_n_0_750ee82);
  wire recovered_385_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_385_o[0] = recovered_385_s[0] ^ (recovered_385_ci || recovered_385_cy);
  assign recovered_385_co[0] = (recovered_385_s[0] & (recovered_385_ci || recovered_385_cy)) | (~recovered_385_s[0] & recovered_385_di[0]);
  assign recovered_385_o[1] = recovered_385_s[1] ^ recovered_385_co[0];
  assign recovered_385_co[1] = (recovered_385_s[1] & recovered_385_co[0]) | (~recovered_385_s[1] & recovered_385_di[1]);
  assign recovered_385_o[2] = recovered_385_s[2] ^ recovered_385_co[1];
  assign recovered_385_co[2] = (recovered_385_s[2] & recovered_385_co[1]) | (~recovered_385_s[2] & recovered_385_di[2]);
  assign recovered_385_o[3] = recovered_385_s[3] ^ recovered_385_co[2];
  assign recovered_385_co[3] = (recovered_385_s[3] & recovered_385_co[2]) | (~recovered_385_s[3] & recovered_385_di[3]);
  assign {esc_add_ln208_81_reg_7779_reg_7__i_1_n_0_4d12364 ,esc_NLW_add_ln208_81_reg_7779_reg_7__i_1_CO_UNCONNECTED_9825c22 [2:0]} = recovered_385_co;
  assign esc_add_ln208_78_reg_7717_reg_11_a25b5c3 [7:4] = recovered_385_o;

  // Reconstructed LUT2: esc_add_ln208_84_reg_7841_3__i_2_1308b2c
  assign esc_add_ln208_84_reg_7841_3__i_2_n_0_434b45c = ((DOADO[3]) ? (~(esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [3])) : (esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [3]));

  // Reconstructed LUT2: esc_add_ln208_84_reg_7841_3__i_3_0d47eb9
  assign esc_add_ln208_84_reg_7841_3__i_3_n_0_bc7c798 = ((DOADO[2]) ? (~(esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [2])) : (esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [2]));

  // Reconstructed LUT2: esc_add_ln208_84_reg_7841_3__i_4_64b5671
  assign esc_add_ln208_84_reg_7841_3__i_4_n_0_1c74e94 = ((DOADO[1]) ? (~(esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [1])) : (esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [1]));

  // Reconstructed LUT2: esc_add_ln208_84_reg_7841_3__i_5_a020014
  assign esc_add_ln208_84_reg_7841_3__i_5_n_0_ce0eb92 = ((DOADO[0]) ? (~(esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [0])) : (esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [0]));

  // Reconstructed LUT2: esc_add_ln208_84_reg_7841_7__i_2_57dfca2
  assign esc_add_ln208_84_reg_7841_7__i_2_n_0_2c8ffc1 = ((DOADO[7]) ? (~(esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [7])) : (esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [7]));

  // Reconstructed LUT2: esc_add_ln208_84_reg_7841_7__i_3_2a6d474
  assign esc_add_ln208_84_reg_7841_7__i_3_n_0_7502281 = ((DOADO[6]) ? (~(esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [6])) : (esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [6]));

  // Reconstructed LUT2: esc_add_ln208_84_reg_7841_7__i_4_f71da17
  assign esc_add_ln208_84_reg_7841_7__i_4_n_0_549000c = ((DOADO[5]) ? (~(esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [5])) : (esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [5]));

  // Reconstructed LUT2: esc_add_ln208_84_reg_7841_7__i_5_6a4348c
  assign esc_add_ln208_84_reg_7841_7__i_5_n_0_f886d10 = ((DOADO[4]) ? (~(esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [4])) : (esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [4]));

  // Reconstructed CARRY4: esc_add_ln208_84_reg_7841_reg_11__i_1_deea6dc
  wire [3:0] recovered_394_co, recovered_394_o, recovered_394_s, recovered_394_di;
  assign recovered_394_s = esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [11:8];
  assign recovered_394_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_394_ci = ((esc_add_ln208_84_reg_7841_reg_7__i_1_n_0_99b0121) !== 1'bz) && (esc_add_ln208_84_reg_7841_reg_7__i_1_n_0_99b0121);
  wire recovered_394_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_394_o[0] = recovered_394_s[0] ^ (recovered_394_ci || recovered_394_cy);
  assign recovered_394_co[0] = (recovered_394_s[0] & (recovered_394_ci || recovered_394_cy)) | (~recovered_394_s[0] & recovered_394_di[0]);
  assign recovered_394_o[1] = recovered_394_s[1] ^ recovered_394_co[0];
  assign recovered_394_co[1] = (recovered_394_s[1] & recovered_394_co[0]) | (~recovered_394_s[1] & recovered_394_di[1]);
  assign recovered_394_o[2] = recovered_394_s[2] ^ recovered_394_co[1];
  assign recovered_394_co[2] = (recovered_394_s[2] & recovered_394_co[1]) | (~recovered_394_s[2] & recovered_394_di[2]);
  assign recovered_394_o[3] = recovered_394_s[3] ^ recovered_394_co[2];
  assign recovered_394_co[3] = (recovered_394_s[3] & recovered_394_co[2]) | (~recovered_394_s[3] & recovered_394_di[3]);
  assign esc_add_ln208_81_reg_7779_reg_11_758e45d [11:8] = recovered_394_o;

  // Reconstructed CARRY4: esc_add_ln208_84_reg_7841_reg_3__i_1_6b20458
  wire [3:0] recovered_395_co, recovered_395_o, recovered_395_s, recovered_395_di;
  assign recovered_395_s = {esc_add_ln208_84_reg_7841_3__i_2_n_0_434b45c ,esc_add_ln208_84_reg_7841_3__i_3_n_0_bc7c798 ,esc_add_ln208_84_reg_7841_3__i_4_n_0_1c74e94 ,esc_add_ln208_84_reg_7841_3__i_5_n_0_ce0eb92 };
  assign recovered_395_di = esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [3:0];
  wire recovered_395_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_395_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_395_o[0] = recovered_395_s[0] ^ (recovered_395_ci || recovered_395_cy);
  assign recovered_395_co[0] = (recovered_395_s[0] & (recovered_395_ci || recovered_395_cy)) | (~recovered_395_s[0] & recovered_395_di[0]);
  assign recovered_395_o[1] = recovered_395_s[1] ^ recovered_395_co[0];
  assign recovered_395_co[1] = (recovered_395_s[1] & recovered_395_co[0]) | (~recovered_395_s[1] & recovered_395_di[1]);
  assign recovered_395_o[2] = recovered_395_s[2] ^ recovered_395_co[1];
  assign recovered_395_co[2] = (recovered_395_s[2] & recovered_395_co[1]) | (~recovered_395_s[2] & recovered_395_di[2]);
  assign recovered_395_o[3] = recovered_395_s[3] ^ recovered_395_co[2];
  assign recovered_395_co[3] = (recovered_395_s[3] & recovered_395_co[2]) | (~recovered_395_s[3] & recovered_395_di[3]);
  assign {esc_add_ln208_84_reg_7841_reg_3__i_1_n_0_1e15dfe ,esc_NLW_add_ln208_84_reg_7841_reg_3__i_1_CO_UNCONNECTED_307b20f [2:0]} = recovered_395_co;
  assign esc_add_ln208_81_reg_7779_reg_11_758e45d [3:0] = recovered_395_o;

  // Reconstructed CARRY4: esc_add_ln208_84_reg_7841_reg_7__i_1_674c0e2
  wire [3:0] recovered_396_co, recovered_396_o, recovered_396_s, recovered_396_di;
  assign recovered_396_s = {esc_add_ln208_84_reg_7841_7__i_2_n_0_2c8ffc1 ,esc_add_ln208_84_reg_7841_7__i_3_n_0_7502281 ,esc_add_ln208_84_reg_7841_7__i_4_n_0_549000c ,esc_add_ln208_84_reg_7841_7__i_5_n_0_f886d10 };
  assign recovered_396_di = esc_add_ln208_84_reg_7841_reg_11__0_e5f06c7 [7:4];
  wire recovered_396_ci = ((esc_add_ln208_84_reg_7841_reg_3__i_1_n_0_1e15dfe) !== 1'bz) && (esc_add_ln208_84_reg_7841_reg_3__i_1_n_0_1e15dfe);
  wire recovered_396_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_396_o[0] = recovered_396_s[0] ^ (recovered_396_ci || recovered_396_cy);
  assign recovered_396_co[0] = (recovered_396_s[0] & (recovered_396_ci || recovered_396_cy)) | (~recovered_396_s[0] & recovered_396_di[0]);
  assign recovered_396_o[1] = recovered_396_s[1] ^ recovered_396_co[0];
  assign recovered_396_co[1] = (recovered_396_s[1] & recovered_396_co[0]) | (~recovered_396_s[1] & recovered_396_di[1]);
  assign recovered_396_o[2] = recovered_396_s[2] ^ recovered_396_co[1];
  assign recovered_396_co[2] = (recovered_396_s[2] & recovered_396_co[1]) | (~recovered_396_s[2] & recovered_396_di[2]);
  assign recovered_396_o[3] = recovered_396_s[3] ^ recovered_396_co[2];
  assign recovered_396_co[3] = (recovered_396_s[3] & recovered_396_co[2]) | (~recovered_396_s[3] & recovered_396_di[3]);
  assign {esc_add_ln208_84_reg_7841_reg_7__i_1_n_0_99b0121 ,esc_NLW_add_ln208_84_reg_7841_reg_7__i_1_CO_UNCONNECTED_da47d04 [2:0]} = recovered_396_co;
  assign esc_add_ln208_81_reg_7779_reg_11_758e45d [7:4] = recovered_396_o;

  // Reconstructed LUT2: esc_add_ln208_87_reg_7903_3__i_2_a51b570
  assign esc_add_ln208_87_reg_7903_3__i_2_n_0_f4c5497 = ((DOADO[3]) ? (~(esc_add_ln208_87_reg_7903_reg_11_09bd1ec [3])) : (esc_add_ln208_87_reg_7903_reg_11_09bd1ec [3]));

  // Reconstructed LUT2: esc_add_ln208_87_reg_7903_3__i_3_fc5b135
  assign esc_add_ln208_87_reg_7903_3__i_3_n_0_f75f161 = ((DOADO[2]) ? (~(esc_add_ln208_87_reg_7903_reg_11_09bd1ec [2])) : (esc_add_ln208_87_reg_7903_reg_11_09bd1ec [2]));

  // Reconstructed LUT2: esc_add_ln208_87_reg_7903_3__i_4_f3aab69
  assign esc_add_ln208_87_reg_7903_3__i_4_n_0_31afac7 = ((DOADO[1]) ? (~(esc_add_ln208_87_reg_7903_reg_11_09bd1ec [1])) : (esc_add_ln208_87_reg_7903_reg_11_09bd1ec [1]));

  // Reconstructed LUT2: esc_add_ln208_87_reg_7903_3__i_5_54c7aa2
  assign esc_add_ln208_87_reg_7903_3__i_5_n_0_b99ead5 = ((DOADO[0]) ? (~(esc_add_ln208_87_reg_7903_reg_11_09bd1ec [0])) : (esc_add_ln208_87_reg_7903_reg_11_09bd1ec [0]));

  // Reconstructed LUT2: esc_add_ln208_87_reg_7903_7__i_2_baa1332
  assign esc_add_ln208_87_reg_7903_7__i_2_n_0_45dd29a = ((DOADO[7]) ? (~(esc_add_ln208_87_reg_7903_reg_11_09bd1ec [7])) : (esc_add_ln208_87_reg_7903_reg_11_09bd1ec [7]));

  // Reconstructed LUT2: esc_add_ln208_87_reg_7903_7__i_3_925f92b
  assign esc_add_ln208_87_reg_7903_7__i_3_n_0_e541aad = ((DOADO[6]) ? (~(esc_add_ln208_87_reg_7903_reg_11_09bd1ec [6])) : (esc_add_ln208_87_reg_7903_reg_11_09bd1ec [6]));

  // Reconstructed LUT2: esc_add_ln208_87_reg_7903_7__i_4_66a0fe9
  assign esc_add_ln208_87_reg_7903_7__i_4_n_0_fd025e0 = ((DOADO[5]) ? (~(esc_add_ln208_87_reg_7903_reg_11_09bd1ec [5])) : (esc_add_ln208_87_reg_7903_reg_11_09bd1ec [5]));

  // Reconstructed LUT2: esc_add_ln208_87_reg_7903_7__i_5_63e56d5
  assign esc_add_ln208_87_reg_7903_7__i_5_n_0_71c0526 = ((DOADO[4]) ? (~(esc_add_ln208_87_reg_7903_reg_11_09bd1ec [4])) : (esc_add_ln208_87_reg_7903_reg_11_09bd1ec [4]));

  // Reconstructed CARRY4: esc_add_ln208_87_reg_7903_reg_11__i_1_04baaa4
  wire [3:0] recovered_405_co, recovered_405_o, recovered_405_s, recovered_405_di;
  assign recovered_405_s = esc_add_ln208_87_reg_7903_reg_11_09bd1ec [11:8];
  assign recovered_405_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_405_ci = ((esc_add_ln208_87_reg_7903_reg_7__i_1_n_0_7bf0612) !== 1'bz) && (esc_add_ln208_87_reg_7903_reg_7__i_1_n_0_7bf0612);
  wire recovered_405_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_405_o[0] = recovered_405_s[0] ^ (recovered_405_ci || recovered_405_cy);
  assign recovered_405_co[0] = (recovered_405_s[0] & (recovered_405_ci || recovered_405_cy)) | (~recovered_405_s[0] & recovered_405_di[0]);
  assign recovered_405_o[1] = recovered_405_s[1] ^ recovered_405_co[0];
  assign recovered_405_co[1] = (recovered_405_s[1] & recovered_405_co[0]) | (~recovered_405_s[1] & recovered_405_di[1]);
  assign recovered_405_o[2] = recovered_405_s[2] ^ recovered_405_co[1];
  assign recovered_405_co[2] = (recovered_405_s[2] & recovered_405_co[1]) | (~recovered_405_s[2] & recovered_405_di[2]);
  assign recovered_405_o[3] = recovered_405_s[3] ^ recovered_405_co[2];
  assign recovered_405_co[3] = (recovered_405_s[3] & recovered_405_co[2]) | (~recovered_405_s[3] & recovered_405_di[3]);
  assign {esc_add_ln208_87_reg_7903_reg_11__i_1_n_0_2d0377b ,esc_NLW_add_ln208_87_reg_7903_reg_11__i_1_CO_UNCONNECTED_7270aa1 [2:0]} = recovered_405_co;
  assign esc_add_ln208_84_reg_7841_reg_11_3a19824 [11:8] = recovered_405_o;

  // Reconstructed CARRY4: esc_add_ln208_87_reg_7903_reg_12__i_1_8858f64
  wire [3:0] recovered_406_co, recovered_406_o, recovered_406_s, recovered_406_di;
  assign recovered_406_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 };
  assign recovered_406_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_406_ci = ((esc_add_ln208_87_reg_7903_reg_11__i_1_n_0_2d0377b) !== 1'bz) && (esc_add_ln208_87_reg_7903_reg_11__i_1_n_0_2d0377b);
  wire recovered_406_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_406_o[0] = recovered_406_s[0] ^ (recovered_406_ci || recovered_406_cy);
  assign recovered_406_co[0] = (recovered_406_s[0] & (recovered_406_ci || recovered_406_cy)) | (~recovered_406_s[0] & recovered_406_di[0]);
  assign recovered_406_o[1] = recovered_406_s[1] ^ recovered_406_co[0];
  assign recovered_406_co[1] = (recovered_406_s[1] & recovered_406_co[0]) | (~recovered_406_s[1] & recovered_406_di[1]);
  assign recovered_406_o[2] = recovered_406_s[2] ^ recovered_406_co[1];
  assign recovered_406_co[2] = (recovered_406_s[2] & recovered_406_co[1]) | (~recovered_406_s[2] & recovered_406_di[2]);
  assign recovered_406_o[3] = recovered_406_s[3] ^ recovered_406_co[2];
  assign recovered_406_co[3] = (recovered_406_s[3] & recovered_406_co[2]) | (~recovered_406_s[3] & recovered_406_di[3]);
  assign esc_add_ln208_84_reg_7841_reg_11_3a19824 [12] = recovered_406_co;

  // Reconstructed CARRY4: esc_add_ln208_87_reg_7903_reg_3__i_1_ac96312
  wire [3:0] recovered_407_co, recovered_407_o, recovered_407_s, recovered_407_di;
  assign recovered_407_s = {esc_add_ln208_87_reg_7903_3__i_2_n_0_f4c5497 ,esc_add_ln208_87_reg_7903_3__i_3_n_0_f75f161 ,esc_add_ln208_87_reg_7903_3__i_4_n_0_31afac7 ,esc_add_ln208_87_reg_7903_3__i_5_n_0_b99ead5 };
  assign recovered_407_di = esc_add_ln208_87_reg_7903_reg_11_09bd1ec [3:0];
  wire recovered_407_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_407_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_407_o[0] = recovered_407_s[0] ^ (recovered_407_ci || recovered_407_cy);
  assign recovered_407_co[0] = (recovered_407_s[0] & (recovered_407_ci || recovered_407_cy)) | (~recovered_407_s[0] & recovered_407_di[0]);
  assign recovered_407_o[1] = recovered_407_s[1] ^ recovered_407_co[0];
  assign recovered_407_co[1] = (recovered_407_s[1] & recovered_407_co[0]) | (~recovered_407_s[1] & recovered_407_di[1]);
  assign recovered_407_o[2] = recovered_407_s[2] ^ recovered_407_co[1];
  assign recovered_407_co[2] = (recovered_407_s[2] & recovered_407_co[1]) | (~recovered_407_s[2] & recovered_407_di[2]);
  assign recovered_407_o[3] = recovered_407_s[3] ^ recovered_407_co[2];
  assign recovered_407_co[3] = (recovered_407_s[3] & recovered_407_co[2]) | (~recovered_407_s[3] & recovered_407_di[3]);
  assign {esc_add_ln208_87_reg_7903_reg_3__i_1_n_0_a1308bf ,esc_NLW_add_ln208_87_reg_7903_reg_3__i_1_CO_UNCONNECTED_4d76354 [2:0]} = recovered_407_co;
  assign esc_add_ln208_84_reg_7841_reg_11_3a19824 [3:0] = recovered_407_o;

  // Reconstructed CARRY4: esc_add_ln208_87_reg_7903_reg_7__i_1_65b71ce
  wire [3:0] recovered_408_co, recovered_408_o, recovered_408_s, recovered_408_di;
  assign recovered_408_s = {esc_add_ln208_87_reg_7903_7__i_2_n_0_45dd29a ,esc_add_ln208_87_reg_7903_7__i_3_n_0_e541aad ,esc_add_ln208_87_reg_7903_7__i_4_n_0_fd025e0 ,esc_add_ln208_87_reg_7903_7__i_5_n_0_71c0526 };
  assign recovered_408_di = esc_add_ln208_87_reg_7903_reg_11_09bd1ec [7:4];
  wire recovered_408_ci = ((esc_add_ln208_87_reg_7903_reg_3__i_1_n_0_a1308bf) !== 1'bz) && (esc_add_ln208_87_reg_7903_reg_3__i_1_n_0_a1308bf);
  wire recovered_408_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_408_o[0] = recovered_408_s[0] ^ (recovered_408_ci || recovered_408_cy);
  assign recovered_408_co[0] = (recovered_408_s[0] & (recovered_408_ci || recovered_408_cy)) | (~recovered_408_s[0] & recovered_408_di[0]);
  assign recovered_408_o[1] = recovered_408_s[1] ^ recovered_408_co[0];
  assign recovered_408_co[1] = (recovered_408_s[1] & recovered_408_co[0]) | (~recovered_408_s[1] & recovered_408_di[1]);
  assign recovered_408_o[2] = recovered_408_s[2] ^ recovered_408_co[1];
  assign recovered_408_co[2] = (recovered_408_s[2] & recovered_408_co[1]) | (~recovered_408_s[2] & recovered_408_di[2]);
  assign recovered_408_o[3] = recovered_408_s[3] ^ recovered_408_co[2];
  assign recovered_408_co[3] = (recovered_408_s[3] & recovered_408_co[2]) | (~recovered_408_s[3] & recovered_408_di[3]);
  assign {esc_add_ln208_87_reg_7903_reg_7__i_1_n_0_7bf0612 ,esc_NLW_add_ln208_87_reg_7903_reg_7__i_1_CO_UNCONNECTED_174dab5 [2:0]} = recovered_408_co;
  assign esc_add_ln208_84_reg_7841_reg_11_3a19824 [7:4] = recovered_408_o;

  // Reconstructed LUT2: esc_add_ln208_90_reg_7965_3__i_2_0f1c011
  assign esc_add_ln208_90_reg_7965_3__i_2_n_0_c89938d = ((DOADO[3]) ? (~(esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [3])) : (esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [3]));

  // Reconstructed LUT2: esc_add_ln208_90_reg_7965_3__i_3_cd1fbd4
  assign esc_add_ln208_90_reg_7965_3__i_3_n_0_dd333d1 = ((DOADO[2]) ? (~(esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [2])) : (esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [2]));

  // Reconstructed LUT2: esc_add_ln208_90_reg_7965_3__i_4_2c40198
  assign esc_add_ln208_90_reg_7965_3__i_4_n_0_9824211 = ((DOADO[1]) ? (~(esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [1])) : (esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [1]));

  // Reconstructed LUT2: esc_add_ln208_90_reg_7965_3__i_5_beeb213
  assign esc_add_ln208_90_reg_7965_3__i_5_n_0_bd69146 = ((DOADO[0]) ? (~(esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [0])) : (esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [0]));

  // Reconstructed LUT2: esc_add_ln208_90_reg_7965_7__i_2_6258774
  assign esc_add_ln208_90_reg_7965_7__i_2_n_0_3404232 = ((DOADO[7]) ? (~(esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [7])) : (esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [7]));

  // Reconstructed LUT2: esc_add_ln208_90_reg_7965_7__i_3_a512654
  assign esc_add_ln208_90_reg_7965_7__i_3_n_0_51c21ef = ((DOADO[6]) ? (~(esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [6])) : (esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [6]));

  // Reconstructed LUT2: esc_add_ln208_90_reg_7965_7__i_4_e63ab8c
  assign esc_add_ln208_90_reg_7965_7__i_4_n_0_5d60749 = ((DOADO[5]) ? (~(esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [5])) : (esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [5]));

  // Reconstructed LUT2: esc_add_ln208_90_reg_7965_7__i_5_1c17ead
  assign esc_add_ln208_90_reg_7965_7__i_5_n_0_2bbdecf = ((DOADO[4]) ? (~(esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [4])) : (esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [4]));

  // Reconstructed CARRY4: esc_add_ln208_90_reg_7965_reg_11__i_1_f8bc6f9
  wire [3:0] recovered_417_co, recovered_417_o, recovered_417_s, recovered_417_di;
  assign recovered_417_s = esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [11:8];
  assign recovered_417_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_417_ci = ((esc_add_ln208_90_reg_7965_reg_7__i_1_n_0_30f1e19) !== 1'bz) && (esc_add_ln208_90_reg_7965_reg_7__i_1_n_0_30f1e19);
  wire recovered_417_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_417_o[0] = recovered_417_s[0] ^ (recovered_417_ci || recovered_417_cy);
  assign recovered_417_co[0] = (recovered_417_s[0] & (recovered_417_ci || recovered_417_cy)) | (~recovered_417_s[0] & recovered_417_di[0]);
  assign recovered_417_o[1] = recovered_417_s[1] ^ recovered_417_co[0];
  assign recovered_417_co[1] = (recovered_417_s[1] & recovered_417_co[0]) | (~recovered_417_s[1] & recovered_417_di[1]);
  assign recovered_417_o[2] = recovered_417_s[2] ^ recovered_417_co[1];
  assign recovered_417_co[2] = (recovered_417_s[2] & recovered_417_co[1]) | (~recovered_417_s[2] & recovered_417_di[2]);
  assign recovered_417_o[3] = recovered_417_s[3] ^ recovered_417_co[2];
  assign recovered_417_co[3] = (recovered_417_s[3] & recovered_417_co[2]) | (~recovered_417_s[3] & recovered_417_di[3]);
  assign {esc_add_ln208_90_reg_7965_reg_11__i_1_n_0_3bb84e0 ,esc_NLW_add_ln208_90_reg_7965_reg_11__i_1_CO_UNCONNECTED_64db9cf [2:0]} = recovered_417_co;
  assign esc_add_ln208_87_reg_7903_reg_12_ebbbe3f [11:8] = recovered_417_o;

  // Reconstructed CARRY4: esc_add_ln208_90_reg_7965_reg_12__i_1_acb0353
  wire [3:0] recovered_418_co, recovered_418_o, recovered_418_s, recovered_418_di;
  assign recovered_418_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [12]};
  assign recovered_418_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_418_ci = ((esc_add_ln208_90_reg_7965_reg_11__i_1_n_0_3bb84e0) !== 1'bz) && (esc_add_ln208_90_reg_7965_reg_11__i_1_n_0_3bb84e0);
  wire recovered_418_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_418_o[0] = recovered_418_s[0] ^ (recovered_418_ci || recovered_418_cy);
  assign recovered_418_co[0] = (recovered_418_s[0] & (recovered_418_ci || recovered_418_cy)) | (~recovered_418_s[0] & recovered_418_di[0]);
  assign recovered_418_o[1] = recovered_418_s[1] ^ recovered_418_co[0];
  assign recovered_418_co[1] = (recovered_418_s[1] & recovered_418_co[0]) | (~recovered_418_s[1] & recovered_418_di[1]);
  assign recovered_418_o[2] = recovered_418_s[2] ^ recovered_418_co[1];
  assign recovered_418_co[2] = (recovered_418_s[2] & recovered_418_co[1]) | (~recovered_418_s[2] & recovered_418_di[2]);
  assign recovered_418_o[3] = recovered_418_s[3] ^ recovered_418_co[2];
  assign recovered_418_co[3] = (recovered_418_s[3] & recovered_418_co[2]) | (~recovered_418_s[3] & recovered_418_di[3]);
  assign esc_add_ln208_87_reg_7903_reg_12_ebbbe3f [12] = recovered_418_o;

  // Reconstructed CARRY4: esc_add_ln208_90_reg_7965_reg_3__i_1_4535e23
  wire [3:0] recovered_419_co, recovered_419_o, recovered_419_s, recovered_419_di;
  assign recovered_419_s = {esc_add_ln208_90_reg_7965_3__i_2_n_0_c89938d ,esc_add_ln208_90_reg_7965_3__i_3_n_0_dd333d1 ,esc_add_ln208_90_reg_7965_3__i_4_n_0_9824211 ,esc_add_ln208_90_reg_7965_3__i_5_n_0_bd69146 };
  assign recovered_419_di = esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [3:0];
  wire recovered_419_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_419_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_419_o[0] = recovered_419_s[0] ^ (recovered_419_ci || recovered_419_cy);
  assign recovered_419_co[0] = (recovered_419_s[0] & (recovered_419_ci || recovered_419_cy)) | (~recovered_419_s[0] & recovered_419_di[0]);
  assign recovered_419_o[1] = recovered_419_s[1] ^ recovered_419_co[0];
  assign recovered_419_co[1] = (recovered_419_s[1] & recovered_419_co[0]) | (~recovered_419_s[1] & recovered_419_di[1]);
  assign recovered_419_o[2] = recovered_419_s[2] ^ recovered_419_co[1];
  assign recovered_419_co[2] = (recovered_419_s[2] & recovered_419_co[1]) | (~recovered_419_s[2] & recovered_419_di[2]);
  assign recovered_419_o[3] = recovered_419_s[3] ^ recovered_419_co[2];
  assign recovered_419_co[3] = (recovered_419_s[3] & recovered_419_co[2]) | (~recovered_419_s[3] & recovered_419_di[3]);
  assign {esc_add_ln208_90_reg_7965_reg_3__i_1_n_0_2590075 ,esc_NLW_add_ln208_90_reg_7965_reg_3__i_1_CO_UNCONNECTED_cc0073d [2:0]} = recovered_419_co;
  assign esc_add_ln208_87_reg_7903_reg_12_ebbbe3f [3:0] = recovered_419_o;

  // Reconstructed CARRY4: esc_add_ln208_90_reg_7965_reg_7__i_1_8e6459b
  wire [3:0] recovered_420_co, recovered_420_o, recovered_420_s, recovered_420_di;
  assign recovered_420_s = {esc_add_ln208_90_reg_7965_7__i_2_n_0_3404232 ,esc_add_ln208_90_reg_7965_7__i_3_n_0_51c21ef ,esc_add_ln208_90_reg_7965_7__i_4_n_0_5d60749 ,esc_add_ln208_90_reg_7965_7__i_5_n_0_2bbdecf };
  assign recovered_420_di = esc_add_ln208_90_reg_7965_reg_12__0_2fe7d8f [7:4];
  wire recovered_420_ci = ((esc_add_ln208_90_reg_7965_reg_3__i_1_n_0_2590075) !== 1'bz) && (esc_add_ln208_90_reg_7965_reg_3__i_1_n_0_2590075);
  wire recovered_420_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_420_o[0] = recovered_420_s[0] ^ (recovered_420_ci || recovered_420_cy);
  assign recovered_420_co[0] = (recovered_420_s[0] & (recovered_420_ci || recovered_420_cy)) | (~recovered_420_s[0] & recovered_420_di[0]);
  assign recovered_420_o[1] = recovered_420_s[1] ^ recovered_420_co[0];
  assign recovered_420_co[1] = (recovered_420_s[1] & recovered_420_co[0]) | (~recovered_420_s[1] & recovered_420_di[1]);
  assign recovered_420_o[2] = recovered_420_s[2] ^ recovered_420_co[1];
  assign recovered_420_co[2] = (recovered_420_s[2] & recovered_420_co[1]) | (~recovered_420_s[2] & recovered_420_di[2]);
  assign recovered_420_o[3] = recovered_420_s[3] ^ recovered_420_co[2];
  assign recovered_420_co[3] = (recovered_420_s[3] & recovered_420_co[2]) | (~recovered_420_s[3] & recovered_420_di[3]);
  assign {esc_add_ln208_90_reg_7965_reg_7__i_1_n_0_30f1e19 ,esc_NLW_add_ln208_90_reg_7965_reg_7__i_1_CO_UNCONNECTED_c7c8416 [2:0]} = recovered_420_co;
  assign esc_add_ln208_87_reg_7903_reg_12_ebbbe3f [7:4] = recovered_420_o;

  // Reconstructed LUT2: esc_add_ln208_93_reg_8027_3__i_2_7211162
  assign esc_add_ln208_93_reg_8027_3__i_2_n_0_b2a7e69 = ((DOADO[3]) ? (~(esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [3])) : (esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [3]));

  // Reconstructed LUT2: esc_add_ln208_93_reg_8027_3__i_3_af2ef86
  assign esc_add_ln208_93_reg_8027_3__i_3_n_0_bd66261 = ((DOADO[2]) ? (~(esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [2])) : (esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [2]));

  // Reconstructed LUT2: esc_add_ln208_93_reg_8027_3__i_4_0b5e9b9
  assign esc_add_ln208_93_reg_8027_3__i_4_n_0_58c00bd = ((DOADO[1]) ? (~(esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [1])) : (esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [1]));

  // Reconstructed LUT2: esc_add_ln208_93_reg_8027_3__i_5_9d4a59b
  assign esc_add_ln208_93_reg_8027_3__i_5_n_0_c5edabf = ((DOADO[0]) ? (~(esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [0])) : (esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [0]));

  // Reconstructed LUT2: esc_add_ln208_93_reg_8027_7__i_2_8dcea34
  assign esc_add_ln208_93_reg_8027_7__i_2_n_0_9c53918 = ((DOADO[7]) ? (~(esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [7])) : (esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [7]));

  // Reconstructed LUT2: esc_add_ln208_93_reg_8027_7__i_3_13ab3d2
  assign esc_add_ln208_93_reg_8027_7__i_3_n_0_09dcbb1 = ((DOADO[6]) ? (~(esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [6])) : (esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [6]));

  // Reconstructed LUT2: esc_add_ln208_93_reg_8027_7__i_4_db58f46
  assign esc_add_ln208_93_reg_8027_7__i_4_n_0_87df4e3 = ((DOADO[5]) ? (~(esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [5])) : (esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [5]));

  // Reconstructed LUT2: esc_add_ln208_93_reg_8027_7__i_5_c870c49
  assign esc_add_ln208_93_reg_8027_7__i_5_n_0_1ecc40f = ((DOADO[4]) ? (~(esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [4])) : (esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [4]));

  // Reconstructed CARRY4: esc_add_ln208_93_reg_8027_reg_11__i_1_7b3f0dc
  wire [3:0] recovered_429_co, recovered_429_o, recovered_429_s, recovered_429_di;
  assign recovered_429_s = esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [11:8];
  assign recovered_429_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_429_ci = ((esc_add_ln208_93_reg_8027_reg_7__i_1_n_0_90631f4) !== 1'bz) && (esc_add_ln208_93_reg_8027_reg_7__i_1_n_0_90631f4);
  wire recovered_429_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_429_o[0] = recovered_429_s[0] ^ (recovered_429_ci || recovered_429_cy);
  assign recovered_429_co[0] = (recovered_429_s[0] & (recovered_429_ci || recovered_429_cy)) | (~recovered_429_s[0] & recovered_429_di[0]);
  assign recovered_429_o[1] = recovered_429_s[1] ^ recovered_429_co[0];
  assign recovered_429_co[1] = (recovered_429_s[1] & recovered_429_co[0]) | (~recovered_429_s[1] & recovered_429_di[1]);
  assign recovered_429_o[2] = recovered_429_s[2] ^ recovered_429_co[1];
  assign recovered_429_co[2] = (recovered_429_s[2] & recovered_429_co[1]) | (~recovered_429_s[2] & recovered_429_di[2]);
  assign recovered_429_o[3] = recovered_429_s[3] ^ recovered_429_co[2];
  assign recovered_429_co[3] = (recovered_429_s[3] & recovered_429_co[2]) | (~recovered_429_s[3] & recovered_429_di[3]);
  assign {esc_add_ln208_93_reg_8027_reg_11__i_1_n_0_db54423 ,esc_NLW_add_ln208_93_reg_8027_reg_11__i_1_CO_UNCONNECTED_081f578 [2:0]} = recovered_429_co;
  assign esc_add_ln208_90_reg_7965_reg_12_6090767 [11:8] = recovered_429_o;

  // Reconstructed CARRY4: esc_add_ln208_93_reg_8027_reg_12__i_1_ef76a31
  wire [3:0] recovered_430_co, recovered_430_o, recovered_430_s, recovered_430_di;
  assign recovered_430_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [12]};
  assign recovered_430_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_430_ci = ((esc_add_ln208_93_reg_8027_reg_11__i_1_n_0_db54423) !== 1'bz) && (esc_add_ln208_93_reg_8027_reg_11__i_1_n_0_db54423);
  wire recovered_430_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_430_o[0] = recovered_430_s[0] ^ (recovered_430_ci || recovered_430_cy);
  assign recovered_430_co[0] = (recovered_430_s[0] & (recovered_430_ci || recovered_430_cy)) | (~recovered_430_s[0] & recovered_430_di[0]);
  assign recovered_430_o[1] = recovered_430_s[1] ^ recovered_430_co[0];
  assign recovered_430_co[1] = (recovered_430_s[1] & recovered_430_co[0]) | (~recovered_430_s[1] & recovered_430_di[1]);
  assign recovered_430_o[2] = recovered_430_s[2] ^ recovered_430_co[1];
  assign recovered_430_co[2] = (recovered_430_s[2] & recovered_430_co[1]) | (~recovered_430_s[2] & recovered_430_di[2]);
  assign recovered_430_o[3] = recovered_430_s[3] ^ recovered_430_co[2];
  assign recovered_430_co[3] = (recovered_430_s[3] & recovered_430_co[2]) | (~recovered_430_s[3] & recovered_430_di[3]);
  assign esc_add_ln208_90_reg_7965_reg_12_6090767 [12] = recovered_430_o;

  // Reconstructed CARRY4: esc_add_ln208_93_reg_8027_reg_3__i_1_4c3205a
  wire [3:0] recovered_431_co, recovered_431_o, recovered_431_s, recovered_431_di;
  assign recovered_431_s = {esc_add_ln208_93_reg_8027_3__i_2_n_0_b2a7e69 ,esc_add_ln208_93_reg_8027_3__i_3_n_0_bd66261 ,esc_add_ln208_93_reg_8027_3__i_4_n_0_58c00bd ,esc_add_ln208_93_reg_8027_3__i_5_n_0_c5edabf };
  assign recovered_431_di = esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [3:0];
  wire recovered_431_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_431_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_431_o[0] = recovered_431_s[0] ^ (recovered_431_ci || recovered_431_cy);
  assign recovered_431_co[0] = (recovered_431_s[0] & (recovered_431_ci || recovered_431_cy)) | (~recovered_431_s[0] & recovered_431_di[0]);
  assign recovered_431_o[1] = recovered_431_s[1] ^ recovered_431_co[0];
  assign recovered_431_co[1] = (recovered_431_s[1] & recovered_431_co[0]) | (~recovered_431_s[1] & recovered_431_di[1]);
  assign recovered_431_o[2] = recovered_431_s[2] ^ recovered_431_co[1];
  assign recovered_431_co[2] = (recovered_431_s[2] & recovered_431_co[1]) | (~recovered_431_s[2] & recovered_431_di[2]);
  assign recovered_431_o[3] = recovered_431_s[3] ^ recovered_431_co[2];
  assign recovered_431_co[3] = (recovered_431_s[3] & recovered_431_co[2]) | (~recovered_431_s[3] & recovered_431_di[3]);
  assign {esc_add_ln208_93_reg_8027_reg_3__i_1_n_0_21dbeaa ,esc_NLW_add_ln208_93_reg_8027_reg_3__i_1_CO_UNCONNECTED_0bdb964 [2:0]} = recovered_431_co;
  assign esc_add_ln208_90_reg_7965_reg_12_6090767 [3:0] = recovered_431_o;

  // Reconstructed CARRY4: esc_add_ln208_93_reg_8027_reg_7__i_1_1638588
  wire [3:0] recovered_432_co, recovered_432_o, recovered_432_s, recovered_432_di;
  assign recovered_432_s = {esc_add_ln208_93_reg_8027_7__i_2_n_0_9c53918 ,esc_add_ln208_93_reg_8027_7__i_3_n_0_09dcbb1 ,esc_add_ln208_93_reg_8027_7__i_4_n_0_87df4e3 ,esc_add_ln208_93_reg_8027_7__i_5_n_0_1ecc40f };
  assign recovered_432_di = esc_add_ln208_93_reg_8027_reg_12__0_ad2ec13 [7:4];
  wire recovered_432_ci = ((esc_add_ln208_93_reg_8027_reg_3__i_1_n_0_21dbeaa) !== 1'bz) && (esc_add_ln208_93_reg_8027_reg_3__i_1_n_0_21dbeaa);
  wire recovered_432_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_432_o[0] = recovered_432_s[0] ^ (recovered_432_ci || recovered_432_cy);
  assign recovered_432_co[0] = (recovered_432_s[0] & (recovered_432_ci || recovered_432_cy)) | (~recovered_432_s[0] & recovered_432_di[0]);
  assign recovered_432_o[1] = recovered_432_s[1] ^ recovered_432_co[0];
  assign recovered_432_co[1] = (recovered_432_s[1] & recovered_432_co[0]) | (~recovered_432_s[1] & recovered_432_di[1]);
  assign recovered_432_o[2] = recovered_432_s[2] ^ recovered_432_co[1];
  assign recovered_432_co[2] = (recovered_432_s[2] & recovered_432_co[1]) | (~recovered_432_s[2] & recovered_432_di[2]);
  assign recovered_432_o[3] = recovered_432_s[3] ^ recovered_432_co[2];
  assign recovered_432_co[3] = (recovered_432_s[3] & recovered_432_co[2]) | (~recovered_432_s[3] & recovered_432_di[3]);
  assign {esc_add_ln208_93_reg_8027_reg_7__i_1_n_0_90631f4 ,esc_NLW_add_ln208_93_reg_8027_reg_7__i_1_CO_UNCONNECTED_2477b36 [2:0]} = recovered_432_co;
  assign esc_add_ln208_90_reg_7965_reg_12_6090767 [7:4] = recovered_432_o;

  // Reconstructed LUT2: esc_add_ln208_96_reg_8089_3__i_2_8f1ff85
  assign esc_add_ln208_96_reg_8089_3__i_2_n_0_868016c = ((DOADO[3]) ? (~(esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [3])) : (esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [3]));

  // Reconstructed LUT2: esc_add_ln208_96_reg_8089_3__i_3_2aa031d
  assign esc_add_ln208_96_reg_8089_3__i_3_n_0_0538a8c = ((DOADO[2]) ? (~(esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [2])) : (esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [2]));

  // Reconstructed LUT2: esc_add_ln208_96_reg_8089_3__i_4_b98393e
  assign esc_add_ln208_96_reg_8089_3__i_4_n_0_b591fc9 = ((DOADO[1]) ? (~(esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [1])) : (esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [1]));

  // Reconstructed LUT2: esc_add_ln208_96_reg_8089_3__i_5_512d0de
  assign esc_add_ln208_96_reg_8089_3__i_5_n_0_492cab7 = ((DOADO[0]) ? (~(esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [0])) : (esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [0]));

  // Reconstructed LUT2: esc_add_ln208_96_reg_8089_7__i_2_33847e2
  assign esc_add_ln208_96_reg_8089_7__i_2_n_0_ef85ea1 = ((DOADO[7]) ? (~(esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [7])) : (esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [7]));

  // Reconstructed LUT2: esc_add_ln208_96_reg_8089_7__i_3_8d2c769
  assign esc_add_ln208_96_reg_8089_7__i_3_n_0_3e79da8 = ((DOADO[6]) ? (~(esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [6])) : (esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [6]));

  // Reconstructed LUT2: esc_add_ln208_96_reg_8089_7__i_4_aab813f
  assign esc_add_ln208_96_reg_8089_7__i_4_n_0_4c42276 = ((DOADO[5]) ? (~(esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [5])) : (esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [5]));

  // Reconstructed LUT2: esc_add_ln208_96_reg_8089_7__i_5_7932816
  assign esc_add_ln208_96_reg_8089_7__i_5_n_0_f4d6eae = ((DOADO[4]) ? (~(esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [4])) : (esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [4]));

  // Reconstructed CARRY4: esc_add_ln208_96_reg_8089_reg_11__i_1_ce38ebe
  wire [3:0] recovered_441_co, recovered_441_o, recovered_441_s, recovered_441_di;
  assign recovered_441_s = esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [11:8];
  assign recovered_441_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_441_ci = ((esc_add_ln208_96_reg_8089_reg_7__i_1_n_0_91916af) !== 1'bz) && (esc_add_ln208_96_reg_8089_reg_7__i_1_n_0_91916af);
  wire recovered_441_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_441_o[0] = recovered_441_s[0] ^ (recovered_441_ci || recovered_441_cy);
  assign recovered_441_co[0] = (recovered_441_s[0] & (recovered_441_ci || recovered_441_cy)) | (~recovered_441_s[0] & recovered_441_di[0]);
  assign recovered_441_o[1] = recovered_441_s[1] ^ recovered_441_co[0];
  assign recovered_441_co[1] = (recovered_441_s[1] & recovered_441_co[0]) | (~recovered_441_s[1] & recovered_441_di[1]);
  assign recovered_441_o[2] = recovered_441_s[2] ^ recovered_441_co[1];
  assign recovered_441_co[2] = (recovered_441_s[2] & recovered_441_co[1]) | (~recovered_441_s[2] & recovered_441_di[2]);
  assign recovered_441_o[3] = recovered_441_s[3] ^ recovered_441_co[2];
  assign recovered_441_co[3] = (recovered_441_s[3] & recovered_441_co[2]) | (~recovered_441_s[3] & recovered_441_di[3]);
  assign {esc_add_ln208_96_reg_8089_reg_11__i_1_n_0_aab1676 ,esc_NLW_add_ln208_96_reg_8089_reg_11__i_1_CO_UNCONNECTED_2ea4a37 [2:0]} = recovered_441_co;
  assign esc_add_ln208_93_reg_8027_reg_12_0c8544f [11:8] = recovered_441_o;

  // Reconstructed CARRY4: esc_add_ln208_96_reg_8089_reg_12__i_1_56dd1fc
  wire [3:0] recovered_442_co, recovered_442_o, recovered_442_s, recovered_442_di;
  assign recovered_442_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [12]};
  assign recovered_442_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_442_ci = ((esc_add_ln208_96_reg_8089_reg_11__i_1_n_0_aab1676) !== 1'bz) && (esc_add_ln208_96_reg_8089_reg_11__i_1_n_0_aab1676);
  wire recovered_442_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_442_o[0] = recovered_442_s[0] ^ (recovered_442_ci || recovered_442_cy);
  assign recovered_442_co[0] = (recovered_442_s[0] & (recovered_442_ci || recovered_442_cy)) | (~recovered_442_s[0] & recovered_442_di[0]);
  assign recovered_442_o[1] = recovered_442_s[1] ^ recovered_442_co[0];
  assign recovered_442_co[1] = (recovered_442_s[1] & recovered_442_co[0]) | (~recovered_442_s[1] & recovered_442_di[1]);
  assign recovered_442_o[2] = recovered_442_s[2] ^ recovered_442_co[1];
  assign recovered_442_co[2] = (recovered_442_s[2] & recovered_442_co[1]) | (~recovered_442_s[2] & recovered_442_di[2]);
  assign recovered_442_o[3] = recovered_442_s[3] ^ recovered_442_co[2];
  assign recovered_442_co[3] = (recovered_442_s[3] & recovered_442_co[2]) | (~recovered_442_s[3] & recovered_442_di[3]);
  assign esc_add_ln208_93_reg_8027_reg_12_0c8544f [12] = recovered_442_o;

  // Reconstructed CARRY4: esc_add_ln208_96_reg_8089_reg_3__i_1_7e79434
  wire [3:0] recovered_443_co, recovered_443_o, recovered_443_s, recovered_443_di;
  assign recovered_443_s = {esc_add_ln208_96_reg_8089_3__i_2_n_0_868016c ,esc_add_ln208_96_reg_8089_3__i_3_n_0_0538a8c ,esc_add_ln208_96_reg_8089_3__i_4_n_0_b591fc9 ,esc_add_ln208_96_reg_8089_3__i_5_n_0_492cab7 };
  assign recovered_443_di = esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [3:0];
  wire recovered_443_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_443_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_443_o[0] = recovered_443_s[0] ^ (recovered_443_ci || recovered_443_cy);
  assign recovered_443_co[0] = (recovered_443_s[0] & (recovered_443_ci || recovered_443_cy)) | (~recovered_443_s[0] & recovered_443_di[0]);
  assign recovered_443_o[1] = recovered_443_s[1] ^ recovered_443_co[0];
  assign recovered_443_co[1] = (recovered_443_s[1] & recovered_443_co[0]) | (~recovered_443_s[1] & recovered_443_di[1]);
  assign recovered_443_o[2] = recovered_443_s[2] ^ recovered_443_co[1];
  assign recovered_443_co[2] = (recovered_443_s[2] & recovered_443_co[1]) | (~recovered_443_s[2] & recovered_443_di[2]);
  assign recovered_443_o[3] = recovered_443_s[3] ^ recovered_443_co[2];
  assign recovered_443_co[3] = (recovered_443_s[3] & recovered_443_co[2]) | (~recovered_443_s[3] & recovered_443_di[3]);
  assign {esc_add_ln208_96_reg_8089_reg_3__i_1_n_0_c21d59c ,esc_NLW_add_ln208_96_reg_8089_reg_3__i_1_CO_UNCONNECTED_cb9bff0 [2:0]} = recovered_443_co;
  assign esc_add_ln208_93_reg_8027_reg_12_0c8544f [3:0] = recovered_443_o;

  // Reconstructed CARRY4: esc_add_ln208_96_reg_8089_reg_7__i_1_1b1e40c
  wire [3:0] recovered_444_co, recovered_444_o, recovered_444_s, recovered_444_di;
  assign recovered_444_s = {esc_add_ln208_96_reg_8089_7__i_2_n_0_ef85ea1 ,esc_add_ln208_96_reg_8089_7__i_3_n_0_3e79da8 ,esc_add_ln208_96_reg_8089_7__i_4_n_0_4c42276 ,esc_add_ln208_96_reg_8089_7__i_5_n_0_f4d6eae };
  assign recovered_444_di = esc_add_ln208_96_reg_8089_reg_12__0_4851c79 [7:4];
  wire recovered_444_ci = ((esc_add_ln208_96_reg_8089_reg_3__i_1_n_0_c21d59c) !== 1'bz) && (esc_add_ln208_96_reg_8089_reg_3__i_1_n_0_c21d59c);
  wire recovered_444_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_444_o[0] = recovered_444_s[0] ^ (recovered_444_ci || recovered_444_cy);
  assign recovered_444_co[0] = (recovered_444_s[0] & (recovered_444_ci || recovered_444_cy)) | (~recovered_444_s[0] & recovered_444_di[0]);
  assign recovered_444_o[1] = recovered_444_s[1] ^ recovered_444_co[0];
  assign recovered_444_co[1] = (recovered_444_s[1] & recovered_444_co[0]) | (~recovered_444_s[1] & recovered_444_di[1]);
  assign recovered_444_o[2] = recovered_444_s[2] ^ recovered_444_co[1];
  assign recovered_444_co[2] = (recovered_444_s[2] & recovered_444_co[1]) | (~recovered_444_s[2] & recovered_444_di[2]);
  assign recovered_444_o[3] = recovered_444_s[3] ^ recovered_444_co[2];
  assign recovered_444_co[3] = (recovered_444_s[3] & recovered_444_co[2]) | (~recovered_444_s[3] & recovered_444_di[3]);
  assign {esc_add_ln208_96_reg_8089_reg_7__i_1_n_0_91916af ,esc_NLW_add_ln208_96_reg_8089_reg_7__i_1_CO_UNCONNECTED_efb9c12 [2:0]} = recovered_444_co;
  assign esc_add_ln208_93_reg_8027_reg_12_0c8544f [7:4] = recovered_444_o;

  // Reconstructed LUT2: esc_add_ln208_99_reg_8131_3__i_2_2541467
  assign esc_add_ln208_99_reg_8131_3__i_2_n_0_e87eeda = ((DOADO[3]) ? (~(esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [3])) : (esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [3]));

  // Reconstructed LUT2: esc_add_ln208_99_reg_8131_3__i_3_ab8466e
  assign esc_add_ln208_99_reg_8131_3__i_3_n_0_03aec61 = ((DOADO[2]) ? (~(esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [2])) : (esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [2]));

  // Reconstructed LUT2: esc_add_ln208_99_reg_8131_3__i_4_0cf45d7
  assign esc_add_ln208_99_reg_8131_3__i_4_n_0_dea97e3 = ((DOADO[1]) ? (~(esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [1])) : (esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [1]));

  // Reconstructed LUT2: esc_add_ln208_99_reg_8131_3__i_5_ba486aa
  assign esc_add_ln208_99_reg_8131_3__i_5_n_0_d90a829 = ((DOADO[0]) ? (~(esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [0])) : (esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [0]));

  // Reconstructed LUT2: esc_add_ln208_99_reg_8131_7__i_2_6ac0a29
  assign esc_add_ln208_99_reg_8131_7__i_2_n_0_cbda796 = ((DOADO[7]) ? (~(esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [7])) : (esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [7]));

  // Reconstructed LUT2: esc_add_ln208_99_reg_8131_7__i_3_f68126c
  assign esc_add_ln208_99_reg_8131_7__i_3_n_0_c8dbe0f = ((DOADO[6]) ? (~(esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [6])) : (esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [6]));

  // Reconstructed LUT2: esc_add_ln208_99_reg_8131_7__i_4_50d32af
  assign esc_add_ln208_99_reg_8131_7__i_4_n_0_53a4daf = ((DOADO[5]) ? (~(esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [5])) : (esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [5]));

  // Reconstructed LUT2: esc_add_ln208_99_reg_8131_7__i_5_2a8f272
  assign esc_add_ln208_99_reg_8131_7__i_5_n_0_ee5b030 = ((DOADO[4]) ? (~(esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [4])) : (esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [4]));

  // Reconstructed CARRY4: esc_add_ln208_99_reg_8131_reg_11__i_1_aa3105f
  wire [3:0] recovered_453_co, recovered_453_o, recovered_453_s, recovered_453_di;
  assign recovered_453_s = esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [11:8];
  assign recovered_453_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_453_ci = ((esc_add_ln208_99_reg_8131_reg_7__i_1_n_0_25a6e02) !== 1'bz) && (esc_add_ln208_99_reg_8131_reg_7__i_1_n_0_25a6e02);
  wire recovered_453_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_453_o[0] = recovered_453_s[0] ^ (recovered_453_ci || recovered_453_cy);
  assign recovered_453_co[0] = (recovered_453_s[0] & (recovered_453_ci || recovered_453_cy)) | (~recovered_453_s[0] & recovered_453_di[0]);
  assign recovered_453_o[1] = recovered_453_s[1] ^ recovered_453_co[0];
  assign recovered_453_co[1] = (recovered_453_s[1] & recovered_453_co[0]) | (~recovered_453_s[1] & recovered_453_di[1]);
  assign recovered_453_o[2] = recovered_453_s[2] ^ recovered_453_co[1];
  assign recovered_453_co[2] = (recovered_453_s[2] & recovered_453_co[1]) | (~recovered_453_s[2] & recovered_453_di[2]);
  assign recovered_453_o[3] = recovered_453_s[3] ^ recovered_453_co[2];
  assign recovered_453_co[3] = (recovered_453_s[3] & recovered_453_co[2]) | (~recovered_453_s[3] & recovered_453_di[3]);
  assign {esc_add_ln208_99_reg_8131_reg_11__i_1_n_0_ad9b987 ,esc_NLW_add_ln208_99_reg_8131_reg_11__i_1_CO_UNCONNECTED_02acc8a [2:0]} = recovered_453_co;
  assign esc_add_ln208_96_reg_8089_reg_12_26fe0a4 [11:8] = recovered_453_o;

  // Reconstructed CARRY4: esc_add_ln208_99_reg_8131_reg_12__i_1_f740568
  wire [3:0] recovered_454_co, recovered_454_o, recovered_454_s, recovered_454_di;
  assign recovered_454_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [12]};
  assign recovered_454_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_454_ci = ((esc_add_ln208_99_reg_8131_reg_11__i_1_n_0_ad9b987) !== 1'bz) && (esc_add_ln208_99_reg_8131_reg_11__i_1_n_0_ad9b987);
  wire recovered_454_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_454_o[0] = recovered_454_s[0] ^ (recovered_454_ci || recovered_454_cy);
  assign recovered_454_co[0] = (recovered_454_s[0] & (recovered_454_ci || recovered_454_cy)) | (~recovered_454_s[0] & recovered_454_di[0]);
  assign recovered_454_o[1] = recovered_454_s[1] ^ recovered_454_co[0];
  assign recovered_454_co[1] = (recovered_454_s[1] & recovered_454_co[0]) | (~recovered_454_s[1] & recovered_454_di[1]);
  assign recovered_454_o[2] = recovered_454_s[2] ^ recovered_454_co[1];
  assign recovered_454_co[2] = (recovered_454_s[2] & recovered_454_co[1]) | (~recovered_454_s[2] & recovered_454_di[2]);
  assign recovered_454_o[3] = recovered_454_s[3] ^ recovered_454_co[2];
  assign recovered_454_co[3] = (recovered_454_s[3] & recovered_454_co[2]) | (~recovered_454_s[3] & recovered_454_di[3]);
  assign esc_add_ln208_96_reg_8089_reg_12_26fe0a4 [12] = recovered_454_o;

  // Reconstructed CARRY4: esc_add_ln208_99_reg_8131_reg_3__i_1_255a821
  wire [3:0] recovered_455_co, recovered_455_o, recovered_455_s, recovered_455_di;
  assign recovered_455_s = {esc_add_ln208_99_reg_8131_3__i_2_n_0_e87eeda ,esc_add_ln208_99_reg_8131_3__i_3_n_0_03aec61 ,esc_add_ln208_99_reg_8131_3__i_4_n_0_dea97e3 ,esc_add_ln208_99_reg_8131_3__i_5_n_0_d90a829 };
  assign recovered_455_di = esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [3:0];
  wire recovered_455_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_455_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_455_o[0] = recovered_455_s[0] ^ (recovered_455_ci || recovered_455_cy);
  assign recovered_455_co[0] = (recovered_455_s[0] & (recovered_455_ci || recovered_455_cy)) | (~recovered_455_s[0] & recovered_455_di[0]);
  assign recovered_455_o[1] = recovered_455_s[1] ^ recovered_455_co[0];
  assign recovered_455_co[1] = (recovered_455_s[1] & recovered_455_co[0]) | (~recovered_455_s[1] & recovered_455_di[1]);
  assign recovered_455_o[2] = recovered_455_s[2] ^ recovered_455_co[1];
  assign recovered_455_co[2] = (recovered_455_s[2] & recovered_455_co[1]) | (~recovered_455_s[2] & recovered_455_di[2]);
  assign recovered_455_o[3] = recovered_455_s[3] ^ recovered_455_co[2];
  assign recovered_455_co[3] = (recovered_455_s[3] & recovered_455_co[2]) | (~recovered_455_s[3] & recovered_455_di[3]);
  assign {esc_add_ln208_99_reg_8131_reg_3__i_1_n_0_d594831 ,esc_NLW_add_ln208_99_reg_8131_reg_3__i_1_CO_UNCONNECTED_636af47 [2:0]} = recovered_455_co;
  assign esc_add_ln208_96_reg_8089_reg_12_26fe0a4 [3:0] = recovered_455_o;

  // Reconstructed CARRY4: esc_add_ln208_99_reg_8131_reg_7__i_1_9f159b2
  wire [3:0] recovered_456_co, recovered_456_o, recovered_456_s, recovered_456_di;
  assign recovered_456_s = {esc_add_ln208_99_reg_8131_7__i_2_n_0_cbda796 ,esc_add_ln208_99_reg_8131_7__i_3_n_0_c8dbe0f ,esc_add_ln208_99_reg_8131_7__i_4_n_0_53a4daf ,esc_add_ln208_99_reg_8131_7__i_5_n_0_ee5b030 };
  assign recovered_456_di = esc_add_ln208_99_reg_8131_reg_12__0_1dd2b6e [7:4];
  wire recovered_456_ci = ((esc_add_ln208_99_reg_8131_reg_3__i_1_n_0_d594831) !== 1'bz) && (esc_add_ln208_99_reg_8131_reg_3__i_1_n_0_d594831);
  wire recovered_456_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_456_o[0] = recovered_456_s[0] ^ (recovered_456_ci || recovered_456_cy);
  assign recovered_456_co[0] = (recovered_456_s[0] & (recovered_456_ci || recovered_456_cy)) | (~recovered_456_s[0] & recovered_456_di[0]);
  assign recovered_456_o[1] = recovered_456_s[1] ^ recovered_456_co[0];
  assign recovered_456_co[1] = (recovered_456_s[1] & recovered_456_co[0]) | (~recovered_456_s[1] & recovered_456_di[1]);
  assign recovered_456_o[2] = recovered_456_s[2] ^ recovered_456_co[1];
  assign recovered_456_co[2] = (recovered_456_s[2] & recovered_456_co[1]) | (~recovered_456_s[2] & recovered_456_di[2]);
  assign recovered_456_o[3] = recovered_456_s[3] ^ recovered_456_co[2];
  assign recovered_456_co[3] = (recovered_456_s[3] & recovered_456_co[2]) | (~recovered_456_s[3] & recovered_456_di[3]);
  assign {esc_add_ln208_99_reg_8131_reg_7__i_1_n_0_25a6e02 ,esc_NLW_add_ln208_99_reg_8131_reg_7__i_1_CO_UNCONNECTED_239213a [2:0]} = recovered_456_co;
  assign esc_add_ln208_96_reg_8089_reg_12_26fe0a4 [7:4] = recovered_456_o;

  // Reconstructed LUT5: esc_add_ln74_reg_6855_10__i_1_ddbb7be
  assign esc_add_ln68_reg_8723_reg_2_180a5a5 [3] = ((esc_add_ln68_reg_8723_reg_4_ae92a68) ? (((esc_add_ln68_reg_8723_reg_3_d7954e8) ? (((esc_add_ln68_reg_8723_reg_1_d6e0e48) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b1) : (esc_add_ln68_reg_8723_reg_2__0_0488464))) : (esc_add_ln68_reg_8723_reg_2__0_0488464))) : (1'b0))) : (((esc_add_ln68_reg_8723_reg_3_d7954e8) ? (1'b0) : (((esc_add_ln68_reg_8723_reg_1_d6e0e48) ? (1'b0) : (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b0) : (~(esc_add_ln68_reg_8723_reg_2__0_0488464)))))))));

  // Reconstructed LUT6: esc_add_ln74_reg_6855_6__i_1_da6d022
  assign esc_add_ln68_reg_8723_reg_2_180a5a5 [0] = ((zext_ln74_2_fu_2977_p1[1]) ? (((esc_y_2_reg_2385_reg_4__0_25a3d14 [1]) ? (((esc_add_ln74_reg_6855_reg_6__2_76dcc1d) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b0) : (~(zext_ln74_2_fu_2977_p1[0])))) : (((esc_y_2_reg_2385_reg_4_1138322 [1]) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b0) : (~(zext_ln74_2_fu_2977_p1[0])))) : (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b1) : (zext_ln74_2_fu_2977_p1[0]))))))) : (((esc_add_ln74_reg_6855_reg_6__2_76dcc1d) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b1) : (zext_ln74_2_fu_2977_p1[0]))) : (((esc_y_2_reg_2385_reg_4_1138322 [1]) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b0) : (~(zext_ln74_2_fu_2977_p1[0])))) : (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b1) : (zext_ln74_2_fu_2977_p1[0]))))))))) : (((esc_y_2_reg_2385_reg_4__0_25a3d14 [1]) ? (((esc_add_ln74_reg_6855_reg_6__2_76dcc1d) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b1) : (zext_ln74_2_fu_2977_p1[0]))) : (((esc_y_2_reg_2385_reg_4_1138322 [1]) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b1) : (zext_ln74_2_fu_2977_p1[0]))) : (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b0) : (~(zext_ln74_2_fu_2977_p1[0])))))))) : (((esc_add_ln74_reg_6855_reg_6__2_76dcc1d) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b0) : (~(zext_ln74_2_fu_2977_p1[0])))) : (((esc_y_2_reg_2385_reg_4_1138322 [1]) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b1) : (zext_ln74_2_fu_2977_p1[0]))) : (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b0) : (~(zext_ln74_2_fu_2977_p1[0])))))))))));

  // Reconstructed LUT5: esc_add_ln74_reg_6855_7__i_1_3c20a3e
  assign esc_add_ln68_reg_8723_reg_2_180a5a5 [1] = ((ap_phi_mux_y_2_phi_fu_2389_p4) ? (((esc_add_ln68_reg_8723_reg_1_d6e0e48) ? (((esc_add_ln68_reg_8723_reg_2__0_0488464) ? (((esc_add_ln74_reg_6855_reg_7__2_c3111d6) ? (esc_add_ln68_reg_8723_reg_3_d7954e8) : (~(esc_add_ln68_reg_8723_reg_3_d7954e8)))) : (((esc_add_ln74_reg_6855_reg_7__2_c3111d6) ? (~(esc_add_ln68_reg_8723_reg_3_d7954e8)) : (esc_add_ln68_reg_8723_reg_3_d7954e8))))) : (((esc_add_ln68_reg_8723_reg_2__0_0488464) ? (~(esc_add_ln74_reg_6855_reg_7__2_c3111d6)) : (esc_add_ln74_reg_6855_reg_7__2_c3111d6))))) : (((esc_add_ln68_reg_8723_reg_1_d6e0e48) ? (((esc_add_ln68_reg_8723_reg_2__0_0488464) ? (((esc_add_ln74_reg_6855_reg_7__2_c3111d6) ? (esc_add_ln68_reg_8723_reg_3_d7954e8) : (~(esc_add_ln68_reg_8723_reg_3_d7954e8)))) : (esc_add_ln74_reg_6855_reg_7__2_c3111d6))) : (((esc_add_ln68_reg_8723_reg_2__0_0488464) ? (((esc_add_ln74_reg_6855_reg_7__2_c3111d6) ? (~(esc_add_ln68_reg_8723_reg_3_d7954e8)) : (esc_add_ln68_reg_8723_reg_3_d7954e8))) : (esc_add_ln74_reg_6855_reg_7__2_c3111d6))))));

  // Reconstructed LUT5: esc_add_ln74_reg_6855_9__i_1_46a745d
  assign esc_add_ln68_reg_8723_reg_2_180a5a5 [2] = ((esc_add_ln68_reg_8723_reg_4_ae92a68) ? (((esc_add_ln68_reg_8723_reg_3_d7954e8) ? (((esc_add_ln68_reg_8723_reg_1_d6e0e48) ? (((esc_add_ln68_reg_8723_reg_2__0_0488464) ? (1'b0) : (~(ap_phi_mux_y_2_phi_fu_2389_p4)))) : (~(esc_add_ln68_reg_8723_reg_2__0_0488464)))) : (1'b1))) : (((esc_add_ln68_reg_8723_reg_3_d7954e8) ? (((esc_add_ln68_reg_8723_reg_1_d6e0e48) ? (esc_add_ln68_reg_8723_reg_2__0_0488464) : (1'b0))) : (1'b0))));

  // Reconstructed LUT2: esc_edge_counts_addr_1_reg_6833_3__i_1_f400a92
  assign D = ((esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc [3]) ? (~(Q)) : (Q));

  RAMB18E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(18'h00000),
    .INIT_B(18'h00000),
    .INIT_FILE("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("PERFORMANCE"),
    .READ_WIDTH_A(9),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(18'h00000),
    .SRVAL_B(18'h00000),
    .WRITE_MODE_A("READ_FIRST"),
    .WRITE_MODE_B("WRITE_FIRST"),
    .WRITE_WIDTH_A(9),
    .WRITE_WIDTH_B(0)) 
    ram0_reg
       (.ADDRARDADDR({ram0_reg_i_2__0_n_0,ram0_reg_i_3__0_n_0,ram0_reg_i_4__0_n_0,ram0_reg_i_5__0_n_0,ram0_reg_i_6__0_n_0,ram0_reg_i_7__0_n_0,ram0_reg_i_8__0_n_0,ram0_reg_i_9_n_0,ram0_reg_i_10__0_n_0,ram0_reg_i_11__0_n_0,ram0_reg_i_12__0_n_0,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .ADDRBWRADDR({esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .CLKARDCLK(ap_clk),
        .CLKBWRCLK(esc_const0_a0cf646 ),
        .DIADI({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,edge_counts_d0[7],ram0_reg_i_14__0_n_0,edge_counts_d0[5:0]}),
        .DIBDI({esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .DIPADIP({esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .DIPBDIP({esc_const1_c064970 ,esc_const1_c064970 }),
        .DOADO(DOADO),
        .ENARDEN(edge_counts_ce0),
        .ENBWREN(esc_const0_a0cf646 ),
        .REGCEAREGCE(esc_const0_a0cf646 ),
        .REGCEB(esc_const0_a0cf646 ),
        .RSTRAMARSTRAM(esc_const0_a0cf646 ),
        .RSTRAMB(esc_const0_a0cf646 ),
        .RSTREGARSTREG(esc_const0_a0cf646 ),
        .RSTREGB(esc_const0_a0cf646 ),
        .WEA({GND_2,WEA}),
        .WEBWE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }));

  // Reconstructed LUT6: ram0_reg_i_100
  assign ram0_reg_i_100_n_0 = ((ram0_reg_4[2]) ? (((ram0_reg_4[1]) ? (((ram0_reg_4[0]) ? (((mul_ln215_reg_6908[0]) ? (((mul_ln215_reg_6908[1]) ? (1'b0) : (~(ram0_reg_i_86_n_0)))) : (~(ram0_reg_i_86_n_0)))) : (~(ram0_reg_i_86_n_0)))) : (~(ram0_reg_i_86_n_0)))) : (((ram0_reg_4[1]) ? (((ram0_reg_4[0]) ? (((mul_ln215_reg_6908[0]) ? (((mul_ln215_reg_6908[1]) ? (~(ram0_reg_i_86_n_0)) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: ram0_reg_i_101
  assign esc_ap_CS_fsm_reg_17__0_3991a9e = ((ram0_reg_15) ? (((ram0_reg_6[3]) ? (((ram0_reg_6[4]) ? (1'b1) : (((ram0_reg_6[5]) ? (1'b1) : (~(ram0_reg_5)))))) : (1'b1))) : (1'b1));

  // Reconstructed LUT6: ram0_reg_i_102
  assign esc_ap_CS_fsm_reg_19_bd70f8c = ((ram0_reg_6[5]) ? (~(ram0_reg_21)) : (((ram0_reg_6[4]) ? (~(ram0_reg_21)) : (((ram0_reg_21) ? (((ram0_reg_6[6]) ? (1'b0) : (((ram0_reg_6[8]) ? (1'b0) : (~(ram0_reg_6[7])))))) : (1'b1))))));

  // Reconstructed LUT2: ram0_reg_i_107
  assign ram0_reg_i_107_n_0 = ((ram0_reg_4[0]) ? (mul_ln215_reg_6908[1]) : (1'b0));

  // Reconstructed CARRY4: ram0_reg_i_108
  wire [3:0] recovered_467_co, recovered_467_o, recovered_467_s, recovered_467_di;
  assign recovered_467_s = {ram0_reg_i_152_n_0,ram0_reg_i_153_n_0,ram0_reg_i_154_n_0,ram0_reg_i_108_1[2]};
  assign recovered_467_di = {ram0_reg_i_108_0[0],ram0_reg_i_108_1[4:3],esc_const0_a0cf646 };
  wire recovered_467_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_467_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_467_o[0] = recovered_467_s[0] ^ (recovered_467_ci || recovered_467_cy);
  assign recovered_467_co[0] = (recovered_467_s[0] & (recovered_467_ci || recovered_467_cy)) | (~recovered_467_s[0] & recovered_467_di[0]);
  assign recovered_467_o[1] = recovered_467_s[1] ^ recovered_467_co[0];
  assign recovered_467_co[1] = (recovered_467_s[1] & recovered_467_co[0]) | (~recovered_467_s[1] & recovered_467_di[1]);
  assign recovered_467_o[2] = recovered_467_s[2] ^ recovered_467_co[1];
  assign recovered_467_co[2] = (recovered_467_s[2] & recovered_467_co[1]) | (~recovered_467_s[2] & recovered_467_di[2]);
  assign recovered_467_o[3] = recovered_467_s[3] ^ recovered_467_co[2];
  assign recovered_467_co[3] = (recovered_467_s[3] & recovered_467_co[2]) | (~recovered_467_s[3] & recovered_467_di[3]);
  assign {CO,NLW_ram0_reg_i_108_CO_UNCONNECTED[2:0]} = recovered_467_co;
  assign data42 = recovered_467_o;

  // Reconstructed LUT6: ram0_reg_i_109
  assign ram0_reg_i_109_n_0 = ((mul_ln215_reg_6908[0]) ? (((ram0_reg_31) ? (((esc_ap_CS_fsm_reg_26_bc9d1aa) ? (((ram0_reg_i_123_n_0) ? (((mul_ln215_reg_6908[1]) ? (~(ram0_reg_i_124_n_0)) : (1'b1))) : (1'b1))) : (((ram0_reg_i_123_n_0) ? (~(ram0_reg_i_124_n_0)) : (((mul_ln215_reg_6908[1]) ? (1'b1) : (~(ram0_reg_i_124_n_0)))))))) : (((ram0_reg_i_123_n_0) ? (~(ram0_reg_i_124_n_0)) : (((mul_ln215_reg_6908[1]) ? (1'b1) : (~(ram0_reg_i_124_n_0)))))))) : (((ram0_reg_31) ? (((esc_ap_CS_fsm_reg_26_bc9d1aa) ? (((ram0_reg_i_123_n_0) ? (((mul_ln215_reg_6908[1]) ? (~(ram0_reg_i_124_n_0)) : (1'b1))) : (1'b1))) : (((mul_ln215_reg_6908[1]) ? (~(ram0_reg_i_124_n_0)) : (1'b1))))) : (((mul_ln215_reg_6908[1]) ? (~(ram0_reg_i_124_n_0)) : (1'b1))))));

  // Reconstructed LUT6: ram0_reg_i_10__0
  assign ram0_reg_i_10__0_n_0 = ((ap_enable_reg_pp3_iter0_reg_rep__2) ? (((ap_enable_reg_pp3_iter0_reg_rep) ? (((ram0_reg_i_31_n_0) ? (1'b1) : (((ram0_reg_19) ? (1'b1) : (((esc_ap_CS_fsm_reg_35_69cfbc2) ? (ap_enable_reg_pp3_iter0_reg_rep__2_1) : (1'b1))))))) : (((esc_ap_CS_fsm_reg_35_69cfbc2) ? (ap_enable_reg_pp3_iter0_reg_rep__2_1) : (1'b1))))) : (ap_enable_reg_pp3_iter0_reg_rep__2_1));

  // Reconstructed LUT6: ram0_reg_i_110
  assign esc_ap_CS_fsm_reg_35__0_74dd3b9 = ((ram0_reg_i_53) ? (((ram0_reg_6[22]) ? (((ram0_reg_30) ? (~(ram0_reg_15)) : (1'b0))) : (((ram0_reg_6[21]) ? (((ram0_reg_30) ? (~(ram0_reg_15)) : (1'b0))) : (((ram0_reg_30) ? (((ram0_reg_15) ? (~(ram0_reg_6[23])) : (1'b1))) : (1'b0))))))) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_111
  assign ram0_reg_i_111_n_0 = ((esc_y_2_reg_2385_reg_4__0_25a3d14 [1]) ? (((ram0_reg_i_49_0) ? (((esc_y_2_reg_2385_reg_3_172fc4c) ? (((esc_y_2_reg_2385_reg_4_1138322 [1]) ? (~(esc_y_2_reg_2385_reg_4_1138322 [0])) : (esc_y_2_reg_2385_reg_4_1138322 [0]))) : (~(esc_y_2_reg_2385_reg_4__0_25a3d14 [0])))) : (((esc_y_2_reg_2385_reg_4_1138322 [1]) ? (~(esc_y_2_reg_2385_reg_4_1138322 [0])) : (esc_y_2_reg_2385_reg_4_1138322 [0]))))) : (((ram0_reg_i_49_0) ? (((esc_y_2_reg_2385_reg_3_172fc4c) ? (((esc_y_2_reg_2385_reg_4_1138322 [1]) ? (~(esc_y_2_reg_2385_reg_4_1138322 [0])) : (esc_y_2_reg_2385_reg_4_1138322 [0]))) : (esc_y_2_reg_2385_reg_4__0_25a3d14 [0]))) : (((esc_y_2_reg_2385_reg_4_1138322 [1]) ? (~(esc_y_2_reg_2385_reg_4_1138322 [0])) : (esc_y_2_reg_2385_reg_4_1138322 [0]))))));

  // Reconstructed LUT3: ram0_reg_i_117
  assign esc_ap_CS_fsm_reg_46_ba5f378 = ((ram0_reg_6[30]) ? (1'b0) : (((ram0_reg_6[32]) ? (1'b0) : (~(ram0_reg_6[31])))));

  // Reconstructed LUT5: ram0_reg_i_119
  assign esc_ap_CS_fsm_reg_54_3d44ae7 = ((ram0_reg_6[36]) ? (~(ram_reg_i_373__0)) : (((ram0_reg_6[37]) ? (~(ram_reg_i_373__0)) : (((ram_reg_i_373__0) ? (((ram0_reg_6[38]) ? (1'b0) : (~(ram0_reg_6[39])))) : (1'b1))))));

  // Reconstructed LUT6: ram0_reg_i_11__0
  assign ram0_reg_i_11__0_n_0 = ((ap_enable_reg_pp3_iter0_reg_rep__2) ? (((ap_enable_reg_pp3_iter0_reg_rep) ? (((ram0_reg_i_32__0_n_0) ? (1'b1) : (((ap_enable_reg_pp3_iter0_reg_0) ? (((esc_ap_CS_fsm_reg_21_af57a65) ? (ap_enable_reg_pp3_iter0_reg) : (1'b1))) : (1'b1))))) : (((esc_ap_CS_fsm_reg_21_af57a65) ? (ap_enable_reg_pp3_iter0_reg) : (1'b1))))) : (ap_enable_reg_pp3_iter0_reg));

  // Reconstructed LUT5: ram0_reg_i_123
  assign ram0_reg_i_123_n_0 = ((ram0_reg_6[11]) ? (1'b0) : (((ram0_reg_22) ? (((ram0_reg_6[10]) ? (~(ram0_reg_26)) : (((ram0_reg_6[9]) ? (~(ram0_reg_26)) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT5: ram0_reg_i_124
  assign ram0_reg_i_124_n_0 = ((ram0_reg_6[18]) ? (((ram0_reg_22) ? (1'b0) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (1'b0) : (((ram0_reg_32) ? (ram0_reg_26) : (1'b1))))))) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (1'b0) : (((ram0_reg_32) ? (ram0_reg_26) : (1'b1))))));

  // Reconstructed LUT6: ram0_reg_i_125
  assign esc_ap_CS_fsm_reg_29_d9f5eab = ((ram0_reg_6[15]) ? (((ram0_reg_22) ? (~(ram0_reg_6[17])) : (1'b1))) : (((ram0_reg_6[16]) ? (((ram0_reg_22) ? (~(ram0_reg_6[17])) : (1'b1))) : (((ram0_reg_22) ? (((ram0_reg_6[14]) ? (1'b0) : (((ram0_reg_6[13]) ? (1'b0) : (~(ram0_reg_6[17])))))) : (1'b1))))));

  // Reconstructed LUT6: ram0_reg_i_126
  assign ram0_reg_i_126_n_0 = ((ram0_reg_15) ? (((ram0_reg_6[24]) ? (((ram0_reg_6[25]) ? (1'b1) : (ram0_reg_6[26]))) : (((ram0_reg_6[23]) ? (((ram0_reg_6[25]) ? (1'b1) : (ram0_reg_6[26]))) : (((esc_ap_CS_fsm_reg_33_3728c13) ? (1'b1) : (((ram0_reg_6[25]) ? (1'b1) : (ram0_reg_6[26]))))))))) : (((ram0_reg_6[23]) ? (1'b0) : (esc_ap_CS_fsm_reg_33_3728c13))));

  // Reconstructed LUT6: ram0_reg_i_127
  assign ram0_reg_i_127_n_0 = ((ram0_reg_i_62_1) ? (ram0_reg_i_81_n_0) : (((ram0_reg_13) ? (ram0_reg_i_81_n_0) : (((ram0_reg_12) ? (ram0_reg_i_81_n_0) : (((ram0_reg_i_157_n_0) ? (1'b0) : (((ram0_reg_i_62_0) ? (ram0_reg_i_81_n_0) : (1'b0))))))))));

  // Reconstructed LUT6: ram0_reg_i_12__0
  assign ram0_reg_i_12__0_n_0 = ((ap_enable_reg_pp3_iter0_reg_rep__2) ? (((ap_enable_reg_pp3_iter0_reg_rep) ? (((ram0_reg_i_33__0_n_0) ? (1'b1) : (((esc_ap_CS_fsm_reg_16_2d815ec) ? (((ap_enable_reg_pp3_iter0_reg_rep_0) ? (esc_ap_CS_fsm_reg_48_486bf78) : (1'b1))) : (1'b1))))) : (((ap_enable_reg_pp3_iter0_reg_rep_0) ? (esc_ap_CS_fsm_reg_48_486bf78) : (1'b1))))) : (esc_ap_CS_fsm_reg_48_486bf78));

  // Reconstructed LUT6: ram0_reg_i_131
  assign ram0_reg_i_131_n_0 = ((ram0_reg_i_63_2) ? (((ram0_reg_30) ? (1'b1) : (((ram0_reg_i_63_1) ? (1'b1) : (((ram0_reg_i_63_0) ? (1'b1) : (((ram0_reg_i_161_n_0) ? (~(ram0_reg_i_160_n_0)) : (1'b0))))))))) : (((ram0_reg_i_63_1) ? (1'b1) : (((ram0_reg_i_63_0) ? (1'b1) : (((ram0_reg_i_161_n_0) ? (~(ram0_reg_i_160_n_0)) : (1'b0))))))));

  // Reconstructed LUT6: ram0_reg_i_132
  assign ram0_reg_i_132_n_0 = ((ram0_reg_i_66_3) ? (((ram0_reg_i_157_n_0) ? (((ram0_reg_12) ? (1'b0) : (((ram0_reg_i_66_2) ? (1'b1) : (((ram0_reg_i_66_1) ? (1'b0) : (~(ram0_reg_i_66_0)))))))) : (1'b0))) : (((ram0_reg_12) ? (1'b0) : (((ram0_reg_i_66_2) ? (1'b1) : (((ram0_reg_i_66_1) ? (1'b0) : (~(ram0_reg_i_66_0)))))))));

  // Reconstructed LUT4: ram0_reg_i_135
  assign ram0_reg_i_135_n_0 = ((ram0_reg_6[33]) ? (((ram0_reg_i_131_0) ? (((ram0_reg_6[34]) ? (~(ram0_reg_6[35])) : (1'b0))) : (1'b1))) : (((ram0_reg_i_131_0) ? (~(ram0_reg_6[35])) : (1'b1))));

  // Reconstructed LUT5: ram0_reg_i_13__0
  assign edge_counts_d0[7] = ((ram0_reg_24[7]) ? (((ram0_reg_i_34__0_n_0) ? (((ram0_reg_24[6]) ? (1'b0) : (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))))) : (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))))) : (((ram0_reg_i_34__0_n_0) ? (((ram0_reg_24[6]) ? (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT3: ram0_reg_i_141
  assign esc_ap_CS_fsm_reg_33_3728c13 = ((ram0_reg_22) ? (((ram0_reg_6[22]) ? (1'b1) : (ram0_reg_6[21]))) : (1'b0));

  // Reconstructed LUT5: ram0_reg_i_146
  assign esc_ap_CS_fsm_reg_26_bc9d1aa = ((ram0_reg_6[11]) ? (~(ram0_reg_22)) : (((ram0_reg_6[12]) ? (~(ram0_reg_22)) : (((ram0_reg_22) ? (((ram0_reg_6[13]) ? (1'b0) : (~(ram0_reg_6[14])))) : (1'b1))))));

  // Reconstructed LUT4: ram0_reg_i_14__0
  assign ram0_reg_i_14__0_n_0 = ((ram0_reg_23) ? (((ram0_reg_6[1]) ? (((ram0_reg_24[6]) ? (~(ram0_reg_i_34__0_n_0)) : (ram0_reg_i_34__0_n_0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT3: ram0_reg_i_152
  assign ram0_reg_i_152_n_0 = ((ram0_reg_i_108_0[0]) ? (((ram0_reg_i_108_0[2]) ? (ram0_reg_i_108_1[5]) : (~(ram0_reg_i_108_1[5])))) : (((ram0_reg_i_108_0[2]) ? (~(ram0_reg_i_108_1[5])) : (ram0_reg_i_108_1[5]))));

  // Reconstructed LUT2: ram0_reg_i_153
  assign ram0_reg_i_153_n_0 = ((ram0_reg_i_108_0[1]) ? (~(ram0_reg_i_108_1[4])) : (ram0_reg_i_108_1[4]));

  // Reconstructed LUT2: ram0_reg_i_154
  assign ram0_reg_i_154_n_0 = ((ram0_reg_i_108_0[0]) ? (~(ram0_reg_i_108_1[3])) : (ram0_reg_i_108_1[3]));

  // Reconstructed LUT6: ram0_reg_i_157
  assign ram0_reg_i_157_n_0 = ((ram0_reg_6[29]) ? (ram0_reg_22) : (((ram0_reg_6[27]) ? (ram0_reg_22) : (((ram0_reg_6[28]) ? (ram0_reg_22) : (((ram0_reg_6[30]) ? (ram0_reg_22) : (((ram0_reg_16) ? (1'b0) : (ram0_reg_22))))))))));

  // Reconstructed LUT4: ram0_reg_i_15__0
  assign edge_counts_d0[5] = ((ram0_reg_24[5]) ? (((ram0_reg_i_35__0_n_0) ? (1'b0) : (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))))) : (((ram0_reg_i_35__0_n_0) ? (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: ram0_reg_i_160
  assign ram0_reg_i_160_n_0 = ((ram0_reg_6[18]) ? (((ram0_reg_22) ? (((ram0_reg_6[19]) ? (~(ram0_reg_6[20])) : (1'b0))) : (1'b1))) : (((ram0_reg_22) ? (~(ram0_reg_6[20])) : (1'b1))));

  // Reconstructed LUT5: ram0_reg_i_161
  assign ram0_reg_i_161_n_0 = ((ram0_reg_6[23]) ? (((ram0_reg_i_131_0) ? (1'b0) : (ram0_reg_30))) : (((ram0_reg_i_131_0) ? (((ram0_reg_30) ? (((ram0_reg_6[21]) ? (1'b0) : (~(ram0_reg_6[22])))) : (1'b0))) : (ram0_reg_30))));

  // Reconstructed LUT6: ram0_reg_i_16__0
  assign edge_counts_d0[4] = ((ram0_reg_24[4]) ? (((ram0_reg_24[3]) ? (((ram0_reg_24[0]) ? (((ram0_reg_24[1]) ? (((ram0_reg_24[2]) ? (1'b0) : (ap_enable_reg_pp1_iter1_reg))) : (ap_enable_reg_pp1_iter1_reg))) : (ap_enable_reg_pp1_iter1_reg))) : (ap_enable_reg_pp1_iter1_reg))) : (((ram0_reg_24[3]) ? (((ram0_reg_24[0]) ? (((ram0_reg_24[1]) ? (((ram0_reg_24[2]) ? (ap_enable_reg_pp1_iter1_reg) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: ram0_reg_i_17__0
  assign edge_counts_d0[3] = ((ram0_reg_24[3]) ? (((ram0_reg_24[2]) ? (((ram0_reg_24[1]) ? (((ram0_reg_24[0]) ? (1'b0) : (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))))) : (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))))) : (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))))) : (((ram0_reg_24[2]) ? (((ram0_reg_24[1]) ? (((ram0_reg_24[0]) ? (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: ram0_reg_i_18__0
  assign edge_counts_d0[2] = ((ram0_reg_24[2]) ? (((ram0_reg_24[0]) ? (((ram0_reg_24[1]) ? (1'b0) : (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))))) : (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))))) : (((ram0_reg_24[0]) ? (((ram0_reg_24[1]) ? (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: ram0_reg_i_19__0
  assign edge_counts_d0[1] = ((ram0_reg_24[1]) ? (((ram0_reg_24[0]) ? (1'b0) : (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))))) : (((ram0_reg_24[0]) ? (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))) : (1'b0))));

  // Reconstructed LUT3: ram0_reg_i_20__0
  assign edge_counts_d0[0] = ((ram0_reg_24[0]) ? (1'b0) : (((ram0_reg_23) ? (ram0_reg_6[1]) : (1'b0))));

  // Reconstructed LUT5: ram0_reg_i_22
  assign esc_ap_CS_fsm_reg_1_637b98d = ((ap_enable_reg_pp3_iter0) ? (((ram0_reg_6[3]) ? (1'b1) : (((ap_enable_reg_pp0_iter1) ? (((ram0_reg_6[0]) ? (1'b1) : (ram0_reg_20))) : (ram0_reg_20))))) : (((ap_enable_reg_pp0_iter1) ? (((ram0_reg_6[0]) ? (1'b1) : (ram0_reg_20))) : (ram0_reg_20))));

  // Reconstructed LUT2: ram0_reg_i_22__0
  assign ap_enable_reg_pp1_iter1_reg = ((ram0_reg_6[1]) ? (ram0_reg_23) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_23__0
  assign ram0_reg_i_23__0_n_0 = ((esc_add_ln74_reg_6855_reg_10__0_d3d73fa) ? (((esc_ap_CS_fsm_reg_17_dedac0c) ? (((ram0_reg_i_37_n_0) ? (((ram0_reg_4[5]) ? (((ram0_reg_5) ? (1'b0) : (ap_enable_reg_pp3_iter0_reg_rep))) : (1'b0))) : (ap_enable_reg_pp3_iter0_reg_rep))) : (((ram0_reg_4[5]) ? (((ram0_reg_5) ? (1'b0) : (ap_enable_reg_pp3_iter0_reg_rep))) : (1'b0))))) : (ap_enable_reg_pp3_iter0_reg_rep));

  // Reconstructed LUT6: ram0_reg_i_24
  assign ram0_reg_i_24_n_0 = ((esc_add_ln74_reg_6855_reg_9__1_9d031f6) ? (((esc_ap_CS_fsm_reg_17_dedac0c) ? (((ram0_reg_i_38__0_n_0) ? (((ram0_reg_4[4]) ? (((ram0_reg_5) ? (1'b0) : (ap_enable_reg_pp3_iter0_reg_rep))) : (1'b0))) : (ap_enable_reg_pp3_iter0_reg_rep))) : (((ram0_reg_4[4]) ? (((ram0_reg_5) ? (1'b0) : (ap_enable_reg_pp3_iter0_reg_rep))) : (1'b0))))) : (ap_enable_reg_pp3_iter0_reg_rep));

  // Reconstructed LUT6: ram0_reg_i_24__0
  assign esc_mul_ln215_reg_6908_reg_1_09f3be8 = ((ram0_reg_i_73_n_0) ? (1'b0) : (((ram0_reg_4[5]) ? (((mul_ln215_reg_6908[1]) ? (((ram0_reg_i_72_n_0) ? (~(esc_ap_CS_fsm_reg_23_edf6f2f)) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (1'b0) : (~(esc_ap_CS_fsm_reg_23_edf6f2f)))))) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (1'b0) : (~(esc_ap_CS_fsm_reg_23_edf6f2f)))))) : (((mul_ln215_reg_6908[1]) ? (((ram0_reg_i_72_n_0) ? (~(esc_ap_CS_fsm_reg_35__1_673f736)) : (1'b1))) : (1'b1))))));

  // Reconstructed LUT6: ram0_reg_i_25__0
  assign ram0_reg_i_25__0_n_0 = ((esc_add_ln74_reg_6855_reg_8__1_c9f6290) ? (((esc_ap_CS_fsm_reg_17_dedac0c) ? (((ram0_reg_i_39__0_n_0) ? (((ram0_reg_4[3]) ? (((ram0_reg_5) ? (1'b0) : (ap_enable_reg_pp3_iter0_reg_rep))) : (1'b0))) : (ap_enable_reg_pp3_iter0_reg_rep))) : (((ram0_reg_4[3]) ? (((ram0_reg_5) ? (1'b0) : (ap_enable_reg_pp3_iter0_reg_rep))) : (1'b0))))) : (ap_enable_reg_pp3_iter0_reg_rep));

  // Reconstructed LUT6: ram0_reg_i_26
  assign ap_enable_reg_pp3_iter0_reg_rep__2 = ((ram0_reg_i_81_n_0) ? (((ram0_reg_18) ? (((ram0_reg_17) ? (((ram0_reg_6[30]) ? (~(ram0_reg_15)) : (((ram0_reg_16) ? (1'b1) : (~(ram0_reg_15)))))) : (~(ram0_reg_15)))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_26__0
  assign ram0_reg_i_26__0_n_0 = ((ram0_reg_i_23__0_1[3]) ? (((ap_enable_reg_pp1_iter0_reg) ? (((ram0_reg_i_23__0_0[7]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))))) : (((ram0_reg_i_23__0_2[1]) ? (((ram0_reg_i_23__0_0[7]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))))) : (((ram0_reg_i_23__0_0[7]) ? (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (1'b0))))))) : (((ap_enable_reg_pp1_iter0_reg) ? (((ram0_reg_i_23__0_0[7]) ? (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (1'b0))) : (((ram0_reg_i_23__0_2[1]) ? (((ram0_reg_i_23__0_0[7]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))))) : (((ram0_reg_i_23__0_0[7]) ? (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT6: ram0_reg_i_27
  assign esc_add_ln74_reg_6855_reg_10_52d2cb4 = ((mul_ln215_reg_6908[0]) ? (((ram0_reg_i_83_n_0) ? (((esc_ap_CS_fsm_reg_48__0_0aa522c) ? (1'b0) : (((ram0_reg_i_72_n_0) ? (~(ram0_reg_4[5])) : (ram0_reg_4[5]))))) : (((ram0_reg_i_72_n_0) ? (~(ram0_reg_4[5])) : (ram0_reg_4[5]))))) : (((mul_ln215_reg_6908[1]) ? (((ram0_reg_i_83_n_0) ? (((esc_ap_CS_fsm_reg_48__0_0aa522c) ? (1'b0) : (((ram0_reg_i_72_n_0) ? (~(ram0_reg_4[5])) : (ram0_reg_4[5]))))) : (((ram0_reg_i_72_n_0) ? (~(ram0_reg_4[5])) : (ram0_reg_4[5]))))) : (((ram0_reg_i_83_n_0) ? (((esc_ap_CS_fsm_reg_48__0_0aa522c) ? (1'b0) : (((ram0_reg_i_72_n_0) ? (~(ram0_reg_4[5])) : (ram0_reg_4[5]))))) : (((esc_ap_CS_fsm_reg_48__0_0aa522c) ? (ram0_reg_4[5]) : (((ram0_reg_i_72_n_0) ? (~(ram0_reg_4[5])) : (ram0_reg_4[5]))))))))));

  // Reconstructed LUT6: ram0_reg_i_27__0
  assign ram0_reg_i_27__0_n_0 = ((ram0_reg_i_23__0_0[6]) ? (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ram0_reg_i_23__0_2[0]) ? (((ram0_reg_i_23__0_1[2]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter0_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))))) : (((ram0_reg_i_23__0_1[2]) ? (((ap_enable_reg_pp1_iter0_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (1'b0))))))) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (((ram0_reg_i_23__0_2[0]) ? (((ram0_reg_i_23__0_1[2]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter0_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))))) : (((ram0_reg_i_23__0_1[2]) ? (((ap_enable_reg_pp1_iter0_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT6: ram0_reg_i_28
  assign ram0_reg_i_28_n_0 = ((ram0_reg_i_23__0_0[5]) ? (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((data42[3]) ? (((ram0_reg_i_23__0_1[1]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter0_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))))) : (((ram0_reg_i_23__0_1[1]) ? (((ap_enable_reg_pp1_iter0_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (1'b0))))))) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (((data42[3]) ? (((ram0_reg_i_23__0_1[1]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter0_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))))) : (((ram0_reg_i_23__0_1[1]) ? (((ap_enable_reg_pp1_iter0_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT6: ram0_reg_i_28__0
  assign esc_add_ln74_reg_6855_reg_9__0_2980795 = ((ram0_reg_4[4]) ? (((ram0_reg_i_88_n_0) ? (((ram0_reg_25) ? (((ram0_reg_i_85_n_0) ? (1'b0) : (ram0_reg_i_84_n_0))) : (((ram0_reg_i_86_n_0) ? (((ram0_reg_i_85_n_0) ? (1'b0) : (ram0_reg_i_84_n_0))) : (1'b0))))) : (((ram0_reg_i_86_n_0) ? (((ram0_reg_i_85_n_0) ? (1'b0) : (ram0_reg_i_84_n_0))) : (1'b0))))) : (((ram0_reg_i_88_n_0) ? (((ram0_reg_25) ? (((ram0_reg_i_86_n_0) ? (~(ram0_reg_i_85_n_0)) : (1'b0))) : (~(ram0_reg_i_85_n_0)))) : (~(ram0_reg_i_85_n_0)))));

  // Reconstructed LUT6: ram0_reg_i_29__0
  assign ram0_reg_i_29__0_n_0 = ((ram0_reg_i_23__0_0[4]) ? (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((data42[2]) ? (((ram0_reg_i_23__0_1[0]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter0_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))))) : (((ram0_reg_i_23__0_1[0]) ? (((ap_enable_reg_pp1_iter0_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (1'b0))))))) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (((data42[2]) ? (((ram0_reg_i_23__0_1[0]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter0_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))))) : (((ram0_reg_i_23__0_1[0]) ? (((ap_enable_reg_pp1_iter0_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT4: ram0_reg_i_2__0
  assign ram0_reg_i_2__0_n_0 = ((ap_enable_reg_pp3_iter0_reg_rep__2) ? (((ram0_reg_i_23__0_n_0) ? (1'b1) : (((esc_mul_ln215_reg_6908_reg_1_09f3be8) ? (esc_add_ln74_reg_6855_reg_10_52d2cb4) : (1'b1))))) : (esc_add_ln74_reg_6855_reg_10_52d2cb4));

  // Reconstructed LUT6: ram0_reg_i_30
  assign ram0_reg_i_30_n_0 = ((ram0_reg_i_23__0_0[3]) ? (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((data42[1]) ? (((D) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter0_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))))) : (((D) ? (((ap_enable_reg_pp1_iter0_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (1'b0))))))) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (((data42[1]) ? (((D) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter0_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))))) : (((D) ? (((ap_enable_reg_pp1_iter0_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT6: ram0_reg_i_30__0
  assign esc_add_ln74_reg_6855_reg_9_9c8c6ed = ((ap_enable_reg_pp3_iter0_reg_rep__2_0) ? (((ram0_reg_i_88_n_0) ? (((mul_ln215_reg_6908[1]) ? (~(ram0_reg_4[4])) : (((mul_ln215_reg_6908[0]) ? (~(ram0_reg_4[4])) : (((ram0_reg_4[4]) ? (1'b1) : (~(esc_ap_CS_fsm_reg_48__0_0aa522c)))))))) : (ram0_reg_4[4]))) : (((ram0_reg_i_88_n_0) ? (((ram0_reg_4[4]) ? (1'b0) : (~(esc_ap_CS_fsm_reg_48__0_0aa522c)))) : (((ram0_reg_4[4]) ? (~(esc_ap_CS_fsm_reg_48__0_0aa522c)) : (1'b0))))));

  // Reconstructed LUT6: ram0_reg_i_31
  assign ram0_reg_i_31_n_0 = ((ram0_reg_i_23__0_0[2]) ? (((esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc [2]) ? (((ap_enable_reg_pp1_iter0_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((data42[0]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))))))) : (((ap_enable_reg_pp1_iter0_reg) ? (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (((data42[0]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))))))))) : (((esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc [2]) ? (((ap_enable_reg_pp1_iter0_reg) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))) : (((data42[0]) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))) : (1'b0))))) : (((ap_enable_reg_pp1_iter0_reg) ? (1'b0) : (((data42[0]) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))) : (1'b0))))))));

  // Reconstructed LUT6: ram0_reg_i_31__0
  assign esc_add_ln74_reg_6855_reg_8__0_dab2ff8 = ((ram0_reg_i_93_n_0) ? (1'b0) : (((esc_ap_CS_fsm_reg_23_edf6f2f) ? (((esc_ap_CS_fsm_reg_35__1_673f736) ? (((mul_ln215_reg_6908[1]) ? (((ram0_reg_i_92_n_0) ? (1'b0) : (~(ram0_reg_4[3])))) : (~(ram0_reg_4[3])))) : (~(ram0_reg_4[3])))) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (((mul_ln215_reg_6908[1]) ? (((ram0_reg_i_92_n_0) ? (ram0_reg_4[3]) : (~(ram0_reg_4[3])))) : (~(ram0_reg_4[3])))) : (1'b1))))));

  // Reconstructed LUT6: ram0_reg_i_32__0
  assign ram0_reg_i_32__0_n_0 = ((ram0_reg_i_23__0_0[1]) ? (((esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc [1]) ? (((ap_enable_reg_pp1_iter0_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ram0_reg_i_108_1[1]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))))))) : (((ap_enable_reg_pp1_iter0_reg) ? (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (((ram0_reg_i_108_1[1]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))))))))) : (((esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc [1]) ? (((ap_enable_reg_pp1_iter0_reg) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))) : (((ram0_reg_i_108_1[1]) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))) : (1'b0))))) : (((ap_enable_reg_pp1_iter0_reg) ? (1'b0) : (((ram0_reg_i_108_1[1]) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))) : (1'b0))))))));

  // Reconstructed LUT6: ram0_reg_i_33
  assign esc_add_ln74_reg_6855_reg_8_0e33662 = ((ap_enable_reg_pp3_iter0_reg_rep__2_0) ? (((ram0_reg_14) ? (((ram0_reg_i_96_n_0) ? (((ram0_reg_4[2]) ? (((ram0_reg_4[3]) ? (1'b1) : (~(esc_ap_CS_fsm_reg_48__0_0aa522c)))) : (ram0_reg_4[3]))) : (ram0_reg_4[3]))) : (((ram0_reg_i_96_n_0) ? (((ram0_reg_4[2]) ? (~(ram0_reg_4[3])) : (ram0_reg_4[3]))) : (ram0_reg_4[3]))))) : (((ram0_reg_i_96_n_0) ? (((ram0_reg_4[2]) ? (((ram0_reg_4[3]) ? (1'b0) : (~(esc_ap_CS_fsm_reg_48__0_0aa522c)))) : (((ram0_reg_4[3]) ? (~(esc_ap_CS_fsm_reg_48__0_0aa522c)) : (1'b0))))) : (((ram0_reg_4[3]) ? (~(esc_ap_CS_fsm_reg_48__0_0aa522c)) : (1'b0))))));

  // Reconstructed LUT6: ram0_reg_i_33__0
  assign ram0_reg_i_33__0_n_0 = ((ram0_reg_i_23__0_0[0]) ? (((esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc [0]) ? (((ap_enable_reg_pp1_iter0_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ram0_reg_i_108_1[0]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))))))) : (((ap_enable_reg_pp1_iter0_reg) ? (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))) : (((ram0_reg_i_108_1[0]) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (((ap_enable_reg_pp1_iter1_reg) ? (esc_ap_CS_fsm_reg_17_dedac0c) : (1'b0))))))))) : (((esc_edge_counts_addr_1_reg_6833_reg_3_4c015fc [0]) ? (((ap_enable_reg_pp1_iter0_reg) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))) : (((ram0_reg_i_108_1[0]) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))) : (1'b0))))) : (((ap_enable_reg_pp1_iter0_reg) ? (1'b0) : (((ram0_reg_i_108_1[0]) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (esc_ap_CS_fsm_reg_17_dedac0c))) : (1'b0))))))));

  // Reconstructed LUT6: ram0_reg_i_34
  assign esc_add_ln74_reg_6855_reg_7__0_abb43a8 = ((ram0_reg_i_100_n_0) ? (1'b0) : (((esc_ap_CS_fsm_reg_23_edf6f2f) ? (((esc_ap_CS_fsm_reg_35__1_673f736) ? (((ram0_reg_i_98_n_0) ? (1'b0) : (~(ram0_reg_4[2])))) : (~(ram0_reg_4[2])))) : (((ram0_reg_i_99_n_0) ? (((esc_ap_CS_fsm_reg_35__1_673f736) ? (((ram0_reg_i_98_n_0) ? (ram0_reg_4[2]) : (1'b1))) : (1'b1))) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (((ram0_reg_i_98_n_0) ? (1'b0) : (~(ram0_reg_4[2])))) : (1'b1))))))));

  // Reconstructed LUT6: ram0_reg_i_34__0
  assign ram0_reg_i_34__0_n_0 = ((ram0_reg_24[5]) ? (((ram0_reg_24[3]) ? (((ram0_reg_24[0]) ? (((ram0_reg_24[1]) ? (((ram0_reg_24[2]) ? (ram0_reg_24[4]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT4: ram0_reg_i_35
  assign esc_add_ln74_reg_6855_reg_7__1_e9ac382 = ((ram0_reg_4[2]) ? (((esc_ap_CS_fsm_reg_19_bd70f8c) ? (((esc_add_ln68_reg_8723_reg_2_180a5a5 [1]) ? (esc_ap_CS_fsm_reg_17__0_3991a9e) : (1'b1))) : (1'b0))) : (((esc_add_ln68_reg_8723_reg_2_180a5a5 [1]) ? (esc_ap_CS_fsm_reg_17__0_3991a9e) : (1'b1))));

  // Reconstructed LUT5: ram0_reg_i_35__0
  assign ram0_reg_i_35__0_n_0 = ((ram0_reg_24[4]) ? (((ram0_reg_24[2]) ? (((ram0_reg_24[1]) ? (((ram0_reg_24[0]) ? (ram0_reg_24[3]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_37
  assign ram0_reg_i_37_n_0 = ((ram0_reg_6[2]) ? (((ap_enable_reg_pp1_iter0) ? (((ram0_reg_i_23__0_1[6]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[10])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[10])) : (1'b1))))) : (((ram0_reg_i_23__0_2[4]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[10])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[10])) : (1'b1))))))) : (((ram0_reg_i_23__0_2[4]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[10])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[10])) : (1'b1))))));

  // Reconstructed LUT5: ram0_reg_i_37__0
  assign ap_enable_reg_pp3_iter0_reg_rep = ((ram0_reg_6[18]) ? (((ram0_reg_22) ? (1'b0) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (1'b0) : (((ram0_reg_32) ? (~(ram0_reg_26)) : (1'b0))))))) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (1'b0) : (((ram0_reg_32) ? (~(ram0_reg_26)) : (1'b0))))));

  // Reconstructed LUT6: ram0_reg_i_38
  assign esc_add_ln74_reg_6855_reg_7_6b2f341 = ((ap_enable_reg_pp3_iter0_reg_rep__2_0) ? (((ram0_reg_4[0]) ? (((ram0_reg_4[1]) ? (((ram0_reg_14) ? (((ram0_reg_4[2]) ? (1'b1) : (~(esc_ap_CS_fsm_reg_48__0_0aa522c)))) : (~(ram0_reg_4[2])))) : (ram0_reg_4[2]))) : (ram0_reg_4[2]))) : (((ram0_reg_4[0]) ? (((ram0_reg_4[1]) ? (((ram0_reg_4[2]) ? (1'b0) : (~(esc_ap_CS_fsm_reg_48__0_0aa522c)))) : (((ram0_reg_4[2]) ? (~(esc_ap_CS_fsm_reg_48__0_0aa522c)) : (1'b0))))) : (((ram0_reg_4[2]) ? (~(esc_ap_CS_fsm_reg_48__0_0aa522c)) : (1'b0))))));

  // Reconstructed LUT6: ram0_reg_i_38__0
  assign ram0_reg_i_38__0_n_0 = ((ram0_reg_6[2]) ? (((ap_enable_reg_pp1_iter0) ? (((ram0_reg_i_23__0_1[5]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[9])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[9])) : (1'b1))))) : (((ram0_reg_i_23__0_2[3]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[9])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[9])) : (1'b1))))))) : (((ram0_reg_i_23__0_2[3]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[9])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[9])) : (1'b1))))));

  // Reconstructed LUT6: ram0_reg_i_39
  assign esc_add_ln74_reg_6855_reg_6_25e4b8d = ((ap_enable_reg_pp3_iter0_reg_rep__2_0) ? (((ram0_reg_4[0]) ? (((mul_ln215_reg_6908[1]) ? (~(ram0_reg_4[1])) : (((mul_ln215_reg_6908[0]) ? (~(ram0_reg_4[1])) : (((ram0_reg_4[1]) ? (1'b1) : (~(esc_ap_CS_fsm_reg_48__0_0aa522c)))))))) : (ram0_reg_4[1]))) : (((ram0_reg_4[0]) ? (((ram0_reg_4[1]) ? (1'b0) : (~(esc_ap_CS_fsm_reg_48__0_0aa522c)))) : (((ram0_reg_4[1]) ? (~(esc_ap_CS_fsm_reg_48__0_0aa522c)) : (1'b0))))));

  // Reconstructed LUT6: ram0_reg_i_39__0
  assign ram0_reg_i_39__0_n_0 = ((ram0_reg_6[2]) ? (((ap_enable_reg_pp1_iter0) ? (((ram0_reg_i_23__0_1[4]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[8])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[8])) : (1'b1))))) : (((ram0_reg_i_23__0_2[2]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[8])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[8])) : (1'b1))))))) : (((ram0_reg_i_23__0_2[2]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[8])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_23__0_0[8])) : (1'b1))))));

  // Reconstructed LUT4: ram0_reg_i_3__0
  assign ram0_reg_i_3__0_n_0 = ((ap_enable_reg_pp3_iter0_reg_rep__2) ? (((ram0_reg_i_24_n_0) ? (1'b1) : (((esc_add_ln74_reg_6855_reg_9__0_2980795) ? (esc_add_ln74_reg_6855_reg_9_9c8c6ed) : (1'b1))))) : (esc_add_ln74_reg_6855_reg_9_9c8c6ed));

  // Reconstructed LUT6: ram0_reg_i_40
  assign esc_add_ln74_reg_6855_reg_6__0_8e7e51f = ((mul_ln215_reg_6908[0]) ? (((ram0_reg_i_86_n_0) ? (((ram0_reg_4[1]) ? (((ram0_reg_i_107_n_0) ? (~(esc_ap_CS_fsm_reg_23_edf6f2f)) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (1'b0) : (~(esc_ap_CS_fsm_reg_23_edf6f2f)))))) : (((ram0_reg_i_107_n_0) ? (~(esc_ap_CS_fsm_reg_35__1_673f736)) : (1'b1))))) : (((ram0_reg_4[1]) ? (((ram0_reg_i_107_n_0) ? (~(esc_ap_CS_fsm_reg_23_edf6f2f)) : (1'b0))) : (~(ram0_reg_i_107_n_0)))))) : (((ram0_reg_i_86_n_0) ? (((ram0_reg_4[1]) ? (((ram0_reg_i_107_n_0) ? (~(esc_ap_CS_fsm_reg_23_edf6f2f)) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (1'b0) : (~(esc_ap_CS_fsm_reg_23_edf6f2f)))))) : (((ram0_reg_i_107_n_0) ? (~(esc_ap_CS_fsm_reg_35__1_673f736)) : (1'b1))))) : (((ram0_reg_4[1]) ? (1'b0) : (((ram0_reg_i_107_n_0) ? (~(esc_ap_CS_fsm_reg_35__1_673f736)) : (1'b1))))))));

  // Reconstructed LUT4: ram0_reg_i_41
  assign esc_add_ln74_reg_6855_reg_6__1_a3a11c9 = ((ram0_reg_4[1]) ? (((esc_ap_CS_fsm_reg_19_bd70f8c) ? (((esc_add_ln68_reg_8723_reg_2_180a5a5 [0]) ? (esc_ap_CS_fsm_reg_17__0_3991a9e) : (1'b1))) : (1'b0))) : (((esc_add_ln68_reg_8723_reg_2_180a5a5 [0]) ? (esc_ap_CS_fsm_reg_17__0_3991a9e) : (1'b1))));

  // Reconstructed LUT5: ram0_reg_i_43
  assign esc_add_ln74_reg_6855_reg_5_2a13e9b = ((ap_enable_reg_pp3_iter0_reg_rep__2_0) ? (((mul_ln215_reg_6908[0]) ? (~(ram0_reg_4[0])) : (((mul_ln215_reg_6908[1]) ? (~(ram0_reg_4[0])) : (((ram0_reg_4[0]) ? (1'b1) : (~(esc_ap_CS_fsm_reg_48__0_0aa522c)))))))) : (((ram0_reg_4[0]) ? (1'b0) : (~(esc_ap_CS_fsm_reg_48__0_0aa522c)))));

  // Reconstructed LUT6: ram0_reg_i_44
  assign esc_mul_ln215_reg_6908_reg_0_b3fe01c = ((esc_ap_CS_fsm_reg_35__1_673f736) ? (((ram0_reg_i_86_n_0) ? (((ram0_reg_4[0]) ? (((mul_ln215_reg_6908[1]) ? (~(esc_ap_CS_fsm_reg_23_edf6f2f)) : (1'b0))) : (~(mul_ln215_reg_6908[1])))) : (((ram0_reg_4[0]) ? (((mul_ln215_reg_6908[1]) ? (((mul_ln215_reg_6908[0]) ? (~(esc_ap_CS_fsm_reg_23_edf6f2f)) : (1'b0))) : (1'b0))) : (~(mul_ln215_reg_6908[1])))))) : (((ram0_reg_i_86_n_0) ? (((ram0_reg_4[0]) ? (~(esc_ap_CS_fsm_reg_23_edf6f2f)) : (1'b1))) : (((ram0_reg_4[0]) ? (((mul_ln215_reg_6908[1]) ? (((mul_ln215_reg_6908[0]) ? (~(esc_ap_CS_fsm_reg_23_edf6f2f)) : (1'b0))) : (1'b0))) : (((mul_ln215_reg_6908[1]) ? (~(mul_ln215_reg_6908[0])) : (1'b1))))))));

  // Reconstructed LUT5: ram0_reg_i_45
  assign esc_add_ln74_reg_6855_reg_5__0_2b6f97c = ((ram0_reg_4[0]) ? (((esc_ap_CS_fsm_reg_19_bd70f8c) ? (((zext_ln74_2_fu_2977_p1[0]) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (esc_ap_CS_fsm_reg_17__0_3991a9e) : (1'b1))) : (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b1) : (esc_ap_CS_fsm_reg_17__0_3991a9e))))) : (1'b0))) : (((zext_ln74_2_fu_2977_p1[0]) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (esc_ap_CS_fsm_reg_17__0_3991a9e) : (1'b1))) : (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b1) : (esc_ap_CS_fsm_reg_17__0_3991a9e))))));

  // Reconstructed LUT4: ram0_reg_i_47
  assign esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd = ((ap_enable_reg_pp3_iter0_reg_rep__2_0) ? (((mul_ln215_reg_6908[1]) ? (((mul_ln215_reg_6908[0]) ? (1'b1) : (~(esc_ap_CS_fsm_reg_48__0_0aa522c)))) : (~(mul_ln215_reg_6908[0])))) : (((mul_ln215_reg_6908[1]) ? (~(esc_ap_CS_fsm_reg_48__0_0aa522c)) : (1'b0))));

  // Reconstructed LUT5: ram0_reg_i_48
  assign esc_mul_ln215_reg_6908_reg_1__0_292d7d8 = ((esc_ap_CS_fsm_reg_35__1_673f736) ? (((mul_ln215_reg_6908[0]) ? (((mul_ln215_reg_6908[1]) ? (ram0_reg_i_109_n_0) : (1'b0))) : (((mul_ln215_reg_6908[1]) ? (((esc_ap_CS_fsm_reg_35__0_74dd3b9) ? (1'b0) : (ram0_reg_i_109_n_0))) : (1'b0))))) : (((mul_ln215_reg_6908[0]) ? (((mul_ln215_reg_6908[1]) ? (ram0_reg_i_109_n_0) : (((esc_ap_CS_fsm_reg_35__0_74dd3b9) ? (1'b0) : (ram0_reg_i_109_n_0))))) : (((mul_ln215_reg_6908[1]) ? (((esc_ap_CS_fsm_reg_35__0_74dd3b9) ? (1'b0) : (ram0_reg_i_109_n_0))) : (ram0_reg_i_109_n_0))))));

  // Reconstructed LUT4: ram0_reg_i_49
  assign esc_mul_ln215_reg_6908_reg_1__1_b396821 = ((ram0_reg_i_111_n_0) ? (((esc_ap_CS_fsm_reg_19_bd70f8c) ? (1'b1) : (~(mul_ln215_reg_6908[1])))) : (((esc_ap_CS_fsm_reg_17__0_3991a9e) ? (((esc_ap_CS_fsm_reg_19_bd70f8c) ? (1'b1) : (~(mul_ln215_reg_6908[1])))) : (1'b0))));

  // Reconstructed LUT4: ram0_reg_i_4__0
  assign ram0_reg_i_4__0_n_0 = ((ap_enable_reg_pp3_iter0_reg_rep__2) ? (((ram0_reg_i_25__0_n_0) ? (1'b1) : (((esc_add_ln74_reg_6855_reg_8__0_dab2ff8) ? (esc_add_ln74_reg_6855_reg_8_0e33662) : (1'b1))))) : (esc_add_ln74_reg_6855_reg_8_0e33662));

  // Reconstructed LUT6: ram0_reg_i_55
  assign ap_enable_reg_pp3_iter0_reg_rep__2_1 = ((esc_ap_CS_fsm_reg_54_3d44ae7) ? (((ram0_reg_9) ? (((esc_ap_CS_fsm_reg_46_ba5f378) ? (((ram0_reg_33) ? (((ram0_reg_13) ? (1'b1) : (ram0_reg_12))) : (1'b1))) : (((ram0_reg_13) ? (1'b1) : (ram0_reg_12))))) : (1'b0))) : (1'b1));

  // Reconstructed LUT6: ram0_reg_i_56
  assign esc_ap_CS_fsm_reg_35_69cfbc2 = ((ram0_reg_i_124_n_0) ? (((ram0_reg_i_123_n_0) ? (1'b0) : (((ram0_reg_31) ? (((ram0_reg_30) ? (((ram0_reg_29) ? (1'b0) : (~(esc_ap_CS_fsm_reg_35__0_74dd3b9)))) : (1'b0))) : (1'b0))))) : (((ram0_reg_30) ? (((ram0_reg_29) ? (1'b0) : (~(esc_ap_CS_fsm_reg_35__0_74dd3b9)))) : (1'b0))));

  // Reconstructed LUT5: ram0_reg_i_59
  assign esc_ap_CS_fsm_reg_21_af57a65 = ((esc_ap_CS_fsm_reg_35__0_74dd3b9) ? (1'b0) : (((ram0_reg_i_126_n_0) ? (1'b0) : (((ram0_reg_i_124_n_0) ? (((esc_ap_CS_fsm_reg_29_d9f5eab) ? (~(ram0_reg_i_123_n_0)) : (1'b0))) : (1'b1))))));

  // Reconstructed LUT6: ram0_reg_i_5__0
  assign ram0_reg_i_5__0_n_0 = ((ap_enable_reg_pp3_iter0_reg_rep__2) ? (((ap_enable_reg_pp3_iter0_reg_rep) ? (((ram0_reg_i_26__0_n_0) ? (1'b1) : (((esc_add_ln74_reg_6855_reg_7__1_e9ac382) ? (((esc_add_ln74_reg_6855_reg_7__0_abb43a8) ? (esc_add_ln74_reg_6855_reg_7_6b2f341) : (1'b1))) : (1'b1))))) : (((esc_add_ln74_reg_6855_reg_7__0_abb43a8) ? (esc_add_ln74_reg_6855_reg_7_6b2f341) : (1'b1))))) : (esc_add_ln74_reg_6855_reg_7_6b2f341));

  // Reconstructed LUT5: ram0_reg_i_60
  assign ap_enable_reg_pp3_iter0_reg_0 = ((ram0_reg_6[7]) ? (1'b1) : (((ram0_reg_6[8]) ? (1'b1) : (((ram0_reg_6[5]) ? (~(ap_enable_reg_pp3_iter0)) : (((ram0_reg_6[6]) ? (~(ap_enable_reg_pp3_iter0)) : (1'b1))))))));

  // Reconstructed LUT6: ram0_reg_i_62
  assign ap_enable_reg_pp3_iter0_reg = ((ram0_reg_6[39]) ? (((ap_enable_reg_pp3_iter0) ? (1'b1) : (ram0_reg_i_127_n_0))) : (((ram0_reg_6[38]) ? (((ap_enable_reg_pp3_iter0) ? (1'b1) : (ram0_reg_i_127_n_0))) : (((ap_enable_reg_pp3_iter0) ? (((ram0_reg_8) ? (ram0_reg_i_127_n_0) : (((ram0_reg_7) ? (1'b1) : (ram0_reg_i_127_n_0))))) : (ram0_reg_i_127_n_0))))));

  // Reconstructed LUT5: ram0_reg_i_63
  assign ap_enable_reg_pp3_iter0_reg_rep_0 = ((ram0_reg_i_131_n_0) ? (1'b0) : (((ram0_reg_i_124_n_0) ? (((ram0_reg_28) ? (((ram0_reg_27) ? (ram0_reg_26) : (1'b1))) : (1'b0))) : (1'b1))));

  // Reconstructed LUT6: ram0_reg_i_64
  assign esc_ap_CS_fsm_reg_16_2d815ec = ((ram0_reg_21) ? (((ram0_reg_6[6]) ? (((ram0_reg_6[7]) ? (~(ram0_reg_6[8])) : (1'b0))) : (((ram0_reg_6[7]) ? (~(ram0_reg_6[8])) : (((ram0_reg_6[8]) ? (1'b0) : (((ram0_reg_6[5]) ? (1'b1) : (~(ram0_reg_6[4])))))))))) : (1'b1));

  // Reconstructed LUT6: ram0_reg_i_66
  assign esc_ap_CS_fsm_reg_48_486bf78 = ((ram0_reg_i_135_n_0) ? (((esc_ap_CS_fsm_reg_54_3d44ae7) ? (((ram0_reg_11) ? (1'b1) : (((ram0_reg_10) ? (1'b1) : (((ram0_reg_9) ? (~(ram0_reg_i_132_n_0)) : (1'b0))))))) : (((ram0_reg_11) ? (1'b1) : (ram0_reg_10))))) : (((esc_ap_CS_fsm_reg_54_3d44ae7) ? (1'b1) : (((ram0_reg_11) ? (1'b1) : (ram0_reg_10))))));

  // Reconstructed LUT6: ram0_reg_i_6__0
  assign ram0_reg_i_6__0_n_0 = ((ap_enable_reg_pp3_iter0_reg_rep__2) ? (((ap_enable_reg_pp3_iter0_reg_rep) ? (((ram0_reg_i_27__0_n_0) ? (1'b1) : (((esc_add_ln74_reg_6855_reg_6__1_a3a11c9) ? (((esc_add_ln74_reg_6855_reg_6__0_8e7e51f) ? (esc_add_ln74_reg_6855_reg_6_25e4b8d) : (1'b1))) : (1'b1))))) : (((esc_add_ln74_reg_6855_reg_6__0_8e7e51f) ? (esc_add_ln74_reg_6855_reg_6_25e4b8d) : (1'b1))))) : (esc_add_ln74_reg_6855_reg_6_25e4b8d));

  // Reconstructed LUT6: ram0_reg_i_70
  assign esc_ap_CS_fsm_reg_23_edf6f2f = ((ram0_reg_26) ? (1'b0) : (((ram0_reg_6[9]) ? (((ap_enable_reg_pp3_iter0) ? (((ram0_reg_6[11]) ? (1'b0) : (ram0_reg_i_124_n_0))) : (1'b0))) : (((ram0_reg_6[10]) ? (((ap_enable_reg_pp3_iter0) ? (((ram0_reg_6[11]) ? (1'b0) : (ram0_reg_i_124_n_0))) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT6: ram0_reg_i_71
  assign esc_ap_CS_fsm_reg_35__1_673f736 = ((ram0_reg_15) ? (((ram0_reg_6[19]) ? (1'b1) : (((ram0_reg_6[20]) ? (1'b1) : (((esc_ap_CS_fsm_reg_33_3728c13) ? (1'b1) : (((ram0_reg_6[23]) ? (1'b1) : (~(ram0_reg_30)))))))))) : (((esc_ap_CS_fsm_reg_33_3728c13) ? (1'b1) : (~(ram0_reg_30)))));

  // Reconstructed LUT5: ram0_reg_i_72
  assign ram0_reg_i_72_n_0 = ((ram0_reg_4[4]) ? (((ram0_reg_4[2]) ? (((ram0_reg_4[1]) ? (((ram0_reg_4[0]) ? (ram0_reg_4[3]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_73
  assign ram0_reg_i_73_n_0 = ((ram0_reg_i_86_n_0) ? (1'b0) : (((ram0_reg_4[5]) ? (((ram0_reg_i_88_n_0) ? (((ram0_reg_4[4]) ? (((mul_ln215_reg_6908[0]) ? (~(mul_ln215_reg_6908[1])) : (1'b1))) : (1'b1))) : (1'b1))) : (((ram0_reg_i_88_n_0) ? (((ram0_reg_4[4]) ? (((mul_ln215_reg_6908[0]) ? (mul_ln215_reg_6908[1]) : (1'b0))) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: ram0_reg_i_76
  assign esc_ap_CS_fsm_reg_17_dedac0c = ((ram0_reg_6[3]) ? (((ram0_reg_15) ? (1'b0) : (ram0_reg_5))) : (((ram0_reg_15) ? (((ram0_reg_5) ? (((ram0_reg_6[4]) ? (1'b0) : (~(ram0_reg_6[5])))) : (1'b0))) : (ram0_reg_5))));

  // Reconstructed LUT5: ram0_reg_i_77
  assign esc_add_ln74_reg_6855_reg_10__0_d3d73fa = ((ram0_reg_4[5]) ? (((ram0_reg_5) ? (((ram0_reg_i_32_0) ? (1'b0) : (((esc_ap_CS_fsm_reg_17__0_3991a9e) ? (1'b1) : (~(esc_add_ln68_reg_8723_reg_2_180a5a5 [3])))))) : (((esc_ap_CS_fsm_reg_17__0_3991a9e) ? (1'b1) : (~(esc_add_ln68_reg_8723_reg_2_180a5a5 [3])))))) : (((esc_ap_CS_fsm_reg_17__0_3991a9e) ? (1'b1) : (~(esc_add_ln68_reg_8723_reg_2_180a5a5 [3])))));

  // Reconstructed LUT6: ram0_reg_i_7__0
  assign ram0_reg_i_7__0_n_0 = ((ap_enable_reg_pp3_iter0_reg_rep__2) ? (((ap_enable_reg_pp3_iter0_reg_rep) ? (((ram0_reg_i_28_n_0) ? (1'b1) : (((esc_add_ln74_reg_6855_reg_5__0_2b6f97c) ? (((esc_mul_ln215_reg_6908_reg_0_b3fe01c) ? (esc_add_ln74_reg_6855_reg_5_2a13e9b) : (1'b1))) : (1'b1))))) : (((esc_mul_ln215_reg_6908_reg_0_b3fe01c) ? (esc_add_ln74_reg_6855_reg_5_2a13e9b) : (1'b1))))) : (esc_add_ln74_reg_6855_reg_5_2a13e9b));

  // Reconstructed LUT6: ram0_reg_i_81
  assign ram0_reg_i_81_n_0 = ((ram0_reg_9) ? (((ram0_reg_6[39]) ? (~(ram0_reg_15)) : (((ram0_reg_6[38]) ? (~(ram0_reg_15)) : (((ram0_reg_15) ? (((ram0_reg_6[37]) ? (1'b0) : (~(ram0_reg_6[36])))) : (1'b1))))))) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_82
  assign esc_ap_CS_fsm_reg_48__0_0aa522c = ((ram0_reg_i_54_2) ? (1'b0) : (((ram0_reg_i_54_1) ? (1'b0) : (((ram0_reg_i_54_0) ? (1'b0) : (((ram0_reg_i_54) ? (1'b0) : (((ram0_reg_10) ? (1'b0) : (ram0_reg_9))))))))));

  // Reconstructed LUT6: ram0_reg_i_83
  assign ram0_reg_i_83_n_0 = ((ram0_reg_15) ? (((ram0_reg_6[31]) ? (1'b0) : (((ram0_reg_6[32]) ? (1'b0) : (((ram0_reg_6[30]) ? (1'b0) : (((ram0_reg_17) ? (ram0_reg_18) : (1'b0))))))))) : (ram0_reg_18));

  // Reconstructed LUT6: ram0_reg_i_84
  assign ram0_reg_i_84_n_0 = ((ram0_reg_i_124_n_0) ? (((ram0_reg_i_123_n_0) ? (1'b0) : (((mul_ln215_reg_6908[1]) ? (((ram0_reg_i_88_n_0) ? (((ram0_reg_4[4]) ? (1'b1) : (~(esc_ap_CS_fsm_reg_35__1_673f736)))) : (~(esc_ap_CS_fsm_reg_35__1_673f736)))) : (~(esc_ap_CS_fsm_reg_35__1_673f736)))))) : (((mul_ln215_reg_6908[1]) ? (((ram0_reg_i_88_n_0) ? (((ram0_reg_4[4]) ? (1'b1) : (~(esc_ap_CS_fsm_reg_35__1_673f736)))) : (~(esc_ap_CS_fsm_reg_35__1_673f736)))) : (~(esc_ap_CS_fsm_reg_35__1_673f736)))));

  // Reconstructed LUT6: ram0_reg_i_85
  assign ram0_reg_i_85_n_0 = ((mul_ln215_reg_6908[1]) ? (((ram0_reg_i_96_n_0) ? (((ram0_reg_4[2]) ? (((ram0_reg_4[4]) ? (1'b0) : (((ram0_reg_4[3]) ? (esc_ap_CS_fsm_reg_35__1_673f736) : (1'b0))))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_86
  assign ram0_reg_i_86_n_0 = ((esc_ap_CS_fsm_reg_26_bc9d1aa) ? (((ram0_reg_31) ? (~(esc_ap_CS_fsm_reg_35__0_74dd3b9)) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (~(esc_ap_CS_fsm_reg_35__0_74dd3b9)) : (((ram0_reg_22) ? (((ram0_reg_6[18]) ? (~(esc_ap_CS_fsm_reg_35__0_74dd3b9)) : (1'b0))) : (1'b0))))))) : (((esc_ap_CS_fsm_reg_35__1_673f736) ? (~(esc_ap_CS_fsm_reg_35__0_74dd3b9)) : (((ram0_reg_22) ? (((ram0_reg_6[18]) ? (~(esc_ap_CS_fsm_reg_35__0_74dd3b9)) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT4: ram0_reg_i_88
  assign ram0_reg_i_88_n_0 = ((ram0_reg_4[3]) ? (((ram0_reg_4[0]) ? (((ram0_reg_4[1]) ? (ram0_reg_4[2]) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_8__0
  assign ram0_reg_i_8__0_n_0 = ((ap_enable_reg_pp3_iter0_reg_rep__2) ? (((ap_enable_reg_pp3_iter0_reg_rep) ? (((ram0_reg_i_29__0_n_0) ? (1'b1) : (((esc_mul_ln215_reg_6908_reg_1__1_b396821) ? (((esc_mul_ln215_reg_6908_reg_1__0_292d7d8) ? (esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd) : (1'b1))) : (1'b1))))) : (((esc_mul_ln215_reg_6908_reg_1__0_292d7d8) ? (esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd) : (1'b1))))) : (esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd));

  // Reconstructed LUT6: ram0_reg_i_9
  assign ram0_reg_i_9_n_0 = ((ap_enable_reg_pp3_iter0_reg_rep__2) ? (((ram0_reg_3) ? (1'b1) : (((ram0_reg_i_30_n_0) ? (((ap_enable_reg_pp3_iter0_reg_rep) ? (1'b1) : (ram0_reg_1))) : (((ram0_reg_2) ? (ram0_reg_1) : (((ap_enable_reg_pp3_iter0_reg_rep) ? (1'b1) : (ram0_reg_1))))))))) : (ram0_reg_1));

  // Reconstructed LUT5: ram0_reg_i_90
  assign esc_add_ln74_reg_6855_reg_9__1_9d031f6 = ((ram0_reg_4[4]) ? (((ram0_reg_5) ? (((ram0_reg_i_32_0) ? (1'b0) : (((esc_ap_CS_fsm_reg_17__0_3991a9e) ? (1'b1) : (~(esc_add_ln68_reg_8723_reg_2_180a5a5 [2])))))) : (((esc_ap_CS_fsm_reg_17__0_3991a9e) ? (1'b1) : (~(esc_add_ln68_reg_8723_reg_2_180a5a5 [2])))))) : (((esc_ap_CS_fsm_reg_17__0_3991a9e) ? (1'b1) : (~(esc_add_ln68_reg_8723_reg_2_180a5a5 [2])))));

  // Reconstructed LUT6: ram0_reg_i_91
  assign ap_enable_reg_pp3_iter0_reg_rep__2_0 = ((ram0_reg_18) ? (((ram0_reg_17) ? (((ram0_reg_6[30]) ? (((ram0_reg_15) ? (esc_ap_CS_fsm_reg_48__0_0aa522c) : (1'b0))) : (((ram0_reg_16) ? (1'b0) : (((ram0_reg_15) ? (esc_ap_CS_fsm_reg_48__0_0aa522c) : (1'b0))))))) : (((ram0_reg_15) ? (esc_ap_CS_fsm_reg_48__0_0aa522c) : (1'b0))))) : (esc_ap_CS_fsm_reg_48__0_0aa522c));

  // Reconstructed LUT3: ram0_reg_i_92
  assign ram0_reg_i_92_n_0 = ((ram0_reg_4[2]) ? (((ram0_reg_4[1]) ? (ram0_reg_4[0]) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_93
  assign ram0_reg_i_93_n_0 = ((ram0_reg_4[3]) ? (((ram0_reg_4[2]) ? (((ram0_reg_25) ? (((ram0_reg_4[0]) ? (((ram0_reg_4[1]) ? (1'b0) : (~(ram0_reg_i_86_n_0)))) : (~(ram0_reg_i_86_n_0)))) : (~(ram0_reg_i_86_n_0)))) : (~(ram0_reg_i_86_n_0)))) : (((ram0_reg_4[2]) ? (((ram0_reg_25) ? (((ram0_reg_4[0]) ? (((ram0_reg_4[1]) ? (~(ram0_reg_i_86_n_0)) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: ram0_reg_i_95
  assign esc_add_ln74_reg_6855_reg_8__1_c9f6290 = ((ram0_reg_4[3]) ? (((ram0_reg_5) ? (((ram0_reg_i_32_0) ? (1'b0) : (((esc_ap_CS_fsm_reg_17__0_3991a9e) ? (1'b1) : (((ram0_reg_i_32) ? (~(zext_ln74_2_fu_2977_p1[1])) : (zext_ln74_2_fu_2977_p1[1]))))))) : (((esc_ap_CS_fsm_reg_17__0_3991a9e) ? (1'b1) : (((ram0_reg_i_32) ? (~(zext_ln74_2_fu_2977_p1[1])) : (zext_ln74_2_fu_2977_p1[1]))))))) : (((esc_ap_CS_fsm_reg_17__0_3991a9e) ? (1'b1) : (((ram0_reg_i_32) ? (~(zext_ln74_2_fu_2977_p1[1])) : (zext_ln74_2_fu_2977_p1[1]))))));

  // Reconstructed LUT2: ram0_reg_i_96
  assign ram0_reg_i_96_n_0 = ((ram0_reg_4[0]) ? (ram0_reg_4[1]) : (1'b0));

  // Reconstructed LUT3: ram0_reg_i_98
  assign ram0_reg_i_98_n_0 = ((ram0_reg_4[1]) ? (((mul_ln215_reg_6908[1]) ? (ram0_reg_4[0]) : (1'b0))) : (1'b0));

  // Reconstructed LUT4: ram0_reg_i_99
  assign ram0_reg_i_99_n_0 = ((mul_ln215_reg_6908[1]) ? (((ram0_reg_4[0]) ? (((ram0_reg_4[1]) ? (ram0_reg_4[2]) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT2: esc_reg_2512_7__i_2_72ed0b5
  assign ap_enable_reg_pp1_iter0_reg = ((ram0_reg_6[2]) ? (ap_enable_reg_pp1_iter0) : (1'b0));

  // Reconstructed LUT5: esc_y_2_reg_2385_1__i_1_0890703
  assign esc_add_ln68_reg_8723_reg_1_d6e0e48 = ((esc_y_2_reg_2385_reg_4_1138322 [1]) ? (((esc_y_2_reg_2385_reg_3_172fc4c) ? (1'b1) : (((esc_y_2_reg_2385_reg_3__0_c63e66d) ? (((ram0_reg_6[3]) ? (esc_y_2_reg_2385_reg_4__0_25a3d14 [1]) : (1'b1))) : (1'b1))))) : (((esc_y_2_reg_2385_reg_3_172fc4c) ? (1'b0) : (((esc_y_2_reg_2385_reg_3__0_c63e66d) ? (((ram0_reg_6[3]) ? (esc_y_2_reg_2385_reg_4__0_25a3d14 [1]) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: esc_y_2_reg_2385_2__i_1_517d75e
  assign esc_add_ln68_reg_8723_reg_2__0_0488464 = ((esc_y_2_reg_2385_reg_4_1138322 [2]) ? (((esc_y_2_reg_2385_reg_3_172fc4c) ? (1'b1) : (((esc_y_2_reg_2385_reg_3__0_c63e66d) ? (((ram0_reg_6[3]) ? (esc_y_2_reg_2385_reg_4__0_25a3d14 [2]) : (1'b1))) : (1'b1))))) : (((esc_y_2_reg_2385_reg_3_172fc4c) ? (1'b0) : (((esc_y_2_reg_2385_reg_3__0_c63e66d) ? (((ram0_reg_6[3]) ? (esc_y_2_reg_2385_reg_4__0_25a3d14 [2]) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: esc_y_2_reg_2385_3__i_1_fca6da6
  assign esc_add_ln68_reg_8723_reg_3_d7954e8 = ((esc_y_2_reg_2385_reg_4_1138322 [3]) ? (((esc_y_2_reg_2385_reg_3_172fc4c) ? (1'b1) : (((esc_y_2_reg_2385_reg_3__0_c63e66d) ? (((ram0_reg_6[3]) ? (esc_y_2_reg_2385_reg_4__0_25a3d14 [3]) : (1'b1))) : (1'b1))))) : (((esc_y_2_reg_2385_reg_3_172fc4c) ? (1'b0) : (((esc_y_2_reg_2385_reg_3__0_c63e66d) ? (((ram0_reg_6[3]) ? (esc_y_2_reg_2385_reg_4__0_25a3d14 [3]) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: esc_y_2_reg_2385_4__i_1_bf7875b
  assign esc_add_ln68_reg_8723_reg_4_ae92a68 = ((esc_y_2_reg_2385_reg_4_1138322 [4]) ? (((esc_y_2_reg_2385_reg_3_172fc4c) ? (1'b1) : (((esc_y_2_reg_2385_reg_3__0_c63e66d) ? (((ram0_reg_6[3]) ? (esc_y_2_reg_2385_reg_4__0_25a3d14 [4]) : (1'b1))) : (1'b1))))) : (((esc_y_2_reg_2385_reg_3_172fc4c) ? (1'b0) : (((esc_y_2_reg_2385_reg_3__0_c63e66d) ? (((ram0_reg_6[3]) ? (esc_y_2_reg_2385_reg_4__0_25a3d14 [4]) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT3: esc_y_reg_2297_4__i_2_c2ea9b9
  assign y_reg_22970 = ((esc_y_reg_2297_reg_0_8039ace) ? (1'b0) : (((ram0_reg_6[0]) ? (ap_enable_reg_pp0_iter1) : (1'b0))));

endmodule

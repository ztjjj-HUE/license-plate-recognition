// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_blue_counts_ram_9
   (DOADO,
    D,
    esc_add_ln208_40_reg_7067_reg_8_4748565 ,
    esc_add_ln208_44_reg_7119_reg_9_9449ba5 ,
    esc_add_ln208_47_reg_7171_reg_9_5141771 ,
    esc_add_ln208_50_reg_7223_reg_10_aa3bb5f ,
    esc_add_ln208_53_reg_7275_reg_10_0754859 ,
    esc_add_ln208_56_reg_7327_reg_10_b6e53dd ,
    esc_add_ln208_59_reg_7379_reg_10_8ef5260 ,
    esc_add_ln208_62_reg_7431_reg_11_6ab2f6a ,
    esc_add_ln208_65_reg_7483_reg_11_f154d09 ,
    esc_add_ln208_68_reg_7535_reg_11_e9aafb9 ,
    esc_add_ln208_71_reg_7587_reg_11_d2760f7 ,
    esc_add_ln208_74_reg_7649_reg_11_23515cd ,
    esc_add_ln208_77_reg_7711_reg_11_bc8d80b ,
    esc_add_ln208_80_reg_7773_reg_11_d71fa1b ,
    esc_add_ln208_83_reg_7835_reg_11_118cabd ,
    esc_add_ln208_86_reg_7897_reg_12_202b975 ,
    esc_add_ln208_89_reg_7959_reg_12_637a141 ,
    esc_add_ln208_92_reg_8021_reg_12_8f48385 ,
    esc_add_ln208_95_reg_8083_reg_12_2d1a536 ,
    esc_add_ln208_98_reg_8125_reg_12_1367b81 ,
    esc_add_ln208_101_reg_8167_reg_12_d11b77b ,
    esc_add_ln208_104_reg_8199_reg_12_b9a1976 ,
    esc_add_ln208_107_reg_8231_reg_12_85508a2 ,
    esc_add_ln208_110_reg_8263_reg_12_8c4af8a ,
    esc_add_ln208_113_reg_8295_reg_12_525514a ,
    esc_add_ln208_116_reg_8327_reg_12_e26cb33 ,
    esc_add_ln208_119_reg_8359_reg_12_abf25fc ,
    esc_add_ln208_122_reg_8391_reg_12_c056c12 ,
    esc_add_ln208_125_reg_8423_reg_12_a546884 ,
    esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 ,
    esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 ,
    esc_add_ln208_134_reg_8519_reg_13_79685f6 ,
    esc_add_ln208_137_reg_8551_reg_13_711eea5 ,
    esc_add_ln208_140_reg_8583_reg_13_3a2afb7 ,
    esc_add_ln208_143_reg_8615_reg_13_7ea25a2 ,
    esc_add_ln208_146_reg_8647_reg_13_c285ab8 ,
    esc_add_ln208_149_reg_8679_reg_13_a787366 ,
    zext_ln208_86_fu_5765_p1,
    ap_enable_reg_pp1_iter1_reg,
    esc_mul_ln215_reg_6908_reg_0_b3fe01c ,
    esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ,
    esc_mul_ln215_reg_6908_reg_0__1_55582ee ,
    ap_clk,
    blue_counts_ce0,
    Q,
    esc_add_ln208_47_reg_7171_reg_9__0_3783b12 ,
    esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 ,
    esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 ,
    esc_add_ln208_56_reg_7327_reg_10__0_e100627 ,
    esc_add_ln208_59_reg_7379_reg_10__0_cb96932 ,
    esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 ,
    esc_add_ln208_65_reg_7483_reg_11__0_6caa48b ,
    esc_add_ln208_68_reg_7535_reg_11__0_eeee088 ,
    esc_add_ln208_71_reg_7587_reg_11__0_248299a ,
    esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e ,
    esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 ,
    esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 ,
    esc_add_ln208_83_reg_7835_reg_11__0_741884e ,
    esc_add_ln208_86_reg_7897_reg_11_897ebea ,
    esc_add_ln208_89_reg_7959_reg_12__0_27a5822 ,
    esc_add_ln208_92_reg_8021_reg_12__0_1f8120a ,
    esc_add_ln208_95_reg_8083_reg_12__0_30298fc ,
    esc_add_ln208_98_reg_8125_reg_12__0_2065764 ,
    esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 ,
    esc_add_ln208_104_reg_8199_reg_12__0_418f127 ,
    esc_add_ln208_107_reg_8231_reg_12__0_575cc95 ,
    esc_add_ln208_110_reg_8263_reg_12__0_42182a4 ,
    esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 ,
    esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 ,
    esc_add_ln208_119_reg_8359_reg_12__0_63393ef ,
    esc_add_ln208_122_reg_8391_reg_12__0_cec336a ,
    esc_add_ln208_125_reg_8423_reg_12__0_5cba652 ,
    esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 ,
    esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 ,
    esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f ,
    esc_add_ln208_137_reg_8551_reg_13__0_215f155 ,
    esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 ,
    esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 ,
    esc_add_ln208_146_reg_8647_reg_13__0_24263ad ,
    esc_add_ln208_149_reg_8679_reg_13__0_b628b5d ,
    esc_add_ln208_152_reg_8711_reg_13_848699e ,
    esc_add_ln208_39_reg_8728_reg_15_81ea661 ,
    ram0_reg_0,
    ram0_reg_1,
    ram0_reg_2,
    ram0_reg_3,
    ram0_reg_4,
    ram0_reg_5,
    data42,
    ram0_reg_i_25_0,
    ram0_reg_i_25_1,
    ram0_reg_i_53_0,
    ram0_reg_6,
    ram0_reg_7,
    ram0_reg_8,
    ram0_reg_9,
    ram0_reg_10,
    ram0_reg_11,
    ram0_reg_12,
    ram0_reg_13,
    ram0_reg_14,
    ram0_reg_15,
    ram0_reg_16,
    ram0_reg_17,
    ram0_reg_18,
    ram0_reg_19,
    ram0_reg_20,
    ram0_reg_21,
    ram0_reg_22,
    ram0_reg_23,
    ram0_reg_24,
    ram0_reg_25,
    ram0_reg_26,
    ram0_reg_27,
    ram0_reg_28,
    ram0_reg_29,
    ram0_reg_30,
    ram0_reg_31,
    ap_enable_reg_pp1_iter0,
    ram0_reg_32,
    ram0_reg_33,
    ram0_reg_34,
    ram0_reg_35,
    ram0_reg_36,
    ram0_reg_37,
    ram0_reg_38,
    ap_enable_reg_pp0_iter1,
    previous_blue_1_reg_6804,
    ram0_reg_39,
    ap_phi_mux_y_2_phi_fu_2389_p4,
    ram0_reg_40,
    mul_ln215_reg_6908,
    ram0_reg_41,
    ram0_reg_42,
    ram0_reg_43,
    ram0_reg_44,
    ram0_reg_45,
    ram0_reg_i_53_1,
    ram0_reg_i_53_2,
    ap_enable_reg_pp3_iter0);
  output [7:0]DOADO;
  output [8:0]D;
  output [9:0]esc_add_ln208_40_reg_7067_reg_8_4748565 ;
  output [9:0]esc_add_ln208_44_reg_7119_reg_9_9449ba5 ;
  output [10:0]esc_add_ln208_47_reg_7171_reg_9_5141771 ;
  output [10:0]esc_add_ln208_50_reg_7223_reg_10_aa3bb5f ;
  output [10:0]esc_add_ln208_53_reg_7275_reg_10_0754859 ;
  output [10:0]esc_add_ln208_56_reg_7327_reg_10_b6e53dd ;
  output [11:0]esc_add_ln208_59_reg_7379_reg_10_8ef5260 ;
  output [11:0]esc_add_ln208_62_reg_7431_reg_11_6ab2f6a ;
  output [11:0]esc_add_ln208_65_reg_7483_reg_11_f154d09 ;
  output [11:0]esc_add_ln208_68_reg_7535_reg_11_e9aafb9 ;
  output [11:0]esc_add_ln208_71_reg_7587_reg_11_d2760f7 ;
  output [11:0]esc_add_ln208_74_reg_7649_reg_11_23515cd ;
  output [11:0]esc_add_ln208_77_reg_7711_reg_11_bc8d80b ;
  output [11:0]esc_add_ln208_80_reg_7773_reg_11_d71fa1b ;
  output [12:0]esc_add_ln208_83_reg_7835_reg_11_118cabd ;
  output [12:0]esc_add_ln208_86_reg_7897_reg_12_202b975 ;
  output [12:0]esc_add_ln208_89_reg_7959_reg_12_637a141 ;
  output [12:0]esc_add_ln208_92_reg_8021_reg_12_8f48385 ;
  output [12:0]esc_add_ln208_95_reg_8083_reg_12_2d1a536 ;
  output [12:0]esc_add_ln208_98_reg_8125_reg_12_1367b81 ;
  output [12:0]esc_add_ln208_101_reg_8167_reg_12_d11b77b ;
  output [12:0]esc_add_ln208_104_reg_8199_reg_12_b9a1976 ;
  output [12:0]esc_add_ln208_107_reg_8231_reg_12_85508a2 ;
  output [12:0]esc_add_ln208_110_reg_8263_reg_12_8c4af8a ;
  output [12:0]esc_add_ln208_113_reg_8295_reg_12_525514a ;
  output [12:0]esc_add_ln208_116_reg_8327_reg_12_e26cb33 ;
  output [12:0]esc_add_ln208_119_reg_8359_reg_12_abf25fc ;
  output [12:0]esc_add_ln208_122_reg_8391_reg_12_c056c12 ;
  output [12:0]esc_add_ln208_125_reg_8423_reg_12_a546884 ;
  output [12:0]esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 ;
  output [13:0]esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 ;
  output [13:0]esc_add_ln208_134_reg_8519_reg_13_79685f6 ;
  output [13:0]esc_add_ln208_137_reg_8551_reg_13_711eea5 ;
  output [13:0]esc_add_ln208_140_reg_8583_reg_13_3a2afb7 ;
  output [13:0]esc_add_ln208_143_reg_8615_reg_13_7ea25a2 ;
  output [13:0]esc_add_ln208_146_reg_8647_reg_13_c285ab8 ;
  output [13:0]esc_add_ln208_149_reg_8679_reg_13_a787366 ;
  output [13:0]zext_ln208_86_fu_5765_p1;
  output ap_enable_reg_pp1_iter1_reg;
  output esc_mul_ln215_reg_6908_reg_0_b3fe01c ;
  output esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ;
  output esc_mul_ln215_reg_6908_reg_0__1_55582ee ;
  input ap_clk;
  input blue_counts_ce0;
  input [8:0]Q;
  input [9:0]esc_add_ln208_47_reg_7171_reg_9__0_3783b12 ;
  input [9:0]esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 ;
  input [10:0]esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 ;
  input [10:0]esc_add_ln208_56_reg_7327_reg_10__0_e100627 ;
  input [10:0]esc_add_ln208_59_reg_7379_reg_10__0_cb96932 ;
  input [10:0]esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 ;
  input [11:0]esc_add_ln208_65_reg_7483_reg_11__0_6caa48b ;
  input [11:0]esc_add_ln208_68_reg_7535_reg_11__0_eeee088 ;
  input [11:0]esc_add_ln208_71_reg_7587_reg_11__0_248299a ;
  input [11:0]esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e ;
  input [11:0]esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 ;
  input [11:0]esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 ;
  input [11:0]esc_add_ln208_83_reg_7835_reg_11__0_741884e ;
  input [11:0]esc_add_ln208_86_reg_7897_reg_11_897ebea ;
  input [12:0]esc_add_ln208_89_reg_7959_reg_12__0_27a5822 ;
  input [12:0]esc_add_ln208_92_reg_8021_reg_12__0_1f8120a ;
  input [12:0]esc_add_ln208_95_reg_8083_reg_12__0_30298fc ;
  input [12:0]esc_add_ln208_98_reg_8125_reg_12__0_2065764 ;
  input [12:0]esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 ;
  input [12:0]esc_add_ln208_104_reg_8199_reg_12__0_418f127 ;
  input [12:0]esc_add_ln208_107_reg_8231_reg_12__0_575cc95 ;
  input [12:0]esc_add_ln208_110_reg_8263_reg_12__0_42182a4 ;
  input [12:0]esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 ;
  input [12:0]esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 ;
  input [12:0]esc_add_ln208_119_reg_8359_reg_12__0_63393ef ;
  input [12:0]esc_add_ln208_122_reg_8391_reg_12__0_cec336a ;
  input [12:0]esc_add_ln208_125_reg_8423_reg_12__0_5cba652 ;
  input [12:0]esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 ;
  input [12:0]esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 ;
  input [12:0]esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f ;
  input [13:0]esc_add_ln208_137_reg_8551_reg_13__0_215f155 ;
  input [13:0]esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 ;
  input [13:0]esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 ;
  input [13:0]esc_add_ln208_146_reg_8647_reg_13__0_24263ad ;
  input [13:0]esc_add_ln208_149_reg_8679_reg_13__0_b628b5d ;
  input [13:0]esc_add_ln208_152_reg_8711_reg_13_848699e ;
  input [13:0]esc_add_ln208_39_reg_8728_reg_15_81ea661 ;
  input ram0_reg_0;
  input ram0_reg_1;
  input ram0_reg_2;
  input ram0_reg_3;
  input ram0_reg_4;
  input ram0_reg_5;
  input [8:0]data42;
  input [10:0]ram0_reg_i_25_0;
  input [10:0]ram0_reg_i_25_1;
  input [7:0]ram0_reg_i_53_0;
  input ram0_reg_6;
  input [7:0]ram0_reg_7;
  input ram0_reg_8;
  input ram0_reg_9;
  input ram0_reg_10;
  input [1:0]ram0_reg_11;
  input ram0_reg_12;
  input ram0_reg_13;
  input ram0_reg_14;
  input ram0_reg_15;
  input ram0_reg_16;
  input ram0_reg_17;
  input ram0_reg_18;
  input ram0_reg_19;
  input ram0_reg_20;
  input ram0_reg_21;
  input ram0_reg_22;
  input ram0_reg_23;
  input ram0_reg_24;
  input ram0_reg_25;
  input ram0_reg_26;
  input ram0_reg_27;
  input ram0_reg_28;
  input ram0_reg_29;
  input [2:0]ram0_reg_30;
  input ram0_reg_31;
  input ap_enable_reg_pp1_iter0;
  input ram0_reg_32;
  input ram0_reg_33;
  input ram0_reg_34;
  input ram0_reg_35;
  input ram0_reg_36;
  input ram0_reg_37;
  input ram0_reg_38;
  input ap_enable_reg_pp0_iter1;
  input previous_blue_1_reg_6804;
  input ram0_reg_39;
  input [0:0]ap_phi_mux_y_2_phi_fu_2389_p4;
  input ram0_reg_40;
  input [0:0]mul_ln215_reg_6908;
  input ram0_reg_41;
  input ram0_reg_42;
  input ram0_reg_43;
  input ram0_reg_44;
  input ram0_reg_45;
  input ram0_reg_i_53_1;
  input ram0_reg_i_53_2;
  input ap_enable_reg_pp3_iter0;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [8:0]D;
  wire [7:0]DOADO;
  wire GND_2;
  wire [8:0]Q;
  wire esc_add_ln208_101_reg_8167_3__i_2_n_0_38204af ;
  wire esc_add_ln208_101_reg_8167_3__i_3_n_0_02c55f9 ;
  wire esc_add_ln208_101_reg_8167_3__i_4_n_0_b7b8249 ;
  wire esc_add_ln208_101_reg_8167_3__i_5_n_0_3bfadf9 ;
  wire esc_add_ln208_101_reg_8167_7__i_2_n_0_3b42f32 ;
  wire esc_add_ln208_101_reg_8167_7__i_3_n_0_0150c91 ;
  wire esc_add_ln208_101_reg_8167_7__i_4_n_0_cdbe992 ;
  wire esc_add_ln208_101_reg_8167_7__i_5_n_0_e128efc ;
  wire esc_add_ln208_101_reg_8167_reg_11__i_1_n_0_d02e3e3 ;
  wire [12:0]esc_add_ln208_101_reg_8167_reg_12_d11b77b ;
  wire [12:0]esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 ;
  wire esc_add_ln208_101_reg_8167_reg_3__i_1_n_0_5c68086 ;
  wire esc_add_ln208_101_reg_8167_reg_7__i_1_n_0_1522780 ;
  wire esc_add_ln208_104_reg_8199_3__i_2_n_0_c1dff9c ;
  wire esc_add_ln208_104_reg_8199_3__i_3_n_0_dbb8c7d ;
  wire esc_add_ln208_104_reg_8199_3__i_4_n_0_ed69558 ;
  wire esc_add_ln208_104_reg_8199_3__i_5_n_0_cd7aa00 ;
  wire esc_add_ln208_104_reg_8199_7__i_2_n_0_8861246 ;
  wire esc_add_ln208_104_reg_8199_7__i_3_n_0_3c7afa6 ;
  wire esc_add_ln208_104_reg_8199_7__i_4_n_0_bac7a4c ;
  wire esc_add_ln208_104_reg_8199_7__i_5_n_0_e8611d4 ;
  wire esc_add_ln208_104_reg_8199_reg_11__i_1_n_0_f1b3be7 ;
  wire [12:0]esc_add_ln208_104_reg_8199_reg_12_b9a1976 ;
  wire [12:0]esc_add_ln208_104_reg_8199_reg_12__0_418f127 ;
  wire esc_add_ln208_104_reg_8199_reg_3__i_1_n_0_5a8fe27 ;
  wire esc_add_ln208_104_reg_8199_reg_7__i_1_n_0_17657f7 ;
  wire esc_add_ln208_107_reg_8231_3__i_2_n_0_4a148f0 ;
  wire esc_add_ln208_107_reg_8231_3__i_3_n_0_98f593f ;
  wire esc_add_ln208_107_reg_8231_3__i_4_n_0_77f1f90 ;
  wire esc_add_ln208_107_reg_8231_3__i_5_n_0_457f28a ;
  wire esc_add_ln208_107_reg_8231_7__i_2_n_0_47c4da2 ;
  wire esc_add_ln208_107_reg_8231_7__i_3_n_0_c8eab89 ;
  wire esc_add_ln208_107_reg_8231_7__i_4_n_0_155fe11 ;
  wire esc_add_ln208_107_reg_8231_7__i_5_n_0_eef0235 ;
  wire esc_add_ln208_107_reg_8231_reg_11__i_1_n_0_a3bac88 ;
  wire [12:0]esc_add_ln208_107_reg_8231_reg_12_85508a2 ;
  wire [12:0]esc_add_ln208_107_reg_8231_reg_12__0_575cc95 ;
  wire esc_add_ln208_107_reg_8231_reg_3__i_1_n_0_1910cb2 ;
  wire esc_add_ln208_107_reg_8231_reg_7__i_1_n_0_afa71e9 ;
  wire esc_add_ln208_110_reg_8263_3__i_2_n_0_180133a ;
  wire esc_add_ln208_110_reg_8263_3__i_3_n_0_3b5880d ;
  wire esc_add_ln208_110_reg_8263_3__i_4_n_0_13ae061 ;
  wire esc_add_ln208_110_reg_8263_3__i_5_n_0_50bd5d4 ;
  wire esc_add_ln208_110_reg_8263_7__i_2_n_0_6786063 ;
  wire esc_add_ln208_110_reg_8263_7__i_3_n_0_2a7035b ;
  wire esc_add_ln208_110_reg_8263_7__i_4_n_0_b586c03 ;
  wire esc_add_ln208_110_reg_8263_7__i_5_n_0_1332b02 ;
  wire esc_add_ln208_110_reg_8263_reg_11__i_1_n_0_9d29414 ;
  wire [12:0]esc_add_ln208_110_reg_8263_reg_12_8c4af8a ;
  wire [12:0]esc_add_ln208_110_reg_8263_reg_12__0_42182a4 ;
  wire esc_add_ln208_110_reg_8263_reg_3__i_1_n_0_f2d281d ;
  wire esc_add_ln208_110_reg_8263_reg_7__i_1_n_0_b307750 ;
  wire esc_add_ln208_113_reg_8295_3__i_2_n_0_93a5182 ;
  wire esc_add_ln208_113_reg_8295_3__i_3_n_0_6946030 ;
  wire esc_add_ln208_113_reg_8295_3__i_4_n_0_3bfd948 ;
  wire esc_add_ln208_113_reg_8295_3__i_5_n_0_3337824 ;
  wire esc_add_ln208_113_reg_8295_7__i_2_n_0_5ad978e ;
  wire esc_add_ln208_113_reg_8295_7__i_3_n_0_a901118 ;
  wire esc_add_ln208_113_reg_8295_7__i_4_n_0_0f5e013 ;
  wire esc_add_ln208_113_reg_8295_7__i_5_n_0_de6c861 ;
  wire esc_add_ln208_113_reg_8295_reg_11__i_1_n_0_bbf0819 ;
  wire [12:0]esc_add_ln208_113_reg_8295_reg_12_525514a ;
  wire [12:0]esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 ;
  wire esc_add_ln208_113_reg_8295_reg_3__i_1_n_0_5c2df74 ;
  wire esc_add_ln208_113_reg_8295_reg_7__i_1_n_0_bf6e9b2 ;
  wire esc_add_ln208_116_reg_8327_3__i_2_n_0_77e8112 ;
  wire esc_add_ln208_116_reg_8327_3__i_3_n_0_060984c ;
  wire esc_add_ln208_116_reg_8327_3__i_4_n_0_b6afb77 ;
  wire esc_add_ln208_116_reg_8327_3__i_5_n_0_2a528d0 ;
  wire esc_add_ln208_116_reg_8327_7__i_2_n_0_2081363 ;
  wire esc_add_ln208_116_reg_8327_7__i_3_n_0_6f394ea ;
  wire esc_add_ln208_116_reg_8327_7__i_4_n_0_2682cc5 ;
  wire esc_add_ln208_116_reg_8327_7__i_5_n_0_0562e6a ;
  wire esc_add_ln208_116_reg_8327_reg_11__i_1_n_0_7e87537 ;
  wire [12:0]esc_add_ln208_116_reg_8327_reg_12_e26cb33 ;
  wire [12:0]esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 ;
  wire esc_add_ln208_116_reg_8327_reg_3__i_1_n_0_1f43223 ;
  wire esc_add_ln208_116_reg_8327_reg_7__i_1_n_0_8ae925b ;
  wire esc_add_ln208_119_reg_8359_3__i_2_n_0_a1bc0c1 ;
  wire esc_add_ln208_119_reg_8359_3__i_3_n_0_c3c7e0e ;
  wire esc_add_ln208_119_reg_8359_3__i_4_n_0_fa8e4af ;
  wire esc_add_ln208_119_reg_8359_3__i_5_n_0_c2c3d75 ;
  wire esc_add_ln208_119_reg_8359_7__i_2_n_0_1044494 ;
  wire esc_add_ln208_119_reg_8359_7__i_3_n_0_2c9812d ;
  wire esc_add_ln208_119_reg_8359_7__i_4_n_0_e71a19a ;
  wire esc_add_ln208_119_reg_8359_7__i_5_n_0_4299aca ;
  wire esc_add_ln208_119_reg_8359_reg_11__i_1_n_0_cad678e ;
  wire [12:0]esc_add_ln208_119_reg_8359_reg_12_abf25fc ;
  wire [12:0]esc_add_ln208_119_reg_8359_reg_12__0_63393ef ;
  wire esc_add_ln208_119_reg_8359_reg_3__i_1_n_0_93bdcfb ;
  wire esc_add_ln208_119_reg_8359_reg_7__i_1_n_0_38bbe71 ;
  wire esc_add_ln208_122_reg_8391_3__i_2_n_0_89a0bfd ;
  wire esc_add_ln208_122_reg_8391_3__i_3_n_0_a44bebf ;
  wire esc_add_ln208_122_reg_8391_3__i_4_n_0_8bdf34b ;
  wire esc_add_ln208_122_reg_8391_3__i_5_n_0_d5b0839 ;
  wire esc_add_ln208_122_reg_8391_7__i_2_n_0_f7a33c7 ;
  wire esc_add_ln208_122_reg_8391_7__i_3_n_0_8f1b239 ;
  wire esc_add_ln208_122_reg_8391_7__i_4_n_0_b294405 ;
  wire esc_add_ln208_122_reg_8391_7__i_5_n_0_3064f83 ;
  wire esc_add_ln208_122_reg_8391_reg_11__i_1_n_0_7d03e0b ;
  wire [12:0]esc_add_ln208_122_reg_8391_reg_12_c056c12 ;
  wire [12:0]esc_add_ln208_122_reg_8391_reg_12__0_cec336a ;
  wire esc_add_ln208_122_reg_8391_reg_3__i_1_n_0_6805bda ;
  wire esc_add_ln208_122_reg_8391_reg_7__i_1_n_0_988279e ;
  wire esc_add_ln208_125_reg_8423_3__i_2_n_0_73a6811 ;
  wire esc_add_ln208_125_reg_8423_3__i_3_n_0_625f302 ;
  wire esc_add_ln208_125_reg_8423_3__i_4_n_0_c3ccc6e ;
  wire esc_add_ln208_125_reg_8423_3__i_5_n_0_b9ef9e5 ;
  wire esc_add_ln208_125_reg_8423_7__i_2_n_0_775c9f7 ;
  wire esc_add_ln208_125_reg_8423_7__i_3_n_0_b69b2e5 ;
  wire esc_add_ln208_125_reg_8423_7__i_4_n_0_c310702 ;
  wire esc_add_ln208_125_reg_8423_7__i_5_n_0_7ff1805 ;
  wire esc_add_ln208_125_reg_8423_reg_11__i_1_n_0_6bf1419 ;
  wire [12:0]esc_add_ln208_125_reg_8423_reg_12_a546884 ;
  wire [12:0]esc_add_ln208_125_reg_8423_reg_12__0_5cba652 ;
  wire esc_add_ln208_125_reg_8423_reg_3__i_1_n_0_03feca3 ;
  wire esc_add_ln208_125_reg_8423_reg_7__i_1_n_0_a51f088 ;
  wire esc_add_ln208_128_reg_8455_3__i_2_n_0_7d1eb60 ;
  wire esc_add_ln208_128_reg_8455_3__i_3_n_0_f134447 ;
  wire esc_add_ln208_128_reg_8455_3__i_4_n_0_4cba90e ;
  wire esc_add_ln208_128_reg_8455_3__i_5_n_0_2cca731 ;
  wire esc_add_ln208_128_reg_8455_7__i_2_n_0_2095e42 ;
  wire esc_add_ln208_128_reg_8455_7__i_3_n_0_4705c5f ;
  wire esc_add_ln208_128_reg_8455_7__i_4_n_0_0c828b7 ;
  wire esc_add_ln208_128_reg_8455_7__i_5_n_0_2a9d3fd ;
  wire esc_add_ln208_128_reg_8455_reg_11__i_1_n_0_5647a0a ;
  wire [12:0]esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 ;
  wire [12:0]esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 ;
  wire esc_add_ln208_128_reg_8455_reg_3__i_1_n_0_1fca9ee ;
  wire esc_add_ln208_128_reg_8455_reg_7__i_1_n_0_7bb2674 ;
  wire esc_add_ln208_131_reg_8487_3__i_2_n_0_6fc87f4 ;
  wire esc_add_ln208_131_reg_8487_3__i_3_n_0_e0429a9 ;
  wire esc_add_ln208_131_reg_8487_3__i_4_n_0_8ab1732 ;
  wire esc_add_ln208_131_reg_8487_3__i_5_n_0_e0ef96a ;
  wire esc_add_ln208_131_reg_8487_7__i_2_n_0_81f6faa ;
  wire esc_add_ln208_131_reg_8487_7__i_3_n_0_0edcb9f ;
  wire esc_add_ln208_131_reg_8487_7__i_4_n_0_0900209 ;
  wire esc_add_ln208_131_reg_8487_7__i_5_n_0_f6d73a4 ;
  wire esc_add_ln208_131_reg_8487_reg_11__i_1_n_0_8d18615 ;
  wire [13:0]esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 ;
  wire [12:0]esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 ;
  wire esc_add_ln208_131_reg_8487_reg_3__i_1_n_0_73d3ea4 ;
  wire esc_add_ln208_131_reg_8487_reg_7__i_1_n_0_f577232 ;
  wire esc_add_ln208_134_reg_8519_3__i_2_n_0_4107dd6 ;
  wire esc_add_ln208_134_reg_8519_3__i_3_n_0_2329e7f ;
  wire esc_add_ln208_134_reg_8519_3__i_4_n_0_4006024 ;
  wire esc_add_ln208_134_reg_8519_3__i_5_n_0_7f8e999 ;
  wire esc_add_ln208_134_reg_8519_7__i_2_n_0_2e1b8fb ;
  wire esc_add_ln208_134_reg_8519_7__i_3_n_0_bc728eb ;
  wire esc_add_ln208_134_reg_8519_7__i_4_n_0_0bb706e ;
  wire esc_add_ln208_134_reg_8519_7__i_5_n_0_85c175b ;
  wire esc_add_ln208_134_reg_8519_reg_11__i_1_n_0_ef2ae3e ;
  wire [13:0]esc_add_ln208_134_reg_8519_reg_13_79685f6 ;
  wire [12:0]esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f ;
  wire esc_add_ln208_134_reg_8519_reg_3__i_1_n_0_4723170 ;
  wire esc_add_ln208_134_reg_8519_reg_7__i_1_n_0_c595bda ;
  wire esc_add_ln208_137_reg_8551_3__i_2_n_0_204f9eb ;
  wire esc_add_ln208_137_reg_8551_3__i_3_n_0_3c6e873 ;
  wire esc_add_ln208_137_reg_8551_3__i_4_n_0_47917d6 ;
  wire esc_add_ln208_137_reg_8551_3__i_5_n_0_4a85f84 ;
  wire esc_add_ln208_137_reg_8551_7__i_2_n_0_15e06d5 ;
  wire esc_add_ln208_137_reg_8551_7__i_3_n_0_7325944 ;
  wire esc_add_ln208_137_reg_8551_7__i_4_n_0_0f6e3e4 ;
  wire esc_add_ln208_137_reg_8551_7__i_5_n_0_457a937 ;
  wire esc_add_ln208_137_reg_8551_reg_11__i_1_n_0_b7a80e2 ;
  wire [13:0]esc_add_ln208_137_reg_8551_reg_13_711eea5 ;
  wire [13:0]esc_add_ln208_137_reg_8551_reg_13__0_215f155 ;
  wire esc_add_ln208_137_reg_8551_reg_3__i_1_n_0_3a4f3c5 ;
  wire esc_add_ln208_137_reg_8551_reg_7__i_1_n_0_d32e017 ;
  wire esc_add_ln208_140_reg_8583_3__i_2_n_0_841829b ;
  wire esc_add_ln208_140_reg_8583_3__i_3_n_0_821abcb ;
  wire esc_add_ln208_140_reg_8583_3__i_4_n_0_8302584 ;
  wire esc_add_ln208_140_reg_8583_3__i_5_n_0_3c21bf2 ;
  wire esc_add_ln208_140_reg_8583_7__i_2_n_0_744a5b5 ;
  wire esc_add_ln208_140_reg_8583_7__i_3_n_0_88a100d ;
  wire esc_add_ln208_140_reg_8583_7__i_4_n_0_f0687de ;
  wire esc_add_ln208_140_reg_8583_7__i_5_n_0_d32a40d ;
  wire esc_add_ln208_140_reg_8583_reg_11__i_1_n_0_c49c1d5 ;
  wire [13:0]esc_add_ln208_140_reg_8583_reg_13_3a2afb7 ;
  wire [13:0]esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 ;
  wire esc_add_ln208_140_reg_8583_reg_3__i_1_n_0_00d3fb5 ;
  wire esc_add_ln208_140_reg_8583_reg_7__i_1_n_0_50057e5 ;
  wire esc_add_ln208_143_reg_8615_3__i_2_n_0_636c1d8 ;
  wire esc_add_ln208_143_reg_8615_3__i_3_n_0_311abfb ;
  wire esc_add_ln208_143_reg_8615_3__i_4_n_0_fe9ceb3 ;
  wire esc_add_ln208_143_reg_8615_3__i_5_n_0_60fcf4c ;
  wire esc_add_ln208_143_reg_8615_7__i_2_n_0_c26d3bc ;
  wire esc_add_ln208_143_reg_8615_7__i_3_n_0_68e26a8 ;
  wire esc_add_ln208_143_reg_8615_7__i_4_n_0_bc01c24 ;
  wire esc_add_ln208_143_reg_8615_7__i_5_n_0_626914f ;
  wire esc_add_ln208_143_reg_8615_reg_11__i_1_n_0_9fab781 ;
  wire [13:0]esc_add_ln208_143_reg_8615_reg_13_7ea25a2 ;
  wire [13:0]esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 ;
  wire esc_add_ln208_143_reg_8615_reg_3__i_1_n_0_6e474f0 ;
  wire esc_add_ln208_143_reg_8615_reg_7__i_1_n_0_152dc00 ;
  wire esc_add_ln208_146_reg_8647_3__i_2_n_0_ef6a05d ;
  wire esc_add_ln208_146_reg_8647_3__i_3_n_0_f842a07 ;
  wire esc_add_ln208_146_reg_8647_3__i_4_n_0_5001f18 ;
  wire esc_add_ln208_146_reg_8647_3__i_5_n_0_1177c92 ;
  wire esc_add_ln208_146_reg_8647_7__i_2_n_0_c0740ec ;
  wire esc_add_ln208_146_reg_8647_7__i_3_n_0_86398a0 ;
  wire esc_add_ln208_146_reg_8647_7__i_4_n_0_7810831 ;
  wire esc_add_ln208_146_reg_8647_7__i_5_n_0_b003e6f ;
  wire esc_add_ln208_146_reg_8647_reg_11__i_1_n_0_93e94f3 ;
  wire [13:0]esc_add_ln208_146_reg_8647_reg_13_c285ab8 ;
  wire [13:0]esc_add_ln208_146_reg_8647_reg_13__0_24263ad ;
  wire esc_add_ln208_146_reg_8647_reg_3__i_1_n_0_37a3acc ;
  wire esc_add_ln208_146_reg_8647_reg_7__i_1_n_0_403eb86 ;
  wire esc_add_ln208_149_reg_8679_3__i_2_n_0_8a301ab ;
  wire esc_add_ln208_149_reg_8679_3__i_3_n_0_a25d75a ;
  wire esc_add_ln208_149_reg_8679_3__i_4_n_0_3405b5c ;
  wire esc_add_ln208_149_reg_8679_3__i_5_n_0_ee00f1a ;
  wire esc_add_ln208_149_reg_8679_7__i_2_n_0_9f83f46 ;
  wire esc_add_ln208_149_reg_8679_7__i_3_n_0_5125bcb ;
  wire esc_add_ln208_149_reg_8679_7__i_4_n_0_bd2ae98 ;
  wire esc_add_ln208_149_reg_8679_7__i_5_n_0_8e90a07 ;
  wire esc_add_ln208_149_reg_8679_reg_11__i_1_n_0_8ffda78 ;
  wire [13:0]esc_add_ln208_149_reg_8679_reg_13_a787366 ;
  wire [13:0]esc_add_ln208_149_reg_8679_reg_13__0_b628b5d ;
  wire esc_add_ln208_149_reg_8679_reg_3__i_1_n_0_7227bdf ;
  wire esc_add_ln208_149_reg_8679_reg_7__i_1_n_0_04b99c2 ;
  wire esc_add_ln208_152_reg_8711_3__i_2_n_0_e996f01 ;
  wire esc_add_ln208_152_reg_8711_3__i_3_n_0_0ca6af8 ;
  wire esc_add_ln208_152_reg_8711_3__i_4_n_0_baba261 ;
  wire esc_add_ln208_152_reg_8711_3__i_5_n_0_3b91a4e ;
  wire esc_add_ln208_152_reg_8711_7__i_2_n_0_ed9973b ;
  wire esc_add_ln208_152_reg_8711_7__i_3_n_0_ce7010c ;
  wire esc_add_ln208_152_reg_8711_7__i_4_n_0_13af8e6 ;
  wire esc_add_ln208_152_reg_8711_7__i_5_n_0_b6a9da2 ;
  wire esc_add_ln208_152_reg_8711_reg_11__i_1_n_0_3461e44 ;
  wire [13:0]esc_add_ln208_152_reg_8711_reg_13_848699e ;
  wire esc_add_ln208_152_reg_8711_reg_3__i_1_n_0_0cc1d1a ;
  wire esc_add_ln208_152_reg_8711_reg_7__i_1_n_0_84f8c9b ;
  wire esc_add_ln208_39_reg_8728_3__i_10_n_0_403481d ;
  wire esc_add_ln208_39_reg_8728_3__i_7_n_0_22aaad8 ;
  wire esc_add_ln208_39_reg_8728_3__i_8_n_0_f24e38d ;
  wire esc_add_ln208_39_reg_8728_3__i_9_n_0_28e464e ;
  wire esc_add_ln208_39_reg_8728_7__i_10_n_0_367f83d ;
  wire esc_add_ln208_39_reg_8728_7__i_7_n_0_fbf9927 ;
  wire esc_add_ln208_39_reg_8728_7__i_8_n_0_a64a1e7 ;
  wire esc_add_ln208_39_reg_8728_7__i_9_n_0_40eeeff ;
  wire esc_add_ln208_39_reg_8728_reg_11__i_2_n_0_641e002 ;
  wire [13:0]esc_add_ln208_39_reg_8728_reg_15_81ea661 ;
  wire esc_add_ln208_39_reg_8728_reg_3__i_2_n_0_b82e945 ;
  wire esc_add_ln208_39_reg_8728_reg_7__i_2_n_0_73a6098 ;
  wire esc_add_ln208_40_reg_7067_3__i_2_n_0_96eb7c8 ;
  wire esc_add_ln208_40_reg_7067_3__i_3_n_0_67f7c93 ;
  wire esc_add_ln208_40_reg_7067_3__i_4_n_0_9845a8c ;
  wire esc_add_ln208_40_reg_7067_3__i_5_n_0_164633f ;
  wire esc_add_ln208_40_reg_7067_7__i_2_n_0_50584df ;
  wire esc_add_ln208_40_reg_7067_7__i_3_n_0_7d42b03 ;
  wire esc_add_ln208_40_reg_7067_7__i_4_n_0_baec1f8 ;
  wire esc_add_ln208_40_reg_7067_7__i_5_n_0_33aaf1b ;
  wire esc_add_ln208_40_reg_7067_reg_3__i_1_n_0_8263a45 ;
  wire esc_add_ln208_40_reg_7067_reg_7__i_1_n_0_d513a20 ;
  wire [9:0]esc_add_ln208_40_reg_7067_reg_8_4748565 ;
  wire esc_add_ln208_44_reg_7119_3__i_2_n_0_2a0983a ;
  wire esc_add_ln208_44_reg_7119_3__i_3_n_0_ad92b5b ;
  wire esc_add_ln208_44_reg_7119_3__i_4_n_0_2afc826 ;
  wire esc_add_ln208_44_reg_7119_3__i_5_n_0_c3553e3 ;
  wire esc_add_ln208_44_reg_7119_7__i_2_n_0_7645409 ;
  wire esc_add_ln208_44_reg_7119_7__i_3_n_0_1cc3fa6 ;
  wire esc_add_ln208_44_reg_7119_7__i_4_n_0_b306a08 ;
  wire esc_add_ln208_44_reg_7119_7__i_5_n_0_487d070 ;
  wire esc_add_ln208_44_reg_7119_reg_3__i_1_n_0_1f37292 ;
  wire esc_add_ln208_44_reg_7119_reg_7__i_1_n_0_9812eda ;
  wire [9:0]esc_add_ln208_44_reg_7119_reg_9_9449ba5 ;
  wire esc_add_ln208_47_reg_7171_3__i_2_n_0_e6e4799 ;
  wire esc_add_ln208_47_reg_7171_3__i_3_n_0_5feda06 ;
  wire esc_add_ln208_47_reg_7171_3__i_4_n_0_b1f0a76 ;
  wire esc_add_ln208_47_reg_7171_3__i_5_n_0_47fb3cc ;
  wire esc_add_ln208_47_reg_7171_7__i_2_n_0_73c23cd ;
  wire esc_add_ln208_47_reg_7171_7__i_3_n_0_8bdef78 ;
  wire esc_add_ln208_47_reg_7171_7__i_4_n_0_eec460c ;
  wire esc_add_ln208_47_reg_7171_7__i_5_n_0_4bec516 ;
  wire esc_add_ln208_47_reg_7171_reg_3__i_1_n_0_29ca070 ;
  wire esc_add_ln208_47_reg_7171_reg_7__i_1_n_0_3677d32 ;
  wire [10:0]esc_add_ln208_47_reg_7171_reg_9_5141771 ;
  wire [9:0]esc_add_ln208_47_reg_7171_reg_9__0_3783b12 ;
  wire esc_add_ln208_50_reg_7223_3__i_2_n_0_d63092b ;
  wire esc_add_ln208_50_reg_7223_3__i_3_n_0_90f9e62 ;
  wire esc_add_ln208_50_reg_7223_3__i_4_n_0_7547f33 ;
  wire esc_add_ln208_50_reg_7223_3__i_5_n_0_5006374 ;
  wire esc_add_ln208_50_reg_7223_7__i_2_n_0_5c19c3a ;
  wire esc_add_ln208_50_reg_7223_7__i_3_n_0_42b26d2 ;
  wire esc_add_ln208_50_reg_7223_7__i_4_n_0_699b1cb ;
  wire esc_add_ln208_50_reg_7223_7__i_5_n_0_efd6698 ;
  wire [10:0]esc_add_ln208_50_reg_7223_reg_10_aa3bb5f ;
  wire [9:0]esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 ;
  wire esc_add_ln208_50_reg_7223_reg_3__i_1_n_0_3f5aea7 ;
  wire esc_add_ln208_50_reg_7223_reg_7__i_1_n_0_700420e ;
  wire esc_add_ln208_53_reg_7275_3__i_2_n_0_cdbccc5 ;
  wire esc_add_ln208_53_reg_7275_3__i_3_n_0_087b9aa ;
  wire esc_add_ln208_53_reg_7275_3__i_4_n_0_a66a71f ;
  wire esc_add_ln208_53_reg_7275_3__i_5_n_0_1eed7b6 ;
  wire esc_add_ln208_53_reg_7275_7__i_2_n_0_64e8bf6 ;
  wire esc_add_ln208_53_reg_7275_7__i_3_n_0_a4657fa ;
  wire esc_add_ln208_53_reg_7275_7__i_4_n_0_24dd9fd ;
  wire esc_add_ln208_53_reg_7275_7__i_5_n_0_e3b1e5e ;
  wire [10:0]esc_add_ln208_53_reg_7275_reg_10_0754859 ;
  wire [10:0]esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 ;
  wire esc_add_ln208_53_reg_7275_reg_3__i_1_n_0_284bae9 ;
  wire esc_add_ln208_53_reg_7275_reg_7__i_1_n_0_10ffd4a ;
  wire esc_add_ln208_56_reg_7327_3__i_2_n_0_8635e74 ;
  wire esc_add_ln208_56_reg_7327_3__i_3_n_0_8a1f0fa ;
  wire esc_add_ln208_56_reg_7327_3__i_4_n_0_268b686 ;
  wire esc_add_ln208_56_reg_7327_3__i_5_n_0_9341fe9 ;
  wire esc_add_ln208_56_reg_7327_7__i_2_n_0_2c2dc63 ;
  wire esc_add_ln208_56_reg_7327_7__i_3_n_0_366cc97 ;
  wire esc_add_ln208_56_reg_7327_7__i_4_n_0_22a0e45 ;
  wire esc_add_ln208_56_reg_7327_7__i_5_n_0_20763ff ;
  wire [10:0]esc_add_ln208_56_reg_7327_reg_10_b6e53dd ;
  wire [10:0]esc_add_ln208_56_reg_7327_reg_10__0_e100627 ;
  wire esc_add_ln208_56_reg_7327_reg_3__i_1_n_0_f366b57 ;
  wire esc_add_ln208_56_reg_7327_reg_7__i_1_n_0_1f572be ;
  wire esc_add_ln208_59_reg_7379_3__i_2_n_0_a7c344a ;
  wire esc_add_ln208_59_reg_7379_3__i_3_n_0_de678a6 ;
  wire esc_add_ln208_59_reg_7379_3__i_4_n_0_2147988 ;
  wire esc_add_ln208_59_reg_7379_3__i_5_n_0_4b259b6 ;
  wire esc_add_ln208_59_reg_7379_7__i_2_n_0_11fb2a9 ;
  wire esc_add_ln208_59_reg_7379_7__i_3_n_0_d8843a7 ;
  wire esc_add_ln208_59_reg_7379_7__i_4_n_0_0969c35 ;
  wire esc_add_ln208_59_reg_7379_7__i_5_n_0_f16c2ea ;
  wire [11:0]esc_add_ln208_59_reg_7379_reg_10_8ef5260 ;
  wire [10:0]esc_add_ln208_59_reg_7379_reg_10__0_cb96932 ;
  wire esc_add_ln208_59_reg_7379_reg_3__i_1_n_0_8d2e0ae ;
  wire esc_add_ln208_59_reg_7379_reg_7__i_1_n_0_2c56762 ;
  wire esc_add_ln208_62_reg_7431_3__i_2_n_0_0fa8743 ;
  wire esc_add_ln208_62_reg_7431_3__i_3_n_0_c1ea5e4 ;
  wire esc_add_ln208_62_reg_7431_3__i_4_n_0_e2f7dcc ;
  wire esc_add_ln208_62_reg_7431_3__i_5_n_0_7fd5657 ;
  wire esc_add_ln208_62_reg_7431_7__i_2_n_0_12178f4 ;
  wire esc_add_ln208_62_reg_7431_7__i_3_n_0_66f10a0 ;
  wire esc_add_ln208_62_reg_7431_7__i_4_n_0_4370974 ;
  wire esc_add_ln208_62_reg_7431_7__i_5_n_0_5d4d57f ;
  wire [11:0]esc_add_ln208_62_reg_7431_reg_11_6ab2f6a ;
  wire [10:0]esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 ;
  wire esc_add_ln208_62_reg_7431_reg_3__i_1_n_0_5e8d60d ;
  wire esc_add_ln208_62_reg_7431_reg_7__i_1_n_0_9e9db93 ;
  wire esc_add_ln208_65_reg_7483_3__i_2_n_0_3cc8d84 ;
  wire esc_add_ln208_65_reg_7483_3__i_3_n_0_04aedb2 ;
  wire esc_add_ln208_65_reg_7483_3__i_4_n_0_11c8708 ;
  wire esc_add_ln208_65_reg_7483_3__i_5_n_0_2cc0bf8 ;
  wire esc_add_ln208_65_reg_7483_7__i_2_n_0_28fd2e8 ;
  wire esc_add_ln208_65_reg_7483_7__i_3_n_0_262d496 ;
  wire esc_add_ln208_65_reg_7483_7__i_4_n_0_b9e6098 ;
  wire esc_add_ln208_65_reg_7483_7__i_5_n_0_0d2516d ;
  wire [11:0]esc_add_ln208_65_reg_7483_reg_11_f154d09 ;
  wire [11:0]esc_add_ln208_65_reg_7483_reg_11__0_6caa48b ;
  wire esc_add_ln208_65_reg_7483_reg_3__i_1_n_0_e756f1b ;
  wire esc_add_ln208_65_reg_7483_reg_7__i_1_n_0_950dabc ;
  wire esc_add_ln208_68_reg_7535_3__i_2_n_0_274d44b ;
  wire esc_add_ln208_68_reg_7535_3__i_3_n_0_7d13aed ;
  wire esc_add_ln208_68_reg_7535_3__i_4_n_0_8f3859f ;
  wire esc_add_ln208_68_reg_7535_3__i_5_n_0_bba27e8 ;
  wire esc_add_ln208_68_reg_7535_7__i_2_n_0_51973bb ;
  wire esc_add_ln208_68_reg_7535_7__i_3_n_0_9701d9c ;
  wire esc_add_ln208_68_reg_7535_7__i_4_n_0_3739859 ;
  wire esc_add_ln208_68_reg_7535_7__i_5_n_0_330e570 ;
  wire [11:0]esc_add_ln208_68_reg_7535_reg_11_e9aafb9 ;
  wire [11:0]esc_add_ln208_68_reg_7535_reg_11__0_eeee088 ;
  wire esc_add_ln208_68_reg_7535_reg_3__i_1_n_0_88d4441 ;
  wire esc_add_ln208_68_reg_7535_reg_7__i_1_n_0_73fe897 ;
  wire esc_add_ln208_71_reg_7587_3__i_2_n_0_a8dae4e ;
  wire esc_add_ln208_71_reg_7587_3__i_3_n_0_114ee5f ;
  wire esc_add_ln208_71_reg_7587_3__i_4_n_0_be8afe3 ;
  wire esc_add_ln208_71_reg_7587_3__i_5_n_0_90fe6d3 ;
  wire esc_add_ln208_71_reg_7587_7__i_2_n_0_7c5afb9 ;
  wire esc_add_ln208_71_reg_7587_7__i_3_n_0_1d7135d ;
  wire esc_add_ln208_71_reg_7587_7__i_4_n_0_bd4be42 ;
  wire esc_add_ln208_71_reg_7587_7__i_5_n_0_8c1f839 ;
  wire [11:0]esc_add_ln208_71_reg_7587_reg_11_d2760f7 ;
  wire [11:0]esc_add_ln208_71_reg_7587_reg_11__0_248299a ;
  wire esc_add_ln208_71_reg_7587_reg_3__i_1_n_0_f8abe82 ;
  wire esc_add_ln208_71_reg_7587_reg_7__i_1_n_0_53cfd7e ;
  wire esc_add_ln208_74_reg_7649_3__i_2_n_0_c5286e0 ;
  wire esc_add_ln208_74_reg_7649_3__i_3_n_0_8926a2f ;
  wire esc_add_ln208_74_reg_7649_3__i_4_n_0_e414c85 ;
  wire esc_add_ln208_74_reg_7649_3__i_5_n_0_35113bd ;
  wire esc_add_ln208_74_reg_7649_7__i_2_n_0_679129b ;
  wire esc_add_ln208_74_reg_7649_7__i_3_n_0_569753f ;
  wire esc_add_ln208_74_reg_7649_7__i_4_n_0_baa5a7d ;
  wire esc_add_ln208_74_reg_7649_7__i_5_n_0_e0c49e0 ;
  wire [11:0]esc_add_ln208_74_reg_7649_reg_11_23515cd ;
  wire [11:0]esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e ;
  wire esc_add_ln208_74_reg_7649_reg_3__i_1_n_0_0cff9ec ;
  wire esc_add_ln208_74_reg_7649_reg_7__i_1_n_0_2c26d94 ;
  wire esc_add_ln208_77_reg_7711_3__i_2_n_0_6614f09 ;
  wire esc_add_ln208_77_reg_7711_3__i_3_n_0_c23a92a ;
  wire esc_add_ln208_77_reg_7711_3__i_4_n_0_58ea1da ;
  wire esc_add_ln208_77_reg_7711_3__i_5_n_0_65dffee ;
  wire esc_add_ln208_77_reg_7711_7__i_2_n_0_c7c80ab ;
  wire esc_add_ln208_77_reg_7711_7__i_3_n_0_ccff718 ;
  wire esc_add_ln208_77_reg_7711_7__i_4_n_0_6b5d261 ;
  wire esc_add_ln208_77_reg_7711_7__i_5_n_0_5b2447b ;
  wire [11:0]esc_add_ln208_77_reg_7711_reg_11_bc8d80b ;
  wire [11:0]esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 ;
  wire esc_add_ln208_77_reg_7711_reg_3__i_1_n_0_1a20c18 ;
  wire esc_add_ln208_77_reg_7711_reg_7__i_1_n_0_3d5ca1f ;
  wire esc_add_ln208_80_reg_7773_3__i_2_n_0_315c110 ;
  wire esc_add_ln208_80_reg_7773_3__i_3_n_0_ec62b69 ;
  wire esc_add_ln208_80_reg_7773_3__i_4_n_0_3a504e0 ;
  wire esc_add_ln208_80_reg_7773_3__i_5_n_0_ff5e715 ;
  wire esc_add_ln208_80_reg_7773_7__i_2_n_0_94f5558 ;
  wire esc_add_ln208_80_reg_7773_7__i_3_n_0_0371ed5 ;
  wire esc_add_ln208_80_reg_7773_7__i_4_n_0_9020c7a ;
  wire esc_add_ln208_80_reg_7773_7__i_5_n_0_5a73682 ;
  wire [11:0]esc_add_ln208_80_reg_7773_reg_11_d71fa1b ;
  wire [11:0]esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 ;
  wire esc_add_ln208_80_reg_7773_reg_3__i_1_n_0_1c656c6 ;
  wire esc_add_ln208_80_reg_7773_reg_7__i_1_n_0_6a7939e ;
  wire esc_add_ln208_83_reg_7835_3__i_2_n_0_2c30e02 ;
  wire esc_add_ln208_83_reg_7835_3__i_3_n_0_a2705c8 ;
  wire esc_add_ln208_83_reg_7835_3__i_4_n_0_3fd20a9 ;
  wire esc_add_ln208_83_reg_7835_3__i_5_n_0_df4e5dd ;
  wire esc_add_ln208_83_reg_7835_7__i_2_n_0_db5cbb8 ;
  wire esc_add_ln208_83_reg_7835_7__i_3_n_0_0eef1c3 ;
  wire esc_add_ln208_83_reg_7835_7__i_4_n_0_94198d9 ;
  wire esc_add_ln208_83_reg_7835_7__i_5_n_0_8ac1322 ;
  wire [12:0]esc_add_ln208_83_reg_7835_reg_11_118cabd ;
  wire [11:0]esc_add_ln208_83_reg_7835_reg_11__0_741884e ;
  wire esc_add_ln208_83_reg_7835_reg_3__i_1_n_0_b982185 ;
  wire esc_add_ln208_83_reg_7835_reg_7__i_1_n_0_d78e7fe ;
  wire esc_add_ln208_86_reg_7897_3__i_2_n_0_363c320 ;
  wire esc_add_ln208_86_reg_7897_3__i_3_n_0_8929e1f ;
  wire esc_add_ln208_86_reg_7897_3__i_4_n_0_1e9e4c1 ;
  wire esc_add_ln208_86_reg_7897_3__i_5_n_0_1cda033 ;
  wire esc_add_ln208_86_reg_7897_7__i_2_n_0_4a7ddc2 ;
  wire esc_add_ln208_86_reg_7897_7__i_3_n_0_dcb5d81 ;
  wire esc_add_ln208_86_reg_7897_7__i_4_n_0_d7d3b1b ;
  wire esc_add_ln208_86_reg_7897_7__i_5_n_0_5c8b5cf ;
  wire [11:0]esc_add_ln208_86_reg_7897_reg_11_897ebea ;
  wire esc_add_ln208_86_reg_7897_reg_11__i_1_n_0_0cb93a0 ;
  wire [12:0]esc_add_ln208_86_reg_7897_reg_12_202b975 ;
  wire esc_add_ln208_86_reg_7897_reg_3__i_1_n_0_0baed0f ;
  wire esc_add_ln208_86_reg_7897_reg_7__i_1_n_0_dbf3cc0 ;
  wire esc_add_ln208_89_reg_7959_3__i_2_n_0_a287011 ;
  wire esc_add_ln208_89_reg_7959_3__i_3_n_0_6f96709 ;
  wire esc_add_ln208_89_reg_7959_3__i_4_n_0_74c8e02 ;
  wire esc_add_ln208_89_reg_7959_3__i_5_n_0_5ab44a9 ;
  wire esc_add_ln208_89_reg_7959_7__i_2_n_0_88e8b5c ;
  wire esc_add_ln208_89_reg_7959_7__i_3_n_0_d34244b ;
  wire esc_add_ln208_89_reg_7959_7__i_4_n_0_ebd9be9 ;
  wire esc_add_ln208_89_reg_7959_7__i_5_n_0_960a627 ;
  wire esc_add_ln208_89_reg_7959_reg_11__i_1_n_0_ea476e8 ;
  wire [12:0]esc_add_ln208_89_reg_7959_reg_12_637a141 ;
  wire [12:0]esc_add_ln208_89_reg_7959_reg_12__0_27a5822 ;
  wire esc_add_ln208_89_reg_7959_reg_3__i_1_n_0_a180a61 ;
  wire esc_add_ln208_89_reg_7959_reg_7__i_1_n_0_a63f320 ;
  wire esc_add_ln208_92_reg_8021_3__i_2_n_0_d472932 ;
  wire esc_add_ln208_92_reg_8021_3__i_3_n_0_d031732 ;
  wire esc_add_ln208_92_reg_8021_3__i_4_n_0_0763430 ;
  wire esc_add_ln208_92_reg_8021_3__i_5_n_0_30cac59 ;
  wire esc_add_ln208_92_reg_8021_7__i_2_n_0_292e299 ;
  wire esc_add_ln208_92_reg_8021_7__i_3_n_0_2d36721 ;
  wire esc_add_ln208_92_reg_8021_7__i_4_n_0_00c4d33 ;
  wire esc_add_ln208_92_reg_8021_7__i_5_n_0_b97fd14 ;
  wire esc_add_ln208_92_reg_8021_reg_11__i_1_n_0_bbe91ac ;
  wire [12:0]esc_add_ln208_92_reg_8021_reg_12_8f48385 ;
  wire [12:0]esc_add_ln208_92_reg_8021_reg_12__0_1f8120a ;
  wire esc_add_ln208_92_reg_8021_reg_3__i_1_n_0_f486265 ;
  wire esc_add_ln208_92_reg_8021_reg_7__i_1_n_0_201e348 ;
  wire esc_add_ln208_95_reg_8083_3__i_2_n_0_11c230b ;
  wire esc_add_ln208_95_reg_8083_3__i_3_n_0_c532e3e ;
  wire esc_add_ln208_95_reg_8083_3__i_4_n_0_111f6dc ;
  wire esc_add_ln208_95_reg_8083_3__i_5_n_0_f866e80 ;
  wire esc_add_ln208_95_reg_8083_7__i_2_n_0_90a6918 ;
  wire esc_add_ln208_95_reg_8083_7__i_3_n_0_2ee3a8c ;
  wire esc_add_ln208_95_reg_8083_7__i_4_n_0_10ec784 ;
  wire esc_add_ln208_95_reg_8083_7__i_5_n_0_262aef2 ;
  wire esc_add_ln208_95_reg_8083_reg_11__i_1_n_0_6c49a8c ;
  wire [12:0]esc_add_ln208_95_reg_8083_reg_12_2d1a536 ;
  wire [12:0]esc_add_ln208_95_reg_8083_reg_12__0_30298fc ;
  wire esc_add_ln208_95_reg_8083_reg_3__i_1_n_0_3d47bc8 ;
  wire esc_add_ln208_95_reg_8083_reg_7__i_1_n_0_e2568f4 ;
  wire esc_add_ln208_98_reg_8125_3__i_2_n_0_f008b3b ;
  wire esc_add_ln208_98_reg_8125_3__i_3_n_0_896f534 ;
  wire esc_add_ln208_98_reg_8125_3__i_4_n_0_6339384 ;
  wire esc_add_ln208_98_reg_8125_3__i_5_n_0_35ff0bd ;
  wire esc_add_ln208_98_reg_8125_7__i_2_n_0_3ebfd12 ;
  wire esc_add_ln208_98_reg_8125_7__i_3_n_0_1b9adae ;
  wire esc_add_ln208_98_reg_8125_7__i_4_n_0_32ca77b ;
  wire esc_add_ln208_98_reg_8125_7__i_5_n_0_eac0e01 ;
  wire esc_add_ln208_98_reg_8125_reg_11__i_1_n_0_04189a0 ;
  wire [12:0]esc_add_ln208_98_reg_8125_reg_12_1367b81 ;
  wire [12:0]esc_add_ln208_98_reg_8125_reg_12__0_2065764 ;
  wire esc_add_ln208_98_reg_8125_reg_3__i_1_n_0_71dbc58 ;
  wire esc_add_ln208_98_reg_8125_reg_7__i_1_n_0_c586656 ;
  wire ap_clk;
  wire ap_enable_reg_pp0_iter1;
  wire ap_enable_reg_pp1_iter0;
  wire ap_enable_reg_pp1_iter1_reg;
  wire ap_enable_reg_pp3_iter0;
  wire [0:0]ap_phi_mux_y_2_phi_fu_2389_p4;
  wire blue_counts_ce0;
  wire [7:0]blue_counts_d0;
  wire blue_counts_we0;
  wire [8:0]data42;
  wire [0:0]mul_ln215_reg_6908;
  wire esc_mul_ln215_reg_6908_reg_0_b3fe01c ;
  wire esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ;
  wire esc_mul_ln215_reg_6908_reg_0__1_55582ee ;
  wire previous_blue_1_reg_6804;
  wire ram0_reg_0;
  wire ram0_reg_1;
  wire ram0_reg_10;
  wire [1:0]ram0_reg_11;
  wire ram0_reg_12;
  wire ram0_reg_13;
  wire ram0_reg_14;
  wire ram0_reg_15;
  wire ram0_reg_16;
  wire ram0_reg_17;
  wire ram0_reg_18;
  wire ram0_reg_19;
  wire ram0_reg_2;
  wire ram0_reg_20;
  wire ram0_reg_21;
  wire ram0_reg_22;
  wire ram0_reg_23;
  wire ram0_reg_24;
  wire ram0_reg_25;
  wire ram0_reg_26;
  wire ram0_reg_27;
  wire ram0_reg_28;
  wire ram0_reg_29;
  wire ram0_reg_3;
  wire [2:0]ram0_reg_30;
  wire ram0_reg_31;
  wire ram0_reg_32;
  wire ram0_reg_33;
  wire ram0_reg_34;
  wire ram0_reg_35;
  wire ram0_reg_36;
  wire ram0_reg_37;
  wire ram0_reg_38;
  wire ram0_reg_39;
  wire ram0_reg_4;
  wire ram0_reg_40;
  wire ram0_reg_41;
  wire ram0_reg_42;
  wire ram0_reg_43;
  wire ram0_reg_44;
  wire ram0_reg_45;
  wire ram0_reg_5;
  wire ram0_reg_6;
  wire [7:0]ram0_reg_7;
  wire ram0_reg_8;
  wire ram0_reg_9;
  wire ram0_reg_i_103_n_0;
  wire ram0_reg_i_10_n_0;
  wire ram0_reg_i_112_n_0;
  wire ram0_reg_i_113_n_0;
  wire ram0_reg_i_11_n_0;
  wire ram0_reg_i_12_n_0;
  wire ram0_reg_i_14_n_0;
  wire [10:0]ram0_reg_i_25_0;
  wire [10:0]ram0_reg_i_25_1;
  wire ram0_reg_i_25_n_0;
  wire ram0_reg_i_29_n_0;
  wire ram0_reg_i_2_n_0;
  wire ram0_reg_i_32_n_0;
  wire ram0_reg_i_36_n_0;
  wire ram0_reg_i_3_n_0;
  wire ram0_reg_i_42_n_0;
  wire ram0_reg_i_46_n_0;
  wire ram0_reg_i_4_n_0;
  wire ram0_reg_i_50_n_0;
  wire ram0_reg_i_51_n_0;
  wire [7:0]ram0_reg_i_53_0;
  wire ram0_reg_i_53_1;
  wire ram0_reg_i_53_2;
  wire ram0_reg_i_58_n_0;
  wire ram0_reg_i_5_n_0;
  wire ram0_reg_i_61_n_0;
  wire ram0_reg_i_65_n_0;
  wire ram0_reg_i_67_n_0;
  wire ram0_reg_i_68_n_0;
  wire ram0_reg_i_6_n_0;
  wire ram0_reg_i_75_n_0;
  wire ram0_reg_i_7_n_0;
  wire ram0_reg_i_89_n_0;
  wire ram0_reg_i_8_n_0;
  wire ram0_reg_i_94_n_0;
  wire ram0_reg_i_9__0_n_0;
  wire [13:0]zext_ln208_86_fu_5765_p1;
  wire [3:0]esc_NLW_add_ln208_101_reg_8167_reg_11__i_1_CO_UNCONNECTED_f5a36c2 ;
  wire [3:0]esc_NLW_add_ln208_101_reg_8167_reg_3__i_1_CO_UNCONNECTED_4697e93 ;
  wire [3:0]esc_NLW_add_ln208_101_reg_8167_reg_7__i_1_CO_UNCONNECTED_03a390a ;
  wire [3:0]esc_NLW_add_ln208_104_reg_8199_reg_11__i_1_CO_UNCONNECTED_6c98f1c ;
  wire [3:0]esc_NLW_add_ln208_104_reg_8199_reg_3__i_1_CO_UNCONNECTED_949eb87 ;
  wire [3:0]esc_NLW_add_ln208_104_reg_8199_reg_7__i_1_CO_UNCONNECTED_e8b7ea3 ;
  wire [3:0]esc_NLW_add_ln208_107_reg_8231_reg_11__i_1_CO_UNCONNECTED_4d6dd8d ;
  wire [3:0]esc_NLW_add_ln208_107_reg_8231_reg_3__i_1_CO_UNCONNECTED_910266c ;
  wire [3:0]esc_NLW_add_ln208_107_reg_8231_reg_7__i_1_CO_UNCONNECTED_fc8a7b9 ;
  wire [3:0]esc_NLW_add_ln208_110_reg_8263_reg_11__i_1_CO_UNCONNECTED_676035a ;
  wire [3:0]esc_NLW_add_ln208_110_reg_8263_reg_3__i_1_CO_UNCONNECTED_39673ab ;
  wire [3:0]esc_NLW_add_ln208_110_reg_8263_reg_7__i_1_CO_UNCONNECTED_c74dc38 ;
  wire [3:0]esc_NLW_add_ln208_113_reg_8295_reg_11__i_1_CO_UNCONNECTED_92723e1 ;
  wire [3:0]esc_NLW_add_ln208_113_reg_8295_reg_3__i_1_CO_UNCONNECTED_9b78498 ;
  wire [3:0]esc_NLW_add_ln208_113_reg_8295_reg_7__i_1_CO_UNCONNECTED_d4dcbdd ;
  wire [3:0]esc_NLW_add_ln208_116_reg_8327_reg_11__i_1_CO_UNCONNECTED_e0eeac4 ;
  wire [3:0]esc_NLW_add_ln208_116_reg_8327_reg_3__i_1_CO_UNCONNECTED_fef25cf ;
  wire [3:0]esc_NLW_add_ln208_116_reg_8327_reg_7__i_1_CO_UNCONNECTED_36ab947 ;
  wire [3:0]esc_NLW_add_ln208_119_reg_8359_reg_11__i_1_CO_UNCONNECTED_dae9214 ;
  wire [3:0]esc_NLW_add_ln208_119_reg_8359_reg_3__i_1_CO_UNCONNECTED_fc1fee6 ;
  wire [3:0]esc_NLW_add_ln208_119_reg_8359_reg_7__i_1_CO_UNCONNECTED_b793dff ;
  wire [3:0]esc_NLW_add_ln208_122_reg_8391_reg_11__i_1_CO_UNCONNECTED_2871b14 ;
  wire [3:0]esc_NLW_add_ln208_122_reg_8391_reg_3__i_1_CO_UNCONNECTED_d1516f0 ;
  wire [3:0]esc_NLW_add_ln208_122_reg_8391_reg_7__i_1_CO_UNCONNECTED_4c81e6e ;
  wire [3:0]esc_NLW_add_ln208_125_reg_8423_reg_11__i_1_CO_UNCONNECTED_d91b9a4 ;
  wire [3:0]esc_NLW_add_ln208_125_reg_8423_reg_3__i_1_CO_UNCONNECTED_00654ed ;
  wire [3:0]esc_NLW_add_ln208_125_reg_8423_reg_7__i_1_CO_UNCONNECTED_adf1474 ;
  wire [3:0]esc_NLW_add_ln208_128_reg_8455_reg_11__i_1_CO_UNCONNECTED_ddbfc67 ;
  wire [3:0]esc_NLW_add_ln208_128_reg_8455_reg_3__i_1_CO_UNCONNECTED_18d4305 ;
  wire [3:0]esc_NLW_add_ln208_128_reg_8455_reg_7__i_1_CO_UNCONNECTED_890ce7f ;
  wire [3:0]esc_NLW_add_ln208_131_reg_8487_reg_11__i_1_CO_UNCONNECTED_8d0dfa6 ;
  wire [3:0]esc_NLW_add_ln208_131_reg_8487_reg_3__i_1_CO_UNCONNECTED_ed4b886 ;
  wire [3:0]esc_NLW_add_ln208_131_reg_8487_reg_7__i_1_CO_UNCONNECTED_386230f ;
  wire [3:0]esc_NLW_add_ln208_134_reg_8519_reg_11__i_1_CO_UNCONNECTED_b8ef1cc ;
  wire [3:0]esc_NLW_add_ln208_134_reg_8519_reg_13__i_2_CO_UNCONNECTED_a4b9dad ;
  wire [3:0]esc_NLW_add_ln208_134_reg_8519_reg_3__i_1_CO_UNCONNECTED_a31ce89 ;
  wire [3:0]esc_NLW_add_ln208_134_reg_8519_reg_7__i_1_CO_UNCONNECTED_1af465d ;
  wire [3:0]esc_NLW_add_ln208_137_reg_8551_reg_11__i_1_CO_UNCONNECTED_ec24eca ;
  wire [3:0]esc_NLW_add_ln208_137_reg_8551_reg_3__i_1_CO_UNCONNECTED_be9e1e0 ;
  wire [3:0]esc_NLW_add_ln208_137_reg_8551_reg_7__i_1_CO_UNCONNECTED_45b7a66 ;
  wire [3:0]esc_NLW_add_ln208_140_reg_8583_reg_11__i_1_CO_UNCONNECTED_ccf108c ;
  wire [3:0]esc_NLW_add_ln208_140_reg_8583_reg_3__i_1_CO_UNCONNECTED_8ebbf8f ;
  wire [3:0]esc_NLW_add_ln208_140_reg_8583_reg_7__i_1_CO_UNCONNECTED_c4423df ;
  wire [3:0]esc_NLW_add_ln208_143_reg_8615_reg_11__i_1_CO_UNCONNECTED_63c0eaf ;
  wire [3:0]esc_NLW_add_ln208_143_reg_8615_reg_3__i_1_CO_UNCONNECTED_5959e1f ;
  wire [3:0]esc_NLW_add_ln208_143_reg_8615_reg_7__i_1_CO_UNCONNECTED_ef1bbcc ;
  wire [3:0]esc_NLW_add_ln208_146_reg_8647_reg_11__i_1_CO_UNCONNECTED_2fb2c09 ;
  wire [3:0]esc_NLW_add_ln208_146_reg_8647_reg_3__i_1_CO_UNCONNECTED_a97048d ;
  wire [3:0]esc_NLW_add_ln208_146_reg_8647_reg_7__i_1_CO_UNCONNECTED_9f8b11c ;
  wire [3:0]esc_NLW_add_ln208_149_reg_8679_reg_11__i_1_CO_UNCONNECTED_2fd82b6 ;
  wire [3:0]esc_NLW_add_ln208_149_reg_8679_reg_3__i_1_CO_UNCONNECTED_2556e63 ;
  wire [3:0]esc_NLW_add_ln208_149_reg_8679_reg_7__i_1_CO_UNCONNECTED_72c72db ;
  wire [3:0]esc_NLW_add_ln208_152_reg_8711_reg_11__i_1_CO_UNCONNECTED_da760e3 ;
  wire [3:0]esc_NLW_add_ln208_152_reg_8711_reg_3__i_1_CO_UNCONNECTED_8ee9dfe ;
  wire [3:0]esc_NLW_add_ln208_152_reg_8711_reg_7__i_1_CO_UNCONNECTED_3274c78 ;
  wire [3:0]esc_NLW_add_ln208_39_reg_8728_reg_11__i_2_CO_UNCONNECTED_5c5c086 ;
  wire [3:0]esc_NLW_add_ln208_39_reg_8728_reg_3__i_2_CO_UNCONNECTED_9e15017 ;
  wire [3:0]esc_NLW_add_ln208_39_reg_8728_reg_7__i_2_CO_UNCONNECTED_861159c ;
  wire [3:0]esc_NLW_add_ln208_40_reg_7067_reg_3__i_1_CO_UNCONNECTED_64d71c2 ;
  wire [3:0]esc_NLW_add_ln208_40_reg_7067_reg_7__i_1_CO_UNCONNECTED_246c155 ;
  wire [3:0]esc_NLW_add_ln208_44_reg_7119_reg_3__i_1_CO_UNCONNECTED_99df3c0 ;
  wire [3:0]esc_NLW_add_ln208_44_reg_7119_reg_7__i_1_CO_UNCONNECTED_4383b86 ;
  wire [3:0]esc_NLW_add_ln208_44_reg_7119_reg_9__i_2_CO_UNCONNECTED_a4935c4 ;
  wire [3:0]esc_NLW_add_ln208_47_reg_7171_reg_3__i_1_CO_UNCONNECTED_58087cc ;
  wire [3:0]esc_NLW_add_ln208_47_reg_7171_reg_7__i_1_CO_UNCONNECTED_0c681f4 ;
  wire [3:0]esc_NLW_add_ln208_50_reg_7223_reg_10__i_2_CO_UNCONNECTED_0b7b42a ;
  wire [3:0]esc_NLW_add_ln208_50_reg_7223_reg_3__i_1_CO_UNCONNECTED_0841f61 ;
  wire [3:0]esc_NLW_add_ln208_50_reg_7223_reg_7__i_1_CO_UNCONNECTED_d141306 ;
  wire [3:0]esc_NLW_add_ln208_53_reg_7275_reg_3__i_1_CO_UNCONNECTED_973a58c ;
  wire [3:0]esc_NLW_add_ln208_53_reg_7275_reg_7__i_1_CO_UNCONNECTED_8d21bf0 ;
  wire [3:0]esc_NLW_add_ln208_56_reg_7327_reg_3__i_1_CO_UNCONNECTED_aaa1e10 ;
  wire [3:0]esc_NLW_add_ln208_56_reg_7327_reg_7__i_1_CO_UNCONNECTED_693ccdd ;
  wire [3:0]esc_NLW_add_ln208_59_reg_7379_reg_3__i_1_CO_UNCONNECTED_6fd1f0c ;
  wire [3:0]esc_NLW_add_ln208_59_reg_7379_reg_7__i_1_CO_UNCONNECTED_29a5f86 ;
  wire [3:0]esc_NLW_add_ln208_62_reg_7431_reg_11__i_2_CO_UNCONNECTED_709ade5 ;
  wire [3:0]esc_NLW_add_ln208_62_reg_7431_reg_3__i_1_CO_UNCONNECTED_b41439c ;
  wire [3:0]esc_NLW_add_ln208_62_reg_7431_reg_7__i_1_CO_UNCONNECTED_c4eef1c ;
  wire [3:0]esc_NLW_add_ln208_65_reg_7483_reg_3__i_1_CO_UNCONNECTED_639670e ;
  wire [3:0]esc_NLW_add_ln208_65_reg_7483_reg_7__i_1_CO_UNCONNECTED_f000cec ;
  wire [3:0]esc_NLW_add_ln208_68_reg_7535_reg_3__i_1_CO_UNCONNECTED_b8e46ce ;
  wire [3:0]esc_NLW_add_ln208_68_reg_7535_reg_7__i_1_CO_UNCONNECTED_1e8137c ;
  wire [3:0]esc_NLW_add_ln208_71_reg_7587_reg_3__i_1_CO_UNCONNECTED_98283f7 ;
  wire [3:0]esc_NLW_add_ln208_71_reg_7587_reg_7__i_1_CO_UNCONNECTED_cf5fbb8 ;
  wire [3:0]esc_NLW_add_ln208_74_reg_7649_reg_3__i_1_CO_UNCONNECTED_0c7d911 ;
  wire [3:0]esc_NLW_add_ln208_74_reg_7649_reg_7__i_1_CO_UNCONNECTED_3a0e76c ;
  wire [3:0]esc_NLW_add_ln208_77_reg_7711_reg_3__i_1_CO_UNCONNECTED_ebae6ed ;
  wire [3:0]esc_NLW_add_ln208_77_reg_7711_reg_7__i_1_CO_UNCONNECTED_988ee92 ;
  wire [3:0]esc_NLW_add_ln208_80_reg_7773_reg_3__i_1_CO_UNCONNECTED_d853d52 ;
  wire [3:0]esc_NLW_add_ln208_80_reg_7773_reg_7__i_1_CO_UNCONNECTED_be00f2c ;
  wire [3:0]esc_NLW_add_ln208_83_reg_7835_reg_3__i_1_CO_UNCONNECTED_f3052ac ;
  wire [3:0]esc_NLW_add_ln208_83_reg_7835_reg_7__i_1_CO_UNCONNECTED_3fcc446 ;
  wire [3:0]esc_NLW_add_ln208_86_reg_7897_reg_11__i_1_CO_UNCONNECTED_56e2b21 ;
  wire [3:0]esc_NLW_add_ln208_86_reg_7897_reg_3__i_1_CO_UNCONNECTED_14c31d4 ;
  wire [3:0]esc_NLW_add_ln208_86_reg_7897_reg_7__i_1_CO_UNCONNECTED_aa082d5 ;
  wire [3:0]esc_NLW_add_ln208_89_reg_7959_reg_11__i_1_CO_UNCONNECTED_1d49898 ;
  wire [3:0]esc_NLW_add_ln208_89_reg_7959_reg_3__i_1_CO_UNCONNECTED_2920456 ;
  wire [3:0]esc_NLW_add_ln208_89_reg_7959_reg_7__i_1_CO_UNCONNECTED_8c03365 ;
  wire [3:0]esc_NLW_add_ln208_92_reg_8021_reg_11__i_1_CO_UNCONNECTED_ebba00d ;
  wire [3:0]esc_NLW_add_ln208_92_reg_8021_reg_3__i_1_CO_UNCONNECTED_64d8cb4 ;
  wire [3:0]esc_NLW_add_ln208_92_reg_8021_reg_7__i_1_CO_UNCONNECTED_7b3a5e9 ;
  wire [3:0]esc_NLW_add_ln208_95_reg_8083_reg_11__i_1_CO_UNCONNECTED_e4ceec3 ;
  wire [3:0]esc_NLW_add_ln208_95_reg_8083_reg_3__i_1_CO_UNCONNECTED_40085d5 ;
  wire [3:0]esc_NLW_add_ln208_95_reg_8083_reg_7__i_1_CO_UNCONNECTED_02d9b36 ;
  wire [3:0]esc_NLW_add_ln208_98_reg_8125_reg_11__i_1_CO_UNCONNECTED_592cb79 ;
  wire [3:0]esc_NLW_add_ln208_98_reg_8125_reg_3__i_1_CO_UNCONNECTED_4d55cc8 ;
  wire [3:0]esc_NLW_add_ln208_98_reg_8125_reg_7__i_1_CO_UNCONNECTED_37ba7f4 ;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed GND: GND_1
  assign GND_2 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT2: esc_add_ln208_101_reg_8167_3__i_2_5dfc3be
  assign esc_add_ln208_101_reg_8167_3__i_2_n_0_38204af = ((DOADO[3]) ? (~(esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [3])) : (esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [3]));

  // Reconstructed LUT2: esc_add_ln208_101_reg_8167_3__i_3_68fb5c7
  assign esc_add_ln208_101_reg_8167_3__i_3_n_0_02c55f9 = ((DOADO[2]) ? (~(esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [2])) : (esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [2]));

  // Reconstructed LUT2: esc_add_ln208_101_reg_8167_3__i_4_c98ce9a
  assign esc_add_ln208_101_reg_8167_3__i_4_n_0_b7b8249 = ((DOADO[1]) ? (~(esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [1])) : (esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [1]));

  // Reconstructed LUT2: esc_add_ln208_101_reg_8167_3__i_5_cafd5cb
  assign esc_add_ln208_101_reg_8167_3__i_5_n_0_3bfadf9 = ((DOADO[0]) ? (~(esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [0])) : (esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [0]));

  // Reconstructed LUT2: esc_add_ln208_101_reg_8167_7__i_2_b07043a
  assign esc_add_ln208_101_reg_8167_7__i_2_n_0_3b42f32 = ((DOADO[7]) ? (~(esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [7])) : (esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [7]));

  // Reconstructed LUT2: esc_add_ln208_101_reg_8167_7__i_3_843e39e
  assign esc_add_ln208_101_reg_8167_7__i_3_n_0_0150c91 = ((DOADO[6]) ? (~(esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [6])) : (esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [6]));

  // Reconstructed LUT2: esc_add_ln208_101_reg_8167_7__i_4_feee51a
  assign esc_add_ln208_101_reg_8167_7__i_4_n_0_cdbe992 = ((DOADO[5]) ? (~(esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [5])) : (esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [5]));

  // Reconstructed LUT2: esc_add_ln208_101_reg_8167_7__i_5_942fb7f
  assign esc_add_ln208_101_reg_8167_7__i_5_n_0_e128efc = ((DOADO[4]) ? (~(esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [4])) : (esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [4]));

  // Reconstructed CARRY4: esc_add_ln208_101_reg_8167_reg_11__i_1_3cd291b
  wire [3:0] recovered_12_co, recovered_12_o, recovered_12_s, recovered_12_di;
  assign recovered_12_s = esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [11:8];
  assign recovered_12_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_12_ci = ((esc_add_ln208_101_reg_8167_reg_7__i_1_n_0_1522780) !== 1'bz) && (esc_add_ln208_101_reg_8167_reg_7__i_1_n_0_1522780);
  wire recovered_12_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_12_o[0] = recovered_12_s[0] ^ (recovered_12_ci || recovered_12_cy);
  assign recovered_12_co[0] = (recovered_12_s[0] & (recovered_12_ci || recovered_12_cy)) | (~recovered_12_s[0] & recovered_12_di[0]);
  assign recovered_12_o[1] = recovered_12_s[1] ^ recovered_12_co[0];
  assign recovered_12_co[1] = (recovered_12_s[1] & recovered_12_co[0]) | (~recovered_12_s[1] & recovered_12_di[1]);
  assign recovered_12_o[2] = recovered_12_s[2] ^ recovered_12_co[1];
  assign recovered_12_co[2] = (recovered_12_s[2] & recovered_12_co[1]) | (~recovered_12_s[2] & recovered_12_di[2]);
  assign recovered_12_o[3] = recovered_12_s[3] ^ recovered_12_co[2];
  assign recovered_12_co[3] = (recovered_12_s[3] & recovered_12_co[2]) | (~recovered_12_s[3] & recovered_12_di[3]);
  assign {esc_add_ln208_101_reg_8167_reg_11__i_1_n_0_d02e3e3 ,esc_NLW_add_ln208_101_reg_8167_reg_11__i_1_CO_UNCONNECTED_f5a36c2 [2:0]} = recovered_12_co;
  assign esc_add_ln208_98_reg_8125_reg_12_1367b81 [11:8] = recovered_12_o;

  // Reconstructed CARRY4: esc_add_ln208_101_reg_8167_reg_12__i_2_2210957
  wire [3:0] recovered_13_co, recovered_13_o, recovered_13_s, recovered_13_di;
  assign recovered_13_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [12]};
  assign recovered_13_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_13_ci = ((esc_add_ln208_101_reg_8167_reg_11__i_1_n_0_d02e3e3) !== 1'bz) && (esc_add_ln208_101_reg_8167_reg_11__i_1_n_0_d02e3e3);
  wire recovered_13_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_13_o[0] = recovered_13_s[0] ^ (recovered_13_ci || recovered_13_cy);
  assign recovered_13_co[0] = (recovered_13_s[0] & (recovered_13_ci || recovered_13_cy)) | (~recovered_13_s[0] & recovered_13_di[0]);
  assign recovered_13_o[1] = recovered_13_s[1] ^ recovered_13_co[0];
  assign recovered_13_co[1] = (recovered_13_s[1] & recovered_13_co[0]) | (~recovered_13_s[1] & recovered_13_di[1]);
  assign recovered_13_o[2] = recovered_13_s[2] ^ recovered_13_co[1];
  assign recovered_13_co[2] = (recovered_13_s[2] & recovered_13_co[1]) | (~recovered_13_s[2] & recovered_13_di[2]);
  assign recovered_13_o[3] = recovered_13_s[3] ^ recovered_13_co[2];
  assign recovered_13_co[3] = (recovered_13_s[3] & recovered_13_co[2]) | (~recovered_13_s[3] & recovered_13_di[3]);
  assign esc_add_ln208_98_reg_8125_reg_12_1367b81 [12] = recovered_13_o;

  // Reconstructed CARRY4: esc_add_ln208_101_reg_8167_reg_3__i_1_b48546b
  wire [3:0] recovered_14_co, recovered_14_o, recovered_14_s, recovered_14_di;
  assign recovered_14_s = {esc_add_ln208_101_reg_8167_3__i_2_n_0_38204af ,esc_add_ln208_101_reg_8167_3__i_3_n_0_02c55f9 ,esc_add_ln208_101_reg_8167_3__i_4_n_0_b7b8249 ,esc_add_ln208_101_reg_8167_3__i_5_n_0_3bfadf9 };
  assign recovered_14_di = esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [3:0];
  wire recovered_14_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_14_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_14_o[0] = recovered_14_s[0] ^ (recovered_14_ci || recovered_14_cy);
  assign recovered_14_co[0] = (recovered_14_s[0] & (recovered_14_ci || recovered_14_cy)) | (~recovered_14_s[0] & recovered_14_di[0]);
  assign recovered_14_o[1] = recovered_14_s[1] ^ recovered_14_co[0];
  assign recovered_14_co[1] = (recovered_14_s[1] & recovered_14_co[0]) | (~recovered_14_s[1] & recovered_14_di[1]);
  assign recovered_14_o[2] = recovered_14_s[2] ^ recovered_14_co[1];
  assign recovered_14_co[2] = (recovered_14_s[2] & recovered_14_co[1]) | (~recovered_14_s[2] & recovered_14_di[2]);
  assign recovered_14_o[3] = recovered_14_s[3] ^ recovered_14_co[2];
  assign recovered_14_co[3] = (recovered_14_s[3] & recovered_14_co[2]) | (~recovered_14_s[3] & recovered_14_di[3]);
  assign {esc_add_ln208_101_reg_8167_reg_3__i_1_n_0_5c68086 ,esc_NLW_add_ln208_101_reg_8167_reg_3__i_1_CO_UNCONNECTED_4697e93 [2:0]} = recovered_14_co;
  assign esc_add_ln208_98_reg_8125_reg_12_1367b81 [3:0] = recovered_14_o;

  // Reconstructed CARRY4: esc_add_ln208_101_reg_8167_reg_7__i_1_f26de60
  wire [3:0] recovered_15_co, recovered_15_o, recovered_15_s, recovered_15_di;
  assign recovered_15_s = {esc_add_ln208_101_reg_8167_7__i_2_n_0_3b42f32 ,esc_add_ln208_101_reg_8167_7__i_3_n_0_0150c91 ,esc_add_ln208_101_reg_8167_7__i_4_n_0_cdbe992 ,esc_add_ln208_101_reg_8167_7__i_5_n_0_e128efc };
  assign recovered_15_di = esc_add_ln208_101_reg_8167_reg_12__0_0cb81b2 [7:4];
  wire recovered_15_ci = ((esc_add_ln208_101_reg_8167_reg_3__i_1_n_0_5c68086) !== 1'bz) && (esc_add_ln208_101_reg_8167_reg_3__i_1_n_0_5c68086);
  wire recovered_15_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_15_o[0] = recovered_15_s[0] ^ (recovered_15_ci || recovered_15_cy);
  assign recovered_15_co[0] = (recovered_15_s[0] & (recovered_15_ci || recovered_15_cy)) | (~recovered_15_s[0] & recovered_15_di[0]);
  assign recovered_15_o[1] = recovered_15_s[1] ^ recovered_15_co[0];
  assign recovered_15_co[1] = (recovered_15_s[1] & recovered_15_co[0]) | (~recovered_15_s[1] & recovered_15_di[1]);
  assign recovered_15_o[2] = recovered_15_s[2] ^ recovered_15_co[1];
  assign recovered_15_co[2] = (recovered_15_s[2] & recovered_15_co[1]) | (~recovered_15_s[2] & recovered_15_di[2]);
  assign recovered_15_o[3] = recovered_15_s[3] ^ recovered_15_co[2];
  assign recovered_15_co[3] = (recovered_15_s[3] & recovered_15_co[2]) | (~recovered_15_s[3] & recovered_15_di[3]);
  assign {esc_add_ln208_101_reg_8167_reg_7__i_1_n_0_1522780 ,esc_NLW_add_ln208_101_reg_8167_reg_7__i_1_CO_UNCONNECTED_03a390a [2:0]} = recovered_15_co;
  assign esc_add_ln208_98_reg_8125_reg_12_1367b81 [7:4] = recovered_15_o;

  // Reconstructed LUT2: esc_add_ln208_104_reg_8199_3__i_2_4bfdb9c
  assign esc_add_ln208_104_reg_8199_3__i_2_n_0_c1dff9c = ((DOADO[3]) ? (~(esc_add_ln208_104_reg_8199_reg_12__0_418f127 [3])) : (esc_add_ln208_104_reg_8199_reg_12__0_418f127 [3]));

  // Reconstructed LUT2: esc_add_ln208_104_reg_8199_3__i_3_fe687a4
  assign esc_add_ln208_104_reg_8199_3__i_3_n_0_dbb8c7d = ((DOADO[2]) ? (~(esc_add_ln208_104_reg_8199_reg_12__0_418f127 [2])) : (esc_add_ln208_104_reg_8199_reg_12__0_418f127 [2]));

  // Reconstructed LUT2: esc_add_ln208_104_reg_8199_3__i_4_ca83058
  assign esc_add_ln208_104_reg_8199_3__i_4_n_0_ed69558 = ((DOADO[1]) ? (~(esc_add_ln208_104_reg_8199_reg_12__0_418f127 [1])) : (esc_add_ln208_104_reg_8199_reg_12__0_418f127 [1]));

  // Reconstructed LUT2: esc_add_ln208_104_reg_8199_3__i_5_da0e7f9
  assign esc_add_ln208_104_reg_8199_3__i_5_n_0_cd7aa00 = ((DOADO[0]) ? (~(esc_add_ln208_104_reg_8199_reg_12__0_418f127 [0])) : (esc_add_ln208_104_reg_8199_reg_12__0_418f127 [0]));

  // Reconstructed LUT2: esc_add_ln208_104_reg_8199_7__i_2_59f2705
  assign esc_add_ln208_104_reg_8199_7__i_2_n_0_8861246 = ((DOADO[7]) ? (~(esc_add_ln208_104_reg_8199_reg_12__0_418f127 [7])) : (esc_add_ln208_104_reg_8199_reg_12__0_418f127 [7]));

  // Reconstructed LUT2: esc_add_ln208_104_reg_8199_7__i_3_e7b2a35
  assign esc_add_ln208_104_reg_8199_7__i_3_n_0_3c7afa6 = ((DOADO[6]) ? (~(esc_add_ln208_104_reg_8199_reg_12__0_418f127 [6])) : (esc_add_ln208_104_reg_8199_reg_12__0_418f127 [6]));

  // Reconstructed LUT2: esc_add_ln208_104_reg_8199_7__i_4_e68adc3
  assign esc_add_ln208_104_reg_8199_7__i_4_n_0_bac7a4c = ((DOADO[5]) ? (~(esc_add_ln208_104_reg_8199_reg_12__0_418f127 [5])) : (esc_add_ln208_104_reg_8199_reg_12__0_418f127 [5]));

  // Reconstructed LUT2: esc_add_ln208_104_reg_8199_7__i_5_cee7d7d
  assign esc_add_ln208_104_reg_8199_7__i_5_n_0_e8611d4 = ((DOADO[4]) ? (~(esc_add_ln208_104_reg_8199_reg_12__0_418f127 [4])) : (esc_add_ln208_104_reg_8199_reg_12__0_418f127 [4]));

  // Reconstructed CARRY4: esc_add_ln208_104_reg_8199_reg_11__i_1_daffe32
  wire [3:0] recovered_24_co, recovered_24_o, recovered_24_s, recovered_24_di;
  assign recovered_24_s = esc_add_ln208_104_reg_8199_reg_12__0_418f127 [11:8];
  assign recovered_24_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_24_ci = ((esc_add_ln208_104_reg_8199_reg_7__i_1_n_0_17657f7) !== 1'bz) && (esc_add_ln208_104_reg_8199_reg_7__i_1_n_0_17657f7);
  wire recovered_24_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_24_o[0] = recovered_24_s[0] ^ (recovered_24_ci || recovered_24_cy);
  assign recovered_24_co[0] = (recovered_24_s[0] & (recovered_24_ci || recovered_24_cy)) | (~recovered_24_s[0] & recovered_24_di[0]);
  assign recovered_24_o[1] = recovered_24_s[1] ^ recovered_24_co[0];
  assign recovered_24_co[1] = (recovered_24_s[1] & recovered_24_co[0]) | (~recovered_24_s[1] & recovered_24_di[1]);
  assign recovered_24_o[2] = recovered_24_s[2] ^ recovered_24_co[1];
  assign recovered_24_co[2] = (recovered_24_s[2] & recovered_24_co[1]) | (~recovered_24_s[2] & recovered_24_di[2]);
  assign recovered_24_o[3] = recovered_24_s[3] ^ recovered_24_co[2];
  assign recovered_24_co[3] = (recovered_24_s[3] & recovered_24_co[2]) | (~recovered_24_s[3] & recovered_24_di[3]);
  assign {esc_add_ln208_104_reg_8199_reg_11__i_1_n_0_f1b3be7 ,esc_NLW_add_ln208_104_reg_8199_reg_11__i_1_CO_UNCONNECTED_6c98f1c [2:0]} = recovered_24_co;
  assign esc_add_ln208_101_reg_8167_reg_12_d11b77b [11:8] = recovered_24_o;

  // Reconstructed CARRY4: esc_add_ln208_104_reg_8199_reg_12__i_2_d3c37b3
  wire [3:0] recovered_25_co, recovered_25_o, recovered_25_s, recovered_25_di;
  assign recovered_25_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_104_reg_8199_reg_12__0_418f127 [12]};
  assign recovered_25_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_25_ci = ((esc_add_ln208_104_reg_8199_reg_11__i_1_n_0_f1b3be7) !== 1'bz) && (esc_add_ln208_104_reg_8199_reg_11__i_1_n_0_f1b3be7);
  wire recovered_25_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_25_o[0] = recovered_25_s[0] ^ (recovered_25_ci || recovered_25_cy);
  assign recovered_25_co[0] = (recovered_25_s[0] & (recovered_25_ci || recovered_25_cy)) | (~recovered_25_s[0] & recovered_25_di[0]);
  assign recovered_25_o[1] = recovered_25_s[1] ^ recovered_25_co[0];
  assign recovered_25_co[1] = (recovered_25_s[1] & recovered_25_co[0]) | (~recovered_25_s[1] & recovered_25_di[1]);
  assign recovered_25_o[2] = recovered_25_s[2] ^ recovered_25_co[1];
  assign recovered_25_co[2] = (recovered_25_s[2] & recovered_25_co[1]) | (~recovered_25_s[2] & recovered_25_di[2]);
  assign recovered_25_o[3] = recovered_25_s[3] ^ recovered_25_co[2];
  assign recovered_25_co[3] = (recovered_25_s[3] & recovered_25_co[2]) | (~recovered_25_s[3] & recovered_25_di[3]);
  assign esc_add_ln208_101_reg_8167_reg_12_d11b77b [12] = recovered_25_o;

  // Reconstructed CARRY4: esc_add_ln208_104_reg_8199_reg_3__i_1_a5742ad
  wire [3:0] recovered_26_co, recovered_26_o, recovered_26_s, recovered_26_di;
  assign recovered_26_s = {esc_add_ln208_104_reg_8199_3__i_2_n_0_c1dff9c ,esc_add_ln208_104_reg_8199_3__i_3_n_0_dbb8c7d ,esc_add_ln208_104_reg_8199_3__i_4_n_0_ed69558 ,esc_add_ln208_104_reg_8199_3__i_5_n_0_cd7aa00 };
  assign recovered_26_di = esc_add_ln208_104_reg_8199_reg_12__0_418f127 [3:0];
  wire recovered_26_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_26_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_26_o[0] = recovered_26_s[0] ^ (recovered_26_ci || recovered_26_cy);
  assign recovered_26_co[0] = (recovered_26_s[0] & (recovered_26_ci || recovered_26_cy)) | (~recovered_26_s[0] & recovered_26_di[0]);
  assign recovered_26_o[1] = recovered_26_s[1] ^ recovered_26_co[0];
  assign recovered_26_co[1] = (recovered_26_s[1] & recovered_26_co[0]) | (~recovered_26_s[1] & recovered_26_di[1]);
  assign recovered_26_o[2] = recovered_26_s[2] ^ recovered_26_co[1];
  assign recovered_26_co[2] = (recovered_26_s[2] & recovered_26_co[1]) | (~recovered_26_s[2] & recovered_26_di[2]);
  assign recovered_26_o[3] = recovered_26_s[3] ^ recovered_26_co[2];
  assign recovered_26_co[3] = (recovered_26_s[3] & recovered_26_co[2]) | (~recovered_26_s[3] & recovered_26_di[3]);
  assign {esc_add_ln208_104_reg_8199_reg_3__i_1_n_0_5a8fe27 ,esc_NLW_add_ln208_104_reg_8199_reg_3__i_1_CO_UNCONNECTED_949eb87 [2:0]} = recovered_26_co;
  assign esc_add_ln208_101_reg_8167_reg_12_d11b77b [3:0] = recovered_26_o;

  // Reconstructed CARRY4: esc_add_ln208_104_reg_8199_reg_7__i_1_f305c0c
  wire [3:0] recovered_27_co, recovered_27_o, recovered_27_s, recovered_27_di;
  assign recovered_27_s = {esc_add_ln208_104_reg_8199_7__i_2_n_0_8861246 ,esc_add_ln208_104_reg_8199_7__i_3_n_0_3c7afa6 ,esc_add_ln208_104_reg_8199_7__i_4_n_0_bac7a4c ,esc_add_ln208_104_reg_8199_7__i_5_n_0_e8611d4 };
  assign recovered_27_di = esc_add_ln208_104_reg_8199_reg_12__0_418f127 [7:4];
  wire recovered_27_ci = ((esc_add_ln208_104_reg_8199_reg_3__i_1_n_0_5a8fe27) !== 1'bz) && (esc_add_ln208_104_reg_8199_reg_3__i_1_n_0_5a8fe27);
  wire recovered_27_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_27_o[0] = recovered_27_s[0] ^ (recovered_27_ci || recovered_27_cy);
  assign recovered_27_co[0] = (recovered_27_s[0] & (recovered_27_ci || recovered_27_cy)) | (~recovered_27_s[0] & recovered_27_di[0]);
  assign recovered_27_o[1] = recovered_27_s[1] ^ recovered_27_co[0];
  assign recovered_27_co[1] = (recovered_27_s[1] & recovered_27_co[0]) | (~recovered_27_s[1] & recovered_27_di[1]);
  assign recovered_27_o[2] = recovered_27_s[2] ^ recovered_27_co[1];
  assign recovered_27_co[2] = (recovered_27_s[2] & recovered_27_co[1]) | (~recovered_27_s[2] & recovered_27_di[2]);
  assign recovered_27_o[3] = recovered_27_s[3] ^ recovered_27_co[2];
  assign recovered_27_co[3] = (recovered_27_s[3] & recovered_27_co[2]) | (~recovered_27_s[3] & recovered_27_di[3]);
  assign {esc_add_ln208_104_reg_8199_reg_7__i_1_n_0_17657f7 ,esc_NLW_add_ln208_104_reg_8199_reg_7__i_1_CO_UNCONNECTED_e8b7ea3 [2:0]} = recovered_27_co;
  assign esc_add_ln208_101_reg_8167_reg_12_d11b77b [7:4] = recovered_27_o;

  // Reconstructed LUT2: esc_add_ln208_107_reg_8231_3__i_2_6d9c53f
  assign esc_add_ln208_107_reg_8231_3__i_2_n_0_4a148f0 = ((DOADO[3]) ? (~(esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [3])) : (esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [3]));

  // Reconstructed LUT2: esc_add_ln208_107_reg_8231_3__i_3_d8fb241
  assign esc_add_ln208_107_reg_8231_3__i_3_n_0_98f593f = ((DOADO[2]) ? (~(esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [2])) : (esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [2]));

  // Reconstructed LUT2: esc_add_ln208_107_reg_8231_3__i_4_e1c0aa4
  assign esc_add_ln208_107_reg_8231_3__i_4_n_0_77f1f90 = ((DOADO[1]) ? (~(esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [1])) : (esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [1]));

  // Reconstructed LUT2: esc_add_ln208_107_reg_8231_3__i_5_0b23df0
  assign esc_add_ln208_107_reg_8231_3__i_5_n_0_457f28a = ((DOADO[0]) ? (~(esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [0])) : (esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [0]));

  // Reconstructed LUT2: esc_add_ln208_107_reg_8231_7__i_2_4b81b4e
  assign esc_add_ln208_107_reg_8231_7__i_2_n_0_47c4da2 = ((DOADO[7]) ? (~(esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [7])) : (esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [7]));

  // Reconstructed LUT2: esc_add_ln208_107_reg_8231_7__i_3_c8992d6
  assign esc_add_ln208_107_reg_8231_7__i_3_n_0_c8eab89 = ((DOADO[6]) ? (~(esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [6])) : (esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [6]));

  // Reconstructed LUT2: esc_add_ln208_107_reg_8231_7__i_4_58e55de
  assign esc_add_ln208_107_reg_8231_7__i_4_n_0_155fe11 = ((DOADO[5]) ? (~(esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [5])) : (esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [5]));

  // Reconstructed LUT2: esc_add_ln208_107_reg_8231_7__i_5_434b54b
  assign esc_add_ln208_107_reg_8231_7__i_5_n_0_eef0235 = ((DOADO[4]) ? (~(esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [4])) : (esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [4]));

  // Reconstructed CARRY4: esc_add_ln208_107_reg_8231_reg_11__i_1_56c4d93
  wire [3:0] recovered_36_co, recovered_36_o, recovered_36_s, recovered_36_di;
  assign recovered_36_s = esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [11:8];
  assign recovered_36_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_36_ci = ((esc_add_ln208_107_reg_8231_reg_7__i_1_n_0_afa71e9) !== 1'bz) && (esc_add_ln208_107_reg_8231_reg_7__i_1_n_0_afa71e9);
  wire recovered_36_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_36_o[0] = recovered_36_s[0] ^ (recovered_36_ci || recovered_36_cy);
  assign recovered_36_co[0] = (recovered_36_s[0] & (recovered_36_ci || recovered_36_cy)) | (~recovered_36_s[0] & recovered_36_di[0]);
  assign recovered_36_o[1] = recovered_36_s[1] ^ recovered_36_co[0];
  assign recovered_36_co[1] = (recovered_36_s[1] & recovered_36_co[0]) | (~recovered_36_s[1] & recovered_36_di[1]);
  assign recovered_36_o[2] = recovered_36_s[2] ^ recovered_36_co[1];
  assign recovered_36_co[2] = (recovered_36_s[2] & recovered_36_co[1]) | (~recovered_36_s[2] & recovered_36_di[2]);
  assign recovered_36_o[3] = recovered_36_s[3] ^ recovered_36_co[2];
  assign recovered_36_co[3] = (recovered_36_s[3] & recovered_36_co[2]) | (~recovered_36_s[3] & recovered_36_di[3]);
  assign {esc_add_ln208_107_reg_8231_reg_11__i_1_n_0_a3bac88 ,esc_NLW_add_ln208_107_reg_8231_reg_11__i_1_CO_UNCONNECTED_4d6dd8d [2:0]} = recovered_36_co;
  assign esc_add_ln208_104_reg_8199_reg_12_b9a1976 [11:8] = recovered_36_o;

  // Reconstructed CARRY4: esc_add_ln208_107_reg_8231_reg_12__i_2_2696ba2
  wire [3:0] recovered_37_co, recovered_37_o, recovered_37_s, recovered_37_di;
  assign recovered_37_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [12]};
  assign recovered_37_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_37_ci = ((esc_add_ln208_107_reg_8231_reg_11__i_1_n_0_a3bac88) !== 1'bz) && (esc_add_ln208_107_reg_8231_reg_11__i_1_n_0_a3bac88);
  wire recovered_37_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_37_o[0] = recovered_37_s[0] ^ (recovered_37_ci || recovered_37_cy);
  assign recovered_37_co[0] = (recovered_37_s[0] & (recovered_37_ci || recovered_37_cy)) | (~recovered_37_s[0] & recovered_37_di[0]);
  assign recovered_37_o[1] = recovered_37_s[1] ^ recovered_37_co[0];
  assign recovered_37_co[1] = (recovered_37_s[1] & recovered_37_co[0]) | (~recovered_37_s[1] & recovered_37_di[1]);
  assign recovered_37_o[2] = recovered_37_s[2] ^ recovered_37_co[1];
  assign recovered_37_co[2] = (recovered_37_s[2] & recovered_37_co[1]) | (~recovered_37_s[2] & recovered_37_di[2]);
  assign recovered_37_o[3] = recovered_37_s[3] ^ recovered_37_co[2];
  assign recovered_37_co[3] = (recovered_37_s[3] & recovered_37_co[2]) | (~recovered_37_s[3] & recovered_37_di[3]);
  assign esc_add_ln208_104_reg_8199_reg_12_b9a1976 [12] = recovered_37_o;

  // Reconstructed CARRY4: esc_add_ln208_107_reg_8231_reg_3__i_1_09789a0
  wire [3:0] recovered_38_co, recovered_38_o, recovered_38_s, recovered_38_di;
  assign recovered_38_s = {esc_add_ln208_107_reg_8231_3__i_2_n_0_4a148f0 ,esc_add_ln208_107_reg_8231_3__i_3_n_0_98f593f ,esc_add_ln208_107_reg_8231_3__i_4_n_0_77f1f90 ,esc_add_ln208_107_reg_8231_3__i_5_n_0_457f28a };
  assign recovered_38_di = esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [3:0];
  wire recovered_38_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_38_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_38_o[0] = recovered_38_s[0] ^ (recovered_38_ci || recovered_38_cy);
  assign recovered_38_co[0] = (recovered_38_s[0] & (recovered_38_ci || recovered_38_cy)) | (~recovered_38_s[0] & recovered_38_di[0]);
  assign recovered_38_o[1] = recovered_38_s[1] ^ recovered_38_co[0];
  assign recovered_38_co[1] = (recovered_38_s[1] & recovered_38_co[0]) | (~recovered_38_s[1] & recovered_38_di[1]);
  assign recovered_38_o[2] = recovered_38_s[2] ^ recovered_38_co[1];
  assign recovered_38_co[2] = (recovered_38_s[2] & recovered_38_co[1]) | (~recovered_38_s[2] & recovered_38_di[2]);
  assign recovered_38_o[3] = recovered_38_s[3] ^ recovered_38_co[2];
  assign recovered_38_co[3] = (recovered_38_s[3] & recovered_38_co[2]) | (~recovered_38_s[3] & recovered_38_di[3]);
  assign {esc_add_ln208_107_reg_8231_reg_3__i_1_n_0_1910cb2 ,esc_NLW_add_ln208_107_reg_8231_reg_3__i_1_CO_UNCONNECTED_910266c [2:0]} = recovered_38_co;
  assign esc_add_ln208_104_reg_8199_reg_12_b9a1976 [3:0] = recovered_38_o;

  // Reconstructed CARRY4: esc_add_ln208_107_reg_8231_reg_7__i_1_3aaa672
  wire [3:0] recovered_39_co, recovered_39_o, recovered_39_s, recovered_39_di;
  assign recovered_39_s = {esc_add_ln208_107_reg_8231_7__i_2_n_0_47c4da2 ,esc_add_ln208_107_reg_8231_7__i_3_n_0_c8eab89 ,esc_add_ln208_107_reg_8231_7__i_4_n_0_155fe11 ,esc_add_ln208_107_reg_8231_7__i_5_n_0_eef0235 };
  assign recovered_39_di = esc_add_ln208_107_reg_8231_reg_12__0_575cc95 [7:4];
  wire recovered_39_ci = ((esc_add_ln208_107_reg_8231_reg_3__i_1_n_0_1910cb2) !== 1'bz) && (esc_add_ln208_107_reg_8231_reg_3__i_1_n_0_1910cb2);
  wire recovered_39_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_39_o[0] = recovered_39_s[0] ^ (recovered_39_ci || recovered_39_cy);
  assign recovered_39_co[0] = (recovered_39_s[0] & (recovered_39_ci || recovered_39_cy)) | (~recovered_39_s[0] & recovered_39_di[0]);
  assign recovered_39_o[1] = recovered_39_s[1] ^ recovered_39_co[0];
  assign recovered_39_co[1] = (recovered_39_s[1] & recovered_39_co[0]) | (~recovered_39_s[1] & recovered_39_di[1]);
  assign recovered_39_o[2] = recovered_39_s[2] ^ recovered_39_co[1];
  assign recovered_39_co[2] = (recovered_39_s[2] & recovered_39_co[1]) | (~recovered_39_s[2] & recovered_39_di[2]);
  assign recovered_39_o[3] = recovered_39_s[3] ^ recovered_39_co[2];
  assign recovered_39_co[3] = (recovered_39_s[3] & recovered_39_co[2]) | (~recovered_39_s[3] & recovered_39_di[3]);
  assign {esc_add_ln208_107_reg_8231_reg_7__i_1_n_0_afa71e9 ,esc_NLW_add_ln208_107_reg_8231_reg_7__i_1_CO_UNCONNECTED_fc8a7b9 [2:0]} = recovered_39_co;
  assign esc_add_ln208_104_reg_8199_reg_12_b9a1976 [7:4] = recovered_39_o;

  // Reconstructed LUT2: esc_add_ln208_110_reg_8263_3__i_2_03d6f7b
  assign esc_add_ln208_110_reg_8263_3__i_2_n_0_180133a = ((DOADO[3]) ? (~(esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [3])) : (esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [3]));

  // Reconstructed LUT2: esc_add_ln208_110_reg_8263_3__i_3_23a6cb8
  assign esc_add_ln208_110_reg_8263_3__i_3_n_0_3b5880d = ((DOADO[2]) ? (~(esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [2])) : (esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [2]));

  // Reconstructed LUT2: esc_add_ln208_110_reg_8263_3__i_4_b2460c5
  assign esc_add_ln208_110_reg_8263_3__i_4_n_0_13ae061 = ((DOADO[1]) ? (~(esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [1])) : (esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [1]));

  // Reconstructed LUT2: esc_add_ln208_110_reg_8263_3__i_5_8e265e9
  assign esc_add_ln208_110_reg_8263_3__i_5_n_0_50bd5d4 = ((DOADO[0]) ? (~(esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [0])) : (esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [0]));

  // Reconstructed LUT2: esc_add_ln208_110_reg_8263_7__i_2_504104c
  assign esc_add_ln208_110_reg_8263_7__i_2_n_0_6786063 = ((DOADO[7]) ? (~(esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [7])) : (esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [7]));

  // Reconstructed LUT2: esc_add_ln208_110_reg_8263_7__i_3_3946397
  assign esc_add_ln208_110_reg_8263_7__i_3_n_0_2a7035b = ((DOADO[6]) ? (~(esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [6])) : (esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [6]));

  // Reconstructed LUT2: esc_add_ln208_110_reg_8263_7__i_4_94a4231
  assign esc_add_ln208_110_reg_8263_7__i_4_n_0_b586c03 = ((DOADO[5]) ? (~(esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [5])) : (esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [5]));

  // Reconstructed LUT2: esc_add_ln208_110_reg_8263_7__i_5_e614453
  assign esc_add_ln208_110_reg_8263_7__i_5_n_0_1332b02 = ((DOADO[4]) ? (~(esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [4])) : (esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [4]));

  // Reconstructed CARRY4: esc_add_ln208_110_reg_8263_reg_11__i_1_3e3c503
  wire [3:0] recovered_48_co, recovered_48_o, recovered_48_s, recovered_48_di;
  assign recovered_48_s = esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [11:8];
  assign recovered_48_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_48_ci = ((esc_add_ln208_110_reg_8263_reg_7__i_1_n_0_b307750) !== 1'bz) && (esc_add_ln208_110_reg_8263_reg_7__i_1_n_0_b307750);
  wire recovered_48_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_48_o[0] = recovered_48_s[0] ^ (recovered_48_ci || recovered_48_cy);
  assign recovered_48_co[0] = (recovered_48_s[0] & (recovered_48_ci || recovered_48_cy)) | (~recovered_48_s[0] & recovered_48_di[0]);
  assign recovered_48_o[1] = recovered_48_s[1] ^ recovered_48_co[0];
  assign recovered_48_co[1] = (recovered_48_s[1] & recovered_48_co[0]) | (~recovered_48_s[1] & recovered_48_di[1]);
  assign recovered_48_o[2] = recovered_48_s[2] ^ recovered_48_co[1];
  assign recovered_48_co[2] = (recovered_48_s[2] & recovered_48_co[1]) | (~recovered_48_s[2] & recovered_48_di[2]);
  assign recovered_48_o[3] = recovered_48_s[3] ^ recovered_48_co[2];
  assign recovered_48_co[3] = (recovered_48_s[3] & recovered_48_co[2]) | (~recovered_48_s[3] & recovered_48_di[3]);
  assign {esc_add_ln208_110_reg_8263_reg_11__i_1_n_0_9d29414 ,esc_NLW_add_ln208_110_reg_8263_reg_11__i_1_CO_UNCONNECTED_676035a [2:0]} = recovered_48_co;
  assign esc_add_ln208_107_reg_8231_reg_12_85508a2 [11:8] = recovered_48_o;

  // Reconstructed CARRY4: esc_add_ln208_110_reg_8263_reg_12__i_2_4107677
  wire [3:0] recovered_49_co, recovered_49_o, recovered_49_s, recovered_49_di;
  assign recovered_49_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [12]};
  assign recovered_49_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_49_ci = ((esc_add_ln208_110_reg_8263_reg_11__i_1_n_0_9d29414) !== 1'bz) && (esc_add_ln208_110_reg_8263_reg_11__i_1_n_0_9d29414);
  wire recovered_49_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_49_o[0] = recovered_49_s[0] ^ (recovered_49_ci || recovered_49_cy);
  assign recovered_49_co[0] = (recovered_49_s[0] & (recovered_49_ci || recovered_49_cy)) | (~recovered_49_s[0] & recovered_49_di[0]);
  assign recovered_49_o[1] = recovered_49_s[1] ^ recovered_49_co[0];
  assign recovered_49_co[1] = (recovered_49_s[1] & recovered_49_co[0]) | (~recovered_49_s[1] & recovered_49_di[1]);
  assign recovered_49_o[2] = recovered_49_s[2] ^ recovered_49_co[1];
  assign recovered_49_co[2] = (recovered_49_s[2] & recovered_49_co[1]) | (~recovered_49_s[2] & recovered_49_di[2]);
  assign recovered_49_o[3] = recovered_49_s[3] ^ recovered_49_co[2];
  assign recovered_49_co[3] = (recovered_49_s[3] & recovered_49_co[2]) | (~recovered_49_s[3] & recovered_49_di[3]);
  assign esc_add_ln208_107_reg_8231_reg_12_85508a2 [12] = recovered_49_o;

  // Reconstructed CARRY4: esc_add_ln208_110_reg_8263_reg_3__i_1_14a0a84
  wire [3:0] recovered_50_co, recovered_50_o, recovered_50_s, recovered_50_di;
  assign recovered_50_s = {esc_add_ln208_110_reg_8263_3__i_2_n_0_180133a ,esc_add_ln208_110_reg_8263_3__i_3_n_0_3b5880d ,esc_add_ln208_110_reg_8263_3__i_4_n_0_13ae061 ,esc_add_ln208_110_reg_8263_3__i_5_n_0_50bd5d4 };
  assign recovered_50_di = esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [3:0];
  wire recovered_50_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_50_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_50_o[0] = recovered_50_s[0] ^ (recovered_50_ci || recovered_50_cy);
  assign recovered_50_co[0] = (recovered_50_s[0] & (recovered_50_ci || recovered_50_cy)) | (~recovered_50_s[0] & recovered_50_di[0]);
  assign recovered_50_o[1] = recovered_50_s[1] ^ recovered_50_co[0];
  assign recovered_50_co[1] = (recovered_50_s[1] & recovered_50_co[0]) | (~recovered_50_s[1] & recovered_50_di[1]);
  assign recovered_50_o[2] = recovered_50_s[2] ^ recovered_50_co[1];
  assign recovered_50_co[2] = (recovered_50_s[2] & recovered_50_co[1]) | (~recovered_50_s[2] & recovered_50_di[2]);
  assign recovered_50_o[3] = recovered_50_s[3] ^ recovered_50_co[2];
  assign recovered_50_co[3] = (recovered_50_s[3] & recovered_50_co[2]) | (~recovered_50_s[3] & recovered_50_di[3]);
  assign {esc_add_ln208_110_reg_8263_reg_3__i_1_n_0_f2d281d ,esc_NLW_add_ln208_110_reg_8263_reg_3__i_1_CO_UNCONNECTED_39673ab [2:0]} = recovered_50_co;
  assign esc_add_ln208_107_reg_8231_reg_12_85508a2 [3:0] = recovered_50_o;

  // Reconstructed CARRY4: esc_add_ln208_110_reg_8263_reg_7__i_1_64f8364
  wire [3:0] recovered_51_co, recovered_51_o, recovered_51_s, recovered_51_di;
  assign recovered_51_s = {esc_add_ln208_110_reg_8263_7__i_2_n_0_6786063 ,esc_add_ln208_110_reg_8263_7__i_3_n_0_2a7035b ,esc_add_ln208_110_reg_8263_7__i_4_n_0_b586c03 ,esc_add_ln208_110_reg_8263_7__i_5_n_0_1332b02 };
  assign recovered_51_di = esc_add_ln208_110_reg_8263_reg_12__0_42182a4 [7:4];
  wire recovered_51_ci = ((esc_add_ln208_110_reg_8263_reg_3__i_1_n_0_f2d281d) !== 1'bz) && (esc_add_ln208_110_reg_8263_reg_3__i_1_n_0_f2d281d);
  wire recovered_51_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_51_o[0] = recovered_51_s[0] ^ (recovered_51_ci || recovered_51_cy);
  assign recovered_51_co[0] = (recovered_51_s[0] & (recovered_51_ci || recovered_51_cy)) | (~recovered_51_s[0] & recovered_51_di[0]);
  assign recovered_51_o[1] = recovered_51_s[1] ^ recovered_51_co[0];
  assign recovered_51_co[1] = (recovered_51_s[1] & recovered_51_co[0]) | (~recovered_51_s[1] & recovered_51_di[1]);
  assign recovered_51_o[2] = recovered_51_s[2] ^ recovered_51_co[1];
  assign recovered_51_co[2] = (recovered_51_s[2] & recovered_51_co[1]) | (~recovered_51_s[2] & recovered_51_di[2]);
  assign recovered_51_o[3] = recovered_51_s[3] ^ recovered_51_co[2];
  assign recovered_51_co[3] = (recovered_51_s[3] & recovered_51_co[2]) | (~recovered_51_s[3] & recovered_51_di[3]);
  assign {esc_add_ln208_110_reg_8263_reg_7__i_1_n_0_b307750 ,esc_NLW_add_ln208_110_reg_8263_reg_7__i_1_CO_UNCONNECTED_c74dc38 [2:0]} = recovered_51_co;
  assign esc_add_ln208_107_reg_8231_reg_12_85508a2 [7:4] = recovered_51_o;

  // Reconstructed LUT2: esc_add_ln208_113_reg_8295_3__i_2_2c8e066
  assign esc_add_ln208_113_reg_8295_3__i_2_n_0_93a5182 = ((DOADO[3]) ? (~(esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [3])) : (esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [3]));

  // Reconstructed LUT2: esc_add_ln208_113_reg_8295_3__i_3_6ae25d3
  assign esc_add_ln208_113_reg_8295_3__i_3_n_0_6946030 = ((DOADO[2]) ? (~(esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [2])) : (esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [2]));

  // Reconstructed LUT2: esc_add_ln208_113_reg_8295_3__i_4_24554dd
  assign esc_add_ln208_113_reg_8295_3__i_4_n_0_3bfd948 = ((DOADO[1]) ? (~(esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [1])) : (esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [1]));

  // Reconstructed LUT2: esc_add_ln208_113_reg_8295_3__i_5_36f301d
  assign esc_add_ln208_113_reg_8295_3__i_5_n_0_3337824 = ((DOADO[0]) ? (~(esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [0])) : (esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [0]));

  // Reconstructed LUT2: esc_add_ln208_113_reg_8295_7__i_2_f4768e1
  assign esc_add_ln208_113_reg_8295_7__i_2_n_0_5ad978e = ((DOADO[7]) ? (~(esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [7])) : (esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [7]));

  // Reconstructed LUT2: esc_add_ln208_113_reg_8295_7__i_3_6f80daf
  assign esc_add_ln208_113_reg_8295_7__i_3_n_0_a901118 = ((DOADO[6]) ? (~(esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [6])) : (esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [6]));

  // Reconstructed LUT2: esc_add_ln208_113_reg_8295_7__i_4_21c820f
  assign esc_add_ln208_113_reg_8295_7__i_4_n_0_0f5e013 = ((DOADO[5]) ? (~(esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [5])) : (esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [5]));

  // Reconstructed LUT2: esc_add_ln208_113_reg_8295_7__i_5_1ab64d5
  assign esc_add_ln208_113_reg_8295_7__i_5_n_0_de6c861 = ((DOADO[4]) ? (~(esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [4])) : (esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [4]));

  // Reconstructed CARRY4: esc_add_ln208_113_reg_8295_reg_11__i_1_e49b830
  wire [3:0] recovered_60_co, recovered_60_o, recovered_60_s, recovered_60_di;
  assign recovered_60_s = esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [11:8];
  assign recovered_60_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_60_ci = ((esc_add_ln208_113_reg_8295_reg_7__i_1_n_0_bf6e9b2) !== 1'bz) && (esc_add_ln208_113_reg_8295_reg_7__i_1_n_0_bf6e9b2);
  wire recovered_60_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_60_o[0] = recovered_60_s[0] ^ (recovered_60_ci || recovered_60_cy);
  assign recovered_60_co[0] = (recovered_60_s[0] & (recovered_60_ci || recovered_60_cy)) | (~recovered_60_s[0] & recovered_60_di[0]);
  assign recovered_60_o[1] = recovered_60_s[1] ^ recovered_60_co[0];
  assign recovered_60_co[1] = (recovered_60_s[1] & recovered_60_co[0]) | (~recovered_60_s[1] & recovered_60_di[1]);
  assign recovered_60_o[2] = recovered_60_s[2] ^ recovered_60_co[1];
  assign recovered_60_co[2] = (recovered_60_s[2] & recovered_60_co[1]) | (~recovered_60_s[2] & recovered_60_di[2]);
  assign recovered_60_o[3] = recovered_60_s[3] ^ recovered_60_co[2];
  assign recovered_60_co[3] = (recovered_60_s[3] & recovered_60_co[2]) | (~recovered_60_s[3] & recovered_60_di[3]);
  assign {esc_add_ln208_113_reg_8295_reg_11__i_1_n_0_bbf0819 ,esc_NLW_add_ln208_113_reg_8295_reg_11__i_1_CO_UNCONNECTED_92723e1 [2:0]} = recovered_60_co;
  assign esc_add_ln208_110_reg_8263_reg_12_8c4af8a [11:8] = recovered_60_o;

  // Reconstructed CARRY4: esc_add_ln208_113_reg_8295_reg_12__i_2_b3f54ad
  wire [3:0] recovered_61_co, recovered_61_o, recovered_61_s, recovered_61_di;
  assign recovered_61_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [12]};
  assign recovered_61_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_61_ci = ((esc_add_ln208_113_reg_8295_reg_11__i_1_n_0_bbf0819) !== 1'bz) && (esc_add_ln208_113_reg_8295_reg_11__i_1_n_0_bbf0819);
  wire recovered_61_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_61_o[0] = recovered_61_s[0] ^ (recovered_61_ci || recovered_61_cy);
  assign recovered_61_co[0] = (recovered_61_s[0] & (recovered_61_ci || recovered_61_cy)) | (~recovered_61_s[0] & recovered_61_di[0]);
  assign recovered_61_o[1] = recovered_61_s[1] ^ recovered_61_co[0];
  assign recovered_61_co[1] = (recovered_61_s[1] & recovered_61_co[0]) | (~recovered_61_s[1] & recovered_61_di[1]);
  assign recovered_61_o[2] = recovered_61_s[2] ^ recovered_61_co[1];
  assign recovered_61_co[2] = (recovered_61_s[2] & recovered_61_co[1]) | (~recovered_61_s[2] & recovered_61_di[2]);
  assign recovered_61_o[3] = recovered_61_s[3] ^ recovered_61_co[2];
  assign recovered_61_co[3] = (recovered_61_s[3] & recovered_61_co[2]) | (~recovered_61_s[3] & recovered_61_di[3]);
  assign esc_add_ln208_110_reg_8263_reg_12_8c4af8a [12] = recovered_61_o;

  // Reconstructed CARRY4: esc_add_ln208_113_reg_8295_reg_3__i_1_bb37029
  wire [3:0] recovered_62_co, recovered_62_o, recovered_62_s, recovered_62_di;
  assign recovered_62_s = {esc_add_ln208_113_reg_8295_3__i_2_n_0_93a5182 ,esc_add_ln208_113_reg_8295_3__i_3_n_0_6946030 ,esc_add_ln208_113_reg_8295_3__i_4_n_0_3bfd948 ,esc_add_ln208_113_reg_8295_3__i_5_n_0_3337824 };
  assign recovered_62_di = esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [3:0];
  wire recovered_62_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_62_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_62_o[0] = recovered_62_s[0] ^ (recovered_62_ci || recovered_62_cy);
  assign recovered_62_co[0] = (recovered_62_s[0] & (recovered_62_ci || recovered_62_cy)) | (~recovered_62_s[0] & recovered_62_di[0]);
  assign recovered_62_o[1] = recovered_62_s[1] ^ recovered_62_co[0];
  assign recovered_62_co[1] = (recovered_62_s[1] & recovered_62_co[0]) | (~recovered_62_s[1] & recovered_62_di[1]);
  assign recovered_62_o[2] = recovered_62_s[2] ^ recovered_62_co[1];
  assign recovered_62_co[2] = (recovered_62_s[2] & recovered_62_co[1]) | (~recovered_62_s[2] & recovered_62_di[2]);
  assign recovered_62_o[3] = recovered_62_s[3] ^ recovered_62_co[2];
  assign recovered_62_co[3] = (recovered_62_s[3] & recovered_62_co[2]) | (~recovered_62_s[3] & recovered_62_di[3]);
  assign {esc_add_ln208_113_reg_8295_reg_3__i_1_n_0_5c2df74 ,esc_NLW_add_ln208_113_reg_8295_reg_3__i_1_CO_UNCONNECTED_9b78498 [2:0]} = recovered_62_co;
  assign esc_add_ln208_110_reg_8263_reg_12_8c4af8a [3:0] = recovered_62_o;

  // Reconstructed CARRY4: esc_add_ln208_113_reg_8295_reg_7__i_1_f04448d
  wire [3:0] recovered_63_co, recovered_63_o, recovered_63_s, recovered_63_di;
  assign recovered_63_s = {esc_add_ln208_113_reg_8295_7__i_2_n_0_5ad978e ,esc_add_ln208_113_reg_8295_7__i_3_n_0_a901118 ,esc_add_ln208_113_reg_8295_7__i_4_n_0_0f5e013 ,esc_add_ln208_113_reg_8295_7__i_5_n_0_de6c861 };
  assign recovered_63_di = esc_add_ln208_113_reg_8295_reg_12__0_1e57fb3 [7:4];
  wire recovered_63_ci = ((esc_add_ln208_113_reg_8295_reg_3__i_1_n_0_5c2df74) !== 1'bz) && (esc_add_ln208_113_reg_8295_reg_3__i_1_n_0_5c2df74);
  wire recovered_63_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_63_o[0] = recovered_63_s[0] ^ (recovered_63_ci || recovered_63_cy);
  assign recovered_63_co[0] = (recovered_63_s[0] & (recovered_63_ci || recovered_63_cy)) | (~recovered_63_s[0] & recovered_63_di[0]);
  assign recovered_63_o[1] = recovered_63_s[1] ^ recovered_63_co[0];
  assign recovered_63_co[1] = (recovered_63_s[1] & recovered_63_co[0]) | (~recovered_63_s[1] & recovered_63_di[1]);
  assign recovered_63_o[2] = recovered_63_s[2] ^ recovered_63_co[1];
  assign recovered_63_co[2] = (recovered_63_s[2] & recovered_63_co[1]) | (~recovered_63_s[2] & recovered_63_di[2]);
  assign recovered_63_o[3] = recovered_63_s[3] ^ recovered_63_co[2];
  assign recovered_63_co[3] = (recovered_63_s[3] & recovered_63_co[2]) | (~recovered_63_s[3] & recovered_63_di[3]);
  assign {esc_add_ln208_113_reg_8295_reg_7__i_1_n_0_bf6e9b2 ,esc_NLW_add_ln208_113_reg_8295_reg_7__i_1_CO_UNCONNECTED_d4dcbdd [2:0]} = recovered_63_co;
  assign esc_add_ln208_110_reg_8263_reg_12_8c4af8a [7:4] = recovered_63_o;

  // Reconstructed LUT2: esc_add_ln208_116_reg_8327_3__i_2_5aaec95
  assign esc_add_ln208_116_reg_8327_3__i_2_n_0_77e8112 = ((DOADO[3]) ? (~(esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [3])) : (esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [3]));

  // Reconstructed LUT2: esc_add_ln208_116_reg_8327_3__i_3_1b45cb9
  assign esc_add_ln208_116_reg_8327_3__i_3_n_0_060984c = ((DOADO[2]) ? (~(esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [2])) : (esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [2]));

  // Reconstructed LUT2: esc_add_ln208_116_reg_8327_3__i_4_02e12eb
  assign esc_add_ln208_116_reg_8327_3__i_4_n_0_b6afb77 = ((DOADO[1]) ? (~(esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [1])) : (esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [1]));

  // Reconstructed LUT2: esc_add_ln208_116_reg_8327_3__i_5_981e9e1
  assign esc_add_ln208_116_reg_8327_3__i_5_n_0_2a528d0 = ((DOADO[0]) ? (~(esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [0])) : (esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [0]));

  // Reconstructed LUT2: esc_add_ln208_116_reg_8327_7__i_2_b90c337
  assign esc_add_ln208_116_reg_8327_7__i_2_n_0_2081363 = ((DOADO[7]) ? (~(esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [7])) : (esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [7]));

  // Reconstructed LUT2: esc_add_ln208_116_reg_8327_7__i_3_40cb7fc
  assign esc_add_ln208_116_reg_8327_7__i_3_n_0_6f394ea = ((DOADO[6]) ? (~(esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [6])) : (esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [6]));

  // Reconstructed LUT2: esc_add_ln208_116_reg_8327_7__i_4_352b3cf
  assign esc_add_ln208_116_reg_8327_7__i_4_n_0_2682cc5 = ((DOADO[5]) ? (~(esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [5])) : (esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [5]));

  // Reconstructed LUT2: esc_add_ln208_116_reg_8327_7__i_5_763f793
  assign esc_add_ln208_116_reg_8327_7__i_5_n_0_0562e6a = ((DOADO[4]) ? (~(esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [4])) : (esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [4]));

  // Reconstructed CARRY4: esc_add_ln208_116_reg_8327_reg_11__i_1_1d15e58
  wire [3:0] recovered_72_co, recovered_72_o, recovered_72_s, recovered_72_di;
  assign recovered_72_s = esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [11:8];
  assign recovered_72_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_72_ci = ((esc_add_ln208_116_reg_8327_reg_7__i_1_n_0_8ae925b) !== 1'bz) && (esc_add_ln208_116_reg_8327_reg_7__i_1_n_0_8ae925b);
  wire recovered_72_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_72_o[0] = recovered_72_s[0] ^ (recovered_72_ci || recovered_72_cy);
  assign recovered_72_co[0] = (recovered_72_s[0] & (recovered_72_ci || recovered_72_cy)) | (~recovered_72_s[0] & recovered_72_di[0]);
  assign recovered_72_o[1] = recovered_72_s[1] ^ recovered_72_co[0];
  assign recovered_72_co[1] = (recovered_72_s[1] & recovered_72_co[0]) | (~recovered_72_s[1] & recovered_72_di[1]);
  assign recovered_72_o[2] = recovered_72_s[2] ^ recovered_72_co[1];
  assign recovered_72_co[2] = (recovered_72_s[2] & recovered_72_co[1]) | (~recovered_72_s[2] & recovered_72_di[2]);
  assign recovered_72_o[3] = recovered_72_s[3] ^ recovered_72_co[2];
  assign recovered_72_co[3] = (recovered_72_s[3] & recovered_72_co[2]) | (~recovered_72_s[3] & recovered_72_di[3]);
  assign {esc_add_ln208_116_reg_8327_reg_11__i_1_n_0_7e87537 ,esc_NLW_add_ln208_116_reg_8327_reg_11__i_1_CO_UNCONNECTED_e0eeac4 [2:0]} = recovered_72_co;
  assign esc_add_ln208_113_reg_8295_reg_12_525514a [11:8] = recovered_72_o;

  // Reconstructed CARRY4: esc_add_ln208_116_reg_8327_reg_12__i_2_9fcf5d4
  wire [3:0] recovered_73_co, recovered_73_o, recovered_73_s, recovered_73_di;
  assign recovered_73_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [12]};
  assign recovered_73_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_73_ci = ((esc_add_ln208_116_reg_8327_reg_11__i_1_n_0_7e87537) !== 1'bz) && (esc_add_ln208_116_reg_8327_reg_11__i_1_n_0_7e87537);
  wire recovered_73_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_73_o[0] = recovered_73_s[0] ^ (recovered_73_ci || recovered_73_cy);
  assign recovered_73_co[0] = (recovered_73_s[0] & (recovered_73_ci || recovered_73_cy)) | (~recovered_73_s[0] & recovered_73_di[0]);
  assign recovered_73_o[1] = recovered_73_s[1] ^ recovered_73_co[0];
  assign recovered_73_co[1] = (recovered_73_s[1] & recovered_73_co[0]) | (~recovered_73_s[1] & recovered_73_di[1]);
  assign recovered_73_o[2] = recovered_73_s[2] ^ recovered_73_co[1];
  assign recovered_73_co[2] = (recovered_73_s[2] & recovered_73_co[1]) | (~recovered_73_s[2] & recovered_73_di[2]);
  assign recovered_73_o[3] = recovered_73_s[3] ^ recovered_73_co[2];
  assign recovered_73_co[3] = (recovered_73_s[3] & recovered_73_co[2]) | (~recovered_73_s[3] & recovered_73_di[3]);
  assign esc_add_ln208_113_reg_8295_reg_12_525514a [12] = recovered_73_o;

  // Reconstructed CARRY4: esc_add_ln208_116_reg_8327_reg_3__i_1_dbed2b6
  wire [3:0] recovered_74_co, recovered_74_o, recovered_74_s, recovered_74_di;
  assign recovered_74_s = {esc_add_ln208_116_reg_8327_3__i_2_n_0_77e8112 ,esc_add_ln208_116_reg_8327_3__i_3_n_0_060984c ,esc_add_ln208_116_reg_8327_3__i_4_n_0_b6afb77 ,esc_add_ln208_116_reg_8327_3__i_5_n_0_2a528d0 };
  assign recovered_74_di = esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [3:0];
  wire recovered_74_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_74_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_74_o[0] = recovered_74_s[0] ^ (recovered_74_ci || recovered_74_cy);
  assign recovered_74_co[0] = (recovered_74_s[0] & (recovered_74_ci || recovered_74_cy)) | (~recovered_74_s[0] & recovered_74_di[0]);
  assign recovered_74_o[1] = recovered_74_s[1] ^ recovered_74_co[0];
  assign recovered_74_co[1] = (recovered_74_s[1] & recovered_74_co[0]) | (~recovered_74_s[1] & recovered_74_di[1]);
  assign recovered_74_o[2] = recovered_74_s[2] ^ recovered_74_co[1];
  assign recovered_74_co[2] = (recovered_74_s[2] & recovered_74_co[1]) | (~recovered_74_s[2] & recovered_74_di[2]);
  assign recovered_74_o[3] = recovered_74_s[3] ^ recovered_74_co[2];
  assign recovered_74_co[3] = (recovered_74_s[3] & recovered_74_co[2]) | (~recovered_74_s[3] & recovered_74_di[3]);
  assign {esc_add_ln208_116_reg_8327_reg_3__i_1_n_0_1f43223 ,esc_NLW_add_ln208_116_reg_8327_reg_3__i_1_CO_UNCONNECTED_fef25cf [2:0]} = recovered_74_co;
  assign esc_add_ln208_113_reg_8295_reg_12_525514a [3:0] = recovered_74_o;

  // Reconstructed CARRY4: esc_add_ln208_116_reg_8327_reg_7__i_1_b15ecb1
  wire [3:0] recovered_75_co, recovered_75_o, recovered_75_s, recovered_75_di;
  assign recovered_75_s = {esc_add_ln208_116_reg_8327_7__i_2_n_0_2081363 ,esc_add_ln208_116_reg_8327_7__i_3_n_0_6f394ea ,esc_add_ln208_116_reg_8327_7__i_4_n_0_2682cc5 ,esc_add_ln208_116_reg_8327_7__i_5_n_0_0562e6a };
  assign recovered_75_di = esc_add_ln208_116_reg_8327_reg_12__0_74ef5a9 [7:4];
  wire recovered_75_ci = ((esc_add_ln208_116_reg_8327_reg_3__i_1_n_0_1f43223) !== 1'bz) && (esc_add_ln208_116_reg_8327_reg_3__i_1_n_0_1f43223);
  wire recovered_75_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_75_o[0] = recovered_75_s[0] ^ (recovered_75_ci || recovered_75_cy);
  assign recovered_75_co[0] = (recovered_75_s[0] & (recovered_75_ci || recovered_75_cy)) | (~recovered_75_s[0] & recovered_75_di[0]);
  assign recovered_75_o[1] = recovered_75_s[1] ^ recovered_75_co[0];
  assign recovered_75_co[1] = (recovered_75_s[1] & recovered_75_co[0]) | (~recovered_75_s[1] & recovered_75_di[1]);
  assign recovered_75_o[2] = recovered_75_s[2] ^ recovered_75_co[1];
  assign recovered_75_co[2] = (recovered_75_s[2] & recovered_75_co[1]) | (~recovered_75_s[2] & recovered_75_di[2]);
  assign recovered_75_o[3] = recovered_75_s[3] ^ recovered_75_co[2];
  assign recovered_75_co[3] = (recovered_75_s[3] & recovered_75_co[2]) | (~recovered_75_s[3] & recovered_75_di[3]);
  assign {esc_add_ln208_116_reg_8327_reg_7__i_1_n_0_8ae925b ,esc_NLW_add_ln208_116_reg_8327_reg_7__i_1_CO_UNCONNECTED_36ab947 [2:0]} = recovered_75_co;
  assign esc_add_ln208_113_reg_8295_reg_12_525514a [7:4] = recovered_75_o;

  // Reconstructed LUT2: esc_add_ln208_119_reg_8359_3__i_2_90cc5b2
  assign esc_add_ln208_119_reg_8359_3__i_2_n_0_a1bc0c1 = ((DOADO[3]) ? (~(esc_add_ln208_119_reg_8359_reg_12__0_63393ef [3])) : (esc_add_ln208_119_reg_8359_reg_12__0_63393ef [3]));

  // Reconstructed LUT2: esc_add_ln208_119_reg_8359_3__i_3_d1023cc
  assign esc_add_ln208_119_reg_8359_3__i_3_n_0_c3c7e0e = ((DOADO[2]) ? (~(esc_add_ln208_119_reg_8359_reg_12__0_63393ef [2])) : (esc_add_ln208_119_reg_8359_reg_12__0_63393ef [2]));

  // Reconstructed LUT2: esc_add_ln208_119_reg_8359_3__i_4_9d59346
  assign esc_add_ln208_119_reg_8359_3__i_4_n_0_fa8e4af = ((DOADO[1]) ? (~(esc_add_ln208_119_reg_8359_reg_12__0_63393ef [1])) : (esc_add_ln208_119_reg_8359_reg_12__0_63393ef [1]));

  // Reconstructed LUT2: esc_add_ln208_119_reg_8359_3__i_5_e038d5b
  assign esc_add_ln208_119_reg_8359_3__i_5_n_0_c2c3d75 = ((DOADO[0]) ? (~(esc_add_ln208_119_reg_8359_reg_12__0_63393ef [0])) : (esc_add_ln208_119_reg_8359_reg_12__0_63393ef [0]));

  // Reconstructed LUT2: esc_add_ln208_119_reg_8359_7__i_2_67047f8
  assign esc_add_ln208_119_reg_8359_7__i_2_n_0_1044494 = ((DOADO[7]) ? (~(esc_add_ln208_119_reg_8359_reg_12__0_63393ef [7])) : (esc_add_ln208_119_reg_8359_reg_12__0_63393ef [7]));

  // Reconstructed LUT2: esc_add_ln208_119_reg_8359_7__i_3_8f9826a
  assign esc_add_ln208_119_reg_8359_7__i_3_n_0_2c9812d = ((DOADO[6]) ? (~(esc_add_ln208_119_reg_8359_reg_12__0_63393ef [6])) : (esc_add_ln208_119_reg_8359_reg_12__0_63393ef [6]));

  // Reconstructed LUT2: esc_add_ln208_119_reg_8359_7__i_4_a605ccf
  assign esc_add_ln208_119_reg_8359_7__i_4_n_0_e71a19a = ((DOADO[5]) ? (~(esc_add_ln208_119_reg_8359_reg_12__0_63393ef [5])) : (esc_add_ln208_119_reg_8359_reg_12__0_63393ef [5]));

  // Reconstructed LUT2: esc_add_ln208_119_reg_8359_7__i_5_4b2f507
  assign esc_add_ln208_119_reg_8359_7__i_5_n_0_4299aca = ((DOADO[4]) ? (~(esc_add_ln208_119_reg_8359_reg_12__0_63393ef [4])) : (esc_add_ln208_119_reg_8359_reg_12__0_63393ef [4]));

  // Reconstructed CARRY4: esc_add_ln208_119_reg_8359_reg_11__i_1_8af9c23
  wire [3:0] recovered_84_co, recovered_84_o, recovered_84_s, recovered_84_di;
  assign recovered_84_s = esc_add_ln208_119_reg_8359_reg_12__0_63393ef [11:8];
  assign recovered_84_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_84_ci = ((esc_add_ln208_119_reg_8359_reg_7__i_1_n_0_38bbe71) !== 1'bz) && (esc_add_ln208_119_reg_8359_reg_7__i_1_n_0_38bbe71);
  wire recovered_84_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_84_o[0] = recovered_84_s[0] ^ (recovered_84_ci || recovered_84_cy);
  assign recovered_84_co[0] = (recovered_84_s[0] & (recovered_84_ci || recovered_84_cy)) | (~recovered_84_s[0] & recovered_84_di[0]);
  assign recovered_84_o[1] = recovered_84_s[1] ^ recovered_84_co[0];
  assign recovered_84_co[1] = (recovered_84_s[1] & recovered_84_co[0]) | (~recovered_84_s[1] & recovered_84_di[1]);
  assign recovered_84_o[2] = recovered_84_s[2] ^ recovered_84_co[1];
  assign recovered_84_co[2] = (recovered_84_s[2] & recovered_84_co[1]) | (~recovered_84_s[2] & recovered_84_di[2]);
  assign recovered_84_o[3] = recovered_84_s[3] ^ recovered_84_co[2];
  assign recovered_84_co[3] = (recovered_84_s[3] & recovered_84_co[2]) | (~recovered_84_s[3] & recovered_84_di[3]);
  assign {esc_add_ln208_119_reg_8359_reg_11__i_1_n_0_cad678e ,esc_NLW_add_ln208_119_reg_8359_reg_11__i_1_CO_UNCONNECTED_dae9214 [2:0]} = recovered_84_co;
  assign esc_add_ln208_116_reg_8327_reg_12_e26cb33 [11:8] = recovered_84_o;

  // Reconstructed CARRY4: esc_add_ln208_119_reg_8359_reg_12__i_2_f6a184c
  wire [3:0] recovered_85_co, recovered_85_o, recovered_85_s, recovered_85_di;
  assign recovered_85_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_119_reg_8359_reg_12__0_63393ef [12]};
  assign recovered_85_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_85_ci = ((esc_add_ln208_119_reg_8359_reg_11__i_1_n_0_cad678e) !== 1'bz) && (esc_add_ln208_119_reg_8359_reg_11__i_1_n_0_cad678e);
  wire recovered_85_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_85_o[0] = recovered_85_s[0] ^ (recovered_85_ci || recovered_85_cy);
  assign recovered_85_co[0] = (recovered_85_s[0] & (recovered_85_ci || recovered_85_cy)) | (~recovered_85_s[0] & recovered_85_di[0]);
  assign recovered_85_o[1] = recovered_85_s[1] ^ recovered_85_co[0];
  assign recovered_85_co[1] = (recovered_85_s[1] & recovered_85_co[0]) | (~recovered_85_s[1] & recovered_85_di[1]);
  assign recovered_85_o[2] = recovered_85_s[2] ^ recovered_85_co[1];
  assign recovered_85_co[2] = (recovered_85_s[2] & recovered_85_co[1]) | (~recovered_85_s[2] & recovered_85_di[2]);
  assign recovered_85_o[3] = recovered_85_s[3] ^ recovered_85_co[2];
  assign recovered_85_co[3] = (recovered_85_s[3] & recovered_85_co[2]) | (~recovered_85_s[3] & recovered_85_di[3]);
  assign esc_add_ln208_116_reg_8327_reg_12_e26cb33 [12] = recovered_85_o;

  // Reconstructed CARRY4: esc_add_ln208_119_reg_8359_reg_3__i_1_c323e1b
  wire [3:0] recovered_86_co, recovered_86_o, recovered_86_s, recovered_86_di;
  assign recovered_86_s = {esc_add_ln208_119_reg_8359_3__i_2_n_0_a1bc0c1 ,esc_add_ln208_119_reg_8359_3__i_3_n_0_c3c7e0e ,esc_add_ln208_119_reg_8359_3__i_4_n_0_fa8e4af ,esc_add_ln208_119_reg_8359_3__i_5_n_0_c2c3d75 };
  assign recovered_86_di = esc_add_ln208_119_reg_8359_reg_12__0_63393ef [3:0];
  wire recovered_86_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_86_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_86_o[0] = recovered_86_s[0] ^ (recovered_86_ci || recovered_86_cy);
  assign recovered_86_co[0] = (recovered_86_s[0] & (recovered_86_ci || recovered_86_cy)) | (~recovered_86_s[0] & recovered_86_di[0]);
  assign recovered_86_o[1] = recovered_86_s[1] ^ recovered_86_co[0];
  assign recovered_86_co[1] = (recovered_86_s[1] & recovered_86_co[0]) | (~recovered_86_s[1] & recovered_86_di[1]);
  assign recovered_86_o[2] = recovered_86_s[2] ^ recovered_86_co[1];
  assign recovered_86_co[2] = (recovered_86_s[2] & recovered_86_co[1]) | (~recovered_86_s[2] & recovered_86_di[2]);
  assign recovered_86_o[3] = recovered_86_s[3] ^ recovered_86_co[2];
  assign recovered_86_co[3] = (recovered_86_s[3] & recovered_86_co[2]) | (~recovered_86_s[3] & recovered_86_di[3]);
  assign {esc_add_ln208_119_reg_8359_reg_3__i_1_n_0_93bdcfb ,esc_NLW_add_ln208_119_reg_8359_reg_3__i_1_CO_UNCONNECTED_fc1fee6 [2:0]} = recovered_86_co;
  assign esc_add_ln208_116_reg_8327_reg_12_e26cb33 [3:0] = recovered_86_o;

  // Reconstructed CARRY4: esc_add_ln208_119_reg_8359_reg_7__i_1_e8e62d7
  wire [3:0] recovered_87_co, recovered_87_o, recovered_87_s, recovered_87_di;
  assign recovered_87_s = {esc_add_ln208_119_reg_8359_7__i_2_n_0_1044494 ,esc_add_ln208_119_reg_8359_7__i_3_n_0_2c9812d ,esc_add_ln208_119_reg_8359_7__i_4_n_0_e71a19a ,esc_add_ln208_119_reg_8359_7__i_5_n_0_4299aca };
  assign recovered_87_di = esc_add_ln208_119_reg_8359_reg_12__0_63393ef [7:4];
  wire recovered_87_ci = ((esc_add_ln208_119_reg_8359_reg_3__i_1_n_0_93bdcfb) !== 1'bz) && (esc_add_ln208_119_reg_8359_reg_3__i_1_n_0_93bdcfb);
  wire recovered_87_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_87_o[0] = recovered_87_s[0] ^ (recovered_87_ci || recovered_87_cy);
  assign recovered_87_co[0] = (recovered_87_s[0] & (recovered_87_ci || recovered_87_cy)) | (~recovered_87_s[0] & recovered_87_di[0]);
  assign recovered_87_o[1] = recovered_87_s[1] ^ recovered_87_co[0];
  assign recovered_87_co[1] = (recovered_87_s[1] & recovered_87_co[0]) | (~recovered_87_s[1] & recovered_87_di[1]);
  assign recovered_87_o[2] = recovered_87_s[2] ^ recovered_87_co[1];
  assign recovered_87_co[2] = (recovered_87_s[2] & recovered_87_co[1]) | (~recovered_87_s[2] & recovered_87_di[2]);
  assign recovered_87_o[3] = recovered_87_s[3] ^ recovered_87_co[2];
  assign recovered_87_co[3] = (recovered_87_s[3] & recovered_87_co[2]) | (~recovered_87_s[3] & recovered_87_di[3]);
  assign {esc_add_ln208_119_reg_8359_reg_7__i_1_n_0_38bbe71 ,esc_NLW_add_ln208_119_reg_8359_reg_7__i_1_CO_UNCONNECTED_b793dff [2:0]} = recovered_87_co;
  assign esc_add_ln208_116_reg_8327_reg_12_e26cb33 [7:4] = recovered_87_o;

  // Reconstructed LUT2: esc_add_ln208_122_reg_8391_3__i_2_9a0119a
  assign esc_add_ln208_122_reg_8391_3__i_2_n_0_89a0bfd = ((DOADO[3]) ? (~(esc_add_ln208_122_reg_8391_reg_12__0_cec336a [3])) : (esc_add_ln208_122_reg_8391_reg_12__0_cec336a [3]));

  // Reconstructed LUT2: esc_add_ln208_122_reg_8391_3__i_3_73458fb
  assign esc_add_ln208_122_reg_8391_3__i_3_n_0_a44bebf = ((DOADO[2]) ? (~(esc_add_ln208_122_reg_8391_reg_12__0_cec336a [2])) : (esc_add_ln208_122_reg_8391_reg_12__0_cec336a [2]));

  // Reconstructed LUT2: esc_add_ln208_122_reg_8391_3__i_4_e3b4bbf
  assign esc_add_ln208_122_reg_8391_3__i_4_n_0_8bdf34b = ((DOADO[1]) ? (~(esc_add_ln208_122_reg_8391_reg_12__0_cec336a [1])) : (esc_add_ln208_122_reg_8391_reg_12__0_cec336a [1]));

  // Reconstructed LUT2: esc_add_ln208_122_reg_8391_3__i_5_12aa327
  assign esc_add_ln208_122_reg_8391_3__i_5_n_0_d5b0839 = ((DOADO[0]) ? (~(esc_add_ln208_122_reg_8391_reg_12__0_cec336a [0])) : (esc_add_ln208_122_reg_8391_reg_12__0_cec336a [0]));

  // Reconstructed LUT2: esc_add_ln208_122_reg_8391_7__i_2_ec86435
  assign esc_add_ln208_122_reg_8391_7__i_2_n_0_f7a33c7 = ((DOADO[7]) ? (~(esc_add_ln208_122_reg_8391_reg_12__0_cec336a [7])) : (esc_add_ln208_122_reg_8391_reg_12__0_cec336a [7]));

  // Reconstructed LUT2: esc_add_ln208_122_reg_8391_7__i_3_d42a605
  assign esc_add_ln208_122_reg_8391_7__i_3_n_0_8f1b239 = ((DOADO[6]) ? (~(esc_add_ln208_122_reg_8391_reg_12__0_cec336a [6])) : (esc_add_ln208_122_reg_8391_reg_12__0_cec336a [6]));

  // Reconstructed LUT2: esc_add_ln208_122_reg_8391_7__i_4_55b03ed
  assign esc_add_ln208_122_reg_8391_7__i_4_n_0_b294405 = ((DOADO[5]) ? (~(esc_add_ln208_122_reg_8391_reg_12__0_cec336a [5])) : (esc_add_ln208_122_reg_8391_reg_12__0_cec336a [5]));

  // Reconstructed LUT2: esc_add_ln208_122_reg_8391_7__i_5_6903deb
  assign esc_add_ln208_122_reg_8391_7__i_5_n_0_3064f83 = ((DOADO[4]) ? (~(esc_add_ln208_122_reg_8391_reg_12__0_cec336a [4])) : (esc_add_ln208_122_reg_8391_reg_12__0_cec336a [4]));

  // Reconstructed CARRY4: esc_add_ln208_122_reg_8391_reg_11__i_1_4db450c
  wire [3:0] recovered_96_co, recovered_96_o, recovered_96_s, recovered_96_di;
  assign recovered_96_s = esc_add_ln208_122_reg_8391_reg_12__0_cec336a [11:8];
  assign recovered_96_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_96_ci = ((esc_add_ln208_122_reg_8391_reg_7__i_1_n_0_988279e) !== 1'bz) && (esc_add_ln208_122_reg_8391_reg_7__i_1_n_0_988279e);
  wire recovered_96_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_96_o[0] = recovered_96_s[0] ^ (recovered_96_ci || recovered_96_cy);
  assign recovered_96_co[0] = (recovered_96_s[0] & (recovered_96_ci || recovered_96_cy)) | (~recovered_96_s[0] & recovered_96_di[0]);
  assign recovered_96_o[1] = recovered_96_s[1] ^ recovered_96_co[0];
  assign recovered_96_co[1] = (recovered_96_s[1] & recovered_96_co[0]) | (~recovered_96_s[1] & recovered_96_di[1]);
  assign recovered_96_o[2] = recovered_96_s[2] ^ recovered_96_co[1];
  assign recovered_96_co[2] = (recovered_96_s[2] & recovered_96_co[1]) | (~recovered_96_s[2] & recovered_96_di[2]);
  assign recovered_96_o[3] = recovered_96_s[3] ^ recovered_96_co[2];
  assign recovered_96_co[3] = (recovered_96_s[3] & recovered_96_co[2]) | (~recovered_96_s[3] & recovered_96_di[3]);
  assign {esc_add_ln208_122_reg_8391_reg_11__i_1_n_0_7d03e0b ,esc_NLW_add_ln208_122_reg_8391_reg_11__i_1_CO_UNCONNECTED_2871b14 [2:0]} = recovered_96_co;
  assign esc_add_ln208_119_reg_8359_reg_12_abf25fc [11:8] = recovered_96_o;

  // Reconstructed CARRY4: esc_add_ln208_122_reg_8391_reg_12__i_2_88deaad
  wire [3:0] recovered_97_co, recovered_97_o, recovered_97_s, recovered_97_di;
  assign recovered_97_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_122_reg_8391_reg_12__0_cec336a [12]};
  assign recovered_97_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_97_ci = ((esc_add_ln208_122_reg_8391_reg_11__i_1_n_0_7d03e0b) !== 1'bz) && (esc_add_ln208_122_reg_8391_reg_11__i_1_n_0_7d03e0b);
  wire recovered_97_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_97_o[0] = recovered_97_s[0] ^ (recovered_97_ci || recovered_97_cy);
  assign recovered_97_co[0] = (recovered_97_s[0] & (recovered_97_ci || recovered_97_cy)) | (~recovered_97_s[0] & recovered_97_di[0]);
  assign recovered_97_o[1] = recovered_97_s[1] ^ recovered_97_co[0];
  assign recovered_97_co[1] = (recovered_97_s[1] & recovered_97_co[0]) | (~recovered_97_s[1] & recovered_97_di[1]);
  assign recovered_97_o[2] = recovered_97_s[2] ^ recovered_97_co[1];
  assign recovered_97_co[2] = (recovered_97_s[2] & recovered_97_co[1]) | (~recovered_97_s[2] & recovered_97_di[2]);
  assign recovered_97_o[3] = recovered_97_s[3] ^ recovered_97_co[2];
  assign recovered_97_co[3] = (recovered_97_s[3] & recovered_97_co[2]) | (~recovered_97_s[3] & recovered_97_di[3]);
  assign esc_add_ln208_119_reg_8359_reg_12_abf25fc [12] = recovered_97_o;

  // Reconstructed CARRY4: esc_add_ln208_122_reg_8391_reg_3__i_1_ceb0e97
  wire [3:0] recovered_98_co, recovered_98_o, recovered_98_s, recovered_98_di;
  assign recovered_98_s = {esc_add_ln208_122_reg_8391_3__i_2_n_0_89a0bfd ,esc_add_ln208_122_reg_8391_3__i_3_n_0_a44bebf ,esc_add_ln208_122_reg_8391_3__i_4_n_0_8bdf34b ,esc_add_ln208_122_reg_8391_3__i_5_n_0_d5b0839 };
  assign recovered_98_di = esc_add_ln208_122_reg_8391_reg_12__0_cec336a [3:0];
  wire recovered_98_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_98_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_98_o[0] = recovered_98_s[0] ^ (recovered_98_ci || recovered_98_cy);
  assign recovered_98_co[0] = (recovered_98_s[0] & (recovered_98_ci || recovered_98_cy)) | (~recovered_98_s[0] & recovered_98_di[0]);
  assign recovered_98_o[1] = recovered_98_s[1] ^ recovered_98_co[0];
  assign recovered_98_co[1] = (recovered_98_s[1] & recovered_98_co[0]) | (~recovered_98_s[1] & recovered_98_di[1]);
  assign recovered_98_o[2] = recovered_98_s[2] ^ recovered_98_co[1];
  assign recovered_98_co[2] = (recovered_98_s[2] & recovered_98_co[1]) | (~recovered_98_s[2] & recovered_98_di[2]);
  assign recovered_98_o[3] = recovered_98_s[3] ^ recovered_98_co[2];
  assign recovered_98_co[3] = (recovered_98_s[3] & recovered_98_co[2]) | (~recovered_98_s[3] & recovered_98_di[3]);
  assign {esc_add_ln208_122_reg_8391_reg_3__i_1_n_0_6805bda ,esc_NLW_add_ln208_122_reg_8391_reg_3__i_1_CO_UNCONNECTED_d1516f0 [2:0]} = recovered_98_co;
  assign esc_add_ln208_119_reg_8359_reg_12_abf25fc [3:0] = recovered_98_o;

  // Reconstructed CARRY4: esc_add_ln208_122_reg_8391_reg_7__i_1_c8891bb
  wire [3:0] recovered_99_co, recovered_99_o, recovered_99_s, recovered_99_di;
  assign recovered_99_s = {esc_add_ln208_122_reg_8391_7__i_2_n_0_f7a33c7 ,esc_add_ln208_122_reg_8391_7__i_3_n_0_8f1b239 ,esc_add_ln208_122_reg_8391_7__i_4_n_0_b294405 ,esc_add_ln208_122_reg_8391_7__i_5_n_0_3064f83 };
  assign recovered_99_di = esc_add_ln208_122_reg_8391_reg_12__0_cec336a [7:4];
  wire recovered_99_ci = ((esc_add_ln208_122_reg_8391_reg_3__i_1_n_0_6805bda) !== 1'bz) && (esc_add_ln208_122_reg_8391_reg_3__i_1_n_0_6805bda);
  wire recovered_99_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_99_o[0] = recovered_99_s[0] ^ (recovered_99_ci || recovered_99_cy);
  assign recovered_99_co[0] = (recovered_99_s[0] & (recovered_99_ci || recovered_99_cy)) | (~recovered_99_s[0] & recovered_99_di[0]);
  assign recovered_99_o[1] = recovered_99_s[1] ^ recovered_99_co[0];
  assign recovered_99_co[1] = (recovered_99_s[1] & recovered_99_co[0]) | (~recovered_99_s[1] & recovered_99_di[1]);
  assign recovered_99_o[2] = recovered_99_s[2] ^ recovered_99_co[1];
  assign recovered_99_co[2] = (recovered_99_s[2] & recovered_99_co[1]) | (~recovered_99_s[2] & recovered_99_di[2]);
  assign recovered_99_o[3] = recovered_99_s[3] ^ recovered_99_co[2];
  assign recovered_99_co[3] = (recovered_99_s[3] & recovered_99_co[2]) | (~recovered_99_s[3] & recovered_99_di[3]);
  assign {esc_add_ln208_122_reg_8391_reg_7__i_1_n_0_988279e ,esc_NLW_add_ln208_122_reg_8391_reg_7__i_1_CO_UNCONNECTED_4c81e6e [2:0]} = recovered_99_co;
  assign esc_add_ln208_119_reg_8359_reg_12_abf25fc [7:4] = recovered_99_o;

  // Reconstructed LUT2: esc_add_ln208_125_reg_8423_3__i_2_2f22fc4
  assign esc_add_ln208_125_reg_8423_3__i_2_n_0_73a6811 = ((DOADO[3]) ? (~(esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [3])) : (esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [3]));

  // Reconstructed LUT2: esc_add_ln208_125_reg_8423_3__i_3_3a8c3e6
  assign esc_add_ln208_125_reg_8423_3__i_3_n_0_625f302 = ((DOADO[2]) ? (~(esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [2])) : (esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [2]));

  // Reconstructed LUT2: esc_add_ln208_125_reg_8423_3__i_4_db33aa0
  assign esc_add_ln208_125_reg_8423_3__i_4_n_0_c3ccc6e = ((DOADO[1]) ? (~(esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [1])) : (esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [1]));

  // Reconstructed LUT2: esc_add_ln208_125_reg_8423_3__i_5_0f3b036
  assign esc_add_ln208_125_reg_8423_3__i_5_n_0_b9ef9e5 = ((DOADO[0]) ? (~(esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [0])) : (esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [0]));

  // Reconstructed LUT2: esc_add_ln208_125_reg_8423_7__i_2_3172dff
  assign esc_add_ln208_125_reg_8423_7__i_2_n_0_775c9f7 = ((DOADO[7]) ? (~(esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [7])) : (esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [7]));

  // Reconstructed LUT2: esc_add_ln208_125_reg_8423_7__i_3_980a6c3
  assign esc_add_ln208_125_reg_8423_7__i_3_n_0_b69b2e5 = ((DOADO[6]) ? (~(esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [6])) : (esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [6]));

  // Reconstructed LUT2: esc_add_ln208_125_reg_8423_7__i_4_ba7d32f
  assign esc_add_ln208_125_reg_8423_7__i_4_n_0_c310702 = ((DOADO[5]) ? (~(esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [5])) : (esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [5]));

  // Reconstructed LUT2: esc_add_ln208_125_reg_8423_7__i_5_4841b34
  assign esc_add_ln208_125_reg_8423_7__i_5_n_0_7ff1805 = ((DOADO[4]) ? (~(esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [4])) : (esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [4]));

  // Reconstructed CARRY4: esc_add_ln208_125_reg_8423_reg_11__i_1_7a3a357
  wire [3:0] recovered_108_co, recovered_108_o, recovered_108_s, recovered_108_di;
  assign recovered_108_s = esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [11:8];
  assign recovered_108_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_108_ci = ((esc_add_ln208_125_reg_8423_reg_7__i_1_n_0_a51f088) !== 1'bz) && (esc_add_ln208_125_reg_8423_reg_7__i_1_n_0_a51f088);
  wire recovered_108_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_108_o[0] = recovered_108_s[0] ^ (recovered_108_ci || recovered_108_cy);
  assign recovered_108_co[0] = (recovered_108_s[0] & (recovered_108_ci || recovered_108_cy)) | (~recovered_108_s[0] & recovered_108_di[0]);
  assign recovered_108_o[1] = recovered_108_s[1] ^ recovered_108_co[0];
  assign recovered_108_co[1] = (recovered_108_s[1] & recovered_108_co[0]) | (~recovered_108_s[1] & recovered_108_di[1]);
  assign recovered_108_o[2] = recovered_108_s[2] ^ recovered_108_co[1];
  assign recovered_108_co[2] = (recovered_108_s[2] & recovered_108_co[1]) | (~recovered_108_s[2] & recovered_108_di[2]);
  assign recovered_108_o[3] = recovered_108_s[3] ^ recovered_108_co[2];
  assign recovered_108_co[3] = (recovered_108_s[3] & recovered_108_co[2]) | (~recovered_108_s[3] & recovered_108_di[3]);
  assign {esc_add_ln208_125_reg_8423_reg_11__i_1_n_0_6bf1419 ,esc_NLW_add_ln208_125_reg_8423_reg_11__i_1_CO_UNCONNECTED_d91b9a4 [2:0]} = recovered_108_co;
  assign esc_add_ln208_122_reg_8391_reg_12_c056c12 [11:8] = recovered_108_o;

  // Reconstructed CARRY4: esc_add_ln208_125_reg_8423_reg_12__i_2_02df672
  wire [3:0] recovered_109_co, recovered_109_o, recovered_109_s, recovered_109_di;
  assign recovered_109_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [12]};
  assign recovered_109_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_109_ci = ((esc_add_ln208_125_reg_8423_reg_11__i_1_n_0_6bf1419) !== 1'bz) && (esc_add_ln208_125_reg_8423_reg_11__i_1_n_0_6bf1419);
  wire recovered_109_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_109_o[0] = recovered_109_s[0] ^ (recovered_109_ci || recovered_109_cy);
  assign recovered_109_co[0] = (recovered_109_s[0] & (recovered_109_ci || recovered_109_cy)) | (~recovered_109_s[0] & recovered_109_di[0]);
  assign recovered_109_o[1] = recovered_109_s[1] ^ recovered_109_co[0];
  assign recovered_109_co[1] = (recovered_109_s[1] & recovered_109_co[0]) | (~recovered_109_s[1] & recovered_109_di[1]);
  assign recovered_109_o[2] = recovered_109_s[2] ^ recovered_109_co[1];
  assign recovered_109_co[2] = (recovered_109_s[2] & recovered_109_co[1]) | (~recovered_109_s[2] & recovered_109_di[2]);
  assign recovered_109_o[3] = recovered_109_s[3] ^ recovered_109_co[2];
  assign recovered_109_co[3] = (recovered_109_s[3] & recovered_109_co[2]) | (~recovered_109_s[3] & recovered_109_di[3]);
  assign esc_add_ln208_122_reg_8391_reg_12_c056c12 [12] = recovered_109_o;

  // Reconstructed CARRY4: esc_add_ln208_125_reg_8423_reg_3__i_1_d7f297c
  wire [3:0] recovered_110_co, recovered_110_o, recovered_110_s, recovered_110_di;
  assign recovered_110_s = {esc_add_ln208_125_reg_8423_3__i_2_n_0_73a6811 ,esc_add_ln208_125_reg_8423_3__i_3_n_0_625f302 ,esc_add_ln208_125_reg_8423_3__i_4_n_0_c3ccc6e ,esc_add_ln208_125_reg_8423_3__i_5_n_0_b9ef9e5 };
  assign recovered_110_di = esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [3:0];
  wire recovered_110_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_110_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_110_o[0] = recovered_110_s[0] ^ (recovered_110_ci || recovered_110_cy);
  assign recovered_110_co[0] = (recovered_110_s[0] & (recovered_110_ci || recovered_110_cy)) | (~recovered_110_s[0] & recovered_110_di[0]);
  assign recovered_110_o[1] = recovered_110_s[1] ^ recovered_110_co[0];
  assign recovered_110_co[1] = (recovered_110_s[1] & recovered_110_co[0]) | (~recovered_110_s[1] & recovered_110_di[1]);
  assign recovered_110_o[2] = recovered_110_s[2] ^ recovered_110_co[1];
  assign recovered_110_co[2] = (recovered_110_s[2] & recovered_110_co[1]) | (~recovered_110_s[2] & recovered_110_di[2]);
  assign recovered_110_o[3] = recovered_110_s[3] ^ recovered_110_co[2];
  assign recovered_110_co[3] = (recovered_110_s[3] & recovered_110_co[2]) | (~recovered_110_s[3] & recovered_110_di[3]);
  assign {esc_add_ln208_125_reg_8423_reg_3__i_1_n_0_03feca3 ,esc_NLW_add_ln208_125_reg_8423_reg_3__i_1_CO_UNCONNECTED_00654ed [2:0]} = recovered_110_co;
  assign esc_add_ln208_122_reg_8391_reg_12_c056c12 [3:0] = recovered_110_o;

  // Reconstructed CARRY4: esc_add_ln208_125_reg_8423_reg_7__i_1_7ce86bd
  wire [3:0] recovered_111_co, recovered_111_o, recovered_111_s, recovered_111_di;
  assign recovered_111_s = {esc_add_ln208_125_reg_8423_7__i_2_n_0_775c9f7 ,esc_add_ln208_125_reg_8423_7__i_3_n_0_b69b2e5 ,esc_add_ln208_125_reg_8423_7__i_4_n_0_c310702 ,esc_add_ln208_125_reg_8423_7__i_5_n_0_7ff1805 };
  assign recovered_111_di = esc_add_ln208_125_reg_8423_reg_12__0_5cba652 [7:4];
  wire recovered_111_ci = ((esc_add_ln208_125_reg_8423_reg_3__i_1_n_0_03feca3) !== 1'bz) && (esc_add_ln208_125_reg_8423_reg_3__i_1_n_0_03feca3);
  wire recovered_111_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_111_o[0] = recovered_111_s[0] ^ (recovered_111_ci || recovered_111_cy);
  assign recovered_111_co[0] = (recovered_111_s[0] & (recovered_111_ci || recovered_111_cy)) | (~recovered_111_s[0] & recovered_111_di[0]);
  assign recovered_111_o[1] = recovered_111_s[1] ^ recovered_111_co[0];
  assign recovered_111_co[1] = (recovered_111_s[1] & recovered_111_co[0]) | (~recovered_111_s[1] & recovered_111_di[1]);
  assign recovered_111_o[2] = recovered_111_s[2] ^ recovered_111_co[1];
  assign recovered_111_co[2] = (recovered_111_s[2] & recovered_111_co[1]) | (~recovered_111_s[2] & recovered_111_di[2]);
  assign recovered_111_o[3] = recovered_111_s[3] ^ recovered_111_co[2];
  assign recovered_111_co[3] = (recovered_111_s[3] & recovered_111_co[2]) | (~recovered_111_s[3] & recovered_111_di[3]);
  assign {esc_add_ln208_125_reg_8423_reg_7__i_1_n_0_a51f088 ,esc_NLW_add_ln208_125_reg_8423_reg_7__i_1_CO_UNCONNECTED_adf1474 [2:0]} = recovered_111_co;
  assign esc_add_ln208_122_reg_8391_reg_12_c056c12 [7:4] = recovered_111_o;

  // Reconstructed LUT2: esc_add_ln208_128_reg_8455_3__i_2_33d5f65
  assign esc_add_ln208_128_reg_8455_3__i_2_n_0_7d1eb60 = ((DOADO[3]) ? (~(esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [3])) : (esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [3]));

  // Reconstructed LUT2: esc_add_ln208_128_reg_8455_3__i_3_b1938cb
  assign esc_add_ln208_128_reg_8455_3__i_3_n_0_f134447 = ((DOADO[2]) ? (~(esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [2])) : (esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [2]));

  // Reconstructed LUT2: esc_add_ln208_128_reg_8455_3__i_4_12d502f
  assign esc_add_ln208_128_reg_8455_3__i_4_n_0_4cba90e = ((DOADO[1]) ? (~(esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [1])) : (esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [1]));

  // Reconstructed LUT2: esc_add_ln208_128_reg_8455_3__i_5_aea97e4
  assign esc_add_ln208_128_reg_8455_3__i_5_n_0_2cca731 = ((DOADO[0]) ? (~(esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [0])) : (esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [0]));

  // Reconstructed LUT2: esc_add_ln208_128_reg_8455_7__i_2_8fe69d5
  assign esc_add_ln208_128_reg_8455_7__i_2_n_0_2095e42 = ((DOADO[7]) ? (~(esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [7])) : (esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [7]));

  // Reconstructed LUT2: esc_add_ln208_128_reg_8455_7__i_3_0fa2504
  assign esc_add_ln208_128_reg_8455_7__i_3_n_0_4705c5f = ((DOADO[6]) ? (~(esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [6])) : (esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [6]));

  // Reconstructed LUT2: esc_add_ln208_128_reg_8455_7__i_4_2102326
  assign esc_add_ln208_128_reg_8455_7__i_4_n_0_0c828b7 = ((DOADO[5]) ? (~(esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [5])) : (esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [5]));

  // Reconstructed LUT2: esc_add_ln208_128_reg_8455_7__i_5_d42766d
  assign esc_add_ln208_128_reg_8455_7__i_5_n_0_2a9d3fd = ((DOADO[4]) ? (~(esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [4])) : (esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [4]));

  // Reconstructed CARRY4: esc_add_ln208_128_reg_8455_reg_11__i_1_a4731d8
  wire [3:0] recovered_120_co, recovered_120_o, recovered_120_s, recovered_120_di;
  assign recovered_120_s = esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [11:8];
  assign recovered_120_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_120_ci = ((esc_add_ln208_128_reg_8455_reg_7__i_1_n_0_7bb2674) !== 1'bz) && (esc_add_ln208_128_reg_8455_reg_7__i_1_n_0_7bb2674);
  wire recovered_120_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_120_o[0] = recovered_120_s[0] ^ (recovered_120_ci || recovered_120_cy);
  assign recovered_120_co[0] = (recovered_120_s[0] & (recovered_120_ci || recovered_120_cy)) | (~recovered_120_s[0] & recovered_120_di[0]);
  assign recovered_120_o[1] = recovered_120_s[1] ^ recovered_120_co[0];
  assign recovered_120_co[1] = (recovered_120_s[1] & recovered_120_co[0]) | (~recovered_120_s[1] & recovered_120_di[1]);
  assign recovered_120_o[2] = recovered_120_s[2] ^ recovered_120_co[1];
  assign recovered_120_co[2] = (recovered_120_s[2] & recovered_120_co[1]) | (~recovered_120_s[2] & recovered_120_di[2]);
  assign recovered_120_o[3] = recovered_120_s[3] ^ recovered_120_co[2];
  assign recovered_120_co[3] = (recovered_120_s[3] & recovered_120_co[2]) | (~recovered_120_s[3] & recovered_120_di[3]);
  assign {esc_add_ln208_128_reg_8455_reg_11__i_1_n_0_5647a0a ,esc_NLW_add_ln208_128_reg_8455_reg_11__i_1_CO_UNCONNECTED_ddbfc67 [2:0]} = recovered_120_co;
  assign esc_add_ln208_125_reg_8423_reg_12_a546884 [11:8] = recovered_120_o;

  // Reconstructed CARRY4: esc_add_ln208_128_reg_8455_reg_12__i_2_31b2514
  wire [3:0] recovered_121_co, recovered_121_o, recovered_121_s, recovered_121_di;
  assign recovered_121_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [12]};
  assign recovered_121_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_121_ci = ((esc_add_ln208_128_reg_8455_reg_11__i_1_n_0_5647a0a) !== 1'bz) && (esc_add_ln208_128_reg_8455_reg_11__i_1_n_0_5647a0a);
  wire recovered_121_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_121_o[0] = recovered_121_s[0] ^ (recovered_121_ci || recovered_121_cy);
  assign recovered_121_co[0] = (recovered_121_s[0] & (recovered_121_ci || recovered_121_cy)) | (~recovered_121_s[0] & recovered_121_di[0]);
  assign recovered_121_o[1] = recovered_121_s[1] ^ recovered_121_co[0];
  assign recovered_121_co[1] = (recovered_121_s[1] & recovered_121_co[0]) | (~recovered_121_s[1] & recovered_121_di[1]);
  assign recovered_121_o[2] = recovered_121_s[2] ^ recovered_121_co[1];
  assign recovered_121_co[2] = (recovered_121_s[2] & recovered_121_co[1]) | (~recovered_121_s[2] & recovered_121_di[2]);
  assign recovered_121_o[3] = recovered_121_s[3] ^ recovered_121_co[2];
  assign recovered_121_co[3] = (recovered_121_s[3] & recovered_121_co[2]) | (~recovered_121_s[3] & recovered_121_di[3]);
  assign esc_add_ln208_125_reg_8423_reg_12_a546884 [12] = recovered_121_o;

  // Reconstructed CARRY4: esc_add_ln208_128_reg_8455_reg_3__i_1_7583b84
  wire [3:0] recovered_122_co, recovered_122_o, recovered_122_s, recovered_122_di;
  assign recovered_122_s = {esc_add_ln208_128_reg_8455_3__i_2_n_0_7d1eb60 ,esc_add_ln208_128_reg_8455_3__i_3_n_0_f134447 ,esc_add_ln208_128_reg_8455_3__i_4_n_0_4cba90e ,esc_add_ln208_128_reg_8455_3__i_5_n_0_2cca731 };
  assign recovered_122_di = esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [3:0];
  wire recovered_122_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_122_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_122_o[0] = recovered_122_s[0] ^ (recovered_122_ci || recovered_122_cy);
  assign recovered_122_co[0] = (recovered_122_s[0] & (recovered_122_ci || recovered_122_cy)) | (~recovered_122_s[0] & recovered_122_di[0]);
  assign recovered_122_o[1] = recovered_122_s[1] ^ recovered_122_co[0];
  assign recovered_122_co[1] = (recovered_122_s[1] & recovered_122_co[0]) | (~recovered_122_s[1] & recovered_122_di[1]);
  assign recovered_122_o[2] = recovered_122_s[2] ^ recovered_122_co[1];
  assign recovered_122_co[2] = (recovered_122_s[2] & recovered_122_co[1]) | (~recovered_122_s[2] & recovered_122_di[2]);
  assign recovered_122_o[3] = recovered_122_s[3] ^ recovered_122_co[2];
  assign recovered_122_co[3] = (recovered_122_s[3] & recovered_122_co[2]) | (~recovered_122_s[3] & recovered_122_di[3]);
  assign {esc_add_ln208_128_reg_8455_reg_3__i_1_n_0_1fca9ee ,esc_NLW_add_ln208_128_reg_8455_reg_3__i_1_CO_UNCONNECTED_18d4305 [2:0]} = recovered_122_co;
  assign esc_add_ln208_125_reg_8423_reg_12_a546884 [3:0] = recovered_122_o;

  // Reconstructed CARRY4: esc_add_ln208_128_reg_8455_reg_7__i_1_88919c2
  wire [3:0] recovered_123_co, recovered_123_o, recovered_123_s, recovered_123_di;
  assign recovered_123_s = {esc_add_ln208_128_reg_8455_7__i_2_n_0_2095e42 ,esc_add_ln208_128_reg_8455_7__i_3_n_0_4705c5f ,esc_add_ln208_128_reg_8455_7__i_4_n_0_0c828b7 ,esc_add_ln208_128_reg_8455_7__i_5_n_0_2a9d3fd };
  assign recovered_123_di = esc_add_ln208_128_reg_8455_reg_12__0_5f58a45 [7:4];
  wire recovered_123_ci = ((esc_add_ln208_128_reg_8455_reg_3__i_1_n_0_1fca9ee) !== 1'bz) && (esc_add_ln208_128_reg_8455_reg_3__i_1_n_0_1fca9ee);
  wire recovered_123_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_123_o[0] = recovered_123_s[0] ^ (recovered_123_ci || recovered_123_cy);
  assign recovered_123_co[0] = (recovered_123_s[0] & (recovered_123_ci || recovered_123_cy)) | (~recovered_123_s[0] & recovered_123_di[0]);
  assign recovered_123_o[1] = recovered_123_s[1] ^ recovered_123_co[0];
  assign recovered_123_co[1] = (recovered_123_s[1] & recovered_123_co[0]) | (~recovered_123_s[1] & recovered_123_di[1]);
  assign recovered_123_o[2] = recovered_123_s[2] ^ recovered_123_co[1];
  assign recovered_123_co[2] = (recovered_123_s[2] & recovered_123_co[1]) | (~recovered_123_s[2] & recovered_123_di[2]);
  assign recovered_123_o[3] = recovered_123_s[3] ^ recovered_123_co[2];
  assign recovered_123_co[3] = (recovered_123_s[3] & recovered_123_co[2]) | (~recovered_123_s[3] & recovered_123_di[3]);
  assign {esc_add_ln208_128_reg_8455_reg_7__i_1_n_0_7bb2674 ,esc_NLW_add_ln208_128_reg_8455_reg_7__i_1_CO_UNCONNECTED_890ce7f [2:0]} = recovered_123_co;
  assign esc_add_ln208_125_reg_8423_reg_12_a546884 [7:4] = recovered_123_o;

  // Reconstructed LUT2: esc_add_ln208_131_reg_8487_3__i_2_ad8976b
  assign esc_add_ln208_131_reg_8487_3__i_2_n_0_6fc87f4 = ((DOADO[3]) ? (~(esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [3])) : (esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [3]));

  // Reconstructed LUT2: esc_add_ln208_131_reg_8487_3__i_3_29f30ce
  assign esc_add_ln208_131_reg_8487_3__i_3_n_0_e0429a9 = ((DOADO[2]) ? (~(esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [2])) : (esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [2]));

  // Reconstructed LUT2: esc_add_ln208_131_reg_8487_3__i_4_eefde68
  assign esc_add_ln208_131_reg_8487_3__i_4_n_0_8ab1732 = ((DOADO[1]) ? (~(esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [1])) : (esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [1]));

  // Reconstructed LUT2: esc_add_ln208_131_reg_8487_3__i_5_b0b0c99
  assign esc_add_ln208_131_reg_8487_3__i_5_n_0_e0ef96a = ((DOADO[0]) ? (~(esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [0])) : (esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [0]));

  // Reconstructed LUT2: esc_add_ln208_131_reg_8487_7__i_2_b8e6b40
  assign esc_add_ln208_131_reg_8487_7__i_2_n_0_81f6faa = ((DOADO[7]) ? (~(esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [7])) : (esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [7]));

  // Reconstructed LUT2: esc_add_ln208_131_reg_8487_7__i_3_831dcc5
  assign esc_add_ln208_131_reg_8487_7__i_3_n_0_0edcb9f = ((DOADO[6]) ? (~(esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [6])) : (esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [6]));

  // Reconstructed LUT2: esc_add_ln208_131_reg_8487_7__i_4_dbe303f
  assign esc_add_ln208_131_reg_8487_7__i_4_n_0_0900209 = ((DOADO[5]) ? (~(esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [5])) : (esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [5]));

  // Reconstructed LUT2: esc_add_ln208_131_reg_8487_7__i_5_028b0d1
  assign esc_add_ln208_131_reg_8487_7__i_5_n_0_f6d73a4 = ((DOADO[4]) ? (~(esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [4])) : (esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [4]));

  // Reconstructed CARRY4: esc_add_ln208_131_reg_8487_reg_11__i_1_f3fbce0
  wire [3:0] recovered_132_co, recovered_132_o, recovered_132_s, recovered_132_di;
  assign recovered_132_s = esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [11:8];
  assign recovered_132_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_132_ci = ((esc_add_ln208_131_reg_8487_reg_7__i_1_n_0_f577232) !== 1'bz) && (esc_add_ln208_131_reg_8487_reg_7__i_1_n_0_f577232);
  wire recovered_132_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_132_o[0] = recovered_132_s[0] ^ (recovered_132_ci || recovered_132_cy);
  assign recovered_132_co[0] = (recovered_132_s[0] & (recovered_132_ci || recovered_132_cy)) | (~recovered_132_s[0] & recovered_132_di[0]);
  assign recovered_132_o[1] = recovered_132_s[1] ^ recovered_132_co[0];
  assign recovered_132_co[1] = (recovered_132_s[1] & recovered_132_co[0]) | (~recovered_132_s[1] & recovered_132_di[1]);
  assign recovered_132_o[2] = recovered_132_s[2] ^ recovered_132_co[1];
  assign recovered_132_co[2] = (recovered_132_s[2] & recovered_132_co[1]) | (~recovered_132_s[2] & recovered_132_di[2]);
  assign recovered_132_o[3] = recovered_132_s[3] ^ recovered_132_co[2];
  assign recovered_132_co[3] = (recovered_132_s[3] & recovered_132_co[2]) | (~recovered_132_s[3] & recovered_132_di[3]);
  assign {esc_add_ln208_131_reg_8487_reg_11__i_1_n_0_8d18615 ,esc_NLW_add_ln208_131_reg_8487_reg_11__i_1_CO_UNCONNECTED_8d0dfa6 [2:0]} = recovered_132_co;
  assign esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 [11:8] = recovered_132_o;

  // Reconstructed CARRY4: esc_add_ln208_131_reg_8487_reg_12__i_2_24819de
  wire [3:0] recovered_133_co, recovered_133_o, recovered_133_s, recovered_133_di;
  assign recovered_133_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [12]};
  assign recovered_133_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_133_ci = ((esc_add_ln208_131_reg_8487_reg_11__i_1_n_0_8d18615) !== 1'bz) && (esc_add_ln208_131_reg_8487_reg_11__i_1_n_0_8d18615);
  wire recovered_133_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_133_o[0] = recovered_133_s[0] ^ (recovered_133_ci || recovered_133_cy);
  assign recovered_133_co[0] = (recovered_133_s[0] & (recovered_133_ci || recovered_133_cy)) | (~recovered_133_s[0] & recovered_133_di[0]);
  assign recovered_133_o[1] = recovered_133_s[1] ^ recovered_133_co[0];
  assign recovered_133_co[1] = (recovered_133_s[1] & recovered_133_co[0]) | (~recovered_133_s[1] & recovered_133_di[1]);
  assign recovered_133_o[2] = recovered_133_s[2] ^ recovered_133_co[1];
  assign recovered_133_co[2] = (recovered_133_s[2] & recovered_133_co[1]) | (~recovered_133_s[2] & recovered_133_di[2]);
  assign recovered_133_o[3] = recovered_133_s[3] ^ recovered_133_co[2];
  assign recovered_133_co[3] = (recovered_133_s[3] & recovered_133_co[2]) | (~recovered_133_s[3] & recovered_133_di[3]);
  assign esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 [12] = recovered_133_o;

  // Reconstructed CARRY4: esc_add_ln208_131_reg_8487_reg_3__i_1_77e108f
  wire [3:0] recovered_134_co, recovered_134_o, recovered_134_s, recovered_134_di;
  assign recovered_134_s = {esc_add_ln208_131_reg_8487_3__i_2_n_0_6fc87f4 ,esc_add_ln208_131_reg_8487_3__i_3_n_0_e0429a9 ,esc_add_ln208_131_reg_8487_3__i_4_n_0_8ab1732 ,esc_add_ln208_131_reg_8487_3__i_5_n_0_e0ef96a };
  assign recovered_134_di = esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [3:0];
  wire recovered_134_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_134_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_134_o[0] = recovered_134_s[0] ^ (recovered_134_ci || recovered_134_cy);
  assign recovered_134_co[0] = (recovered_134_s[0] & (recovered_134_ci || recovered_134_cy)) | (~recovered_134_s[0] & recovered_134_di[0]);
  assign recovered_134_o[1] = recovered_134_s[1] ^ recovered_134_co[0];
  assign recovered_134_co[1] = (recovered_134_s[1] & recovered_134_co[0]) | (~recovered_134_s[1] & recovered_134_di[1]);
  assign recovered_134_o[2] = recovered_134_s[2] ^ recovered_134_co[1];
  assign recovered_134_co[2] = (recovered_134_s[2] & recovered_134_co[1]) | (~recovered_134_s[2] & recovered_134_di[2]);
  assign recovered_134_o[3] = recovered_134_s[3] ^ recovered_134_co[2];
  assign recovered_134_co[3] = (recovered_134_s[3] & recovered_134_co[2]) | (~recovered_134_s[3] & recovered_134_di[3]);
  assign {esc_add_ln208_131_reg_8487_reg_3__i_1_n_0_73d3ea4 ,esc_NLW_add_ln208_131_reg_8487_reg_3__i_1_CO_UNCONNECTED_ed4b886 [2:0]} = recovered_134_co;
  assign esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 [3:0] = recovered_134_o;

  // Reconstructed CARRY4: esc_add_ln208_131_reg_8487_reg_7__i_1_5c27291
  wire [3:0] recovered_135_co, recovered_135_o, recovered_135_s, recovered_135_di;
  assign recovered_135_s = {esc_add_ln208_131_reg_8487_7__i_2_n_0_81f6faa ,esc_add_ln208_131_reg_8487_7__i_3_n_0_0edcb9f ,esc_add_ln208_131_reg_8487_7__i_4_n_0_0900209 ,esc_add_ln208_131_reg_8487_7__i_5_n_0_f6d73a4 };
  assign recovered_135_di = esc_add_ln208_131_reg_8487_reg_12__0_cea36b3 [7:4];
  wire recovered_135_ci = ((esc_add_ln208_131_reg_8487_reg_3__i_1_n_0_73d3ea4) !== 1'bz) && (esc_add_ln208_131_reg_8487_reg_3__i_1_n_0_73d3ea4);
  wire recovered_135_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_135_o[0] = recovered_135_s[0] ^ (recovered_135_ci || recovered_135_cy);
  assign recovered_135_co[0] = (recovered_135_s[0] & (recovered_135_ci || recovered_135_cy)) | (~recovered_135_s[0] & recovered_135_di[0]);
  assign recovered_135_o[1] = recovered_135_s[1] ^ recovered_135_co[0];
  assign recovered_135_co[1] = (recovered_135_s[1] & recovered_135_co[0]) | (~recovered_135_s[1] & recovered_135_di[1]);
  assign recovered_135_o[2] = recovered_135_s[2] ^ recovered_135_co[1];
  assign recovered_135_co[2] = (recovered_135_s[2] & recovered_135_co[1]) | (~recovered_135_s[2] & recovered_135_di[2]);
  assign recovered_135_o[3] = recovered_135_s[3] ^ recovered_135_co[2];
  assign recovered_135_co[3] = (recovered_135_s[3] & recovered_135_co[2]) | (~recovered_135_s[3] & recovered_135_di[3]);
  assign {esc_add_ln208_131_reg_8487_reg_7__i_1_n_0_f577232 ,esc_NLW_add_ln208_131_reg_8487_reg_7__i_1_CO_UNCONNECTED_386230f [2:0]} = recovered_135_co;
  assign esc_add_ln208_128_reg_8455_reg_12_7c8bdc1 [7:4] = recovered_135_o;

  // Reconstructed LUT2: esc_add_ln208_134_reg_8519_3__i_2_df35c3d
  assign esc_add_ln208_134_reg_8519_3__i_2_n_0_4107dd6 = ((DOADO[3]) ? (~(esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [3])) : (esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [3]));

  // Reconstructed LUT2: esc_add_ln208_134_reg_8519_3__i_3_49b7bae
  assign esc_add_ln208_134_reg_8519_3__i_3_n_0_2329e7f = ((DOADO[2]) ? (~(esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [2])) : (esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [2]));

  // Reconstructed LUT2: esc_add_ln208_134_reg_8519_3__i_4_d9106be
  assign esc_add_ln208_134_reg_8519_3__i_4_n_0_4006024 = ((DOADO[1]) ? (~(esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [1])) : (esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [1]));

  // Reconstructed LUT2: esc_add_ln208_134_reg_8519_3__i_5_cb63c38
  assign esc_add_ln208_134_reg_8519_3__i_5_n_0_7f8e999 = ((DOADO[0]) ? (~(esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [0])) : (esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [0]));

  // Reconstructed LUT2: esc_add_ln208_134_reg_8519_7__i_2_d7dbc3d
  assign esc_add_ln208_134_reg_8519_7__i_2_n_0_2e1b8fb = ((DOADO[7]) ? (~(esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [7])) : (esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [7]));

  // Reconstructed LUT2: esc_add_ln208_134_reg_8519_7__i_3_8e39ca9
  assign esc_add_ln208_134_reg_8519_7__i_3_n_0_bc728eb = ((DOADO[6]) ? (~(esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [6])) : (esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [6]));

  // Reconstructed LUT2: esc_add_ln208_134_reg_8519_7__i_4_189ec99
  assign esc_add_ln208_134_reg_8519_7__i_4_n_0_0bb706e = ((DOADO[5]) ? (~(esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [5])) : (esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [5]));

  // Reconstructed LUT2: esc_add_ln208_134_reg_8519_7__i_5_ba5160f
  assign esc_add_ln208_134_reg_8519_7__i_5_n_0_85c175b = ((DOADO[4]) ? (~(esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [4])) : (esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [4]));

  // Reconstructed CARRY4: esc_add_ln208_134_reg_8519_reg_11__i_1_2ca2d6f
  wire [3:0] recovered_144_co, recovered_144_o, recovered_144_s, recovered_144_di;
  assign recovered_144_s = esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [11:8];
  assign recovered_144_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_144_ci = ((esc_add_ln208_134_reg_8519_reg_7__i_1_n_0_c595bda) !== 1'bz) && (esc_add_ln208_134_reg_8519_reg_7__i_1_n_0_c595bda);
  wire recovered_144_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_144_o[0] = recovered_144_s[0] ^ (recovered_144_ci || recovered_144_cy);
  assign recovered_144_co[0] = (recovered_144_s[0] & (recovered_144_ci || recovered_144_cy)) | (~recovered_144_s[0] & recovered_144_di[0]);
  assign recovered_144_o[1] = recovered_144_s[1] ^ recovered_144_co[0];
  assign recovered_144_co[1] = (recovered_144_s[1] & recovered_144_co[0]) | (~recovered_144_s[1] & recovered_144_di[1]);
  assign recovered_144_o[2] = recovered_144_s[2] ^ recovered_144_co[1];
  assign recovered_144_co[2] = (recovered_144_s[2] & recovered_144_co[1]) | (~recovered_144_s[2] & recovered_144_di[2]);
  assign recovered_144_o[3] = recovered_144_s[3] ^ recovered_144_co[2];
  assign recovered_144_co[3] = (recovered_144_s[3] & recovered_144_co[2]) | (~recovered_144_s[3] & recovered_144_di[3]);
  assign {esc_add_ln208_134_reg_8519_reg_11__i_1_n_0_ef2ae3e ,esc_NLW_add_ln208_134_reg_8519_reg_11__i_1_CO_UNCONNECTED_b8ef1cc [2:0]} = recovered_144_co;
  assign esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 [11:8] = recovered_144_o;

  // Reconstructed CARRY4: esc_add_ln208_134_reg_8519_reg_13__i_2_658eed9
  wire [3:0] recovered_145_co, recovered_145_o, recovered_145_s, recovered_145_di;
  assign recovered_145_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 ,esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [12]};
  assign recovered_145_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_145_ci = ((esc_add_ln208_134_reg_8519_reg_11__i_1_n_0_ef2ae3e) !== 1'bz) && (esc_add_ln208_134_reg_8519_reg_11__i_1_n_0_ef2ae3e);
  wire recovered_145_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_145_o[0] = recovered_145_s[0] ^ (recovered_145_ci || recovered_145_cy);
  assign recovered_145_co[0] = (recovered_145_s[0] & (recovered_145_ci || recovered_145_cy)) | (~recovered_145_s[0] & recovered_145_di[0]);
  assign recovered_145_o[1] = recovered_145_s[1] ^ recovered_145_co[0];
  assign recovered_145_co[1] = (recovered_145_s[1] & recovered_145_co[0]) | (~recovered_145_s[1] & recovered_145_di[1]);
  assign recovered_145_o[2] = recovered_145_s[2] ^ recovered_145_co[1];
  assign recovered_145_co[2] = (recovered_145_s[2] & recovered_145_co[1]) | (~recovered_145_s[2] & recovered_145_di[2]);
  assign recovered_145_o[3] = recovered_145_s[3] ^ recovered_145_co[2];
  assign recovered_145_co[3] = (recovered_145_s[3] & recovered_145_co[2]) | (~recovered_145_s[3] & recovered_145_di[3]);
  assign {esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 [13],esc_NLW_add_ln208_134_reg_8519_reg_13__i_2_CO_UNCONNECTED_a4b9dad [0]} = recovered_145_co;
  assign esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 [12] = recovered_145_o;

  // Reconstructed CARRY4: esc_add_ln208_134_reg_8519_reg_3__i_1_796cef9
  wire [3:0] recovered_146_co, recovered_146_o, recovered_146_s, recovered_146_di;
  assign recovered_146_s = {esc_add_ln208_134_reg_8519_3__i_2_n_0_4107dd6 ,esc_add_ln208_134_reg_8519_3__i_3_n_0_2329e7f ,esc_add_ln208_134_reg_8519_3__i_4_n_0_4006024 ,esc_add_ln208_134_reg_8519_3__i_5_n_0_7f8e999 };
  assign recovered_146_di = esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [3:0];
  wire recovered_146_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_146_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_146_o[0] = recovered_146_s[0] ^ (recovered_146_ci || recovered_146_cy);
  assign recovered_146_co[0] = (recovered_146_s[0] & (recovered_146_ci || recovered_146_cy)) | (~recovered_146_s[0] & recovered_146_di[0]);
  assign recovered_146_o[1] = recovered_146_s[1] ^ recovered_146_co[0];
  assign recovered_146_co[1] = (recovered_146_s[1] & recovered_146_co[0]) | (~recovered_146_s[1] & recovered_146_di[1]);
  assign recovered_146_o[2] = recovered_146_s[2] ^ recovered_146_co[1];
  assign recovered_146_co[2] = (recovered_146_s[2] & recovered_146_co[1]) | (~recovered_146_s[2] & recovered_146_di[2]);
  assign recovered_146_o[3] = recovered_146_s[3] ^ recovered_146_co[2];
  assign recovered_146_co[3] = (recovered_146_s[3] & recovered_146_co[2]) | (~recovered_146_s[3] & recovered_146_di[3]);
  assign {esc_add_ln208_134_reg_8519_reg_3__i_1_n_0_4723170 ,esc_NLW_add_ln208_134_reg_8519_reg_3__i_1_CO_UNCONNECTED_a31ce89 [2:0]} = recovered_146_co;
  assign esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 [3:0] = recovered_146_o;

  // Reconstructed CARRY4: esc_add_ln208_134_reg_8519_reg_7__i_1_71f89b7
  wire [3:0] recovered_147_co, recovered_147_o, recovered_147_s, recovered_147_di;
  assign recovered_147_s = {esc_add_ln208_134_reg_8519_7__i_2_n_0_2e1b8fb ,esc_add_ln208_134_reg_8519_7__i_3_n_0_bc728eb ,esc_add_ln208_134_reg_8519_7__i_4_n_0_0bb706e ,esc_add_ln208_134_reg_8519_7__i_5_n_0_85c175b };
  assign recovered_147_di = esc_add_ln208_134_reg_8519_reg_13__0_3ac8e1f [7:4];
  wire recovered_147_ci = ((esc_add_ln208_134_reg_8519_reg_3__i_1_n_0_4723170) !== 1'bz) && (esc_add_ln208_134_reg_8519_reg_3__i_1_n_0_4723170);
  wire recovered_147_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_147_o[0] = recovered_147_s[0] ^ (recovered_147_ci || recovered_147_cy);
  assign recovered_147_co[0] = (recovered_147_s[0] & (recovered_147_ci || recovered_147_cy)) | (~recovered_147_s[0] & recovered_147_di[0]);
  assign recovered_147_o[1] = recovered_147_s[1] ^ recovered_147_co[0];
  assign recovered_147_co[1] = (recovered_147_s[1] & recovered_147_co[0]) | (~recovered_147_s[1] & recovered_147_di[1]);
  assign recovered_147_o[2] = recovered_147_s[2] ^ recovered_147_co[1];
  assign recovered_147_co[2] = (recovered_147_s[2] & recovered_147_co[1]) | (~recovered_147_s[2] & recovered_147_di[2]);
  assign recovered_147_o[3] = recovered_147_s[3] ^ recovered_147_co[2];
  assign recovered_147_co[3] = (recovered_147_s[3] & recovered_147_co[2]) | (~recovered_147_s[3] & recovered_147_di[3]);
  assign {esc_add_ln208_134_reg_8519_reg_7__i_1_n_0_c595bda ,esc_NLW_add_ln208_134_reg_8519_reg_7__i_1_CO_UNCONNECTED_1af465d [2:0]} = recovered_147_co;
  assign esc_add_ln208_131_reg_8487_reg_12_2e4a9f1 [7:4] = recovered_147_o;

  // Reconstructed LUT2: esc_add_ln208_137_reg_8551_3__i_2_b6c1b3f
  assign esc_add_ln208_137_reg_8551_3__i_2_n_0_204f9eb = ((DOADO[3]) ? (~(esc_add_ln208_137_reg_8551_reg_13__0_215f155 [3])) : (esc_add_ln208_137_reg_8551_reg_13__0_215f155 [3]));

  // Reconstructed LUT2: esc_add_ln208_137_reg_8551_3__i_3_7d7e132
  assign esc_add_ln208_137_reg_8551_3__i_3_n_0_3c6e873 = ((DOADO[2]) ? (~(esc_add_ln208_137_reg_8551_reg_13__0_215f155 [2])) : (esc_add_ln208_137_reg_8551_reg_13__0_215f155 [2]));

  // Reconstructed LUT2: esc_add_ln208_137_reg_8551_3__i_4_fb307b9
  assign esc_add_ln208_137_reg_8551_3__i_4_n_0_47917d6 = ((DOADO[1]) ? (~(esc_add_ln208_137_reg_8551_reg_13__0_215f155 [1])) : (esc_add_ln208_137_reg_8551_reg_13__0_215f155 [1]));

  // Reconstructed LUT2: esc_add_ln208_137_reg_8551_3__i_5_4465768
  assign esc_add_ln208_137_reg_8551_3__i_5_n_0_4a85f84 = ((DOADO[0]) ? (~(esc_add_ln208_137_reg_8551_reg_13__0_215f155 [0])) : (esc_add_ln208_137_reg_8551_reg_13__0_215f155 [0]));

  // Reconstructed LUT2: esc_add_ln208_137_reg_8551_7__i_2_feab664
  assign esc_add_ln208_137_reg_8551_7__i_2_n_0_15e06d5 = ((DOADO[7]) ? (~(esc_add_ln208_137_reg_8551_reg_13__0_215f155 [7])) : (esc_add_ln208_137_reg_8551_reg_13__0_215f155 [7]));

  // Reconstructed LUT2: esc_add_ln208_137_reg_8551_7__i_3_c8e3692
  assign esc_add_ln208_137_reg_8551_7__i_3_n_0_7325944 = ((DOADO[6]) ? (~(esc_add_ln208_137_reg_8551_reg_13__0_215f155 [6])) : (esc_add_ln208_137_reg_8551_reg_13__0_215f155 [6]));

  // Reconstructed LUT2: esc_add_ln208_137_reg_8551_7__i_4_7ee07c9
  assign esc_add_ln208_137_reg_8551_7__i_4_n_0_0f6e3e4 = ((DOADO[5]) ? (~(esc_add_ln208_137_reg_8551_reg_13__0_215f155 [5])) : (esc_add_ln208_137_reg_8551_reg_13__0_215f155 [5]));

  // Reconstructed LUT2: esc_add_ln208_137_reg_8551_7__i_5_40991a8
  assign esc_add_ln208_137_reg_8551_7__i_5_n_0_457a937 = ((DOADO[4]) ? (~(esc_add_ln208_137_reg_8551_reg_13__0_215f155 [4])) : (esc_add_ln208_137_reg_8551_reg_13__0_215f155 [4]));

  // Reconstructed CARRY4: esc_add_ln208_137_reg_8551_reg_11__i_1_a3f9691
  wire [3:0] recovered_156_co, recovered_156_o, recovered_156_s, recovered_156_di;
  assign recovered_156_s = esc_add_ln208_137_reg_8551_reg_13__0_215f155 [11:8];
  assign recovered_156_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_156_ci = ((esc_add_ln208_137_reg_8551_reg_7__i_1_n_0_d32e017) !== 1'bz) && (esc_add_ln208_137_reg_8551_reg_7__i_1_n_0_d32e017);
  wire recovered_156_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_156_o[0] = recovered_156_s[0] ^ (recovered_156_ci || recovered_156_cy);
  assign recovered_156_co[0] = (recovered_156_s[0] & (recovered_156_ci || recovered_156_cy)) | (~recovered_156_s[0] & recovered_156_di[0]);
  assign recovered_156_o[1] = recovered_156_s[1] ^ recovered_156_co[0];
  assign recovered_156_co[1] = (recovered_156_s[1] & recovered_156_co[0]) | (~recovered_156_s[1] & recovered_156_di[1]);
  assign recovered_156_o[2] = recovered_156_s[2] ^ recovered_156_co[1];
  assign recovered_156_co[2] = (recovered_156_s[2] & recovered_156_co[1]) | (~recovered_156_s[2] & recovered_156_di[2]);
  assign recovered_156_o[3] = recovered_156_s[3] ^ recovered_156_co[2];
  assign recovered_156_co[3] = (recovered_156_s[3] & recovered_156_co[2]) | (~recovered_156_s[3] & recovered_156_di[3]);
  assign {esc_add_ln208_137_reg_8551_reg_11__i_1_n_0_b7a80e2 ,esc_NLW_add_ln208_137_reg_8551_reg_11__i_1_CO_UNCONNECTED_ec24eca [2:0]} = recovered_156_co;
  assign esc_add_ln208_134_reg_8519_reg_13_79685f6 [11:8] = recovered_156_o;

  // Reconstructed CARRY4: esc_add_ln208_137_reg_8551_reg_13__i_2_41497d6
  wire [3:0] recovered_157_co, recovered_157_o, recovered_157_s, recovered_157_di;
  assign recovered_157_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_137_reg_8551_reg_13__0_215f155 [13:12]};
  assign recovered_157_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_157_ci = ((esc_add_ln208_137_reg_8551_reg_11__i_1_n_0_b7a80e2) !== 1'bz) && (esc_add_ln208_137_reg_8551_reg_11__i_1_n_0_b7a80e2);
  wire recovered_157_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_157_o[0] = recovered_157_s[0] ^ (recovered_157_ci || recovered_157_cy);
  assign recovered_157_co[0] = (recovered_157_s[0] & (recovered_157_ci || recovered_157_cy)) | (~recovered_157_s[0] & recovered_157_di[0]);
  assign recovered_157_o[1] = recovered_157_s[1] ^ recovered_157_co[0];
  assign recovered_157_co[1] = (recovered_157_s[1] & recovered_157_co[0]) | (~recovered_157_s[1] & recovered_157_di[1]);
  assign recovered_157_o[2] = recovered_157_s[2] ^ recovered_157_co[1];
  assign recovered_157_co[2] = (recovered_157_s[2] & recovered_157_co[1]) | (~recovered_157_s[2] & recovered_157_di[2]);
  assign recovered_157_o[3] = recovered_157_s[3] ^ recovered_157_co[2];
  assign recovered_157_co[3] = (recovered_157_s[3] & recovered_157_co[2]) | (~recovered_157_s[3] & recovered_157_di[3]);
  assign esc_add_ln208_134_reg_8519_reg_13_79685f6 [13:12] = recovered_157_o;

  // Reconstructed CARRY4: esc_add_ln208_137_reg_8551_reg_3__i_1_0491a25
  wire [3:0] recovered_158_co, recovered_158_o, recovered_158_s, recovered_158_di;
  assign recovered_158_s = {esc_add_ln208_137_reg_8551_3__i_2_n_0_204f9eb ,esc_add_ln208_137_reg_8551_3__i_3_n_0_3c6e873 ,esc_add_ln208_137_reg_8551_3__i_4_n_0_47917d6 ,esc_add_ln208_137_reg_8551_3__i_5_n_0_4a85f84 };
  assign recovered_158_di = esc_add_ln208_137_reg_8551_reg_13__0_215f155 [3:0];
  wire recovered_158_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_158_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_158_o[0] = recovered_158_s[0] ^ (recovered_158_ci || recovered_158_cy);
  assign recovered_158_co[0] = (recovered_158_s[0] & (recovered_158_ci || recovered_158_cy)) | (~recovered_158_s[0] & recovered_158_di[0]);
  assign recovered_158_o[1] = recovered_158_s[1] ^ recovered_158_co[0];
  assign recovered_158_co[1] = (recovered_158_s[1] & recovered_158_co[0]) | (~recovered_158_s[1] & recovered_158_di[1]);
  assign recovered_158_o[2] = recovered_158_s[2] ^ recovered_158_co[1];
  assign recovered_158_co[2] = (recovered_158_s[2] & recovered_158_co[1]) | (~recovered_158_s[2] & recovered_158_di[2]);
  assign recovered_158_o[3] = recovered_158_s[3] ^ recovered_158_co[2];
  assign recovered_158_co[3] = (recovered_158_s[3] & recovered_158_co[2]) | (~recovered_158_s[3] & recovered_158_di[3]);
  assign {esc_add_ln208_137_reg_8551_reg_3__i_1_n_0_3a4f3c5 ,esc_NLW_add_ln208_137_reg_8551_reg_3__i_1_CO_UNCONNECTED_be9e1e0 [2:0]} = recovered_158_co;
  assign esc_add_ln208_134_reg_8519_reg_13_79685f6 [3:0] = recovered_158_o;

  // Reconstructed CARRY4: esc_add_ln208_137_reg_8551_reg_7__i_1_6988ec6
  wire [3:0] recovered_159_co, recovered_159_o, recovered_159_s, recovered_159_di;
  assign recovered_159_s = {esc_add_ln208_137_reg_8551_7__i_2_n_0_15e06d5 ,esc_add_ln208_137_reg_8551_7__i_3_n_0_7325944 ,esc_add_ln208_137_reg_8551_7__i_4_n_0_0f6e3e4 ,esc_add_ln208_137_reg_8551_7__i_5_n_0_457a937 };
  assign recovered_159_di = esc_add_ln208_137_reg_8551_reg_13__0_215f155 [7:4];
  wire recovered_159_ci = ((esc_add_ln208_137_reg_8551_reg_3__i_1_n_0_3a4f3c5) !== 1'bz) && (esc_add_ln208_137_reg_8551_reg_3__i_1_n_0_3a4f3c5);
  wire recovered_159_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_159_o[0] = recovered_159_s[0] ^ (recovered_159_ci || recovered_159_cy);
  assign recovered_159_co[0] = (recovered_159_s[0] & (recovered_159_ci || recovered_159_cy)) | (~recovered_159_s[0] & recovered_159_di[0]);
  assign recovered_159_o[1] = recovered_159_s[1] ^ recovered_159_co[0];
  assign recovered_159_co[1] = (recovered_159_s[1] & recovered_159_co[0]) | (~recovered_159_s[1] & recovered_159_di[1]);
  assign recovered_159_o[2] = recovered_159_s[2] ^ recovered_159_co[1];
  assign recovered_159_co[2] = (recovered_159_s[2] & recovered_159_co[1]) | (~recovered_159_s[2] & recovered_159_di[2]);
  assign recovered_159_o[3] = recovered_159_s[3] ^ recovered_159_co[2];
  assign recovered_159_co[3] = (recovered_159_s[3] & recovered_159_co[2]) | (~recovered_159_s[3] & recovered_159_di[3]);
  assign {esc_add_ln208_137_reg_8551_reg_7__i_1_n_0_d32e017 ,esc_NLW_add_ln208_137_reg_8551_reg_7__i_1_CO_UNCONNECTED_45b7a66 [2:0]} = recovered_159_co;
  assign esc_add_ln208_134_reg_8519_reg_13_79685f6 [7:4] = recovered_159_o;

  // Reconstructed LUT2: esc_add_ln208_140_reg_8583_3__i_2_5cdbc61
  assign esc_add_ln208_140_reg_8583_3__i_2_n_0_841829b = ((DOADO[3]) ? (~(esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [3])) : (esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [3]));

  // Reconstructed LUT2: esc_add_ln208_140_reg_8583_3__i_3_60212d7
  assign esc_add_ln208_140_reg_8583_3__i_3_n_0_821abcb = ((DOADO[2]) ? (~(esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [2])) : (esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [2]));

  // Reconstructed LUT2: esc_add_ln208_140_reg_8583_3__i_4_20a984c
  assign esc_add_ln208_140_reg_8583_3__i_4_n_0_8302584 = ((DOADO[1]) ? (~(esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [1])) : (esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [1]));

  // Reconstructed LUT2: esc_add_ln208_140_reg_8583_3__i_5_a7b888b
  assign esc_add_ln208_140_reg_8583_3__i_5_n_0_3c21bf2 = ((DOADO[0]) ? (~(esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [0])) : (esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [0]));

  // Reconstructed LUT2: esc_add_ln208_140_reg_8583_7__i_2_4c06c8d
  assign esc_add_ln208_140_reg_8583_7__i_2_n_0_744a5b5 = ((DOADO[7]) ? (~(esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [7])) : (esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [7]));

  // Reconstructed LUT2: esc_add_ln208_140_reg_8583_7__i_3_9223b9d
  assign esc_add_ln208_140_reg_8583_7__i_3_n_0_88a100d = ((DOADO[6]) ? (~(esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [6])) : (esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [6]));

  // Reconstructed LUT2: esc_add_ln208_140_reg_8583_7__i_4_80714a1
  assign esc_add_ln208_140_reg_8583_7__i_4_n_0_f0687de = ((DOADO[5]) ? (~(esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [5])) : (esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [5]));

  // Reconstructed LUT2: esc_add_ln208_140_reg_8583_7__i_5_ef71be9
  assign esc_add_ln208_140_reg_8583_7__i_5_n_0_d32a40d = ((DOADO[4]) ? (~(esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [4])) : (esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [4]));

  // Reconstructed CARRY4: esc_add_ln208_140_reg_8583_reg_11__i_1_0a92387
  wire [3:0] recovered_168_co, recovered_168_o, recovered_168_s, recovered_168_di;
  assign recovered_168_s = esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [11:8];
  assign recovered_168_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_168_ci = ((esc_add_ln208_140_reg_8583_reg_7__i_1_n_0_50057e5) !== 1'bz) && (esc_add_ln208_140_reg_8583_reg_7__i_1_n_0_50057e5);
  wire recovered_168_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_168_o[0] = recovered_168_s[0] ^ (recovered_168_ci || recovered_168_cy);
  assign recovered_168_co[0] = (recovered_168_s[0] & (recovered_168_ci || recovered_168_cy)) | (~recovered_168_s[0] & recovered_168_di[0]);
  assign recovered_168_o[1] = recovered_168_s[1] ^ recovered_168_co[0];
  assign recovered_168_co[1] = (recovered_168_s[1] & recovered_168_co[0]) | (~recovered_168_s[1] & recovered_168_di[1]);
  assign recovered_168_o[2] = recovered_168_s[2] ^ recovered_168_co[1];
  assign recovered_168_co[2] = (recovered_168_s[2] & recovered_168_co[1]) | (~recovered_168_s[2] & recovered_168_di[2]);
  assign recovered_168_o[3] = recovered_168_s[3] ^ recovered_168_co[2];
  assign recovered_168_co[3] = (recovered_168_s[3] & recovered_168_co[2]) | (~recovered_168_s[3] & recovered_168_di[3]);
  assign {esc_add_ln208_140_reg_8583_reg_11__i_1_n_0_c49c1d5 ,esc_NLW_add_ln208_140_reg_8583_reg_11__i_1_CO_UNCONNECTED_ccf108c [2:0]} = recovered_168_co;
  assign esc_add_ln208_137_reg_8551_reg_13_711eea5 [11:8] = recovered_168_o;

  // Reconstructed CARRY4: esc_add_ln208_140_reg_8583_reg_13__i_2_10942d0
  wire [3:0] recovered_169_co, recovered_169_o, recovered_169_s, recovered_169_di;
  assign recovered_169_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [13:12]};
  assign recovered_169_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_169_ci = ((esc_add_ln208_140_reg_8583_reg_11__i_1_n_0_c49c1d5) !== 1'bz) && (esc_add_ln208_140_reg_8583_reg_11__i_1_n_0_c49c1d5);
  wire recovered_169_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_169_o[0] = recovered_169_s[0] ^ (recovered_169_ci || recovered_169_cy);
  assign recovered_169_co[0] = (recovered_169_s[0] & (recovered_169_ci || recovered_169_cy)) | (~recovered_169_s[0] & recovered_169_di[0]);
  assign recovered_169_o[1] = recovered_169_s[1] ^ recovered_169_co[0];
  assign recovered_169_co[1] = (recovered_169_s[1] & recovered_169_co[0]) | (~recovered_169_s[1] & recovered_169_di[1]);
  assign recovered_169_o[2] = recovered_169_s[2] ^ recovered_169_co[1];
  assign recovered_169_co[2] = (recovered_169_s[2] & recovered_169_co[1]) | (~recovered_169_s[2] & recovered_169_di[2]);
  assign recovered_169_o[3] = recovered_169_s[3] ^ recovered_169_co[2];
  assign recovered_169_co[3] = (recovered_169_s[3] & recovered_169_co[2]) | (~recovered_169_s[3] & recovered_169_di[3]);
  assign esc_add_ln208_137_reg_8551_reg_13_711eea5 [13:12] = recovered_169_o;

  // Reconstructed CARRY4: esc_add_ln208_140_reg_8583_reg_3__i_1_80a728a
  wire [3:0] recovered_170_co, recovered_170_o, recovered_170_s, recovered_170_di;
  assign recovered_170_s = {esc_add_ln208_140_reg_8583_3__i_2_n_0_841829b ,esc_add_ln208_140_reg_8583_3__i_3_n_0_821abcb ,esc_add_ln208_140_reg_8583_3__i_4_n_0_8302584 ,esc_add_ln208_140_reg_8583_3__i_5_n_0_3c21bf2 };
  assign recovered_170_di = esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [3:0];
  wire recovered_170_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_170_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_170_o[0] = recovered_170_s[0] ^ (recovered_170_ci || recovered_170_cy);
  assign recovered_170_co[0] = (recovered_170_s[0] & (recovered_170_ci || recovered_170_cy)) | (~recovered_170_s[0] & recovered_170_di[0]);
  assign recovered_170_o[1] = recovered_170_s[1] ^ recovered_170_co[0];
  assign recovered_170_co[1] = (recovered_170_s[1] & recovered_170_co[0]) | (~recovered_170_s[1] & recovered_170_di[1]);
  assign recovered_170_o[2] = recovered_170_s[2] ^ recovered_170_co[1];
  assign recovered_170_co[2] = (recovered_170_s[2] & recovered_170_co[1]) | (~recovered_170_s[2] & recovered_170_di[2]);
  assign recovered_170_o[3] = recovered_170_s[3] ^ recovered_170_co[2];
  assign recovered_170_co[3] = (recovered_170_s[3] & recovered_170_co[2]) | (~recovered_170_s[3] & recovered_170_di[3]);
  assign {esc_add_ln208_140_reg_8583_reg_3__i_1_n_0_00d3fb5 ,esc_NLW_add_ln208_140_reg_8583_reg_3__i_1_CO_UNCONNECTED_8ebbf8f [2:0]} = recovered_170_co;
  assign esc_add_ln208_137_reg_8551_reg_13_711eea5 [3:0] = recovered_170_o;

  // Reconstructed CARRY4: esc_add_ln208_140_reg_8583_reg_7__i_1_35d28a0
  wire [3:0] recovered_171_co, recovered_171_o, recovered_171_s, recovered_171_di;
  assign recovered_171_s = {esc_add_ln208_140_reg_8583_7__i_2_n_0_744a5b5 ,esc_add_ln208_140_reg_8583_7__i_3_n_0_88a100d ,esc_add_ln208_140_reg_8583_7__i_4_n_0_f0687de ,esc_add_ln208_140_reg_8583_7__i_5_n_0_d32a40d };
  assign recovered_171_di = esc_add_ln208_140_reg_8583_reg_13__0_abec0f5 [7:4];
  wire recovered_171_ci = ((esc_add_ln208_140_reg_8583_reg_3__i_1_n_0_00d3fb5) !== 1'bz) && (esc_add_ln208_140_reg_8583_reg_3__i_1_n_0_00d3fb5);
  wire recovered_171_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_171_o[0] = recovered_171_s[0] ^ (recovered_171_ci || recovered_171_cy);
  assign recovered_171_co[0] = (recovered_171_s[0] & (recovered_171_ci || recovered_171_cy)) | (~recovered_171_s[0] & recovered_171_di[0]);
  assign recovered_171_o[1] = recovered_171_s[1] ^ recovered_171_co[0];
  assign recovered_171_co[1] = (recovered_171_s[1] & recovered_171_co[0]) | (~recovered_171_s[1] & recovered_171_di[1]);
  assign recovered_171_o[2] = recovered_171_s[2] ^ recovered_171_co[1];
  assign recovered_171_co[2] = (recovered_171_s[2] & recovered_171_co[1]) | (~recovered_171_s[2] & recovered_171_di[2]);
  assign recovered_171_o[3] = recovered_171_s[3] ^ recovered_171_co[2];
  assign recovered_171_co[3] = (recovered_171_s[3] & recovered_171_co[2]) | (~recovered_171_s[3] & recovered_171_di[3]);
  assign {esc_add_ln208_140_reg_8583_reg_7__i_1_n_0_50057e5 ,esc_NLW_add_ln208_140_reg_8583_reg_7__i_1_CO_UNCONNECTED_c4423df [2:0]} = recovered_171_co;
  assign esc_add_ln208_137_reg_8551_reg_13_711eea5 [7:4] = recovered_171_o;

  // Reconstructed LUT2: esc_add_ln208_143_reg_8615_3__i_2_abbeb3e
  assign esc_add_ln208_143_reg_8615_3__i_2_n_0_636c1d8 = ((DOADO[3]) ? (~(esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [3])) : (esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [3]));

  // Reconstructed LUT2: esc_add_ln208_143_reg_8615_3__i_3_fa8520e
  assign esc_add_ln208_143_reg_8615_3__i_3_n_0_311abfb = ((DOADO[2]) ? (~(esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [2])) : (esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [2]));

  // Reconstructed LUT2: esc_add_ln208_143_reg_8615_3__i_4_13cb05b
  assign esc_add_ln208_143_reg_8615_3__i_4_n_0_fe9ceb3 = ((DOADO[1]) ? (~(esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [1])) : (esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [1]));

  // Reconstructed LUT2: esc_add_ln208_143_reg_8615_3__i_5_419870e
  assign esc_add_ln208_143_reg_8615_3__i_5_n_0_60fcf4c = ((DOADO[0]) ? (~(esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [0])) : (esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [0]));

  // Reconstructed LUT2: esc_add_ln208_143_reg_8615_7__i_2_4dd19b5
  assign esc_add_ln208_143_reg_8615_7__i_2_n_0_c26d3bc = ((DOADO[7]) ? (~(esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [7])) : (esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [7]));

  // Reconstructed LUT2: esc_add_ln208_143_reg_8615_7__i_3_64dfac8
  assign esc_add_ln208_143_reg_8615_7__i_3_n_0_68e26a8 = ((DOADO[6]) ? (~(esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [6])) : (esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [6]));

  // Reconstructed LUT2: esc_add_ln208_143_reg_8615_7__i_4_dc84bea
  assign esc_add_ln208_143_reg_8615_7__i_4_n_0_bc01c24 = ((DOADO[5]) ? (~(esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [5])) : (esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [5]));

  // Reconstructed LUT2: esc_add_ln208_143_reg_8615_7__i_5_3a246a5
  assign esc_add_ln208_143_reg_8615_7__i_5_n_0_626914f = ((DOADO[4]) ? (~(esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [4])) : (esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [4]));

  // Reconstructed CARRY4: esc_add_ln208_143_reg_8615_reg_11__i_1_fc06500
  wire [3:0] recovered_180_co, recovered_180_o, recovered_180_s, recovered_180_di;
  assign recovered_180_s = esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [11:8];
  assign recovered_180_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_180_ci = ((esc_add_ln208_143_reg_8615_reg_7__i_1_n_0_152dc00) !== 1'bz) && (esc_add_ln208_143_reg_8615_reg_7__i_1_n_0_152dc00);
  wire recovered_180_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_180_o[0] = recovered_180_s[0] ^ (recovered_180_ci || recovered_180_cy);
  assign recovered_180_co[0] = (recovered_180_s[0] & (recovered_180_ci || recovered_180_cy)) | (~recovered_180_s[0] & recovered_180_di[0]);
  assign recovered_180_o[1] = recovered_180_s[1] ^ recovered_180_co[0];
  assign recovered_180_co[1] = (recovered_180_s[1] & recovered_180_co[0]) | (~recovered_180_s[1] & recovered_180_di[1]);
  assign recovered_180_o[2] = recovered_180_s[2] ^ recovered_180_co[1];
  assign recovered_180_co[2] = (recovered_180_s[2] & recovered_180_co[1]) | (~recovered_180_s[2] & recovered_180_di[2]);
  assign recovered_180_o[3] = recovered_180_s[3] ^ recovered_180_co[2];
  assign recovered_180_co[3] = (recovered_180_s[3] & recovered_180_co[2]) | (~recovered_180_s[3] & recovered_180_di[3]);
  assign {esc_add_ln208_143_reg_8615_reg_11__i_1_n_0_9fab781 ,esc_NLW_add_ln208_143_reg_8615_reg_11__i_1_CO_UNCONNECTED_63c0eaf [2:0]} = recovered_180_co;
  assign esc_add_ln208_140_reg_8583_reg_13_3a2afb7 [11:8] = recovered_180_o;

  // Reconstructed CARRY4: esc_add_ln208_143_reg_8615_reg_13__i_2_54ae56d
  wire [3:0] recovered_181_co, recovered_181_o, recovered_181_s, recovered_181_di;
  assign recovered_181_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [13:12]};
  assign recovered_181_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_181_ci = ((esc_add_ln208_143_reg_8615_reg_11__i_1_n_0_9fab781) !== 1'bz) && (esc_add_ln208_143_reg_8615_reg_11__i_1_n_0_9fab781);
  wire recovered_181_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_181_o[0] = recovered_181_s[0] ^ (recovered_181_ci || recovered_181_cy);
  assign recovered_181_co[0] = (recovered_181_s[0] & (recovered_181_ci || recovered_181_cy)) | (~recovered_181_s[0] & recovered_181_di[0]);
  assign recovered_181_o[1] = recovered_181_s[1] ^ recovered_181_co[0];
  assign recovered_181_co[1] = (recovered_181_s[1] & recovered_181_co[0]) | (~recovered_181_s[1] & recovered_181_di[1]);
  assign recovered_181_o[2] = recovered_181_s[2] ^ recovered_181_co[1];
  assign recovered_181_co[2] = (recovered_181_s[2] & recovered_181_co[1]) | (~recovered_181_s[2] & recovered_181_di[2]);
  assign recovered_181_o[3] = recovered_181_s[3] ^ recovered_181_co[2];
  assign recovered_181_co[3] = (recovered_181_s[3] & recovered_181_co[2]) | (~recovered_181_s[3] & recovered_181_di[3]);
  assign esc_add_ln208_140_reg_8583_reg_13_3a2afb7 [13:12] = recovered_181_o;

  // Reconstructed CARRY4: esc_add_ln208_143_reg_8615_reg_3__i_1_90e3a6c
  wire [3:0] recovered_182_co, recovered_182_o, recovered_182_s, recovered_182_di;
  assign recovered_182_s = {esc_add_ln208_143_reg_8615_3__i_2_n_0_636c1d8 ,esc_add_ln208_143_reg_8615_3__i_3_n_0_311abfb ,esc_add_ln208_143_reg_8615_3__i_4_n_0_fe9ceb3 ,esc_add_ln208_143_reg_8615_3__i_5_n_0_60fcf4c };
  assign recovered_182_di = esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [3:0];
  wire recovered_182_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_182_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_182_o[0] = recovered_182_s[0] ^ (recovered_182_ci || recovered_182_cy);
  assign recovered_182_co[0] = (recovered_182_s[0] & (recovered_182_ci || recovered_182_cy)) | (~recovered_182_s[0] & recovered_182_di[0]);
  assign recovered_182_o[1] = recovered_182_s[1] ^ recovered_182_co[0];
  assign recovered_182_co[1] = (recovered_182_s[1] & recovered_182_co[0]) | (~recovered_182_s[1] & recovered_182_di[1]);
  assign recovered_182_o[2] = recovered_182_s[2] ^ recovered_182_co[1];
  assign recovered_182_co[2] = (recovered_182_s[2] & recovered_182_co[1]) | (~recovered_182_s[2] & recovered_182_di[2]);
  assign recovered_182_o[3] = recovered_182_s[3] ^ recovered_182_co[2];
  assign recovered_182_co[3] = (recovered_182_s[3] & recovered_182_co[2]) | (~recovered_182_s[3] & recovered_182_di[3]);
  assign {esc_add_ln208_143_reg_8615_reg_3__i_1_n_0_6e474f0 ,esc_NLW_add_ln208_143_reg_8615_reg_3__i_1_CO_UNCONNECTED_5959e1f [2:0]} = recovered_182_co;
  assign esc_add_ln208_140_reg_8583_reg_13_3a2afb7 [3:0] = recovered_182_o;

  // Reconstructed CARRY4: esc_add_ln208_143_reg_8615_reg_7__i_1_694af39
  wire [3:0] recovered_183_co, recovered_183_o, recovered_183_s, recovered_183_di;
  assign recovered_183_s = {esc_add_ln208_143_reg_8615_7__i_2_n_0_c26d3bc ,esc_add_ln208_143_reg_8615_7__i_3_n_0_68e26a8 ,esc_add_ln208_143_reg_8615_7__i_4_n_0_bc01c24 ,esc_add_ln208_143_reg_8615_7__i_5_n_0_626914f };
  assign recovered_183_di = esc_add_ln208_143_reg_8615_reg_13__0_8320cd1 [7:4];
  wire recovered_183_ci = ((esc_add_ln208_143_reg_8615_reg_3__i_1_n_0_6e474f0) !== 1'bz) && (esc_add_ln208_143_reg_8615_reg_3__i_1_n_0_6e474f0);
  wire recovered_183_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_183_o[0] = recovered_183_s[0] ^ (recovered_183_ci || recovered_183_cy);
  assign recovered_183_co[0] = (recovered_183_s[0] & (recovered_183_ci || recovered_183_cy)) | (~recovered_183_s[0] & recovered_183_di[0]);
  assign recovered_183_o[1] = recovered_183_s[1] ^ recovered_183_co[0];
  assign recovered_183_co[1] = (recovered_183_s[1] & recovered_183_co[0]) | (~recovered_183_s[1] & recovered_183_di[1]);
  assign recovered_183_o[2] = recovered_183_s[2] ^ recovered_183_co[1];
  assign recovered_183_co[2] = (recovered_183_s[2] & recovered_183_co[1]) | (~recovered_183_s[2] & recovered_183_di[2]);
  assign recovered_183_o[3] = recovered_183_s[3] ^ recovered_183_co[2];
  assign recovered_183_co[3] = (recovered_183_s[3] & recovered_183_co[2]) | (~recovered_183_s[3] & recovered_183_di[3]);
  assign {esc_add_ln208_143_reg_8615_reg_7__i_1_n_0_152dc00 ,esc_NLW_add_ln208_143_reg_8615_reg_7__i_1_CO_UNCONNECTED_ef1bbcc [2:0]} = recovered_183_co;
  assign esc_add_ln208_140_reg_8583_reg_13_3a2afb7 [7:4] = recovered_183_o;

  // Reconstructed LUT2: esc_add_ln208_146_reg_8647_3__i_2_318c1b6
  assign esc_add_ln208_146_reg_8647_3__i_2_n_0_ef6a05d = ((DOADO[3]) ? (~(esc_add_ln208_146_reg_8647_reg_13__0_24263ad [3])) : (esc_add_ln208_146_reg_8647_reg_13__0_24263ad [3]));

  // Reconstructed LUT2: esc_add_ln208_146_reg_8647_3__i_3_d556a62
  assign esc_add_ln208_146_reg_8647_3__i_3_n_0_f842a07 = ((DOADO[2]) ? (~(esc_add_ln208_146_reg_8647_reg_13__0_24263ad [2])) : (esc_add_ln208_146_reg_8647_reg_13__0_24263ad [2]));

  // Reconstructed LUT2: esc_add_ln208_146_reg_8647_3__i_4_d2c0713
  assign esc_add_ln208_146_reg_8647_3__i_4_n_0_5001f18 = ((DOADO[1]) ? (~(esc_add_ln208_146_reg_8647_reg_13__0_24263ad [1])) : (esc_add_ln208_146_reg_8647_reg_13__0_24263ad [1]));

  // Reconstructed LUT2: esc_add_ln208_146_reg_8647_3__i_5_3f1e8c3
  assign esc_add_ln208_146_reg_8647_3__i_5_n_0_1177c92 = ((DOADO[0]) ? (~(esc_add_ln208_146_reg_8647_reg_13__0_24263ad [0])) : (esc_add_ln208_146_reg_8647_reg_13__0_24263ad [0]));

  // Reconstructed LUT2: esc_add_ln208_146_reg_8647_7__i_2_feec8cd
  assign esc_add_ln208_146_reg_8647_7__i_2_n_0_c0740ec = ((DOADO[7]) ? (~(esc_add_ln208_146_reg_8647_reg_13__0_24263ad [7])) : (esc_add_ln208_146_reg_8647_reg_13__0_24263ad [7]));

  // Reconstructed LUT2: esc_add_ln208_146_reg_8647_7__i_3_93020f4
  assign esc_add_ln208_146_reg_8647_7__i_3_n_0_86398a0 = ((DOADO[6]) ? (~(esc_add_ln208_146_reg_8647_reg_13__0_24263ad [6])) : (esc_add_ln208_146_reg_8647_reg_13__0_24263ad [6]));

  // Reconstructed LUT2: esc_add_ln208_146_reg_8647_7__i_4_eaf920e
  assign esc_add_ln208_146_reg_8647_7__i_4_n_0_7810831 = ((DOADO[5]) ? (~(esc_add_ln208_146_reg_8647_reg_13__0_24263ad [5])) : (esc_add_ln208_146_reg_8647_reg_13__0_24263ad [5]));

  // Reconstructed LUT2: esc_add_ln208_146_reg_8647_7__i_5_947cdb0
  assign esc_add_ln208_146_reg_8647_7__i_5_n_0_b003e6f = ((DOADO[4]) ? (~(esc_add_ln208_146_reg_8647_reg_13__0_24263ad [4])) : (esc_add_ln208_146_reg_8647_reg_13__0_24263ad [4]));

  // Reconstructed CARRY4: esc_add_ln208_146_reg_8647_reg_11__i_1_26808ed
  wire [3:0] recovered_192_co, recovered_192_o, recovered_192_s, recovered_192_di;
  assign recovered_192_s = esc_add_ln208_146_reg_8647_reg_13__0_24263ad [11:8];
  assign recovered_192_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_192_ci = ((esc_add_ln208_146_reg_8647_reg_7__i_1_n_0_403eb86) !== 1'bz) && (esc_add_ln208_146_reg_8647_reg_7__i_1_n_0_403eb86);
  wire recovered_192_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_192_o[0] = recovered_192_s[0] ^ (recovered_192_ci || recovered_192_cy);
  assign recovered_192_co[0] = (recovered_192_s[0] & (recovered_192_ci || recovered_192_cy)) | (~recovered_192_s[0] & recovered_192_di[0]);
  assign recovered_192_o[1] = recovered_192_s[1] ^ recovered_192_co[0];
  assign recovered_192_co[1] = (recovered_192_s[1] & recovered_192_co[0]) | (~recovered_192_s[1] & recovered_192_di[1]);
  assign recovered_192_o[2] = recovered_192_s[2] ^ recovered_192_co[1];
  assign recovered_192_co[2] = (recovered_192_s[2] & recovered_192_co[1]) | (~recovered_192_s[2] & recovered_192_di[2]);
  assign recovered_192_o[3] = recovered_192_s[3] ^ recovered_192_co[2];
  assign recovered_192_co[3] = (recovered_192_s[3] & recovered_192_co[2]) | (~recovered_192_s[3] & recovered_192_di[3]);
  assign {esc_add_ln208_146_reg_8647_reg_11__i_1_n_0_93e94f3 ,esc_NLW_add_ln208_146_reg_8647_reg_11__i_1_CO_UNCONNECTED_2fb2c09 [2:0]} = recovered_192_co;
  assign esc_add_ln208_143_reg_8615_reg_13_7ea25a2 [11:8] = recovered_192_o;

  // Reconstructed CARRY4: esc_add_ln208_146_reg_8647_reg_13__i_2_8065892
  wire [3:0] recovered_193_co, recovered_193_o, recovered_193_s, recovered_193_di;
  assign recovered_193_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_146_reg_8647_reg_13__0_24263ad [13:12]};
  assign recovered_193_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_193_ci = ((esc_add_ln208_146_reg_8647_reg_11__i_1_n_0_93e94f3) !== 1'bz) && (esc_add_ln208_146_reg_8647_reg_11__i_1_n_0_93e94f3);
  wire recovered_193_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_193_o[0] = recovered_193_s[0] ^ (recovered_193_ci || recovered_193_cy);
  assign recovered_193_co[0] = (recovered_193_s[0] & (recovered_193_ci || recovered_193_cy)) | (~recovered_193_s[0] & recovered_193_di[0]);
  assign recovered_193_o[1] = recovered_193_s[1] ^ recovered_193_co[0];
  assign recovered_193_co[1] = (recovered_193_s[1] & recovered_193_co[0]) | (~recovered_193_s[1] & recovered_193_di[1]);
  assign recovered_193_o[2] = recovered_193_s[2] ^ recovered_193_co[1];
  assign recovered_193_co[2] = (recovered_193_s[2] & recovered_193_co[1]) | (~recovered_193_s[2] & recovered_193_di[2]);
  assign recovered_193_o[3] = recovered_193_s[3] ^ recovered_193_co[2];
  assign recovered_193_co[3] = (recovered_193_s[3] & recovered_193_co[2]) | (~recovered_193_s[3] & recovered_193_di[3]);
  assign esc_add_ln208_143_reg_8615_reg_13_7ea25a2 [13:12] = recovered_193_o;

  // Reconstructed CARRY4: esc_add_ln208_146_reg_8647_reg_3__i_1_ae35f28
  wire [3:0] recovered_194_co, recovered_194_o, recovered_194_s, recovered_194_di;
  assign recovered_194_s = {esc_add_ln208_146_reg_8647_3__i_2_n_0_ef6a05d ,esc_add_ln208_146_reg_8647_3__i_3_n_0_f842a07 ,esc_add_ln208_146_reg_8647_3__i_4_n_0_5001f18 ,esc_add_ln208_146_reg_8647_3__i_5_n_0_1177c92 };
  assign recovered_194_di = esc_add_ln208_146_reg_8647_reg_13__0_24263ad [3:0];
  wire recovered_194_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_194_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_194_o[0] = recovered_194_s[0] ^ (recovered_194_ci || recovered_194_cy);
  assign recovered_194_co[0] = (recovered_194_s[0] & (recovered_194_ci || recovered_194_cy)) | (~recovered_194_s[0] & recovered_194_di[0]);
  assign recovered_194_o[1] = recovered_194_s[1] ^ recovered_194_co[0];
  assign recovered_194_co[1] = (recovered_194_s[1] & recovered_194_co[0]) | (~recovered_194_s[1] & recovered_194_di[1]);
  assign recovered_194_o[2] = recovered_194_s[2] ^ recovered_194_co[1];
  assign recovered_194_co[2] = (recovered_194_s[2] & recovered_194_co[1]) | (~recovered_194_s[2] & recovered_194_di[2]);
  assign recovered_194_o[3] = recovered_194_s[3] ^ recovered_194_co[2];
  assign recovered_194_co[3] = (recovered_194_s[3] & recovered_194_co[2]) | (~recovered_194_s[3] & recovered_194_di[3]);
  assign {esc_add_ln208_146_reg_8647_reg_3__i_1_n_0_37a3acc ,esc_NLW_add_ln208_146_reg_8647_reg_3__i_1_CO_UNCONNECTED_a97048d [2:0]} = recovered_194_co;
  assign esc_add_ln208_143_reg_8615_reg_13_7ea25a2 [3:0] = recovered_194_o;

  // Reconstructed CARRY4: esc_add_ln208_146_reg_8647_reg_7__i_1_f71844d
  wire [3:0] recovered_195_co, recovered_195_o, recovered_195_s, recovered_195_di;
  assign recovered_195_s = {esc_add_ln208_146_reg_8647_7__i_2_n_0_c0740ec ,esc_add_ln208_146_reg_8647_7__i_3_n_0_86398a0 ,esc_add_ln208_146_reg_8647_7__i_4_n_0_7810831 ,esc_add_ln208_146_reg_8647_7__i_5_n_0_b003e6f };
  assign recovered_195_di = esc_add_ln208_146_reg_8647_reg_13__0_24263ad [7:4];
  wire recovered_195_ci = ((esc_add_ln208_146_reg_8647_reg_3__i_1_n_0_37a3acc) !== 1'bz) && (esc_add_ln208_146_reg_8647_reg_3__i_1_n_0_37a3acc);
  wire recovered_195_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_195_o[0] = recovered_195_s[0] ^ (recovered_195_ci || recovered_195_cy);
  assign recovered_195_co[0] = (recovered_195_s[0] & (recovered_195_ci || recovered_195_cy)) | (~recovered_195_s[0] & recovered_195_di[0]);
  assign recovered_195_o[1] = recovered_195_s[1] ^ recovered_195_co[0];
  assign recovered_195_co[1] = (recovered_195_s[1] & recovered_195_co[0]) | (~recovered_195_s[1] & recovered_195_di[1]);
  assign recovered_195_o[2] = recovered_195_s[2] ^ recovered_195_co[1];
  assign recovered_195_co[2] = (recovered_195_s[2] & recovered_195_co[1]) | (~recovered_195_s[2] & recovered_195_di[2]);
  assign recovered_195_o[3] = recovered_195_s[3] ^ recovered_195_co[2];
  assign recovered_195_co[3] = (recovered_195_s[3] & recovered_195_co[2]) | (~recovered_195_s[3] & recovered_195_di[3]);
  assign {esc_add_ln208_146_reg_8647_reg_7__i_1_n_0_403eb86 ,esc_NLW_add_ln208_146_reg_8647_reg_7__i_1_CO_UNCONNECTED_9f8b11c [2:0]} = recovered_195_co;
  assign esc_add_ln208_143_reg_8615_reg_13_7ea25a2 [7:4] = recovered_195_o;

  // Reconstructed LUT2: esc_add_ln208_149_reg_8679_3__i_2_ed8065c
  assign esc_add_ln208_149_reg_8679_3__i_2_n_0_8a301ab = ((DOADO[3]) ? (~(esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [3])) : (esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [3]));

  // Reconstructed LUT2: esc_add_ln208_149_reg_8679_3__i_3_669c06f
  assign esc_add_ln208_149_reg_8679_3__i_3_n_0_a25d75a = ((DOADO[2]) ? (~(esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [2])) : (esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [2]));

  // Reconstructed LUT2: esc_add_ln208_149_reg_8679_3__i_4_3469b21
  assign esc_add_ln208_149_reg_8679_3__i_4_n_0_3405b5c = ((DOADO[1]) ? (~(esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [1])) : (esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [1]));

  // Reconstructed LUT2: esc_add_ln208_149_reg_8679_3__i_5_a095b86
  assign esc_add_ln208_149_reg_8679_3__i_5_n_0_ee00f1a = ((DOADO[0]) ? (~(esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [0])) : (esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [0]));

  // Reconstructed LUT2: esc_add_ln208_149_reg_8679_7__i_2_049f746
  assign esc_add_ln208_149_reg_8679_7__i_2_n_0_9f83f46 = ((DOADO[7]) ? (~(esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [7])) : (esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [7]));

  // Reconstructed LUT2: esc_add_ln208_149_reg_8679_7__i_3_842af87
  assign esc_add_ln208_149_reg_8679_7__i_3_n_0_5125bcb = ((DOADO[6]) ? (~(esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [6])) : (esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [6]));

  // Reconstructed LUT2: esc_add_ln208_149_reg_8679_7__i_4_65edb8d
  assign esc_add_ln208_149_reg_8679_7__i_4_n_0_bd2ae98 = ((DOADO[5]) ? (~(esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [5])) : (esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [5]));

  // Reconstructed LUT2: esc_add_ln208_149_reg_8679_7__i_5_39e17d8
  assign esc_add_ln208_149_reg_8679_7__i_5_n_0_8e90a07 = ((DOADO[4]) ? (~(esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [4])) : (esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [4]));

  // Reconstructed CARRY4: esc_add_ln208_149_reg_8679_reg_11__i_1_724cb6a
  wire [3:0] recovered_204_co, recovered_204_o, recovered_204_s, recovered_204_di;
  assign recovered_204_s = esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [11:8];
  assign recovered_204_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_204_ci = ((esc_add_ln208_149_reg_8679_reg_7__i_1_n_0_04b99c2) !== 1'bz) && (esc_add_ln208_149_reg_8679_reg_7__i_1_n_0_04b99c2);
  wire recovered_204_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_204_o[0] = recovered_204_s[0] ^ (recovered_204_ci || recovered_204_cy);
  assign recovered_204_co[0] = (recovered_204_s[0] & (recovered_204_ci || recovered_204_cy)) | (~recovered_204_s[0] & recovered_204_di[0]);
  assign recovered_204_o[1] = recovered_204_s[1] ^ recovered_204_co[0];
  assign recovered_204_co[1] = (recovered_204_s[1] & recovered_204_co[0]) | (~recovered_204_s[1] & recovered_204_di[1]);
  assign recovered_204_o[2] = recovered_204_s[2] ^ recovered_204_co[1];
  assign recovered_204_co[2] = (recovered_204_s[2] & recovered_204_co[1]) | (~recovered_204_s[2] & recovered_204_di[2]);
  assign recovered_204_o[3] = recovered_204_s[3] ^ recovered_204_co[2];
  assign recovered_204_co[3] = (recovered_204_s[3] & recovered_204_co[2]) | (~recovered_204_s[3] & recovered_204_di[3]);
  assign {esc_add_ln208_149_reg_8679_reg_11__i_1_n_0_8ffda78 ,esc_NLW_add_ln208_149_reg_8679_reg_11__i_1_CO_UNCONNECTED_2fd82b6 [2:0]} = recovered_204_co;
  assign esc_add_ln208_146_reg_8647_reg_13_c285ab8 [11:8] = recovered_204_o;

  // Reconstructed CARRY4: esc_add_ln208_149_reg_8679_reg_13__i_2_a3c5470
  wire [3:0] recovered_205_co, recovered_205_o, recovered_205_s, recovered_205_di;
  assign recovered_205_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [13:12]};
  assign recovered_205_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_205_ci = ((esc_add_ln208_149_reg_8679_reg_11__i_1_n_0_8ffda78) !== 1'bz) && (esc_add_ln208_149_reg_8679_reg_11__i_1_n_0_8ffda78);
  wire recovered_205_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_205_o[0] = recovered_205_s[0] ^ (recovered_205_ci || recovered_205_cy);
  assign recovered_205_co[0] = (recovered_205_s[0] & (recovered_205_ci || recovered_205_cy)) | (~recovered_205_s[0] & recovered_205_di[0]);
  assign recovered_205_o[1] = recovered_205_s[1] ^ recovered_205_co[0];
  assign recovered_205_co[1] = (recovered_205_s[1] & recovered_205_co[0]) | (~recovered_205_s[1] & recovered_205_di[1]);
  assign recovered_205_o[2] = recovered_205_s[2] ^ recovered_205_co[1];
  assign recovered_205_co[2] = (recovered_205_s[2] & recovered_205_co[1]) | (~recovered_205_s[2] & recovered_205_di[2]);
  assign recovered_205_o[3] = recovered_205_s[3] ^ recovered_205_co[2];
  assign recovered_205_co[3] = (recovered_205_s[3] & recovered_205_co[2]) | (~recovered_205_s[3] & recovered_205_di[3]);
  assign esc_add_ln208_146_reg_8647_reg_13_c285ab8 [13:12] = recovered_205_o;

  // Reconstructed CARRY4: esc_add_ln208_149_reg_8679_reg_3__i_1_ae33772
  wire [3:0] recovered_206_co, recovered_206_o, recovered_206_s, recovered_206_di;
  assign recovered_206_s = {esc_add_ln208_149_reg_8679_3__i_2_n_0_8a301ab ,esc_add_ln208_149_reg_8679_3__i_3_n_0_a25d75a ,esc_add_ln208_149_reg_8679_3__i_4_n_0_3405b5c ,esc_add_ln208_149_reg_8679_3__i_5_n_0_ee00f1a };
  assign recovered_206_di = esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [3:0];
  wire recovered_206_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_206_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_206_o[0] = recovered_206_s[0] ^ (recovered_206_ci || recovered_206_cy);
  assign recovered_206_co[0] = (recovered_206_s[0] & (recovered_206_ci || recovered_206_cy)) | (~recovered_206_s[0] & recovered_206_di[0]);
  assign recovered_206_o[1] = recovered_206_s[1] ^ recovered_206_co[0];
  assign recovered_206_co[1] = (recovered_206_s[1] & recovered_206_co[0]) | (~recovered_206_s[1] & recovered_206_di[1]);
  assign recovered_206_o[2] = recovered_206_s[2] ^ recovered_206_co[1];
  assign recovered_206_co[2] = (recovered_206_s[2] & recovered_206_co[1]) | (~recovered_206_s[2] & recovered_206_di[2]);
  assign recovered_206_o[3] = recovered_206_s[3] ^ recovered_206_co[2];
  assign recovered_206_co[3] = (recovered_206_s[3] & recovered_206_co[2]) | (~recovered_206_s[3] & recovered_206_di[3]);
  assign {esc_add_ln208_149_reg_8679_reg_3__i_1_n_0_7227bdf ,esc_NLW_add_ln208_149_reg_8679_reg_3__i_1_CO_UNCONNECTED_2556e63 [2:0]} = recovered_206_co;
  assign esc_add_ln208_146_reg_8647_reg_13_c285ab8 [3:0] = recovered_206_o;

  // Reconstructed CARRY4: esc_add_ln208_149_reg_8679_reg_7__i_1_2d86e66
  wire [3:0] recovered_207_co, recovered_207_o, recovered_207_s, recovered_207_di;
  assign recovered_207_s = {esc_add_ln208_149_reg_8679_7__i_2_n_0_9f83f46 ,esc_add_ln208_149_reg_8679_7__i_3_n_0_5125bcb ,esc_add_ln208_149_reg_8679_7__i_4_n_0_bd2ae98 ,esc_add_ln208_149_reg_8679_7__i_5_n_0_8e90a07 };
  assign recovered_207_di = esc_add_ln208_149_reg_8679_reg_13__0_b628b5d [7:4];
  wire recovered_207_ci = ((esc_add_ln208_149_reg_8679_reg_3__i_1_n_0_7227bdf) !== 1'bz) && (esc_add_ln208_149_reg_8679_reg_3__i_1_n_0_7227bdf);
  wire recovered_207_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_207_o[0] = recovered_207_s[0] ^ (recovered_207_ci || recovered_207_cy);
  assign recovered_207_co[0] = (recovered_207_s[0] & (recovered_207_ci || recovered_207_cy)) | (~recovered_207_s[0] & recovered_207_di[0]);
  assign recovered_207_o[1] = recovered_207_s[1] ^ recovered_207_co[0];
  assign recovered_207_co[1] = (recovered_207_s[1] & recovered_207_co[0]) | (~recovered_207_s[1] & recovered_207_di[1]);
  assign recovered_207_o[2] = recovered_207_s[2] ^ recovered_207_co[1];
  assign recovered_207_co[2] = (recovered_207_s[2] & recovered_207_co[1]) | (~recovered_207_s[2] & recovered_207_di[2]);
  assign recovered_207_o[3] = recovered_207_s[3] ^ recovered_207_co[2];
  assign recovered_207_co[3] = (recovered_207_s[3] & recovered_207_co[2]) | (~recovered_207_s[3] & recovered_207_di[3]);
  assign {esc_add_ln208_149_reg_8679_reg_7__i_1_n_0_04b99c2 ,esc_NLW_add_ln208_149_reg_8679_reg_7__i_1_CO_UNCONNECTED_72c72db [2:0]} = recovered_207_co;
  assign esc_add_ln208_146_reg_8647_reg_13_c285ab8 [7:4] = recovered_207_o;

  // Reconstructed LUT2: esc_add_ln208_152_reg_8711_3__i_2_7b6f09e
  assign esc_add_ln208_152_reg_8711_3__i_2_n_0_e996f01 = ((DOADO[3]) ? (~(esc_add_ln208_152_reg_8711_reg_13_848699e [3])) : (esc_add_ln208_152_reg_8711_reg_13_848699e [3]));

  // Reconstructed LUT2: esc_add_ln208_152_reg_8711_3__i_3_06362cb
  assign esc_add_ln208_152_reg_8711_3__i_3_n_0_0ca6af8 = ((DOADO[2]) ? (~(esc_add_ln208_152_reg_8711_reg_13_848699e [2])) : (esc_add_ln208_152_reg_8711_reg_13_848699e [2]));

  // Reconstructed LUT2: esc_add_ln208_152_reg_8711_3__i_4_1867c8a
  assign esc_add_ln208_152_reg_8711_3__i_4_n_0_baba261 = ((DOADO[1]) ? (~(esc_add_ln208_152_reg_8711_reg_13_848699e [1])) : (esc_add_ln208_152_reg_8711_reg_13_848699e [1]));

  // Reconstructed LUT2: esc_add_ln208_152_reg_8711_3__i_5_dbd3dc6
  assign esc_add_ln208_152_reg_8711_3__i_5_n_0_3b91a4e = ((DOADO[0]) ? (~(esc_add_ln208_152_reg_8711_reg_13_848699e [0])) : (esc_add_ln208_152_reg_8711_reg_13_848699e [0]));

  // Reconstructed LUT2: esc_add_ln208_152_reg_8711_7__i_2_bda147d
  assign esc_add_ln208_152_reg_8711_7__i_2_n_0_ed9973b = ((DOADO[7]) ? (~(esc_add_ln208_152_reg_8711_reg_13_848699e [7])) : (esc_add_ln208_152_reg_8711_reg_13_848699e [7]));

  // Reconstructed LUT2: esc_add_ln208_152_reg_8711_7__i_3_1ccdab4
  assign esc_add_ln208_152_reg_8711_7__i_3_n_0_ce7010c = ((DOADO[6]) ? (~(esc_add_ln208_152_reg_8711_reg_13_848699e [6])) : (esc_add_ln208_152_reg_8711_reg_13_848699e [6]));

  // Reconstructed LUT2: esc_add_ln208_152_reg_8711_7__i_4_4d77cc3
  assign esc_add_ln208_152_reg_8711_7__i_4_n_0_13af8e6 = ((DOADO[5]) ? (~(esc_add_ln208_152_reg_8711_reg_13_848699e [5])) : (esc_add_ln208_152_reg_8711_reg_13_848699e [5]));

  // Reconstructed LUT2: esc_add_ln208_152_reg_8711_7__i_5_b04991e
  assign esc_add_ln208_152_reg_8711_7__i_5_n_0_b6a9da2 = ((DOADO[4]) ? (~(esc_add_ln208_152_reg_8711_reg_13_848699e [4])) : (esc_add_ln208_152_reg_8711_reg_13_848699e [4]));

  // Reconstructed CARRY4: esc_add_ln208_152_reg_8711_reg_11__i_1_3d0c737
  wire [3:0] recovered_216_co, recovered_216_o, recovered_216_s, recovered_216_di;
  assign recovered_216_s = esc_add_ln208_152_reg_8711_reg_13_848699e [11:8];
  assign recovered_216_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_216_ci = ((esc_add_ln208_152_reg_8711_reg_7__i_1_n_0_84f8c9b) !== 1'bz) && (esc_add_ln208_152_reg_8711_reg_7__i_1_n_0_84f8c9b);
  wire recovered_216_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_216_o[0] = recovered_216_s[0] ^ (recovered_216_ci || recovered_216_cy);
  assign recovered_216_co[0] = (recovered_216_s[0] & (recovered_216_ci || recovered_216_cy)) | (~recovered_216_s[0] & recovered_216_di[0]);
  assign recovered_216_o[1] = recovered_216_s[1] ^ recovered_216_co[0];
  assign recovered_216_co[1] = (recovered_216_s[1] & recovered_216_co[0]) | (~recovered_216_s[1] & recovered_216_di[1]);
  assign recovered_216_o[2] = recovered_216_s[2] ^ recovered_216_co[1];
  assign recovered_216_co[2] = (recovered_216_s[2] & recovered_216_co[1]) | (~recovered_216_s[2] & recovered_216_di[2]);
  assign recovered_216_o[3] = recovered_216_s[3] ^ recovered_216_co[2];
  assign recovered_216_co[3] = (recovered_216_s[3] & recovered_216_co[2]) | (~recovered_216_s[3] & recovered_216_di[3]);
  assign {esc_add_ln208_152_reg_8711_reg_11__i_1_n_0_3461e44 ,esc_NLW_add_ln208_152_reg_8711_reg_11__i_1_CO_UNCONNECTED_da760e3 [2:0]} = recovered_216_co;
  assign esc_add_ln208_149_reg_8679_reg_13_a787366 [11:8] = recovered_216_o;

  // Reconstructed CARRY4: esc_add_ln208_152_reg_8711_reg_13__i_2_be6fdf3
  wire [3:0] recovered_217_co, recovered_217_o, recovered_217_s, recovered_217_di;
  assign recovered_217_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_152_reg_8711_reg_13_848699e [13:12]};
  assign recovered_217_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_217_ci = ((esc_add_ln208_152_reg_8711_reg_11__i_1_n_0_3461e44) !== 1'bz) && (esc_add_ln208_152_reg_8711_reg_11__i_1_n_0_3461e44);
  wire recovered_217_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_217_o[0] = recovered_217_s[0] ^ (recovered_217_ci || recovered_217_cy);
  assign recovered_217_co[0] = (recovered_217_s[0] & (recovered_217_ci || recovered_217_cy)) | (~recovered_217_s[0] & recovered_217_di[0]);
  assign recovered_217_o[1] = recovered_217_s[1] ^ recovered_217_co[0];
  assign recovered_217_co[1] = (recovered_217_s[1] & recovered_217_co[0]) | (~recovered_217_s[1] & recovered_217_di[1]);
  assign recovered_217_o[2] = recovered_217_s[2] ^ recovered_217_co[1];
  assign recovered_217_co[2] = (recovered_217_s[2] & recovered_217_co[1]) | (~recovered_217_s[2] & recovered_217_di[2]);
  assign recovered_217_o[3] = recovered_217_s[3] ^ recovered_217_co[2];
  assign recovered_217_co[3] = (recovered_217_s[3] & recovered_217_co[2]) | (~recovered_217_s[3] & recovered_217_di[3]);
  assign esc_add_ln208_149_reg_8679_reg_13_a787366 [13:12] = recovered_217_o;

  // Reconstructed CARRY4: esc_add_ln208_152_reg_8711_reg_3__i_1_897c434
  wire [3:0] recovered_218_co, recovered_218_o, recovered_218_s, recovered_218_di;
  assign recovered_218_s = {esc_add_ln208_152_reg_8711_3__i_2_n_0_e996f01 ,esc_add_ln208_152_reg_8711_3__i_3_n_0_0ca6af8 ,esc_add_ln208_152_reg_8711_3__i_4_n_0_baba261 ,esc_add_ln208_152_reg_8711_3__i_5_n_0_3b91a4e };
  assign recovered_218_di = esc_add_ln208_152_reg_8711_reg_13_848699e [3:0];
  wire recovered_218_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_218_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_218_o[0] = recovered_218_s[0] ^ (recovered_218_ci || recovered_218_cy);
  assign recovered_218_co[0] = (recovered_218_s[0] & (recovered_218_ci || recovered_218_cy)) | (~recovered_218_s[0] & recovered_218_di[0]);
  assign recovered_218_o[1] = recovered_218_s[1] ^ recovered_218_co[0];
  assign recovered_218_co[1] = (recovered_218_s[1] & recovered_218_co[0]) | (~recovered_218_s[1] & recovered_218_di[1]);
  assign recovered_218_o[2] = recovered_218_s[2] ^ recovered_218_co[1];
  assign recovered_218_co[2] = (recovered_218_s[2] & recovered_218_co[1]) | (~recovered_218_s[2] & recovered_218_di[2]);
  assign recovered_218_o[3] = recovered_218_s[3] ^ recovered_218_co[2];
  assign recovered_218_co[3] = (recovered_218_s[3] & recovered_218_co[2]) | (~recovered_218_s[3] & recovered_218_di[3]);
  assign {esc_add_ln208_152_reg_8711_reg_3__i_1_n_0_0cc1d1a ,esc_NLW_add_ln208_152_reg_8711_reg_3__i_1_CO_UNCONNECTED_8ee9dfe [2:0]} = recovered_218_co;
  assign esc_add_ln208_149_reg_8679_reg_13_a787366 [3:0] = recovered_218_o;

  // Reconstructed CARRY4: esc_add_ln208_152_reg_8711_reg_7__i_1_2c0ca95
  wire [3:0] recovered_219_co, recovered_219_o, recovered_219_s, recovered_219_di;
  assign recovered_219_s = {esc_add_ln208_152_reg_8711_7__i_2_n_0_ed9973b ,esc_add_ln208_152_reg_8711_7__i_3_n_0_ce7010c ,esc_add_ln208_152_reg_8711_7__i_4_n_0_13af8e6 ,esc_add_ln208_152_reg_8711_7__i_5_n_0_b6a9da2 };
  assign recovered_219_di = esc_add_ln208_152_reg_8711_reg_13_848699e [7:4];
  wire recovered_219_ci = ((esc_add_ln208_152_reg_8711_reg_3__i_1_n_0_0cc1d1a) !== 1'bz) && (esc_add_ln208_152_reg_8711_reg_3__i_1_n_0_0cc1d1a);
  wire recovered_219_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_219_o[0] = recovered_219_s[0] ^ (recovered_219_ci || recovered_219_cy);
  assign recovered_219_co[0] = (recovered_219_s[0] & (recovered_219_ci || recovered_219_cy)) | (~recovered_219_s[0] & recovered_219_di[0]);
  assign recovered_219_o[1] = recovered_219_s[1] ^ recovered_219_co[0];
  assign recovered_219_co[1] = (recovered_219_s[1] & recovered_219_co[0]) | (~recovered_219_s[1] & recovered_219_di[1]);
  assign recovered_219_o[2] = recovered_219_s[2] ^ recovered_219_co[1];
  assign recovered_219_co[2] = (recovered_219_s[2] & recovered_219_co[1]) | (~recovered_219_s[2] & recovered_219_di[2]);
  assign recovered_219_o[3] = recovered_219_s[3] ^ recovered_219_co[2];
  assign recovered_219_co[3] = (recovered_219_s[3] & recovered_219_co[2]) | (~recovered_219_s[3] & recovered_219_di[3]);
  assign {esc_add_ln208_152_reg_8711_reg_7__i_1_n_0_84f8c9b ,esc_NLW_add_ln208_152_reg_8711_reg_7__i_1_CO_UNCONNECTED_3274c78 [2:0]} = recovered_219_co;
  assign esc_add_ln208_149_reg_8679_reg_13_a787366 [7:4] = recovered_219_o;

  // Reconstructed LUT2: esc_add_ln208_39_reg_8728_3__i_10_39d8e35
  assign esc_add_ln208_39_reg_8728_3__i_10_n_0_403481d = ((DOADO[0]) ? (~(esc_add_ln208_39_reg_8728_reg_15_81ea661 [0])) : (esc_add_ln208_39_reg_8728_reg_15_81ea661 [0]));

  // Reconstructed LUT2: esc_add_ln208_39_reg_8728_3__i_7_d0c65bf
  assign esc_add_ln208_39_reg_8728_3__i_7_n_0_22aaad8 = ((DOADO[3]) ? (~(esc_add_ln208_39_reg_8728_reg_15_81ea661 [3])) : (esc_add_ln208_39_reg_8728_reg_15_81ea661 [3]));

  // Reconstructed LUT2: esc_add_ln208_39_reg_8728_3__i_8_99b9907
  assign esc_add_ln208_39_reg_8728_3__i_8_n_0_f24e38d = ((DOADO[2]) ? (~(esc_add_ln208_39_reg_8728_reg_15_81ea661 [2])) : (esc_add_ln208_39_reg_8728_reg_15_81ea661 [2]));

  // Reconstructed LUT2: esc_add_ln208_39_reg_8728_3__i_9_46d47cb
  assign esc_add_ln208_39_reg_8728_3__i_9_n_0_28e464e = ((DOADO[1]) ? (~(esc_add_ln208_39_reg_8728_reg_15_81ea661 [1])) : (esc_add_ln208_39_reg_8728_reg_15_81ea661 [1]));

  // Reconstructed LUT2: esc_add_ln208_39_reg_8728_7__i_10_bb7f12c
  assign esc_add_ln208_39_reg_8728_7__i_10_n_0_367f83d = ((DOADO[4]) ? (~(esc_add_ln208_39_reg_8728_reg_15_81ea661 [4])) : (esc_add_ln208_39_reg_8728_reg_15_81ea661 [4]));

  // Reconstructed LUT2: esc_add_ln208_39_reg_8728_7__i_7_8f29d72
  assign esc_add_ln208_39_reg_8728_7__i_7_n_0_fbf9927 = ((DOADO[7]) ? (~(esc_add_ln208_39_reg_8728_reg_15_81ea661 [7])) : (esc_add_ln208_39_reg_8728_reg_15_81ea661 [7]));

  // Reconstructed LUT2: esc_add_ln208_39_reg_8728_7__i_8_8ec3ffb
  assign esc_add_ln208_39_reg_8728_7__i_8_n_0_a64a1e7 = ((DOADO[6]) ? (~(esc_add_ln208_39_reg_8728_reg_15_81ea661 [6])) : (esc_add_ln208_39_reg_8728_reg_15_81ea661 [6]));

  // Reconstructed LUT2: esc_add_ln208_39_reg_8728_7__i_9_45ff94b
  assign esc_add_ln208_39_reg_8728_7__i_9_n_0_40eeeff = ((DOADO[5]) ? (~(esc_add_ln208_39_reg_8728_reg_15_81ea661 [5])) : (esc_add_ln208_39_reg_8728_reg_15_81ea661 [5]));

  // Reconstructed CARRY4: esc_add_ln208_39_reg_8728_reg_11__i_2_a41694b
  wire [3:0] recovered_228_co, recovered_228_o, recovered_228_s, recovered_228_di;
  assign recovered_228_s = esc_add_ln208_39_reg_8728_reg_15_81ea661 [11:8];
  assign recovered_228_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_228_ci = ((esc_add_ln208_39_reg_8728_reg_7__i_2_n_0_73a6098) !== 1'bz) && (esc_add_ln208_39_reg_8728_reg_7__i_2_n_0_73a6098);
  wire recovered_228_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_228_o[0] = recovered_228_s[0] ^ (recovered_228_ci || recovered_228_cy);
  assign recovered_228_co[0] = (recovered_228_s[0] & (recovered_228_ci || recovered_228_cy)) | (~recovered_228_s[0] & recovered_228_di[0]);
  assign recovered_228_o[1] = recovered_228_s[1] ^ recovered_228_co[0];
  assign recovered_228_co[1] = (recovered_228_s[1] & recovered_228_co[0]) | (~recovered_228_s[1] & recovered_228_di[1]);
  assign recovered_228_o[2] = recovered_228_s[2] ^ recovered_228_co[1];
  assign recovered_228_co[2] = (recovered_228_s[2] & recovered_228_co[1]) | (~recovered_228_s[2] & recovered_228_di[2]);
  assign recovered_228_o[3] = recovered_228_s[3] ^ recovered_228_co[2];
  assign recovered_228_co[3] = (recovered_228_s[3] & recovered_228_co[2]) | (~recovered_228_s[3] & recovered_228_di[3]);
  assign {esc_add_ln208_39_reg_8728_reg_11__i_2_n_0_641e002 ,esc_NLW_add_ln208_39_reg_8728_reg_11__i_2_CO_UNCONNECTED_5c5c086 [2:0]} = recovered_228_co;
  assign zext_ln208_86_fu_5765_p1[11:8] = recovered_228_o;

  // Reconstructed CARRY4: esc_add_ln208_39_reg_8728_reg_15__i_2_a11a60f
  wire [3:0] recovered_229_co, recovered_229_o, recovered_229_s, recovered_229_di;
  assign recovered_229_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_39_reg_8728_reg_15_81ea661 [13:12]};
  assign recovered_229_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_229_ci = ((esc_add_ln208_39_reg_8728_reg_11__i_2_n_0_641e002) !== 1'bz) && (esc_add_ln208_39_reg_8728_reg_11__i_2_n_0_641e002);
  wire recovered_229_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_229_o[0] = recovered_229_s[0] ^ (recovered_229_ci || recovered_229_cy);
  assign recovered_229_co[0] = (recovered_229_s[0] & (recovered_229_ci || recovered_229_cy)) | (~recovered_229_s[0] & recovered_229_di[0]);
  assign recovered_229_o[1] = recovered_229_s[1] ^ recovered_229_co[0];
  assign recovered_229_co[1] = (recovered_229_s[1] & recovered_229_co[0]) | (~recovered_229_s[1] & recovered_229_di[1]);
  assign recovered_229_o[2] = recovered_229_s[2] ^ recovered_229_co[1];
  assign recovered_229_co[2] = (recovered_229_s[2] & recovered_229_co[1]) | (~recovered_229_s[2] & recovered_229_di[2]);
  assign recovered_229_o[3] = recovered_229_s[3] ^ recovered_229_co[2];
  assign recovered_229_co[3] = (recovered_229_s[3] & recovered_229_co[2]) | (~recovered_229_s[3] & recovered_229_di[3]);
  assign zext_ln208_86_fu_5765_p1[13:12] = recovered_229_o;

  // Reconstructed CARRY4: esc_add_ln208_39_reg_8728_reg_3__i_2_90252c8
  wire [3:0] recovered_230_co, recovered_230_o, recovered_230_s, recovered_230_di;
  assign recovered_230_s = {esc_add_ln208_39_reg_8728_3__i_7_n_0_22aaad8 ,esc_add_ln208_39_reg_8728_3__i_8_n_0_f24e38d ,esc_add_ln208_39_reg_8728_3__i_9_n_0_28e464e ,esc_add_ln208_39_reg_8728_3__i_10_n_0_403481d };
  assign recovered_230_di = esc_add_ln208_39_reg_8728_reg_15_81ea661 [3:0];
  wire recovered_230_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_230_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_230_o[0] = recovered_230_s[0] ^ (recovered_230_ci || recovered_230_cy);
  assign recovered_230_co[0] = (recovered_230_s[0] & (recovered_230_ci || recovered_230_cy)) | (~recovered_230_s[0] & recovered_230_di[0]);
  assign recovered_230_o[1] = recovered_230_s[1] ^ recovered_230_co[0];
  assign recovered_230_co[1] = (recovered_230_s[1] & recovered_230_co[0]) | (~recovered_230_s[1] & recovered_230_di[1]);
  assign recovered_230_o[2] = recovered_230_s[2] ^ recovered_230_co[1];
  assign recovered_230_co[2] = (recovered_230_s[2] & recovered_230_co[1]) | (~recovered_230_s[2] & recovered_230_di[2]);
  assign recovered_230_o[3] = recovered_230_s[3] ^ recovered_230_co[2];
  assign recovered_230_co[3] = (recovered_230_s[3] & recovered_230_co[2]) | (~recovered_230_s[3] & recovered_230_di[3]);
  assign {esc_add_ln208_39_reg_8728_reg_3__i_2_n_0_b82e945 ,esc_NLW_add_ln208_39_reg_8728_reg_3__i_2_CO_UNCONNECTED_9e15017 [2:0]} = recovered_230_co;
  assign zext_ln208_86_fu_5765_p1[3:0] = recovered_230_o;

  // Reconstructed CARRY4: esc_add_ln208_39_reg_8728_reg_7__i_2_9b0736b
  wire [3:0] recovered_231_co, recovered_231_o, recovered_231_s, recovered_231_di;
  assign recovered_231_s = {esc_add_ln208_39_reg_8728_7__i_7_n_0_fbf9927 ,esc_add_ln208_39_reg_8728_7__i_8_n_0_a64a1e7 ,esc_add_ln208_39_reg_8728_7__i_9_n_0_40eeeff ,esc_add_ln208_39_reg_8728_7__i_10_n_0_367f83d };
  assign recovered_231_di = esc_add_ln208_39_reg_8728_reg_15_81ea661 [7:4];
  wire recovered_231_ci = ((esc_add_ln208_39_reg_8728_reg_3__i_2_n_0_b82e945) !== 1'bz) && (esc_add_ln208_39_reg_8728_reg_3__i_2_n_0_b82e945);
  wire recovered_231_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_231_o[0] = recovered_231_s[0] ^ (recovered_231_ci || recovered_231_cy);
  assign recovered_231_co[0] = (recovered_231_s[0] & (recovered_231_ci || recovered_231_cy)) | (~recovered_231_s[0] & recovered_231_di[0]);
  assign recovered_231_o[1] = recovered_231_s[1] ^ recovered_231_co[0];
  assign recovered_231_co[1] = (recovered_231_s[1] & recovered_231_co[0]) | (~recovered_231_s[1] & recovered_231_di[1]);
  assign recovered_231_o[2] = recovered_231_s[2] ^ recovered_231_co[1];
  assign recovered_231_co[2] = (recovered_231_s[2] & recovered_231_co[1]) | (~recovered_231_s[2] & recovered_231_di[2]);
  assign recovered_231_o[3] = recovered_231_s[3] ^ recovered_231_co[2];
  assign recovered_231_co[3] = (recovered_231_s[3] & recovered_231_co[2]) | (~recovered_231_s[3] & recovered_231_di[3]);
  assign {esc_add_ln208_39_reg_8728_reg_7__i_2_n_0_73a6098 ,esc_NLW_add_ln208_39_reg_8728_reg_7__i_2_CO_UNCONNECTED_861159c [2:0]} = recovered_231_co;
  assign zext_ln208_86_fu_5765_p1[7:4] = recovered_231_o;

  // Reconstructed LUT2: esc_add_ln208_40_reg_7067_3__i_2_9c71232
  assign esc_add_ln208_40_reg_7067_3__i_2_n_0_96eb7c8 = ((ram0_reg_7[3]) ? (~(DOADO[3])) : (DOADO[3]));

  // Reconstructed LUT2: esc_add_ln208_40_reg_7067_3__i_3_0098ce9
  assign esc_add_ln208_40_reg_7067_3__i_3_n_0_67f7c93 = ((ram0_reg_7[2]) ? (~(DOADO[2])) : (DOADO[2]));

  // Reconstructed LUT2: esc_add_ln208_40_reg_7067_3__i_4_9116a50
  assign esc_add_ln208_40_reg_7067_3__i_4_n_0_9845a8c = ((ram0_reg_7[1]) ? (~(DOADO[1])) : (DOADO[1]));

  // Reconstructed LUT2: esc_add_ln208_40_reg_7067_3__i_5_7704d7c
  assign esc_add_ln208_40_reg_7067_3__i_5_n_0_164633f = ((ram0_reg_7[0]) ? (~(DOADO[0])) : (DOADO[0]));

  // Reconstructed LUT2: esc_add_ln208_40_reg_7067_7__i_2_9b337ae
  assign esc_add_ln208_40_reg_7067_7__i_2_n_0_50584df = ((ram0_reg_7[7]) ? (~(DOADO[7])) : (DOADO[7]));

  // Reconstructed LUT2: esc_add_ln208_40_reg_7067_7__i_3_834e0f3
  assign esc_add_ln208_40_reg_7067_7__i_3_n_0_7d42b03 = ((ram0_reg_7[6]) ? (~(DOADO[6])) : (DOADO[6]));

  // Reconstructed LUT2: esc_add_ln208_40_reg_7067_7__i_4_b8e9990
  assign esc_add_ln208_40_reg_7067_7__i_4_n_0_baec1f8 = ((ram0_reg_7[5]) ? (~(DOADO[5])) : (DOADO[5]));

  // Reconstructed LUT2: esc_add_ln208_40_reg_7067_7__i_5_c79b934
  assign esc_add_ln208_40_reg_7067_7__i_5_n_0_33aaf1b = ((ram0_reg_7[4]) ? (~(DOADO[4])) : (DOADO[4]));

  // Reconstructed CARRY4: esc_add_ln208_40_reg_7067_reg_3__i_1_a10c9c0
  wire [3:0] recovered_240_co, recovered_240_o, recovered_240_s, recovered_240_di;
  assign recovered_240_s = {esc_add_ln208_40_reg_7067_3__i_2_n_0_96eb7c8 ,esc_add_ln208_40_reg_7067_3__i_3_n_0_67f7c93 ,esc_add_ln208_40_reg_7067_3__i_4_n_0_9845a8c ,esc_add_ln208_40_reg_7067_3__i_5_n_0_164633f };
  assign recovered_240_di = DOADO[3:0];
  wire recovered_240_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_240_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_240_o[0] = recovered_240_s[0] ^ (recovered_240_ci || recovered_240_cy);
  assign recovered_240_co[0] = (recovered_240_s[0] & (recovered_240_ci || recovered_240_cy)) | (~recovered_240_s[0] & recovered_240_di[0]);
  assign recovered_240_o[1] = recovered_240_s[1] ^ recovered_240_co[0];
  assign recovered_240_co[1] = (recovered_240_s[1] & recovered_240_co[0]) | (~recovered_240_s[1] & recovered_240_di[1]);
  assign recovered_240_o[2] = recovered_240_s[2] ^ recovered_240_co[1];
  assign recovered_240_co[2] = (recovered_240_s[2] & recovered_240_co[1]) | (~recovered_240_s[2] & recovered_240_di[2]);
  assign recovered_240_o[3] = recovered_240_s[3] ^ recovered_240_co[2];
  assign recovered_240_co[3] = (recovered_240_s[3] & recovered_240_co[2]) | (~recovered_240_s[3] & recovered_240_di[3]);
  assign {esc_add_ln208_40_reg_7067_reg_3__i_1_n_0_8263a45 ,esc_NLW_add_ln208_40_reg_7067_reg_3__i_1_CO_UNCONNECTED_64d71c2 [2:0]} = recovered_240_co;
  assign D[3:0] = recovered_240_o;

  // Reconstructed CARRY4: esc_add_ln208_40_reg_7067_reg_7__i_1_6687856
  wire [3:0] recovered_241_co, recovered_241_o, recovered_241_s, recovered_241_di;
  assign recovered_241_s = {esc_add_ln208_40_reg_7067_7__i_2_n_0_50584df ,esc_add_ln208_40_reg_7067_7__i_3_n_0_7d42b03 ,esc_add_ln208_40_reg_7067_7__i_4_n_0_baec1f8 ,esc_add_ln208_40_reg_7067_7__i_5_n_0_33aaf1b };
  assign recovered_241_di = DOADO[7:4];
  wire recovered_241_ci = ((esc_add_ln208_40_reg_7067_reg_3__i_1_n_0_8263a45) !== 1'bz) && (esc_add_ln208_40_reg_7067_reg_3__i_1_n_0_8263a45);
  wire recovered_241_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_241_o[0] = recovered_241_s[0] ^ (recovered_241_ci || recovered_241_cy);
  assign recovered_241_co[0] = (recovered_241_s[0] & (recovered_241_ci || recovered_241_cy)) | (~recovered_241_s[0] & recovered_241_di[0]);
  assign recovered_241_o[1] = recovered_241_s[1] ^ recovered_241_co[0];
  assign recovered_241_co[1] = (recovered_241_s[1] & recovered_241_co[0]) | (~recovered_241_s[1] & recovered_241_di[1]);
  assign recovered_241_o[2] = recovered_241_s[2] ^ recovered_241_co[1];
  assign recovered_241_co[2] = (recovered_241_s[2] & recovered_241_co[1]) | (~recovered_241_s[2] & recovered_241_di[2]);
  assign recovered_241_o[3] = recovered_241_s[3] ^ recovered_241_co[2];
  assign recovered_241_co[3] = (recovered_241_s[3] & recovered_241_co[2]) | (~recovered_241_s[3] & recovered_241_di[3]);
  assign {esc_add_ln208_40_reg_7067_reg_7__i_1_n_0_d513a20 ,esc_NLW_add_ln208_40_reg_7067_reg_7__i_1_CO_UNCONNECTED_246c155 [2:0]} = recovered_241_co;
  assign D[7:4] = recovered_241_o;

  // Reconstructed CARRY4: esc_add_ln208_40_reg_7067_reg_8__i_2_cbd7eda
  wire [3:0] recovered_242_co, recovered_242_o, recovered_242_s, recovered_242_di;
  assign recovered_242_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 };
  assign recovered_242_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_242_ci = ((esc_add_ln208_40_reg_7067_reg_7__i_1_n_0_d513a20) !== 1'bz) && (esc_add_ln208_40_reg_7067_reg_7__i_1_n_0_d513a20);
  wire recovered_242_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_242_o[0] = recovered_242_s[0] ^ (recovered_242_ci || recovered_242_cy);
  assign recovered_242_co[0] = (recovered_242_s[0] & (recovered_242_ci || recovered_242_cy)) | (~recovered_242_s[0] & recovered_242_di[0]);
  assign recovered_242_o[1] = recovered_242_s[1] ^ recovered_242_co[0];
  assign recovered_242_co[1] = (recovered_242_s[1] & recovered_242_co[0]) | (~recovered_242_s[1] & recovered_242_di[1]);
  assign recovered_242_o[2] = recovered_242_s[2] ^ recovered_242_co[1];
  assign recovered_242_co[2] = (recovered_242_s[2] & recovered_242_co[1]) | (~recovered_242_s[2] & recovered_242_di[2]);
  assign recovered_242_o[3] = recovered_242_s[3] ^ recovered_242_co[2];
  assign recovered_242_co[3] = (recovered_242_s[3] & recovered_242_co[2]) | (~recovered_242_s[3] & recovered_242_di[3]);
  assign D[8] = recovered_242_co;

  // Reconstructed LUT2: esc_add_ln208_44_reg_7119_3__i_2_024b4de
  assign esc_add_ln208_44_reg_7119_3__i_2_n_0_2a0983a = ((DOADO[3]) ? (~(Q[3])) : (Q[3]));

  // Reconstructed LUT2: esc_add_ln208_44_reg_7119_3__i_3_8f00481
  assign esc_add_ln208_44_reg_7119_3__i_3_n_0_ad92b5b = ((DOADO[2]) ? (~(Q[2])) : (Q[2]));

  // Reconstructed LUT2: esc_add_ln208_44_reg_7119_3__i_4_1590d01
  assign esc_add_ln208_44_reg_7119_3__i_4_n_0_2afc826 = ((DOADO[1]) ? (~(Q[1])) : (Q[1]));

  // Reconstructed LUT2: esc_add_ln208_44_reg_7119_3__i_5_5e7820a
  assign esc_add_ln208_44_reg_7119_3__i_5_n_0_c3553e3 = ((DOADO[0]) ? (~(Q[0])) : (Q[0]));

  // Reconstructed LUT2: esc_add_ln208_44_reg_7119_7__i_2_2c95763
  assign esc_add_ln208_44_reg_7119_7__i_2_n_0_7645409 = ((DOADO[7]) ? (~(Q[7])) : (Q[7]));

  // Reconstructed LUT2: esc_add_ln208_44_reg_7119_7__i_3_82ac467
  assign esc_add_ln208_44_reg_7119_7__i_3_n_0_1cc3fa6 = ((DOADO[6]) ? (~(Q[6])) : (Q[6]));

  // Reconstructed LUT2: esc_add_ln208_44_reg_7119_7__i_4_4a7c724
  assign esc_add_ln208_44_reg_7119_7__i_4_n_0_b306a08 = ((DOADO[5]) ? (~(Q[5])) : (Q[5]));

  // Reconstructed LUT2: esc_add_ln208_44_reg_7119_7__i_5_c22f76e
  assign esc_add_ln208_44_reg_7119_7__i_5_n_0_487d070 = ((DOADO[4]) ? (~(Q[4])) : (Q[4]));

  // Reconstructed CARRY4: esc_add_ln208_44_reg_7119_reg_3__i_1_5558ce0
  wire [3:0] recovered_251_co, recovered_251_o, recovered_251_s, recovered_251_di;
  assign recovered_251_s = {esc_add_ln208_44_reg_7119_3__i_2_n_0_2a0983a ,esc_add_ln208_44_reg_7119_3__i_3_n_0_ad92b5b ,esc_add_ln208_44_reg_7119_3__i_4_n_0_2afc826 ,esc_add_ln208_44_reg_7119_3__i_5_n_0_c3553e3 };
  assign recovered_251_di = Q[3:0];
  wire recovered_251_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_251_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_251_o[0] = recovered_251_s[0] ^ (recovered_251_ci || recovered_251_cy);
  assign recovered_251_co[0] = (recovered_251_s[0] & (recovered_251_ci || recovered_251_cy)) | (~recovered_251_s[0] & recovered_251_di[0]);
  assign recovered_251_o[1] = recovered_251_s[1] ^ recovered_251_co[0];
  assign recovered_251_co[1] = (recovered_251_s[1] & recovered_251_co[0]) | (~recovered_251_s[1] & recovered_251_di[1]);
  assign recovered_251_o[2] = recovered_251_s[2] ^ recovered_251_co[1];
  assign recovered_251_co[2] = (recovered_251_s[2] & recovered_251_co[1]) | (~recovered_251_s[2] & recovered_251_di[2]);
  assign recovered_251_o[3] = recovered_251_s[3] ^ recovered_251_co[2];
  assign recovered_251_co[3] = (recovered_251_s[3] & recovered_251_co[2]) | (~recovered_251_s[3] & recovered_251_di[3]);
  assign {esc_add_ln208_44_reg_7119_reg_3__i_1_n_0_1f37292 ,esc_NLW_add_ln208_44_reg_7119_reg_3__i_1_CO_UNCONNECTED_99df3c0 [2:0]} = recovered_251_co;
  assign esc_add_ln208_40_reg_7067_reg_8_4748565 [3:0] = recovered_251_o;

  // Reconstructed CARRY4: esc_add_ln208_44_reg_7119_reg_7__i_1_6e7e53a
  wire [3:0] recovered_252_co, recovered_252_o, recovered_252_s, recovered_252_di;
  assign recovered_252_s = {esc_add_ln208_44_reg_7119_7__i_2_n_0_7645409 ,esc_add_ln208_44_reg_7119_7__i_3_n_0_1cc3fa6 ,esc_add_ln208_44_reg_7119_7__i_4_n_0_b306a08 ,esc_add_ln208_44_reg_7119_7__i_5_n_0_487d070 };
  assign recovered_252_di = Q[7:4];
  wire recovered_252_ci = ((esc_add_ln208_44_reg_7119_reg_3__i_1_n_0_1f37292) !== 1'bz) && (esc_add_ln208_44_reg_7119_reg_3__i_1_n_0_1f37292);
  wire recovered_252_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_252_o[0] = recovered_252_s[0] ^ (recovered_252_ci || recovered_252_cy);
  assign recovered_252_co[0] = (recovered_252_s[0] & (recovered_252_ci || recovered_252_cy)) | (~recovered_252_s[0] & recovered_252_di[0]);
  assign recovered_252_o[1] = recovered_252_s[1] ^ recovered_252_co[0];
  assign recovered_252_co[1] = (recovered_252_s[1] & recovered_252_co[0]) | (~recovered_252_s[1] & recovered_252_di[1]);
  assign recovered_252_o[2] = recovered_252_s[2] ^ recovered_252_co[1];
  assign recovered_252_co[2] = (recovered_252_s[2] & recovered_252_co[1]) | (~recovered_252_s[2] & recovered_252_di[2]);
  assign recovered_252_o[3] = recovered_252_s[3] ^ recovered_252_co[2];
  assign recovered_252_co[3] = (recovered_252_s[3] & recovered_252_co[2]) | (~recovered_252_s[3] & recovered_252_di[3]);
  assign {esc_add_ln208_44_reg_7119_reg_7__i_1_n_0_9812eda ,esc_NLW_add_ln208_44_reg_7119_reg_7__i_1_CO_UNCONNECTED_4383b86 [2:0]} = recovered_252_co;
  assign esc_add_ln208_40_reg_7067_reg_8_4748565 [7:4] = recovered_252_o;

  // Reconstructed CARRY4: esc_add_ln208_44_reg_7119_reg_9__i_2_1c13958
  wire [3:0] recovered_253_co, recovered_253_o, recovered_253_s, recovered_253_di;
  assign recovered_253_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 ,Q[8]};
  assign recovered_253_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_253_ci = ((esc_add_ln208_44_reg_7119_reg_7__i_1_n_0_9812eda) !== 1'bz) && (esc_add_ln208_44_reg_7119_reg_7__i_1_n_0_9812eda);
  wire recovered_253_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_253_o[0] = recovered_253_s[0] ^ (recovered_253_ci || recovered_253_cy);
  assign recovered_253_co[0] = (recovered_253_s[0] & (recovered_253_ci || recovered_253_cy)) | (~recovered_253_s[0] & recovered_253_di[0]);
  assign recovered_253_o[1] = recovered_253_s[1] ^ recovered_253_co[0];
  assign recovered_253_co[1] = (recovered_253_s[1] & recovered_253_co[0]) | (~recovered_253_s[1] & recovered_253_di[1]);
  assign recovered_253_o[2] = recovered_253_s[2] ^ recovered_253_co[1];
  assign recovered_253_co[2] = (recovered_253_s[2] & recovered_253_co[1]) | (~recovered_253_s[2] & recovered_253_di[2]);
  assign recovered_253_o[3] = recovered_253_s[3] ^ recovered_253_co[2];
  assign recovered_253_co[3] = (recovered_253_s[3] & recovered_253_co[2]) | (~recovered_253_s[3] & recovered_253_di[3]);
  assign {esc_add_ln208_40_reg_7067_reg_8_4748565 [9],esc_NLW_add_ln208_44_reg_7119_reg_9__i_2_CO_UNCONNECTED_a4935c4 [0]} = recovered_253_co;
  assign esc_add_ln208_40_reg_7067_reg_8_4748565 [8] = recovered_253_o;

  // Reconstructed LUT2: esc_add_ln208_47_reg_7171_3__i_2_ebb309c
  assign esc_add_ln208_47_reg_7171_3__i_2_n_0_e6e4799 = ((DOADO[3]) ? (~(esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [3])) : (esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [3]));

  // Reconstructed LUT2: esc_add_ln208_47_reg_7171_3__i_3_005223f
  assign esc_add_ln208_47_reg_7171_3__i_3_n_0_5feda06 = ((DOADO[2]) ? (~(esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [2])) : (esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [2]));

  // Reconstructed LUT2: esc_add_ln208_47_reg_7171_3__i_4_63bbaa2
  assign esc_add_ln208_47_reg_7171_3__i_4_n_0_b1f0a76 = ((DOADO[1]) ? (~(esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [1])) : (esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [1]));

  // Reconstructed LUT2: esc_add_ln208_47_reg_7171_3__i_5_2e046ab
  assign esc_add_ln208_47_reg_7171_3__i_5_n_0_47fb3cc = ((DOADO[0]) ? (~(esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [0])) : (esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [0]));

  // Reconstructed LUT2: esc_add_ln208_47_reg_7171_7__i_2_8ec9692
  assign esc_add_ln208_47_reg_7171_7__i_2_n_0_73c23cd = ((DOADO[7]) ? (~(esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [7])) : (esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [7]));

  // Reconstructed LUT2: esc_add_ln208_47_reg_7171_7__i_3_dd63cc0
  assign esc_add_ln208_47_reg_7171_7__i_3_n_0_8bdef78 = ((DOADO[6]) ? (~(esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [6])) : (esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [6]));

  // Reconstructed LUT2: esc_add_ln208_47_reg_7171_7__i_4_a40687c
  assign esc_add_ln208_47_reg_7171_7__i_4_n_0_eec460c = ((DOADO[5]) ? (~(esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [5])) : (esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [5]));

  // Reconstructed LUT2: esc_add_ln208_47_reg_7171_7__i_5_e456b5b
  assign esc_add_ln208_47_reg_7171_7__i_5_n_0_4bec516 = ((DOADO[4]) ? (~(esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [4])) : (esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [4]));

  // Reconstructed CARRY4: esc_add_ln208_47_reg_7171_reg_3__i_1_36acf73
  wire [3:0] recovered_262_co, recovered_262_o, recovered_262_s, recovered_262_di;
  assign recovered_262_s = {esc_add_ln208_47_reg_7171_3__i_2_n_0_e6e4799 ,esc_add_ln208_47_reg_7171_3__i_3_n_0_5feda06 ,esc_add_ln208_47_reg_7171_3__i_4_n_0_b1f0a76 ,esc_add_ln208_47_reg_7171_3__i_5_n_0_47fb3cc };
  assign recovered_262_di = esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [3:0];
  wire recovered_262_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_262_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_262_o[0] = recovered_262_s[0] ^ (recovered_262_ci || recovered_262_cy);
  assign recovered_262_co[0] = (recovered_262_s[0] & (recovered_262_ci || recovered_262_cy)) | (~recovered_262_s[0] & recovered_262_di[0]);
  assign recovered_262_o[1] = recovered_262_s[1] ^ recovered_262_co[0];
  assign recovered_262_co[1] = (recovered_262_s[1] & recovered_262_co[0]) | (~recovered_262_s[1] & recovered_262_di[1]);
  assign recovered_262_o[2] = recovered_262_s[2] ^ recovered_262_co[1];
  assign recovered_262_co[2] = (recovered_262_s[2] & recovered_262_co[1]) | (~recovered_262_s[2] & recovered_262_di[2]);
  assign recovered_262_o[3] = recovered_262_s[3] ^ recovered_262_co[2];
  assign recovered_262_co[3] = (recovered_262_s[3] & recovered_262_co[2]) | (~recovered_262_s[3] & recovered_262_di[3]);
  assign {esc_add_ln208_47_reg_7171_reg_3__i_1_n_0_29ca070 ,esc_NLW_add_ln208_47_reg_7171_reg_3__i_1_CO_UNCONNECTED_58087cc [2:0]} = recovered_262_co;
  assign esc_add_ln208_44_reg_7119_reg_9_9449ba5 [3:0] = recovered_262_o;

  // Reconstructed CARRY4: esc_add_ln208_47_reg_7171_reg_7__i_1_8aee475
  wire [3:0] recovered_263_co, recovered_263_o, recovered_263_s, recovered_263_di;
  assign recovered_263_s = {esc_add_ln208_47_reg_7171_7__i_2_n_0_73c23cd ,esc_add_ln208_47_reg_7171_7__i_3_n_0_8bdef78 ,esc_add_ln208_47_reg_7171_7__i_4_n_0_eec460c ,esc_add_ln208_47_reg_7171_7__i_5_n_0_4bec516 };
  assign recovered_263_di = esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [7:4];
  wire recovered_263_ci = ((esc_add_ln208_47_reg_7171_reg_3__i_1_n_0_29ca070) !== 1'bz) && (esc_add_ln208_47_reg_7171_reg_3__i_1_n_0_29ca070);
  wire recovered_263_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_263_o[0] = recovered_263_s[0] ^ (recovered_263_ci || recovered_263_cy);
  assign recovered_263_co[0] = (recovered_263_s[0] & (recovered_263_ci || recovered_263_cy)) | (~recovered_263_s[0] & recovered_263_di[0]);
  assign recovered_263_o[1] = recovered_263_s[1] ^ recovered_263_co[0];
  assign recovered_263_co[1] = (recovered_263_s[1] & recovered_263_co[0]) | (~recovered_263_s[1] & recovered_263_di[1]);
  assign recovered_263_o[2] = recovered_263_s[2] ^ recovered_263_co[1];
  assign recovered_263_co[2] = (recovered_263_s[2] & recovered_263_co[1]) | (~recovered_263_s[2] & recovered_263_di[2]);
  assign recovered_263_o[3] = recovered_263_s[3] ^ recovered_263_co[2];
  assign recovered_263_co[3] = (recovered_263_s[3] & recovered_263_co[2]) | (~recovered_263_s[3] & recovered_263_di[3]);
  assign {esc_add_ln208_47_reg_7171_reg_7__i_1_n_0_3677d32 ,esc_NLW_add_ln208_47_reg_7171_reg_7__i_1_CO_UNCONNECTED_0c681f4 [2:0]} = recovered_263_co;
  assign esc_add_ln208_44_reg_7119_reg_9_9449ba5 [7:4] = recovered_263_o;

  // Reconstructed CARRY4: esc_add_ln208_47_reg_7171_reg_9__i_2_f4e122f
  wire [3:0] recovered_264_co, recovered_264_o, recovered_264_s, recovered_264_di;
  assign recovered_264_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_47_reg_7171_reg_9__0_3783b12 [9:8]};
  assign recovered_264_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_264_ci = ((esc_add_ln208_47_reg_7171_reg_7__i_1_n_0_3677d32) !== 1'bz) && (esc_add_ln208_47_reg_7171_reg_7__i_1_n_0_3677d32);
  wire recovered_264_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_264_o[0] = recovered_264_s[0] ^ (recovered_264_ci || recovered_264_cy);
  assign recovered_264_co[0] = (recovered_264_s[0] & (recovered_264_ci || recovered_264_cy)) | (~recovered_264_s[0] & recovered_264_di[0]);
  assign recovered_264_o[1] = recovered_264_s[1] ^ recovered_264_co[0];
  assign recovered_264_co[1] = (recovered_264_s[1] & recovered_264_co[0]) | (~recovered_264_s[1] & recovered_264_di[1]);
  assign recovered_264_o[2] = recovered_264_s[2] ^ recovered_264_co[1];
  assign recovered_264_co[2] = (recovered_264_s[2] & recovered_264_co[1]) | (~recovered_264_s[2] & recovered_264_di[2]);
  assign recovered_264_o[3] = recovered_264_s[3] ^ recovered_264_co[2];
  assign recovered_264_co[3] = (recovered_264_s[3] & recovered_264_co[2]) | (~recovered_264_s[3] & recovered_264_di[3]);
  assign esc_add_ln208_44_reg_7119_reg_9_9449ba5 [9:8] = recovered_264_o;

  // Reconstructed LUT2: esc_add_ln208_50_reg_7223_3__i_2_944b955
  assign esc_add_ln208_50_reg_7223_3__i_2_n_0_d63092b = ((DOADO[3]) ? (~(esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [3])) : (esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [3]));

  // Reconstructed LUT2: esc_add_ln208_50_reg_7223_3__i_3_0c6d676
  assign esc_add_ln208_50_reg_7223_3__i_3_n_0_90f9e62 = ((DOADO[2]) ? (~(esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [2])) : (esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [2]));

  // Reconstructed LUT2: esc_add_ln208_50_reg_7223_3__i_4_9b9ae0a
  assign esc_add_ln208_50_reg_7223_3__i_4_n_0_7547f33 = ((DOADO[1]) ? (~(esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [1])) : (esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [1]));

  // Reconstructed LUT2: esc_add_ln208_50_reg_7223_3__i_5_e6820a3
  assign esc_add_ln208_50_reg_7223_3__i_5_n_0_5006374 = ((DOADO[0]) ? (~(esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [0])) : (esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [0]));

  // Reconstructed LUT2: esc_add_ln208_50_reg_7223_7__i_2_40c1394
  assign esc_add_ln208_50_reg_7223_7__i_2_n_0_5c19c3a = ((DOADO[7]) ? (~(esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [7])) : (esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [7]));

  // Reconstructed LUT2: esc_add_ln208_50_reg_7223_7__i_3_c21e33d
  assign esc_add_ln208_50_reg_7223_7__i_3_n_0_42b26d2 = ((DOADO[6]) ? (~(esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [6])) : (esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [6]));

  // Reconstructed LUT2: esc_add_ln208_50_reg_7223_7__i_4_b8bd91a
  assign esc_add_ln208_50_reg_7223_7__i_4_n_0_699b1cb = ((DOADO[5]) ? (~(esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [5])) : (esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [5]));

  // Reconstructed LUT2: esc_add_ln208_50_reg_7223_7__i_5_7822196
  assign esc_add_ln208_50_reg_7223_7__i_5_n_0_efd6698 = ((DOADO[4]) ? (~(esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [4])) : (esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [4]));

  // Reconstructed CARRY4: esc_add_ln208_50_reg_7223_reg_10__i_2_072558f
  wire [3:0] recovered_273_co, recovered_273_o, recovered_273_s, recovered_273_di;
  assign recovered_273_s = {esc_const0_a0cf646 ,esc_const1_c064970 ,esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [9:8]};
  assign recovered_273_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_273_ci = ((esc_add_ln208_50_reg_7223_reg_7__i_1_n_0_700420e) !== 1'bz) && (esc_add_ln208_50_reg_7223_reg_7__i_1_n_0_700420e);
  wire recovered_273_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_273_o[0] = recovered_273_s[0] ^ (recovered_273_ci || recovered_273_cy);
  assign recovered_273_co[0] = (recovered_273_s[0] & (recovered_273_ci || recovered_273_cy)) | (~recovered_273_s[0] & recovered_273_di[0]);
  assign recovered_273_o[1] = recovered_273_s[1] ^ recovered_273_co[0];
  assign recovered_273_co[1] = (recovered_273_s[1] & recovered_273_co[0]) | (~recovered_273_s[1] & recovered_273_di[1]);
  assign recovered_273_o[2] = recovered_273_s[2] ^ recovered_273_co[1];
  assign recovered_273_co[2] = (recovered_273_s[2] & recovered_273_co[1]) | (~recovered_273_s[2] & recovered_273_di[2]);
  assign recovered_273_o[3] = recovered_273_s[3] ^ recovered_273_co[2];
  assign recovered_273_co[3] = (recovered_273_s[3] & recovered_273_co[2]) | (~recovered_273_s[3] & recovered_273_di[3]);
  assign {esc_add_ln208_47_reg_7171_reg_9_5141771 [10],esc_NLW_add_ln208_50_reg_7223_reg_10__i_2_CO_UNCONNECTED_0b7b42a [1:0]} = recovered_273_co;
  assign esc_add_ln208_47_reg_7171_reg_9_5141771 [9:8] = recovered_273_o;

  // Reconstructed CARRY4: esc_add_ln208_50_reg_7223_reg_3__i_1_5f4eebf
  wire [3:0] recovered_274_co, recovered_274_o, recovered_274_s, recovered_274_di;
  assign recovered_274_s = {esc_add_ln208_50_reg_7223_3__i_2_n_0_d63092b ,esc_add_ln208_50_reg_7223_3__i_3_n_0_90f9e62 ,esc_add_ln208_50_reg_7223_3__i_4_n_0_7547f33 ,esc_add_ln208_50_reg_7223_3__i_5_n_0_5006374 };
  assign recovered_274_di = esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [3:0];
  wire recovered_274_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_274_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_274_o[0] = recovered_274_s[0] ^ (recovered_274_ci || recovered_274_cy);
  assign recovered_274_co[0] = (recovered_274_s[0] & (recovered_274_ci || recovered_274_cy)) | (~recovered_274_s[0] & recovered_274_di[0]);
  assign recovered_274_o[1] = recovered_274_s[1] ^ recovered_274_co[0];
  assign recovered_274_co[1] = (recovered_274_s[1] & recovered_274_co[0]) | (~recovered_274_s[1] & recovered_274_di[1]);
  assign recovered_274_o[2] = recovered_274_s[2] ^ recovered_274_co[1];
  assign recovered_274_co[2] = (recovered_274_s[2] & recovered_274_co[1]) | (~recovered_274_s[2] & recovered_274_di[2]);
  assign recovered_274_o[3] = recovered_274_s[3] ^ recovered_274_co[2];
  assign recovered_274_co[3] = (recovered_274_s[3] & recovered_274_co[2]) | (~recovered_274_s[3] & recovered_274_di[3]);
  assign {esc_add_ln208_50_reg_7223_reg_3__i_1_n_0_3f5aea7 ,esc_NLW_add_ln208_50_reg_7223_reg_3__i_1_CO_UNCONNECTED_0841f61 [2:0]} = recovered_274_co;
  assign esc_add_ln208_47_reg_7171_reg_9_5141771 [3:0] = recovered_274_o;

  // Reconstructed CARRY4: esc_add_ln208_50_reg_7223_reg_7__i_1_0bd44a6
  wire [3:0] recovered_275_co, recovered_275_o, recovered_275_s, recovered_275_di;
  assign recovered_275_s = {esc_add_ln208_50_reg_7223_7__i_2_n_0_5c19c3a ,esc_add_ln208_50_reg_7223_7__i_3_n_0_42b26d2 ,esc_add_ln208_50_reg_7223_7__i_4_n_0_699b1cb ,esc_add_ln208_50_reg_7223_7__i_5_n_0_efd6698 };
  assign recovered_275_di = esc_add_ln208_50_reg_7223_reg_10__0_0ff3bf0 [7:4];
  wire recovered_275_ci = ((esc_add_ln208_50_reg_7223_reg_3__i_1_n_0_3f5aea7) !== 1'bz) && (esc_add_ln208_50_reg_7223_reg_3__i_1_n_0_3f5aea7);
  wire recovered_275_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_275_o[0] = recovered_275_s[0] ^ (recovered_275_ci || recovered_275_cy);
  assign recovered_275_co[0] = (recovered_275_s[0] & (recovered_275_ci || recovered_275_cy)) | (~recovered_275_s[0] & recovered_275_di[0]);
  assign recovered_275_o[1] = recovered_275_s[1] ^ recovered_275_co[0];
  assign recovered_275_co[1] = (recovered_275_s[1] & recovered_275_co[0]) | (~recovered_275_s[1] & recovered_275_di[1]);
  assign recovered_275_o[2] = recovered_275_s[2] ^ recovered_275_co[1];
  assign recovered_275_co[2] = (recovered_275_s[2] & recovered_275_co[1]) | (~recovered_275_s[2] & recovered_275_di[2]);
  assign recovered_275_o[3] = recovered_275_s[3] ^ recovered_275_co[2];
  assign recovered_275_co[3] = (recovered_275_s[3] & recovered_275_co[2]) | (~recovered_275_s[3] & recovered_275_di[3]);
  assign {esc_add_ln208_50_reg_7223_reg_7__i_1_n_0_700420e ,esc_NLW_add_ln208_50_reg_7223_reg_7__i_1_CO_UNCONNECTED_d141306 [2:0]} = recovered_275_co;
  assign esc_add_ln208_47_reg_7171_reg_9_5141771 [7:4] = recovered_275_o;

  // Reconstructed LUT2: esc_add_ln208_53_reg_7275_3__i_2_ec68019
  assign esc_add_ln208_53_reg_7275_3__i_2_n_0_cdbccc5 = ((DOADO[3]) ? (~(esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [3])) : (esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [3]));

  // Reconstructed LUT2: esc_add_ln208_53_reg_7275_3__i_3_8fd6f7c
  assign esc_add_ln208_53_reg_7275_3__i_3_n_0_087b9aa = ((DOADO[2]) ? (~(esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [2])) : (esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [2]));

  // Reconstructed LUT2: esc_add_ln208_53_reg_7275_3__i_4_04bd62c
  assign esc_add_ln208_53_reg_7275_3__i_4_n_0_a66a71f = ((DOADO[1]) ? (~(esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [1])) : (esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [1]));

  // Reconstructed LUT2: esc_add_ln208_53_reg_7275_3__i_5_af0c716
  assign esc_add_ln208_53_reg_7275_3__i_5_n_0_1eed7b6 = ((DOADO[0]) ? (~(esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [0])) : (esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [0]));

  // Reconstructed LUT2: esc_add_ln208_53_reg_7275_7__i_2_ceef5be
  assign esc_add_ln208_53_reg_7275_7__i_2_n_0_64e8bf6 = ((DOADO[7]) ? (~(esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [7])) : (esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [7]));

  // Reconstructed LUT2: esc_add_ln208_53_reg_7275_7__i_3_5ec8f56
  assign esc_add_ln208_53_reg_7275_7__i_3_n_0_a4657fa = ((DOADO[6]) ? (~(esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [6])) : (esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [6]));

  // Reconstructed LUT2: esc_add_ln208_53_reg_7275_7__i_4_458ec23
  assign esc_add_ln208_53_reg_7275_7__i_4_n_0_24dd9fd = ((DOADO[5]) ? (~(esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [5])) : (esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [5]));

  // Reconstructed LUT2: esc_add_ln208_53_reg_7275_7__i_5_6dd7299
  assign esc_add_ln208_53_reg_7275_7__i_5_n_0_e3b1e5e = ((DOADO[4]) ? (~(esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [4])) : (esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [4]));

  // Reconstructed CARRY4: esc_add_ln208_53_reg_7275_reg_10__i_2_603902d
  wire [3:0] recovered_284_co, recovered_284_o, recovered_284_s, recovered_284_di;
  assign recovered_284_s = {esc_const0_a0cf646 ,esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [10:8]};
  assign recovered_284_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_284_ci = ((esc_add_ln208_53_reg_7275_reg_7__i_1_n_0_10ffd4a) !== 1'bz) && (esc_add_ln208_53_reg_7275_reg_7__i_1_n_0_10ffd4a);
  wire recovered_284_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_284_o[0] = recovered_284_s[0] ^ (recovered_284_ci || recovered_284_cy);
  assign recovered_284_co[0] = (recovered_284_s[0] & (recovered_284_ci || recovered_284_cy)) | (~recovered_284_s[0] & recovered_284_di[0]);
  assign recovered_284_o[1] = recovered_284_s[1] ^ recovered_284_co[0];
  assign recovered_284_co[1] = (recovered_284_s[1] & recovered_284_co[0]) | (~recovered_284_s[1] & recovered_284_di[1]);
  assign recovered_284_o[2] = recovered_284_s[2] ^ recovered_284_co[1];
  assign recovered_284_co[2] = (recovered_284_s[2] & recovered_284_co[1]) | (~recovered_284_s[2] & recovered_284_di[2]);
  assign recovered_284_o[3] = recovered_284_s[3] ^ recovered_284_co[2];
  assign recovered_284_co[3] = (recovered_284_s[3] & recovered_284_co[2]) | (~recovered_284_s[3] & recovered_284_di[3]);
  assign esc_add_ln208_50_reg_7223_reg_10_aa3bb5f [10:8] = recovered_284_o;

  // Reconstructed CARRY4: esc_add_ln208_53_reg_7275_reg_3__i_1_69a9bc0
  wire [3:0] recovered_285_co, recovered_285_o, recovered_285_s, recovered_285_di;
  assign recovered_285_s = {esc_add_ln208_53_reg_7275_3__i_2_n_0_cdbccc5 ,esc_add_ln208_53_reg_7275_3__i_3_n_0_087b9aa ,esc_add_ln208_53_reg_7275_3__i_4_n_0_a66a71f ,esc_add_ln208_53_reg_7275_3__i_5_n_0_1eed7b6 };
  assign recovered_285_di = esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [3:0];
  wire recovered_285_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_285_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_285_o[0] = recovered_285_s[0] ^ (recovered_285_ci || recovered_285_cy);
  assign recovered_285_co[0] = (recovered_285_s[0] & (recovered_285_ci || recovered_285_cy)) | (~recovered_285_s[0] & recovered_285_di[0]);
  assign recovered_285_o[1] = recovered_285_s[1] ^ recovered_285_co[0];
  assign recovered_285_co[1] = (recovered_285_s[1] & recovered_285_co[0]) | (~recovered_285_s[1] & recovered_285_di[1]);
  assign recovered_285_o[2] = recovered_285_s[2] ^ recovered_285_co[1];
  assign recovered_285_co[2] = (recovered_285_s[2] & recovered_285_co[1]) | (~recovered_285_s[2] & recovered_285_di[2]);
  assign recovered_285_o[3] = recovered_285_s[3] ^ recovered_285_co[2];
  assign recovered_285_co[3] = (recovered_285_s[3] & recovered_285_co[2]) | (~recovered_285_s[3] & recovered_285_di[3]);
  assign {esc_add_ln208_53_reg_7275_reg_3__i_1_n_0_284bae9 ,esc_NLW_add_ln208_53_reg_7275_reg_3__i_1_CO_UNCONNECTED_973a58c [2:0]} = recovered_285_co;
  assign esc_add_ln208_50_reg_7223_reg_10_aa3bb5f [3:0] = recovered_285_o;

  // Reconstructed CARRY4: esc_add_ln208_53_reg_7275_reg_7__i_1_30c3872
  wire [3:0] recovered_286_co, recovered_286_o, recovered_286_s, recovered_286_di;
  assign recovered_286_s = {esc_add_ln208_53_reg_7275_7__i_2_n_0_64e8bf6 ,esc_add_ln208_53_reg_7275_7__i_3_n_0_a4657fa ,esc_add_ln208_53_reg_7275_7__i_4_n_0_24dd9fd ,esc_add_ln208_53_reg_7275_7__i_5_n_0_e3b1e5e };
  assign recovered_286_di = esc_add_ln208_53_reg_7275_reg_10__0_3cad4e9 [7:4];
  wire recovered_286_ci = ((esc_add_ln208_53_reg_7275_reg_3__i_1_n_0_284bae9) !== 1'bz) && (esc_add_ln208_53_reg_7275_reg_3__i_1_n_0_284bae9);
  wire recovered_286_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_286_o[0] = recovered_286_s[0] ^ (recovered_286_ci || recovered_286_cy);
  assign recovered_286_co[0] = (recovered_286_s[0] & (recovered_286_ci || recovered_286_cy)) | (~recovered_286_s[0] & recovered_286_di[0]);
  assign recovered_286_o[1] = recovered_286_s[1] ^ recovered_286_co[0];
  assign recovered_286_co[1] = (recovered_286_s[1] & recovered_286_co[0]) | (~recovered_286_s[1] & recovered_286_di[1]);
  assign recovered_286_o[2] = recovered_286_s[2] ^ recovered_286_co[1];
  assign recovered_286_co[2] = (recovered_286_s[2] & recovered_286_co[1]) | (~recovered_286_s[2] & recovered_286_di[2]);
  assign recovered_286_o[3] = recovered_286_s[3] ^ recovered_286_co[2];
  assign recovered_286_co[3] = (recovered_286_s[3] & recovered_286_co[2]) | (~recovered_286_s[3] & recovered_286_di[3]);
  assign {esc_add_ln208_53_reg_7275_reg_7__i_1_n_0_10ffd4a ,esc_NLW_add_ln208_53_reg_7275_reg_7__i_1_CO_UNCONNECTED_8d21bf0 [2:0]} = recovered_286_co;
  assign esc_add_ln208_50_reg_7223_reg_10_aa3bb5f [7:4] = recovered_286_o;

  // Reconstructed LUT2: esc_add_ln208_56_reg_7327_3__i_2_66e7aa8
  assign esc_add_ln208_56_reg_7327_3__i_2_n_0_8635e74 = ((DOADO[3]) ? (~(esc_add_ln208_56_reg_7327_reg_10__0_e100627 [3])) : (esc_add_ln208_56_reg_7327_reg_10__0_e100627 [3]));

  // Reconstructed LUT2: esc_add_ln208_56_reg_7327_3__i_3_bb042aa
  assign esc_add_ln208_56_reg_7327_3__i_3_n_0_8a1f0fa = ((DOADO[2]) ? (~(esc_add_ln208_56_reg_7327_reg_10__0_e100627 [2])) : (esc_add_ln208_56_reg_7327_reg_10__0_e100627 [2]));

  // Reconstructed LUT2: esc_add_ln208_56_reg_7327_3__i_4_dac527e
  assign esc_add_ln208_56_reg_7327_3__i_4_n_0_268b686 = ((DOADO[1]) ? (~(esc_add_ln208_56_reg_7327_reg_10__0_e100627 [1])) : (esc_add_ln208_56_reg_7327_reg_10__0_e100627 [1]));

  // Reconstructed LUT2: esc_add_ln208_56_reg_7327_3__i_5_cc06a7d
  assign esc_add_ln208_56_reg_7327_3__i_5_n_0_9341fe9 = ((DOADO[0]) ? (~(esc_add_ln208_56_reg_7327_reg_10__0_e100627 [0])) : (esc_add_ln208_56_reg_7327_reg_10__0_e100627 [0]));

  // Reconstructed LUT2: esc_add_ln208_56_reg_7327_7__i_2_b7d3e5b
  assign esc_add_ln208_56_reg_7327_7__i_2_n_0_2c2dc63 = ((DOADO[7]) ? (~(esc_add_ln208_56_reg_7327_reg_10__0_e100627 [7])) : (esc_add_ln208_56_reg_7327_reg_10__0_e100627 [7]));

  // Reconstructed LUT2: esc_add_ln208_56_reg_7327_7__i_3_ad02699
  assign esc_add_ln208_56_reg_7327_7__i_3_n_0_366cc97 = ((DOADO[6]) ? (~(esc_add_ln208_56_reg_7327_reg_10__0_e100627 [6])) : (esc_add_ln208_56_reg_7327_reg_10__0_e100627 [6]));

  // Reconstructed LUT2: esc_add_ln208_56_reg_7327_7__i_4_1e4bd62
  assign esc_add_ln208_56_reg_7327_7__i_4_n_0_22a0e45 = ((DOADO[5]) ? (~(esc_add_ln208_56_reg_7327_reg_10__0_e100627 [5])) : (esc_add_ln208_56_reg_7327_reg_10__0_e100627 [5]));

  // Reconstructed LUT2: esc_add_ln208_56_reg_7327_7__i_5_03fd526
  assign esc_add_ln208_56_reg_7327_7__i_5_n_0_20763ff = ((DOADO[4]) ? (~(esc_add_ln208_56_reg_7327_reg_10__0_e100627 [4])) : (esc_add_ln208_56_reg_7327_reg_10__0_e100627 [4]));

  // Reconstructed CARRY4: esc_add_ln208_56_reg_7327_reg_10__i_2_02c08b1
  wire [3:0] recovered_295_co, recovered_295_o, recovered_295_s, recovered_295_di;
  assign recovered_295_s = {esc_const0_a0cf646 ,esc_add_ln208_56_reg_7327_reg_10__0_e100627 [10:8]};
  assign recovered_295_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_295_ci = ((esc_add_ln208_56_reg_7327_reg_7__i_1_n_0_1f572be) !== 1'bz) && (esc_add_ln208_56_reg_7327_reg_7__i_1_n_0_1f572be);
  wire recovered_295_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_295_o[0] = recovered_295_s[0] ^ (recovered_295_ci || recovered_295_cy);
  assign recovered_295_co[0] = (recovered_295_s[0] & (recovered_295_ci || recovered_295_cy)) | (~recovered_295_s[0] & recovered_295_di[0]);
  assign recovered_295_o[1] = recovered_295_s[1] ^ recovered_295_co[0];
  assign recovered_295_co[1] = (recovered_295_s[1] & recovered_295_co[0]) | (~recovered_295_s[1] & recovered_295_di[1]);
  assign recovered_295_o[2] = recovered_295_s[2] ^ recovered_295_co[1];
  assign recovered_295_co[2] = (recovered_295_s[2] & recovered_295_co[1]) | (~recovered_295_s[2] & recovered_295_di[2]);
  assign recovered_295_o[3] = recovered_295_s[3] ^ recovered_295_co[2];
  assign recovered_295_co[3] = (recovered_295_s[3] & recovered_295_co[2]) | (~recovered_295_s[3] & recovered_295_di[3]);
  assign esc_add_ln208_53_reg_7275_reg_10_0754859 [10:8] = recovered_295_o;

  // Reconstructed CARRY4: esc_add_ln208_56_reg_7327_reg_3__i_1_35bdba1
  wire [3:0] recovered_296_co, recovered_296_o, recovered_296_s, recovered_296_di;
  assign recovered_296_s = {esc_add_ln208_56_reg_7327_3__i_2_n_0_8635e74 ,esc_add_ln208_56_reg_7327_3__i_3_n_0_8a1f0fa ,esc_add_ln208_56_reg_7327_3__i_4_n_0_268b686 ,esc_add_ln208_56_reg_7327_3__i_5_n_0_9341fe9 };
  assign recovered_296_di = esc_add_ln208_56_reg_7327_reg_10__0_e100627 [3:0];
  wire recovered_296_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_296_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_296_o[0] = recovered_296_s[0] ^ (recovered_296_ci || recovered_296_cy);
  assign recovered_296_co[0] = (recovered_296_s[0] & (recovered_296_ci || recovered_296_cy)) | (~recovered_296_s[0] & recovered_296_di[0]);
  assign recovered_296_o[1] = recovered_296_s[1] ^ recovered_296_co[0];
  assign recovered_296_co[1] = (recovered_296_s[1] & recovered_296_co[0]) | (~recovered_296_s[1] & recovered_296_di[1]);
  assign recovered_296_o[2] = recovered_296_s[2] ^ recovered_296_co[1];
  assign recovered_296_co[2] = (recovered_296_s[2] & recovered_296_co[1]) | (~recovered_296_s[2] & recovered_296_di[2]);
  assign recovered_296_o[3] = recovered_296_s[3] ^ recovered_296_co[2];
  assign recovered_296_co[3] = (recovered_296_s[3] & recovered_296_co[2]) | (~recovered_296_s[3] & recovered_296_di[3]);
  assign {esc_add_ln208_56_reg_7327_reg_3__i_1_n_0_f366b57 ,esc_NLW_add_ln208_56_reg_7327_reg_3__i_1_CO_UNCONNECTED_aaa1e10 [2:0]} = recovered_296_co;
  assign esc_add_ln208_53_reg_7275_reg_10_0754859 [3:0] = recovered_296_o;

  // Reconstructed CARRY4: esc_add_ln208_56_reg_7327_reg_7__i_1_eaaaa7e
  wire [3:0] recovered_297_co, recovered_297_o, recovered_297_s, recovered_297_di;
  assign recovered_297_s = {esc_add_ln208_56_reg_7327_7__i_2_n_0_2c2dc63 ,esc_add_ln208_56_reg_7327_7__i_3_n_0_366cc97 ,esc_add_ln208_56_reg_7327_7__i_4_n_0_22a0e45 ,esc_add_ln208_56_reg_7327_7__i_5_n_0_20763ff };
  assign recovered_297_di = esc_add_ln208_56_reg_7327_reg_10__0_e100627 [7:4];
  wire recovered_297_ci = ((esc_add_ln208_56_reg_7327_reg_3__i_1_n_0_f366b57) !== 1'bz) && (esc_add_ln208_56_reg_7327_reg_3__i_1_n_0_f366b57);
  wire recovered_297_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_297_o[0] = recovered_297_s[0] ^ (recovered_297_ci || recovered_297_cy);
  assign recovered_297_co[0] = (recovered_297_s[0] & (recovered_297_ci || recovered_297_cy)) | (~recovered_297_s[0] & recovered_297_di[0]);
  assign recovered_297_o[1] = recovered_297_s[1] ^ recovered_297_co[0];
  assign recovered_297_co[1] = (recovered_297_s[1] & recovered_297_co[0]) | (~recovered_297_s[1] & recovered_297_di[1]);
  assign recovered_297_o[2] = recovered_297_s[2] ^ recovered_297_co[1];
  assign recovered_297_co[2] = (recovered_297_s[2] & recovered_297_co[1]) | (~recovered_297_s[2] & recovered_297_di[2]);
  assign recovered_297_o[3] = recovered_297_s[3] ^ recovered_297_co[2];
  assign recovered_297_co[3] = (recovered_297_s[3] & recovered_297_co[2]) | (~recovered_297_s[3] & recovered_297_di[3]);
  assign {esc_add_ln208_56_reg_7327_reg_7__i_1_n_0_1f572be ,esc_NLW_add_ln208_56_reg_7327_reg_7__i_1_CO_UNCONNECTED_693ccdd [2:0]} = recovered_297_co;
  assign esc_add_ln208_53_reg_7275_reg_10_0754859 [7:4] = recovered_297_o;

  // Reconstructed LUT2: esc_add_ln208_59_reg_7379_3__i_2_60bd135
  assign esc_add_ln208_59_reg_7379_3__i_2_n_0_a7c344a = ((DOADO[3]) ? (~(esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [3])) : (esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [3]));

  // Reconstructed LUT2: esc_add_ln208_59_reg_7379_3__i_3_99706bc
  assign esc_add_ln208_59_reg_7379_3__i_3_n_0_de678a6 = ((DOADO[2]) ? (~(esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [2])) : (esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [2]));

  // Reconstructed LUT2: esc_add_ln208_59_reg_7379_3__i_4_c47fdfb
  assign esc_add_ln208_59_reg_7379_3__i_4_n_0_2147988 = ((DOADO[1]) ? (~(esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [1])) : (esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [1]));

  // Reconstructed LUT2: esc_add_ln208_59_reg_7379_3__i_5_38e95c5
  assign esc_add_ln208_59_reg_7379_3__i_5_n_0_4b259b6 = ((DOADO[0]) ? (~(esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [0])) : (esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [0]));

  // Reconstructed LUT2: esc_add_ln208_59_reg_7379_7__i_2_834cde9
  assign esc_add_ln208_59_reg_7379_7__i_2_n_0_11fb2a9 = ((DOADO[7]) ? (~(esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [7])) : (esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [7]));

  // Reconstructed LUT2: esc_add_ln208_59_reg_7379_7__i_3_780539d
  assign esc_add_ln208_59_reg_7379_7__i_3_n_0_d8843a7 = ((DOADO[6]) ? (~(esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [6])) : (esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [6]));

  // Reconstructed LUT2: esc_add_ln208_59_reg_7379_7__i_4_8d98363
  assign esc_add_ln208_59_reg_7379_7__i_4_n_0_0969c35 = ((DOADO[5]) ? (~(esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [5])) : (esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [5]));

  // Reconstructed LUT2: esc_add_ln208_59_reg_7379_7__i_5_e588b9d
  assign esc_add_ln208_59_reg_7379_7__i_5_n_0_f16c2ea = ((DOADO[4]) ? (~(esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [4])) : (esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [4]));

  // Reconstructed CARRY4: esc_add_ln208_59_reg_7379_reg_10__i_2_8a447cd
  wire [3:0] recovered_306_co, recovered_306_o, recovered_306_s, recovered_306_di;
  assign recovered_306_s = {esc_const0_a0cf646 ,esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [10:8]};
  assign recovered_306_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_306_ci = ((esc_add_ln208_59_reg_7379_reg_7__i_1_n_0_2c56762) !== 1'bz) && (esc_add_ln208_59_reg_7379_reg_7__i_1_n_0_2c56762);
  wire recovered_306_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_306_o[0] = recovered_306_s[0] ^ (recovered_306_ci || recovered_306_cy);
  assign recovered_306_co[0] = (recovered_306_s[0] & (recovered_306_ci || recovered_306_cy)) | (~recovered_306_s[0] & recovered_306_di[0]);
  assign recovered_306_o[1] = recovered_306_s[1] ^ recovered_306_co[0];
  assign recovered_306_co[1] = (recovered_306_s[1] & recovered_306_co[0]) | (~recovered_306_s[1] & recovered_306_di[1]);
  assign recovered_306_o[2] = recovered_306_s[2] ^ recovered_306_co[1];
  assign recovered_306_co[2] = (recovered_306_s[2] & recovered_306_co[1]) | (~recovered_306_s[2] & recovered_306_di[2]);
  assign recovered_306_o[3] = recovered_306_s[3] ^ recovered_306_co[2];
  assign recovered_306_co[3] = (recovered_306_s[3] & recovered_306_co[2]) | (~recovered_306_s[3] & recovered_306_di[3]);
  assign esc_add_ln208_56_reg_7327_reg_10_b6e53dd [10:8] = recovered_306_o;

  // Reconstructed CARRY4: esc_add_ln208_59_reg_7379_reg_3__i_1_df51d65
  wire [3:0] recovered_307_co, recovered_307_o, recovered_307_s, recovered_307_di;
  assign recovered_307_s = {esc_add_ln208_59_reg_7379_3__i_2_n_0_a7c344a ,esc_add_ln208_59_reg_7379_3__i_3_n_0_de678a6 ,esc_add_ln208_59_reg_7379_3__i_4_n_0_2147988 ,esc_add_ln208_59_reg_7379_3__i_5_n_0_4b259b6 };
  assign recovered_307_di = esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [3:0];
  wire recovered_307_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_307_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_307_o[0] = recovered_307_s[0] ^ (recovered_307_ci || recovered_307_cy);
  assign recovered_307_co[0] = (recovered_307_s[0] & (recovered_307_ci || recovered_307_cy)) | (~recovered_307_s[0] & recovered_307_di[0]);
  assign recovered_307_o[1] = recovered_307_s[1] ^ recovered_307_co[0];
  assign recovered_307_co[1] = (recovered_307_s[1] & recovered_307_co[0]) | (~recovered_307_s[1] & recovered_307_di[1]);
  assign recovered_307_o[2] = recovered_307_s[2] ^ recovered_307_co[1];
  assign recovered_307_co[2] = (recovered_307_s[2] & recovered_307_co[1]) | (~recovered_307_s[2] & recovered_307_di[2]);
  assign recovered_307_o[3] = recovered_307_s[3] ^ recovered_307_co[2];
  assign recovered_307_co[3] = (recovered_307_s[3] & recovered_307_co[2]) | (~recovered_307_s[3] & recovered_307_di[3]);
  assign {esc_add_ln208_59_reg_7379_reg_3__i_1_n_0_8d2e0ae ,esc_NLW_add_ln208_59_reg_7379_reg_3__i_1_CO_UNCONNECTED_6fd1f0c [2:0]} = recovered_307_co;
  assign esc_add_ln208_56_reg_7327_reg_10_b6e53dd [3:0] = recovered_307_o;

  // Reconstructed CARRY4: esc_add_ln208_59_reg_7379_reg_7__i_1_8827751
  wire [3:0] recovered_308_co, recovered_308_o, recovered_308_s, recovered_308_di;
  assign recovered_308_s = {esc_add_ln208_59_reg_7379_7__i_2_n_0_11fb2a9 ,esc_add_ln208_59_reg_7379_7__i_3_n_0_d8843a7 ,esc_add_ln208_59_reg_7379_7__i_4_n_0_0969c35 ,esc_add_ln208_59_reg_7379_7__i_5_n_0_f16c2ea };
  assign recovered_308_di = esc_add_ln208_59_reg_7379_reg_10__0_cb96932 [7:4];
  wire recovered_308_ci = ((esc_add_ln208_59_reg_7379_reg_3__i_1_n_0_8d2e0ae) !== 1'bz) && (esc_add_ln208_59_reg_7379_reg_3__i_1_n_0_8d2e0ae);
  wire recovered_308_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_308_o[0] = recovered_308_s[0] ^ (recovered_308_ci || recovered_308_cy);
  assign recovered_308_co[0] = (recovered_308_s[0] & (recovered_308_ci || recovered_308_cy)) | (~recovered_308_s[0] & recovered_308_di[0]);
  assign recovered_308_o[1] = recovered_308_s[1] ^ recovered_308_co[0];
  assign recovered_308_co[1] = (recovered_308_s[1] & recovered_308_co[0]) | (~recovered_308_s[1] & recovered_308_di[1]);
  assign recovered_308_o[2] = recovered_308_s[2] ^ recovered_308_co[1];
  assign recovered_308_co[2] = (recovered_308_s[2] & recovered_308_co[1]) | (~recovered_308_s[2] & recovered_308_di[2]);
  assign recovered_308_o[3] = recovered_308_s[3] ^ recovered_308_co[2];
  assign recovered_308_co[3] = (recovered_308_s[3] & recovered_308_co[2]) | (~recovered_308_s[3] & recovered_308_di[3]);
  assign {esc_add_ln208_59_reg_7379_reg_7__i_1_n_0_2c56762 ,esc_NLW_add_ln208_59_reg_7379_reg_7__i_1_CO_UNCONNECTED_29a5f86 [2:0]} = recovered_308_co;
  assign esc_add_ln208_56_reg_7327_reg_10_b6e53dd [7:4] = recovered_308_o;

  // Reconstructed LUT2: esc_add_ln208_62_reg_7431_3__i_2_424b470
  assign esc_add_ln208_62_reg_7431_3__i_2_n_0_0fa8743 = ((DOADO[3]) ? (~(esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [3])) : (esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [3]));

  // Reconstructed LUT2: esc_add_ln208_62_reg_7431_3__i_3_082cec1
  assign esc_add_ln208_62_reg_7431_3__i_3_n_0_c1ea5e4 = ((DOADO[2]) ? (~(esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [2])) : (esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [2]));

  // Reconstructed LUT2: esc_add_ln208_62_reg_7431_3__i_4_553dc31
  assign esc_add_ln208_62_reg_7431_3__i_4_n_0_e2f7dcc = ((DOADO[1]) ? (~(esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [1])) : (esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [1]));

  // Reconstructed LUT2: esc_add_ln208_62_reg_7431_3__i_5_a3f0b2e
  assign esc_add_ln208_62_reg_7431_3__i_5_n_0_7fd5657 = ((DOADO[0]) ? (~(esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [0])) : (esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [0]));

  // Reconstructed LUT2: esc_add_ln208_62_reg_7431_7__i_2_176c38b
  assign esc_add_ln208_62_reg_7431_7__i_2_n_0_12178f4 = ((DOADO[7]) ? (~(esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [7])) : (esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [7]));

  // Reconstructed LUT2: esc_add_ln208_62_reg_7431_7__i_3_282ba8c
  assign esc_add_ln208_62_reg_7431_7__i_3_n_0_66f10a0 = ((DOADO[6]) ? (~(esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [6])) : (esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [6]));

  // Reconstructed LUT2: esc_add_ln208_62_reg_7431_7__i_4_d9184c2
  assign esc_add_ln208_62_reg_7431_7__i_4_n_0_4370974 = ((DOADO[5]) ? (~(esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [5])) : (esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [5]));

  // Reconstructed LUT2: esc_add_ln208_62_reg_7431_7__i_5_7fa7b35
  assign esc_add_ln208_62_reg_7431_7__i_5_n_0_5d4d57f = ((DOADO[4]) ? (~(esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [4])) : (esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [4]));

  // Reconstructed CARRY4: esc_add_ln208_62_reg_7431_reg_11__i_2_bb377cf
  wire [3:0] recovered_317_co, recovered_317_o, recovered_317_s, recovered_317_di;
  assign recovered_317_s = {esc_const1_c064970 ,esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [10:8]};
  assign recovered_317_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_317_ci = ((esc_add_ln208_62_reg_7431_reg_7__i_1_n_0_9e9db93) !== 1'bz) && (esc_add_ln208_62_reg_7431_reg_7__i_1_n_0_9e9db93);
  wire recovered_317_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_317_o[0] = recovered_317_s[0] ^ (recovered_317_ci || recovered_317_cy);
  assign recovered_317_co[0] = (recovered_317_s[0] & (recovered_317_ci || recovered_317_cy)) | (~recovered_317_s[0] & recovered_317_di[0]);
  assign recovered_317_o[1] = recovered_317_s[1] ^ recovered_317_co[0];
  assign recovered_317_co[1] = (recovered_317_s[1] & recovered_317_co[0]) | (~recovered_317_s[1] & recovered_317_di[1]);
  assign recovered_317_o[2] = recovered_317_s[2] ^ recovered_317_co[1];
  assign recovered_317_co[2] = (recovered_317_s[2] & recovered_317_co[1]) | (~recovered_317_s[2] & recovered_317_di[2]);
  assign recovered_317_o[3] = recovered_317_s[3] ^ recovered_317_co[2];
  assign recovered_317_co[3] = (recovered_317_s[3] & recovered_317_co[2]) | (~recovered_317_s[3] & recovered_317_di[3]);
  assign {esc_add_ln208_59_reg_7379_reg_10_8ef5260 [11],esc_NLW_add_ln208_62_reg_7431_reg_11__i_2_CO_UNCONNECTED_709ade5 [2:0]} = recovered_317_co;
  assign esc_add_ln208_59_reg_7379_reg_10_8ef5260 [10:8] = recovered_317_o;

  // Reconstructed CARRY4: esc_add_ln208_62_reg_7431_reg_3__i_1_cc9b63e
  wire [3:0] recovered_318_co, recovered_318_o, recovered_318_s, recovered_318_di;
  assign recovered_318_s = {esc_add_ln208_62_reg_7431_3__i_2_n_0_0fa8743 ,esc_add_ln208_62_reg_7431_3__i_3_n_0_c1ea5e4 ,esc_add_ln208_62_reg_7431_3__i_4_n_0_e2f7dcc ,esc_add_ln208_62_reg_7431_3__i_5_n_0_7fd5657 };
  assign recovered_318_di = esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [3:0];
  wire recovered_318_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_318_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_318_o[0] = recovered_318_s[0] ^ (recovered_318_ci || recovered_318_cy);
  assign recovered_318_co[0] = (recovered_318_s[0] & (recovered_318_ci || recovered_318_cy)) | (~recovered_318_s[0] & recovered_318_di[0]);
  assign recovered_318_o[1] = recovered_318_s[1] ^ recovered_318_co[0];
  assign recovered_318_co[1] = (recovered_318_s[1] & recovered_318_co[0]) | (~recovered_318_s[1] & recovered_318_di[1]);
  assign recovered_318_o[2] = recovered_318_s[2] ^ recovered_318_co[1];
  assign recovered_318_co[2] = (recovered_318_s[2] & recovered_318_co[1]) | (~recovered_318_s[2] & recovered_318_di[2]);
  assign recovered_318_o[3] = recovered_318_s[3] ^ recovered_318_co[2];
  assign recovered_318_co[3] = (recovered_318_s[3] & recovered_318_co[2]) | (~recovered_318_s[3] & recovered_318_di[3]);
  assign {esc_add_ln208_62_reg_7431_reg_3__i_1_n_0_5e8d60d ,esc_NLW_add_ln208_62_reg_7431_reg_3__i_1_CO_UNCONNECTED_b41439c [2:0]} = recovered_318_co;
  assign esc_add_ln208_59_reg_7379_reg_10_8ef5260 [3:0] = recovered_318_o;

  // Reconstructed CARRY4: esc_add_ln208_62_reg_7431_reg_7__i_1_3576737
  wire [3:0] recovered_319_co, recovered_319_o, recovered_319_s, recovered_319_di;
  assign recovered_319_s = {esc_add_ln208_62_reg_7431_7__i_2_n_0_12178f4 ,esc_add_ln208_62_reg_7431_7__i_3_n_0_66f10a0 ,esc_add_ln208_62_reg_7431_7__i_4_n_0_4370974 ,esc_add_ln208_62_reg_7431_7__i_5_n_0_5d4d57f };
  assign recovered_319_di = esc_add_ln208_62_reg_7431_reg_11__0_ea05c78 [7:4];
  wire recovered_319_ci = ((esc_add_ln208_62_reg_7431_reg_3__i_1_n_0_5e8d60d) !== 1'bz) && (esc_add_ln208_62_reg_7431_reg_3__i_1_n_0_5e8d60d);
  wire recovered_319_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_319_o[0] = recovered_319_s[0] ^ (recovered_319_ci || recovered_319_cy);
  assign recovered_319_co[0] = (recovered_319_s[0] & (recovered_319_ci || recovered_319_cy)) | (~recovered_319_s[0] & recovered_319_di[0]);
  assign recovered_319_o[1] = recovered_319_s[1] ^ recovered_319_co[0];
  assign recovered_319_co[1] = (recovered_319_s[1] & recovered_319_co[0]) | (~recovered_319_s[1] & recovered_319_di[1]);
  assign recovered_319_o[2] = recovered_319_s[2] ^ recovered_319_co[1];
  assign recovered_319_co[2] = (recovered_319_s[2] & recovered_319_co[1]) | (~recovered_319_s[2] & recovered_319_di[2]);
  assign recovered_319_o[3] = recovered_319_s[3] ^ recovered_319_co[2];
  assign recovered_319_co[3] = (recovered_319_s[3] & recovered_319_co[2]) | (~recovered_319_s[3] & recovered_319_di[3]);
  assign {esc_add_ln208_62_reg_7431_reg_7__i_1_n_0_9e9db93 ,esc_NLW_add_ln208_62_reg_7431_reg_7__i_1_CO_UNCONNECTED_c4eef1c [2:0]} = recovered_319_co;
  assign esc_add_ln208_59_reg_7379_reg_10_8ef5260 [7:4] = recovered_319_o;

  // Reconstructed LUT2: esc_add_ln208_65_reg_7483_3__i_2_2be8708
  assign esc_add_ln208_65_reg_7483_3__i_2_n_0_3cc8d84 = ((DOADO[3]) ? (~(esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [3])) : (esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [3]));

  // Reconstructed LUT2: esc_add_ln208_65_reg_7483_3__i_3_a8bebd0
  assign esc_add_ln208_65_reg_7483_3__i_3_n_0_04aedb2 = ((DOADO[2]) ? (~(esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [2])) : (esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [2]));

  // Reconstructed LUT2: esc_add_ln208_65_reg_7483_3__i_4_79cd2c4
  assign esc_add_ln208_65_reg_7483_3__i_4_n_0_11c8708 = ((DOADO[1]) ? (~(esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [1])) : (esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [1]));

  // Reconstructed LUT2: esc_add_ln208_65_reg_7483_3__i_5_f10fcbd
  assign esc_add_ln208_65_reg_7483_3__i_5_n_0_2cc0bf8 = ((DOADO[0]) ? (~(esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [0])) : (esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [0]));

  // Reconstructed LUT2: esc_add_ln208_65_reg_7483_7__i_2_50c132c
  assign esc_add_ln208_65_reg_7483_7__i_2_n_0_28fd2e8 = ((DOADO[7]) ? (~(esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [7])) : (esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [7]));

  // Reconstructed LUT2: esc_add_ln208_65_reg_7483_7__i_3_4b0c1b9
  assign esc_add_ln208_65_reg_7483_7__i_3_n_0_262d496 = ((DOADO[6]) ? (~(esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [6])) : (esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [6]));

  // Reconstructed LUT2: esc_add_ln208_65_reg_7483_7__i_4_8144a81
  assign esc_add_ln208_65_reg_7483_7__i_4_n_0_b9e6098 = ((DOADO[5]) ? (~(esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [5])) : (esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [5]));

  // Reconstructed LUT2: esc_add_ln208_65_reg_7483_7__i_5_4f30dfe
  assign esc_add_ln208_65_reg_7483_7__i_5_n_0_0d2516d = ((DOADO[4]) ? (~(esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [4])) : (esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [4]));

  // Reconstructed CARRY4: esc_add_ln208_65_reg_7483_reg_11__i_2_a9deaa3
  wire [3:0] recovered_328_co, recovered_328_o, recovered_328_s, recovered_328_di;
  assign recovered_328_s = esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [11:8];
  assign recovered_328_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_328_ci = ((esc_add_ln208_65_reg_7483_reg_7__i_1_n_0_950dabc) !== 1'bz) && (esc_add_ln208_65_reg_7483_reg_7__i_1_n_0_950dabc);
  wire recovered_328_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_328_o[0] = recovered_328_s[0] ^ (recovered_328_ci || recovered_328_cy);
  assign recovered_328_co[0] = (recovered_328_s[0] & (recovered_328_ci || recovered_328_cy)) | (~recovered_328_s[0] & recovered_328_di[0]);
  assign recovered_328_o[1] = recovered_328_s[1] ^ recovered_328_co[0];
  assign recovered_328_co[1] = (recovered_328_s[1] & recovered_328_co[0]) | (~recovered_328_s[1] & recovered_328_di[1]);
  assign recovered_328_o[2] = recovered_328_s[2] ^ recovered_328_co[1];
  assign recovered_328_co[2] = (recovered_328_s[2] & recovered_328_co[1]) | (~recovered_328_s[2] & recovered_328_di[2]);
  assign recovered_328_o[3] = recovered_328_s[3] ^ recovered_328_co[2];
  assign recovered_328_co[3] = (recovered_328_s[3] & recovered_328_co[2]) | (~recovered_328_s[3] & recovered_328_di[3]);
  assign esc_add_ln208_62_reg_7431_reg_11_6ab2f6a [11:8] = recovered_328_o;

  // Reconstructed CARRY4: esc_add_ln208_65_reg_7483_reg_3__i_1_48b640c
  wire [3:0] recovered_329_co, recovered_329_o, recovered_329_s, recovered_329_di;
  assign recovered_329_s = {esc_add_ln208_65_reg_7483_3__i_2_n_0_3cc8d84 ,esc_add_ln208_65_reg_7483_3__i_3_n_0_04aedb2 ,esc_add_ln208_65_reg_7483_3__i_4_n_0_11c8708 ,esc_add_ln208_65_reg_7483_3__i_5_n_0_2cc0bf8 };
  assign recovered_329_di = esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [3:0];
  wire recovered_329_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_329_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_329_o[0] = recovered_329_s[0] ^ (recovered_329_ci || recovered_329_cy);
  assign recovered_329_co[0] = (recovered_329_s[0] & (recovered_329_ci || recovered_329_cy)) | (~recovered_329_s[0] & recovered_329_di[0]);
  assign recovered_329_o[1] = recovered_329_s[1] ^ recovered_329_co[0];
  assign recovered_329_co[1] = (recovered_329_s[1] & recovered_329_co[0]) | (~recovered_329_s[1] & recovered_329_di[1]);
  assign recovered_329_o[2] = recovered_329_s[2] ^ recovered_329_co[1];
  assign recovered_329_co[2] = (recovered_329_s[2] & recovered_329_co[1]) | (~recovered_329_s[2] & recovered_329_di[2]);
  assign recovered_329_o[3] = recovered_329_s[3] ^ recovered_329_co[2];
  assign recovered_329_co[3] = (recovered_329_s[3] & recovered_329_co[2]) | (~recovered_329_s[3] & recovered_329_di[3]);
  assign {esc_add_ln208_65_reg_7483_reg_3__i_1_n_0_e756f1b ,esc_NLW_add_ln208_65_reg_7483_reg_3__i_1_CO_UNCONNECTED_639670e [2:0]} = recovered_329_co;
  assign esc_add_ln208_62_reg_7431_reg_11_6ab2f6a [3:0] = recovered_329_o;

  // Reconstructed CARRY4: esc_add_ln208_65_reg_7483_reg_7__i_1_60e80c3
  wire [3:0] recovered_330_co, recovered_330_o, recovered_330_s, recovered_330_di;
  assign recovered_330_s = {esc_add_ln208_65_reg_7483_7__i_2_n_0_28fd2e8 ,esc_add_ln208_65_reg_7483_7__i_3_n_0_262d496 ,esc_add_ln208_65_reg_7483_7__i_4_n_0_b9e6098 ,esc_add_ln208_65_reg_7483_7__i_5_n_0_0d2516d };
  assign recovered_330_di = esc_add_ln208_65_reg_7483_reg_11__0_6caa48b [7:4];
  wire recovered_330_ci = ((esc_add_ln208_65_reg_7483_reg_3__i_1_n_0_e756f1b) !== 1'bz) && (esc_add_ln208_65_reg_7483_reg_3__i_1_n_0_e756f1b);
  wire recovered_330_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_330_o[0] = recovered_330_s[0] ^ (recovered_330_ci || recovered_330_cy);
  assign recovered_330_co[0] = (recovered_330_s[0] & (recovered_330_ci || recovered_330_cy)) | (~recovered_330_s[0] & recovered_330_di[0]);
  assign recovered_330_o[1] = recovered_330_s[1] ^ recovered_330_co[0];
  assign recovered_330_co[1] = (recovered_330_s[1] & recovered_330_co[0]) | (~recovered_330_s[1] & recovered_330_di[1]);
  assign recovered_330_o[2] = recovered_330_s[2] ^ recovered_330_co[1];
  assign recovered_330_co[2] = (recovered_330_s[2] & recovered_330_co[1]) | (~recovered_330_s[2] & recovered_330_di[2]);
  assign recovered_330_o[3] = recovered_330_s[3] ^ recovered_330_co[2];
  assign recovered_330_co[3] = (recovered_330_s[3] & recovered_330_co[2]) | (~recovered_330_s[3] & recovered_330_di[3]);
  assign {esc_add_ln208_65_reg_7483_reg_7__i_1_n_0_950dabc ,esc_NLW_add_ln208_65_reg_7483_reg_7__i_1_CO_UNCONNECTED_f000cec [2:0]} = recovered_330_co;
  assign esc_add_ln208_62_reg_7431_reg_11_6ab2f6a [7:4] = recovered_330_o;

  // Reconstructed LUT2: esc_add_ln208_68_reg_7535_3__i_2_9829f66
  assign esc_add_ln208_68_reg_7535_3__i_2_n_0_274d44b = ((DOADO[3]) ? (~(esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [3])) : (esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [3]));

  // Reconstructed LUT2: esc_add_ln208_68_reg_7535_3__i_3_12e9829
  assign esc_add_ln208_68_reg_7535_3__i_3_n_0_7d13aed = ((DOADO[2]) ? (~(esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [2])) : (esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [2]));

  // Reconstructed LUT2: esc_add_ln208_68_reg_7535_3__i_4_654a4ba
  assign esc_add_ln208_68_reg_7535_3__i_4_n_0_8f3859f = ((DOADO[1]) ? (~(esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [1])) : (esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [1]));

  // Reconstructed LUT2: esc_add_ln208_68_reg_7535_3__i_5_a681b4c
  assign esc_add_ln208_68_reg_7535_3__i_5_n_0_bba27e8 = ((DOADO[0]) ? (~(esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [0])) : (esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [0]));

  // Reconstructed LUT2: esc_add_ln208_68_reg_7535_7__i_2_29a0416
  assign esc_add_ln208_68_reg_7535_7__i_2_n_0_51973bb = ((DOADO[7]) ? (~(esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [7])) : (esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [7]));

  // Reconstructed LUT2: esc_add_ln208_68_reg_7535_7__i_3_4161ac2
  assign esc_add_ln208_68_reg_7535_7__i_3_n_0_9701d9c = ((DOADO[6]) ? (~(esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [6])) : (esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [6]));

  // Reconstructed LUT2: esc_add_ln208_68_reg_7535_7__i_4_e81617a
  assign esc_add_ln208_68_reg_7535_7__i_4_n_0_3739859 = ((DOADO[5]) ? (~(esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [5])) : (esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [5]));

  // Reconstructed LUT2: esc_add_ln208_68_reg_7535_7__i_5_d1ea84f
  assign esc_add_ln208_68_reg_7535_7__i_5_n_0_330e570 = ((DOADO[4]) ? (~(esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [4])) : (esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [4]));

  // Reconstructed CARRY4: esc_add_ln208_68_reg_7535_reg_11__i_2_e7021a7
  wire [3:0] recovered_339_co, recovered_339_o, recovered_339_s, recovered_339_di;
  assign recovered_339_s = esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [11:8];
  assign recovered_339_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_339_ci = ((esc_add_ln208_68_reg_7535_reg_7__i_1_n_0_73fe897) !== 1'bz) && (esc_add_ln208_68_reg_7535_reg_7__i_1_n_0_73fe897);
  wire recovered_339_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_339_o[0] = recovered_339_s[0] ^ (recovered_339_ci || recovered_339_cy);
  assign recovered_339_co[0] = (recovered_339_s[0] & (recovered_339_ci || recovered_339_cy)) | (~recovered_339_s[0] & recovered_339_di[0]);
  assign recovered_339_o[1] = recovered_339_s[1] ^ recovered_339_co[0];
  assign recovered_339_co[1] = (recovered_339_s[1] & recovered_339_co[0]) | (~recovered_339_s[1] & recovered_339_di[1]);
  assign recovered_339_o[2] = recovered_339_s[2] ^ recovered_339_co[1];
  assign recovered_339_co[2] = (recovered_339_s[2] & recovered_339_co[1]) | (~recovered_339_s[2] & recovered_339_di[2]);
  assign recovered_339_o[3] = recovered_339_s[3] ^ recovered_339_co[2];
  assign recovered_339_co[3] = (recovered_339_s[3] & recovered_339_co[2]) | (~recovered_339_s[3] & recovered_339_di[3]);
  assign esc_add_ln208_65_reg_7483_reg_11_f154d09 [11:8] = recovered_339_o;

  // Reconstructed CARRY4: esc_add_ln208_68_reg_7535_reg_3__i_1_54b4929
  wire [3:0] recovered_340_co, recovered_340_o, recovered_340_s, recovered_340_di;
  assign recovered_340_s = {esc_add_ln208_68_reg_7535_3__i_2_n_0_274d44b ,esc_add_ln208_68_reg_7535_3__i_3_n_0_7d13aed ,esc_add_ln208_68_reg_7535_3__i_4_n_0_8f3859f ,esc_add_ln208_68_reg_7535_3__i_5_n_0_bba27e8 };
  assign recovered_340_di = esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [3:0];
  wire recovered_340_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_340_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_340_o[0] = recovered_340_s[0] ^ (recovered_340_ci || recovered_340_cy);
  assign recovered_340_co[0] = (recovered_340_s[0] & (recovered_340_ci || recovered_340_cy)) | (~recovered_340_s[0] & recovered_340_di[0]);
  assign recovered_340_o[1] = recovered_340_s[1] ^ recovered_340_co[0];
  assign recovered_340_co[1] = (recovered_340_s[1] & recovered_340_co[0]) | (~recovered_340_s[1] & recovered_340_di[1]);
  assign recovered_340_o[2] = recovered_340_s[2] ^ recovered_340_co[1];
  assign recovered_340_co[2] = (recovered_340_s[2] & recovered_340_co[1]) | (~recovered_340_s[2] & recovered_340_di[2]);
  assign recovered_340_o[3] = recovered_340_s[3] ^ recovered_340_co[2];
  assign recovered_340_co[3] = (recovered_340_s[3] & recovered_340_co[2]) | (~recovered_340_s[3] & recovered_340_di[3]);
  assign {esc_add_ln208_68_reg_7535_reg_3__i_1_n_0_88d4441 ,esc_NLW_add_ln208_68_reg_7535_reg_3__i_1_CO_UNCONNECTED_b8e46ce [2:0]} = recovered_340_co;
  assign esc_add_ln208_65_reg_7483_reg_11_f154d09 [3:0] = recovered_340_o;

  // Reconstructed CARRY4: esc_add_ln208_68_reg_7535_reg_7__i_1_6a3d57f
  wire [3:0] recovered_341_co, recovered_341_o, recovered_341_s, recovered_341_di;
  assign recovered_341_s = {esc_add_ln208_68_reg_7535_7__i_2_n_0_51973bb ,esc_add_ln208_68_reg_7535_7__i_3_n_0_9701d9c ,esc_add_ln208_68_reg_7535_7__i_4_n_0_3739859 ,esc_add_ln208_68_reg_7535_7__i_5_n_0_330e570 };
  assign recovered_341_di = esc_add_ln208_68_reg_7535_reg_11__0_eeee088 [7:4];
  wire recovered_341_ci = ((esc_add_ln208_68_reg_7535_reg_3__i_1_n_0_88d4441) !== 1'bz) && (esc_add_ln208_68_reg_7535_reg_3__i_1_n_0_88d4441);
  wire recovered_341_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_341_o[0] = recovered_341_s[0] ^ (recovered_341_ci || recovered_341_cy);
  assign recovered_341_co[0] = (recovered_341_s[0] & (recovered_341_ci || recovered_341_cy)) | (~recovered_341_s[0] & recovered_341_di[0]);
  assign recovered_341_o[1] = recovered_341_s[1] ^ recovered_341_co[0];
  assign recovered_341_co[1] = (recovered_341_s[1] & recovered_341_co[0]) | (~recovered_341_s[1] & recovered_341_di[1]);
  assign recovered_341_o[2] = recovered_341_s[2] ^ recovered_341_co[1];
  assign recovered_341_co[2] = (recovered_341_s[2] & recovered_341_co[1]) | (~recovered_341_s[2] & recovered_341_di[2]);
  assign recovered_341_o[3] = recovered_341_s[3] ^ recovered_341_co[2];
  assign recovered_341_co[3] = (recovered_341_s[3] & recovered_341_co[2]) | (~recovered_341_s[3] & recovered_341_di[3]);
  assign {esc_add_ln208_68_reg_7535_reg_7__i_1_n_0_73fe897 ,esc_NLW_add_ln208_68_reg_7535_reg_7__i_1_CO_UNCONNECTED_1e8137c [2:0]} = recovered_341_co;
  assign esc_add_ln208_65_reg_7483_reg_11_f154d09 [7:4] = recovered_341_o;

  // Reconstructed LUT2: esc_add_ln208_71_reg_7587_3__i_2_737a24d
  assign esc_add_ln208_71_reg_7587_3__i_2_n_0_a8dae4e = ((DOADO[3]) ? (~(esc_add_ln208_71_reg_7587_reg_11__0_248299a [3])) : (esc_add_ln208_71_reg_7587_reg_11__0_248299a [3]));

  // Reconstructed LUT2: esc_add_ln208_71_reg_7587_3__i_3_59f8e16
  assign esc_add_ln208_71_reg_7587_3__i_3_n_0_114ee5f = ((DOADO[2]) ? (~(esc_add_ln208_71_reg_7587_reg_11__0_248299a [2])) : (esc_add_ln208_71_reg_7587_reg_11__0_248299a [2]));

  // Reconstructed LUT2: esc_add_ln208_71_reg_7587_3__i_4_6cb592e
  assign esc_add_ln208_71_reg_7587_3__i_4_n_0_be8afe3 = ((DOADO[1]) ? (~(esc_add_ln208_71_reg_7587_reg_11__0_248299a [1])) : (esc_add_ln208_71_reg_7587_reg_11__0_248299a [1]));

  // Reconstructed LUT2: esc_add_ln208_71_reg_7587_3__i_5_218c48f
  assign esc_add_ln208_71_reg_7587_3__i_5_n_0_90fe6d3 = ((DOADO[0]) ? (~(esc_add_ln208_71_reg_7587_reg_11__0_248299a [0])) : (esc_add_ln208_71_reg_7587_reg_11__0_248299a [0]));

  // Reconstructed LUT2: esc_add_ln208_71_reg_7587_7__i_2_cb634a1
  assign esc_add_ln208_71_reg_7587_7__i_2_n_0_7c5afb9 = ((DOADO[7]) ? (~(esc_add_ln208_71_reg_7587_reg_11__0_248299a [7])) : (esc_add_ln208_71_reg_7587_reg_11__0_248299a [7]));

  // Reconstructed LUT2: esc_add_ln208_71_reg_7587_7__i_3_4619daf
  assign esc_add_ln208_71_reg_7587_7__i_3_n_0_1d7135d = ((DOADO[6]) ? (~(esc_add_ln208_71_reg_7587_reg_11__0_248299a [6])) : (esc_add_ln208_71_reg_7587_reg_11__0_248299a [6]));

  // Reconstructed LUT2: esc_add_ln208_71_reg_7587_7__i_4_8adb97a
  assign esc_add_ln208_71_reg_7587_7__i_4_n_0_bd4be42 = ((DOADO[5]) ? (~(esc_add_ln208_71_reg_7587_reg_11__0_248299a [5])) : (esc_add_ln208_71_reg_7587_reg_11__0_248299a [5]));

  // Reconstructed LUT2: esc_add_ln208_71_reg_7587_7__i_5_4d468c6
  assign esc_add_ln208_71_reg_7587_7__i_5_n_0_8c1f839 = ((DOADO[4]) ? (~(esc_add_ln208_71_reg_7587_reg_11__0_248299a [4])) : (esc_add_ln208_71_reg_7587_reg_11__0_248299a [4]));

  // Reconstructed CARRY4: esc_add_ln208_71_reg_7587_reg_11__i_2_b9e13cc
  wire [3:0] recovered_350_co, recovered_350_o, recovered_350_s, recovered_350_di;
  assign recovered_350_s = esc_add_ln208_71_reg_7587_reg_11__0_248299a [11:8];
  assign recovered_350_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_350_ci = ((esc_add_ln208_71_reg_7587_reg_7__i_1_n_0_53cfd7e) !== 1'bz) && (esc_add_ln208_71_reg_7587_reg_7__i_1_n_0_53cfd7e);
  wire recovered_350_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_350_o[0] = recovered_350_s[0] ^ (recovered_350_ci || recovered_350_cy);
  assign recovered_350_co[0] = (recovered_350_s[0] & (recovered_350_ci || recovered_350_cy)) | (~recovered_350_s[0] & recovered_350_di[0]);
  assign recovered_350_o[1] = recovered_350_s[1] ^ recovered_350_co[0];
  assign recovered_350_co[1] = (recovered_350_s[1] & recovered_350_co[0]) | (~recovered_350_s[1] & recovered_350_di[1]);
  assign recovered_350_o[2] = recovered_350_s[2] ^ recovered_350_co[1];
  assign recovered_350_co[2] = (recovered_350_s[2] & recovered_350_co[1]) | (~recovered_350_s[2] & recovered_350_di[2]);
  assign recovered_350_o[3] = recovered_350_s[3] ^ recovered_350_co[2];
  assign recovered_350_co[3] = (recovered_350_s[3] & recovered_350_co[2]) | (~recovered_350_s[3] & recovered_350_di[3]);
  assign esc_add_ln208_68_reg_7535_reg_11_e9aafb9 [11:8] = recovered_350_o;

  // Reconstructed CARRY4: esc_add_ln208_71_reg_7587_reg_3__i_1_f7a97fd
  wire [3:0] recovered_351_co, recovered_351_o, recovered_351_s, recovered_351_di;
  assign recovered_351_s = {esc_add_ln208_71_reg_7587_3__i_2_n_0_a8dae4e ,esc_add_ln208_71_reg_7587_3__i_3_n_0_114ee5f ,esc_add_ln208_71_reg_7587_3__i_4_n_0_be8afe3 ,esc_add_ln208_71_reg_7587_3__i_5_n_0_90fe6d3 };
  assign recovered_351_di = esc_add_ln208_71_reg_7587_reg_11__0_248299a [3:0];
  wire recovered_351_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_351_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_351_o[0] = recovered_351_s[0] ^ (recovered_351_ci || recovered_351_cy);
  assign recovered_351_co[0] = (recovered_351_s[0] & (recovered_351_ci || recovered_351_cy)) | (~recovered_351_s[0] & recovered_351_di[0]);
  assign recovered_351_o[1] = recovered_351_s[1] ^ recovered_351_co[0];
  assign recovered_351_co[1] = (recovered_351_s[1] & recovered_351_co[0]) | (~recovered_351_s[1] & recovered_351_di[1]);
  assign recovered_351_o[2] = recovered_351_s[2] ^ recovered_351_co[1];
  assign recovered_351_co[2] = (recovered_351_s[2] & recovered_351_co[1]) | (~recovered_351_s[2] & recovered_351_di[2]);
  assign recovered_351_o[3] = recovered_351_s[3] ^ recovered_351_co[2];
  assign recovered_351_co[3] = (recovered_351_s[3] & recovered_351_co[2]) | (~recovered_351_s[3] & recovered_351_di[3]);
  assign {esc_add_ln208_71_reg_7587_reg_3__i_1_n_0_f8abe82 ,esc_NLW_add_ln208_71_reg_7587_reg_3__i_1_CO_UNCONNECTED_98283f7 [2:0]} = recovered_351_co;
  assign esc_add_ln208_68_reg_7535_reg_11_e9aafb9 [3:0] = recovered_351_o;

  // Reconstructed CARRY4: esc_add_ln208_71_reg_7587_reg_7__i_1_ddae959
  wire [3:0] recovered_352_co, recovered_352_o, recovered_352_s, recovered_352_di;
  assign recovered_352_s = {esc_add_ln208_71_reg_7587_7__i_2_n_0_7c5afb9 ,esc_add_ln208_71_reg_7587_7__i_3_n_0_1d7135d ,esc_add_ln208_71_reg_7587_7__i_4_n_0_bd4be42 ,esc_add_ln208_71_reg_7587_7__i_5_n_0_8c1f839 };
  assign recovered_352_di = esc_add_ln208_71_reg_7587_reg_11__0_248299a [7:4];
  wire recovered_352_ci = ((esc_add_ln208_71_reg_7587_reg_3__i_1_n_0_f8abe82) !== 1'bz) && (esc_add_ln208_71_reg_7587_reg_3__i_1_n_0_f8abe82);
  wire recovered_352_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_352_o[0] = recovered_352_s[0] ^ (recovered_352_ci || recovered_352_cy);
  assign recovered_352_co[0] = (recovered_352_s[0] & (recovered_352_ci || recovered_352_cy)) | (~recovered_352_s[0] & recovered_352_di[0]);
  assign recovered_352_o[1] = recovered_352_s[1] ^ recovered_352_co[0];
  assign recovered_352_co[1] = (recovered_352_s[1] & recovered_352_co[0]) | (~recovered_352_s[1] & recovered_352_di[1]);
  assign recovered_352_o[2] = recovered_352_s[2] ^ recovered_352_co[1];
  assign recovered_352_co[2] = (recovered_352_s[2] & recovered_352_co[1]) | (~recovered_352_s[2] & recovered_352_di[2]);
  assign recovered_352_o[3] = recovered_352_s[3] ^ recovered_352_co[2];
  assign recovered_352_co[3] = (recovered_352_s[3] & recovered_352_co[2]) | (~recovered_352_s[3] & recovered_352_di[3]);
  assign {esc_add_ln208_71_reg_7587_reg_7__i_1_n_0_53cfd7e ,esc_NLW_add_ln208_71_reg_7587_reg_7__i_1_CO_UNCONNECTED_cf5fbb8 [2:0]} = recovered_352_co;
  assign esc_add_ln208_68_reg_7535_reg_11_e9aafb9 [7:4] = recovered_352_o;

  // Reconstructed LUT2: esc_add_ln208_74_reg_7649_3__i_2_0cba617
  assign esc_add_ln208_74_reg_7649_3__i_2_n_0_c5286e0 = ((DOADO[3]) ? (~(esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [3])) : (esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [3]));

  // Reconstructed LUT2: esc_add_ln208_74_reg_7649_3__i_3_7a22a6e
  assign esc_add_ln208_74_reg_7649_3__i_3_n_0_8926a2f = ((DOADO[2]) ? (~(esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [2])) : (esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [2]));

  // Reconstructed LUT2: esc_add_ln208_74_reg_7649_3__i_4_e6c8375
  assign esc_add_ln208_74_reg_7649_3__i_4_n_0_e414c85 = ((DOADO[1]) ? (~(esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [1])) : (esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [1]));

  // Reconstructed LUT2: esc_add_ln208_74_reg_7649_3__i_5_d24e73c
  assign esc_add_ln208_74_reg_7649_3__i_5_n_0_35113bd = ((DOADO[0]) ? (~(esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [0])) : (esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [0]));

  // Reconstructed LUT2: esc_add_ln208_74_reg_7649_7__i_2_bb89da2
  assign esc_add_ln208_74_reg_7649_7__i_2_n_0_679129b = ((DOADO[7]) ? (~(esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [7])) : (esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [7]));

  // Reconstructed LUT2: esc_add_ln208_74_reg_7649_7__i_3_552f866
  assign esc_add_ln208_74_reg_7649_7__i_3_n_0_569753f = ((DOADO[6]) ? (~(esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [6])) : (esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [6]));

  // Reconstructed LUT2: esc_add_ln208_74_reg_7649_7__i_4_4b98fdc
  assign esc_add_ln208_74_reg_7649_7__i_4_n_0_baa5a7d = ((DOADO[5]) ? (~(esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [5])) : (esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [5]));

  // Reconstructed LUT2: esc_add_ln208_74_reg_7649_7__i_5_e64a3af
  assign esc_add_ln208_74_reg_7649_7__i_5_n_0_e0c49e0 = ((DOADO[4]) ? (~(esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [4])) : (esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [4]));

  // Reconstructed CARRY4: esc_add_ln208_74_reg_7649_reg_11__i_2_11c03e3
  wire [3:0] recovered_361_co, recovered_361_o, recovered_361_s, recovered_361_di;
  assign recovered_361_s = esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [11:8];
  assign recovered_361_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_361_ci = ((esc_add_ln208_74_reg_7649_reg_7__i_1_n_0_2c26d94) !== 1'bz) && (esc_add_ln208_74_reg_7649_reg_7__i_1_n_0_2c26d94);
  wire recovered_361_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_361_o[0] = recovered_361_s[0] ^ (recovered_361_ci || recovered_361_cy);
  assign recovered_361_co[0] = (recovered_361_s[0] & (recovered_361_ci || recovered_361_cy)) | (~recovered_361_s[0] & recovered_361_di[0]);
  assign recovered_361_o[1] = recovered_361_s[1] ^ recovered_361_co[0];
  assign recovered_361_co[1] = (recovered_361_s[1] & recovered_361_co[0]) | (~recovered_361_s[1] & recovered_361_di[1]);
  assign recovered_361_o[2] = recovered_361_s[2] ^ recovered_361_co[1];
  assign recovered_361_co[2] = (recovered_361_s[2] & recovered_361_co[1]) | (~recovered_361_s[2] & recovered_361_di[2]);
  assign recovered_361_o[3] = recovered_361_s[3] ^ recovered_361_co[2];
  assign recovered_361_co[3] = (recovered_361_s[3] & recovered_361_co[2]) | (~recovered_361_s[3] & recovered_361_di[3]);
  assign esc_add_ln208_71_reg_7587_reg_11_d2760f7 [11:8] = recovered_361_o;

  // Reconstructed CARRY4: esc_add_ln208_74_reg_7649_reg_3__i_1_1457202
  wire [3:0] recovered_362_co, recovered_362_o, recovered_362_s, recovered_362_di;
  assign recovered_362_s = {esc_add_ln208_74_reg_7649_3__i_2_n_0_c5286e0 ,esc_add_ln208_74_reg_7649_3__i_3_n_0_8926a2f ,esc_add_ln208_74_reg_7649_3__i_4_n_0_e414c85 ,esc_add_ln208_74_reg_7649_3__i_5_n_0_35113bd };
  assign recovered_362_di = esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [3:0];
  wire recovered_362_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_362_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_362_o[0] = recovered_362_s[0] ^ (recovered_362_ci || recovered_362_cy);
  assign recovered_362_co[0] = (recovered_362_s[0] & (recovered_362_ci || recovered_362_cy)) | (~recovered_362_s[0] & recovered_362_di[0]);
  assign recovered_362_o[1] = recovered_362_s[1] ^ recovered_362_co[0];
  assign recovered_362_co[1] = (recovered_362_s[1] & recovered_362_co[0]) | (~recovered_362_s[1] & recovered_362_di[1]);
  assign recovered_362_o[2] = recovered_362_s[2] ^ recovered_362_co[1];
  assign recovered_362_co[2] = (recovered_362_s[2] & recovered_362_co[1]) | (~recovered_362_s[2] & recovered_362_di[2]);
  assign recovered_362_o[3] = recovered_362_s[3] ^ recovered_362_co[2];
  assign recovered_362_co[3] = (recovered_362_s[3] & recovered_362_co[2]) | (~recovered_362_s[3] & recovered_362_di[3]);
  assign {esc_add_ln208_74_reg_7649_reg_3__i_1_n_0_0cff9ec ,esc_NLW_add_ln208_74_reg_7649_reg_3__i_1_CO_UNCONNECTED_0c7d911 [2:0]} = recovered_362_co;
  assign esc_add_ln208_71_reg_7587_reg_11_d2760f7 [3:0] = recovered_362_o;

  // Reconstructed CARRY4: esc_add_ln208_74_reg_7649_reg_7__i_1_7b019e5
  wire [3:0] recovered_363_co, recovered_363_o, recovered_363_s, recovered_363_di;
  assign recovered_363_s = {esc_add_ln208_74_reg_7649_7__i_2_n_0_679129b ,esc_add_ln208_74_reg_7649_7__i_3_n_0_569753f ,esc_add_ln208_74_reg_7649_7__i_4_n_0_baa5a7d ,esc_add_ln208_74_reg_7649_7__i_5_n_0_e0c49e0 };
  assign recovered_363_di = esc_add_ln208_74_reg_7649_reg_11__0_70c8b9e [7:4];
  wire recovered_363_ci = ((esc_add_ln208_74_reg_7649_reg_3__i_1_n_0_0cff9ec) !== 1'bz) && (esc_add_ln208_74_reg_7649_reg_3__i_1_n_0_0cff9ec);
  wire recovered_363_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_363_o[0] = recovered_363_s[0] ^ (recovered_363_ci || recovered_363_cy);
  assign recovered_363_co[0] = (recovered_363_s[0] & (recovered_363_ci || recovered_363_cy)) | (~recovered_363_s[0] & recovered_363_di[0]);
  assign recovered_363_o[1] = recovered_363_s[1] ^ recovered_363_co[0];
  assign recovered_363_co[1] = (recovered_363_s[1] & recovered_363_co[0]) | (~recovered_363_s[1] & recovered_363_di[1]);
  assign recovered_363_o[2] = recovered_363_s[2] ^ recovered_363_co[1];
  assign recovered_363_co[2] = (recovered_363_s[2] & recovered_363_co[1]) | (~recovered_363_s[2] & recovered_363_di[2]);
  assign recovered_363_o[3] = recovered_363_s[3] ^ recovered_363_co[2];
  assign recovered_363_co[3] = (recovered_363_s[3] & recovered_363_co[2]) | (~recovered_363_s[3] & recovered_363_di[3]);
  assign {esc_add_ln208_74_reg_7649_reg_7__i_1_n_0_2c26d94 ,esc_NLW_add_ln208_74_reg_7649_reg_7__i_1_CO_UNCONNECTED_3a0e76c [2:0]} = recovered_363_co;
  assign esc_add_ln208_71_reg_7587_reg_11_d2760f7 [7:4] = recovered_363_o;

  // Reconstructed LUT2: esc_add_ln208_77_reg_7711_3__i_2_e97001a
  assign esc_add_ln208_77_reg_7711_3__i_2_n_0_6614f09 = ((DOADO[3]) ? (~(esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [3])) : (esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [3]));

  // Reconstructed LUT2: esc_add_ln208_77_reg_7711_3__i_3_3197198
  assign esc_add_ln208_77_reg_7711_3__i_3_n_0_c23a92a = ((DOADO[2]) ? (~(esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [2])) : (esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [2]));

  // Reconstructed LUT2: esc_add_ln208_77_reg_7711_3__i_4_e0d39ed
  assign esc_add_ln208_77_reg_7711_3__i_4_n_0_58ea1da = ((DOADO[1]) ? (~(esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [1])) : (esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [1]));

  // Reconstructed LUT2: esc_add_ln208_77_reg_7711_3__i_5_462546f
  assign esc_add_ln208_77_reg_7711_3__i_5_n_0_65dffee = ((DOADO[0]) ? (~(esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [0])) : (esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [0]));

  // Reconstructed LUT2: esc_add_ln208_77_reg_7711_7__i_2_bab5658
  assign esc_add_ln208_77_reg_7711_7__i_2_n_0_c7c80ab = ((DOADO[7]) ? (~(esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [7])) : (esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [7]));

  // Reconstructed LUT2: esc_add_ln208_77_reg_7711_7__i_3_73a4f28
  assign esc_add_ln208_77_reg_7711_7__i_3_n_0_ccff718 = ((DOADO[6]) ? (~(esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [6])) : (esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [6]));

  // Reconstructed LUT2: esc_add_ln208_77_reg_7711_7__i_4_aaf6e8c
  assign esc_add_ln208_77_reg_7711_7__i_4_n_0_6b5d261 = ((DOADO[5]) ? (~(esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [5])) : (esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [5]));

  // Reconstructed LUT2: esc_add_ln208_77_reg_7711_7__i_5_a2a0fdf
  assign esc_add_ln208_77_reg_7711_7__i_5_n_0_5b2447b = ((DOADO[4]) ? (~(esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [4])) : (esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [4]));

  // Reconstructed CARRY4: esc_add_ln208_77_reg_7711_reg_11__i_2_6eee654
  wire [3:0] recovered_372_co, recovered_372_o, recovered_372_s, recovered_372_di;
  assign recovered_372_s = esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [11:8];
  assign recovered_372_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_372_ci = ((esc_add_ln208_77_reg_7711_reg_7__i_1_n_0_3d5ca1f) !== 1'bz) && (esc_add_ln208_77_reg_7711_reg_7__i_1_n_0_3d5ca1f);
  wire recovered_372_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_372_o[0] = recovered_372_s[0] ^ (recovered_372_ci || recovered_372_cy);
  assign recovered_372_co[0] = (recovered_372_s[0] & (recovered_372_ci || recovered_372_cy)) | (~recovered_372_s[0] & recovered_372_di[0]);
  assign recovered_372_o[1] = recovered_372_s[1] ^ recovered_372_co[0];
  assign recovered_372_co[1] = (recovered_372_s[1] & recovered_372_co[0]) | (~recovered_372_s[1] & recovered_372_di[1]);
  assign recovered_372_o[2] = recovered_372_s[2] ^ recovered_372_co[1];
  assign recovered_372_co[2] = (recovered_372_s[2] & recovered_372_co[1]) | (~recovered_372_s[2] & recovered_372_di[2]);
  assign recovered_372_o[3] = recovered_372_s[3] ^ recovered_372_co[2];
  assign recovered_372_co[3] = (recovered_372_s[3] & recovered_372_co[2]) | (~recovered_372_s[3] & recovered_372_di[3]);
  assign esc_add_ln208_74_reg_7649_reg_11_23515cd [11:8] = recovered_372_o;

  // Reconstructed CARRY4: esc_add_ln208_77_reg_7711_reg_3__i_1_829be33
  wire [3:0] recovered_373_co, recovered_373_o, recovered_373_s, recovered_373_di;
  assign recovered_373_s = {esc_add_ln208_77_reg_7711_3__i_2_n_0_6614f09 ,esc_add_ln208_77_reg_7711_3__i_3_n_0_c23a92a ,esc_add_ln208_77_reg_7711_3__i_4_n_0_58ea1da ,esc_add_ln208_77_reg_7711_3__i_5_n_0_65dffee };
  assign recovered_373_di = esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [3:0];
  wire recovered_373_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_373_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_373_o[0] = recovered_373_s[0] ^ (recovered_373_ci || recovered_373_cy);
  assign recovered_373_co[0] = (recovered_373_s[0] & (recovered_373_ci || recovered_373_cy)) | (~recovered_373_s[0] & recovered_373_di[0]);
  assign recovered_373_o[1] = recovered_373_s[1] ^ recovered_373_co[0];
  assign recovered_373_co[1] = (recovered_373_s[1] & recovered_373_co[0]) | (~recovered_373_s[1] & recovered_373_di[1]);
  assign recovered_373_o[2] = recovered_373_s[2] ^ recovered_373_co[1];
  assign recovered_373_co[2] = (recovered_373_s[2] & recovered_373_co[1]) | (~recovered_373_s[2] & recovered_373_di[2]);
  assign recovered_373_o[3] = recovered_373_s[3] ^ recovered_373_co[2];
  assign recovered_373_co[3] = (recovered_373_s[3] & recovered_373_co[2]) | (~recovered_373_s[3] & recovered_373_di[3]);
  assign {esc_add_ln208_77_reg_7711_reg_3__i_1_n_0_1a20c18 ,esc_NLW_add_ln208_77_reg_7711_reg_3__i_1_CO_UNCONNECTED_ebae6ed [2:0]} = recovered_373_co;
  assign esc_add_ln208_74_reg_7649_reg_11_23515cd [3:0] = recovered_373_o;

  // Reconstructed CARRY4: esc_add_ln208_77_reg_7711_reg_7__i_1_cb409fb
  wire [3:0] recovered_374_co, recovered_374_o, recovered_374_s, recovered_374_di;
  assign recovered_374_s = {esc_add_ln208_77_reg_7711_7__i_2_n_0_c7c80ab ,esc_add_ln208_77_reg_7711_7__i_3_n_0_ccff718 ,esc_add_ln208_77_reg_7711_7__i_4_n_0_6b5d261 ,esc_add_ln208_77_reg_7711_7__i_5_n_0_5b2447b };
  assign recovered_374_di = esc_add_ln208_77_reg_7711_reg_11__0_8dbdeb4 [7:4];
  wire recovered_374_ci = ((esc_add_ln208_77_reg_7711_reg_3__i_1_n_0_1a20c18) !== 1'bz) && (esc_add_ln208_77_reg_7711_reg_3__i_1_n_0_1a20c18);
  wire recovered_374_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_374_o[0] = recovered_374_s[0] ^ (recovered_374_ci || recovered_374_cy);
  assign recovered_374_co[0] = (recovered_374_s[0] & (recovered_374_ci || recovered_374_cy)) | (~recovered_374_s[0] & recovered_374_di[0]);
  assign recovered_374_o[1] = recovered_374_s[1] ^ recovered_374_co[0];
  assign recovered_374_co[1] = (recovered_374_s[1] & recovered_374_co[0]) | (~recovered_374_s[1] & recovered_374_di[1]);
  assign recovered_374_o[2] = recovered_374_s[2] ^ recovered_374_co[1];
  assign recovered_374_co[2] = (recovered_374_s[2] & recovered_374_co[1]) | (~recovered_374_s[2] & recovered_374_di[2]);
  assign recovered_374_o[3] = recovered_374_s[3] ^ recovered_374_co[2];
  assign recovered_374_co[3] = (recovered_374_s[3] & recovered_374_co[2]) | (~recovered_374_s[3] & recovered_374_di[3]);
  assign {esc_add_ln208_77_reg_7711_reg_7__i_1_n_0_3d5ca1f ,esc_NLW_add_ln208_77_reg_7711_reg_7__i_1_CO_UNCONNECTED_988ee92 [2:0]} = recovered_374_co;
  assign esc_add_ln208_74_reg_7649_reg_11_23515cd [7:4] = recovered_374_o;

  // Reconstructed LUT2: esc_add_ln208_80_reg_7773_3__i_2_617137a
  assign esc_add_ln208_80_reg_7773_3__i_2_n_0_315c110 = ((DOADO[3]) ? (~(esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [3])) : (esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [3]));

  // Reconstructed LUT2: esc_add_ln208_80_reg_7773_3__i_3_13785e0
  assign esc_add_ln208_80_reg_7773_3__i_3_n_0_ec62b69 = ((DOADO[2]) ? (~(esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [2])) : (esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [2]));

  // Reconstructed LUT2: esc_add_ln208_80_reg_7773_3__i_4_5d3b0b2
  assign esc_add_ln208_80_reg_7773_3__i_4_n_0_3a504e0 = ((DOADO[1]) ? (~(esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [1])) : (esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [1]));

  // Reconstructed LUT2: esc_add_ln208_80_reg_7773_3__i_5_6cd12f4
  assign esc_add_ln208_80_reg_7773_3__i_5_n_0_ff5e715 = ((DOADO[0]) ? (~(esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [0])) : (esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [0]));

  // Reconstructed LUT2: esc_add_ln208_80_reg_7773_7__i_2_ee8f838
  assign esc_add_ln208_80_reg_7773_7__i_2_n_0_94f5558 = ((DOADO[7]) ? (~(esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [7])) : (esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [7]));

  // Reconstructed LUT2: esc_add_ln208_80_reg_7773_7__i_3_f1c3bce
  assign esc_add_ln208_80_reg_7773_7__i_3_n_0_0371ed5 = ((DOADO[6]) ? (~(esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [6])) : (esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [6]));

  // Reconstructed LUT2: esc_add_ln208_80_reg_7773_7__i_4_81c43ae
  assign esc_add_ln208_80_reg_7773_7__i_4_n_0_9020c7a = ((DOADO[5]) ? (~(esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [5])) : (esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [5]));

  // Reconstructed LUT2: esc_add_ln208_80_reg_7773_7__i_5_52459df
  assign esc_add_ln208_80_reg_7773_7__i_5_n_0_5a73682 = ((DOADO[4]) ? (~(esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [4])) : (esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [4]));

  // Reconstructed CARRY4: esc_add_ln208_80_reg_7773_reg_11__i_2_53726bb
  wire [3:0] recovered_383_co, recovered_383_o, recovered_383_s, recovered_383_di;
  assign recovered_383_s = esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [11:8];
  assign recovered_383_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_383_ci = ((esc_add_ln208_80_reg_7773_reg_7__i_1_n_0_6a7939e) !== 1'bz) && (esc_add_ln208_80_reg_7773_reg_7__i_1_n_0_6a7939e);
  wire recovered_383_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_383_o[0] = recovered_383_s[0] ^ (recovered_383_ci || recovered_383_cy);
  assign recovered_383_co[0] = (recovered_383_s[0] & (recovered_383_ci || recovered_383_cy)) | (~recovered_383_s[0] & recovered_383_di[0]);
  assign recovered_383_o[1] = recovered_383_s[1] ^ recovered_383_co[0];
  assign recovered_383_co[1] = (recovered_383_s[1] & recovered_383_co[0]) | (~recovered_383_s[1] & recovered_383_di[1]);
  assign recovered_383_o[2] = recovered_383_s[2] ^ recovered_383_co[1];
  assign recovered_383_co[2] = (recovered_383_s[2] & recovered_383_co[1]) | (~recovered_383_s[2] & recovered_383_di[2]);
  assign recovered_383_o[3] = recovered_383_s[3] ^ recovered_383_co[2];
  assign recovered_383_co[3] = (recovered_383_s[3] & recovered_383_co[2]) | (~recovered_383_s[3] & recovered_383_di[3]);
  assign esc_add_ln208_77_reg_7711_reg_11_bc8d80b [11:8] = recovered_383_o;

  // Reconstructed CARRY4: esc_add_ln208_80_reg_7773_reg_3__i_1_1652e7b
  wire [3:0] recovered_384_co, recovered_384_o, recovered_384_s, recovered_384_di;
  assign recovered_384_s = {esc_add_ln208_80_reg_7773_3__i_2_n_0_315c110 ,esc_add_ln208_80_reg_7773_3__i_3_n_0_ec62b69 ,esc_add_ln208_80_reg_7773_3__i_4_n_0_3a504e0 ,esc_add_ln208_80_reg_7773_3__i_5_n_0_ff5e715 };
  assign recovered_384_di = esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [3:0];
  wire recovered_384_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_384_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_384_o[0] = recovered_384_s[0] ^ (recovered_384_ci || recovered_384_cy);
  assign recovered_384_co[0] = (recovered_384_s[0] & (recovered_384_ci || recovered_384_cy)) | (~recovered_384_s[0] & recovered_384_di[0]);
  assign recovered_384_o[1] = recovered_384_s[1] ^ recovered_384_co[0];
  assign recovered_384_co[1] = (recovered_384_s[1] & recovered_384_co[0]) | (~recovered_384_s[1] & recovered_384_di[1]);
  assign recovered_384_o[2] = recovered_384_s[2] ^ recovered_384_co[1];
  assign recovered_384_co[2] = (recovered_384_s[2] & recovered_384_co[1]) | (~recovered_384_s[2] & recovered_384_di[2]);
  assign recovered_384_o[3] = recovered_384_s[3] ^ recovered_384_co[2];
  assign recovered_384_co[3] = (recovered_384_s[3] & recovered_384_co[2]) | (~recovered_384_s[3] & recovered_384_di[3]);
  assign {esc_add_ln208_80_reg_7773_reg_3__i_1_n_0_1c656c6 ,esc_NLW_add_ln208_80_reg_7773_reg_3__i_1_CO_UNCONNECTED_d853d52 [2:0]} = recovered_384_co;
  assign esc_add_ln208_77_reg_7711_reg_11_bc8d80b [3:0] = recovered_384_o;

  // Reconstructed CARRY4: esc_add_ln208_80_reg_7773_reg_7__i_1_a7de97b
  wire [3:0] recovered_385_co, recovered_385_o, recovered_385_s, recovered_385_di;
  assign recovered_385_s = {esc_add_ln208_80_reg_7773_7__i_2_n_0_94f5558 ,esc_add_ln208_80_reg_7773_7__i_3_n_0_0371ed5 ,esc_add_ln208_80_reg_7773_7__i_4_n_0_9020c7a ,esc_add_ln208_80_reg_7773_7__i_5_n_0_5a73682 };
  assign recovered_385_di = esc_add_ln208_80_reg_7773_reg_11__0_d04cfe5 [7:4];
  wire recovered_385_ci = ((esc_add_ln208_80_reg_7773_reg_3__i_1_n_0_1c656c6) !== 1'bz) && (esc_add_ln208_80_reg_7773_reg_3__i_1_n_0_1c656c6);
  wire recovered_385_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_385_o[0] = recovered_385_s[0] ^ (recovered_385_ci || recovered_385_cy);
  assign recovered_385_co[0] = (recovered_385_s[0] & (recovered_385_ci || recovered_385_cy)) | (~recovered_385_s[0] & recovered_385_di[0]);
  assign recovered_385_o[1] = recovered_385_s[1] ^ recovered_385_co[0];
  assign recovered_385_co[1] = (recovered_385_s[1] & recovered_385_co[0]) | (~recovered_385_s[1] & recovered_385_di[1]);
  assign recovered_385_o[2] = recovered_385_s[2] ^ recovered_385_co[1];
  assign recovered_385_co[2] = (recovered_385_s[2] & recovered_385_co[1]) | (~recovered_385_s[2] & recovered_385_di[2]);
  assign recovered_385_o[3] = recovered_385_s[3] ^ recovered_385_co[2];
  assign recovered_385_co[3] = (recovered_385_s[3] & recovered_385_co[2]) | (~recovered_385_s[3] & recovered_385_di[3]);
  assign {esc_add_ln208_80_reg_7773_reg_7__i_1_n_0_6a7939e ,esc_NLW_add_ln208_80_reg_7773_reg_7__i_1_CO_UNCONNECTED_be00f2c [2:0]} = recovered_385_co;
  assign esc_add_ln208_77_reg_7711_reg_11_bc8d80b [7:4] = recovered_385_o;

  // Reconstructed LUT2: esc_add_ln208_83_reg_7835_3__i_2_cc7f907
  assign esc_add_ln208_83_reg_7835_3__i_2_n_0_2c30e02 = ((DOADO[3]) ? (~(esc_add_ln208_83_reg_7835_reg_11__0_741884e [3])) : (esc_add_ln208_83_reg_7835_reg_11__0_741884e [3]));

  // Reconstructed LUT2: esc_add_ln208_83_reg_7835_3__i_3_4bf4d5b
  assign esc_add_ln208_83_reg_7835_3__i_3_n_0_a2705c8 = ((DOADO[2]) ? (~(esc_add_ln208_83_reg_7835_reg_11__0_741884e [2])) : (esc_add_ln208_83_reg_7835_reg_11__0_741884e [2]));

  // Reconstructed LUT2: esc_add_ln208_83_reg_7835_3__i_4_e5def12
  assign esc_add_ln208_83_reg_7835_3__i_4_n_0_3fd20a9 = ((DOADO[1]) ? (~(esc_add_ln208_83_reg_7835_reg_11__0_741884e [1])) : (esc_add_ln208_83_reg_7835_reg_11__0_741884e [1]));

  // Reconstructed LUT2: esc_add_ln208_83_reg_7835_3__i_5_2a12eeb
  assign esc_add_ln208_83_reg_7835_3__i_5_n_0_df4e5dd = ((DOADO[0]) ? (~(esc_add_ln208_83_reg_7835_reg_11__0_741884e [0])) : (esc_add_ln208_83_reg_7835_reg_11__0_741884e [0]));

  // Reconstructed LUT2: esc_add_ln208_83_reg_7835_7__i_2_5b5c567
  assign esc_add_ln208_83_reg_7835_7__i_2_n_0_db5cbb8 = ((DOADO[7]) ? (~(esc_add_ln208_83_reg_7835_reg_11__0_741884e [7])) : (esc_add_ln208_83_reg_7835_reg_11__0_741884e [7]));

  // Reconstructed LUT2: esc_add_ln208_83_reg_7835_7__i_3_063f0b8
  assign esc_add_ln208_83_reg_7835_7__i_3_n_0_0eef1c3 = ((DOADO[6]) ? (~(esc_add_ln208_83_reg_7835_reg_11__0_741884e [6])) : (esc_add_ln208_83_reg_7835_reg_11__0_741884e [6]));

  // Reconstructed LUT2: esc_add_ln208_83_reg_7835_7__i_4_2c1153d
  assign esc_add_ln208_83_reg_7835_7__i_4_n_0_94198d9 = ((DOADO[5]) ? (~(esc_add_ln208_83_reg_7835_reg_11__0_741884e [5])) : (esc_add_ln208_83_reg_7835_reg_11__0_741884e [5]));

  // Reconstructed LUT2: esc_add_ln208_83_reg_7835_7__i_5_8a9ce6b
  assign esc_add_ln208_83_reg_7835_7__i_5_n_0_8ac1322 = ((DOADO[4]) ? (~(esc_add_ln208_83_reg_7835_reg_11__0_741884e [4])) : (esc_add_ln208_83_reg_7835_reg_11__0_741884e [4]));

  // Reconstructed CARRY4: esc_add_ln208_83_reg_7835_reg_11__i_2_196add2
  wire [3:0] recovered_394_co, recovered_394_o, recovered_394_s, recovered_394_di;
  assign recovered_394_s = esc_add_ln208_83_reg_7835_reg_11__0_741884e [11:8];
  assign recovered_394_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_394_ci = ((esc_add_ln208_83_reg_7835_reg_7__i_1_n_0_d78e7fe) !== 1'bz) && (esc_add_ln208_83_reg_7835_reg_7__i_1_n_0_d78e7fe);
  wire recovered_394_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_394_o[0] = recovered_394_s[0] ^ (recovered_394_ci || recovered_394_cy);
  assign recovered_394_co[0] = (recovered_394_s[0] & (recovered_394_ci || recovered_394_cy)) | (~recovered_394_s[0] & recovered_394_di[0]);
  assign recovered_394_o[1] = recovered_394_s[1] ^ recovered_394_co[0];
  assign recovered_394_co[1] = (recovered_394_s[1] & recovered_394_co[0]) | (~recovered_394_s[1] & recovered_394_di[1]);
  assign recovered_394_o[2] = recovered_394_s[2] ^ recovered_394_co[1];
  assign recovered_394_co[2] = (recovered_394_s[2] & recovered_394_co[1]) | (~recovered_394_s[2] & recovered_394_di[2]);
  assign recovered_394_o[3] = recovered_394_s[3] ^ recovered_394_co[2];
  assign recovered_394_co[3] = (recovered_394_s[3] & recovered_394_co[2]) | (~recovered_394_s[3] & recovered_394_di[3]);
  assign esc_add_ln208_80_reg_7773_reg_11_d71fa1b [11:8] = recovered_394_o;

  // Reconstructed CARRY4: esc_add_ln208_83_reg_7835_reg_3__i_1_2d2562b
  wire [3:0] recovered_395_co, recovered_395_o, recovered_395_s, recovered_395_di;
  assign recovered_395_s = {esc_add_ln208_83_reg_7835_3__i_2_n_0_2c30e02 ,esc_add_ln208_83_reg_7835_3__i_3_n_0_a2705c8 ,esc_add_ln208_83_reg_7835_3__i_4_n_0_3fd20a9 ,esc_add_ln208_83_reg_7835_3__i_5_n_0_df4e5dd };
  assign recovered_395_di = esc_add_ln208_83_reg_7835_reg_11__0_741884e [3:0];
  wire recovered_395_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_395_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_395_o[0] = recovered_395_s[0] ^ (recovered_395_ci || recovered_395_cy);
  assign recovered_395_co[0] = (recovered_395_s[0] & (recovered_395_ci || recovered_395_cy)) | (~recovered_395_s[0] & recovered_395_di[0]);
  assign recovered_395_o[1] = recovered_395_s[1] ^ recovered_395_co[0];
  assign recovered_395_co[1] = (recovered_395_s[1] & recovered_395_co[0]) | (~recovered_395_s[1] & recovered_395_di[1]);
  assign recovered_395_o[2] = recovered_395_s[2] ^ recovered_395_co[1];
  assign recovered_395_co[2] = (recovered_395_s[2] & recovered_395_co[1]) | (~recovered_395_s[2] & recovered_395_di[2]);
  assign recovered_395_o[3] = recovered_395_s[3] ^ recovered_395_co[2];
  assign recovered_395_co[3] = (recovered_395_s[3] & recovered_395_co[2]) | (~recovered_395_s[3] & recovered_395_di[3]);
  assign {esc_add_ln208_83_reg_7835_reg_3__i_1_n_0_b982185 ,esc_NLW_add_ln208_83_reg_7835_reg_3__i_1_CO_UNCONNECTED_f3052ac [2:0]} = recovered_395_co;
  assign esc_add_ln208_80_reg_7773_reg_11_d71fa1b [3:0] = recovered_395_o;

  // Reconstructed CARRY4: esc_add_ln208_83_reg_7835_reg_7__i_1_5ea3e09
  wire [3:0] recovered_396_co, recovered_396_o, recovered_396_s, recovered_396_di;
  assign recovered_396_s = {esc_add_ln208_83_reg_7835_7__i_2_n_0_db5cbb8 ,esc_add_ln208_83_reg_7835_7__i_3_n_0_0eef1c3 ,esc_add_ln208_83_reg_7835_7__i_4_n_0_94198d9 ,esc_add_ln208_83_reg_7835_7__i_5_n_0_8ac1322 };
  assign recovered_396_di = esc_add_ln208_83_reg_7835_reg_11__0_741884e [7:4];
  wire recovered_396_ci = ((esc_add_ln208_83_reg_7835_reg_3__i_1_n_0_b982185) !== 1'bz) && (esc_add_ln208_83_reg_7835_reg_3__i_1_n_0_b982185);
  wire recovered_396_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_396_o[0] = recovered_396_s[0] ^ (recovered_396_ci || recovered_396_cy);
  assign recovered_396_co[0] = (recovered_396_s[0] & (recovered_396_ci || recovered_396_cy)) | (~recovered_396_s[0] & recovered_396_di[0]);
  assign recovered_396_o[1] = recovered_396_s[1] ^ recovered_396_co[0];
  assign recovered_396_co[1] = (recovered_396_s[1] & recovered_396_co[0]) | (~recovered_396_s[1] & recovered_396_di[1]);
  assign recovered_396_o[2] = recovered_396_s[2] ^ recovered_396_co[1];
  assign recovered_396_co[2] = (recovered_396_s[2] & recovered_396_co[1]) | (~recovered_396_s[2] & recovered_396_di[2]);
  assign recovered_396_o[3] = recovered_396_s[3] ^ recovered_396_co[2];
  assign recovered_396_co[3] = (recovered_396_s[3] & recovered_396_co[2]) | (~recovered_396_s[3] & recovered_396_di[3]);
  assign {esc_add_ln208_83_reg_7835_reg_7__i_1_n_0_d78e7fe ,esc_NLW_add_ln208_83_reg_7835_reg_7__i_1_CO_UNCONNECTED_3fcc446 [2:0]} = recovered_396_co;
  assign esc_add_ln208_80_reg_7773_reg_11_d71fa1b [7:4] = recovered_396_o;

  // Reconstructed LUT2: esc_add_ln208_86_reg_7897_3__i_2_be4f9f5
  assign esc_add_ln208_86_reg_7897_3__i_2_n_0_363c320 = ((DOADO[3]) ? (~(esc_add_ln208_86_reg_7897_reg_11_897ebea [3])) : (esc_add_ln208_86_reg_7897_reg_11_897ebea [3]));

  // Reconstructed LUT2: esc_add_ln208_86_reg_7897_3__i_3_8f57262
  assign esc_add_ln208_86_reg_7897_3__i_3_n_0_8929e1f = ((DOADO[2]) ? (~(esc_add_ln208_86_reg_7897_reg_11_897ebea [2])) : (esc_add_ln208_86_reg_7897_reg_11_897ebea [2]));

  // Reconstructed LUT2: esc_add_ln208_86_reg_7897_3__i_4_21b64ff
  assign esc_add_ln208_86_reg_7897_3__i_4_n_0_1e9e4c1 = ((DOADO[1]) ? (~(esc_add_ln208_86_reg_7897_reg_11_897ebea [1])) : (esc_add_ln208_86_reg_7897_reg_11_897ebea [1]));

  // Reconstructed LUT2: esc_add_ln208_86_reg_7897_3__i_5_3c5b952
  assign esc_add_ln208_86_reg_7897_3__i_5_n_0_1cda033 = ((DOADO[0]) ? (~(esc_add_ln208_86_reg_7897_reg_11_897ebea [0])) : (esc_add_ln208_86_reg_7897_reg_11_897ebea [0]));

  // Reconstructed LUT2: esc_add_ln208_86_reg_7897_7__i_2_bdabab2
  assign esc_add_ln208_86_reg_7897_7__i_2_n_0_4a7ddc2 = ((DOADO[7]) ? (~(esc_add_ln208_86_reg_7897_reg_11_897ebea [7])) : (esc_add_ln208_86_reg_7897_reg_11_897ebea [7]));

  // Reconstructed LUT2: esc_add_ln208_86_reg_7897_7__i_3_52420a1
  assign esc_add_ln208_86_reg_7897_7__i_3_n_0_dcb5d81 = ((DOADO[6]) ? (~(esc_add_ln208_86_reg_7897_reg_11_897ebea [6])) : (esc_add_ln208_86_reg_7897_reg_11_897ebea [6]));

  // Reconstructed LUT2: esc_add_ln208_86_reg_7897_7__i_4_7ed0f2d
  assign esc_add_ln208_86_reg_7897_7__i_4_n_0_d7d3b1b = ((DOADO[5]) ? (~(esc_add_ln208_86_reg_7897_reg_11_897ebea [5])) : (esc_add_ln208_86_reg_7897_reg_11_897ebea [5]));

  // Reconstructed LUT2: esc_add_ln208_86_reg_7897_7__i_5_8014e1f
  assign esc_add_ln208_86_reg_7897_7__i_5_n_0_5c8b5cf = ((DOADO[4]) ? (~(esc_add_ln208_86_reg_7897_reg_11_897ebea [4])) : (esc_add_ln208_86_reg_7897_reg_11_897ebea [4]));

  // Reconstructed CARRY4: esc_add_ln208_86_reg_7897_reg_11__i_1_e104ce7
  wire [3:0] recovered_405_co, recovered_405_o, recovered_405_s, recovered_405_di;
  assign recovered_405_s = esc_add_ln208_86_reg_7897_reg_11_897ebea [11:8];
  assign recovered_405_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_405_ci = ((esc_add_ln208_86_reg_7897_reg_7__i_1_n_0_dbf3cc0) !== 1'bz) && (esc_add_ln208_86_reg_7897_reg_7__i_1_n_0_dbf3cc0);
  wire recovered_405_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_405_o[0] = recovered_405_s[0] ^ (recovered_405_ci || recovered_405_cy);
  assign recovered_405_co[0] = (recovered_405_s[0] & (recovered_405_ci || recovered_405_cy)) | (~recovered_405_s[0] & recovered_405_di[0]);
  assign recovered_405_o[1] = recovered_405_s[1] ^ recovered_405_co[0];
  assign recovered_405_co[1] = (recovered_405_s[1] & recovered_405_co[0]) | (~recovered_405_s[1] & recovered_405_di[1]);
  assign recovered_405_o[2] = recovered_405_s[2] ^ recovered_405_co[1];
  assign recovered_405_co[2] = (recovered_405_s[2] & recovered_405_co[1]) | (~recovered_405_s[2] & recovered_405_di[2]);
  assign recovered_405_o[3] = recovered_405_s[3] ^ recovered_405_co[2];
  assign recovered_405_co[3] = (recovered_405_s[3] & recovered_405_co[2]) | (~recovered_405_s[3] & recovered_405_di[3]);
  assign {esc_add_ln208_86_reg_7897_reg_11__i_1_n_0_0cb93a0 ,esc_NLW_add_ln208_86_reg_7897_reg_11__i_1_CO_UNCONNECTED_56e2b21 [2:0]} = recovered_405_co;
  assign esc_add_ln208_83_reg_7835_reg_11_118cabd [11:8] = recovered_405_o;

  // Reconstructed CARRY4: esc_add_ln208_86_reg_7897_reg_12__i_2_57a8186
  wire [3:0] recovered_406_co, recovered_406_o, recovered_406_s, recovered_406_di;
  assign recovered_406_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 };
  assign recovered_406_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_406_ci = ((esc_add_ln208_86_reg_7897_reg_11__i_1_n_0_0cb93a0) !== 1'bz) && (esc_add_ln208_86_reg_7897_reg_11__i_1_n_0_0cb93a0);
  wire recovered_406_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_406_o[0] = recovered_406_s[0] ^ (recovered_406_ci || recovered_406_cy);
  assign recovered_406_co[0] = (recovered_406_s[0] & (recovered_406_ci || recovered_406_cy)) | (~recovered_406_s[0] & recovered_406_di[0]);
  assign recovered_406_o[1] = recovered_406_s[1] ^ recovered_406_co[0];
  assign recovered_406_co[1] = (recovered_406_s[1] & recovered_406_co[0]) | (~recovered_406_s[1] & recovered_406_di[1]);
  assign recovered_406_o[2] = recovered_406_s[2] ^ recovered_406_co[1];
  assign recovered_406_co[2] = (recovered_406_s[2] & recovered_406_co[1]) | (~recovered_406_s[2] & recovered_406_di[2]);
  assign recovered_406_o[3] = recovered_406_s[3] ^ recovered_406_co[2];
  assign recovered_406_co[3] = (recovered_406_s[3] & recovered_406_co[2]) | (~recovered_406_s[3] & recovered_406_di[3]);
  assign esc_add_ln208_83_reg_7835_reg_11_118cabd [12] = recovered_406_co;

  // Reconstructed CARRY4: esc_add_ln208_86_reg_7897_reg_3__i_1_230e5f3
  wire [3:0] recovered_407_co, recovered_407_o, recovered_407_s, recovered_407_di;
  assign recovered_407_s = {esc_add_ln208_86_reg_7897_3__i_2_n_0_363c320 ,esc_add_ln208_86_reg_7897_3__i_3_n_0_8929e1f ,esc_add_ln208_86_reg_7897_3__i_4_n_0_1e9e4c1 ,esc_add_ln208_86_reg_7897_3__i_5_n_0_1cda033 };
  assign recovered_407_di = esc_add_ln208_86_reg_7897_reg_11_897ebea [3:0];
  wire recovered_407_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_407_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_407_o[0] = recovered_407_s[0] ^ (recovered_407_ci || recovered_407_cy);
  assign recovered_407_co[0] = (recovered_407_s[0] & (recovered_407_ci || recovered_407_cy)) | (~recovered_407_s[0] & recovered_407_di[0]);
  assign recovered_407_o[1] = recovered_407_s[1] ^ recovered_407_co[0];
  assign recovered_407_co[1] = (recovered_407_s[1] & recovered_407_co[0]) | (~recovered_407_s[1] & recovered_407_di[1]);
  assign recovered_407_o[2] = recovered_407_s[2] ^ recovered_407_co[1];
  assign recovered_407_co[2] = (recovered_407_s[2] & recovered_407_co[1]) | (~recovered_407_s[2] & recovered_407_di[2]);
  assign recovered_407_o[3] = recovered_407_s[3] ^ recovered_407_co[2];
  assign recovered_407_co[3] = (recovered_407_s[3] & recovered_407_co[2]) | (~recovered_407_s[3] & recovered_407_di[3]);
  assign {esc_add_ln208_86_reg_7897_reg_3__i_1_n_0_0baed0f ,esc_NLW_add_ln208_86_reg_7897_reg_3__i_1_CO_UNCONNECTED_14c31d4 [2:0]} = recovered_407_co;
  assign esc_add_ln208_83_reg_7835_reg_11_118cabd [3:0] = recovered_407_o;

  // Reconstructed CARRY4: esc_add_ln208_86_reg_7897_reg_7__i_1_4f25099
  wire [3:0] recovered_408_co, recovered_408_o, recovered_408_s, recovered_408_di;
  assign recovered_408_s = {esc_add_ln208_86_reg_7897_7__i_2_n_0_4a7ddc2 ,esc_add_ln208_86_reg_7897_7__i_3_n_0_dcb5d81 ,esc_add_ln208_86_reg_7897_7__i_4_n_0_d7d3b1b ,esc_add_ln208_86_reg_7897_7__i_5_n_0_5c8b5cf };
  assign recovered_408_di = esc_add_ln208_86_reg_7897_reg_11_897ebea [7:4];
  wire recovered_408_ci = ((esc_add_ln208_86_reg_7897_reg_3__i_1_n_0_0baed0f) !== 1'bz) && (esc_add_ln208_86_reg_7897_reg_3__i_1_n_0_0baed0f);
  wire recovered_408_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_408_o[0] = recovered_408_s[0] ^ (recovered_408_ci || recovered_408_cy);
  assign recovered_408_co[0] = (recovered_408_s[0] & (recovered_408_ci || recovered_408_cy)) | (~recovered_408_s[0] & recovered_408_di[0]);
  assign recovered_408_o[1] = recovered_408_s[1] ^ recovered_408_co[0];
  assign recovered_408_co[1] = (recovered_408_s[1] & recovered_408_co[0]) | (~recovered_408_s[1] & recovered_408_di[1]);
  assign recovered_408_o[2] = recovered_408_s[2] ^ recovered_408_co[1];
  assign recovered_408_co[2] = (recovered_408_s[2] & recovered_408_co[1]) | (~recovered_408_s[2] & recovered_408_di[2]);
  assign recovered_408_o[3] = recovered_408_s[3] ^ recovered_408_co[2];
  assign recovered_408_co[3] = (recovered_408_s[3] & recovered_408_co[2]) | (~recovered_408_s[3] & recovered_408_di[3]);
  assign {esc_add_ln208_86_reg_7897_reg_7__i_1_n_0_dbf3cc0 ,esc_NLW_add_ln208_86_reg_7897_reg_7__i_1_CO_UNCONNECTED_aa082d5 [2:0]} = recovered_408_co;
  assign esc_add_ln208_83_reg_7835_reg_11_118cabd [7:4] = recovered_408_o;

  // Reconstructed LUT2: esc_add_ln208_89_reg_7959_3__i_2_1bf5f7f
  assign esc_add_ln208_89_reg_7959_3__i_2_n_0_a287011 = ((DOADO[3]) ? (~(esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [3])) : (esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [3]));

  // Reconstructed LUT2: esc_add_ln208_89_reg_7959_3__i_3_3969018
  assign esc_add_ln208_89_reg_7959_3__i_3_n_0_6f96709 = ((DOADO[2]) ? (~(esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [2])) : (esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [2]));

  // Reconstructed LUT2: esc_add_ln208_89_reg_7959_3__i_4_1ee30a3
  assign esc_add_ln208_89_reg_7959_3__i_4_n_0_74c8e02 = ((DOADO[1]) ? (~(esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [1])) : (esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [1]));

  // Reconstructed LUT2: esc_add_ln208_89_reg_7959_3__i_5_970965d
  assign esc_add_ln208_89_reg_7959_3__i_5_n_0_5ab44a9 = ((DOADO[0]) ? (~(esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [0])) : (esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [0]));

  // Reconstructed LUT2: esc_add_ln208_89_reg_7959_7__i_2_bf5c31e
  assign esc_add_ln208_89_reg_7959_7__i_2_n_0_88e8b5c = ((DOADO[7]) ? (~(esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [7])) : (esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [7]));

  // Reconstructed LUT2: esc_add_ln208_89_reg_7959_7__i_3_d63ea7f
  assign esc_add_ln208_89_reg_7959_7__i_3_n_0_d34244b = ((DOADO[6]) ? (~(esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [6])) : (esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [6]));

  // Reconstructed LUT2: esc_add_ln208_89_reg_7959_7__i_4_8088fbf
  assign esc_add_ln208_89_reg_7959_7__i_4_n_0_ebd9be9 = ((DOADO[5]) ? (~(esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [5])) : (esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [5]));

  // Reconstructed LUT2: esc_add_ln208_89_reg_7959_7__i_5_9ee04be
  assign esc_add_ln208_89_reg_7959_7__i_5_n_0_960a627 = ((DOADO[4]) ? (~(esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [4])) : (esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [4]));

  // Reconstructed CARRY4: esc_add_ln208_89_reg_7959_reg_11__i_1_b730e67
  wire [3:0] recovered_417_co, recovered_417_o, recovered_417_s, recovered_417_di;
  assign recovered_417_s = esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [11:8];
  assign recovered_417_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_417_ci = ((esc_add_ln208_89_reg_7959_reg_7__i_1_n_0_a63f320) !== 1'bz) && (esc_add_ln208_89_reg_7959_reg_7__i_1_n_0_a63f320);
  wire recovered_417_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_417_o[0] = recovered_417_s[0] ^ (recovered_417_ci || recovered_417_cy);
  assign recovered_417_co[0] = (recovered_417_s[0] & (recovered_417_ci || recovered_417_cy)) | (~recovered_417_s[0] & recovered_417_di[0]);
  assign recovered_417_o[1] = recovered_417_s[1] ^ recovered_417_co[0];
  assign recovered_417_co[1] = (recovered_417_s[1] & recovered_417_co[0]) | (~recovered_417_s[1] & recovered_417_di[1]);
  assign recovered_417_o[2] = recovered_417_s[2] ^ recovered_417_co[1];
  assign recovered_417_co[2] = (recovered_417_s[2] & recovered_417_co[1]) | (~recovered_417_s[2] & recovered_417_di[2]);
  assign recovered_417_o[3] = recovered_417_s[3] ^ recovered_417_co[2];
  assign recovered_417_co[3] = (recovered_417_s[3] & recovered_417_co[2]) | (~recovered_417_s[3] & recovered_417_di[3]);
  assign {esc_add_ln208_89_reg_7959_reg_11__i_1_n_0_ea476e8 ,esc_NLW_add_ln208_89_reg_7959_reg_11__i_1_CO_UNCONNECTED_1d49898 [2:0]} = recovered_417_co;
  assign esc_add_ln208_86_reg_7897_reg_12_202b975 [11:8] = recovered_417_o;

  // Reconstructed CARRY4: esc_add_ln208_89_reg_7959_reg_12__i_2_40467a2
  wire [3:0] recovered_418_co, recovered_418_o, recovered_418_s, recovered_418_di;
  assign recovered_418_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [12]};
  assign recovered_418_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_418_ci = ((esc_add_ln208_89_reg_7959_reg_11__i_1_n_0_ea476e8) !== 1'bz) && (esc_add_ln208_89_reg_7959_reg_11__i_1_n_0_ea476e8);
  wire recovered_418_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_418_o[0] = recovered_418_s[0] ^ (recovered_418_ci || recovered_418_cy);
  assign recovered_418_co[0] = (recovered_418_s[0] & (recovered_418_ci || recovered_418_cy)) | (~recovered_418_s[0] & recovered_418_di[0]);
  assign recovered_418_o[1] = recovered_418_s[1] ^ recovered_418_co[0];
  assign recovered_418_co[1] = (recovered_418_s[1] & recovered_418_co[0]) | (~recovered_418_s[1] & recovered_418_di[1]);
  assign recovered_418_o[2] = recovered_418_s[2] ^ recovered_418_co[1];
  assign recovered_418_co[2] = (recovered_418_s[2] & recovered_418_co[1]) | (~recovered_418_s[2] & recovered_418_di[2]);
  assign recovered_418_o[3] = recovered_418_s[3] ^ recovered_418_co[2];
  assign recovered_418_co[3] = (recovered_418_s[3] & recovered_418_co[2]) | (~recovered_418_s[3] & recovered_418_di[3]);
  assign esc_add_ln208_86_reg_7897_reg_12_202b975 [12] = recovered_418_o;

  // Reconstructed CARRY4: esc_add_ln208_89_reg_7959_reg_3__i_1_c3e57e7
  wire [3:0] recovered_419_co, recovered_419_o, recovered_419_s, recovered_419_di;
  assign recovered_419_s = {esc_add_ln208_89_reg_7959_3__i_2_n_0_a287011 ,esc_add_ln208_89_reg_7959_3__i_3_n_0_6f96709 ,esc_add_ln208_89_reg_7959_3__i_4_n_0_74c8e02 ,esc_add_ln208_89_reg_7959_3__i_5_n_0_5ab44a9 };
  assign recovered_419_di = esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [3:0];
  wire recovered_419_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_419_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_419_o[0] = recovered_419_s[0] ^ (recovered_419_ci || recovered_419_cy);
  assign recovered_419_co[0] = (recovered_419_s[0] & (recovered_419_ci || recovered_419_cy)) | (~recovered_419_s[0] & recovered_419_di[0]);
  assign recovered_419_o[1] = recovered_419_s[1] ^ recovered_419_co[0];
  assign recovered_419_co[1] = (recovered_419_s[1] & recovered_419_co[0]) | (~recovered_419_s[1] & recovered_419_di[1]);
  assign recovered_419_o[2] = recovered_419_s[2] ^ recovered_419_co[1];
  assign recovered_419_co[2] = (recovered_419_s[2] & recovered_419_co[1]) | (~recovered_419_s[2] & recovered_419_di[2]);
  assign recovered_419_o[3] = recovered_419_s[3] ^ recovered_419_co[2];
  assign recovered_419_co[3] = (recovered_419_s[3] & recovered_419_co[2]) | (~recovered_419_s[3] & recovered_419_di[3]);
  assign {esc_add_ln208_89_reg_7959_reg_3__i_1_n_0_a180a61 ,esc_NLW_add_ln208_89_reg_7959_reg_3__i_1_CO_UNCONNECTED_2920456 [2:0]} = recovered_419_co;
  assign esc_add_ln208_86_reg_7897_reg_12_202b975 [3:0] = recovered_419_o;

  // Reconstructed CARRY4: esc_add_ln208_89_reg_7959_reg_7__i_1_a634c8c
  wire [3:0] recovered_420_co, recovered_420_o, recovered_420_s, recovered_420_di;
  assign recovered_420_s = {esc_add_ln208_89_reg_7959_7__i_2_n_0_88e8b5c ,esc_add_ln208_89_reg_7959_7__i_3_n_0_d34244b ,esc_add_ln208_89_reg_7959_7__i_4_n_0_ebd9be9 ,esc_add_ln208_89_reg_7959_7__i_5_n_0_960a627 };
  assign recovered_420_di = esc_add_ln208_89_reg_7959_reg_12__0_27a5822 [7:4];
  wire recovered_420_ci = ((esc_add_ln208_89_reg_7959_reg_3__i_1_n_0_a180a61) !== 1'bz) && (esc_add_ln208_89_reg_7959_reg_3__i_1_n_0_a180a61);
  wire recovered_420_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_420_o[0] = recovered_420_s[0] ^ (recovered_420_ci || recovered_420_cy);
  assign recovered_420_co[0] = (recovered_420_s[0] & (recovered_420_ci || recovered_420_cy)) | (~recovered_420_s[0] & recovered_420_di[0]);
  assign recovered_420_o[1] = recovered_420_s[1] ^ recovered_420_co[0];
  assign recovered_420_co[1] = (recovered_420_s[1] & recovered_420_co[0]) | (~recovered_420_s[1] & recovered_420_di[1]);
  assign recovered_420_o[2] = recovered_420_s[2] ^ recovered_420_co[1];
  assign recovered_420_co[2] = (recovered_420_s[2] & recovered_420_co[1]) | (~recovered_420_s[2] & recovered_420_di[2]);
  assign recovered_420_o[3] = recovered_420_s[3] ^ recovered_420_co[2];
  assign recovered_420_co[3] = (recovered_420_s[3] & recovered_420_co[2]) | (~recovered_420_s[3] & recovered_420_di[3]);
  assign {esc_add_ln208_89_reg_7959_reg_7__i_1_n_0_a63f320 ,esc_NLW_add_ln208_89_reg_7959_reg_7__i_1_CO_UNCONNECTED_8c03365 [2:0]} = recovered_420_co;
  assign esc_add_ln208_86_reg_7897_reg_12_202b975 [7:4] = recovered_420_o;

  // Reconstructed LUT2: esc_add_ln208_92_reg_8021_3__i_2_8ca0904
  assign esc_add_ln208_92_reg_8021_3__i_2_n_0_d472932 = ((DOADO[3]) ? (~(esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [3])) : (esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [3]));

  // Reconstructed LUT2: esc_add_ln208_92_reg_8021_3__i_3_4c99326
  assign esc_add_ln208_92_reg_8021_3__i_3_n_0_d031732 = ((DOADO[2]) ? (~(esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [2])) : (esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [2]));

  // Reconstructed LUT2: esc_add_ln208_92_reg_8021_3__i_4_1b3c5d5
  assign esc_add_ln208_92_reg_8021_3__i_4_n_0_0763430 = ((DOADO[1]) ? (~(esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [1])) : (esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [1]));

  // Reconstructed LUT2: esc_add_ln208_92_reg_8021_3__i_5_a99518d
  assign esc_add_ln208_92_reg_8021_3__i_5_n_0_30cac59 = ((DOADO[0]) ? (~(esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [0])) : (esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [0]));

  // Reconstructed LUT2: esc_add_ln208_92_reg_8021_7__i_2_7d73e09
  assign esc_add_ln208_92_reg_8021_7__i_2_n_0_292e299 = ((DOADO[7]) ? (~(esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [7])) : (esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [7]));

  // Reconstructed LUT2: esc_add_ln208_92_reg_8021_7__i_3_2ea15e7
  assign esc_add_ln208_92_reg_8021_7__i_3_n_0_2d36721 = ((DOADO[6]) ? (~(esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [6])) : (esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [6]));

  // Reconstructed LUT2: esc_add_ln208_92_reg_8021_7__i_4_f656656
  assign esc_add_ln208_92_reg_8021_7__i_4_n_0_00c4d33 = ((DOADO[5]) ? (~(esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [5])) : (esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [5]));

  // Reconstructed LUT2: esc_add_ln208_92_reg_8021_7__i_5_c6e1724
  assign esc_add_ln208_92_reg_8021_7__i_5_n_0_b97fd14 = ((DOADO[4]) ? (~(esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [4])) : (esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [4]));

  // Reconstructed CARRY4: esc_add_ln208_92_reg_8021_reg_11__i_1_ef45ee1
  wire [3:0] recovered_429_co, recovered_429_o, recovered_429_s, recovered_429_di;
  assign recovered_429_s = esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [11:8];
  assign recovered_429_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_429_ci = ((esc_add_ln208_92_reg_8021_reg_7__i_1_n_0_201e348) !== 1'bz) && (esc_add_ln208_92_reg_8021_reg_7__i_1_n_0_201e348);
  wire recovered_429_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_429_o[0] = recovered_429_s[0] ^ (recovered_429_ci || recovered_429_cy);
  assign recovered_429_co[0] = (recovered_429_s[0] & (recovered_429_ci || recovered_429_cy)) | (~recovered_429_s[0] & recovered_429_di[0]);
  assign recovered_429_o[1] = recovered_429_s[1] ^ recovered_429_co[0];
  assign recovered_429_co[1] = (recovered_429_s[1] & recovered_429_co[0]) | (~recovered_429_s[1] & recovered_429_di[1]);
  assign recovered_429_o[2] = recovered_429_s[2] ^ recovered_429_co[1];
  assign recovered_429_co[2] = (recovered_429_s[2] & recovered_429_co[1]) | (~recovered_429_s[2] & recovered_429_di[2]);
  assign recovered_429_o[3] = recovered_429_s[3] ^ recovered_429_co[2];
  assign recovered_429_co[3] = (recovered_429_s[3] & recovered_429_co[2]) | (~recovered_429_s[3] & recovered_429_di[3]);
  assign {esc_add_ln208_92_reg_8021_reg_11__i_1_n_0_bbe91ac ,esc_NLW_add_ln208_92_reg_8021_reg_11__i_1_CO_UNCONNECTED_ebba00d [2:0]} = recovered_429_co;
  assign esc_add_ln208_89_reg_7959_reg_12_637a141 [11:8] = recovered_429_o;

  // Reconstructed CARRY4: esc_add_ln208_92_reg_8021_reg_12__i_2_ac57549
  wire [3:0] recovered_430_co, recovered_430_o, recovered_430_s, recovered_430_di;
  assign recovered_430_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [12]};
  assign recovered_430_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_430_ci = ((esc_add_ln208_92_reg_8021_reg_11__i_1_n_0_bbe91ac) !== 1'bz) && (esc_add_ln208_92_reg_8021_reg_11__i_1_n_0_bbe91ac);
  wire recovered_430_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_430_o[0] = recovered_430_s[0] ^ (recovered_430_ci || recovered_430_cy);
  assign recovered_430_co[0] = (recovered_430_s[0] & (recovered_430_ci || recovered_430_cy)) | (~recovered_430_s[0] & recovered_430_di[0]);
  assign recovered_430_o[1] = recovered_430_s[1] ^ recovered_430_co[0];
  assign recovered_430_co[1] = (recovered_430_s[1] & recovered_430_co[0]) | (~recovered_430_s[1] & recovered_430_di[1]);
  assign recovered_430_o[2] = recovered_430_s[2] ^ recovered_430_co[1];
  assign recovered_430_co[2] = (recovered_430_s[2] & recovered_430_co[1]) | (~recovered_430_s[2] & recovered_430_di[2]);
  assign recovered_430_o[3] = recovered_430_s[3] ^ recovered_430_co[2];
  assign recovered_430_co[3] = (recovered_430_s[3] & recovered_430_co[2]) | (~recovered_430_s[3] & recovered_430_di[3]);
  assign esc_add_ln208_89_reg_7959_reg_12_637a141 [12] = recovered_430_o;

  // Reconstructed CARRY4: esc_add_ln208_92_reg_8021_reg_3__i_1_0e23ac0
  wire [3:0] recovered_431_co, recovered_431_o, recovered_431_s, recovered_431_di;
  assign recovered_431_s = {esc_add_ln208_92_reg_8021_3__i_2_n_0_d472932 ,esc_add_ln208_92_reg_8021_3__i_3_n_0_d031732 ,esc_add_ln208_92_reg_8021_3__i_4_n_0_0763430 ,esc_add_ln208_92_reg_8021_3__i_5_n_0_30cac59 };
  assign recovered_431_di = esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [3:0];
  wire recovered_431_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_431_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_431_o[0] = recovered_431_s[0] ^ (recovered_431_ci || recovered_431_cy);
  assign recovered_431_co[0] = (recovered_431_s[0] & (recovered_431_ci || recovered_431_cy)) | (~recovered_431_s[0] & recovered_431_di[0]);
  assign recovered_431_o[1] = recovered_431_s[1] ^ recovered_431_co[0];
  assign recovered_431_co[1] = (recovered_431_s[1] & recovered_431_co[0]) | (~recovered_431_s[1] & recovered_431_di[1]);
  assign recovered_431_o[2] = recovered_431_s[2] ^ recovered_431_co[1];
  assign recovered_431_co[2] = (recovered_431_s[2] & recovered_431_co[1]) | (~recovered_431_s[2] & recovered_431_di[2]);
  assign recovered_431_o[3] = recovered_431_s[3] ^ recovered_431_co[2];
  assign recovered_431_co[3] = (recovered_431_s[3] & recovered_431_co[2]) | (~recovered_431_s[3] & recovered_431_di[3]);
  assign {esc_add_ln208_92_reg_8021_reg_3__i_1_n_0_f486265 ,esc_NLW_add_ln208_92_reg_8021_reg_3__i_1_CO_UNCONNECTED_64d8cb4 [2:0]} = recovered_431_co;
  assign esc_add_ln208_89_reg_7959_reg_12_637a141 [3:0] = recovered_431_o;

  // Reconstructed CARRY4: esc_add_ln208_92_reg_8021_reg_7__i_1_f9f4227
  wire [3:0] recovered_432_co, recovered_432_o, recovered_432_s, recovered_432_di;
  assign recovered_432_s = {esc_add_ln208_92_reg_8021_7__i_2_n_0_292e299 ,esc_add_ln208_92_reg_8021_7__i_3_n_0_2d36721 ,esc_add_ln208_92_reg_8021_7__i_4_n_0_00c4d33 ,esc_add_ln208_92_reg_8021_7__i_5_n_0_b97fd14 };
  assign recovered_432_di = esc_add_ln208_92_reg_8021_reg_12__0_1f8120a [7:4];
  wire recovered_432_ci = ((esc_add_ln208_92_reg_8021_reg_3__i_1_n_0_f486265) !== 1'bz) && (esc_add_ln208_92_reg_8021_reg_3__i_1_n_0_f486265);
  wire recovered_432_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_432_o[0] = recovered_432_s[0] ^ (recovered_432_ci || recovered_432_cy);
  assign recovered_432_co[0] = (recovered_432_s[0] & (recovered_432_ci || recovered_432_cy)) | (~recovered_432_s[0] & recovered_432_di[0]);
  assign recovered_432_o[1] = recovered_432_s[1] ^ recovered_432_co[0];
  assign recovered_432_co[1] = (recovered_432_s[1] & recovered_432_co[0]) | (~recovered_432_s[1] & recovered_432_di[1]);
  assign recovered_432_o[2] = recovered_432_s[2] ^ recovered_432_co[1];
  assign recovered_432_co[2] = (recovered_432_s[2] & recovered_432_co[1]) | (~recovered_432_s[2] & recovered_432_di[2]);
  assign recovered_432_o[3] = recovered_432_s[3] ^ recovered_432_co[2];
  assign recovered_432_co[3] = (recovered_432_s[3] & recovered_432_co[2]) | (~recovered_432_s[3] & recovered_432_di[3]);
  assign {esc_add_ln208_92_reg_8021_reg_7__i_1_n_0_201e348 ,esc_NLW_add_ln208_92_reg_8021_reg_7__i_1_CO_UNCONNECTED_7b3a5e9 [2:0]} = recovered_432_co;
  assign esc_add_ln208_89_reg_7959_reg_12_637a141 [7:4] = recovered_432_o;

  // Reconstructed LUT2: esc_add_ln208_95_reg_8083_3__i_2_501bb60
  assign esc_add_ln208_95_reg_8083_3__i_2_n_0_11c230b = ((DOADO[3]) ? (~(esc_add_ln208_95_reg_8083_reg_12__0_30298fc [3])) : (esc_add_ln208_95_reg_8083_reg_12__0_30298fc [3]));

  // Reconstructed LUT2: esc_add_ln208_95_reg_8083_3__i_3_760e81a
  assign esc_add_ln208_95_reg_8083_3__i_3_n_0_c532e3e = ((DOADO[2]) ? (~(esc_add_ln208_95_reg_8083_reg_12__0_30298fc [2])) : (esc_add_ln208_95_reg_8083_reg_12__0_30298fc [2]));

  // Reconstructed LUT2: esc_add_ln208_95_reg_8083_3__i_4_0dbf1ad
  assign esc_add_ln208_95_reg_8083_3__i_4_n_0_111f6dc = ((DOADO[1]) ? (~(esc_add_ln208_95_reg_8083_reg_12__0_30298fc [1])) : (esc_add_ln208_95_reg_8083_reg_12__0_30298fc [1]));

  // Reconstructed LUT2: esc_add_ln208_95_reg_8083_3__i_5_88e838d
  assign esc_add_ln208_95_reg_8083_3__i_5_n_0_f866e80 = ((DOADO[0]) ? (~(esc_add_ln208_95_reg_8083_reg_12__0_30298fc [0])) : (esc_add_ln208_95_reg_8083_reg_12__0_30298fc [0]));

  // Reconstructed LUT2: esc_add_ln208_95_reg_8083_7__i_2_f983f05
  assign esc_add_ln208_95_reg_8083_7__i_2_n_0_90a6918 = ((DOADO[7]) ? (~(esc_add_ln208_95_reg_8083_reg_12__0_30298fc [7])) : (esc_add_ln208_95_reg_8083_reg_12__0_30298fc [7]));

  // Reconstructed LUT2: esc_add_ln208_95_reg_8083_7__i_3_8cef9cd
  assign esc_add_ln208_95_reg_8083_7__i_3_n_0_2ee3a8c = ((DOADO[6]) ? (~(esc_add_ln208_95_reg_8083_reg_12__0_30298fc [6])) : (esc_add_ln208_95_reg_8083_reg_12__0_30298fc [6]));

  // Reconstructed LUT2: esc_add_ln208_95_reg_8083_7__i_4_6f201ae
  assign esc_add_ln208_95_reg_8083_7__i_4_n_0_10ec784 = ((DOADO[5]) ? (~(esc_add_ln208_95_reg_8083_reg_12__0_30298fc [5])) : (esc_add_ln208_95_reg_8083_reg_12__0_30298fc [5]));

  // Reconstructed LUT2: esc_add_ln208_95_reg_8083_7__i_5_10ddf85
  assign esc_add_ln208_95_reg_8083_7__i_5_n_0_262aef2 = ((DOADO[4]) ? (~(esc_add_ln208_95_reg_8083_reg_12__0_30298fc [4])) : (esc_add_ln208_95_reg_8083_reg_12__0_30298fc [4]));

  // Reconstructed CARRY4: esc_add_ln208_95_reg_8083_reg_11__i_1_b9023c4
  wire [3:0] recovered_441_co, recovered_441_o, recovered_441_s, recovered_441_di;
  assign recovered_441_s = esc_add_ln208_95_reg_8083_reg_12__0_30298fc [11:8];
  assign recovered_441_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_441_ci = ((esc_add_ln208_95_reg_8083_reg_7__i_1_n_0_e2568f4) !== 1'bz) && (esc_add_ln208_95_reg_8083_reg_7__i_1_n_0_e2568f4);
  wire recovered_441_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_441_o[0] = recovered_441_s[0] ^ (recovered_441_ci || recovered_441_cy);
  assign recovered_441_co[0] = (recovered_441_s[0] & (recovered_441_ci || recovered_441_cy)) | (~recovered_441_s[0] & recovered_441_di[0]);
  assign recovered_441_o[1] = recovered_441_s[1] ^ recovered_441_co[0];
  assign recovered_441_co[1] = (recovered_441_s[1] & recovered_441_co[0]) | (~recovered_441_s[1] & recovered_441_di[1]);
  assign recovered_441_o[2] = recovered_441_s[2] ^ recovered_441_co[1];
  assign recovered_441_co[2] = (recovered_441_s[2] & recovered_441_co[1]) | (~recovered_441_s[2] & recovered_441_di[2]);
  assign recovered_441_o[3] = recovered_441_s[3] ^ recovered_441_co[2];
  assign recovered_441_co[3] = (recovered_441_s[3] & recovered_441_co[2]) | (~recovered_441_s[3] & recovered_441_di[3]);
  assign {esc_add_ln208_95_reg_8083_reg_11__i_1_n_0_6c49a8c ,esc_NLW_add_ln208_95_reg_8083_reg_11__i_1_CO_UNCONNECTED_e4ceec3 [2:0]} = recovered_441_co;
  assign esc_add_ln208_92_reg_8021_reg_12_8f48385 [11:8] = recovered_441_o;

  // Reconstructed CARRY4: esc_add_ln208_95_reg_8083_reg_12__i_2_7c55561
  wire [3:0] recovered_442_co, recovered_442_o, recovered_442_s, recovered_442_di;
  assign recovered_442_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_95_reg_8083_reg_12__0_30298fc [12]};
  assign recovered_442_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_442_ci = ((esc_add_ln208_95_reg_8083_reg_11__i_1_n_0_6c49a8c) !== 1'bz) && (esc_add_ln208_95_reg_8083_reg_11__i_1_n_0_6c49a8c);
  wire recovered_442_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_442_o[0] = recovered_442_s[0] ^ (recovered_442_ci || recovered_442_cy);
  assign recovered_442_co[0] = (recovered_442_s[0] & (recovered_442_ci || recovered_442_cy)) | (~recovered_442_s[0] & recovered_442_di[0]);
  assign recovered_442_o[1] = recovered_442_s[1] ^ recovered_442_co[0];
  assign recovered_442_co[1] = (recovered_442_s[1] & recovered_442_co[0]) | (~recovered_442_s[1] & recovered_442_di[1]);
  assign recovered_442_o[2] = recovered_442_s[2] ^ recovered_442_co[1];
  assign recovered_442_co[2] = (recovered_442_s[2] & recovered_442_co[1]) | (~recovered_442_s[2] & recovered_442_di[2]);
  assign recovered_442_o[3] = recovered_442_s[3] ^ recovered_442_co[2];
  assign recovered_442_co[3] = (recovered_442_s[3] & recovered_442_co[2]) | (~recovered_442_s[3] & recovered_442_di[3]);
  assign esc_add_ln208_92_reg_8021_reg_12_8f48385 [12] = recovered_442_o;

  // Reconstructed CARRY4: esc_add_ln208_95_reg_8083_reg_3__i_1_f941aaf
  wire [3:0] recovered_443_co, recovered_443_o, recovered_443_s, recovered_443_di;
  assign recovered_443_s = {esc_add_ln208_95_reg_8083_3__i_2_n_0_11c230b ,esc_add_ln208_95_reg_8083_3__i_3_n_0_c532e3e ,esc_add_ln208_95_reg_8083_3__i_4_n_0_111f6dc ,esc_add_ln208_95_reg_8083_3__i_5_n_0_f866e80 };
  assign recovered_443_di = esc_add_ln208_95_reg_8083_reg_12__0_30298fc [3:0];
  wire recovered_443_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_443_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_443_o[0] = recovered_443_s[0] ^ (recovered_443_ci || recovered_443_cy);
  assign recovered_443_co[0] = (recovered_443_s[0] & (recovered_443_ci || recovered_443_cy)) | (~recovered_443_s[0] & recovered_443_di[0]);
  assign recovered_443_o[1] = recovered_443_s[1] ^ recovered_443_co[0];
  assign recovered_443_co[1] = (recovered_443_s[1] & recovered_443_co[0]) | (~recovered_443_s[1] & recovered_443_di[1]);
  assign recovered_443_o[2] = recovered_443_s[2] ^ recovered_443_co[1];
  assign recovered_443_co[2] = (recovered_443_s[2] & recovered_443_co[1]) | (~recovered_443_s[2] & recovered_443_di[2]);
  assign recovered_443_o[3] = recovered_443_s[3] ^ recovered_443_co[2];
  assign recovered_443_co[3] = (recovered_443_s[3] & recovered_443_co[2]) | (~recovered_443_s[3] & recovered_443_di[3]);
  assign {esc_add_ln208_95_reg_8083_reg_3__i_1_n_0_3d47bc8 ,esc_NLW_add_ln208_95_reg_8083_reg_3__i_1_CO_UNCONNECTED_40085d5 [2:0]} = recovered_443_co;
  assign esc_add_ln208_92_reg_8021_reg_12_8f48385 [3:0] = recovered_443_o;

  // Reconstructed CARRY4: esc_add_ln208_95_reg_8083_reg_7__i_1_e6f11a7
  wire [3:0] recovered_444_co, recovered_444_o, recovered_444_s, recovered_444_di;
  assign recovered_444_s = {esc_add_ln208_95_reg_8083_7__i_2_n_0_90a6918 ,esc_add_ln208_95_reg_8083_7__i_3_n_0_2ee3a8c ,esc_add_ln208_95_reg_8083_7__i_4_n_0_10ec784 ,esc_add_ln208_95_reg_8083_7__i_5_n_0_262aef2 };
  assign recovered_444_di = esc_add_ln208_95_reg_8083_reg_12__0_30298fc [7:4];
  wire recovered_444_ci = ((esc_add_ln208_95_reg_8083_reg_3__i_1_n_0_3d47bc8) !== 1'bz) && (esc_add_ln208_95_reg_8083_reg_3__i_1_n_0_3d47bc8);
  wire recovered_444_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_444_o[0] = recovered_444_s[0] ^ (recovered_444_ci || recovered_444_cy);
  assign recovered_444_co[0] = (recovered_444_s[0] & (recovered_444_ci || recovered_444_cy)) | (~recovered_444_s[0] & recovered_444_di[0]);
  assign recovered_444_o[1] = recovered_444_s[1] ^ recovered_444_co[0];
  assign recovered_444_co[1] = (recovered_444_s[1] & recovered_444_co[0]) | (~recovered_444_s[1] & recovered_444_di[1]);
  assign recovered_444_o[2] = recovered_444_s[2] ^ recovered_444_co[1];
  assign recovered_444_co[2] = (recovered_444_s[2] & recovered_444_co[1]) | (~recovered_444_s[2] & recovered_444_di[2]);
  assign recovered_444_o[3] = recovered_444_s[3] ^ recovered_444_co[2];
  assign recovered_444_co[3] = (recovered_444_s[3] & recovered_444_co[2]) | (~recovered_444_s[3] & recovered_444_di[3]);
  assign {esc_add_ln208_95_reg_8083_reg_7__i_1_n_0_e2568f4 ,esc_NLW_add_ln208_95_reg_8083_reg_7__i_1_CO_UNCONNECTED_02d9b36 [2:0]} = recovered_444_co;
  assign esc_add_ln208_92_reg_8021_reg_12_8f48385 [7:4] = recovered_444_o;

  // Reconstructed LUT2: esc_add_ln208_98_reg_8125_3__i_2_98a0e60
  assign esc_add_ln208_98_reg_8125_3__i_2_n_0_f008b3b = ((DOADO[3]) ? (~(esc_add_ln208_98_reg_8125_reg_12__0_2065764 [3])) : (esc_add_ln208_98_reg_8125_reg_12__0_2065764 [3]));

  // Reconstructed LUT2: esc_add_ln208_98_reg_8125_3__i_3_fd5f294
  assign esc_add_ln208_98_reg_8125_3__i_3_n_0_896f534 = ((DOADO[2]) ? (~(esc_add_ln208_98_reg_8125_reg_12__0_2065764 [2])) : (esc_add_ln208_98_reg_8125_reg_12__0_2065764 [2]));

  // Reconstructed LUT2: esc_add_ln208_98_reg_8125_3__i_4_cfbed63
  assign esc_add_ln208_98_reg_8125_3__i_4_n_0_6339384 = ((DOADO[1]) ? (~(esc_add_ln208_98_reg_8125_reg_12__0_2065764 [1])) : (esc_add_ln208_98_reg_8125_reg_12__0_2065764 [1]));

  // Reconstructed LUT2: esc_add_ln208_98_reg_8125_3__i_5_c936aa5
  assign esc_add_ln208_98_reg_8125_3__i_5_n_0_35ff0bd = ((DOADO[0]) ? (~(esc_add_ln208_98_reg_8125_reg_12__0_2065764 [0])) : (esc_add_ln208_98_reg_8125_reg_12__0_2065764 [0]));

  // Reconstructed LUT2: esc_add_ln208_98_reg_8125_7__i_2_37f1776
  assign esc_add_ln208_98_reg_8125_7__i_2_n_0_3ebfd12 = ((DOADO[7]) ? (~(esc_add_ln208_98_reg_8125_reg_12__0_2065764 [7])) : (esc_add_ln208_98_reg_8125_reg_12__0_2065764 [7]));

  // Reconstructed LUT2: esc_add_ln208_98_reg_8125_7__i_3_d4dcf78
  assign esc_add_ln208_98_reg_8125_7__i_3_n_0_1b9adae = ((DOADO[6]) ? (~(esc_add_ln208_98_reg_8125_reg_12__0_2065764 [6])) : (esc_add_ln208_98_reg_8125_reg_12__0_2065764 [6]));

  // Reconstructed LUT2: esc_add_ln208_98_reg_8125_7__i_4_c9d54f3
  assign esc_add_ln208_98_reg_8125_7__i_4_n_0_32ca77b = ((DOADO[5]) ? (~(esc_add_ln208_98_reg_8125_reg_12__0_2065764 [5])) : (esc_add_ln208_98_reg_8125_reg_12__0_2065764 [5]));

  // Reconstructed LUT2: esc_add_ln208_98_reg_8125_7__i_5_7e6b172
  assign esc_add_ln208_98_reg_8125_7__i_5_n_0_eac0e01 = ((DOADO[4]) ? (~(esc_add_ln208_98_reg_8125_reg_12__0_2065764 [4])) : (esc_add_ln208_98_reg_8125_reg_12__0_2065764 [4]));

  // Reconstructed CARRY4: esc_add_ln208_98_reg_8125_reg_11__i_1_91ccc8d
  wire [3:0] recovered_453_co, recovered_453_o, recovered_453_s, recovered_453_di;
  assign recovered_453_s = esc_add_ln208_98_reg_8125_reg_12__0_2065764 [11:8];
  assign recovered_453_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_453_ci = ((esc_add_ln208_98_reg_8125_reg_7__i_1_n_0_c586656) !== 1'bz) && (esc_add_ln208_98_reg_8125_reg_7__i_1_n_0_c586656);
  wire recovered_453_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_453_o[0] = recovered_453_s[0] ^ (recovered_453_ci || recovered_453_cy);
  assign recovered_453_co[0] = (recovered_453_s[0] & (recovered_453_ci || recovered_453_cy)) | (~recovered_453_s[0] & recovered_453_di[0]);
  assign recovered_453_o[1] = recovered_453_s[1] ^ recovered_453_co[0];
  assign recovered_453_co[1] = (recovered_453_s[1] & recovered_453_co[0]) | (~recovered_453_s[1] & recovered_453_di[1]);
  assign recovered_453_o[2] = recovered_453_s[2] ^ recovered_453_co[1];
  assign recovered_453_co[2] = (recovered_453_s[2] & recovered_453_co[1]) | (~recovered_453_s[2] & recovered_453_di[2]);
  assign recovered_453_o[3] = recovered_453_s[3] ^ recovered_453_co[2];
  assign recovered_453_co[3] = (recovered_453_s[3] & recovered_453_co[2]) | (~recovered_453_s[3] & recovered_453_di[3]);
  assign {esc_add_ln208_98_reg_8125_reg_11__i_1_n_0_04189a0 ,esc_NLW_add_ln208_98_reg_8125_reg_11__i_1_CO_UNCONNECTED_592cb79 [2:0]} = recovered_453_co;
  assign esc_add_ln208_95_reg_8083_reg_12_2d1a536 [11:8] = recovered_453_o;

  // Reconstructed CARRY4: esc_add_ln208_98_reg_8125_reg_12__i_2_24bb766
  wire [3:0] recovered_454_co, recovered_454_o, recovered_454_s, recovered_454_di;
  assign recovered_454_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_add_ln208_98_reg_8125_reg_12__0_2065764 [12]};
  assign recovered_454_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_454_ci = ((esc_add_ln208_98_reg_8125_reg_11__i_1_n_0_04189a0) !== 1'bz) && (esc_add_ln208_98_reg_8125_reg_11__i_1_n_0_04189a0);
  wire recovered_454_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_454_o[0] = recovered_454_s[0] ^ (recovered_454_ci || recovered_454_cy);
  assign recovered_454_co[0] = (recovered_454_s[0] & (recovered_454_ci || recovered_454_cy)) | (~recovered_454_s[0] & recovered_454_di[0]);
  assign recovered_454_o[1] = recovered_454_s[1] ^ recovered_454_co[0];
  assign recovered_454_co[1] = (recovered_454_s[1] & recovered_454_co[0]) | (~recovered_454_s[1] & recovered_454_di[1]);
  assign recovered_454_o[2] = recovered_454_s[2] ^ recovered_454_co[1];
  assign recovered_454_co[2] = (recovered_454_s[2] & recovered_454_co[1]) | (~recovered_454_s[2] & recovered_454_di[2]);
  assign recovered_454_o[3] = recovered_454_s[3] ^ recovered_454_co[2];
  assign recovered_454_co[3] = (recovered_454_s[3] & recovered_454_co[2]) | (~recovered_454_s[3] & recovered_454_di[3]);
  assign esc_add_ln208_95_reg_8083_reg_12_2d1a536 [12] = recovered_454_o;

  // Reconstructed CARRY4: esc_add_ln208_98_reg_8125_reg_3__i_1_788e6ea
  wire [3:0] recovered_455_co, recovered_455_o, recovered_455_s, recovered_455_di;
  assign recovered_455_s = {esc_add_ln208_98_reg_8125_3__i_2_n_0_f008b3b ,esc_add_ln208_98_reg_8125_3__i_3_n_0_896f534 ,esc_add_ln208_98_reg_8125_3__i_4_n_0_6339384 ,esc_add_ln208_98_reg_8125_3__i_5_n_0_35ff0bd };
  assign recovered_455_di = esc_add_ln208_98_reg_8125_reg_12__0_2065764 [3:0];
  wire recovered_455_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_455_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_455_o[0] = recovered_455_s[0] ^ (recovered_455_ci || recovered_455_cy);
  assign recovered_455_co[0] = (recovered_455_s[0] & (recovered_455_ci || recovered_455_cy)) | (~recovered_455_s[0] & recovered_455_di[0]);
  assign recovered_455_o[1] = recovered_455_s[1] ^ recovered_455_co[0];
  assign recovered_455_co[1] = (recovered_455_s[1] & recovered_455_co[0]) | (~recovered_455_s[1] & recovered_455_di[1]);
  assign recovered_455_o[2] = recovered_455_s[2] ^ recovered_455_co[1];
  assign recovered_455_co[2] = (recovered_455_s[2] & recovered_455_co[1]) | (~recovered_455_s[2] & recovered_455_di[2]);
  assign recovered_455_o[3] = recovered_455_s[3] ^ recovered_455_co[2];
  assign recovered_455_co[3] = (recovered_455_s[3] & recovered_455_co[2]) | (~recovered_455_s[3] & recovered_455_di[3]);
  assign {esc_add_ln208_98_reg_8125_reg_3__i_1_n_0_71dbc58 ,esc_NLW_add_ln208_98_reg_8125_reg_3__i_1_CO_UNCONNECTED_4d55cc8 [2:0]} = recovered_455_co;
  assign esc_add_ln208_95_reg_8083_reg_12_2d1a536 [3:0] = recovered_455_o;

  // Reconstructed CARRY4: esc_add_ln208_98_reg_8125_reg_7__i_1_e70a0bc
  wire [3:0] recovered_456_co, recovered_456_o, recovered_456_s, recovered_456_di;
  assign recovered_456_s = {esc_add_ln208_98_reg_8125_7__i_2_n_0_3ebfd12 ,esc_add_ln208_98_reg_8125_7__i_3_n_0_1b9adae ,esc_add_ln208_98_reg_8125_7__i_4_n_0_32ca77b ,esc_add_ln208_98_reg_8125_7__i_5_n_0_eac0e01 };
  assign recovered_456_di = esc_add_ln208_98_reg_8125_reg_12__0_2065764 [7:4];
  wire recovered_456_ci = ((esc_add_ln208_98_reg_8125_reg_3__i_1_n_0_71dbc58) !== 1'bz) && (esc_add_ln208_98_reg_8125_reg_3__i_1_n_0_71dbc58);
  wire recovered_456_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_456_o[0] = recovered_456_s[0] ^ (recovered_456_ci || recovered_456_cy);
  assign recovered_456_co[0] = (recovered_456_s[0] & (recovered_456_ci || recovered_456_cy)) | (~recovered_456_s[0] & recovered_456_di[0]);
  assign recovered_456_o[1] = recovered_456_s[1] ^ recovered_456_co[0];
  assign recovered_456_co[1] = (recovered_456_s[1] & recovered_456_co[0]) | (~recovered_456_s[1] & recovered_456_di[1]);
  assign recovered_456_o[2] = recovered_456_s[2] ^ recovered_456_co[1];
  assign recovered_456_co[2] = (recovered_456_s[2] & recovered_456_co[1]) | (~recovered_456_s[2] & recovered_456_di[2]);
  assign recovered_456_o[3] = recovered_456_s[3] ^ recovered_456_co[2];
  assign recovered_456_co[3] = (recovered_456_s[3] & recovered_456_co[2]) | (~recovered_456_s[3] & recovered_456_di[3]);
  assign {esc_add_ln208_98_reg_8125_reg_7__i_1_n_0_c586656 ,esc_NLW_add_ln208_98_reg_8125_reg_7__i_1_CO_UNCONNECTED_37ba7f4 [2:0]} = recovered_456_co;
  assign esc_add_ln208_95_reg_8083_reg_12_2d1a536 [7:4] = recovered_456_o;

  RAMB18E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(18'h00000),
    .INIT_B(18'h00000),
    .INIT_FILE("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("PERFORMANCE"),
    .READ_WIDTH_A(9),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(18'h00000),
    .SRVAL_B(18'h00000),
    .WRITE_MODE_A("READ_FIRST"),
    .WRITE_MODE_B("WRITE_FIRST"),
    .WRITE_WIDTH_A(9),
    .WRITE_WIDTH_B(0)) 
    ram0_reg
       (.ADDRARDADDR({ram0_reg_i_2_n_0,ram0_reg_i_3_n_0,ram0_reg_i_4_n_0,ram0_reg_i_5_n_0,ram0_reg_i_6_n_0,ram0_reg_i_7_n_0,ram0_reg_i_8_n_0,ram0_reg_i_9__0_n_0,ram0_reg_i_10_n_0,ram0_reg_i_11_n_0,ram0_reg_i_12_n_0,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .ADDRBWRADDR({esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .CLKARDCLK(ap_clk),
        .CLKBWRCLK(esc_const0_a0cf646 ),
        .DIADI({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,blue_counts_d0[7],ram0_reg_i_14_n_0,blue_counts_d0[5:0]}),
        .DIBDI({esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .DIPADIP({esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .DIPBDIP({esc_const1_c064970 ,esc_const1_c064970 }),
        .DOADO(DOADO),
        .ENARDEN(blue_counts_ce0),
        .ENBWREN(esc_const0_a0cf646 ),
        .REGCEAREGCE(esc_const0_a0cf646 ),
        .REGCEB(esc_const0_a0cf646 ),
        .RSTRAMARSTRAM(esc_const0_a0cf646 ),
        .RSTRAMB(esc_const0_a0cf646 ),
        .RSTREGARSTREG(esc_const0_a0cf646 ),
        .RSTREGB(esc_const0_a0cf646 ),
        .WEA({GND_2,blue_counts_we0}),
        .WEBWE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }));

  // Reconstructed LUT6: ram0_reg_i_10
  assign ram0_reg_i_10_n_0 = ((ram0_reg_4) ? (((ram0_reg_3) ? (((ram0_reg_i_58_n_0) ? (1'b1) : (((ram0_reg_2) ? (1'b1) : (((ram0_reg_1) ? (ram0_reg_0) : (1'b1))))))) : (((ram0_reg_1) ? (ram0_reg_0) : (1'b1))))) : (ram0_reg_0));

  // Reconstructed LUT2: ram0_reg_i_103
  assign ram0_reg_i_103_n_0 = ((ram0_reg_i_53_0[2]) ? (ap_enable_reg_pp1_iter0) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_11
  assign ram0_reg_i_11_n_0 = ((ram0_reg_14) ? (1'b1) : (((ram0_reg_4) ? (((ram0_reg_3) ? (((ram0_reg_i_61_n_0) ? (1'b1) : (((ram0_reg_13) ? (~(ram0_reg_12)) : (1'b1))))) : (~(ram0_reg_12)))) : (1'b0))));

  // Reconstructed LUT6: ram0_reg_i_112
  assign ram0_reg_i_112_n_0 = ((ram0_reg_i_53_0[6]) ? (((ram0_reg_i_53_2) ? (1'b1) : (~(ram0_reg_i_53_1)))) : (((ram0_reg_i_53_0[5]) ? (((ram0_reg_i_53_2) ? (1'b1) : (~(ram0_reg_i_53_1)))) : (((ram0_reg_i_53_2) ? (((ram0_reg_i_53_0[4]) ? (1'b1) : (((ram0_reg_i_53_0[3]) ? (1'b1) : (~(ram0_reg_i_53_1)))))) : (~(ram0_reg_i_53_1)))))));

  // Reconstructed LUT2: ram0_reg_i_113
  assign ram0_reg_i_113_n_0 = ((ram0_reg_i_53_0[7]) ? (ap_enable_reg_pp3_iter0) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_12
  assign ram0_reg_i_12_n_0 = ((ram0_reg_10) ? (1'b1) : (((ram0_reg_4) ? (((ram0_reg_3) ? (((ram0_reg_i_65_n_0) ? (1'b1) : (((ram0_reg_9) ? (~(ram0_reg_8)) : (1'b1))))) : (~(ram0_reg_8)))) : (1'b0))));

  // Reconstructed LUT5: ram0_reg_i_13
  assign blue_counts_d0[7] = ((ram0_reg_7[7]) ? (((ram0_reg_i_67_n_0) ? (((ram0_reg_7[6]) ? (1'b0) : (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))))) : (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))))) : (((ram0_reg_i_67_n_0) ? (((ram0_reg_7[6]) ? (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: ram0_reg_i_14
  assign ram0_reg_i_14_n_0 = ((ram0_reg_6) ? (((ram0_reg_i_53_0[1]) ? (((ram0_reg_7[6]) ? (~(ram0_reg_i_67_n_0)) : (ram0_reg_i_67_n_0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT4: ram0_reg_i_15
  assign blue_counts_d0[5] = ((ram0_reg_7[5]) ? (((ram0_reg_i_68_n_0) ? (1'b0) : (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))))) : (((ram0_reg_i_68_n_0) ? (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: ram0_reg_i_16
  assign blue_counts_d0[4] = ((ram0_reg_7[4]) ? (((ram0_reg_7[3]) ? (((ram0_reg_7[1]) ? (((ram0_reg_7[0]) ? (((ram0_reg_7[2]) ? (1'b0) : (ap_enable_reg_pp1_iter1_reg))) : (ap_enable_reg_pp1_iter1_reg))) : (ap_enable_reg_pp1_iter1_reg))) : (ap_enable_reg_pp1_iter1_reg))) : (((ram0_reg_7[3]) ? (((ram0_reg_7[1]) ? (((ram0_reg_7[0]) ? (((ram0_reg_7[2]) ? (ap_enable_reg_pp1_iter1_reg) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: ram0_reg_i_17
  assign blue_counts_d0[3] = ((ram0_reg_7[3]) ? (((ram0_reg_7[2]) ? (((ram0_reg_7[0]) ? (((ram0_reg_7[1]) ? (1'b0) : (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))))) : (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))))) : (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))))) : (((ram0_reg_7[2]) ? (((ram0_reg_7[0]) ? (((ram0_reg_7[1]) ? (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: ram0_reg_i_18
  assign blue_counts_d0[2] = ((ram0_reg_7[2]) ? (((ram0_reg_7[1]) ? (((ram0_reg_7[0]) ? (1'b0) : (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))))) : (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))))) : (((ram0_reg_7[1]) ? (((ram0_reg_7[0]) ? (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: ram0_reg_i_19
  assign blue_counts_d0[1] = ((ram0_reg_7[0]) ? (((ram0_reg_7[1]) ? (1'b0) : (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))))) : (((ram0_reg_7[1]) ? (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: ram0_reg_i_2
  assign ram0_reg_i_2_n_0 = ((ram0_reg_36) ? (1'b1) : (((ram0_reg_4) ? (((ram0_reg_i_25_n_0) ? (1'b1) : (~(ram0_reg_35)))) : (1'b0))));

  // Reconstructed LUT3: ram0_reg_i_20
  assign blue_counts_d0[0] = ((ram0_reg_7[0]) ? (1'b0) : (((ram0_reg_6) ? (ram0_reg_i_53_0[1]) : (1'b0))));

  // Reconstructed LUT6: ram0_reg_i_21
  assign blue_counts_we0 = ((previous_blue_1_reg_6804) ? (((ram0_reg_i_53_0[1]) ? (((ram0_reg_6) ? (1'b1) : (((ap_enable_reg_pp0_iter1) ? (((ram0_reg_i_53_0[0]) ? (~(ram0_reg_38)) : (1'b0))) : (1'b0))))) : (((ap_enable_reg_pp0_iter1) ? (((ram0_reg_i_53_0[0]) ? (~(ram0_reg_38)) : (1'b0))) : (1'b0))))) : (((ap_enable_reg_pp0_iter1) ? (((ram0_reg_i_53_0[0]) ? (~(ram0_reg_38)) : (1'b0))) : (1'b0))));

  // Reconstructed LUT2: ram0_reg_i_23
  assign ap_enable_reg_pp1_iter1_reg = ((ram0_reg_i_53_0[1]) ? (ram0_reg_6) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_25
  assign ram0_reg_i_25_n_0 = ((ram0_reg_37) ? (((ram0_reg_5) ? (((ram0_reg_i_75_n_0) ? (((ram0_reg_30[2]) ? (((ram0_reg_29) ? (1'b0) : (ram0_reg_3))) : (1'b0))) : (ram0_reg_3))) : (((ram0_reg_30[2]) ? (((ram0_reg_29) ? (1'b0) : (ram0_reg_3))) : (1'b0))))) : (ram0_reg_3));

  // Reconstructed LUT6: ram0_reg_i_29
  assign ram0_reg_i_29_n_0 = ((ram0_reg_34) ? (((ram0_reg_5) ? (((ram0_reg_i_89_n_0) ? (((ram0_reg_30[1]) ? (((ram0_reg_29) ? (1'b0) : (ram0_reg_3))) : (1'b0))) : (ram0_reg_3))) : (((ram0_reg_30[1]) ? (((ram0_reg_29) ? (1'b0) : (ram0_reg_3))) : (1'b0))))) : (ram0_reg_3));

  // Reconstructed LUT4: ram0_reg_i_3
  assign ram0_reg_i_3_n_0 = ((ram0_reg_33) ? (1'b1) : (((ram0_reg_4) ? (((ram0_reg_i_29_n_0) ? (1'b1) : (~(ram0_reg_32)))) : (1'b0))));

  // Reconstructed LUT6: ram0_reg_i_32
  assign ram0_reg_i_32_n_0 = ((ram0_reg_31) ? (((ram0_reg_5) ? (((ram0_reg_i_94_n_0) ? (((ram0_reg_30[0]) ? (((ram0_reg_29) ? (1'b0) : (ram0_reg_3))) : (1'b0))) : (ram0_reg_3))) : (((ram0_reg_30[0]) ? (((ram0_reg_29) ? (1'b0) : (ram0_reg_3))) : (1'b0))))) : (ram0_reg_3));

  // Reconstructed LUT6: ram0_reg_i_36
  assign ram0_reg_i_36_n_0 = ((ram0_reg_i_25_1[7]) ? (((ap_enable_reg_pp1_iter1_reg) ? (ram0_reg_5) : (((data42[5]) ? (((ram0_reg_i_25_0[7]) ? (ram0_reg_5) : (((ram0_reg_i_103_n_0) ? (1'b0) : (ram0_reg_5))))) : (((ram0_reg_i_25_0[7]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (1'b0))) : (1'b0))))))) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (((data42[5]) ? (((ram0_reg_i_25_0[7]) ? (ram0_reg_5) : (((ram0_reg_i_103_n_0) ? (1'b0) : (ram0_reg_5))))) : (((ram0_reg_i_25_0[7]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT4: ram0_reg_i_4
  assign ram0_reg_i_4_n_0 = ((ram0_reg_28) ? (1'b1) : (((ram0_reg_4) ? (((ram0_reg_i_32_n_0) ? (1'b1) : (~(ram0_reg_27)))) : (1'b0))));

  // Reconstructed LUT6: ram0_reg_i_42
  assign ram0_reg_i_42_n_0 = ((ram0_reg_i_25_1[6]) ? (((ap_enable_reg_pp1_iter1_reg) ? (ram0_reg_5) : (((data42[4]) ? (((ram0_reg_i_25_0[6]) ? (ram0_reg_5) : (((ram0_reg_i_103_n_0) ? (1'b0) : (ram0_reg_5))))) : (((ram0_reg_i_25_0[6]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (1'b0))) : (1'b0))))))) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (((data42[4]) ? (((ram0_reg_i_25_0[6]) ? (ram0_reg_5) : (((ram0_reg_i_103_n_0) ? (1'b0) : (ram0_reg_5))))) : (((ram0_reg_i_25_0[6]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT6: ram0_reg_i_46
  assign ram0_reg_i_46_n_0 = ((ram0_reg_i_25_1[5]) ? (((ap_enable_reg_pp1_iter1_reg) ? (ram0_reg_5) : (((data42[3]) ? (((ram0_reg_i_25_0[5]) ? (ram0_reg_5) : (((ram0_reg_i_103_n_0) ? (1'b0) : (ram0_reg_5))))) : (((ram0_reg_i_25_0[5]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (1'b0))) : (1'b0))))))) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (((data42[3]) ? (((ram0_reg_i_25_0[5]) ? (ram0_reg_5) : (((ram0_reg_i_103_n_0) ? (1'b0) : (ram0_reg_5))))) : (((ram0_reg_i_25_0[5]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT6: ram0_reg_i_5
  assign ram0_reg_i_5_n_0 = ((ram0_reg_26) ? (1'b1) : (((ram0_reg_4) ? (((ram0_reg_3) ? (((ram0_reg_i_36_n_0) ? (1'b1) : (((ram0_reg_25) ? (~(ram0_reg_24)) : (1'b1))))) : (~(ram0_reg_24)))) : (1'b0))));

  // Reconstructed LUT6: ram0_reg_i_50
  assign ram0_reg_i_50_n_0 = ((ram0_reg_i_25_1[4]) ? (((ap_enable_reg_pp1_iter1_reg) ? (ram0_reg_5) : (((ram0_reg_i_25_0[4]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (((data42[2]) ? (ram0_reg_5) : (1'b0))))) : (((ram0_reg_i_103_n_0) ? (1'b0) : (((data42[2]) ? (ram0_reg_5) : (1'b0))))))))) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (((ram0_reg_i_25_0[4]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (((data42[2]) ? (ram0_reg_5) : (1'b0))))) : (((ram0_reg_i_103_n_0) ? (1'b0) : (((data42[2]) ? (ram0_reg_5) : (1'b0))))))))));

  // Reconstructed LUT6: ram0_reg_i_51
  assign ram0_reg_i_51_n_0 = ((ram0_reg_i_25_1[3]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_5)) : (((data42[1]) ? (((ram0_reg_i_25_0[3]) ? (~(ram0_reg_5)) : (((ram0_reg_i_103_n_0) ? (1'b1) : (~(ram0_reg_5)))))) : (((ram0_reg_i_25_0[3]) ? (((ram0_reg_i_103_n_0) ? (~(ram0_reg_5)) : (1'b1))) : (1'b1))))))) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b1) : (((data42[1]) ? (((ram0_reg_i_25_0[3]) ? (~(ram0_reg_5)) : (((ram0_reg_i_103_n_0) ? (1'b1) : (~(ram0_reg_5)))))) : (((ram0_reg_i_25_0[3]) ? (((ram0_reg_i_103_n_0) ? (~(ram0_reg_5)) : (1'b1))) : (1'b1))))))));

  // Reconstructed LUT4: ram0_reg_i_52
  assign esc_mul_ln215_reg_6908_reg_0_b3fe01c = ((mul_ln215_reg_6908) ? (((ram0_reg_40) ? (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b1) : (ram0_reg_39))) : (1'b0))) : (((ap_phi_mux_y_2_phi_fu_2389_p4) ? (1'b1) : (ram0_reg_39))));

  // Reconstructed LUT6: ram0_reg_i_53
  assign esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd = ((ram0_reg_45) ? (((mul_ln215_reg_6908) ? (((ram0_reg_44) ? (1'b1) : (ram0_reg_43))) : (1'b1))) : (((mul_ln215_reg_6908) ? (((ram0_reg_44) ? (1'b1) : (ram0_reg_43))) : (((ram0_reg_i_113_n_0) ? (1'b0) : (((ram0_reg_44) ? (1'b0) : (ram0_reg_i_112_n_0))))))));

  // Reconstructed LUT3: ram0_reg_i_54
  assign esc_mul_ln215_reg_6908_reg_0__1_55582ee = ((ram0_reg_42) ? (((mul_ln215_reg_6908) ? (~(ram0_reg_41)) : (1'b1))) : (((mul_ln215_reg_6908) ? (~(ram0_reg_41)) : (1'b0))));

  // Reconstructed LUT6: ram0_reg_i_58
  assign ram0_reg_i_58_n_0 = ((ram0_reg_i_25_1[2]) ? (((ram0_reg_i_25_0[2]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (((data42[0]) ? (ram0_reg_5) : (((ap_enable_reg_pp1_iter1_reg) ? (ram0_reg_5) : (1'b0))))))) : (((ram0_reg_i_103_n_0) ? (((ap_enable_reg_pp1_iter1_reg) ? (ram0_reg_5) : (1'b0))) : (((data42[0]) ? (ram0_reg_5) : (((ap_enable_reg_pp1_iter1_reg) ? (ram0_reg_5) : (1'b0))))))))) : (((ram0_reg_i_25_0[2]) ? (((ram0_reg_i_103_n_0) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (ram0_reg_5))) : (((data42[0]) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (ram0_reg_5))) : (1'b0))))) : (((ram0_reg_i_103_n_0) ? (1'b0) : (((data42[0]) ? (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (ram0_reg_5))) : (1'b0))))))));

  // Reconstructed LUT6: ram0_reg_i_6
  assign ram0_reg_i_6_n_0 = ((ram0_reg_4) ? (((ram0_reg_3) ? (((ram0_reg_i_42_n_0) ? (1'b1) : (((ram0_reg_23) ? (((ram0_reg_22) ? (ram0_reg_21) : (1'b1))) : (1'b1))))) : (((ram0_reg_22) ? (ram0_reg_21) : (1'b1))))) : (ram0_reg_21));

  // Reconstructed LUT6: ram0_reg_i_61
  assign ram0_reg_i_61_n_0 = ((ram0_reg_i_25_1[1]) ? (((ap_enable_reg_pp1_iter1_reg) ? (ram0_reg_5) : (((ram0_reg_i_25_0[1]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (((ram0_reg_11[1]) ? (ram0_reg_5) : (1'b0))))) : (((ram0_reg_i_103_n_0) ? (1'b0) : (((ram0_reg_11[1]) ? (ram0_reg_5) : (1'b0))))))))) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (((ram0_reg_i_25_0[1]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (((ram0_reg_11[1]) ? (ram0_reg_5) : (1'b0))))) : (((ram0_reg_i_103_n_0) ? (1'b0) : (((ram0_reg_11[1]) ? (ram0_reg_5) : (1'b0))))))))));

  // Reconstructed LUT6: ram0_reg_i_65
  assign ram0_reg_i_65_n_0 = ((ram0_reg_i_25_1[0]) ? (((ap_enable_reg_pp1_iter1_reg) ? (ram0_reg_5) : (((ram0_reg_i_25_0[0]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (((ram0_reg_11[0]) ? (ram0_reg_5) : (1'b0))))) : (((ram0_reg_i_103_n_0) ? (1'b0) : (((ram0_reg_11[0]) ? (ram0_reg_5) : (1'b0))))))))) : (((ap_enable_reg_pp1_iter1_reg) ? (1'b0) : (((ram0_reg_i_25_0[0]) ? (((ram0_reg_i_103_n_0) ? (ram0_reg_5) : (((ram0_reg_11[0]) ? (ram0_reg_5) : (1'b0))))) : (((ram0_reg_i_103_n_0) ? (1'b0) : (((ram0_reg_11[0]) ? (ram0_reg_5) : (1'b0))))))))));

  // Reconstructed LUT6: ram0_reg_i_67
  assign ram0_reg_i_67_n_0 = ((ram0_reg_7[5]) ? (((ram0_reg_7[3]) ? (((ram0_reg_7[1]) ? (((ram0_reg_7[0]) ? (((ram0_reg_7[2]) ? (ram0_reg_7[4]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT5: ram0_reg_i_68
  assign ram0_reg_i_68_n_0 = ((ram0_reg_7[4]) ? (((ram0_reg_7[2]) ? (((ram0_reg_7[0]) ? (((ram0_reg_7[1]) ? (ram0_reg_7[3]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: ram0_reg_i_7
  assign ram0_reg_i_7_n_0 = ((ram0_reg_4) ? (((ram0_reg_3) ? (((ram0_reg_i_46_n_0) ? (1'b1) : (((ram0_reg_20) ? (((ram0_reg_19) ? (ram0_reg_18) : (1'b1))) : (1'b1))))) : (((ram0_reg_19) ? (ram0_reg_18) : (1'b1))))) : (ram0_reg_18));

  // Reconstructed LUT6: ram0_reg_i_75
  assign ram0_reg_i_75_n_0 = ((ram0_reg_i_53_0[2]) ? (((ap_enable_reg_pp1_iter0) ? (((ram0_reg_i_25_0[10]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[10])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[10])) : (1'b1))))) : (((data42[8]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[10])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[10])) : (1'b1))))))) : (((data42[8]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[10])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[10])) : (1'b1))))));

  // Reconstructed LUT6: ram0_reg_i_8
  assign ram0_reg_i_8_n_0 = ((ram0_reg_4) ? (((ram0_reg_3) ? (((ram0_reg_i_50_n_0) ? (1'b1) : (((ram0_reg_17) ? (((ram0_reg_16) ? (ram0_reg_15) : (1'b1))) : (1'b1))))) : (((ram0_reg_16) ? (ram0_reg_15) : (1'b1))))) : (ram0_reg_15));

  // Reconstructed LUT6: ram0_reg_i_89
  assign ram0_reg_i_89_n_0 = ((ram0_reg_i_53_0[2]) ? (((ap_enable_reg_pp1_iter0) ? (((ram0_reg_i_25_0[9]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[9])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[9])) : (1'b1))))) : (((data42[7]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[9])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[9])) : (1'b1))))))) : (((data42[7]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[9])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[9])) : (1'b1))))));

  // Reconstructed LUT6: ram0_reg_i_94
  assign ram0_reg_i_94_n_0 = ((ram0_reg_i_53_0[2]) ? (((ap_enable_reg_pp1_iter0) ? (((ram0_reg_i_25_0[8]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[8])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[8])) : (1'b1))))) : (((data42[6]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[8])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[8])) : (1'b1))))))) : (((data42[6]) ? (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[8])) : (1'b0))) : (((ap_enable_reg_pp1_iter1_reg) ? (~(ram0_reg_i_25_1[8])) : (1'b1))))));

  // Reconstructed LUT6: ram0_reg_i_9__0
  assign ram0_reg_i_9__0_n_0 = ((esc_mul_ln215_reg_6908_reg_0__1_55582ee) ? (1'b1) : (((ram0_reg_4) ? (((esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd) ? (1'b1) : (((ram0_reg_3) ? (((esc_mul_ln215_reg_6908_reg_0_b3fe01c) ? (~(ram0_reg_i_51_n_0)) : (1'b1))) : (1'b0))))) : (1'b0))));

endmodule

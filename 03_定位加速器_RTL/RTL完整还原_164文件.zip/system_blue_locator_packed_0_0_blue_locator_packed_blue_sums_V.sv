// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_blue_sums_V
   (blue_sums_V_q1,
    D,
    ram_reg,
    esc_ap_CS_fsm_reg_60_4401d07 ,
    esc_ap_CS_fsm_reg_33_3728c13 ,
    esc_ap_CS_fsm_reg_48_486bf78 ,
    ap_enable_reg_pp3_iter0_reg_rep__1,
    esc_ap_CS_fsm_reg_52_1e1b2ce ,
    ap_enable_reg_pp3_iter1_reg,
    ap_enable_reg_pp3_iter0_reg_rep__1_0,
    esc_ap_CS_fsm_reg_46_ba5f378 ,
    esc_ap_CS_fsm_reg_35_69cfbc2 ,
    ap_enable_reg_pp3_iter0_reg_rep__2,
    ap_enable_reg_pp3_iter0_reg_rep__2_0,
    ap_enable_reg_pp3_iter0_reg_rep__2_1,
    esc_ap_CS_fsm_reg_35__0_74dd3b9 ,
    esc_ap_CS_fsm_reg_35__1_673f736 ,
    esc_ap_CS_fsm_reg_35__2_1eb8d38 ,
    esc_mul_ln215_reg_6908_reg_8_04f5661 ,
    esc_ap_CS_fsm_reg_35__3_270aca4 ,
    esc_mul_ln215_reg_6908_reg_10_5d8e8dd ,
    esc_mul_ln69_reg_6952_reg_0_1ad7a30 ,
    esc_mul_ln215_reg_6908_reg_0_b3fe01c ,
    esc_ap_CS_fsm_reg_40_a90f485 ,
    esc_ap_CS_fsm_reg_38_e2b4bee ,
    esc_ap_CS_fsm_reg_17_dedac0c ,
    esc_ap_CS_fsm_reg_19_bd70f8c ,
    esc_ap_CS_fsm_reg_35__4_7220096 ,
    esc_ap_CS_fsm_reg_41_dd30532 ,
    esc_ap_CS_fsm_reg_44_2431923 ,
    ap_enable_reg_pp3_iter0_reg_rep__2_2,
    ap_enable_reg_pp3_iter0_reg_rep,
    ap_enable_reg_pp3_iter0_reg_rep__1_1,
    ap_enable_reg_pp3_iter0_reg_rep__1_2,
    esc_ap_CS_fsm_reg_55_06ec471 ,
    ram_reg_0,
    esc_ap_CS_fsm_reg_44__0_351736b ,
    ap_enable_reg_pp3_iter0_reg_rep__1_3,
    esc_ap_CS_fsm_reg_54_3d44ae7 ,
    esc_mul_ln69_reg_6952_reg_5_9ff1ee6 ,
    esc_mul_ln69_reg_6952_reg_5__0_fb22d18 ,
    esc_ap_CS_fsm_reg_54__0_150e2e4 ,
    esc_ap_CS_fsm_reg_44__1_8810078 ,
    esc_mul_ln69_reg_6952_reg_4_189b418 ,
    esc_mul_ln69_reg_6952_reg_4__0_e53f4c6 ,
    esc_mul_ln69_reg_6952_reg_9_713209e ,
    esc_ap_CS_fsm_reg_44__2_bbd6c10 ,
    esc_mul_ln69_reg_6952_reg_10_dfe3d8c ,
    esc_mul_ln69_reg_6952_reg_9__0_96a57d4 ,
    esc_ap_CS_fsm_reg_45_350234a ,
    esc_ap_CS_fsm_reg_50_18ba0a7 ,
    esc_ap_CS_fsm_reg_51_0b023c1 ,
    esc_ap_CS_fsm_reg_43_1e97ec5 ,
    esc_ap_CS_fsm_reg_46__0_30ff7c9 ,
    ap_enable_reg_pp3_iter0_reg_rep__2_3,
    ap_enable_reg_pp3_iter0_reg_rep__2_4,
    ap_enable_reg_pp3_iter0_reg_rep__0,
    esc_ap_CS_fsm_reg_17__0_3991a9e ,
    esc_ap_CS_fsm_reg_47_6fd2b4b ,
    ap_enable_reg_pp3_iter0_reg_rep__1_4,
    esc_ap_CS_fsm_reg_22_3c49685 ,
    esc_ap_CS_fsm_reg_18_ff39e99 ,
    ap_enable_reg_pp3_iter0_reg_rep__2_5,
    esc_mul_ln69_reg_6952_reg_0__0_836ee7c ,
    esc_ap_CS_fsm_reg_36_d3028b0 ,
    esc_ap_CS_fsm_reg_55__0_cc9d24c ,
    ap_enable_reg_pp3_iter0_reg_rep__1_5,
    esc_ap_CS_fsm_reg_40__0_5fa6674 ,
    esc_ap_CS_fsm_reg_48__0_0aa522c ,
    esc_ap_CS_fsm_reg_53_f7fb3d3 ,
    ram_reg_1,
    ap_enable_reg_pp3_iter0_reg_rep_0,
    esc_ap_CS_fsm_reg_21_af57a65 ,
    esc_ap_CS_fsm_reg_25_a5aad2c ,
    esc_ap_CS_fsm_reg_34_4939b31 ,
    ap_enable_reg_pp3_iter0_reg_rep_1,
    esc_ap_CS_fsm_reg_27_5198e1b ,
    esc_ap_CS_fsm_reg_28_9946fb8 ,
    esc_ap_CS_fsm_reg_22__0_ff12f14 ,
    esc_ap_CS_fsm_reg_31_c30295b ,
    esc_ap_CS_fsm_reg_31__0_6ea5b12 ,
    esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ,
    esc_ap_CS_fsm_reg_43__0_1e7dad1 ,
    ap_enable_reg_pp3_iter0_reg_rep__1_6,
    esc_ap_CS_fsm_reg_42_9c7e09b ,
    esc_mul_ln215_reg_6908_reg_0__1_55582ee ,
    ram_reg_2,
    ram_reg_3,
    ram_reg_4,
    ram_reg_5,
    ram_reg_6,
    ram_reg_7,
    ram_reg_8,
    ram_reg_9,
    esc_ap_CS_fsm_reg_26_bc9d1aa ,
    ap_clk,
    WEA,
    WEBWE,
    zext_ln215_96_reg_8987_pp4_iter6_reg_reg,
    zext_ln215_97_reg_8962_pp4_iter5_reg_reg,
    Q,
    ap_enable_reg_pp4_iter6,
    ram_reg_10,
    ram_reg_11,
    ap_enable_reg_pp3_iter0,
    ram_reg_12,
    ram_reg_13,
    ram_reg_14,
    ram_reg_15,
    ram0_reg,
    mul_ln215_reg_6908,
    ram_reg_16,
    ram_reg_17,
    ram_reg_18,
    ram_reg_19,
    ram_reg_i_168,
    esc_reg_2530_reg_16_2370fa4 ,
    zext_ln215_93_reg_8977_pp4_iter6_reg_reg,
    zext_ln215_94_reg_8947_pp4_iter5_reg_reg,
    O,
    ram_reg_20,
    ram_reg_21,
    ram_reg_i_166,
    ram_reg_22,
    ram_reg_i_166_0,
    ram_reg_23,
    ram_reg_24,
    ram_reg_25,
    ram_reg_i_452,
    ram_reg_i_452_0,
    ram_reg_i_166_1,
    ram_reg_26,
    ram_reg_i_453,
    ap_enable_reg_pp4_iter7,
    ram0_reg_i_22,
    ram_reg_i_276,
    ram_reg_i_674,
    ram_reg_i_836,
    ram_reg_i_836_0,
    ram_reg_i_836_1,
    ram_reg_i_450,
    ram_reg_i_450_0,
    data20,
    ram_reg_i_452_1,
    ram_reg_i_452_2,
    ram_reg_i_452_3,
    icmp_ln89_reg_8917_pp4_iter7_reg,
    ram_reg_27,
    ram_reg_28,
    ram_reg_i_169,
    ram_reg_i_169_0,
    ram_reg_i_169_1,
    ram_reg_i_455,
    ram_reg_i_455_0,
    ram_reg_i_169_2,
    ram_reg_i_169_3,
    ram_reg_i_453_0,
    ram_reg_i_453_1,
    ram_reg_i_168_0,
    ram_reg_i_168_1,
    ram_reg_29,
    ram_reg_i_453_2,
    ram_reg_i_453_3,
    ram_reg_i_166_2,
    ram_reg_i_166_3,
    ram_reg_i_166_4,
    ram_reg_i_166_5,
    ram_reg_i_166_6,
    ram_reg_30,
    ram_reg_i_120__0,
    esc_ret_reg_9074_reg_17_e7f25af ,
    esc_add_ln208_reg_7057_reg_7_25a7af6 );
  output [16:0]blue_sums_V_q1;
  output [17:0]D;
  output [16:0]ram_reg;
  output esc_ap_CS_fsm_reg_60_4401d07 ;
  output esc_ap_CS_fsm_reg_33_3728c13 ;
  output esc_ap_CS_fsm_reg_48_486bf78 ;
  output ap_enable_reg_pp3_iter0_reg_rep__1;
  output esc_ap_CS_fsm_reg_52_1e1b2ce ;
  output ap_enable_reg_pp3_iter1_reg;
  output ap_enable_reg_pp3_iter0_reg_rep__1_0;
  output esc_ap_CS_fsm_reg_46_ba5f378 ;
  output esc_ap_CS_fsm_reg_35_69cfbc2 ;
  output ap_enable_reg_pp3_iter0_reg_rep__2;
  output ap_enable_reg_pp3_iter0_reg_rep__2_0;
  output ap_enable_reg_pp3_iter0_reg_rep__2_1;
  output esc_ap_CS_fsm_reg_35__0_74dd3b9 ;
  output esc_ap_CS_fsm_reg_35__1_673f736 ;
  output esc_ap_CS_fsm_reg_35__2_1eb8d38 ;
  output esc_mul_ln215_reg_6908_reg_8_04f5661 ;
  output esc_ap_CS_fsm_reg_35__3_270aca4 ;
  output esc_mul_ln215_reg_6908_reg_10_5d8e8dd ;
  output esc_mul_ln69_reg_6952_reg_0_1ad7a30 ;
  output esc_mul_ln215_reg_6908_reg_0_b3fe01c ;
  output esc_ap_CS_fsm_reg_40_a90f485 ;
  output esc_ap_CS_fsm_reg_38_e2b4bee ;
  output esc_ap_CS_fsm_reg_17_dedac0c ;
  output esc_ap_CS_fsm_reg_19_bd70f8c ;
  output esc_ap_CS_fsm_reg_35__4_7220096 ;
  output esc_ap_CS_fsm_reg_41_dd30532 ;
  output esc_ap_CS_fsm_reg_44_2431923 ;
  output ap_enable_reg_pp3_iter0_reg_rep__2_2;
  output ap_enable_reg_pp3_iter0_reg_rep;
  output ap_enable_reg_pp3_iter0_reg_rep__1_1;
  output ap_enable_reg_pp3_iter0_reg_rep__1_2;
  output esc_ap_CS_fsm_reg_55_06ec471 ;
  output [16:0]ram_reg_0;
  output esc_ap_CS_fsm_reg_44__0_351736b ;
  output ap_enable_reg_pp3_iter0_reg_rep__1_3;
  output esc_ap_CS_fsm_reg_54_3d44ae7 ;
  output esc_mul_ln69_reg_6952_reg_5_9ff1ee6 ;
  output esc_mul_ln69_reg_6952_reg_5__0_fb22d18 ;
  output esc_ap_CS_fsm_reg_54__0_150e2e4 ;
  output esc_ap_CS_fsm_reg_44__1_8810078 ;
  output esc_mul_ln69_reg_6952_reg_4_189b418 ;
  output esc_mul_ln69_reg_6952_reg_4__0_e53f4c6 ;
  output esc_mul_ln69_reg_6952_reg_9_713209e ;
  output esc_ap_CS_fsm_reg_44__2_bbd6c10 ;
  output esc_mul_ln69_reg_6952_reg_10_dfe3d8c ;
  output esc_mul_ln69_reg_6952_reg_9__0_96a57d4 ;
  output esc_ap_CS_fsm_reg_45_350234a ;
  output esc_ap_CS_fsm_reg_50_18ba0a7 ;
  output esc_ap_CS_fsm_reg_51_0b023c1 ;
  output esc_ap_CS_fsm_reg_43_1e97ec5 ;
  output esc_ap_CS_fsm_reg_46__0_30ff7c9 ;
  output ap_enable_reg_pp3_iter0_reg_rep__2_3;
  output ap_enable_reg_pp3_iter0_reg_rep__2_4;
  output ap_enable_reg_pp3_iter0_reg_rep__0;
  output esc_ap_CS_fsm_reg_17__0_3991a9e ;
  output esc_ap_CS_fsm_reg_47_6fd2b4b ;
  output ap_enable_reg_pp3_iter0_reg_rep__1_4;
  output esc_ap_CS_fsm_reg_22_3c49685 ;
  output esc_ap_CS_fsm_reg_18_ff39e99 ;
  output ap_enable_reg_pp3_iter0_reg_rep__2_5;
  output esc_mul_ln69_reg_6952_reg_0__0_836ee7c ;
  output esc_ap_CS_fsm_reg_36_d3028b0 ;
  output esc_ap_CS_fsm_reg_55__0_cc9d24c ;
  output ap_enable_reg_pp3_iter0_reg_rep__1_5;
  output esc_ap_CS_fsm_reg_40__0_5fa6674 ;
  output esc_ap_CS_fsm_reg_48__0_0aa522c ;
  output esc_ap_CS_fsm_reg_53_f7fb3d3 ;
  output [16:0]ram_reg_1;
  output ap_enable_reg_pp3_iter0_reg_rep_0;
  output esc_ap_CS_fsm_reg_21_af57a65 ;
  output esc_ap_CS_fsm_reg_25_a5aad2c ;
  output esc_ap_CS_fsm_reg_34_4939b31 ;
  output ap_enable_reg_pp3_iter0_reg_rep_1;
  output esc_ap_CS_fsm_reg_27_5198e1b ;
  output esc_ap_CS_fsm_reg_28_9946fb8 ;
  output esc_ap_CS_fsm_reg_22__0_ff12f14 ;
  output esc_ap_CS_fsm_reg_31_c30295b ;
  output esc_ap_CS_fsm_reg_31__0_6ea5b12 ;
  output esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ;
  output esc_ap_CS_fsm_reg_43__0_1e7dad1 ;
  output ap_enable_reg_pp3_iter0_reg_rep__1_6;
  output esc_ap_CS_fsm_reg_42_9c7e09b ;
  output esc_mul_ln215_reg_6908_reg_0__1_55582ee ;
  output [16:0]ram_reg_2;
  output [16:0]ram_reg_3;
  output [16:0]ram_reg_4;
  output [16:0]ram_reg_5;
  output [16:0]ram_reg_6;
  output [16:0]ram_reg_7;
  output [16:0]ram_reg_8;
  output [16:0]ram_reg_9;
  output esc_ap_CS_fsm_reg_26_bc9d1aa ;
  input ap_clk;
  input [0:0]WEA;
  input [0:0]WEBWE;
  input [10:0]zext_ln215_96_reg_8987_pp4_iter6_reg_reg;
  input [10:0]zext_ln215_97_reg_8962_pp4_iter5_reg_reg;
  input [43:0]Q;
  input ap_enable_reg_pp4_iter6;
  input [10:0]ram_reg_10;
  input ram_reg_11;
  input ap_enable_reg_pp3_iter0;
  input [16:0]ram_reg_12;
  input [16:0]ram_reg_13;
  input [16:0]ram_reg_14;
  input ram_reg_15;
  input ram0_reg;
  input [10:0]mul_ln215_reg_6908;
  input ram_reg_16;
  input [16:0]ram_reg_17;
  input ram_reg_18;
  input ram_reg_19;
  input [16:0]ram_reg_i_168;
  input esc_reg_2530_reg_16_2370fa4 ;
  input [10:0]zext_ln215_93_reg_8977_pp4_iter6_reg_reg;
  input [10:0]zext_ln215_94_reg_8947_pp4_iter5_reg_reg;
  input [0:0]O;
  input [16:0]ram_reg_20;
  input ram_reg_21;
  input [16:0]ram_reg_i_166;
  input [3:0]ram_reg_22;
  input [16:0]ram_reg_i_166_0;
  input [3:0]ram_reg_23;
  input [3:0]ram_reg_24;
  input [3:0]ram_reg_25;
  input [16:0]ram_reg_i_452;
  input [16:0]ram_reg_i_452_0;
  input [16:0]ram_reg_i_166_1;
  input ram_reg_26;
  input [16:0]ram_reg_i_453;
  input ap_enable_reg_pp4_iter7;
  input ram0_reg_i_22;
  input ram_reg_i_276;
  input [5:0]ram_reg_i_674;
  input [16:0]ram_reg_i_836;
  input [16:0]ram_reg_i_836_0;
  input [16:0]ram_reg_i_836_1;
  input [16:0]ram_reg_i_450;
  input [16:0]ram_reg_i_450_0;
  input [10:0]data20;
  input [16:0]ram_reg_i_452_1;
  input [16:0]ram_reg_i_452_2;
  input [16:0]ram_reg_i_452_3;
  input icmp_ln89_reg_8917_pp4_iter7_reg;
  input ram_reg_27;
  input [16:0]ram_reg_28;
  input [16:0]ram_reg_i_169;
  input [16:0]ram_reg_i_169_0;
  input [16:0]ram_reg_i_169_1;
  input [16:0]ram_reg_i_455;
  input [16:0]ram_reg_i_455_0;
  input [16:0]ram_reg_i_169_2;
  input [16:0]ram_reg_i_169_3;
  input [16:0]ram_reg_i_453_0;
  input [16:0]ram_reg_i_453_1;
  input [16:0]ram_reg_i_168_0;
  input [16:0]ram_reg_i_168_1;
  input ram_reg_29;
  input [16:0]ram_reg_i_453_2;
  input [16:0]ram_reg_i_453_3;
  input [16:0]ram_reg_i_166_2;
  input [16:0]ram_reg_i_166_3;
  input [16:0]ram_reg_i_166_4;
  input [16:0]ram_reg_i_166_5;
  input [16:0]ram_reg_i_166_6;
  input ram_reg_30;
  input ram_reg_i_120__0;
  input [16:0]esc_ret_reg_9074_reg_17_e7f25af ;
  input [7:0]esc_add_ln208_reg_7057_reg_7_25a7af6 ;

  wire [17:0]D;
  wire [0:0]O;
  wire [43:0]Q;
  wire [0:0]WEA;
  wire [0:0]WEBWE;
  wire [7:0]esc_add_ln208_reg_7057_reg_7_25a7af6 ;
  wire esc_ap_CS_fsm_reg_17_dedac0c ;
  wire esc_ap_CS_fsm_reg_17__0_3991a9e ;
  wire esc_ap_CS_fsm_reg_18_ff39e99 ;
  wire esc_ap_CS_fsm_reg_19_bd70f8c ;
  wire esc_ap_CS_fsm_reg_21_af57a65 ;
  wire esc_ap_CS_fsm_reg_22_3c49685 ;
  wire esc_ap_CS_fsm_reg_22__0_ff12f14 ;
  wire esc_ap_CS_fsm_reg_25_a5aad2c ;
  wire esc_ap_CS_fsm_reg_26_bc9d1aa ;
  wire esc_ap_CS_fsm_reg_27_5198e1b ;
  wire esc_ap_CS_fsm_reg_28_9946fb8 ;
  wire esc_ap_CS_fsm_reg_31_c30295b ;
  wire esc_ap_CS_fsm_reg_31__0_6ea5b12 ;
  wire esc_ap_CS_fsm_reg_33_3728c13 ;
  wire esc_ap_CS_fsm_reg_34_4939b31 ;
  wire esc_ap_CS_fsm_reg_35_69cfbc2 ;
  wire esc_ap_CS_fsm_reg_35__0_74dd3b9 ;
  wire esc_ap_CS_fsm_reg_35__1_673f736 ;
  wire esc_ap_CS_fsm_reg_35__2_1eb8d38 ;
  wire esc_ap_CS_fsm_reg_35__3_270aca4 ;
  wire esc_ap_CS_fsm_reg_35__4_7220096 ;
  wire esc_ap_CS_fsm_reg_36_d3028b0 ;
  wire esc_ap_CS_fsm_reg_38_e2b4bee ;
  wire esc_ap_CS_fsm_reg_40_a90f485 ;
  wire esc_ap_CS_fsm_reg_40__0_5fa6674 ;
  wire esc_ap_CS_fsm_reg_41_dd30532 ;
  wire esc_ap_CS_fsm_reg_42_9c7e09b ;
  wire esc_ap_CS_fsm_reg_43_1e97ec5 ;
  wire esc_ap_CS_fsm_reg_43__0_1e7dad1 ;
  wire esc_ap_CS_fsm_reg_44_2431923 ;
  wire esc_ap_CS_fsm_reg_44__0_351736b ;
  wire esc_ap_CS_fsm_reg_44__1_8810078 ;
  wire esc_ap_CS_fsm_reg_44__2_bbd6c10 ;
  wire esc_ap_CS_fsm_reg_45_350234a ;
  wire esc_ap_CS_fsm_reg_46_ba5f378 ;
  wire esc_ap_CS_fsm_reg_46__0_30ff7c9 ;
  wire esc_ap_CS_fsm_reg_47_6fd2b4b ;
  wire esc_ap_CS_fsm_reg_48_486bf78 ;
  wire esc_ap_CS_fsm_reg_48__0_0aa522c ;
  wire esc_ap_CS_fsm_reg_50_18ba0a7 ;
  wire esc_ap_CS_fsm_reg_51_0b023c1 ;
  wire esc_ap_CS_fsm_reg_52_1e1b2ce ;
  wire esc_ap_CS_fsm_reg_53_f7fb3d3 ;
  wire esc_ap_CS_fsm_reg_54_3d44ae7 ;
  wire esc_ap_CS_fsm_reg_54__0_150e2e4 ;
  wire esc_ap_CS_fsm_reg_55_06ec471 ;
  wire esc_ap_CS_fsm_reg_55__0_cc9d24c ;
  wire esc_ap_CS_fsm_reg_60_4401d07 ;
  wire ap_clk;
  wire ap_enable_reg_pp3_iter0;
  wire ap_enable_reg_pp3_iter0_reg_rep;
  wire ap_enable_reg_pp3_iter0_reg_rep_0;
  wire ap_enable_reg_pp3_iter0_reg_rep_1;
  wire ap_enable_reg_pp3_iter0_reg_rep__0;
  wire ap_enable_reg_pp3_iter0_reg_rep__1;
  wire ap_enable_reg_pp3_iter0_reg_rep__1_0;
  wire ap_enable_reg_pp3_iter0_reg_rep__1_1;
  wire ap_enable_reg_pp3_iter0_reg_rep__1_2;
  wire ap_enable_reg_pp3_iter0_reg_rep__1_3;
  wire ap_enable_reg_pp3_iter0_reg_rep__1_4;
  wire ap_enable_reg_pp3_iter0_reg_rep__1_5;
  wire ap_enable_reg_pp3_iter0_reg_rep__1_6;
  wire ap_enable_reg_pp3_iter0_reg_rep__2;
  wire ap_enable_reg_pp3_iter0_reg_rep__2_0;
  wire ap_enable_reg_pp3_iter0_reg_rep__2_1;
  wire ap_enable_reg_pp3_iter0_reg_rep__2_2;
  wire ap_enable_reg_pp3_iter0_reg_rep__2_3;
  wire ap_enable_reg_pp3_iter0_reg_rep__2_4;
  wire ap_enable_reg_pp3_iter0_reg_rep__2_5;
  wire ap_enable_reg_pp3_iter1_reg;
  wire ap_enable_reg_pp4_iter6;
  wire ap_enable_reg_pp4_iter7;
  wire [16:0]blue_sums_V_q1;
  wire [10:0]data20;
  wire icmp_ln89_reg_8917_pp4_iter7_reg;
  wire [10:0]mul_ln215_reg_6908;
  wire esc_mul_ln215_reg_6908_reg_0_b3fe01c ;
  wire esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ;
  wire esc_mul_ln215_reg_6908_reg_0__1_55582ee ;
  wire esc_mul_ln215_reg_6908_reg_10_5d8e8dd ;
  wire esc_mul_ln215_reg_6908_reg_8_04f5661 ;
  wire esc_mul_ln69_reg_6952_reg_0_1ad7a30 ;
  wire esc_mul_ln69_reg_6952_reg_0__0_836ee7c ;
  wire esc_mul_ln69_reg_6952_reg_10_dfe3d8c ;
  wire esc_mul_ln69_reg_6952_reg_4_189b418 ;
  wire esc_mul_ln69_reg_6952_reg_4__0_e53f4c6 ;
  wire esc_mul_ln69_reg_6952_reg_5_9ff1ee6 ;
  wire esc_mul_ln69_reg_6952_reg_5__0_fb22d18 ;
  wire esc_mul_ln69_reg_6952_reg_9_713209e ;
  wire esc_mul_ln69_reg_6952_reg_9__0_96a57d4 ;
  wire ram0_reg;
  wire ram0_reg_i_22;
  wire [16:0]ram_reg;
  wire [16:0]ram_reg_0;
  wire [16:0]ram_reg_1;
  wire [10:0]ram_reg_10;
  wire ram_reg_11;
  wire [16:0]ram_reg_12;
  wire [16:0]ram_reg_13;
  wire [16:0]ram_reg_14;
  wire ram_reg_15;
  wire ram_reg_16;
  wire [16:0]ram_reg_17;
  wire ram_reg_18;
  wire ram_reg_19;
  wire [16:0]ram_reg_2;
  wire [16:0]ram_reg_20;
  wire ram_reg_21;
  wire [3:0]ram_reg_22;
  wire [3:0]ram_reg_23;
  wire [3:0]ram_reg_24;
  wire [3:0]ram_reg_25;
  wire ram_reg_26;
  wire ram_reg_27;
  wire [16:0]ram_reg_28;
  wire ram_reg_29;
  wire [16:0]ram_reg_3;
  wire ram_reg_30;
  wire [16:0]ram_reg_4;
  wire [16:0]ram_reg_5;
  wire [16:0]ram_reg_6;
  wire [16:0]ram_reg_7;
  wire [16:0]ram_reg_8;
  wire [16:0]ram_reg_9;
  wire ram_reg_i_120__0;
  wire [16:0]ram_reg_i_166;
  wire [16:0]ram_reg_i_166_0;
  wire [16:0]ram_reg_i_166_1;
  wire [16:0]ram_reg_i_166_2;
  wire [16:0]ram_reg_i_166_3;
  wire [16:0]ram_reg_i_166_4;
  wire [16:0]ram_reg_i_166_5;
  wire [16:0]ram_reg_i_166_6;
  wire [16:0]ram_reg_i_168;
  wire [16:0]ram_reg_i_168_0;
  wire [16:0]ram_reg_i_168_1;
  wire [16:0]ram_reg_i_169;
  wire [16:0]ram_reg_i_169_0;
  wire [16:0]ram_reg_i_169_1;
  wire [16:0]ram_reg_i_169_2;
  wire [16:0]ram_reg_i_169_3;
  wire ram_reg_i_276;
  wire [16:0]ram_reg_i_450;
  wire [16:0]ram_reg_i_450_0;
  wire [16:0]ram_reg_i_452;
  wire [16:0]ram_reg_i_452_0;
  wire [16:0]ram_reg_i_452_1;
  wire [16:0]ram_reg_i_452_2;
  wire [16:0]ram_reg_i_452_3;
  wire [16:0]ram_reg_i_453;
  wire [16:0]ram_reg_i_453_0;
  wire [16:0]ram_reg_i_453_1;
  wire [16:0]ram_reg_i_453_2;
  wire [16:0]ram_reg_i_453_3;
  wire [16:0]ram_reg_i_455;
  wire [16:0]ram_reg_i_455_0;
  wire [5:0]ram_reg_i_674;
  wire [16:0]ram_reg_i_836;
  wire [16:0]ram_reg_i_836_0;
  wire [16:0]ram_reg_i_836_1;
  wire esc_reg_2530_reg_16_2370fa4 ;
  wire [16:0]esc_ret_reg_9074_reg_17_e7f25af ;
  wire [10:0]zext_ln215_93_reg_8977_pp4_iter6_reg_reg;
  wire [10:0]zext_ln215_94_reg_8947_pp4_iter5_reg_reg;
  wire [10:0]zext_ln215_96_reg_8987_pp4_iter6_reg_reg;
  wire [10:0]zext_ln215_97_reg_8962_pp4_iter5_reg_reg;

  system_blue_locator_packed_0_0_blue_locator_packed_blue_sums_V_ram_8 blue_locator_packed_blue_sums_V_ram_U
       (.D(D),
        .DOADO(blue_sums_V_q1[15:0]),
        .DOPADOP(blue_sums_V_q1[16]),
        .O(O),
        .Q(Q),
        .WEA(WEA),
        .WEBWE(WEBWE),
        .esc_add_ln208_reg_7057_reg_7_25a7af6 (esc_add_ln208_reg_7057_reg_7_25a7af6 ),
        .esc_ap_CS_fsm_reg_17_dedac0c (esc_ap_CS_fsm_reg_17_dedac0c ),
        .esc_ap_CS_fsm_reg_17__0_3991a9e (esc_ap_CS_fsm_reg_17__0_3991a9e ),
        .esc_ap_CS_fsm_reg_18_ff39e99 (esc_ap_CS_fsm_reg_18_ff39e99 ),
        .esc_ap_CS_fsm_reg_19_bd70f8c (esc_ap_CS_fsm_reg_19_bd70f8c ),
        .esc_ap_CS_fsm_reg_21_af57a65 (esc_ap_CS_fsm_reg_21_af57a65 ),
        .esc_ap_CS_fsm_reg_22_3c49685 (esc_ap_CS_fsm_reg_22_3c49685 ),
        .esc_ap_CS_fsm_reg_22__0_ff12f14 (esc_ap_CS_fsm_reg_22__0_ff12f14 ),
        .esc_ap_CS_fsm_reg_25_a5aad2c (esc_ap_CS_fsm_reg_25_a5aad2c ),
        .esc_ap_CS_fsm_reg_26_bc9d1aa (esc_ap_CS_fsm_reg_26_bc9d1aa ),
        .esc_ap_CS_fsm_reg_27_5198e1b (esc_ap_CS_fsm_reg_27_5198e1b ),
        .esc_ap_CS_fsm_reg_28_9946fb8 (esc_ap_CS_fsm_reg_28_9946fb8 ),
        .esc_ap_CS_fsm_reg_31_c30295b (esc_ap_CS_fsm_reg_31_c30295b ),
        .esc_ap_CS_fsm_reg_31__0_6ea5b12 (esc_ap_CS_fsm_reg_31__0_6ea5b12 ),
        .esc_ap_CS_fsm_reg_33_3728c13 (esc_ap_CS_fsm_reg_33_3728c13 ),
        .esc_ap_CS_fsm_reg_34_4939b31 (esc_ap_CS_fsm_reg_34_4939b31 ),
        .esc_ap_CS_fsm_reg_35_69cfbc2 (esc_ap_CS_fsm_reg_35_69cfbc2 ),
        .esc_ap_CS_fsm_reg_35__0_74dd3b9 (esc_ap_CS_fsm_reg_35__0_74dd3b9 ),
        .esc_ap_CS_fsm_reg_35__1_673f736 (esc_ap_CS_fsm_reg_35__1_673f736 ),
        .esc_ap_CS_fsm_reg_35__2_1eb8d38 (esc_ap_CS_fsm_reg_35__2_1eb8d38 ),
        .esc_ap_CS_fsm_reg_35__3_270aca4 (esc_ap_CS_fsm_reg_35__3_270aca4 ),
        .esc_ap_CS_fsm_reg_35__4_7220096 (esc_ap_CS_fsm_reg_35__4_7220096 ),
        .esc_ap_CS_fsm_reg_36_d3028b0 (esc_ap_CS_fsm_reg_36_d3028b0 ),
        .esc_ap_CS_fsm_reg_38_e2b4bee (esc_ap_CS_fsm_reg_38_e2b4bee ),
        .esc_ap_CS_fsm_reg_40_a90f485 (esc_ap_CS_fsm_reg_40_a90f485 ),
        .esc_ap_CS_fsm_reg_40__0_5fa6674 (esc_ap_CS_fsm_reg_40__0_5fa6674 ),
        .esc_ap_CS_fsm_reg_41_dd30532 (esc_ap_CS_fsm_reg_41_dd30532 ),
        .esc_ap_CS_fsm_reg_42_9c7e09b (esc_ap_CS_fsm_reg_42_9c7e09b ),
        .esc_ap_CS_fsm_reg_43_1e97ec5 (esc_ap_CS_fsm_reg_43_1e97ec5 ),
        .esc_ap_CS_fsm_reg_43__0_1e7dad1 (esc_ap_CS_fsm_reg_43__0_1e7dad1 ),
        .esc_ap_CS_fsm_reg_44_2431923 (esc_ap_CS_fsm_reg_44_2431923 ),
        .esc_ap_CS_fsm_reg_44__0_351736b (esc_ap_CS_fsm_reg_44__0_351736b ),
        .esc_ap_CS_fsm_reg_44__1_8810078 (esc_ap_CS_fsm_reg_44__1_8810078 ),
        .esc_ap_CS_fsm_reg_44__2_bbd6c10 (esc_ap_CS_fsm_reg_44__2_bbd6c10 ),
        .esc_ap_CS_fsm_reg_45_350234a (esc_ap_CS_fsm_reg_45_350234a ),
        .esc_ap_CS_fsm_reg_46_ba5f378 (esc_ap_CS_fsm_reg_46_ba5f378 ),
        .esc_ap_CS_fsm_reg_46__0_30ff7c9 (esc_ap_CS_fsm_reg_46__0_30ff7c9 ),
        .esc_ap_CS_fsm_reg_47_6fd2b4b (esc_ap_CS_fsm_reg_47_6fd2b4b ),
        .esc_ap_CS_fsm_reg_48_486bf78 (esc_ap_CS_fsm_reg_48_486bf78 ),
        .esc_ap_CS_fsm_reg_48__0_0aa522c (esc_ap_CS_fsm_reg_48__0_0aa522c ),
        .esc_ap_CS_fsm_reg_50_18ba0a7 (esc_ap_CS_fsm_reg_50_18ba0a7 ),
        .esc_ap_CS_fsm_reg_51_0b023c1 (esc_ap_CS_fsm_reg_51_0b023c1 ),
        .esc_ap_CS_fsm_reg_52_1e1b2ce (esc_ap_CS_fsm_reg_52_1e1b2ce ),
        .esc_ap_CS_fsm_reg_53_f7fb3d3 (esc_ap_CS_fsm_reg_53_f7fb3d3 ),
        .esc_ap_CS_fsm_reg_54_3d44ae7 (esc_ap_CS_fsm_reg_54_3d44ae7 ),
        .esc_ap_CS_fsm_reg_54__0_150e2e4 (esc_ap_CS_fsm_reg_54__0_150e2e4 ),
        .esc_ap_CS_fsm_reg_55_06ec471 (esc_ap_CS_fsm_reg_55_06ec471 ),
        .esc_ap_CS_fsm_reg_55__0_cc9d24c (esc_ap_CS_fsm_reg_55__0_cc9d24c ),
        .esc_ap_CS_fsm_reg_60_4401d07 (esc_ap_CS_fsm_reg_60_4401d07 ),
        .ap_clk(ap_clk),
        .ap_enable_reg_pp3_iter0(ap_enable_reg_pp3_iter0),
        .ap_enable_reg_pp3_iter0_reg_rep(ap_enable_reg_pp3_iter0_reg_rep),
        .ap_enable_reg_pp3_iter0_reg_rep_0(ap_enable_reg_pp3_iter0_reg_rep_0),
        .ap_enable_reg_pp3_iter0_reg_rep_1(ap_enable_reg_pp3_iter0_reg_rep_1),
        .ap_enable_reg_pp3_iter0_reg_rep__0(ap_enable_reg_pp3_iter0_reg_rep__0),
        .ap_enable_reg_pp3_iter0_reg_rep__1(ap_enable_reg_pp3_iter0_reg_rep__1),
        .ap_enable_reg_pp3_iter0_reg_rep__1_0(ap_enable_reg_pp3_iter0_reg_rep__1_0),
        .ap_enable_reg_pp3_iter0_reg_rep__1_1(ap_enable_reg_pp3_iter0_reg_rep__1_1),
        .ap_enable_reg_pp3_iter0_reg_rep__1_2(ap_enable_reg_pp3_iter0_reg_rep__1_2),
        .ap_enable_reg_pp3_iter0_reg_rep__1_3(ap_enable_reg_pp3_iter0_reg_rep__1_3),
        .ap_enable_reg_pp3_iter0_reg_rep__1_4(ap_enable_reg_pp3_iter0_reg_rep__1_4),
        .ap_enable_reg_pp3_iter0_reg_rep__1_5(ap_enable_reg_pp3_iter0_reg_rep__1_5),
        .ap_enable_reg_pp3_iter0_reg_rep__1_6(ap_enable_reg_pp3_iter0_reg_rep__1_6),
        .ap_enable_reg_pp3_iter0_reg_rep__2(ap_enable_reg_pp3_iter0_reg_rep__2),
        .ap_enable_reg_pp3_iter0_reg_rep__2_0(ap_enable_reg_pp3_iter0_reg_rep__2_0),
        .ap_enable_reg_pp3_iter0_reg_rep__2_1(ap_enable_reg_pp3_iter0_reg_rep__2_1),
        .ap_enable_reg_pp3_iter0_reg_rep__2_2(ap_enable_reg_pp3_iter0_reg_rep__2_2),
        .ap_enable_reg_pp3_iter0_reg_rep__2_3(ap_enable_reg_pp3_iter0_reg_rep__2_3),
        .ap_enable_reg_pp3_iter0_reg_rep__2_4(ap_enable_reg_pp3_iter0_reg_rep__2_4),
        .ap_enable_reg_pp3_iter0_reg_rep__2_5(ap_enable_reg_pp3_iter0_reg_rep__2_5),
        .ap_enable_reg_pp3_iter1_reg(ap_enable_reg_pp3_iter1_reg),
        .ap_enable_reg_pp4_iter6(ap_enable_reg_pp4_iter6),
        .ap_enable_reg_pp4_iter7(ap_enable_reg_pp4_iter7),
        .data20(data20),
        .icmp_ln89_reg_8917_pp4_iter7_reg(icmp_ln89_reg_8917_pp4_iter7_reg),
        .mul_ln215_reg_6908(mul_ln215_reg_6908),
        .esc_mul_ln215_reg_6908_reg_0_b3fe01c (esc_mul_ln215_reg_6908_reg_0_b3fe01c ),
        .esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd (esc_mul_ln215_reg_6908_reg_0__0_3ecc2bd ),
        .esc_mul_ln215_reg_6908_reg_0__1_55582ee (esc_mul_ln215_reg_6908_reg_0__1_55582ee ),
        .esc_mul_ln215_reg_6908_reg_10_5d8e8dd (esc_mul_ln215_reg_6908_reg_10_5d8e8dd ),
        .esc_mul_ln215_reg_6908_reg_8_04f5661 (esc_mul_ln215_reg_6908_reg_8_04f5661 ),
        .esc_mul_ln69_reg_6952_reg_0_1ad7a30 (esc_mul_ln69_reg_6952_reg_0_1ad7a30 ),
        .esc_mul_ln69_reg_6952_reg_0__0_836ee7c (esc_mul_ln69_reg_6952_reg_0__0_836ee7c ),
        .esc_mul_ln69_reg_6952_reg_10_dfe3d8c (esc_mul_ln69_reg_6952_reg_10_dfe3d8c ),
        .esc_mul_ln69_reg_6952_reg_4_189b418 (esc_mul_ln69_reg_6952_reg_4_189b418 ),
        .esc_mul_ln69_reg_6952_reg_4__0_e53f4c6 (esc_mul_ln69_reg_6952_reg_4__0_e53f4c6 ),
        .esc_mul_ln69_reg_6952_reg_5_9ff1ee6 (esc_mul_ln69_reg_6952_reg_5_9ff1ee6 ),
        .esc_mul_ln69_reg_6952_reg_5__0_fb22d18 (esc_mul_ln69_reg_6952_reg_5__0_fb22d18 ),
        .esc_mul_ln69_reg_6952_reg_9_713209e (esc_mul_ln69_reg_6952_reg_9_713209e ),
        .esc_mul_ln69_reg_6952_reg_9__0_96a57d4 (esc_mul_ln69_reg_6952_reg_9__0_96a57d4 ),
        .ram0_reg(ram0_reg),
        .ram0_reg_i_22(ram0_reg_i_22),
        .ram_reg_0(ram_reg),
        .ram_reg_1(ram_reg_0),
        .ram_reg_10(ram_reg_9),
        .ram_reg_11(ram_reg_10),
        .ram_reg_12(ram_reg_11),
        .ram_reg_13(ram_reg_12),
        .ram_reg_14(ram_reg_13),
        .ram_reg_15(ram_reg_14),
        .ram_reg_16(ram_reg_15),
        .ram_reg_17(ram_reg_16),
        .ram_reg_18(ram_reg_17),
        .ram_reg_19(ram_reg_18),
        .ram_reg_2(ram_reg_1),
        .ram_reg_20(ram_reg_19),
        .ram_reg_21(ram_reg_20),
        .ram_reg_22(ram_reg_21),
        .ram_reg_23(ram_reg_22),
        .ram_reg_24(ram_reg_23),
        .ram_reg_25(ram_reg_24),
        .ram_reg_26(ram_reg_25),
        .ram_reg_27(ram_reg_26),
        .ram_reg_28(ram_reg_27),
        .ram_reg_29(ram_reg_28),
        .ram_reg_3(ram_reg_2),
        .ram_reg_30(ram_reg_29),
        .ram_reg_31(ram_reg_30),
        .ram_reg_4(ram_reg_3),
        .ram_reg_5(ram_reg_4),
        .ram_reg_6(ram_reg_5),
        .ram_reg_7(ram_reg_6),
        .ram_reg_8(ram_reg_7),
        .ram_reg_9(ram_reg_8),
        .ram_reg_i_120__0_0(ram_reg_i_120__0),
        .ram_reg_i_166_0(ram_reg_i_166),
        .ram_reg_i_166_1(ram_reg_i_166_0),
        .ram_reg_i_166_2(ram_reg_i_166_1),
        .ram_reg_i_166_3(ram_reg_i_166_2),
        .ram_reg_i_166_4(ram_reg_i_166_3),
        .ram_reg_i_166_5(ram_reg_i_166_4),
        .ram_reg_i_166_6(ram_reg_i_166_5),
        .ram_reg_i_166_7(ram_reg_i_166_6),
        .ram_reg_i_168_0(ram_reg_i_168),
        .ram_reg_i_168_1(ram_reg_i_168_0),
        .ram_reg_i_168_2(ram_reg_i_168_1),
        .ram_reg_i_169_0(ram_reg_i_169),
        .ram_reg_i_169_1(ram_reg_i_169_0),
        .ram_reg_i_169_2(ram_reg_i_169_1),
        .ram_reg_i_169_3(ram_reg_i_169_2),
        .ram_reg_i_169_4(ram_reg_i_169_3),
        .ram_reg_i_276_0(ram_reg_i_276),
        .ram_reg_i_450_0(ram_reg_i_450),
        .ram_reg_i_450_1(ram_reg_i_450_0),
        .ram_reg_i_452_0(ram_reg_i_452),
        .ram_reg_i_452_1(ram_reg_i_452_0),
        .ram_reg_i_452_2(ram_reg_i_452_1),
        .ram_reg_i_452_3(ram_reg_i_452_2),
        .ram_reg_i_452_4(ram_reg_i_452_3),
        .ram_reg_i_453_0(ram_reg_i_453),
        .ram_reg_i_453_1(ram_reg_i_453_0),
        .ram_reg_i_453_2(ram_reg_i_453_1),
        .ram_reg_i_453_3(ram_reg_i_453_2),
        .ram_reg_i_453_4(ram_reg_i_453_3),
        .ram_reg_i_455_0(ram_reg_i_455),
        .ram_reg_i_455_1(ram_reg_i_455_0),
        .ram_reg_i_674_0(ram_reg_i_674),
        .ram_reg_i_836_0(ram_reg_i_836),
        .ram_reg_i_836_1(ram_reg_i_836_0),
        .ram_reg_i_836_2(ram_reg_i_836_1),
        .esc_reg_2530_reg_16_2370fa4 (esc_reg_2530_reg_16_2370fa4 ),
        .esc_ret_reg_9074_reg_17_e7f25af (esc_ret_reg_9074_reg_17_e7f25af ),
        .zext_ln215_93_reg_8977_pp4_iter6_reg_reg(zext_ln215_93_reg_8977_pp4_iter6_reg_reg),
        .zext_ln215_94_reg_8947_pp4_iter5_reg_reg(zext_ln215_94_reg_8947_pp4_iter5_reg_reg),
        .zext_ln215_96_reg_8987_pp4_iter6_reg_reg(zext_ln215_96_reg_8987_pp4_iter6_reg_reg),
        .zext_ln215_97_reg_8962_pp4_iter5_reg_reg(zext_ln215_97_reg_8962_pp4_iter5_reg_reg));
endmodule

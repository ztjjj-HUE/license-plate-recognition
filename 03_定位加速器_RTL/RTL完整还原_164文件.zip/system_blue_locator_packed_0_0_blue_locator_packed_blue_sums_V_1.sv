// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_blue_sums_V_1
   (edge_sums_V_q1,
    WEA,
    WEBWE,
    D,
    ram_reg,
    esc_ap_CS_fsm_reg_54_3d44ae7 ,
    esc_ap_CS_fsm_reg_15_c4b990a ,
    ram_reg_0,
    esc_ap_CS_fsm_reg_55_06ec471 ,
    esc_ap_CS_fsm_reg_45_350234a ,
    esc_ap_CS_fsm_reg_50_18ba0a7 ,
    esc_x_1_reg_2374_reg_1_abb1053 ,
    ram_reg_1,
    ap_enable_reg_pp3_iter0_reg_rep__0,
    ram_reg_2,
    ram_reg_3,
    ram_reg_4,
    ram_reg_5,
    ram_reg_6,
    ram_reg_7,
    ram_reg_8,
    ram_reg_9,
    ap_clk,
    Q,
    ram_reg_10,
    ap_enable_reg_pp4_iter0,
    esc_reg_2525_reg_0_b7796ac ,
    ram_reg_11,
    ram_reg_12,
    ram_reg_13,
    ram_reg_14,
    ram_reg_15,
    ram_reg_16,
    ram_reg_17,
    ap_enable_reg_pp3_iter0,
    ram_reg_18,
    ram_reg_19,
    ram_reg_20,
    ram_reg_21,
    ram_reg_22,
    ram_reg_23,
    ram_reg_24,
    ram_reg_25,
    ram_reg_26,
    ram_reg_27,
    ram_reg_28,
    ram_reg_29,
    ram_reg_30,
    ram_reg_i_132__0,
    ram_reg_31,
    ram_reg_i_591,
    ap_enable_reg_pp4_iter1,
    ram_reg_32,
    ram_reg_33,
    esc_reg_2535_reg_16_71a81d1 ,
    ram_reg_34,
    ram_reg_35,
    ram_reg_36,
    ram_reg_37,
    ram_reg_38,
    ram_reg_39,
    ram_reg_40,
    ram_reg_41,
    ram_reg_42,
    ram_reg_43,
    ram_reg_44,
    ram_reg_45,
    ram_reg_46,
    ram_reg_47,
    ram_reg_48,
    O,
    ram_reg_49,
    ram_reg_50,
    ram_reg_i_130,
    ram_reg_51,
    ram_reg_i_130_0,
    ram_reg_52,
    ram_reg_53,
    ram_reg_54,
    ram_reg_i_130_1,
    ram_reg_55,
    ram_reg_56,
    ram_reg_57,
    ram_reg_58,
    ram_reg_i_268,
    ram_reg_i_268_0,
    ram_reg_i_262,
    ram_reg_i_262_0,
    ram_reg_i_384__0,
    ram_reg_i_384__0_0,
    ram_reg_i_384__0_1,
    ram_reg_59,
    ram_reg_60,
    ram_reg_i_213,
    ram_reg_i_265,
    ram_reg_i_265_0,
    ram_reg_i_265_1,
    ram_reg_61,
    icmp_ln89_reg_8917_pp4_iter1_reg,
    ram_reg_i_132__0_0,
    ram_reg_62,
    ram_reg_i_132__0_1,
    ram_reg_i_128__0,
    ram_reg_i_266__0,
    ram_reg_i_261__0,
    ram_reg_i_132__0_2,
    ram_reg_i_266__0_0,
    ram_reg_i_266__0_1,
    ram_reg_i_94,
    ram_reg_i_389,
    ram_reg_i_259,
    ram_reg_i_389_0,
    ram_reg_i_389_1,
    ram_reg_i_268_1,
    ram_reg_i_268_2,
    ram_reg_i_389_2,
    ram_reg_i_132__0_3,
    ram_reg_i_389_3,
    ram_reg_i_266__0_2,
    ram_reg_i_266__0_3,
    ram_reg_i_258__0,
    ram_reg_i_258__0_0,
    ram_reg_i_130_2,
    ram_reg_i_130_3,
    ram_reg_i_130_4,
    ram_reg_i_130_5,
    ram_reg_i_130_6,
    ram_reg_i_265_2,
    ram_reg_i_265_3,
    ram_reg_i_265_4,
    esc_ret_3_reg_9002_reg_17_3a058af ,
    esc_add_ln208_1_reg_7062_reg_7_fda81fb );
  output [16:0]edge_sums_V_q1;
  output [0:0]WEA;
  output [0:0]WEBWE;
  output [17:0]D;
  output [16:0]ram_reg;
  output esc_ap_CS_fsm_reg_54_3d44ae7 ;
  output esc_ap_CS_fsm_reg_15_c4b990a ;
  output [16:0]ram_reg_0;
  output esc_ap_CS_fsm_reg_55_06ec471 ;
  output esc_ap_CS_fsm_reg_45_350234a ;
  output esc_ap_CS_fsm_reg_50_18ba0a7 ;
  output esc_x_1_reg_2374_reg_1_abb1053 ;
  output [16:0]ram_reg_1;
  output ap_enable_reg_pp3_iter0_reg_rep__0;
  output [16:0]ram_reg_2;
  output [16:0]ram_reg_3;
  output [16:0]ram_reg_4;
  output [16:0]ram_reg_5;
  output [16:0]ram_reg_6;
  output [16:0]ram_reg_7;
  output [16:0]ram_reg_8;
  output [16:0]ram_reg_9;
  input ap_clk;
  input [10:0]Q;
  input [10:0]ram_reg_10;
  input ap_enable_reg_pp4_iter0;
  input [33:0]esc_reg_2525_reg_0_b7796ac ;
  input ram_reg_11;
  input [16:0]ram_reg_12;
  input ram_reg_13;
  input ram_reg_14;
  input [16:0]ram_reg_15;
  input ram_reg_16;
  input [16:0]ram_reg_17;
  input ap_enable_reg_pp3_iter0;
  input ram_reg_18;
  input ram_reg_19;
  input ram_reg_20;
  input ram_reg_21;
  input ram_reg_22;
  input ram_reg_23;
  input ram_reg_24;
  input ram_reg_25;
  input ram_reg_26;
  input ram_reg_27;
  input ram_reg_28;
  input ram_reg_29;
  input ram_reg_30;
  input [16:0]ram_reg_i_132__0;
  input ram_reg_31;
  input ram_reg_i_591;
  input ap_enable_reg_pp4_iter1;
  input ram_reg_32;
  input ram_reg_33;
  input esc_reg_2535_reg_16_71a81d1 ;
  input ram_reg_34;
  input [10:0]ram_reg_35;
  input [10:0]ram_reg_36;
  input ram_reg_37;
  input ram_reg_38;
  input ram_reg_39;
  input ram_reg_40;
  input ram_reg_41;
  input ram_reg_42;
  input ram_reg_43;
  input ram_reg_44;
  input ram_reg_45;
  input ram_reg_46;
  input ram_reg_47;
  input ram_reg_48;
  input [0:0]O;
  input [16:0]ram_reg_49;
  input ram_reg_50;
  input [16:0]ram_reg_i_130;
  input [3:0]ram_reg_51;
  input [16:0]ram_reg_i_130_0;
  input [3:0]ram_reg_52;
  input [3:0]ram_reg_53;
  input [3:0]ram_reg_54;
  input [16:0]ram_reg_i_130_1;
  input ram_reg_55;
  input ram_reg_56;
  input ram_reg_57;
  input ram_reg_58;
  input [16:0]ram_reg_i_268;
  input ram_reg_i_268_0;
  input [16:0]ram_reg_i_262;
  input [16:0]ram_reg_i_262_0;
  input [16:0]ram_reg_i_384__0;
  input [16:0]ram_reg_i_384__0_0;
  input [16:0]ram_reg_i_384__0_1;
  input ram_reg_59;
  input ram_reg_60;
  input ram_reg_i_213;
  input [16:0]ram_reg_i_265;
  input [16:0]ram_reg_i_265_0;
  input [16:0]ram_reg_i_265_1;
  input [5:0]ram_reg_61;
  input icmp_ln89_reg_8917_pp4_iter1_reg;
  input [16:0]ram_reg_i_132__0_0;
  input ram_reg_62;
  input [16:0]ram_reg_i_132__0_1;
  input ram_reg_i_128__0;
  input [16:0]ram_reg_i_266__0;
  input ram_reg_i_261__0;
  input [16:0]ram_reg_i_132__0_2;
  input [16:0]ram_reg_i_266__0_0;
  input [16:0]ram_reg_i_266__0_1;
  input ram_reg_i_94;
  input [16:0]ram_reg_i_389;
  input ram_reg_i_259;
  input [16:0]ram_reg_i_389_0;
  input [16:0]ram_reg_i_389_1;
  input [16:0]ram_reg_i_268_1;
  input [16:0]ram_reg_i_268_2;
  input [16:0]ram_reg_i_389_2;
  input ram_reg_i_132__0_3;
  input [16:0]ram_reg_i_389_3;
  input [16:0]ram_reg_i_266__0_2;
  input [16:0]ram_reg_i_266__0_3;
  input ram_reg_i_258__0;
  input ram_reg_i_258__0_0;
  input [16:0]ram_reg_i_130_2;
  input [16:0]ram_reg_i_130_3;
  input [16:0]ram_reg_i_130_4;
  input [16:0]ram_reg_i_130_5;
  input [16:0]ram_reg_i_130_6;
  input [16:0]ram_reg_i_265_2;
  input [16:0]ram_reg_i_265_3;
  input ram_reg_i_265_4;
  input [16:0]esc_ret_3_reg_9002_reg_17_3a058af ;
  input [7:0]esc_add_ln208_1_reg_7062_reg_7_fda81fb ;

  wire [17:0]D;
  wire [0:0]O;
  wire [10:0]Q;
  wire [0:0]WEA;
  wire [0:0]WEBWE;
  wire [7:0]esc_add_ln208_1_reg_7062_reg_7_fda81fb ;
  wire esc_ap_CS_fsm_reg_15_c4b990a ;
  wire esc_ap_CS_fsm_reg_45_350234a ;
  wire esc_ap_CS_fsm_reg_50_18ba0a7 ;
  wire esc_ap_CS_fsm_reg_54_3d44ae7 ;
  wire esc_ap_CS_fsm_reg_55_06ec471 ;
  wire ap_clk;
  wire ap_enable_reg_pp3_iter0;
  wire ap_enable_reg_pp3_iter0_reg_rep__0;
  wire ap_enable_reg_pp4_iter0;
  wire ap_enable_reg_pp4_iter1;
  wire [16:0]edge_sums_V_q1;
  wire icmp_ln89_reg_8917_pp4_iter1_reg;
  wire [16:0]ram_reg;
  wire [16:0]ram_reg_0;
  wire [16:0]ram_reg_1;
  wire [10:0]ram_reg_10;
  wire ram_reg_11;
  wire [16:0]ram_reg_12;
  wire ram_reg_13;
  wire ram_reg_14;
  wire [16:0]ram_reg_15;
  wire ram_reg_16;
  wire [16:0]ram_reg_17;
  wire ram_reg_18;
  wire ram_reg_19;
  wire [16:0]ram_reg_2;
  wire ram_reg_20;
  wire ram_reg_21;
  wire ram_reg_22;
  wire ram_reg_23;
  wire ram_reg_24;
  wire ram_reg_25;
  wire ram_reg_26;
  wire ram_reg_27;
  wire ram_reg_28;
  wire ram_reg_29;
  wire [16:0]ram_reg_3;
  wire ram_reg_30;
  wire ram_reg_31;
  wire ram_reg_32;
  wire ram_reg_33;
  wire ram_reg_34;
  wire [10:0]ram_reg_35;
  wire [10:0]ram_reg_36;
  wire ram_reg_37;
  wire ram_reg_38;
  wire ram_reg_39;
  wire [16:0]ram_reg_4;
  wire ram_reg_40;
  wire ram_reg_41;
  wire ram_reg_42;
  wire ram_reg_43;
  wire ram_reg_44;
  wire ram_reg_45;
  wire ram_reg_46;
  wire ram_reg_47;
  wire ram_reg_48;
  wire [16:0]ram_reg_49;
  wire [16:0]ram_reg_5;
  wire ram_reg_50;
  wire [3:0]ram_reg_51;
  wire [3:0]ram_reg_52;
  wire [3:0]ram_reg_53;
  wire [3:0]ram_reg_54;
  wire ram_reg_55;
  wire ram_reg_56;
  wire ram_reg_57;
  wire ram_reg_58;
  wire ram_reg_59;
  wire [16:0]ram_reg_6;
  wire ram_reg_60;
  wire [5:0]ram_reg_61;
  wire ram_reg_62;
  wire [16:0]ram_reg_7;
  wire [16:0]ram_reg_8;
  wire [16:0]ram_reg_9;
  wire ram_reg_i_128__0;
  wire [16:0]ram_reg_i_130;
  wire [16:0]ram_reg_i_130_0;
  wire [16:0]ram_reg_i_130_1;
  wire [16:0]ram_reg_i_130_2;
  wire [16:0]ram_reg_i_130_3;
  wire [16:0]ram_reg_i_130_4;
  wire [16:0]ram_reg_i_130_5;
  wire [16:0]ram_reg_i_130_6;
  wire [16:0]ram_reg_i_132__0;
  wire [16:0]ram_reg_i_132__0_0;
  wire [16:0]ram_reg_i_132__0_1;
  wire [16:0]ram_reg_i_132__0_2;
  wire ram_reg_i_132__0_3;
  wire ram_reg_i_213;
  wire ram_reg_i_258__0;
  wire ram_reg_i_258__0_0;
  wire ram_reg_i_259;
  wire ram_reg_i_261__0;
  wire [16:0]ram_reg_i_262;
  wire [16:0]ram_reg_i_262_0;
  wire [16:0]ram_reg_i_265;
  wire [16:0]ram_reg_i_265_0;
  wire [16:0]ram_reg_i_265_1;
  wire [16:0]ram_reg_i_265_2;
  wire [16:0]ram_reg_i_265_3;
  wire ram_reg_i_265_4;
  wire [16:0]ram_reg_i_266__0;
  wire [16:0]ram_reg_i_266__0_0;
  wire [16:0]ram_reg_i_266__0_1;
  wire [16:0]ram_reg_i_266__0_2;
  wire [16:0]ram_reg_i_266__0_3;
  wire [16:0]ram_reg_i_268;
  wire ram_reg_i_268_0;
  wire [16:0]ram_reg_i_268_1;
  wire [16:0]ram_reg_i_268_2;
  wire [16:0]ram_reg_i_384__0;
  wire [16:0]ram_reg_i_384__0_0;
  wire [16:0]ram_reg_i_384__0_1;
  wire [16:0]ram_reg_i_389;
  wire [16:0]ram_reg_i_389_0;
  wire [16:0]ram_reg_i_389_1;
  wire [16:0]ram_reg_i_389_2;
  wire [16:0]ram_reg_i_389_3;
  wire ram_reg_i_591;
  wire ram_reg_i_94;
  wire [33:0]esc_reg_2525_reg_0_b7796ac ;
  wire esc_reg_2535_reg_16_71a81d1 ;
  wire [16:0]esc_ret_3_reg_9002_reg_17_3a058af ;
  wire esc_x_1_reg_2374_reg_1_abb1053 ;

  system_blue_locator_packed_0_0_blue_locator_packed_blue_sums_V_ram blue_locator_packed_blue_sums_V_ram_U
       (.D(D),
        .DOADO(edge_sums_V_q1[15:0]),
        .DOPADOP(edge_sums_V_q1[16]),
        .O(O),
        .Q(Q),
        .WEA(WEA),
        .WEBWE(WEBWE),
        .esc_add_ln208_1_reg_7062_reg_7_fda81fb (esc_add_ln208_1_reg_7062_reg_7_fda81fb ),
        .esc_ap_CS_fsm_reg_15_c4b990a (esc_ap_CS_fsm_reg_15_c4b990a ),
        .esc_ap_CS_fsm_reg_45_350234a (esc_ap_CS_fsm_reg_45_350234a ),
        .esc_ap_CS_fsm_reg_50_18ba0a7 (esc_ap_CS_fsm_reg_50_18ba0a7 ),
        .esc_ap_CS_fsm_reg_54_3d44ae7 (esc_ap_CS_fsm_reg_54_3d44ae7 ),
        .esc_ap_CS_fsm_reg_55_06ec471 (esc_ap_CS_fsm_reg_55_06ec471 ),
        .ap_clk(ap_clk),
        .ap_enable_reg_pp3_iter0(ap_enable_reg_pp3_iter0),
        .ap_enable_reg_pp3_iter0_reg_rep__0(ap_enable_reg_pp3_iter0_reg_rep__0),
        .ap_enable_reg_pp4_iter0(ap_enable_reg_pp4_iter0),
        .ap_enable_reg_pp4_iter1(ap_enable_reg_pp4_iter1),
        .icmp_ln89_reg_8917_pp4_iter1_reg(icmp_ln89_reg_8917_pp4_iter1_reg),
        .ram_reg_0(ram_reg),
        .ram_reg_1(ram_reg_0),
        .ram_reg_10(ram_reg_9),
        .ram_reg_11(ram_reg_10),
        .ram_reg_12(ram_reg_11),
        .ram_reg_13(ram_reg_12),
        .ram_reg_14(ram_reg_13),
        .ram_reg_15(ram_reg_14),
        .ram_reg_16(ram_reg_15),
        .ram_reg_17(ram_reg_16),
        .ram_reg_18(ram_reg_17),
        .ram_reg_19(ram_reg_18),
        .ram_reg_2(ram_reg_1),
        .ram_reg_20(ram_reg_19),
        .ram_reg_21(ram_reg_20),
        .ram_reg_22(ram_reg_21),
        .ram_reg_23(ram_reg_22),
        .ram_reg_24(ram_reg_23),
        .ram_reg_25(ram_reg_24),
        .ram_reg_26(ram_reg_25),
        .ram_reg_27(ram_reg_26),
        .ram_reg_28(ram_reg_27),
        .ram_reg_29(ram_reg_28),
        .ram_reg_3(ram_reg_2),
        .ram_reg_30(ram_reg_29),
        .ram_reg_31(ram_reg_30),
        .ram_reg_32(ram_reg_31),
        .ram_reg_33(ram_reg_32),
        .ram_reg_34(ram_reg_33),
        .ram_reg_35(ram_reg_34),
        .ram_reg_36(ram_reg_35),
        .ram_reg_37(ram_reg_36),
        .ram_reg_38(ram_reg_37),
        .ram_reg_39(ram_reg_38),
        .ram_reg_4(ram_reg_3),
        .ram_reg_40(ram_reg_39),
        .ram_reg_41(ram_reg_40),
        .ram_reg_42(ram_reg_41),
        .ram_reg_43(ram_reg_42),
        .ram_reg_44(ram_reg_43),
        .ram_reg_45(ram_reg_44),
        .ram_reg_46(ram_reg_45),
        .ram_reg_47(ram_reg_46),
        .ram_reg_48(ram_reg_47),
        .ram_reg_49(ram_reg_48),
        .ram_reg_5(ram_reg_4),
        .ram_reg_50(ram_reg_49),
        .ram_reg_51(ram_reg_50),
        .ram_reg_52(ram_reg_51),
        .ram_reg_53(ram_reg_52),
        .ram_reg_54(ram_reg_53),
        .ram_reg_55(ram_reg_54),
        .ram_reg_56(ram_reg_55),
        .ram_reg_57(ram_reg_56),
        .ram_reg_58(ram_reg_57),
        .ram_reg_59(ram_reg_58),
        .ram_reg_6(ram_reg_5),
        .ram_reg_60(ram_reg_59),
        .ram_reg_61(ram_reg_60),
        .ram_reg_62(ram_reg_61),
        .ram_reg_63(ram_reg_62),
        .ram_reg_7(ram_reg_6),
        .ram_reg_8(ram_reg_7),
        .ram_reg_9(ram_reg_8),
        .ram_reg_i_128__0_0(ram_reg_i_128__0),
        .ram_reg_i_130_0(ram_reg_i_130),
        .ram_reg_i_130_1(ram_reg_i_130_0),
        .ram_reg_i_130_2(ram_reg_i_130_1),
        .ram_reg_i_130_3(ram_reg_i_130_2),
        .ram_reg_i_130_4(ram_reg_i_130_3),
        .ram_reg_i_130_5(ram_reg_i_130_4),
        .ram_reg_i_130_6(ram_reg_i_130_5),
        .ram_reg_i_130_7(ram_reg_i_130_6),
        .ram_reg_i_132__0_0(ram_reg_i_132__0),
        .ram_reg_i_132__0_1(ram_reg_i_132__0_0),
        .ram_reg_i_132__0_2(ram_reg_i_132__0_1),
        .ram_reg_i_132__0_3(ram_reg_i_132__0_2),
        .ram_reg_i_132__0_4(ram_reg_i_132__0_3),
        .ram_reg_i_213_0(ram_reg_i_213),
        .ram_reg_i_258__0_0(ram_reg_i_258__0),
        .ram_reg_i_258__0_1(ram_reg_i_258__0_0),
        .ram_reg_i_259_0(ram_reg_i_259),
        .ram_reg_i_261__0_0(ram_reg_i_261__0),
        .ram_reg_i_262_0(ram_reg_i_262),
        .ram_reg_i_262_1(ram_reg_i_262_0),
        .ram_reg_i_265_0(ram_reg_i_265),
        .ram_reg_i_265_1(ram_reg_i_265_0),
        .ram_reg_i_265_2(ram_reg_i_265_1),
        .ram_reg_i_265_3(ram_reg_i_265_2),
        .ram_reg_i_265_4(ram_reg_i_265_3),
        .ram_reg_i_265_5(ram_reg_i_265_4),
        .ram_reg_i_266__0_0(ram_reg_i_266__0),
        .ram_reg_i_266__0_1(ram_reg_i_266__0_0),
        .ram_reg_i_266__0_2(ram_reg_i_266__0_1),
        .ram_reg_i_266__0_3(ram_reg_i_266__0_2),
        .ram_reg_i_266__0_4(ram_reg_i_266__0_3),
        .ram_reg_i_268_0(ram_reg_i_268),
        .ram_reg_i_268_1(ram_reg_i_268_0),
        .ram_reg_i_268_2(ram_reg_i_268_1),
        .ram_reg_i_268_3(ram_reg_i_268_2),
        .ram_reg_i_384__0_0(ram_reg_i_384__0),
        .ram_reg_i_384__0_1(ram_reg_i_384__0_0),
        .ram_reg_i_384__0_2(ram_reg_i_384__0_1),
        .ram_reg_i_389_0(ram_reg_i_389),
        .ram_reg_i_389_1(ram_reg_i_389_0),
        .ram_reg_i_389_2(ram_reg_i_389_1),
        .ram_reg_i_389_3(ram_reg_i_389_2),
        .ram_reg_i_389_4(ram_reg_i_389_3),
        .ram_reg_i_591(ram_reg_i_591),
        .ram_reg_i_94_0(ram_reg_i_94),
        .esc_reg_2525_reg_0_b7796ac (esc_reg_2525_reg_0_b7796ac ),
        .esc_reg_2535_reg_16_71a81d1 (esc_reg_2535_reg_16_71a81d1 ),
        .esc_ret_3_reg_9002_reg_17_3a058af (esc_ret_3_reg_9002_reg_17_3a058af ),
        .esc_x_1_reg_2374_reg_1_abb1053 (esc_x_1_reg_2374_reg_1_abb1053 ));
endmodule

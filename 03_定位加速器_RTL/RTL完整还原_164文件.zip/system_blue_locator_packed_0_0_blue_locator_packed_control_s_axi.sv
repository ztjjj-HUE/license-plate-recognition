// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_control_s_axi
   (D,
    SR,
    ap_start,
    esc_ap_CS_fsm_reg_1_637b98d ,
    esc_FSM_onehot_wstate_reg_2__0_190a757 ,
    esc_ap_CS_fsm_reg_1__0_160aef6 ,
    s_axi_control_BVALID,
    esc_FSM_onehot_wstate_reg_1__0_bb8fbc8 ,
    s_axi_control_RVALID,
    esc_FSM_onehot_rstate_reg_1__0_1ba0d01 ,
    frame_offset,
    result,
    s_axi_control_RDATA,
    interrupt,
    esc_ap_CS_fsm_reg_1__1_7592067 ,
    esc_ap_CS_fsm_reg_1__2_7d7a24d ,
    esc_ap_CS_fsm_reg_1__3_d3b633e ,
    esc_ap_CS_fsm_reg_1__4_b0443c7 ,
    esc_ap_CS_fsm_reg_1__5_2a64ffc ,
    Q,
    esc_y_reg_2297_reg_0_8039ace ,
    ap_enable_reg_pp0_iter1,
    ap_enable_reg_pp0_iter0_reg,
    ap_enable_reg_pp0_iter0,
    ap_rst_n,
    s_axi_control_WVALID,
    s_axi_control_ARADDR,
    int_ap_idle_reg_0,
    ap_clk,
    s_axi_control_AWADDR,
    output_r_BVALID,
    s_axi_control_WDATA,
    s_axi_control_WSTRB,
    s_axi_control_ARVALID,
    s_axi_control_RREADY,
    s_axi_control_AWVALID,
    s_axi_control_BREADY,
    ap_done);
  output [0:0]D;
  output [0:0]SR;
  output ap_start;
  output esc_ap_CS_fsm_reg_1_637b98d ;
  output esc_FSM_onehot_wstate_reg_2__0_190a757 ;
  output [0:0]esc_ap_CS_fsm_reg_1__0_160aef6 ;
  output s_axi_control_BVALID;
  output esc_FSM_onehot_wstate_reg_1__0_bb8fbc8 ;
  output s_axi_control_RVALID;
  output esc_FSM_onehot_rstate_reg_1__0_1ba0d01 ;
  output [63:0]frame_offset;
  output [61:0]result;
  output [31:0]s_axi_control_RDATA;
  output interrupt;
  input esc_ap_CS_fsm_reg_1__1_7592067 ;
  input esc_ap_CS_fsm_reg_1__2_7d7a24d ;
  input esc_ap_CS_fsm_reg_1__3_d3b633e ;
  input esc_ap_CS_fsm_reg_1__4_b0443c7 ;
  input esc_ap_CS_fsm_reg_1__5_2a64ffc ;
  input [2:0]Q;
  input esc_y_reg_2297_reg_0_8039ace ;
  input ap_enable_reg_pp0_iter1;
  input ap_enable_reg_pp0_iter0_reg;
  input ap_enable_reg_pp0_iter0;
  input ap_rst_n;
  input s_axi_control_WVALID;
  input [5:0]s_axi_control_ARADDR;
  input [0:0]int_ap_idle_reg_0;
  input ap_clk;
  input [5:0]s_axi_control_AWADDR;
  input output_r_BVALID;
  input [31:0]s_axi_control_WDATA;
  input [3:0]s_axi_control_WSTRB;
  input s_axi_control_ARVALID;
  input s_axi_control_RREADY;
  input s_axi_control_AWVALID;
  input s_axi_control_BREADY;
  input ap_done;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]D;
  wire esc_FSM_onehot_rstate_1__i_1_n_0_8290a26 ;
  wire esc_FSM_onehot_rstate_2__i_1_n_0_70a0e36 ;
  wire esc_FSM_onehot_rstate_reg_1__0_1ba0d01 ;
  wire esc_FSM_onehot_wstate_1__i_1_n_0_854f90e ;
  wire esc_FSM_onehot_wstate_2__i_1_n_0_2ed297b ;
  wire esc_FSM_onehot_wstate_3__i_1_n_0_5df7283 ;
  wire esc_FSM_onehot_wstate_reg_1__0_bb8fbc8 ;
  wire esc_FSM_onehot_wstate_reg_2__0_190a757 ;
  wire [2:0]Q;
  wire [0:0]SR;
  wire esc_ap_CS_fsm_reg_1_637b98d ;
  wire [0:0]esc_ap_CS_fsm_reg_1__0_160aef6 ;
  wire esc_ap_CS_fsm_reg_1__1_7592067 ;
  wire esc_ap_CS_fsm_reg_1__2_7d7a24d ;
  wire esc_ap_CS_fsm_reg_1__3_d3b633e ;
  wire esc_ap_CS_fsm_reg_1__4_b0443c7 ;
  wire esc_ap_CS_fsm_reg_1__5_2a64ffc ;
  wire ap_NS_fsm1125_out;
  wire ap_clk;
  wire ap_done;
  wire ap_enable_reg_pp0_iter0;
  wire ap_enable_reg_pp0_iter0_reg;
  wire ap_enable_reg_pp0_iter1;
  wire ap_idle;
  wire ap_rst_n;
  wire ap_start;
  wire ar_hs;
  wire [7:1]data0;
  wire [63:0]frame_offset;
  wire int_ap_done1;
  wire int_ap_done_i_1_n_0;
  wire [0:0]int_ap_idle_reg_0;
  wire int_ap_start3_out;
  wire int_ap_start_i_1_n_0;
  wire int_auto_restart_i_1_n_0;
  wire esc_int_frame_offset_31__i_1_n_0_9d4b028 ;
  wire esc_int_frame_offset_31__i_3_n_0_0fa91b0 ;
  wire esc_int_frame_offset_63__i_1_n_0_8c41a05 ;
  wire [31:0]int_frame_offset_reg0;
  wire [31:0]int_frame_offset_reg04_out;
  wire int_gie_i_1_n_0;
  wire int_gie_reg_n_0;
  wire esc_int_ier_0__i_1_n_0_5993ded ;
  wire esc_int_ier_1__i_1_n_0_f532248 ;
  wire esc_int_ier_1__i_2_n_0_431a4c0 ;
  wire esc_int_ier_reg_n_0__0_bd4abd3 ;
  wire int_isr6_out;
  wire esc_int_isr_0__i_1_n_0_d62a8f7 ;
  wire esc_int_isr_1__i_1_n_0_8db0c89 ;
  wire esc_int_isr_reg_n_0__0_0393731 ;
  wire esc_int_result_31__i_1_n_0_175ccd1 ;
  wire esc_int_result_63__i_1_n_0_78c0e3f ;
  wire esc_int_result_63__i_3_n_0_a98cf4f ;
  wire [31:0]int_result_reg0;
  wire [31:0]int_result_reg01_out;
  wire esc_int_result_reg_n_0__0_fa526ec ;
  wire esc_int_result_reg_n_0__1_08c45f5 ;
  wire output_r_BVALID;
  wire p_0_in;
  wire p_1_in;
  wire esc_rdata_0__i_2_n_0_a457df0 ;
  wire esc_rdata_0__i_3_n_0_cc4cf56 ;
  wire esc_rdata_10__i_1_n_0_7293013 ;
  wire esc_rdata_10__i_2_n_0_0bd83d1 ;
  wire esc_rdata_11__i_1_n_0_0a44289 ;
  wire esc_rdata_11__i_2_n_0_e5907a0 ;
  wire esc_rdata_12__i_1_n_0_a987590 ;
  wire esc_rdata_12__i_2_n_0_aef06b1 ;
  wire esc_rdata_13__i_1_n_0_f78d886 ;
  wire esc_rdata_13__i_2_n_0_b8a0eea ;
  wire esc_rdata_14__i_1_n_0_b131f65 ;
  wire esc_rdata_14__i_2_n_0_577e317 ;
  wire esc_rdata_15__i_1_n_0_883ba46 ;
  wire esc_rdata_15__i_2_n_0_dcb2157 ;
  wire esc_rdata_16__i_1_n_0_fd4dc4d ;
  wire esc_rdata_16__i_2_n_0_b7e52a7 ;
  wire esc_rdata_17__i_1_n_0_3240d5b ;
  wire esc_rdata_17__i_2_n_0_08d9aec ;
  wire esc_rdata_18__i_1_n_0_4dfbff6 ;
  wire esc_rdata_18__i_2_n_0_90770c7 ;
  wire esc_rdata_19__i_1_n_0_eec9235 ;
  wire esc_rdata_19__i_2_n_0_576972e ;
  wire esc_rdata_1__i_2_n_0_4d64846 ;
  wire esc_rdata_1__i_3_n_0_77c227d ;
  wire esc_rdata_20__i_1_n_0_f79cc60 ;
  wire esc_rdata_20__i_2_n_0_5da6e01 ;
  wire esc_rdata_21__i_1_n_0_2ddd0f7 ;
  wire esc_rdata_21__i_2_n_0_b0183b7 ;
  wire esc_rdata_22__i_1_n_0_3999317 ;
  wire esc_rdata_22__i_2_n_0_ecb605b ;
  wire esc_rdata_23__i_1_n_0_d581e50 ;
  wire esc_rdata_23__i_2_n_0_482ee71 ;
  wire esc_rdata_24__i_1_n_0_b89864b ;
  wire esc_rdata_24__i_2_n_0_f792bb4 ;
  wire esc_rdata_25__i_1_n_0_8a2b956 ;
  wire esc_rdata_25__i_2_n_0_3ac8ed7 ;
  wire esc_rdata_26__i_1_n_0_23f5691 ;
  wire esc_rdata_26__i_2_n_0_e8cd84e ;
  wire esc_rdata_27__i_1_n_0_502b465 ;
  wire esc_rdata_27__i_2_n_0_1ef1b07 ;
  wire esc_rdata_28__i_1_n_0_6743271 ;
  wire esc_rdata_28__i_2_n_0_c7adcf5 ;
  wire esc_rdata_29__i_1_n_0_1c1ef74 ;
  wire esc_rdata_29__i_2_n_0_916a39c ;
  wire esc_rdata_2__i_1_n_0_c9bdce3 ;
  wire esc_rdata_2__i_2_n_0_5a1091a ;
  wire esc_rdata_30__i_1_n_0_324ea32 ;
  wire esc_rdata_30__i_2_n_0_4e6bc31 ;
  wire esc_rdata_31__i_1_n_0_4ab42c1 ;
  wire esc_rdata_31__i_3_n_0_5a50bb4 ;
  wire esc_rdata_31__i_4_n_0_1328de1 ;
  wire esc_rdata_31__i_5_n_0_7df9488 ;
  wire esc_rdata_31__i_6_n_0_7d1dbb6 ;
  wire esc_rdata_3__i_1_n_0_a67420f ;
  wire esc_rdata_3__i_2_n_0_3344c46 ;
  wire esc_rdata_4__i_1_n_0_1a98800 ;
  wire esc_rdata_4__i_2_n_0_0bb3f4c ;
  wire esc_rdata_5__i_1_n_0_e4d287d ;
  wire esc_rdata_5__i_2_n_0_74dce8c ;
  wire esc_rdata_6__i_1_n_0_23d2e97 ;
  wire esc_rdata_6__i_2_n_0_e9b9ddb ;
  wire esc_rdata_7__i_1_n_0_b768213 ;
  wire esc_rdata_7__i_2_n_0_b89d9ae ;
  wire esc_rdata_7__i_3_n_0_9018222 ;
  wire esc_rdata_7__i_4_n_0_2ace495 ;
  wire esc_rdata_8__i_1_n_0_d9891d7 ;
  wire esc_rdata_8__i_2_n_0_2a111a0 ;
  wire esc_rdata_9__i_1_n_0_4a43c58 ;
  wire esc_rdata_9__i_2_n_0_fcd395b ;
  wire esc_rdata_reg_0__i_1_n_0_4d97e0e ;
  wire esc_rdata_reg_1__i_1_n_0_77175c7 ;
  wire [61:0]result;
  wire [5:0]s_axi_control_ARADDR;
  wire s_axi_control_ARVALID;
  wire [5:0]s_axi_control_AWADDR;
  wire s_axi_control_AWVALID;
  wire s_axi_control_BREADY;
  wire s_axi_control_BVALID;
  wire [31:0]s_axi_control_RDATA;
  wire s_axi_control_RREADY;
  wire s_axi_control_RVALID;
  wire [31:0]s_axi_control_WDATA;
  wire [3:0]s_axi_control_WSTRB;
  wire s_axi_control_WVALID;
  wire waddr;
  wire esc_waddr_reg_n_0__0_ad4c065 ;
  wire esc_waddr_reg_n_0__1_792a10e ;
  wire esc_waddr_reg_n_0__2_093afb0 ;
  wire esc_waddr_reg_n_0__3_ccbbd3d ;
  wire esc_waddr_reg_n_0__4_2e446af ;
  wire esc_waddr_reg_n_0__5_99ccd75 ;
  wire esc_y_reg_2297_reg_0_8039ace ;

  // Reconstructed LUT4: esc_FSM_onehot_rstate_1__i_1_b2329ff
  assign esc_FSM_onehot_rstate_1__i_1_n_0_8290a26 = ((s_axi_control_RREADY) ? (((s_axi_control_RVALID) ? (1'b1) : (((esc_FSM_onehot_rstate_reg_1__0_1ba0d01) ? (~(s_axi_control_ARVALID)) : (1'b1))))) : (((s_axi_control_RVALID) ? (((esc_FSM_onehot_rstate_reg_1__0_1ba0d01) ? (~(s_axi_control_ARVALID)) : (1'b0))) : (((esc_FSM_onehot_rstate_reg_1__0_1ba0d01) ? (~(s_axi_control_ARVALID)) : (1'b1))))));

  // Reconstructed LUT4: esc_FSM_onehot_rstate_2__i_1_52665dd
  assign esc_FSM_onehot_rstate_2__i_1_n_0_70a0e36 = ((s_axi_control_RREADY) ? (((esc_FSM_onehot_rstate_reg_1__0_1ba0d01) ? (s_axi_control_ARVALID) : (1'b0))) : (((s_axi_control_RVALID) ? (1'b1) : (((esc_FSM_onehot_rstate_reg_1__0_1ba0d01) ? (s_axi_control_ARVALID) : (1'b0))))));

  // Reconstructed FDRE: esc_FSM_onehot_rstate_reg_1_e0fbb55
  reg recovered_3_q = 1'b0;
  assign esc_FSM_onehot_rstate_reg_1__0_1ba0d01 = recovered_3_q;
  wire recovered_3_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_3_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_3_q == 1'b0))) recovered_3_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_3_q == (esc_FSM_onehot_rstate_1__i_1_n_0_8290a26)))) recovered_3_q <= (esc_FSM_onehot_rstate_1__i_1_n_0_8290a26);
  end

  // Reconstructed FDRE: esc_FSM_onehot_rstate_reg_2_acfe8b8
  reg recovered_4_q = 1'b0;
  assign s_axi_control_RVALID = recovered_4_q;
  wire recovered_4_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_4_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (esc_FSM_onehot_rstate_2__i_1_n_0_70a0e36)))) recovered_4_q <= (esc_FSM_onehot_rstate_2__i_1_n_0_70a0e36);
  end

  // Reconstructed LUT5: esc_FSM_onehot_wstate_1__i_1_9d29bc5
  assign esc_FSM_onehot_wstate_1__i_1_n_0_854f90e = ((s_axi_control_AWVALID) ? (((esc_FSM_onehot_wstate_reg_1__0_bb8fbc8) ? (((s_axi_control_BVALID) ? (s_axi_control_BREADY) : (1'b0))) : (((esc_FSM_onehot_wstate_reg_2__0_190a757) ? (((s_axi_control_BVALID) ? (s_axi_control_BREADY) : (1'b0))) : (((s_axi_control_BVALID) ? (s_axi_control_BREADY) : (1'b1))))))) : (((esc_FSM_onehot_wstate_reg_1__0_bb8fbc8) ? (1'b1) : (((esc_FSM_onehot_wstate_reg_2__0_190a757) ? (((s_axi_control_BVALID) ? (s_axi_control_BREADY) : (1'b0))) : (((s_axi_control_BVALID) ? (s_axi_control_BREADY) : (1'b1))))))));

  // Reconstructed LUT4: esc_FSM_onehot_wstate_2__i_1_e615d4c
  assign esc_FSM_onehot_wstate_2__i_1_n_0_2ed297b = ((esc_FSM_onehot_wstate_reg_2__0_190a757) ? (((s_axi_control_WVALID) ? (((esc_FSM_onehot_wstate_reg_1__0_bb8fbc8) ? (s_axi_control_AWVALID) : (1'b0))) : (1'b1))) : (((esc_FSM_onehot_wstate_reg_1__0_bb8fbc8) ? (s_axi_control_AWVALID) : (1'b0))));

  // Reconstructed LUT4: esc_FSM_onehot_wstate_3__i_1_f6f9ec2
  assign esc_FSM_onehot_wstate_3__i_1_n_0_5df7283 = ((s_axi_control_BVALID) ? (((s_axi_control_BREADY) ? (((esc_FSM_onehot_wstate_reg_2__0_190a757) ? (s_axi_control_WVALID) : (1'b0))) : (1'b1))) : (((esc_FSM_onehot_wstate_reg_2__0_190a757) ? (s_axi_control_WVALID) : (1'b0))));

  // Reconstructed FDRE: esc_FSM_onehot_wstate_reg_1_82393a7
  reg recovered_8_q = 1'b0;
  assign esc_FSM_onehot_wstate_reg_1__0_bb8fbc8 = recovered_8_q;
  wire recovered_8_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_8_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_8_q == (esc_FSM_onehot_wstate_1__i_1_n_0_854f90e)))) recovered_8_q <= (esc_FSM_onehot_wstate_1__i_1_n_0_854f90e);
  end

  // Reconstructed FDRE: esc_FSM_onehot_wstate_reg_2_2abec30
  reg recovered_9_q = 1'b0;
  assign esc_FSM_onehot_wstate_reg_2__0_190a757 = recovered_9_q;
  wire recovered_9_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_9_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (esc_FSM_onehot_wstate_2__i_1_n_0_2ed297b)))) recovered_9_q <= (esc_FSM_onehot_wstate_2__i_1_n_0_2ed297b);
  end

  // Reconstructed FDRE: esc_FSM_onehot_wstate_reg_3_f830a0c
  reg recovered_10_q = 1'b0;
  assign s_axi_control_BVALID = recovered_10_q;
  wire recovered_10_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_10_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_10_q == (esc_FSM_onehot_wstate_3__i_1_n_0_5df7283)))) recovered_10_q <= (esc_FSM_onehot_wstate_3__i_1_n_0_5df7283);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_ap_CS_fsm_1__i_1_9540b4a
  assign D = ((esc_ap_CS_fsm_reg_1__5_2a64ffc) ? (((esc_ap_CS_fsm_reg_1__4_b0443c7) ? (ap_NS_fsm1125_out) : (((esc_ap_CS_fsm_reg_1__3_d3b633e) ? (ap_NS_fsm1125_out) : (((esc_ap_CS_fsm_reg_1__2_7d7a24d) ? (ap_NS_fsm1125_out) : (((esc_ap_CS_fsm_reg_1__1_7592067) ? (ap_NS_fsm1125_out) : (1'b1))))))))) : (ap_NS_fsm1125_out));

  // Reconstructed LUT2: esc_ap_CS_fsm_1__i_2_918526f
  assign ap_NS_fsm1125_out = ((Q[0]) ? (ap_start) : (1'b0));

  // Reconstructed LUT6: ap_enable_reg_pp0_iter0_i_1
  assign esc_ap_CS_fsm_reg_1_637b98d = ((ap_rst_n) ? (((ap_enable_reg_pp0_iter0) ? (((Q[1]) ? (~(ap_enable_reg_pp0_iter0_reg)) : (1'b1))) : (((ap_start) ? (((Q[0]) ? (((Q[1]) ? (~(ap_enable_reg_pp0_iter0_reg)) : (1'b1))) : (1'b0))) : (1'b0))))) : (1'b0));

  // Reconstructed LUT6: int_ap_done_i_1
  assign int_ap_done_i_1_n_0 = ((data0[1]) ? (((int_ap_done1) ? (((s_axi_control_ARVALID) ? (((esc_FSM_onehot_rstate_reg_1__0_1ba0d01) ? (((Q[2]) ? (output_r_BVALID) : (1'b0))) : (1'b1))) : (1'b1))) : (1'b1))) : (((Q[2]) ? (output_r_BVALID) : (1'b0))));

  // Reconstructed LUT6: int_ap_done_i_2
  assign int_ap_done1 = ((s_axi_control_ARADDR[2]) ? (1'b0) : (((s_axi_control_ARADDR[3]) ? (1'b0) : (((s_axi_control_ARADDR[0]) ? (1'b0) : (((s_axi_control_ARADDR[1]) ? (1'b0) : (((s_axi_control_ARADDR[4]) ? (1'b0) : (~(s_axi_control_ARADDR[5])))))))))));

  // Reconstructed FDRE: int_ap_done_reg
  reg recovered_18_q = 1'b0;
  assign data0[1] = recovered_18_q;
  wire recovered_18_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_18_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_18_q == (int_ap_done_i_1_n_0)))) recovered_18_q <= (int_ap_done_i_1_n_0);
  end

  // Reconstructed LUT2: int_ap_idle_i_1
  assign ap_idle = ((ap_start) ? (1'b0) : (Q[0]));

  // Reconstructed FDRE: int_ap_idle_reg
  reg recovered_20_q = 1'b0;
  assign data0[2] = recovered_20_q;
  wire recovered_20_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_20_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_20_q == (ap_idle)))) recovered_20_q <= (ap_idle);
  end

  // Reconstructed FDRE: int_ap_ready_reg
  reg recovered_21_q = 1'b0;
  assign data0[3] = recovered_21_q;
  wire recovered_21_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_21_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_21_q == (ap_done)))) recovered_21_q <= (ap_done);
  end

  // Reconstructed LUT5: int_ap_start_i_1
  assign int_ap_start_i_1_n_0 = ((ap_start) ? (((int_ap_start3_out) ? (1'b1) : (((Q[2]) ? (((output_r_BVALID) ? (data0[7]) : (1'b1))) : (1'b1))))) : (((int_ap_start3_out) ? (1'b1) : (((Q[2]) ? (((output_r_BVALID) ? (data0[7]) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: int_ap_start_i_2
  assign int_ap_start3_out = ((esc_waddr_reg_n_0__2_093afb0) ? (1'b0) : (((esc_waddr_reg_n_0__3_ccbbd3d) ? (1'b0) : (((esc_int_ier_1__i_2_n_0_431a4c0) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b0))) : (1'b0))))));

  // Reconstructed FDRE: int_ap_start_reg
  reg recovered_24_q = 1'b0;
  assign ap_start = recovered_24_q;
  wire recovered_24_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_24_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_24_q == (int_ap_start_i_1_n_0)))) recovered_24_q <= (int_ap_start_i_1_n_0);
  end

  // Reconstructed LUT6: int_auto_restart_i_1
  assign int_auto_restart_i_1_n_0 = ((data0[7]) ? (((s_axi_control_WSTRB[0]) ? (((esc_int_ier_1__i_2_n_0_431a4c0) ? (((esc_waddr_reg_n_0__3_ccbbd3d) ? (1'b1) : (((esc_waddr_reg_n_0__2_093afb0) ? (1'b1) : (s_axi_control_WDATA[7]))))) : (1'b1))) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (((esc_int_ier_1__i_2_n_0_431a4c0) ? (((esc_waddr_reg_n_0__3_ccbbd3d) ? (1'b0) : (((esc_waddr_reg_n_0__2_093afb0) ? (1'b0) : (s_axi_control_WDATA[7]))))) : (1'b0))) : (1'b0))));

  // Reconstructed FDRE: int_auto_restart_reg
  reg recovered_26_q = 1'b0;
  assign data0[7] = recovered_26_q;
  wire recovered_26_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_26_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_26_q == (int_auto_restart_i_1_n_0)))) recovered_26_q <= (int_auto_restart_i_1_n_0);
  end

  // Reconstructed LUT3: esc_int_frame_offset_0__i_1_b0b3ce5
  assign int_frame_offset_reg04_out[0] = ((frame_offset[0]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_10__i_1_ccebdaf
  assign int_frame_offset_reg04_out[10] = ((frame_offset[10]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[10]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[10]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_11__i_1_695b8a9
  assign int_frame_offset_reg04_out[11] = ((frame_offset[11]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[11]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[11]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_12__i_1_eb73718
  assign int_frame_offset_reg04_out[12] = ((frame_offset[12]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[12]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[12]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_13__i_1_88ddda0
  assign int_frame_offset_reg04_out[13] = ((frame_offset[13]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[13]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[13]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_14__i_1_9f82939
  assign int_frame_offset_reg04_out[14] = ((frame_offset[14]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[14]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[14]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_15__i_1_1296704
  assign int_frame_offset_reg04_out[15] = ((frame_offset[15]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[15]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[15]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_16__i_1_0cff34d
  assign int_frame_offset_reg04_out[16] = ((frame_offset[16]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[16]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[16]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_17__i_1_35ef5a3
  assign int_frame_offset_reg04_out[17] = ((frame_offset[17]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[17]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[17]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_18__i_1_e16201d
  assign int_frame_offset_reg04_out[18] = ((frame_offset[18]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[18]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[18]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_19__i_1_2ad6c59
  assign int_frame_offset_reg04_out[19] = ((frame_offset[19]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[19]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[19]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_1__i_1_e8db167
  assign int_frame_offset_reg04_out[1] = ((frame_offset[1]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[1]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[1]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_20__i_1_d6bd95c
  assign int_frame_offset_reg04_out[20] = ((frame_offset[20]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[20]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[20]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_21__i_1_68297e6
  assign int_frame_offset_reg04_out[21] = ((frame_offset[21]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[21]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[21]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_22__i_1_8ffbc3b
  assign int_frame_offset_reg04_out[22] = ((frame_offset[22]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[22]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[22]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_23__i_1_5bd911e
  assign int_frame_offset_reg04_out[23] = ((frame_offset[23]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[23]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[23]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_24__i_1_f900de8
  assign int_frame_offset_reg04_out[24] = ((frame_offset[24]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[24]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[24]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_25__i_1_dbadf3e
  assign int_frame_offset_reg04_out[25] = ((frame_offset[25]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[25]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[25]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_26__i_1_f8a0cb6
  assign int_frame_offset_reg04_out[26] = ((frame_offset[26]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[26]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[26]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_27__i_1_6f8bb02
  assign int_frame_offset_reg04_out[27] = ((frame_offset[27]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[27]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[27]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_28__i_1_d240d58
  assign int_frame_offset_reg04_out[28] = ((frame_offset[28]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[28]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[28]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_29__i_1_1e4694e
  assign int_frame_offset_reg04_out[29] = ((frame_offset[29]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[29]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[29]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_2__i_1_bb961e4
  assign int_frame_offset_reg04_out[2] = ((frame_offset[2]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[2]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[2]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_30__i_1_77f83e4
  assign int_frame_offset_reg04_out[30] = ((frame_offset[30]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[30]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[30]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_31__i_1_ea48795
  assign esc_int_frame_offset_31__i_1_n_0_9d4b028 = ((esc_waddr_reg_n_0__2_093afb0) ? (1'b0) : (((esc_int_frame_offset_31__i_3_n_0_0fa91b0) ? (~(esc_waddr_reg_n_0__3_ccbbd3d)) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_31__i_2_36cd4a8
  assign int_frame_offset_reg04_out[31] = ((frame_offset[31]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[31]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[31]) : (1'b0))));

  // Reconstructed LUT6: esc_int_frame_offset_31__i_3_90dcc94
  assign esc_int_frame_offset_31__i_3_n_0_0fa91b0 = ((esc_waddr_reg_n_0__1_792a10e) ? (1'b0) : (((s_axi_control_WVALID) ? (((esc_FSM_onehot_wstate_reg_2__0_190a757) ? (((esc_waddr_reg_n_0__0_ad4c065) ? (1'b0) : (((esc_waddr_reg_n_0__5_99ccd75) ? (1'b0) : (esc_waddr_reg_n_0__4_2e446af))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_32__i_1_a8ae21d
  assign int_frame_offset_reg0[0] = ((frame_offset[32]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_33__i_1_e428c00
  assign int_frame_offset_reg0[1] = ((frame_offset[33]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[1]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[1]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_34__i_1_2af48e1
  assign int_frame_offset_reg0[2] = ((frame_offset[34]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[2]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[2]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_35__i_1_ade4af3
  assign int_frame_offset_reg0[3] = ((frame_offset[35]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[3]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[3]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_36__i_1_0e84ff3
  assign int_frame_offset_reg0[4] = ((frame_offset[36]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[4]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[4]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_37__i_1_a80d356
  assign int_frame_offset_reg0[5] = ((frame_offset[37]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[5]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[5]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_38__i_1_cb4b755
  assign int_frame_offset_reg0[6] = ((frame_offset[38]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[6]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[6]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_39__i_1_a5536c1
  assign int_frame_offset_reg0[7] = ((frame_offset[39]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[7]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[7]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_3__i_1_8e5d39c
  assign int_frame_offset_reg04_out[3] = ((frame_offset[3]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[3]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[3]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_40__i_1_7ef5906
  assign int_frame_offset_reg0[8] = ((frame_offset[40]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[8]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[8]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_41__i_1_d819e98
  assign int_frame_offset_reg0[9] = ((frame_offset[41]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[9]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[9]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_42__i_1_9189e29
  assign int_frame_offset_reg0[10] = ((frame_offset[42]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[10]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[10]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_43__i_1_9ba4a81
  assign int_frame_offset_reg0[11] = ((frame_offset[43]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[11]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[11]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_44__i_1_fc3e461
  assign int_frame_offset_reg0[12] = ((frame_offset[44]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[12]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[12]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_45__i_1_5634ae5
  assign int_frame_offset_reg0[13] = ((frame_offset[45]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[13]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[13]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_46__i_1_fa8a865
  assign int_frame_offset_reg0[14] = ((frame_offset[46]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[14]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[14]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_47__i_1_2179b8f
  assign int_frame_offset_reg0[15] = ((frame_offset[47]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[15]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[15]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_48__i_1_a1d5e3a
  assign int_frame_offset_reg0[16] = ((frame_offset[48]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[16]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[16]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_49__i_1_7f42ed2
  assign int_frame_offset_reg0[17] = ((frame_offset[49]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[17]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[17]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_4__i_1_3338d1a
  assign int_frame_offset_reg04_out[4] = ((frame_offset[4]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[4]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[4]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_50__i_1_1ce6541
  assign int_frame_offset_reg0[18] = ((frame_offset[50]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[18]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[18]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_51__i_1_09ca7a9
  assign int_frame_offset_reg0[19] = ((frame_offset[51]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[19]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[19]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_52__i_1_afa97fd
  assign int_frame_offset_reg0[20] = ((frame_offset[52]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[20]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[20]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_53__i_1_2dbd50b
  assign int_frame_offset_reg0[21] = ((frame_offset[53]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[21]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[21]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_54__i_1_430788f
  assign int_frame_offset_reg0[22] = ((frame_offset[54]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[22]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[22]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_55__i_1_550e674
  assign int_frame_offset_reg0[23] = ((frame_offset[55]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[23]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[23]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_56__i_1_6f65c82
  assign int_frame_offset_reg0[24] = ((frame_offset[56]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[24]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[24]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_57__i_1_2cc0b24
  assign int_frame_offset_reg0[25] = ((frame_offset[57]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[25]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[25]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_58__i_1_c4ee4fd
  assign int_frame_offset_reg0[26] = ((frame_offset[58]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[26]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[26]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_59__i_1_ee0f978
  assign int_frame_offset_reg0[27] = ((frame_offset[59]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[27]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[27]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_5__i_1_d075a22
  assign int_frame_offset_reg04_out[5] = ((frame_offset[5]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[5]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[5]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_60__i_1_e97a120
  assign int_frame_offset_reg0[28] = ((frame_offset[60]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[28]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[28]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_61__i_1_66a2ed3
  assign int_frame_offset_reg0[29] = ((frame_offset[61]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[29]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[29]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_62__i_1_4fc9074
  assign int_frame_offset_reg0[30] = ((frame_offset[62]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[30]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[30]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_63__i_1_c1182f6
  assign esc_int_frame_offset_63__i_1_n_0_8c41a05 = ((esc_int_frame_offset_31__i_3_n_0_0fa91b0) ? (((esc_waddr_reg_n_0__3_ccbbd3d) ? (1'b0) : (esc_waddr_reg_n_0__2_093afb0))) : (1'b0));

  // Reconstructed LUT3: esc_int_frame_offset_63__i_2_7592142
  assign int_frame_offset_reg0[31] = ((frame_offset[63]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[31]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[31]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_6__i_1_5dfca05
  assign int_frame_offset_reg04_out[6] = ((frame_offset[6]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[6]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[6]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_7__i_1_ef6954b
  assign int_frame_offset_reg04_out[7] = ((frame_offset[7]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[7]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[7]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_8__i_1_4da1095
  assign int_frame_offset_reg04_out[8] = ((frame_offset[8]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[8]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[8]) : (1'b0))));

  // Reconstructed LUT3: esc_int_frame_offset_9__i_1_3cb6bac
  assign int_frame_offset_reg04_out[9] = ((frame_offset[9]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[9]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[9]) : (1'b0))));

  // Reconstructed FDRE: esc_int_frame_offset_reg_0_700ba0e
  reg recovered_94_q = 1'b0;
  assign frame_offset[0] = recovered_94_q;
  wire recovered_94_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_94_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_94_q == 1'b0))) recovered_94_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_94_q == (int_frame_offset_reg04_out[0])))) recovered_94_q <= (int_frame_offset_reg04_out[0]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_10_f692c7e
  reg recovered_95_q = 1'b0;
  assign frame_offset[10] = recovered_95_q;
  wire recovered_95_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_95_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_95_q == 1'b0))) recovered_95_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_95_q == (int_frame_offset_reg04_out[10])))) recovered_95_q <= (int_frame_offset_reg04_out[10]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_11_8f67298
  reg recovered_96_q = 1'b0;
  assign frame_offset[11] = recovered_96_q;
  wire recovered_96_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_96_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_96_q == 1'b0))) recovered_96_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_96_q == (int_frame_offset_reg04_out[11])))) recovered_96_q <= (int_frame_offset_reg04_out[11]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_12_179285d
  reg recovered_97_q = 1'b0;
  assign frame_offset[12] = recovered_97_q;
  wire recovered_97_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_97_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_97_q == 1'b0))) recovered_97_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_97_q == (int_frame_offset_reg04_out[12])))) recovered_97_q <= (int_frame_offset_reg04_out[12]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_13_78effc1
  reg recovered_98_q = 1'b0;
  assign frame_offset[13] = recovered_98_q;
  wire recovered_98_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_98_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_98_q == 1'b0))) recovered_98_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_98_q == (int_frame_offset_reg04_out[13])))) recovered_98_q <= (int_frame_offset_reg04_out[13]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_14_2e4f641
  reg recovered_99_q = 1'b0;
  assign frame_offset[14] = recovered_99_q;
  wire recovered_99_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_99_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_99_q == 1'b0))) recovered_99_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_99_q == (int_frame_offset_reg04_out[14])))) recovered_99_q <= (int_frame_offset_reg04_out[14]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_15_bd5d84f
  reg recovered_100_q = 1'b0;
  assign frame_offset[15] = recovered_100_q;
  wire recovered_100_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_100_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_100_q == 1'b0))) recovered_100_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_100_q == (int_frame_offset_reg04_out[15])))) recovered_100_q <= (int_frame_offset_reg04_out[15]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_16_9f8371e
  reg recovered_101_q = 1'b0;
  assign frame_offset[16] = recovered_101_q;
  wire recovered_101_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_101_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_101_q == 1'b0))) recovered_101_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_101_q == (int_frame_offset_reg04_out[16])))) recovered_101_q <= (int_frame_offset_reg04_out[16]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_17_ac45e8c
  reg recovered_102_q = 1'b0;
  assign frame_offset[17] = recovered_102_q;
  wire recovered_102_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_102_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_102_q == 1'b0))) recovered_102_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_102_q == (int_frame_offset_reg04_out[17])))) recovered_102_q <= (int_frame_offset_reg04_out[17]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_18_7329467
  reg recovered_103_q = 1'b0;
  assign frame_offset[18] = recovered_103_q;
  wire recovered_103_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_103_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_103_q == 1'b0))) recovered_103_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_103_q == (int_frame_offset_reg04_out[18])))) recovered_103_q <= (int_frame_offset_reg04_out[18]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_19_b94bdf6
  reg recovered_104_q = 1'b0;
  assign frame_offset[19] = recovered_104_q;
  wire recovered_104_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_104_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_104_q == 1'b0))) recovered_104_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_104_q == (int_frame_offset_reg04_out[19])))) recovered_104_q <= (int_frame_offset_reg04_out[19]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_1_ed2515d
  reg recovered_105_q = 1'b0;
  assign frame_offset[1] = recovered_105_q;
  wire recovered_105_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_105_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_105_q == 1'b0))) recovered_105_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_105_q == (int_frame_offset_reg04_out[1])))) recovered_105_q <= (int_frame_offset_reg04_out[1]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_20_b7c13de
  reg recovered_106_q = 1'b0;
  assign frame_offset[20] = recovered_106_q;
  wire recovered_106_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_106_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_106_q == 1'b0))) recovered_106_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_106_q == (int_frame_offset_reg04_out[20])))) recovered_106_q <= (int_frame_offset_reg04_out[20]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_21_e57bc46
  reg recovered_107_q = 1'b0;
  assign frame_offset[21] = recovered_107_q;
  wire recovered_107_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_107_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_107_q == 1'b0))) recovered_107_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_107_q == (int_frame_offset_reg04_out[21])))) recovered_107_q <= (int_frame_offset_reg04_out[21]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_22_b8b3726
  reg recovered_108_q = 1'b0;
  assign frame_offset[22] = recovered_108_q;
  wire recovered_108_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_108_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_108_q == 1'b0))) recovered_108_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_108_q == (int_frame_offset_reg04_out[22])))) recovered_108_q <= (int_frame_offset_reg04_out[22]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_23_7b223a2
  reg recovered_109_q = 1'b0;
  assign frame_offset[23] = recovered_109_q;
  wire recovered_109_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_109_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_109_q == 1'b0))) recovered_109_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_109_q == (int_frame_offset_reg04_out[23])))) recovered_109_q <= (int_frame_offset_reg04_out[23]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_24_54d4507
  reg recovered_110_q = 1'b0;
  assign frame_offset[24] = recovered_110_q;
  wire recovered_110_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_110_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_110_q == 1'b0))) recovered_110_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_110_q == (int_frame_offset_reg04_out[24])))) recovered_110_q <= (int_frame_offset_reg04_out[24]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_25_0a0569a
  reg recovered_111_q = 1'b0;
  assign frame_offset[25] = recovered_111_q;
  wire recovered_111_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_111_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_111_q == 1'b0))) recovered_111_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_111_q == (int_frame_offset_reg04_out[25])))) recovered_111_q <= (int_frame_offset_reg04_out[25]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_26_7ee80a5
  reg recovered_112_q = 1'b0;
  assign frame_offset[26] = recovered_112_q;
  wire recovered_112_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_112_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_112_q == 1'b0))) recovered_112_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_112_q == (int_frame_offset_reg04_out[26])))) recovered_112_q <= (int_frame_offset_reg04_out[26]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_27_34f9d2e
  reg recovered_113_q = 1'b0;
  assign frame_offset[27] = recovered_113_q;
  wire recovered_113_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_113_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_113_q == 1'b0))) recovered_113_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_113_q == (int_frame_offset_reg04_out[27])))) recovered_113_q <= (int_frame_offset_reg04_out[27]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_28_65bc1fe
  reg recovered_114_q = 1'b0;
  assign frame_offset[28] = recovered_114_q;
  wire recovered_114_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_114_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_114_q == 1'b0))) recovered_114_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_114_q == (int_frame_offset_reg04_out[28])))) recovered_114_q <= (int_frame_offset_reg04_out[28]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_29_d5411eb
  reg recovered_115_q = 1'b0;
  assign frame_offset[29] = recovered_115_q;
  wire recovered_115_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_115_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_115_q == 1'b0))) recovered_115_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_115_q == (int_frame_offset_reg04_out[29])))) recovered_115_q <= (int_frame_offset_reg04_out[29]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_2_86a3a14
  reg recovered_116_q = 1'b0;
  assign frame_offset[2] = recovered_116_q;
  wire recovered_116_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_116_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_116_q == 1'b0))) recovered_116_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_116_q == (int_frame_offset_reg04_out[2])))) recovered_116_q <= (int_frame_offset_reg04_out[2]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_30_886ca35
  reg recovered_117_q = 1'b0;
  assign frame_offset[30] = recovered_117_q;
  wire recovered_117_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_117_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_117_q == 1'b0))) recovered_117_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_117_q == (int_frame_offset_reg04_out[30])))) recovered_117_q <= (int_frame_offset_reg04_out[30]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_31_2980dbb
  reg recovered_118_q = 1'b0;
  assign frame_offset[31] = recovered_118_q;
  wire recovered_118_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_118_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_118_q == 1'b0))) recovered_118_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_118_q == (int_frame_offset_reg04_out[31])))) recovered_118_q <= (int_frame_offset_reg04_out[31]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_32_fbd666d
  reg recovered_119_q = 1'b0;
  assign frame_offset[32] = recovered_119_q;
  wire recovered_119_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_119_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_119_q == 1'b0))) recovered_119_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_119_q == (int_frame_offset_reg0[0])))) recovered_119_q <= (int_frame_offset_reg0[0]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_33_464ee51
  reg recovered_120_q = 1'b0;
  assign frame_offset[33] = recovered_120_q;
  wire recovered_120_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_120_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_120_q == 1'b0))) recovered_120_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_120_q == (int_frame_offset_reg0[1])))) recovered_120_q <= (int_frame_offset_reg0[1]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_34_ea0f39f
  reg recovered_121_q = 1'b0;
  assign frame_offset[34] = recovered_121_q;
  wire recovered_121_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_121_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_121_q == 1'b0))) recovered_121_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_121_q == (int_frame_offset_reg0[2])))) recovered_121_q <= (int_frame_offset_reg0[2]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_35_c54b39d
  reg recovered_122_q = 1'b0;
  assign frame_offset[35] = recovered_122_q;
  wire recovered_122_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_122_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_122_q == 1'b0))) recovered_122_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_122_q == (int_frame_offset_reg0[3])))) recovered_122_q <= (int_frame_offset_reg0[3]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_36_df73522
  reg recovered_123_q = 1'b0;
  assign frame_offset[36] = recovered_123_q;
  wire recovered_123_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_123_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_123_q == 1'b0))) recovered_123_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_123_q == (int_frame_offset_reg0[4])))) recovered_123_q <= (int_frame_offset_reg0[4]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_37_5b9ad25
  reg recovered_124_q = 1'b0;
  assign frame_offset[37] = recovered_124_q;
  wire recovered_124_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_124_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_124_q == 1'b0))) recovered_124_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_124_q == (int_frame_offset_reg0[5])))) recovered_124_q <= (int_frame_offset_reg0[5]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_38_5517d40
  reg recovered_125_q = 1'b0;
  assign frame_offset[38] = recovered_125_q;
  wire recovered_125_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_125_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_125_q == 1'b0))) recovered_125_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_125_q == (int_frame_offset_reg0[6])))) recovered_125_q <= (int_frame_offset_reg0[6]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_39_146aef7
  reg recovered_126_q = 1'b0;
  assign frame_offset[39] = recovered_126_q;
  wire recovered_126_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_126_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_126_q == 1'b0))) recovered_126_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_126_q == (int_frame_offset_reg0[7])))) recovered_126_q <= (int_frame_offset_reg0[7]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_3_a993295
  reg recovered_127_q = 1'b0;
  assign frame_offset[3] = recovered_127_q;
  wire recovered_127_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_127_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_127_q == 1'b0))) recovered_127_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_127_q == (int_frame_offset_reg04_out[3])))) recovered_127_q <= (int_frame_offset_reg04_out[3]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_40_3eefd92
  reg recovered_128_q = 1'b0;
  assign frame_offset[40] = recovered_128_q;
  wire recovered_128_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_128_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_128_q == 1'b0))) recovered_128_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_128_q == (int_frame_offset_reg0[8])))) recovered_128_q <= (int_frame_offset_reg0[8]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_41_8f8f856
  reg recovered_129_q = 1'b0;
  assign frame_offset[41] = recovered_129_q;
  wire recovered_129_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_129_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_129_q == 1'b0))) recovered_129_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_129_q == (int_frame_offset_reg0[9])))) recovered_129_q <= (int_frame_offset_reg0[9]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_42_6a32611
  reg recovered_130_q = 1'b0;
  assign frame_offset[42] = recovered_130_q;
  wire recovered_130_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_130_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_130_q == 1'b0))) recovered_130_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_130_q == (int_frame_offset_reg0[10])))) recovered_130_q <= (int_frame_offset_reg0[10]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_43_29ec95a
  reg recovered_131_q = 1'b0;
  assign frame_offset[43] = recovered_131_q;
  wire recovered_131_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_131_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_131_q == 1'b0))) recovered_131_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_131_q == (int_frame_offset_reg0[11])))) recovered_131_q <= (int_frame_offset_reg0[11]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_44_b445e1a
  reg recovered_132_q = 1'b0;
  assign frame_offset[44] = recovered_132_q;
  wire recovered_132_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_132_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_132_q == 1'b0))) recovered_132_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_132_q == (int_frame_offset_reg0[12])))) recovered_132_q <= (int_frame_offset_reg0[12]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_45_a76fcc3
  reg recovered_133_q = 1'b0;
  assign frame_offset[45] = recovered_133_q;
  wire recovered_133_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_133_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_133_q == 1'b0))) recovered_133_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_133_q == (int_frame_offset_reg0[13])))) recovered_133_q <= (int_frame_offset_reg0[13]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_46_29085e9
  reg recovered_134_q = 1'b0;
  assign frame_offset[46] = recovered_134_q;
  wire recovered_134_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_134_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_134_q == 1'b0))) recovered_134_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_134_q == (int_frame_offset_reg0[14])))) recovered_134_q <= (int_frame_offset_reg0[14]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_47_ac40cc6
  reg recovered_135_q = 1'b0;
  assign frame_offset[47] = recovered_135_q;
  wire recovered_135_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_135_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_135_q == 1'b0))) recovered_135_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_135_q == (int_frame_offset_reg0[15])))) recovered_135_q <= (int_frame_offset_reg0[15]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_48_0c4f54e
  reg recovered_136_q = 1'b0;
  assign frame_offset[48] = recovered_136_q;
  wire recovered_136_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_136_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_136_q == 1'b0))) recovered_136_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_136_q == (int_frame_offset_reg0[16])))) recovered_136_q <= (int_frame_offset_reg0[16]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_49_8ce460d
  reg recovered_137_q = 1'b0;
  assign frame_offset[49] = recovered_137_q;
  wire recovered_137_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_137_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_137_q == 1'b0))) recovered_137_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_137_q == (int_frame_offset_reg0[17])))) recovered_137_q <= (int_frame_offset_reg0[17]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_4_fd93632
  reg recovered_138_q = 1'b0;
  assign frame_offset[4] = recovered_138_q;
  wire recovered_138_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_138_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_138_q == 1'b0))) recovered_138_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_138_q == (int_frame_offset_reg04_out[4])))) recovered_138_q <= (int_frame_offset_reg04_out[4]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_50_5ca6765
  reg recovered_139_q = 1'b0;
  assign frame_offset[50] = recovered_139_q;
  wire recovered_139_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_139_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_139_q == 1'b0))) recovered_139_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_139_q == (int_frame_offset_reg0[18])))) recovered_139_q <= (int_frame_offset_reg0[18]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_51_490ddcb
  reg recovered_140_q = 1'b0;
  assign frame_offset[51] = recovered_140_q;
  wire recovered_140_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_140_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_140_q == 1'b0))) recovered_140_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_140_q == (int_frame_offset_reg0[19])))) recovered_140_q <= (int_frame_offset_reg0[19]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_52_b162563
  reg recovered_141_q = 1'b0;
  assign frame_offset[52] = recovered_141_q;
  wire recovered_141_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_141_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_141_q == 1'b0))) recovered_141_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_141_q == (int_frame_offset_reg0[20])))) recovered_141_q <= (int_frame_offset_reg0[20]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_53_51589d7
  reg recovered_142_q = 1'b0;
  assign frame_offset[53] = recovered_142_q;
  wire recovered_142_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_142_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_142_q == 1'b0))) recovered_142_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_142_q == (int_frame_offset_reg0[21])))) recovered_142_q <= (int_frame_offset_reg0[21]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_54_f135974
  reg recovered_143_q = 1'b0;
  assign frame_offset[54] = recovered_143_q;
  wire recovered_143_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_143_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_143_q == 1'b0))) recovered_143_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_143_q == (int_frame_offset_reg0[22])))) recovered_143_q <= (int_frame_offset_reg0[22]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_55_f6424c9
  reg recovered_144_q = 1'b0;
  assign frame_offset[55] = recovered_144_q;
  wire recovered_144_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_144_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_144_q == 1'b0))) recovered_144_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_144_q == (int_frame_offset_reg0[23])))) recovered_144_q <= (int_frame_offset_reg0[23]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_56_75dea9e
  reg recovered_145_q = 1'b0;
  assign frame_offset[56] = recovered_145_q;
  wire recovered_145_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_145_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_145_q == 1'b0))) recovered_145_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_145_q == (int_frame_offset_reg0[24])))) recovered_145_q <= (int_frame_offset_reg0[24]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_57_85d5fbe
  reg recovered_146_q = 1'b0;
  assign frame_offset[57] = recovered_146_q;
  wire recovered_146_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_146_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_146_q == 1'b0))) recovered_146_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_146_q == (int_frame_offset_reg0[25])))) recovered_146_q <= (int_frame_offset_reg0[25]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_58_2806a79
  reg recovered_147_q = 1'b0;
  assign frame_offset[58] = recovered_147_q;
  wire recovered_147_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_147_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_147_q == 1'b0))) recovered_147_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_147_q == (int_frame_offset_reg0[26])))) recovered_147_q <= (int_frame_offset_reg0[26]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_59_7ee7e6c
  reg recovered_148_q = 1'b0;
  assign frame_offset[59] = recovered_148_q;
  wire recovered_148_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_148_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_148_q == 1'b0))) recovered_148_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_148_q == (int_frame_offset_reg0[27])))) recovered_148_q <= (int_frame_offset_reg0[27]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_5_e6a403e
  reg recovered_149_q = 1'b0;
  assign frame_offset[5] = recovered_149_q;
  wire recovered_149_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_149_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_149_q == 1'b0))) recovered_149_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_149_q == (int_frame_offset_reg04_out[5])))) recovered_149_q <= (int_frame_offset_reg04_out[5]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_60_cdec994
  reg recovered_150_q = 1'b0;
  assign frame_offset[60] = recovered_150_q;
  wire recovered_150_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_150_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_150_q == 1'b0))) recovered_150_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_150_q == (int_frame_offset_reg0[28])))) recovered_150_q <= (int_frame_offset_reg0[28]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_61_dac4be5
  reg recovered_151_q = 1'b0;
  assign frame_offset[61] = recovered_151_q;
  wire recovered_151_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_151_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_151_q == 1'b0))) recovered_151_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_151_q == (int_frame_offset_reg0[29])))) recovered_151_q <= (int_frame_offset_reg0[29]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_62_148d049
  reg recovered_152_q = 1'b0;
  assign frame_offset[62] = recovered_152_q;
  wire recovered_152_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_152_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_152_q == 1'b0))) recovered_152_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_152_q == (int_frame_offset_reg0[30])))) recovered_152_q <= (int_frame_offset_reg0[30]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_63_4f59055
  reg recovered_153_q = 1'b0;
  assign frame_offset[63] = recovered_153_q;
  wire recovered_153_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_153_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_153_q == 1'b0))) recovered_153_q <= 1'b0;
    else if ((esc_int_frame_offset_63__i_1_n_0_8c41a05) || ((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bz) || (((esc_int_frame_offset_63__i_1_n_0_8c41a05) === 1'bx) && (recovered_153_q == (int_frame_offset_reg0[31])))) recovered_153_q <= (int_frame_offset_reg0[31]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_6_1e4b4f8
  reg recovered_154_q = 1'b0;
  assign frame_offset[6] = recovered_154_q;
  wire recovered_154_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_154_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_154_q == 1'b0))) recovered_154_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_154_q == (int_frame_offset_reg04_out[6])))) recovered_154_q <= (int_frame_offset_reg04_out[6]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_7_893e5c1
  reg recovered_155_q = 1'b0;
  assign frame_offset[7] = recovered_155_q;
  wire recovered_155_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_155_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_155_q == 1'b0))) recovered_155_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_155_q == (int_frame_offset_reg04_out[7])))) recovered_155_q <= (int_frame_offset_reg04_out[7]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_8_5dae7ec
  reg recovered_156_q = 1'b0;
  assign frame_offset[8] = recovered_156_q;
  wire recovered_156_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_156_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_156_q == 1'b0))) recovered_156_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_156_q == (int_frame_offset_reg04_out[8])))) recovered_156_q <= (int_frame_offset_reg04_out[8]);
  end

  // Reconstructed FDRE: esc_int_frame_offset_reg_9_6fd43ca
  reg recovered_157_q = 1'b0;
  assign frame_offset[9] = recovered_157_q;
  wire recovered_157_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_157_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_157_q == 1'b0))) recovered_157_q <= 1'b0;
    else if ((esc_int_frame_offset_31__i_1_n_0_9d4b028) || ((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bz) || (((esc_int_frame_offset_31__i_1_n_0_9d4b028) === 1'bx) && (recovered_157_q == (int_frame_offset_reg04_out[9])))) recovered_157_q <= (int_frame_offset_reg04_out[9]);
  end

  // Reconstructed LUT6: int_gie_i_1
  assign int_gie_i_1_n_0 = ((int_gie_reg_n_0) ? (((esc_waddr_reg_n_0__2_093afb0) ? (((esc_int_ier_1__i_2_n_0_431a4c0) ? (((esc_waddr_reg_n_0__3_ccbbd3d) ? (1'b1) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b1))))) : (1'b1))) : (1'b1))) : (((esc_waddr_reg_n_0__2_093afb0) ? (((esc_int_ier_1__i_2_n_0_431a4c0) ? (((esc_waddr_reg_n_0__3_ccbbd3d) ? (1'b0) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b0))))) : (1'b0))) : (1'b0))));

  // Reconstructed FDRE: int_gie_reg
  reg recovered_159_q = 1'b0;
  assign int_gie_reg_n_0 = recovered_159_q;
  wire recovered_159_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_159_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_159_q == 1'b0))) recovered_159_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_159_q == (int_gie_i_1_n_0)))) recovered_159_q <= (int_gie_i_1_n_0);
  end

  // Reconstructed LUT6: esc_int_ier_0__i_1_c6cc610
  assign esc_int_ier_0__i_1_n_0_5993ded = ((esc_int_ier_reg_n_0__0_bd4abd3) ? (((esc_waddr_reg_n_0__3_ccbbd3d) ? (((esc_int_ier_1__i_2_n_0_431a4c0) ? (((esc_waddr_reg_n_0__2_093afb0) ? (1'b1) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b1))))) : (1'b1))) : (1'b1))) : (((esc_waddr_reg_n_0__3_ccbbd3d) ? (((esc_int_ier_1__i_2_n_0_431a4c0) ? (((esc_waddr_reg_n_0__2_093afb0) ? (1'b0) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b0))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_int_ier_1__i_1_09d0a72
  assign esc_int_ier_1__i_1_n_0_f532248 = ((p_0_in) ? (((esc_waddr_reg_n_0__3_ccbbd3d) ? (((esc_int_ier_1__i_2_n_0_431a4c0) ? (((esc_waddr_reg_n_0__2_093afb0) ? (1'b1) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[1]) : (1'b1))))) : (1'b1))) : (1'b1))) : (((esc_waddr_reg_n_0__3_ccbbd3d) ? (((esc_int_ier_1__i_2_n_0_431a4c0) ? (((esc_waddr_reg_n_0__2_093afb0) ? (1'b0) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[1]) : (1'b0))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_int_ier_1__i_2_952e1c9
  assign esc_int_ier_1__i_2_n_0_431a4c0 = ((esc_waddr_reg_n_0__4_2e446af) ? (1'b0) : (((esc_waddr_reg_n_0__1_792a10e) ? (1'b0) : (((s_axi_control_WVALID) ? (((esc_FSM_onehot_wstate_reg_2__0_190a757) ? (((esc_waddr_reg_n_0__0_ad4c065) ? (1'b0) : (~(esc_waddr_reg_n_0__5_99ccd75)))) : (1'b0))) : (1'b0))))));

  // Reconstructed FDRE: esc_int_ier_reg_0_4bef142
  reg recovered_163_q = 1'b0;
  assign esc_int_ier_reg_n_0__0_bd4abd3 = recovered_163_q;
  wire recovered_163_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_163_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_163_q == 1'b0))) recovered_163_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_163_q == (esc_int_ier_0__i_1_n_0_5993ded)))) recovered_163_q <= (esc_int_ier_0__i_1_n_0_5993ded);
  end

  // Reconstructed FDRE: esc_int_ier_reg_1_9b8b99e
  reg recovered_164_q = 1'b0;
  assign p_0_in = recovered_164_q;
  wire recovered_164_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_164_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_164_q == 1'b0))) recovered_164_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_164_q == (esc_int_ier_1__i_1_n_0_f532248)))) recovered_164_q <= (esc_int_ier_1__i_1_n_0_f532248);
  end

  // Reconstructed LUT6: esc_int_isr_0__i_1_a8d78e0
  assign esc_int_isr_0__i_1_n_0_d62a8f7 = ((esc_int_isr_reg_n_0__0_0393731) ? (((output_r_BVALID) ? (((Q[2]) ? (((esc_int_ier_reg_n_0__0_bd4abd3) ? (1'b1) : (((int_isr6_out) ? (~(s_axi_control_WDATA[0])) : (1'b1))))) : (((int_isr6_out) ? (~(s_axi_control_WDATA[0])) : (1'b1))))) : (((int_isr6_out) ? (~(s_axi_control_WDATA[0])) : (1'b1))))) : (((output_r_BVALID) ? (((Q[2]) ? (((esc_int_ier_reg_n_0__0_bd4abd3) ? (1'b1) : (((int_isr6_out) ? (s_axi_control_WDATA[0]) : (1'b0))))) : (((int_isr6_out) ? (s_axi_control_WDATA[0]) : (1'b0))))) : (((int_isr6_out) ? (s_axi_control_WDATA[0]) : (1'b0))))));

  // Reconstructed LUT4: esc_int_isr_0__i_2_79f3d5d
  assign int_isr6_out = ((esc_waddr_reg_n_0__2_093afb0) ? (((esc_int_ier_1__i_2_n_0_431a4c0) ? (((esc_waddr_reg_n_0__3_ccbbd3d) ? (s_axi_control_WSTRB[0]) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: esc_int_isr_1__i_1_22febe8
  assign esc_int_isr_1__i_1_n_0_8db0c89 = ((p_1_in) ? (((output_r_BVALID) ? (((Q[2]) ? (((p_0_in) ? (1'b1) : (((int_isr6_out) ? (~(s_axi_control_WDATA[1])) : (1'b1))))) : (((int_isr6_out) ? (~(s_axi_control_WDATA[1])) : (1'b1))))) : (((int_isr6_out) ? (~(s_axi_control_WDATA[1])) : (1'b1))))) : (((output_r_BVALID) ? (((Q[2]) ? (((p_0_in) ? (1'b1) : (((int_isr6_out) ? (s_axi_control_WDATA[1]) : (1'b0))))) : (((int_isr6_out) ? (s_axi_control_WDATA[1]) : (1'b0))))) : (((int_isr6_out) ? (s_axi_control_WDATA[1]) : (1'b0))))));

  // Reconstructed FDRE: esc_int_isr_reg_0_0ca5b08
  reg recovered_168_q = 1'b0;
  assign esc_int_isr_reg_n_0__0_0393731 = recovered_168_q;
  wire recovered_168_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_168_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_168_q == 1'b0))) recovered_168_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_168_q == (esc_int_isr_0__i_1_n_0_d62a8f7)))) recovered_168_q <= (esc_int_isr_0__i_1_n_0_d62a8f7);
  end

  // Reconstructed FDRE: esc_int_isr_reg_1_4e29141
  reg recovered_169_q = 1'b0;
  assign p_1_in = recovered_169_q;
  wire recovered_169_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_169_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_169_q == 1'b0))) recovered_169_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_169_q == (esc_int_isr_1__i_1_n_0_8db0c89)))) recovered_169_q <= (esc_int_isr_1__i_1_n_0_8db0c89);
  end

  // Reconstructed LUT3: esc_int_result_0__i_1_71cf3b8
  assign int_result_reg01_out[0] = ((esc_int_result_reg_n_0__0_fa526ec) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_10__i_1_7909f45
  assign int_result_reg01_out[10] = ((result[8]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[10]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[10]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_11__i_1_c8e66c5
  assign int_result_reg01_out[11] = ((result[9]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[11]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[11]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_12__i_1_669172f
  assign int_result_reg01_out[12] = ((result[10]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[12]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[12]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_13__i_1_bf37a89
  assign int_result_reg01_out[13] = ((result[11]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[13]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[13]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_14__i_1_cbe4794
  assign int_result_reg01_out[14] = ((result[12]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[14]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[14]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_15__i_1_27ed934
  assign int_result_reg01_out[15] = ((result[13]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[15]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[15]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_16__i_1_1000573
  assign int_result_reg01_out[16] = ((result[14]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[16]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[16]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_17__i_1_d3c4c5b
  assign int_result_reg01_out[17] = ((result[15]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[17]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[17]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_18__i_1_33d349b
  assign int_result_reg01_out[18] = ((result[16]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[18]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[18]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_19__i_1_8415117
  assign int_result_reg01_out[19] = ((result[17]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[19]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[19]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_1__i_1_85b4568
  assign int_result_reg01_out[1] = ((esc_int_result_reg_n_0__1_08c45f5) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[1]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[1]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_20__i_1_19d08f0
  assign int_result_reg01_out[20] = ((result[18]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[20]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[20]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_21__i_1_b9820ad
  assign int_result_reg01_out[21] = ((result[19]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[21]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[21]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_22__i_1_488b4aa
  assign int_result_reg01_out[22] = ((result[20]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[22]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[22]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_23__i_1_c949331
  assign int_result_reg01_out[23] = ((result[21]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[23]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[23]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_24__i_1_be5e034
  assign int_result_reg01_out[24] = ((result[22]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[24]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[24]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_25__i_1_3a20211
  assign int_result_reg01_out[25] = ((result[23]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[25]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[25]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_26__i_1_6b53558
  assign int_result_reg01_out[26] = ((result[24]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[26]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[26]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_27__i_1_3a779ee
  assign int_result_reg01_out[27] = ((result[25]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[27]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[27]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_28__i_1_910c780
  assign int_result_reg01_out[28] = ((result[26]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[28]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[28]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_29__i_1_e9cdf49
  assign int_result_reg01_out[29] = ((result[27]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[29]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[29]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_2__i_1_bf34c97
  assign int_result_reg01_out[2] = ((result[0]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[2]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[2]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_30__i_1_242a90c
  assign int_result_reg01_out[30] = ((result[28]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[30]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[30]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_31__i_1_c61fa7b
  assign esc_int_result_31__i_1_n_0_175ccd1 = ((esc_waddr_reg_n_0__2_093afb0) ? (((esc_waddr_reg_n_0__3_ccbbd3d) ? (esc_int_frame_offset_31__i_3_n_0_0fa91b0) : (1'b0))) : (1'b0));

  // Reconstructed LUT3: esc_int_result_31__i_2_e74871c
  assign int_result_reg01_out[31] = ((result[29]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[31]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[31]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_32__i_1_6e789ea
  assign int_result_reg0[0] = ((result[30]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[0]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_33__i_1_c76f8c7
  assign int_result_reg0[1] = ((result[31]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[1]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[1]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_34__i_1_8ef5664
  assign int_result_reg0[2] = ((result[32]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[2]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[2]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_35__i_1_f0496d3
  assign int_result_reg0[3] = ((result[33]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[3]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[3]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_36__i_1_d2002b0
  assign int_result_reg0[4] = ((result[34]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[4]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[4]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_37__i_1_e572de8
  assign int_result_reg0[5] = ((result[35]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[5]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[5]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_38__i_1_ea85dd6
  assign int_result_reg0[6] = ((result[36]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[6]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[6]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_39__i_1_9d0ece1
  assign int_result_reg0[7] = ((result[37]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[7]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[7]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_3__i_1_f25ba48
  assign int_result_reg01_out[3] = ((result[1]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[3]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[3]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_40__i_1_a44748a
  assign int_result_reg0[8] = ((result[38]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[8]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[8]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_41__i_1_e52c234
  assign int_result_reg0[9] = ((result[39]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[9]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[9]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_42__i_1_404b4ae
  assign int_result_reg0[10] = ((result[40]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[10]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[10]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_43__i_1_ef010b3
  assign int_result_reg0[11] = ((result[41]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[11]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[11]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_44__i_1_b4043de
  assign int_result_reg0[12] = ((result[42]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[12]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[12]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_45__i_1_e5f4855
  assign int_result_reg0[13] = ((result[43]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[13]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[13]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_46__i_1_5cbb2b2
  assign int_result_reg0[14] = ((result[44]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[14]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[14]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_47__i_1_38d66d6
  assign int_result_reg0[15] = ((result[45]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[15]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[15]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_48__i_1_0b93fd5
  assign int_result_reg0[16] = ((result[46]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[16]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[16]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_49__i_1_62112c9
  assign int_result_reg0[17] = ((result[47]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[17]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[17]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_4__i_1_311af19
  assign int_result_reg01_out[4] = ((result[2]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[4]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[4]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_50__i_1_d925b78
  assign int_result_reg0[18] = ((result[48]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[18]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[18]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_51__i_1_8d87836
  assign int_result_reg0[19] = ((result[49]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[19]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[19]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_52__i_1_44871aa
  assign int_result_reg0[20] = ((result[50]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[20]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[20]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_53__i_1_b8d6160
  assign int_result_reg0[21] = ((result[51]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[21]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[21]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_54__i_1_934e783
  assign int_result_reg0[22] = ((result[52]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[22]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[22]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_55__i_1_ebbe566
  assign int_result_reg0[23] = ((result[53]) ? (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[23]) : (1'b1))) : (((s_axi_control_WSTRB[2]) ? (s_axi_control_WDATA[23]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_56__i_1_7a063bb
  assign int_result_reg0[24] = ((result[54]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[24]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[24]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_57__i_1_21f1427
  assign int_result_reg0[25] = ((result[55]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[25]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[25]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_58__i_1_878a2ce
  assign int_result_reg0[26] = ((result[56]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[26]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[26]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_59__i_1_fe838a9
  assign int_result_reg0[27] = ((result[57]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[27]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[27]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_5__i_1_6434cd1
  assign int_result_reg01_out[5] = ((result[3]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[5]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[5]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_60__i_1_0383da9
  assign int_result_reg0[28] = ((result[58]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[28]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[28]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_61__i_1_e1384fd
  assign int_result_reg0[29] = ((result[59]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[29]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[29]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_62__i_1_c0dbfa7
  assign int_result_reg0[30] = ((result[60]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[30]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[30]) : (1'b0))));

  // Reconstructed LUT5: esc_int_result_63__i_1_51a7e7f
  assign esc_int_result_63__i_1_n_0_78c0e3f = ((esc_waddr_reg_n_0__2_093afb0) ? (1'b0) : (((esc_waddr_reg_n_0__5_99ccd75) ? (((esc_waddr_reg_n_0__4_2e446af) ? (1'b0) : (((esc_waddr_reg_n_0__3_ccbbd3d) ? (1'b0) : (esc_int_result_63__i_3_n_0_a98cf4f))))) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_63__i_2_75ce05b
  assign int_result_reg0[31] = ((result[61]) ? (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[31]) : (1'b1))) : (((s_axi_control_WSTRB[3]) ? (s_axi_control_WDATA[31]) : (1'b0))));

  // Reconstructed LUT4: esc_int_result_63__i_3_71d93a5
  assign esc_int_result_63__i_3_n_0_a98cf4f = ((esc_waddr_reg_n_0__1_792a10e) ? (1'b0) : (((s_axi_control_WVALID) ? (((esc_FSM_onehot_wstate_reg_2__0_190a757) ? (~(esc_waddr_reg_n_0__0_ad4c065)) : (1'b0))) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_6__i_1_ba5449e
  assign int_result_reg01_out[6] = ((result[4]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[6]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[6]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_7__i_1_78a67ee
  assign int_result_reg01_out[7] = ((result[5]) ? (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[7]) : (1'b1))) : (((s_axi_control_WSTRB[0]) ? (s_axi_control_WDATA[7]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_8__i_1_0814ad9
  assign int_result_reg01_out[8] = ((result[6]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[8]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[8]) : (1'b0))));

  // Reconstructed LUT3: esc_int_result_9__i_1_5100b35
  assign int_result_reg01_out[9] = ((result[7]) ? (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[9]) : (1'b1))) : (((s_axi_control_WSTRB[1]) ? (s_axi_control_WDATA[9]) : (1'b0))));

  // Reconstructed FDRE: esc_int_result_reg_0_c2293e5
  reg recovered_237_q = 1'b0;
  assign esc_int_result_reg_n_0__0_fa526ec = recovered_237_q;
  wire recovered_237_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_237_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_237_q == 1'b0))) recovered_237_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_237_q == (int_result_reg01_out[0])))) recovered_237_q <= (int_result_reg01_out[0]);
  end

  // Reconstructed FDRE: esc_int_result_reg_10_6b7f07c
  reg recovered_238_q = 1'b0;
  assign result[8] = recovered_238_q;
  wire recovered_238_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_238_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_238_q == 1'b0))) recovered_238_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_238_q == (int_result_reg01_out[10])))) recovered_238_q <= (int_result_reg01_out[10]);
  end

  // Reconstructed FDRE: esc_int_result_reg_11_2290b92
  reg recovered_239_q = 1'b0;
  assign result[9] = recovered_239_q;
  wire recovered_239_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_239_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_239_q == 1'b0))) recovered_239_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_239_q == (int_result_reg01_out[11])))) recovered_239_q <= (int_result_reg01_out[11]);
  end

  // Reconstructed FDRE: esc_int_result_reg_12_6137594
  reg recovered_240_q = 1'b0;
  assign result[10] = recovered_240_q;
  wire recovered_240_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_240_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_240_q == 1'b0))) recovered_240_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_240_q == (int_result_reg01_out[12])))) recovered_240_q <= (int_result_reg01_out[12]);
  end

  // Reconstructed FDRE: esc_int_result_reg_13_ac00479
  reg recovered_241_q = 1'b0;
  assign result[11] = recovered_241_q;
  wire recovered_241_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_241_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_241_q == 1'b0))) recovered_241_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_241_q == (int_result_reg01_out[13])))) recovered_241_q <= (int_result_reg01_out[13]);
  end

  // Reconstructed FDRE: esc_int_result_reg_14_a9d7356
  reg recovered_242_q = 1'b0;
  assign result[12] = recovered_242_q;
  wire recovered_242_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_242_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_242_q == 1'b0))) recovered_242_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_242_q == (int_result_reg01_out[14])))) recovered_242_q <= (int_result_reg01_out[14]);
  end

  // Reconstructed FDRE: esc_int_result_reg_15_c5c082e
  reg recovered_243_q = 1'b0;
  assign result[13] = recovered_243_q;
  wire recovered_243_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_243_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_243_q == 1'b0))) recovered_243_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_243_q == (int_result_reg01_out[15])))) recovered_243_q <= (int_result_reg01_out[15]);
  end

  // Reconstructed FDRE: esc_int_result_reg_16_2b77f95
  reg recovered_244_q = 1'b0;
  assign result[14] = recovered_244_q;
  wire recovered_244_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_244_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_244_q == 1'b0))) recovered_244_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_244_q == (int_result_reg01_out[16])))) recovered_244_q <= (int_result_reg01_out[16]);
  end

  // Reconstructed FDRE: esc_int_result_reg_17_81f6702
  reg recovered_245_q = 1'b0;
  assign result[15] = recovered_245_q;
  wire recovered_245_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_245_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_245_q == 1'b0))) recovered_245_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_245_q == (int_result_reg01_out[17])))) recovered_245_q <= (int_result_reg01_out[17]);
  end

  // Reconstructed FDRE: esc_int_result_reg_18_c3f99dc
  reg recovered_246_q = 1'b0;
  assign result[16] = recovered_246_q;
  wire recovered_246_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_246_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_246_q == 1'b0))) recovered_246_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_246_q == (int_result_reg01_out[18])))) recovered_246_q <= (int_result_reg01_out[18]);
  end

  // Reconstructed FDRE: esc_int_result_reg_19_5abed73
  reg recovered_247_q = 1'b0;
  assign result[17] = recovered_247_q;
  wire recovered_247_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_247_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_247_q == 1'b0))) recovered_247_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_247_q == (int_result_reg01_out[19])))) recovered_247_q <= (int_result_reg01_out[19]);
  end

  // Reconstructed FDRE: esc_int_result_reg_1_243ca3e
  reg recovered_248_q = 1'b0;
  assign esc_int_result_reg_n_0__1_08c45f5 = recovered_248_q;
  wire recovered_248_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_248_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_248_q == 1'b0))) recovered_248_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_248_q == (int_result_reg01_out[1])))) recovered_248_q <= (int_result_reg01_out[1]);
  end

  // Reconstructed FDRE: esc_int_result_reg_20_057558c
  reg recovered_249_q = 1'b0;
  assign result[18] = recovered_249_q;
  wire recovered_249_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_249_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_249_q == 1'b0))) recovered_249_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_249_q == (int_result_reg01_out[20])))) recovered_249_q <= (int_result_reg01_out[20]);
  end

  // Reconstructed FDRE: esc_int_result_reg_21_b8d97a8
  reg recovered_250_q = 1'b0;
  assign result[19] = recovered_250_q;
  wire recovered_250_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_250_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_250_q == 1'b0))) recovered_250_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_250_q == (int_result_reg01_out[21])))) recovered_250_q <= (int_result_reg01_out[21]);
  end

  // Reconstructed FDRE: esc_int_result_reg_22_f90cf8e
  reg recovered_251_q = 1'b0;
  assign result[20] = recovered_251_q;
  wire recovered_251_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_251_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_251_q == 1'b0))) recovered_251_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_251_q == (int_result_reg01_out[22])))) recovered_251_q <= (int_result_reg01_out[22]);
  end

  // Reconstructed FDRE: esc_int_result_reg_23_e5c898d
  reg recovered_252_q = 1'b0;
  assign result[21] = recovered_252_q;
  wire recovered_252_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_252_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_252_q == 1'b0))) recovered_252_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_252_q == (int_result_reg01_out[23])))) recovered_252_q <= (int_result_reg01_out[23]);
  end

  // Reconstructed FDRE: esc_int_result_reg_24_b8a36d2
  reg recovered_253_q = 1'b0;
  assign result[22] = recovered_253_q;
  wire recovered_253_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_253_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_253_q == 1'b0))) recovered_253_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_253_q == (int_result_reg01_out[24])))) recovered_253_q <= (int_result_reg01_out[24]);
  end

  // Reconstructed FDRE: esc_int_result_reg_25_3170305
  reg recovered_254_q = 1'b0;
  assign result[23] = recovered_254_q;
  wire recovered_254_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_254_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_254_q == 1'b0))) recovered_254_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_254_q == (int_result_reg01_out[25])))) recovered_254_q <= (int_result_reg01_out[25]);
  end

  // Reconstructed FDRE: esc_int_result_reg_26_880e047
  reg recovered_255_q = 1'b0;
  assign result[24] = recovered_255_q;
  wire recovered_255_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_255_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_255_q == 1'b0))) recovered_255_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_255_q == (int_result_reg01_out[26])))) recovered_255_q <= (int_result_reg01_out[26]);
  end

  // Reconstructed FDRE: esc_int_result_reg_27_75dd9f4
  reg recovered_256_q = 1'b0;
  assign result[25] = recovered_256_q;
  wire recovered_256_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_256_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_256_q == 1'b0))) recovered_256_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_256_q == (int_result_reg01_out[27])))) recovered_256_q <= (int_result_reg01_out[27]);
  end

  // Reconstructed FDRE: esc_int_result_reg_28_df4360f
  reg recovered_257_q = 1'b0;
  assign result[26] = recovered_257_q;
  wire recovered_257_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_257_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_257_q == 1'b0))) recovered_257_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_257_q == (int_result_reg01_out[28])))) recovered_257_q <= (int_result_reg01_out[28]);
  end

  // Reconstructed FDRE: esc_int_result_reg_29_88c34b1
  reg recovered_258_q = 1'b0;
  assign result[27] = recovered_258_q;
  wire recovered_258_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_258_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_258_q == 1'b0))) recovered_258_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_258_q == (int_result_reg01_out[29])))) recovered_258_q <= (int_result_reg01_out[29]);
  end

  // Reconstructed FDRE: esc_int_result_reg_2_93a557e
  reg recovered_259_q = 1'b0;
  assign result[0] = recovered_259_q;
  wire recovered_259_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_259_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_259_q == 1'b0))) recovered_259_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_259_q == (int_result_reg01_out[2])))) recovered_259_q <= (int_result_reg01_out[2]);
  end

  // Reconstructed FDRE: esc_int_result_reg_30_32772fe
  reg recovered_260_q = 1'b0;
  assign result[28] = recovered_260_q;
  wire recovered_260_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_260_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_260_q == 1'b0))) recovered_260_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_260_q == (int_result_reg01_out[30])))) recovered_260_q <= (int_result_reg01_out[30]);
  end

  // Reconstructed FDRE: esc_int_result_reg_31_299810f
  reg recovered_261_q = 1'b0;
  assign result[29] = recovered_261_q;
  wire recovered_261_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_261_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_261_q == 1'b0))) recovered_261_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_261_q == (int_result_reg01_out[31])))) recovered_261_q <= (int_result_reg01_out[31]);
  end

  // Reconstructed FDRE: esc_int_result_reg_32_63c079e
  reg recovered_262_q = 1'b0;
  assign result[30] = recovered_262_q;
  wire recovered_262_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_262_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_262_q == 1'b0))) recovered_262_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_262_q == (int_result_reg0[0])))) recovered_262_q <= (int_result_reg0[0]);
  end

  // Reconstructed FDRE: esc_int_result_reg_33_1e11aa1
  reg recovered_263_q = 1'b0;
  assign result[31] = recovered_263_q;
  wire recovered_263_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_263_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_263_q == 1'b0))) recovered_263_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_263_q == (int_result_reg0[1])))) recovered_263_q <= (int_result_reg0[1]);
  end

  // Reconstructed FDRE: esc_int_result_reg_34_314b370
  reg recovered_264_q = 1'b0;
  assign result[32] = recovered_264_q;
  wire recovered_264_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_264_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_264_q == 1'b0))) recovered_264_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_264_q == (int_result_reg0[2])))) recovered_264_q <= (int_result_reg0[2]);
  end

  // Reconstructed FDRE: esc_int_result_reg_35_ca905db
  reg recovered_265_q = 1'b0;
  assign result[33] = recovered_265_q;
  wire recovered_265_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_265_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_265_q == 1'b0))) recovered_265_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_265_q == (int_result_reg0[3])))) recovered_265_q <= (int_result_reg0[3]);
  end

  // Reconstructed FDRE: esc_int_result_reg_36_011696a
  reg recovered_266_q = 1'b0;
  assign result[34] = recovered_266_q;
  wire recovered_266_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_266_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_266_q == 1'b0))) recovered_266_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_266_q == (int_result_reg0[4])))) recovered_266_q <= (int_result_reg0[4]);
  end

  // Reconstructed FDRE: esc_int_result_reg_37_d8a205d
  reg recovered_267_q = 1'b0;
  assign result[35] = recovered_267_q;
  wire recovered_267_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_267_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_267_q == 1'b0))) recovered_267_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_267_q == (int_result_reg0[5])))) recovered_267_q <= (int_result_reg0[5]);
  end

  // Reconstructed FDRE: esc_int_result_reg_38_65eb6f1
  reg recovered_268_q = 1'b0;
  assign result[36] = recovered_268_q;
  wire recovered_268_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_268_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_268_q == 1'b0))) recovered_268_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_268_q == (int_result_reg0[6])))) recovered_268_q <= (int_result_reg0[6]);
  end

  // Reconstructed FDRE: esc_int_result_reg_39_816d7c0
  reg recovered_269_q = 1'b0;
  assign result[37] = recovered_269_q;
  wire recovered_269_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_269_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_269_q == 1'b0))) recovered_269_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_269_q == (int_result_reg0[7])))) recovered_269_q <= (int_result_reg0[7]);
  end

  // Reconstructed FDRE: esc_int_result_reg_3_5ae9031
  reg recovered_270_q = 1'b0;
  assign result[1] = recovered_270_q;
  wire recovered_270_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_270_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_270_q == 1'b0))) recovered_270_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_270_q == (int_result_reg01_out[3])))) recovered_270_q <= (int_result_reg01_out[3]);
  end

  // Reconstructed FDRE: esc_int_result_reg_40_bf9dd0e
  reg recovered_271_q = 1'b0;
  assign result[38] = recovered_271_q;
  wire recovered_271_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_271_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_271_q == 1'b0))) recovered_271_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_271_q == (int_result_reg0[8])))) recovered_271_q <= (int_result_reg0[8]);
  end

  // Reconstructed FDRE: esc_int_result_reg_41_7f7c079
  reg recovered_272_q = 1'b0;
  assign result[39] = recovered_272_q;
  wire recovered_272_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_272_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_272_q == 1'b0))) recovered_272_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_272_q == (int_result_reg0[9])))) recovered_272_q <= (int_result_reg0[9]);
  end

  // Reconstructed FDRE: esc_int_result_reg_42_7e825a2
  reg recovered_273_q = 1'b0;
  assign result[40] = recovered_273_q;
  wire recovered_273_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_273_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_273_q == 1'b0))) recovered_273_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_273_q == (int_result_reg0[10])))) recovered_273_q <= (int_result_reg0[10]);
  end

  // Reconstructed FDRE: esc_int_result_reg_43_816fb46
  reg recovered_274_q = 1'b0;
  assign result[41] = recovered_274_q;
  wire recovered_274_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_274_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_274_q == 1'b0))) recovered_274_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_274_q == (int_result_reg0[11])))) recovered_274_q <= (int_result_reg0[11]);
  end

  // Reconstructed FDRE: esc_int_result_reg_44_0f4d493
  reg recovered_275_q = 1'b0;
  assign result[42] = recovered_275_q;
  wire recovered_275_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_275_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_275_q == 1'b0))) recovered_275_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_275_q == (int_result_reg0[12])))) recovered_275_q <= (int_result_reg0[12]);
  end

  // Reconstructed FDRE: esc_int_result_reg_45_b8c5d26
  reg recovered_276_q = 1'b0;
  assign result[43] = recovered_276_q;
  wire recovered_276_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_276_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_276_q == 1'b0))) recovered_276_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_276_q == (int_result_reg0[13])))) recovered_276_q <= (int_result_reg0[13]);
  end

  // Reconstructed FDRE: esc_int_result_reg_46_0e8c955
  reg recovered_277_q = 1'b0;
  assign result[44] = recovered_277_q;
  wire recovered_277_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_277_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_277_q == 1'b0))) recovered_277_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_277_q == (int_result_reg0[14])))) recovered_277_q <= (int_result_reg0[14]);
  end

  // Reconstructed FDRE: esc_int_result_reg_47_f4af2a8
  reg recovered_278_q = 1'b0;
  assign result[45] = recovered_278_q;
  wire recovered_278_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_278_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_278_q == 1'b0))) recovered_278_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_278_q == (int_result_reg0[15])))) recovered_278_q <= (int_result_reg0[15]);
  end

  // Reconstructed FDRE: esc_int_result_reg_48_1244718
  reg recovered_279_q = 1'b0;
  assign result[46] = recovered_279_q;
  wire recovered_279_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_279_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_279_q == 1'b0))) recovered_279_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_279_q == (int_result_reg0[16])))) recovered_279_q <= (int_result_reg0[16]);
  end

  // Reconstructed FDRE: esc_int_result_reg_49_6fc8694
  reg recovered_280_q = 1'b0;
  assign result[47] = recovered_280_q;
  wire recovered_280_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_280_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_280_q == 1'b0))) recovered_280_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_280_q == (int_result_reg0[17])))) recovered_280_q <= (int_result_reg0[17]);
  end

  // Reconstructed FDRE: esc_int_result_reg_4_dc7aaf0
  reg recovered_281_q = 1'b0;
  assign result[2] = recovered_281_q;
  wire recovered_281_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_281_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_281_q == 1'b0))) recovered_281_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_281_q == (int_result_reg01_out[4])))) recovered_281_q <= (int_result_reg01_out[4]);
  end

  // Reconstructed FDRE: esc_int_result_reg_50_35cdafa
  reg recovered_282_q = 1'b0;
  assign result[48] = recovered_282_q;
  wire recovered_282_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_282_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_282_q == 1'b0))) recovered_282_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_282_q == (int_result_reg0[18])))) recovered_282_q <= (int_result_reg0[18]);
  end

  // Reconstructed FDRE: esc_int_result_reg_51_ed6accc
  reg recovered_283_q = 1'b0;
  assign result[49] = recovered_283_q;
  wire recovered_283_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_283_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_283_q == 1'b0))) recovered_283_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_283_q == (int_result_reg0[19])))) recovered_283_q <= (int_result_reg0[19]);
  end

  // Reconstructed FDRE: esc_int_result_reg_52_e9a3912
  reg recovered_284_q = 1'b0;
  assign result[50] = recovered_284_q;
  wire recovered_284_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_284_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_284_q == 1'b0))) recovered_284_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_284_q == (int_result_reg0[20])))) recovered_284_q <= (int_result_reg0[20]);
  end

  // Reconstructed FDRE: esc_int_result_reg_53_0f3e333
  reg recovered_285_q = 1'b0;
  assign result[51] = recovered_285_q;
  wire recovered_285_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_285_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_285_q == 1'b0))) recovered_285_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_285_q == (int_result_reg0[21])))) recovered_285_q <= (int_result_reg0[21]);
  end

  // Reconstructed FDRE: esc_int_result_reg_54_aa450f3
  reg recovered_286_q = 1'b0;
  assign result[52] = recovered_286_q;
  wire recovered_286_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_286_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_286_q == 1'b0))) recovered_286_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_286_q == (int_result_reg0[22])))) recovered_286_q <= (int_result_reg0[22]);
  end

  // Reconstructed FDRE: esc_int_result_reg_55_96266ab
  reg recovered_287_q = 1'b0;
  assign result[53] = recovered_287_q;
  wire recovered_287_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_287_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_287_q == 1'b0))) recovered_287_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_287_q == (int_result_reg0[23])))) recovered_287_q <= (int_result_reg0[23]);
  end

  // Reconstructed FDRE: esc_int_result_reg_56_f4a1cf6
  reg recovered_288_q = 1'b0;
  assign result[54] = recovered_288_q;
  wire recovered_288_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_288_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_288_q == 1'b0))) recovered_288_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_288_q == (int_result_reg0[24])))) recovered_288_q <= (int_result_reg0[24]);
  end

  // Reconstructed FDRE: esc_int_result_reg_57_5f6e0a0
  reg recovered_289_q = 1'b0;
  assign result[55] = recovered_289_q;
  wire recovered_289_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_289_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_289_q == 1'b0))) recovered_289_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_289_q == (int_result_reg0[25])))) recovered_289_q <= (int_result_reg0[25]);
  end

  // Reconstructed FDRE: esc_int_result_reg_58_f42d3b8
  reg recovered_290_q = 1'b0;
  assign result[56] = recovered_290_q;
  wire recovered_290_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_290_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_290_q == 1'b0))) recovered_290_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_290_q == (int_result_reg0[26])))) recovered_290_q <= (int_result_reg0[26]);
  end

  // Reconstructed FDRE: esc_int_result_reg_59_3f7da7a
  reg recovered_291_q = 1'b0;
  assign result[57] = recovered_291_q;
  wire recovered_291_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_291_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_291_q == 1'b0))) recovered_291_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_291_q == (int_result_reg0[27])))) recovered_291_q <= (int_result_reg0[27]);
  end

  // Reconstructed FDRE: esc_int_result_reg_5_1df1634
  reg recovered_292_q = 1'b0;
  assign result[3] = recovered_292_q;
  wire recovered_292_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_292_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_292_q == 1'b0))) recovered_292_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_292_q == (int_result_reg01_out[5])))) recovered_292_q <= (int_result_reg01_out[5]);
  end

  // Reconstructed FDRE: esc_int_result_reg_60_d31f978
  reg recovered_293_q = 1'b0;
  assign result[58] = recovered_293_q;
  wire recovered_293_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_293_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_293_q == 1'b0))) recovered_293_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_293_q == (int_result_reg0[28])))) recovered_293_q <= (int_result_reg0[28]);
  end

  // Reconstructed FDRE: esc_int_result_reg_61_4d95d3d
  reg recovered_294_q = 1'b0;
  assign result[59] = recovered_294_q;
  wire recovered_294_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_294_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_294_q == 1'b0))) recovered_294_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_294_q == (int_result_reg0[29])))) recovered_294_q <= (int_result_reg0[29]);
  end

  // Reconstructed FDRE: esc_int_result_reg_62_bd31a52
  reg recovered_295_q = 1'b0;
  assign result[60] = recovered_295_q;
  wire recovered_295_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_295_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_295_q == 1'b0))) recovered_295_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_295_q == (int_result_reg0[30])))) recovered_295_q <= (int_result_reg0[30]);
  end

  // Reconstructed FDRE: esc_int_result_reg_63_ed65672
  reg recovered_296_q = 1'b0;
  assign result[61] = recovered_296_q;
  wire recovered_296_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_296_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_296_q == 1'b0))) recovered_296_q <= 1'b0;
    else if ((esc_int_result_63__i_1_n_0_78c0e3f) || ((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bz) || (((esc_int_result_63__i_1_n_0_78c0e3f) === 1'bx) && (recovered_296_q == (int_result_reg0[31])))) recovered_296_q <= (int_result_reg0[31]);
  end

  // Reconstructed FDRE: esc_int_result_reg_6_89a4c7d
  reg recovered_297_q = 1'b0;
  assign result[4] = recovered_297_q;
  wire recovered_297_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_297_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_297_q == 1'b0))) recovered_297_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_297_q == (int_result_reg01_out[6])))) recovered_297_q <= (int_result_reg01_out[6]);
  end

  // Reconstructed FDRE: esc_int_result_reg_7_d6494d5
  reg recovered_298_q = 1'b0;
  assign result[5] = recovered_298_q;
  wire recovered_298_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_298_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_298_q == 1'b0))) recovered_298_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_298_q == (int_result_reg01_out[7])))) recovered_298_q <= (int_result_reg01_out[7]);
  end

  // Reconstructed FDRE: esc_int_result_reg_8_6e0c7fe
  reg recovered_299_q = 1'b0;
  assign result[6] = recovered_299_q;
  wire recovered_299_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_299_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_299_q == 1'b0))) recovered_299_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_299_q == (int_result_reg01_out[8])))) recovered_299_q <= (int_result_reg01_out[8]);
  end

  // Reconstructed FDRE: esc_int_result_reg_9_3b9dddc
  reg recovered_300_q = 1'b0;
  assign result[7] = recovered_300_q;
  wire recovered_300_reset = ((int_ap_idle_reg_0)) && ((int_ap_idle_reg_0) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_300_reset || (((int_ap_idle_reg_0) === 1'bx) && (recovered_300_q == 1'b0))) recovered_300_q <= 1'b0;
    else if ((esc_int_result_31__i_1_n_0_175ccd1) || ((esc_int_result_31__i_1_n_0_175ccd1) === 1'bz) || (((esc_int_result_31__i_1_n_0_175ccd1) === 1'bx) && (recovered_300_q == (int_result_reg01_out[9])))) recovered_300_q <= (int_result_reg01_out[9]);
  end

  // Reconstructed LUT6: esc_rdata_0__i_2_0442266
  assign esc_rdata_0__i_2_n_0_a457df0 = ((ap_start) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((int_gie_reg_n_0) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (esc_int_isr_reg_n_0__0_0393731) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (esc_int_isr_reg_n_0__0_0393731) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (esc_int_ier_reg_n_0__0_bd4abd3) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((int_gie_reg_n_0) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (esc_int_isr_reg_n_0__0_0393731) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (esc_int_isr_reg_n_0__0_0393731) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (esc_int_ier_reg_n_0__0_bd4abd3) : (1'b0))))));

  // Reconstructed LUT6: esc_rdata_0__i_3_962596f
  assign esc_rdata_0__i_3_n_0_cc4cf56 = ((frame_offset[0]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[32]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[30]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[30]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (esc_int_result_reg_n_0__0_fa526ec) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[32]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[30]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[30]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (esc_int_result_reg_n_0__0_fa526ec) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_10__i_1_5157948
  assign esc_rdata_10__i_1_n_0_7293013 = ((esc_rdata_10__i_2_n_0_0bd83d1) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_10__i_2_27324e9
  assign esc_rdata_10__i_2_n_0_0bd83d1 = ((frame_offset[10]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[42]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[40]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[40]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[8]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[42]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[40]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[40]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[8]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_11__i_1_7f5ee78
  assign esc_rdata_11__i_1_n_0_0a44289 = ((esc_rdata_11__i_2_n_0_e5907a0) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_11__i_2_bb7b88b
  assign esc_rdata_11__i_2_n_0_e5907a0 = ((frame_offset[11]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[43]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[41]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[41]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[9]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[43]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[41]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[41]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[9]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_12__i_1_ad85025
  assign esc_rdata_12__i_1_n_0_a987590 = ((esc_rdata_12__i_2_n_0_aef06b1) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_12__i_2_6bc5d91
  assign esc_rdata_12__i_2_n_0_aef06b1 = ((frame_offset[12]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[44]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[42]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[42]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[10]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[44]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[42]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[42]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[10]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_13__i_1_a7a4340
  assign esc_rdata_13__i_1_n_0_f78d886 = ((esc_rdata_13__i_2_n_0_b8a0eea) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_13__i_2_c945717
  assign esc_rdata_13__i_2_n_0_b8a0eea = ((frame_offset[13]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[45]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[43]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[43]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[11]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[45]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[43]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[43]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[11]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_14__i_1_d83326c
  assign esc_rdata_14__i_1_n_0_b131f65 = ((esc_rdata_14__i_2_n_0_577e317) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_14__i_2_f780847
  assign esc_rdata_14__i_2_n_0_577e317 = ((frame_offset[14]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[46]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[44]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[44]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[12]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[46]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[44]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[44]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[12]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_15__i_1_dfa308a
  assign esc_rdata_15__i_1_n_0_883ba46 = ((esc_rdata_15__i_2_n_0_dcb2157) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_15__i_2_d1e09f8
  assign esc_rdata_15__i_2_n_0_dcb2157 = ((frame_offset[15]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[47]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[45]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[45]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[13]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[47]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[45]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[45]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[13]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_16__i_1_e06b782
  assign esc_rdata_16__i_1_n_0_fd4dc4d = ((esc_rdata_16__i_2_n_0_b7e52a7) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_16__i_2_a441bc8
  assign esc_rdata_16__i_2_n_0_b7e52a7 = ((frame_offset[16]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[48]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[46]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[46]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[14]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[48]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[46]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[46]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[14]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_17__i_1_1e80107
  assign esc_rdata_17__i_1_n_0_3240d5b = ((esc_rdata_17__i_2_n_0_08d9aec) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_17__i_2_4100edd
  assign esc_rdata_17__i_2_n_0_08d9aec = ((frame_offset[17]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[49]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[47]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[47]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[15]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[49]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[47]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[47]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[15]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_18__i_1_efbf419
  assign esc_rdata_18__i_1_n_0_4dfbff6 = ((esc_rdata_18__i_2_n_0_90770c7) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_18__i_2_09fb68d
  assign esc_rdata_18__i_2_n_0_90770c7 = ((frame_offset[18]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[50]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[48]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[48]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[16]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[50]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[48]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[48]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[16]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_19__i_1_dd90e5d
  assign esc_rdata_19__i_1_n_0_eec9235 = ((esc_rdata_19__i_2_n_0_576972e) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_19__i_2_1c06f3e
  assign esc_rdata_19__i_2_n_0_576972e = ((frame_offset[19]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[51]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[49]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[49]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[17]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[51]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[49]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[49]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[17]) : (1'b0))))));

  // Reconstructed LUT5: esc_rdata_1__i_2_b5154aa
  assign esc_rdata_1__i_2_n_0_4d64846 = ((esc_rdata_7__i_3_n_0_9018222) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (p_1_in) : (1'b0))) : (((data0[1]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (p_0_in) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (p_0_in) : (1'b0))))));

  // Reconstructed LUT6: esc_rdata_1__i_3_1070e2f
  assign esc_rdata_1__i_3_n_0_77c227d = ((frame_offset[1]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[33]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[31]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[31]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (esc_int_result_reg_n_0__1_08c45f5) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[33]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[31]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[31]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (esc_int_result_reg_n_0__1_08c45f5) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_20__i_1_826d311
  assign esc_rdata_20__i_1_n_0_f79cc60 = ((esc_rdata_20__i_2_n_0_5da6e01) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_20__i_2_088a137
  assign esc_rdata_20__i_2_n_0_5da6e01 = ((frame_offset[20]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[52]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[50]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[50]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[18]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[52]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[50]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[50]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[18]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_21__i_1_7e82464
  assign esc_rdata_21__i_1_n_0_2ddd0f7 = ((esc_rdata_21__i_2_n_0_b0183b7) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_21__i_2_46e1423
  assign esc_rdata_21__i_2_n_0_b0183b7 = ((frame_offset[21]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[53]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[51]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[51]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[19]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[53]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[51]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[51]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[19]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_22__i_1_8c4e422
  assign esc_rdata_22__i_1_n_0_3999317 = ((esc_rdata_22__i_2_n_0_ecb605b) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_22__i_2_de05106
  assign esc_rdata_22__i_2_n_0_ecb605b = ((frame_offset[22]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[54]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[52]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[52]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[20]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[54]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[52]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[52]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[20]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_23__i_1_61a0922
  assign esc_rdata_23__i_1_n_0_d581e50 = ((esc_rdata_23__i_2_n_0_482ee71) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_23__i_2_e60e22c
  assign esc_rdata_23__i_2_n_0_482ee71 = ((frame_offset[23]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[55]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[53]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[53]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[21]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[55]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[53]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[53]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[21]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_24__i_1_6fe01c4
  assign esc_rdata_24__i_1_n_0_b89864b = ((esc_rdata_24__i_2_n_0_f792bb4) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_24__i_2_94209a9
  assign esc_rdata_24__i_2_n_0_f792bb4 = ((frame_offset[24]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[56]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[54]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[54]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[22]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[56]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[54]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[54]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[22]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_25__i_1_522ad1f
  assign esc_rdata_25__i_1_n_0_8a2b956 = ((esc_rdata_25__i_2_n_0_3ac8ed7) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_25__i_2_bd5ae5b
  assign esc_rdata_25__i_2_n_0_3ac8ed7 = ((frame_offset[25]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[57]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[55]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[55]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[23]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[57]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[55]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[55]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[23]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_26__i_1_7a66fa1
  assign esc_rdata_26__i_1_n_0_23f5691 = ((esc_rdata_26__i_2_n_0_e8cd84e) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_26__i_2_f5cb55f
  assign esc_rdata_26__i_2_n_0_e8cd84e = ((frame_offset[26]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[58]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[56]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[56]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[24]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[58]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[56]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[56]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[24]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_27__i_1_5241a0d
  assign esc_rdata_27__i_1_n_0_502b465 = ((esc_rdata_27__i_2_n_0_1ef1b07) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_27__i_2_3a1e6fb
  assign esc_rdata_27__i_2_n_0_1ef1b07 = ((frame_offset[27]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[59]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[57]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[57]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[25]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[59]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[57]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[57]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[25]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_28__i_1_023ccca
  assign esc_rdata_28__i_1_n_0_6743271 = ((esc_rdata_28__i_2_n_0_c7adcf5) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_28__i_2_08de8ac
  assign esc_rdata_28__i_2_n_0_c7adcf5 = ((frame_offset[28]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[60]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[58]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[58]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[26]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[60]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[58]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[58]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[26]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_29__i_1_ee60a9e
  assign esc_rdata_29__i_1_n_0_1c1ef74 = ((esc_rdata_29__i_2_n_0_916a39c) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_29__i_2_b61484f
  assign esc_rdata_29__i_2_n_0_916a39c = ((frame_offset[29]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[61]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[59]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[59]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[27]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[61]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[59]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[59]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[27]) : (1'b0))))));

  // Reconstructed LUT5: esc_rdata_2__i_1_c163923
  assign esc_rdata_2__i_1_n_0_c9bdce3 = ((esc_rdata_7__i_4_n_0_2ace495) ? (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_2__i_2_n_0_5a1091a) : (1'b0))) : (((data0[2]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_2__i_2_n_0_5a1091a) : (1'b0))) : (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_2__i_2_n_0_5a1091a) : (1'b1))))) : (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_2__i_2_n_0_5a1091a) : (1'b0))))));

  // Reconstructed LUT6: esc_rdata_2__i_2_554bbcf
  assign esc_rdata_2__i_2_n_0_5a1091a = ((frame_offset[2]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[34]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[32]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[32]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[0]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[34]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[32]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[32]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[0]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_30__i_1_56591d3
  assign esc_rdata_30__i_1_n_0_324ea32 = ((esc_rdata_30__i_2_n_0_4e6bc31) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_30__i_2_5730cfc
  assign esc_rdata_30__i_2_n_0_4e6bc31 = ((frame_offset[30]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[62]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[60]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[60]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[28]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[62]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[60]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[60]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[28]) : (1'b0))))));

  // Reconstructed LUT6: esc_rdata_31__i_1_fddfb72
  assign esc_rdata_31__i_1_n_0_4ab42c1 = ((ar_hs) ? (((esc_rdata_31__i_4_n_0_1328de1) ? (1'b1) : (((s_axi_control_ARADDR[2]) ? (s_axi_control_ARADDR[5]) : (((s_axi_control_ARADDR[4]) ? (((s_axi_control_ARADDR[5]) ? (1'b1) : (s_axi_control_ARADDR[3]))) : (((s_axi_control_ARADDR[5]) ? (s_axi_control_ARADDR[3]) : (1'b0))))))))) : (1'b0));

  // Reconstructed LUT2: esc_rdata_31__i_2_6c2c2b3
  assign ar_hs = ((s_axi_control_ARVALID) ? (esc_FSM_onehot_rstate_reg_1__0_1ba0d01) : (1'b0));

  // Reconstructed LUT2: esc_rdata_31__i_3_3c950fb
  assign esc_rdata_31__i_3_n_0_5a50bb4 = ((esc_rdata_31__i_6_n_0_7d1dbb6) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT2: esc_rdata_31__i_4_c04a875
  assign esc_rdata_31__i_4_n_0_1328de1 = ((s_axi_control_ARADDR[0]) ? (1'b1) : (s_axi_control_ARADDR[1]));

  // Reconstructed LUT6: esc_rdata_31__i_5_c434a98
  assign esc_rdata_31__i_5_n_0_7df9488 = ((s_axi_control_ARADDR[1]) ? (1'b0) : (((s_axi_control_ARADDR[0]) ? (1'b0) : (((s_axi_control_ARADDR[2]) ? (((s_axi_control_ARADDR[5]) ? (1'b0) : (s_axi_control_ARADDR[4]))) : (((s_axi_control_ARADDR[5]) ? (((s_axi_control_ARADDR[4]) ? (1'b0) : (~(s_axi_control_ARADDR[3])))) : (((s_axi_control_ARADDR[4]) ? (~(s_axi_control_ARADDR[3])) : (1'b0))))))))));

  // Reconstructed LUT6: esc_rdata_31__i_6_234fc93
  assign esc_rdata_31__i_6_n_0_7d1dbb6 = ((frame_offset[31]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[63]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[61]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[61]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[29]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[63]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[61]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[61]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[29]) : (1'b0))))));

  // Reconstructed LUT5: esc_rdata_3__i_1_bd67d58
  assign esc_rdata_3__i_1_n_0_a67420f = ((esc_rdata_7__i_4_n_0_2ace495) ? (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_3__i_2_n_0_3344c46) : (1'b0))) : (((data0[3]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_3__i_2_n_0_3344c46) : (1'b0))) : (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_3__i_2_n_0_3344c46) : (1'b1))))) : (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_3__i_2_n_0_3344c46) : (1'b0))))));

  // Reconstructed LUT6: esc_rdata_3__i_2_85ec72b
  assign esc_rdata_3__i_2_n_0_3344c46 = ((frame_offset[3]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[35]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[33]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[33]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[1]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[35]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[33]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[33]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[1]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_4__i_1_726f973
  assign esc_rdata_4__i_1_n_0_1a98800 = ((esc_rdata_4__i_2_n_0_0bb3f4c) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_4__i_2_1e2555c
  assign esc_rdata_4__i_2_n_0_0bb3f4c = ((frame_offset[4]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[36]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[34]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[34]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[2]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[36]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[34]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[34]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[2]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_5__i_1_c14458c
  assign esc_rdata_5__i_1_n_0_e4d287d = ((esc_rdata_5__i_2_n_0_74dce8c) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_5__i_2_3d9741f
  assign esc_rdata_5__i_2_n_0_74dce8c = ((frame_offset[5]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[37]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[35]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[35]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[3]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[37]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[35]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[35]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[3]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_6__i_1_60050a3
  assign esc_rdata_6__i_1_n_0_23d2e97 = ((esc_rdata_6__i_2_n_0_e9b9ddb) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_6__i_2_4225a6e
  assign esc_rdata_6__i_2_n_0_e9b9ddb = ((frame_offset[6]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[38]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[36]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[36]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[4]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[38]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[36]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[36]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[4]) : (1'b0))))));

  // Reconstructed LUT5: esc_rdata_7__i_1_5ab1409
  assign esc_rdata_7__i_1_n_0_b768213 = ((esc_rdata_7__i_4_n_0_2ace495) ? (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_7__i_2_n_0_b89d9ae) : (1'b0))) : (((data0[7]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_7__i_2_n_0_b89d9ae) : (1'b0))) : (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_7__i_2_n_0_b89d9ae) : (1'b1))))) : (((esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_7__i_2_n_0_b89d9ae) : (1'b0))))));

  // Reconstructed LUT6: esc_rdata_7__i_2_2f27dea
  assign esc_rdata_7__i_2_n_0_b89d9ae = ((frame_offset[7]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[39]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[37]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[37]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[5]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[39]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[37]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[37]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[5]) : (1'b0))))));

  // Reconstructed LUT6: esc_rdata_7__i_3_3b6d175
  assign esc_rdata_7__i_3_n_0_9018222 = ((s_axi_control_ARADDR[1]) ? (1'b0) : (((s_axi_control_ARADDR[0]) ? (1'b0) : (((s_axi_control_ARADDR[2]) ? (((s_axi_control_ARADDR[5]) ? (1'b0) : (((s_axi_control_ARADDR[3]) ? (~(s_axi_control_ARADDR[4])) : (1'b1))))) : (((s_axi_control_ARADDR[5]) ? (((s_axi_control_ARADDR[3]) ? (1'b0) : (~(s_axi_control_ARADDR[4])))) : (1'b0))))))));

  // Reconstructed LUT6: esc_rdata_7__i_4_5a08f3d
  assign esc_rdata_7__i_4_n_0_2ace495 = ((s_axi_control_ARADDR[1]) ? (1'b0) : (((s_axi_control_ARADDR[0]) ? (1'b0) : (((s_axi_control_ARADDR[3]) ? (((s_axi_control_ARADDR[5]) ? (1'b0) : (((s_axi_control_ARADDR[4]) ? (s_axi_control_ARADDR[2]) : (1'b1))))) : (((s_axi_control_ARADDR[5]) ? (((s_axi_control_ARADDR[4]) ? (1'b0) : (~(s_axi_control_ARADDR[2])))) : (1'b0))))))));

  // Reconstructed LUT2: esc_rdata_8__i_1_5e9d41c
  assign esc_rdata_8__i_1_n_0_d9891d7 = ((esc_rdata_8__i_2_n_0_2a111a0) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_8__i_2_fe5a236
  assign esc_rdata_8__i_2_n_0_2a111a0 = ((frame_offset[8]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[40]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[38]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[38]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[6]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[40]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[38]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[38]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[6]) : (1'b0))))));

  // Reconstructed LUT2: esc_rdata_9__i_1_032fda6
  assign esc_rdata_9__i_1_n_0_4a43c58 = ((esc_rdata_9__i_2_n_0_fcd395b) ? (esc_rdata_31__i_5_n_0_7df9488) : (1'b0));

  // Reconstructed LUT6: esc_rdata_9__i_2_d930019
  assign esc_rdata_9__i_2_n_0_fcd395b = ((frame_offset[9]) ? (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[41]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[39]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[39]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[7]) : (1'b1))))) : (((esc_rdata_7__i_3_n_0_9018222) ? (((frame_offset[41]) ? (((esc_rdata_7__i_4_n_0_2ace495) ? (result[39]) : (1'b1))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[39]) : (1'b0))))) : (((esc_rdata_7__i_4_n_0_2ace495) ? (result[7]) : (1'b0))))));

  // Reconstructed FDRE: esc_rdata_reg_0_d8cfedc
  reg recovered_371_q = 1'b0;
  assign s_axi_control_RDATA[0] = recovered_371_q;
  wire recovered_371_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_371_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_371_q == 1'b0))) recovered_371_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_371_q == (esc_rdata_reg_0__i_1_n_0_4d97e0e)))) recovered_371_q <= (esc_rdata_reg_0__i_1_n_0_4d97e0e);
  end

  // Reconstructed MUXF7: esc_rdata_reg_0__i_1_1d56d60
  assign esc_rdata_reg_0__i_1_n_0_4d97e0e = (esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_0__i_3_n_0_cc4cf56) : (esc_rdata_0__i_2_n_0_a457df0);

  // Reconstructed FDRE: esc_rdata_reg_10_3e5d271
  reg recovered_373_q = 1'b0;
  assign s_axi_control_RDATA[10] = recovered_373_q;
  wire recovered_373_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_373_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_373_q == 1'b0))) recovered_373_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_373_q == (esc_rdata_10__i_1_n_0_7293013)))) recovered_373_q <= (esc_rdata_10__i_1_n_0_7293013);
  end

  // Reconstructed FDRE: esc_rdata_reg_11_14242f0
  reg recovered_374_q = 1'b0;
  assign s_axi_control_RDATA[11] = recovered_374_q;
  wire recovered_374_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_374_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_374_q == 1'b0))) recovered_374_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_374_q == (esc_rdata_11__i_1_n_0_0a44289)))) recovered_374_q <= (esc_rdata_11__i_1_n_0_0a44289);
  end

  // Reconstructed FDRE: esc_rdata_reg_12_539c5d4
  reg recovered_375_q = 1'b0;
  assign s_axi_control_RDATA[12] = recovered_375_q;
  wire recovered_375_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_375_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_375_q == 1'b0))) recovered_375_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_375_q == (esc_rdata_12__i_1_n_0_a987590)))) recovered_375_q <= (esc_rdata_12__i_1_n_0_a987590);
  end

  // Reconstructed FDRE: esc_rdata_reg_13_a8f9866
  reg recovered_376_q = 1'b0;
  assign s_axi_control_RDATA[13] = recovered_376_q;
  wire recovered_376_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_376_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_376_q == 1'b0))) recovered_376_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_376_q == (esc_rdata_13__i_1_n_0_f78d886)))) recovered_376_q <= (esc_rdata_13__i_1_n_0_f78d886);
  end

  // Reconstructed FDRE: esc_rdata_reg_14_c19cbfd
  reg recovered_377_q = 1'b0;
  assign s_axi_control_RDATA[14] = recovered_377_q;
  wire recovered_377_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_377_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_377_q == 1'b0))) recovered_377_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_377_q == (esc_rdata_14__i_1_n_0_b131f65)))) recovered_377_q <= (esc_rdata_14__i_1_n_0_b131f65);
  end

  // Reconstructed FDRE: esc_rdata_reg_15_90c8f4d
  reg recovered_378_q = 1'b0;
  assign s_axi_control_RDATA[15] = recovered_378_q;
  wire recovered_378_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_378_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_378_q == 1'b0))) recovered_378_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_378_q == (esc_rdata_15__i_1_n_0_883ba46)))) recovered_378_q <= (esc_rdata_15__i_1_n_0_883ba46);
  end

  // Reconstructed FDRE: esc_rdata_reg_16_cefada2
  reg recovered_379_q = 1'b0;
  assign s_axi_control_RDATA[16] = recovered_379_q;
  wire recovered_379_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_379_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_379_q == 1'b0))) recovered_379_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_379_q == (esc_rdata_16__i_1_n_0_fd4dc4d)))) recovered_379_q <= (esc_rdata_16__i_1_n_0_fd4dc4d);
  end

  // Reconstructed FDRE: esc_rdata_reg_17_ccffc70
  reg recovered_380_q = 1'b0;
  assign s_axi_control_RDATA[17] = recovered_380_q;
  wire recovered_380_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_380_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_380_q == 1'b0))) recovered_380_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_380_q == (esc_rdata_17__i_1_n_0_3240d5b)))) recovered_380_q <= (esc_rdata_17__i_1_n_0_3240d5b);
  end

  // Reconstructed FDRE: esc_rdata_reg_18_1487fe8
  reg recovered_381_q = 1'b0;
  assign s_axi_control_RDATA[18] = recovered_381_q;
  wire recovered_381_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_381_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_381_q == 1'b0))) recovered_381_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_381_q == (esc_rdata_18__i_1_n_0_4dfbff6)))) recovered_381_q <= (esc_rdata_18__i_1_n_0_4dfbff6);
  end

  // Reconstructed FDRE: esc_rdata_reg_19_bd3705c
  reg recovered_382_q = 1'b0;
  assign s_axi_control_RDATA[19] = recovered_382_q;
  wire recovered_382_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_382_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_382_q == 1'b0))) recovered_382_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_382_q == (esc_rdata_19__i_1_n_0_eec9235)))) recovered_382_q <= (esc_rdata_19__i_1_n_0_eec9235);
  end

  // Reconstructed FDRE: esc_rdata_reg_1_bf504ab
  reg recovered_383_q = 1'b0;
  assign s_axi_control_RDATA[1] = recovered_383_q;
  wire recovered_383_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_383_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_383_q == 1'b0))) recovered_383_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_383_q == (esc_rdata_reg_1__i_1_n_0_77175c7)))) recovered_383_q <= (esc_rdata_reg_1__i_1_n_0_77175c7);
  end

  // Reconstructed MUXF7: esc_rdata_reg_1__i_1_e620d7f
  assign esc_rdata_reg_1__i_1_n_0_77175c7 = (esc_rdata_31__i_5_n_0_7df9488) ? (esc_rdata_1__i_3_n_0_77c227d) : (esc_rdata_1__i_2_n_0_4d64846);

  // Reconstructed FDRE: esc_rdata_reg_20_02c95b9
  reg recovered_385_q = 1'b0;
  assign s_axi_control_RDATA[20] = recovered_385_q;
  wire recovered_385_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_385_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_385_q == 1'b0))) recovered_385_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_385_q == (esc_rdata_20__i_1_n_0_f79cc60)))) recovered_385_q <= (esc_rdata_20__i_1_n_0_f79cc60);
  end

  // Reconstructed FDRE: esc_rdata_reg_21_c38f2c0
  reg recovered_386_q = 1'b0;
  assign s_axi_control_RDATA[21] = recovered_386_q;
  wire recovered_386_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_386_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_386_q == 1'b0))) recovered_386_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_386_q == (esc_rdata_21__i_1_n_0_2ddd0f7)))) recovered_386_q <= (esc_rdata_21__i_1_n_0_2ddd0f7);
  end

  // Reconstructed FDRE: esc_rdata_reg_22_dcbe476
  reg recovered_387_q = 1'b0;
  assign s_axi_control_RDATA[22] = recovered_387_q;
  wire recovered_387_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_387_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_387_q == 1'b0))) recovered_387_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_387_q == (esc_rdata_22__i_1_n_0_3999317)))) recovered_387_q <= (esc_rdata_22__i_1_n_0_3999317);
  end

  // Reconstructed FDRE: esc_rdata_reg_23_134ce3c
  reg recovered_388_q = 1'b0;
  assign s_axi_control_RDATA[23] = recovered_388_q;
  wire recovered_388_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_388_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_388_q == 1'b0))) recovered_388_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_388_q == (esc_rdata_23__i_1_n_0_d581e50)))) recovered_388_q <= (esc_rdata_23__i_1_n_0_d581e50);
  end

  // Reconstructed FDRE: esc_rdata_reg_24_d7648b7
  reg recovered_389_q = 1'b0;
  assign s_axi_control_RDATA[24] = recovered_389_q;
  wire recovered_389_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_389_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_389_q == 1'b0))) recovered_389_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_389_q == (esc_rdata_24__i_1_n_0_b89864b)))) recovered_389_q <= (esc_rdata_24__i_1_n_0_b89864b);
  end

  // Reconstructed FDRE: esc_rdata_reg_25_586935d
  reg recovered_390_q = 1'b0;
  assign s_axi_control_RDATA[25] = recovered_390_q;
  wire recovered_390_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_390_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_390_q == 1'b0))) recovered_390_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_390_q == (esc_rdata_25__i_1_n_0_8a2b956)))) recovered_390_q <= (esc_rdata_25__i_1_n_0_8a2b956);
  end

  // Reconstructed FDRE: esc_rdata_reg_26_ebfc2ab
  reg recovered_391_q = 1'b0;
  assign s_axi_control_RDATA[26] = recovered_391_q;
  wire recovered_391_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_391_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_391_q == 1'b0))) recovered_391_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_391_q == (esc_rdata_26__i_1_n_0_23f5691)))) recovered_391_q <= (esc_rdata_26__i_1_n_0_23f5691);
  end

  // Reconstructed FDRE: esc_rdata_reg_27_c1ee06d
  reg recovered_392_q = 1'b0;
  assign s_axi_control_RDATA[27] = recovered_392_q;
  wire recovered_392_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_392_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_392_q == 1'b0))) recovered_392_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_392_q == (esc_rdata_27__i_1_n_0_502b465)))) recovered_392_q <= (esc_rdata_27__i_1_n_0_502b465);
  end

  // Reconstructed FDRE: esc_rdata_reg_28_9f008c2
  reg recovered_393_q = 1'b0;
  assign s_axi_control_RDATA[28] = recovered_393_q;
  wire recovered_393_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_393_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_393_q == 1'b0))) recovered_393_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_393_q == (esc_rdata_28__i_1_n_0_6743271)))) recovered_393_q <= (esc_rdata_28__i_1_n_0_6743271);
  end

  // Reconstructed FDRE: esc_rdata_reg_29_4d6d4cc
  reg recovered_394_q = 1'b0;
  assign s_axi_control_RDATA[29] = recovered_394_q;
  wire recovered_394_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_394_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_394_q == 1'b0))) recovered_394_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_394_q == (esc_rdata_29__i_1_n_0_1c1ef74)))) recovered_394_q <= (esc_rdata_29__i_1_n_0_1c1ef74);
  end

  // Reconstructed FDRE: esc_rdata_reg_2_cac3b37
  reg recovered_395_q = 1'b0;
  assign s_axi_control_RDATA[2] = recovered_395_q;
  wire recovered_395_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_395_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_395_q == 1'b0))) recovered_395_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_395_q == (esc_rdata_2__i_1_n_0_c9bdce3)))) recovered_395_q <= (esc_rdata_2__i_1_n_0_c9bdce3);
  end

  // Reconstructed FDRE: esc_rdata_reg_30_1b9e8a4
  reg recovered_396_q = 1'b0;
  assign s_axi_control_RDATA[30] = recovered_396_q;
  wire recovered_396_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_396_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_396_q == 1'b0))) recovered_396_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_396_q == (esc_rdata_30__i_1_n_0_324ea32)))) recovered_396_q <= (esc_rdata_30__i_1_n_0_324ea32);
  end

  // Reconstructed FDRE: esc_rdata_reg_31_743dd29
  reg recovered_397_q = 1'b0;
  assign s_axi_control_RDATA[31] = recovered_397_q;
  wire recovered_397_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_397_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_397_q == 1'b0))) recovered_397_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_397_q == (esc_rdata_31__i_3_n_0_5a50bb4)))) recovered_397_q <= (esc_rdata_31__i_3_n_0_5a50bb4);
  end

  // Reconstructed FDRE: esc_rdata_reg_3_be2b605
  reg recovered_398_q = 1'b0;
  assign s_axi_control_RDATA[3] = recovered_398_q;
  wire recovered_398_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_398_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_398_q == 1'b0))) recovered_398_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_398_q == (esc_rdata_3__i_1_n_0_a67420f)))) recovered_398_q <= (esc_rdata_3__i_1_n_0_a67420f);
  end

  // Reconstructed FDRE: esc_rdata_reg_4_ca46696
  reg recovered_399_q = 1'b0;
  assign s_axi_control_RDATA[4] = recovered_399_q;
  wire recovered_399_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_399_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_399_q == 1'b0))) recovered_399_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_399_q == (esc_rdata_4__i_1_n_0_1a98800)))) recovered_399_q <= (esc_rdata_4__i_1_n_0_1a98800);
  end

  // Reconstructed FDRE: esc_rdata_reg_5_66356e5
  reg recovered_400_q = 1'b0;
  assign s_axi_control_RDATA[5] = recovered_400_q;
  wire recovered_400_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_400_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_400_q == 1'b0))) recovered_400_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_400_q == (esc_rdata_5__i_1_n_0_e4d287d)))) recovered_400_q <= (esc_rdata_5__i_1_n_0_e4d287d);
  end

  // Reconstructed FDRE: esc_rdata_reg_6_2ba4811
  reg recovered_401_q = 1'b0;
  assign s_axi_control_RDATA[6] = recovered_401_q;
  wire recovered_401_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_401_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_401_q == 1'b0))) recovered_401_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_401_q == (esc_rdata_6__i_1_n_0_23d2e97)))) recovered_401_q <= (esc_rdata_6__i_1_n_0_23d2e97);
  end

  // Reconstructed FDRE: esc_rdata_reg_7_d879ea1
  reg recovered_402_q = 1'b0;
  assign s_axi_control_RDATA[7] = recovered_402_q;
  wire recovered_402_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_402_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_402_q == 1'b0))) recovered_402_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_402_q == (esc_rdata_7__i_1_n_0_b768213)))) recovered_402_q <= (esc_rdata_7__i_1_n_0_b768213);
  end

  // Reconstructed FDRE: esc_rdata_reg_8_dac85ad
  reg recovered_403_q = 1'b0;
  assign s_axi_control_RDATA[8] = recovered_403_q;
  wire recovered_403_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_403_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_403_q == 1'b0))) recovered_403_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_403_q == (esc_rdata_8__i_1_n_0_d9891d7)))) recovered_403_q <= (esc_rdata_8__i_1_n_0_d9891d7);
  end

  // Reconstructed FDRE: esc_rdata_reg_9_9da028e
  reg recovered_404_q = 1'b0;
  assign s_axi_control_RDATA[9] = recovered_404_q;
  wire recovered_404_reset = ((esc_rdata_31__i_1_n_0_4ab42c1)) && ((esc_rdata_31__i_1_n_0_4ab42c1) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_404_reset || (((esc_rdata_31__i_1_n_0_4ab42c1) === 1'bx) && (recovered_404_q == 1'b0))) recovered_404_q <= 1'b0;
    else if ((ar_hs) || ((ar_hs) === 1'bz) || (((ar_hs) === 1'bx) && (recovered_404_q == (esc_rdata_9__i_1_n_0_4a43c58)))) recovered_404_q <= (esc_rdata_9__i_1_n_0_4a43c58);
  end

  // Reconstructed LUT2: esc_waddr_5__i_1_fe75332
  assign waddr = ((esc_FSM_onehot_wstate_reg_1__0_bb8fbc8) ? (s_axi_control_AWVALID) : (1'b0));

  // Reconstructed FDRE: esc_waddr_reg_0_a5f0615
  reg recovered_406_q = 1'b0;
  assign esc_waddr_reg_n_0__0_ad4c065 = recovered_406_q;
  wire recovered_406_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_406_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_406_q == 1'b0))) recovered_406_q <= 1'b0;
    else if ((waddr) || ((waddr) === 1'bz) || (((waddr) === 1'bx) && (recovered_406_q == (s_axi_control_AWADDR[0])))) recovered_406_q <= (s_axi_control_AWADDR[0]);
  end

  // Reconstructed FDRE: esc_waddr_reg_1_358bf4d
  reg recovered_407_q = 1'b0;
  assign esc_waddr_reg_n_0__1_792a10e = recovered_407_q;
  wire recovered_407_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_407_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_407_q == 1'b0))) recovered_407_q <= 1'b0;
    else if ((waddr) || ((waddr) === 1'bz) || (((waddr) === 1'bx) && (recovered_407_q == (s_axi_control_AWADDR[1])))) recovered_407_q <= (s_axi_control_AWADDR[1]);
  end

  // Reconstructed FDRE: esc_waddr_reg_2_2c95dfb
  reg recovered_408_q = 1'b0;
  assign esc_waddr_reg_n_0__2_093afb0 = recovered_408_q;
  wire recovered_408_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_408_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_408_q == 1'b0))) recovered_408_q <= 1'b0;
    else if ((waddr) || ((waddr) === 1'bz) || (((waddr) === 1'bx) && (recovered_408_q == (s_axi_control_AWADDR[2])))) recovered_408_q <= (s_axi_control_AWADDR[2]);
  end

  // Reconstructed FDRE: esc_waddr_reg_3_aadf430
  reg recovered_409_q = 1'b0;
  assign esc_waddr_reg_n_0__3_ccbbd3d = recovered_409_q;
  wire recovered_409_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_409_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_409_q == 1'b0))) recovered_409_q <= 1'b0;
    else if ((waddr) || ((waddr) === 1'bz) || (((waddr) === 1'bx) && (recovered_409_q == (s_axi_control_AWADDR[3])))) recovered_409_q <= (s_axi_control_AWADDR[3]);
  end

  // Reconstructed FDRE: esc_waddr_reg_4_22508b6
  reg recovered_410_q = 1'b0;
  assign esc_waddr_reg_n_0__4_2e446af = recovered_410_q;
  wire recovered_410_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_410_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_410_q == 1'b0))) recovered_410_q <= 1'b0;
    else if ((waddr) || ((waddr) === 1'bz) || (((waddr) === 1'bx) && (recovered_410_q == (s_axi_control_AWADDR[4])))) recovered_410_q <= (s_axi_control_AWADDR[4]);
  end

  // Reconstructed FDRE: esc_waddr_reg_5_a9127a4
  reg recovered_411_q = 1'b0;
  assign esc_waddr_reg_n_0__5_99ccd75 = recovered_411_q;
  wire recovered_411_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_411_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_411_q == 1'b0))) recovered_411_q <= 1'b0;
    else if ((waddr) || ((waddr) === 1'bz) || (((waddr) === 1'bx) && (recovered_411_q == (s_axi_control_AWADDR[5])))) recovered_411_q <= (s_axi_control_AWADDR[5]);
  end

  // Reconstructed LUT5: esc_x_reg_2308_5__i_1_7be57ec
  assign esc_ap_CS_fsm_reg_1__0_160aef6 = ((ap_start) ? (((Q[0]) ? (((ap_enable_reg_pp0_iter0) ? (((ap_enable_reg_pp0_iter0_reg) ? (1'b1) : (~(Q[1])))) : (1'b1))) : (1'b0))) : (1'b0));

  // Reconstructed LUT5: esc_y_reg_2297_4__i_1_45b6b7e
  assign SR = ((ap_enable_reg_pp0_iter1) ? (((Q[1]) ? (((esc_y_reg_2297_reg_0_8039ace) ? (((ap_start) ? (Q[0]) : (1'b0))) : (1'b0))) : (((ap_start) ? (Q[0]) : (1'b0))))) : (((ap_start) ? (Q[0]) : (1'b0))));

endmodule

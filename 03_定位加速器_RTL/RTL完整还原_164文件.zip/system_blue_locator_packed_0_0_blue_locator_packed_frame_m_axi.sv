// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_frame_m_axi
   (D,
    SR,
    blue_counts_ce0,
    edge_counts_ce0,
    E,
    esc_data_p1_reg_7_98a71bc ,
    WEA,
    full_n_reg,
    esc_data_p1_reg_0_91510d9 ,
    ap_enable_reg_pp1_iter0_reg,
    m_axi_frame_ARADDR,
    esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 ,
    esc_could_multi_bursts_ARVALID_Dummy_reg_7381e5f ,
    esc_ap_CS_fsm_reg_2_e63bcb7 ,
    Q,
    ap_rst_n,
    ram0_reg,
    esc_state_reg_1_a113b56 ,
    ap_enable_reg_pp1_iter0,
    ram0_reg_0,
    esc_ap_CS_fsm_reg_10_0d2c375 ,
    ram0_reg_1,
    esc_ap_CS_fsm_reg_11_8288f29 ,
    y_reg_22970,
    icmp_ln57_reg_6825,
    and_ln57_reg_6829,
    m_axi_frame_RVALID,
    previous_blue_1_reg_6804,
    ap_clk,
    mem_reg,
    m_axi_frame_RRESP,
    esc_data_p2_reg_63_32ca137 ,
    m_axi_frame_ARREADY);
  output [3:0]D;
  output [0:0]SR;
  output blue_counts_ce0;
  output edge_counts_ce0;
  output [0:0]E;
  output [6:0]esc_data_p1_reg_7_98a71bc ;
  output [0:0]WEA;
  output full_n_reg;
  output esc_data_p1_reg_0_91510d9 ;
  output [0:0]ap_enable_reg_pp1_iter0_reg;
  output [61:0]m_axi_frame_ARADDR;
  output [3:0]esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 ;
  output esc_could_multi_bursts_ARVALID_Dummy_reg_7381e5f ;
  input esc_ap_CS_fsm_reg_2_e63bcb7 ;
  input [4:0]Q;
  input ap_rst_n;
  input ram0_reg;
  input esc_state_reg_1_a113b56 ;
  input ap_enable_reg_pp1_iter0;
  input ram0_reg_0;
  input esc_ap_CS_fsm_reg_10_0d2c375 ;
  input ram0_reg_1;
  input esc_ap_CS_fsm_reg_11_8288f29 ;
  input y_reg_22970;
  input icmp_ln57_reg_6825;
  input and_ln57_reg_6829;
  input m_axi_frame_RVALID;
  input previous_blue_1_reg_6804;
  input ap_clk;
  input [32:0]mem_reg;
  input [1:0]m_axi_frame_RRESP;
  input [63:0]esc_data_p2_reg_63_32ca137 ;
  input m_axi_frame_ARREADY;

  wire [3:0]D;
  wire [0:0]E;
  wire [4:0]Q;
  wire [0:0]SR;
  wire [0:0]WEA;
  wire and_ln57_reg_6829;
  wire esc_ap_CS_fsm_reg_10_0d2c375 ;
  wire esc_ap_CS_fsm_reg_11_8288f29 ;
  wire esc_ap_CS_fsm_reg_2_e63bcb7 ;
  wire ap_clk;
  wire ap_enable_reg_pp1_iter0;
  wire [0:0]ap_enable_reg_pp1_iter0_reg;
  wire ap_rst_n;
  wire blue_counts_ce0;
  wire esc_could_multi_bursts_ARVALID_Dummy_reg_7381e5f ;
  wire [3:0]esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 ;
  wire esc_data_p1_reg_0_91510d9 ;
  wire [6:0]esc_data_p1_reg_7_98a71bc ;
  wire [63:0]esc_data_p2_reg_63_32ca137 ;
  wire edge_counts_ce0;
  wire full_n_reg;
  wire icmp_ln57_reg_6825;
  wire [61:0]m_axi_frame_ARADDR;
  wire m_axi_frame_ARREADY;
  wire [1:0]m_axi_frame_RRESP;
  wire m_axi_frame_RVALID;
  wire [32:0]mem_reg;
  wire previous_blue_1_reg_6804;
  wire ram0_reg;
  wire ram0_reg_0;
  wire ram0_reg_1;
  wire esc_state_reg_1_a113b56 ;
  wire y_reg_22970;

  system_blue_locator_packed_0_0_blue_locator_packed_frame_m_axi_read bus_read
       (.D(D),
        .E(E),
        .Q(Q),
        .SR(SR),
        .WEA(WEA),
        .and_ln57_reg_6829(and_ln57_reg_6829),
        .esc_ap_CS_fsm_reg_10_0d2c375 (esc_ap_CS_fsm_reg_10_0d2c375 ),
        .esc_ap_CS_fsm_reg_11_8288f29 (esc_ap_CS_fsm_reg_11_8288f29 ),
        .esc_ap_CS_fsm_reg_2_e63bcb7 (esc_ap_CS_fsm_reg_2_e63bcb7 ),
        .ap_clk(ap_clk),
        .ap_enable_reg_pp1_iter0(ap_enable_reg_pp1_iter0),
        .ap_enable_reg_pp1_iter0_reg(ap_enable_reg_pp1_iter0_reg),
        .ap_rst_n(ap_rst_n),
        .blue_counts_ce0(blue_counts_ce0),
        .esc_could_multi_bursts_ARVALID_Dummy_reg_0_61f317f (esc_could_multi_bursts_ARVALID_Dummy_reg_7381e5f ),
        .esc_data_p1_reg_0_91510d9 (esc_data_p1_reg_0_91510d9 ),
        .esc_data_p1_reg_7_98a71bc (esc_data_p1_reg_7_98a71bc ),
        .esc_data_p2_reg_63_32ca137 (esc_data_p2_reg_63_32ca137 ),
        .edge_counts_ce0(edge_counts_ce0),
        .full_n_reg(full_n_reg),
        .icmp_ln57_reg_6825(icmp_ln57_reg_6825),
        .m_axi_frame_ARADDR(m_axi_frame_ARADDR),
        .m_axi_frame_ARREADY(m_axi_frame_ARREADY),
        .m_axi_frame_RRESP(m_axi_frame_RRESP),
        .m_axi_frame_RVALID(m_axi_frame_RVALID),
        .mem_reg(mem_reg),
        .out_BUS_ARLEN(esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 ),
        .previous_blue_1_reg_6804(previous_blue_1_reg_6804),
        .ram0_reg(ram0_reg),
        .ram0_reg_0(ram0_reg_0),
        .ram0_reg_1(ram0_reg_1),
        .esc_state_reg_1_a113b56 (esc_state_reg_1_a113b56 ),
        .y_reg_22970(y_reg_22970));
endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_frame_m_axi_buffer__parameterized0
   (full_n_reg_0,
    beat_valid,
    SR,
    S,
    Q,
    esc_mOutPtr_reg_6__0_995f4ea ,
    DI,
    esc_dout_buf_reg_16__0_a1d510e ,
    esc_dout_buf_reg_34__0_9cc5769 ,
    esc_dout_buf_reg_17__0_408b57c ,
    esc_dout_buf_reg_18__0_9bc887a ,
    esc_dout_buf_reg_19__0_7771c89 ,
    esc_dout_buf_reg_20__0_60488c7 ,
    esc_dout_buf_reg_21__0_5d763a5 ,
    esc_dout_buf_reg_22__0_4322709 ,
    esc_dout_buf_reg_23__0_38156b5 ,
    esc_bus_wide_gen_data_buf01_in_ffc6cb2 ,
    ap_clk,
    mem_reg_0,
    m_axi_frame_RRESP,
    m_axi_frame_RVALID,
    ap_rst_n,
    esc_bus_wide_gen_last_split_89b9056 ,
    esc_bus_wide_gen_data_buf_reg_8_02e2baa ,
    esc_bus_wide_gen_data_buf1__0_dc376b6 ,
    D);
  output full_n_reg_0;
  output beat_valid;
  output [0:0]SR;
  output [3:0]S;
  output [5:0]Q;
  output [2:0]esc_mOutPtr_reg_6__0_995f4ea ;
  output [0:0]DI;
  output esc_dout_buf_reg_16__0_a1d510e ;
  output [32:0]esc_dout_buf_reg_34__0_9cc5769 ;
  output esc_dout_buf_reg_17__0_408b57c ;
  output esc_dout_buf_reg_18__0_9bc887a ;
  output esc_dout_buf_reg_19__0_7771c89 ;
  output esc_dout_buf_reg_20__0_60488c7 ;
  output esc_dout_buf_reg_21__0_5d763a5 ;
  output esc_dout_buf_reg_22__0_4322709 ;
  output esc_dout_buf_reg_23__0_38156b5 ;
  output [7:0]esc_bus_wide_gen_data_buf01_in_ffc6cb2 ;
  input ap_clk;
  input [32:0]mem_reg_0;
  input [1:0]m_axi_frame_RRESP;
  input m_axi_frame_RVALID;
  input ap_rst_n;
  input esc_bus_wide_gen_last_split_89b9056 ;
  input [1:0]esc_bus_wide_gen_data_buf_reg_8_02e2baa ;
  input esc_bus_wide_gen_data_buf1__0_dc376b6 ;
  input [6:0]D;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [6:0]D;
  wire [0:0]DI;
  wire [5:0]Q;
  wire [3:0]S;
  wire [0:0]SR;
  wire ap_clk;
  wire ap_rst_n;
  wire beat_valid;
  wire [7:0]esc_bus_wide_gen_data_buf01_in_ffc6cb2 ;
  wire esc_bus_wide_gen_data_buf1__0_dc376b6 ;
  wire [1:0]esc_bus_wide_gen_data_buf_reg_8_02e2baa ;
  wire esc_bus_wide_gen_last_split_89b9056 ;
  wire esc_dout_buf_0__i_1_n_0_a416739 ;
  wire esc_dout_buf_10__i_1_n_0_86c44e6 ;
  wire esc_dout_buf_11__i_1_n_0_9481f99 ;
  wire esc_dout_buf_12__i_1_n_0_86ab95d ;
  wire esc_dout_buf_13__i_1_n_0_9f78cf9 ;
  wire esc_dout_buf_14__i_1_n_0_7dc461f ;
  wire esc_dout_buf_15__i_1_n_0_2bea0e4 ;
  wire esc_dout_buf_16__i_1_n_0_0c36ee8 ;
  wire esc_dout_buf_17__i_1_n_0_7e441d2 ;
  wire esc_dout_buf_18__i_1_n_0_6505df9 ;
  wire esc_dout_buf_19__i_1_n_0_edc3c7b ;
  wire esc_dout_buf_1__i_1_n_0_bcd7410 ;
  wire esc_dout_buf_20__i_1_n_0_ab4b624 ;
  wire esc_dout_buf_21__i_1_n_0_e1219ab ;
  wire esc_dout_buf_22__i_1_n_0_787b7ea ;
  wire esc_dout_buf_23__i_1_n_0_b99fea5 ;
  wire esc_dout_buf_24__i_1_n_0_f596885 ;
  wire esc_dout_buf_25__i_1_n_0_5604152 ;
  wire esc_dout_buf_26__i_1_n_0_eeac2a9 ;
  wire esc_dout_buf_27__i_1_n_0_600d618 ;
  wire esc_dout_buf_28__i_1_n_0_567ea32 ;
  wire esc_dout_buf_29__i_1_n_0_f8b40b3 ;
  wire esc_dout_buf_2__i_1_n_0_0388fd1 ;
  wire esc_dout_buf_30__i_1_n_0_b0eac95 ;
  wire esc_dout_buf_31__i_1_n_0_995d1e3 ;
  wire esc_dout_buf_34__i_2_n_0_bcc0fd3 ;
  wire esc_dout_buf_3__i_1_n_0_a1e89d1 ;
  wire esc_dout_buf_4__i_1_n_0_9790d5b ;
  wire esc_dout_buf_5__i_1_n_0_bcb4bd3 ;
  wire esc_dout_buf_6__i_1_n_0_122f0de ;
  wire esc_dout_buf_7__i_1_n_0_5c8c97d ;
  wire esc_dout_buf_8__i_1_n_0_fa8be1c ;
  wire esc_dout_buf_9__i_1_n_0_2baf451 ;
  wire esc_dout_buf_reg_16__0_a1d510e ;
  wire esc_dout_buf_reg_17__0_408b57c ;
  wire esc_dout_buf_reg_18__0_9bc887a ;
  wire esc_dout_buf_reg_19__0_7771c89 ;
  wire esc_dout_buf_reg_20__0_60488c7 ;
  wire esc_dout_buf_reg_21__0_5d763a5 ;
  wire esc_dout_buf_reg_22__0_4322709 ;
  wire esc_dout_buf_reg_23__0_38156b5 ;
  wire [32:0]esc_dout_buf_reg_34__0_9cc5769 ;
  wire dout_valid_i_1_n_0;
  wire empty_n_i_1_n_0;
  wire empty_n_i_2__0_n_0;
  wire empty_n_i_3__0_n_0;
  wire empty_n_reg_n_0;
  wire full_n_i_1_n_0;
  wire full_n_i_3_n_0;
  wire full_n_reg_0;
  wire esc_mOutPtr_0__i_1_n_0_bf14477 ;
  wire esc_mOutPtr_7__i_1_n_0_d38cd53 ;
  wire [7:6]mOutPtr_reg;
  wire [2:0]esc_mOutPtr_reg_6__0_995f4ea ;
  wire [1:0]m_axi_frame_RRESP;
  wire m_axi_frame_RVALID;
  wire [32:0]mem_reg_0;
  wire mem_reg_i_10_n_0;
  wire mem_reg_i_11_n_0;
  wire mem_reg_i_12_n_0;
  wire mem_reg_i_13_n_0;
  wire mem_reg_i_14_n_0;
  wire mem_reg_i_9_n_0;
  wire p_1_in;
  wire pop;
  wire push;
  wire [34:0]q_buf;
  wire [34:0]q_tmp;
  wire [7:0]raddr;
  wire [7:0]rnext;
  wire show_ahead;
  wire show_ahead0;
  wire show_ahead_i_2_n_0;
  wire [7:0]waddr;
  wire esc_waddr_0__i_1_n_0_3e6a2e1 ;
  wire esc_waddr_1__i_1_n_0_52694fb ;
  wire esc_waddr_2__i_1_n_0_0e06a9f ;
  wire esc_waddr_3__i_1_n_0_0174975 ;
  wire esc_waddr_4__i_1_n_0_cd694eb ;
  wire esc_waddr_5__i_1__0_n_0_cf6130a ;
  wire esc_waddr_6__i_1_n_0_5490cbe ;
  wire esc_waddr_6__i_2_n_0_228b923 ;
  wire esc_waddr_7__i_2_n_0_7208898 ;
  wire esc_waddr_7__i_3_n_0_02cd60d ;
  wire esc_waddr_7__i_4_n_0_54af9cb ;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_0__i_2_1bdf04b
  assign esc_bus_wide_gen_data_buf01_in_ffc6cb2 [0] = ((esc_dout_buf_reg_34__0_9cc5769 [8]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [24]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [16]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [16]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [0]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [24]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [16]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [16]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [0]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_10__i_2_72ebace
  assign esc_dout_buf_reg_18__0_9bc887a = ((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [18]))) : (1'b0))) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_dout_buf_reg_34__0_9cc5769 [10]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [26]) : (1'b1))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [26]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_11__i_2_a2c6319
  assign esc_dout_buf_reg_19__0_7771c89 = ((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [19]))) : (1'b0))) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_dout_buf_reg_34__0_9cc5769 [11]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [27]) : (1'b1))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [27]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_12__i_2_70e53fa
  assign esc_dout_buf_reg_20__0_60488c7 = ((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [20]))) : (1'b0))) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_dout_buf_reg_34__0_9cc5769 [12]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [28]) : (1'b1))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [28]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_13__i_2_f846986
  assign esc_dout_buf_reg_21__0_5d763a5 = ((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [21]))) : (1'b0))) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_dout_buf_reg_34__0_9cc5769 [13]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [29]) : (1'b1))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [29]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_14__i_2_73ea0da
  assign esc_dout_buf_reg_22__0_4322709 = ((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [22]))) : (1'b0))) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_dout_buf_reg_34__0_9cc5769 [14]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [30]) : (1'b1))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [30]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_15__i_4_ca9eb3d
  assign esc_dout_buf_reg_23__0_38156b5 = ((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [23]))) : (1'b0))) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_dout_buf_reg_34__0_9cc5769 [15]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [31]) : (1'b1))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [31]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_1__i_2_e0bf9fb
  assign esc_bus_wide_gen_data_buf01_in_ffc6cb2 [1] = ((esc_dout_buf_reg_34__0_9cc5769 [9]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [25]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [17]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [17]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [1]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [25]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [17]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [17]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [1]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_2__i_2_9e40f3c
  assign esc_bus_wide_gen_data_buf01_in_ffc6cb2 [2] = ((esc_dout_buf_reg_34__0_9cc5769 [10]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [26]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [18]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [18]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [2]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [26]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [18]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [18]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [2]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_3__i_2_1e5f247
  assign esc_bus_wide_gen_data_buf01_in_ffc6cb2 [3] = ((esc_dout_buf_reg_34__0_9cc5769 [11]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [27]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [19]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [19]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [3]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [27]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [19]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [19]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [3]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_4__i_2_0d45bba
  assign esc_bus_wide_gen_data_buf01_in_ffc6cb2 [4] = ((esc_dout_buf_reg_34__0_9cc5769 [12]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [28]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [20]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [20]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [4]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [28]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [20]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [20]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [4]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_5__i_2_96ba043
  assign esc_bus_wide_gen_data_buf01_in_ffc6cb2 [5] = ((esc_dout_buf_reg_34__0_9cc5769 [13]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [29]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [21]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [21]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [5]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [29]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [21]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [21]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [5]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_6__i_2_a750771
  assign esc_bus_wide_gen_data_buf01_in_ffc6cb2 [6] = ((esc_dout_buf_reg_34__0_9cc5769 [14]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [30]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [22]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [22]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [6]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [30]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [22]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [22]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [6]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_7__i_2_d59a5d6
  assign esc_bus_wide_gen_data_buf01_in_ffc6cb2 [7] = ((esc_dout_buf_reg_34__0_9cc5769 [15]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [31]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [23]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [23]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [7]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (((esc_dout_buf_reg_34__0_9cc5769 [31]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b1) : (esc_dout_buf_reg_34__0_9cc5769 [23]))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [23]))))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [7]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_8__i_2_d0fef01
  assign esc_dout_buf_reg_16__0_a1d510e = ((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [16]))) : (1'b0))) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_dout_buf_reg_34__0_9cc5769 [8]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [24]) : (1'b1))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [24]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_9__i_2_91ec7ee
  assign esc_dout_buf_reg_17__0_408b57c = ((esc_bus_wide_gen_data_buf_reg_8_02e2baa [0]) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (1'b0) : (esc_dout_buf_reg_34__0_9cc5769 [17]))) : (1'b0))) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_dout_buf_reg_34__0_9cc5769 [9]) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [25]) : (1'b1))) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa [1]) ? (esc_dout_buf_reg_34__0_9cc5769 [25]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT1: esc_could_multi_bursts_araddr_buf_63__i_1_86e174b
  assign SR = ~(ap_rst_n);

  // Reconstructed LUT3: esc_dout_buf_0__i_1_c652c5c
  assign esc_dout_buf_0__i_1_n_0_a416739 = ((show_ahead) ? (q_tmp[0]) : (q_buf[0]));

  // Reconstructed LUT3: esc_dout_buf_10__i_1_b412b36
  assign esc_dout_buf_10__i_1_n_0_86c44e6 = ((show_ahead) ? (q_tmp[10]) : (q_buf[10]));

  // Reconstructed LUT3: esc_dout_buf_11__i_1_a12fcb3
  assign esc_dout_buf_11__i_1_n_0_9481f99 = ((show_ahead) ? (q_tmp[11]) : (q_buf[11]));

  // Reconstructed LUT3: esc_dout_buf_12__i_1_384cce0
  assign esc_dout_buf_12__i_1_n_0_86ab95d = ((show_ahead) ? (q_tmp[12]) : (q_buf[12]));

  // Reconstructed LUT3: esc_dout_buf_13__i_1_0d19a71
  assign esc_dout_buf_13__i_1_n_0_9f78cf9 = ((show_ahead) ? (q_tmp[13]) : (q_buf[13]));

  // Reconstructed LUT3: esc_dout_buf_14__i_1_52852ec
  assign esc_dout_buf_14__i_1_n_0_7dc461f = ((show_ahead) ? (q_tmp[14]) : (q_buf[14]));

  // Reconstructed LUT3: esc_dout_buf_15__i_1_e0f83f2
  assign esc_dout_buf_15__i_1_n_0_2bea0e4 = ((show_ahead) ? (q_tmp[15]) : (q_buf[15]));

  // Reconstructed LUT3: esc_dout_buf_16__i_1_6b92668
  assign esc_dout_buf_16__i_1_n_0_0c36ee8 = ((show_ahead) ? (q_tmp[16]) : (q_buf[16]));

  // Reconstructed LUT3: esc_dout_buf_17__i_1_c385490
  assign esc_dout_buf_17__i_1_n_0_7e441d2 = ((show_ahead) ? (q_tmp[17]) : (q_buf[17]));

  // Reconstructed LUT3: esc_dout_buf_18__i_1_a3ce381
  assign esc_dout_buf_18__i_1_n_0_6505df9 = ((show_ahead) ? (q_tmp[18]) : (q_buf[18]));

  // Reconstructed LUT3: esc_dout_buf_19__i_1_183094b
  assign esc_dout_buf_19__i_1_n_0_edc3c7b = ((show_ahead) ? (q_tmp[19]) : (q_buf[19]));

  // Reconstructed LUT3: esc_dout_buf_1__i_1_b06e31a
  assign esc_dout_buf_1__i_1_n_0_bcd7410 = ((show_ahead) ? (q_tmp[1]) : (q_buf[1]));

  // Reconstructed LUT3: esc_dout_buf_20__i_1_11b7011
  assign esc_dout_buf_20__i_1_n_0_ab4b624 = ((show_ahead) ? (q_tmp[20]) : (q_buf[20]));

  // Reconstructed LUT3: esc_dout_buf_21__i_1_3eeb9bd
  assign esc_dout_buf_21__i_1_n_0_e1219ab = ((show_ahead) ? (q_tmp[21]) : (q_buf[21]));

  // Reconstructed LUT3: esc_dout_buf_22__i_1_3638525
  assign esc_dout_buf_22__i_1_n_0_787b7ea = ((show_ahead) ? (q_tmp[22]) : (q_buf[22]));

  // Reconstructed LUT3: esc_dout_buf_23__i_1_2d48561
  assign esc_dout_buf_23__i_1_n_0_b99fea5 = ((show_ahead) ? (q_tmp[23]) : (q_buf[23]));

  // Reconstructed LUT3: esc_dout_buf_24__i_1_0f8bc1b
  assign esc_dout_buf_24__i_1_n_0_f596885 = ((show_ahead) ? (q_tmp[24]) : (q_buf[24]));

  // Reconstructed LUT3: esc_dout_buf_25__i_1_f3b0b30
  assign esc_dout_buf_25__i_1_n_0_5604152 = ((show_ahead) ? (q_tmp[25]) : (q_buf[25]));

  // Reconstructed LUT3: esc_dout_buf_26__i_1_24bdd4b
  assign esc_dout_buf_26__i_1_n_0_eeac2a9 = ((show_ahead) ? (q_tmp[26]) : (q_buf[26]));

  // Reconstructed LUT3: esc_dout_buf_27__i_1_cd11586
  assign esc_dout_buf_27__i_1_n_0_600d618 = ((show_ahead) ? (q_tmp[27]) : (q_buf[27]));

  // Reconstructed LUT3: esc_dout_buf_28__i_1_2df00db
  assign esc_dout_buf_28__i_1_n_0_567ea32 = ((show_ahead) ? (q_tmp[28]) : (q_buf[28]));

  // Reconstructed LUT3: esc_dout_buf_29__i_1_2f55c43
  assign esc_dout_buf_29__i_1_n_0_f8b40b3 = ((show_ahead) ? (q_tmp[29]) : (q_buf[29]));

  // Reconstructed LUT3: esc_dout_buf_2__i_1_6fbe35f
  assign esc_dout_buf_2__i_1_n_0_0388fd1 = ((show_ahead) ? (q_tmp[2]) : (q_buf[2]));

  // Reconstructed LUT3: esc_dout_buf_30__i_1_1f87935
  assign esc_dout_buf_30__i_1_n_0_b0eac95 = ((show_ahead) ? (q_tmp[30]) : (q_buf[30]));

  // Reconstructed LUT3: esc_dout_buf_31__i_1_3c7f45c
  assign esc_dout_buf_31__i_1_n_0_995d1e3 = ((show_ahead) ? (q_tmp[31]) : (q_buf[31]));

  // Reconstructed LUT3: esc_dout_buf_34__i_1_8701ce1
  assign pop = ((empty_n_reg_n_0) ? (((esc_bus_wide_gen_last_split_89b9056) ? (1'b1) : (~(beat_valid)))) : (1'b0));

  // Reconstructed LUT3: esc_dout_buf_34__i_2_c26070a
  assign esc_dout_buf_34__i_2_n_0_bcc0fd3 = ((show_ahead) ? (q_tmp[34]) : (q_buf[34]));

  // Reconstructed LUT3: esc_dout_buf_3__i_1_1debc9c
  assign esc_dout_buf_3__i_1_n_0_a1e89d1 = ((show_ahead) ? (q_tmp[3]) : (q_buf[3]));

  // Reconstructed LUT3: esc_dout_buf_4__i_1_eb55711
  assign esc_dout_buf_4__i_1_n_0_9790d5b = ((show_ahead) ? (q_tmp[4]) : (q_buf[4]));

  // Reconstructed LUT3: esc_dout_buf_5__i_1_761e744
  assign esc_dout_buf_5__i_1_n_0_bcb4bd3 = ((show_ahead) ? (q_tmp[5]) : (q_buf[5]));

  // Reconstructed LUT3: esc_dout_buf_6__i_1_2a8ca20
  assign esc_dout_buf_6__i_1_n_0_122f0de = ((show_ahead) ? (q_tmp[6]) : (q_buf[6]));

  // Reconstructed LUT3: esc_dout_buf_7__i_1_4f6f556
  assign esc_dout_buf_7__i_1_n_0_5c8c97d = ((show_ahead) ? (q_tmp[7]) : (q_buf[7]));

  // Reconstructed LUT3: esc_dout_buf_8__i_1_1c8dea4
  assign esc_dout_buf_8__i_1_n_0_fa8be1c = ((show_ahead) ? (q_tmp[8]) : (q_buf[8]));

  // Reconstructed LUT3: esc_dout_buf_9__i_1_b36d46c
  assign esc_dout_buf_9__i_1_n_0_2baf451 = ((show_ahead) ? (q_tmp[9]) : (q_buf[9]));

  // Reconstructed FDRE: esc_dout_buf_reg_0_73c858f
  reg recovered_54_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [0] = recovered_54_q;
  wire recovered_54_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_54_reset || (((SR) === 1'bx) && (recovered_54_q == 1'b0))) recovered_54_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_54_q == (esc_dout_buf_0__i_1_n_0_a416739)))) recovered_54_q <= (esc_dout_buf_0__i_1_n_0_a416739);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_10_f29ae94
  reg recovered_55_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [10] = recovered_55_q;
  wire recovered_55_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_55_reset || (((SR) === 1'bx) && (recovered_55_q == 1'b0))) recovered_55_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_55_q == (esc_dout_buf_10__i_1_n_0_86c44e6)))) recovered_55_q <= (esc_dout_buf_10__i_1_n_0_86c44e6);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_11_8b7e2c1
  reg recovered_56_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [11] = recovered_56_q;
  wire recovered_56_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_56_reset || (((SR) === 1'bx) && (recovered_56_q == 1'b0))) recovered_56_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_56_q == (esc_dout_buf_11__i_1_n_0_9481f99)))) recovered_56_q <= (esc_dout_buf_11__i_1_n_0_9481f99);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_12_7ca0f57
  reg recovered_57_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [12] = recovered_57_q;
  wire recovered_57_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_57_reset || (((SR) === 1'bx) && (recovered_57_q == 1'b0))) recovered_57_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_57_q == (esc_dout_buf_12__i_1_n_0_86ab95d)))) recovered_57_q <= (esc_dout_buf_12__i_1_n_0_86ab95d);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_13_30f5709
  reg recovered_58_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [13] = recovered_58_q;
  wire recovered_58_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_58_reset || (((SR) === 1'bx) && (recovered_58_q == 1'b0))) recovered_58_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_58_q == (esc_dout_buf_13__i_1_n_0_9f78cf9)))) recovered_58_q <= (esc_dout_buf_13__i_1_n_0_9f78cf9);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_14_afe27ef
  reg recovered_59_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [14] = recovered_59_q;
  wire recovered_59_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_59_reset || (((SR) === 1'bx) && (recovered_59_q == 1'b0))) recovered_59_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_59_q == (esc_dout_buf_14__i_1_n_0_7dc461f)))) recovered_59_q <= (esc_dout_buf_14__i_1_n_0_7dc461f);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_15_61438df
  reg recovered_60_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [15] = recovered_60_q;
  wire recovered_60_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_60_reset || (((SR) === 1'bx) && (recovered_60_q == 1'b0))) recovered_60_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_60_q == (esc_dout_buf_15__i_1_n_0_2bea0e4)))) recovered_60_q <= (esc_dout_buf_15__i_1_n_0_2bea0e4);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_16_41b0172
  reg recovered_61_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [16] = recovered_61_q;
  wire recovered_61_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_61_reset || (((SR) === 1'bx) && (recovered_61_q == 1'b0))) recovered_61_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_61_q == (esc_dout_buf_16__i_1_n_0_0c36ee8)))) recovered_61_q <= (esc_dout_buf_16__i_1_n_0_0c36ee8);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_17_f5a2fc8
  reg recovered_62_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [17] = recovered_62_q;
  wire recovered_62_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_62_reset || (((SR) === 1'bx) && (recovered_62_q == 1'b0))) recovered_62_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_62_q == (esc_dout_buf_17__i_1_n_0_7e441d2)))) recovered_62_q <= (esc_dout_buf_17__i_1_n_0_7e441d2);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_18_f551304
  reg recovered_63_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [18] = recovered_63_q;
  wire recovered_63_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_63_reset || (((SR) === 1'bx) && (recovered_63_q == 1'b0))) recovered_63_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_63_q == (esc_dout_buf_18__i_1_n_0_6505df9)))) recovered_63_q <= (esc_dout_buf_18__i_1_n_0_6505df9);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_19_bef1e0f
  reg recovered_64_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [19] = recovered_64_q;
  wire recovered_64_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_64_reset || (((SR) === 1'bx) && (recovered_64_q == 1'b0))) recovered_64_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_64_q == (esc_dout_buf_19__i_1_n_0_edc3c7b)))) recovered_64_q <= (esc_dout_buf_19__i_1_n_0_edc3c7b);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_1_65a567e
  reg recovered_65_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [1] = recovered_65_q;
  wire recovered_65_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_65_reset || (((SR) === 1'bx) && (recovered_65_q == 1'b0))) recovered_65_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_65_q == (esc_dout_buf_1__i_1_n_0_bcd7410)))) recovered_65_q <= (esc_dout_buf_1__i_1_n_0_bcd7410);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_20_167900f
  reg recovered_66_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [20] = recovered_66_q;
  wire recovered_66_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_66_reset || (((SR) === 1'bx) && (recovered_66_q == 1'b0))) recovered_66_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_66_q == (esc_dout_buf_20__i_1_n_0_ab4b624)))) recovered_66_q <= (esc_dout_buf_20__i_1_n_0_ab4b624);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_21_6459474
  reg recovered_67_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [21] = recovered_67_q;
  wire recovered_67_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_67_reset || (((SR) === 1'bx) && (recovered_67_q == 1'b0))) recovered_67_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_67_q == (esc_dout_buf_21__i_1_n_0_e1219ab)))) recovered_67_q <= (esc_dout_buf_21__i_1_n_0_e1219ab);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_22_9d17b17
  reg recovered_68_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [22] = recovered_68_q;
  wire recovered_68_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_68_reset || (((SR) === 1'bx) && (recovered_68_q == 1'b0))) recovered_68_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_68_q == (esc_dout_buf_22__i_1_n_0_787b7ea)))) recovered_68_q <= (esc_dout_buf_22__i_1_n_0_787b7ea);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_23_6933fe3
  reg recovered_69_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [23] = recovered_69_q;
  wire recovered_69_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_69_reset || (((SR) === 1'bx) && (recovered_69_q == 1'b0))) recovered_69_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_69_q == (esc_dout_buf_23__i_1_n_0_b99fea5)))) recovered_69_q <= (esc_dout_buf_23__i_1_n_0_b99fea5);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_24_fd28f8a
  reg recovered_70_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [24] = recovered_70_q;
  wire recovered_70_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_70_reset || (((SR) === 1'bx) && (recovered_70_q == 1'b0))) recovered_70_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_70_q == (esc_dout_buf_24__i_1_n_0_f596885)))) recovered_70_q <= (esc_dout_buf_24__i_1_n_0_f596885);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_25_0ea3461
  reg recovered_71_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [25] = recovered_71_q;
  wire recovered_71_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_71_reset || (((SR) === 1'bx) && (recovered_71_q == 1'b0))) recovered_71_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_71_q == (esc_dout_buf_25__i_1_n_0_5604152)))) recovered_71_q <= (esc_dout_buf_25__i_1_n_0_5604152);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_26_de71e31
  reg recovered_72_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [26] = recovered_72_q;
  wire recovered_72_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_72_reset || (((SR) === 1'bx) && (recovered_72_q == 1'b0))) recovered_72_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_72_q == (esc_dout_buf_26__i_1_n_0_eeac2a9)))) recovered_72_q <= (esc_dout_buf_26__i_1_n_0_eeac2a9);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_27_f2455fc
  reg recovered_73_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [27] = recovered_73_q;
  wire recovered_73_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_73_reset || (((SR) === 1'bx) && (recovered_73_q == 1'b0))) recovered_73_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_73_q == (esc_dout_buf_27__i_1_n_0_600d618)))) recovered_73_q <= (esc_dout_buf_27__i_1_n_0_600d618);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_28_7cd6c17
  reg recovered_74_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [28] = recovered_74_q;
  wire recovered_74_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_74_reset || (((SR) === 1'bx) && (recovered_74_q == 1'b0))) recovered_74_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_74_q == (esc_dout_buf_28__i_1_n_0_567ea32)))) recovered_74_q <= (esc_dout_buf_28__i_1_n_0_567ea32);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_29_f39ef91
  reg recovered_75_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [29] = recovered_75_q;
  wire recovered_75_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_75_reset || (((SR) === 1'bx) && (recovered_75_q == 1'b0))) recovered_75_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_75_q == (esc_dout_buf_29__i_1_n_0_f8b40b3)))) recovered_75_q <= (esc_dout_buf_29__i_1_n_0_f8b40b3);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_2_fbccf26
  reg recovered_76_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [2] = recovered_76_q;
  wire recovered_76_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_76_reset || (((SR) === 1'bx) && (recovered_76_q == 1'b0))) recovered_76_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_76_q == (esc_dout_buf_2__i_1_n_0_0388fd1)))) recovered_76_q <= (esc_dout_buf_2__i_1_n_0_0388fd1);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_30_8980b9d
  reg recovered_77_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [30] = recovered_77_q;
  wire recovered_77_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_77_reset || (((SR) === 1'bx) && (recovered_77_q == 1'b0))) recovered_77_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_77_q == (esc_dout_buf_30__i_1_n_0_b0eac95)))) recovered_77_q <= (esc_dout_buf_30__i_1_n_0_b0eac95);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_31_e6ee0ac
  reg recovered_78_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [31] = recovered_78_q;
  wire recovered_78_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_78_reset || (((SR) === 1'bx) && (recovered_78_q == 1'b0))) recovered_78_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_78_q == (esc_dout_buf_31__i_1_n_0_995d1e3)))) recovered_78_q <= (esc_dout_buf_31__i_1_n_0_995d1e3);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_34_de4e58b
  reg recovered_79_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [32] = recovered_79_q;
  wire recovered_79_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_79_reset || (((SR) === 1'bx) && (recovered_79_q == 1'b0))) recovered_79_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_79_q == (esc_dout_buf_34__i_2_n_0_bcc0fd3)))) recovered_79_q <= (esc_dout_buf_34__i_2_n_0_bcc0fd3);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_3_3968327
  reg recovered_80_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [3] = recovered_80_q;
  wire recovered_80_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_80_reset || (((SR) === 1'bx) && (recovered_80_q == 1'b0))) recovered_80_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_80_q == (esc_dout_buf_3__i_1_n_0_a1e89d1)))) recovered_80_q <= (esc_dout_buf_3__i_1_n_0_a1e89d1);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_4_3b55ddb
  reg recovered_81_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [4] = recovered_81_q;
  wire recovered_81_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_81_reset || (((SR) === 1'bx) && (recovered_81_q == 1'b0))) recovered_81_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_81_q == (esc_dout_buf_4__i_1_n_0_9790d5b)))) recovered_81_q <= (esc_dout_buf_4__i_1_n_0_9790d5b);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_5_cd471d4
  reg recovered_82_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [5] = recovered_82_q;
  wire recovered_82_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_82_reset || (((SR) === 1'bx) && (recovered_82_q == 1'b0))) recovered_82_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_82_q == (esc_dout_buf_5__i_1_n_0_bcb4bd3)))) recovered_82_q <= (esc_dout_buf_5__i_1_n_0_bcb4bd3);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_6_0e42e9e
  reg recovered_83_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [6] = recovered_83_q;
  wire recovered_83_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_83_reset || (((SR) === 1'bx) && (recovered_83_q == 1'b0))) recovered_83_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_83_q == (esc_dout_buf_6__i_1_n_0_122f0de)))) recovered_83_q <= (esc_dout_buf_6__i_1_n_0_122f0de);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_7_22216d7
  reg recovered_84_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [7] = recovered_84_q;
  wire recovered_84_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_84_reset || (((SR) === 1'bx) && (recovered_84_q == 1'b0))) recovered_84_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_84_q == (esc_dout_buf_7__i_1_n_0_5c8c97d)))) recovered_84_q <= (esc_dout_buf_7__i_1_n_0_5c8c97d);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_8_c0dc513
  reg recovered_85_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [8] = recovered_85_q;
  wire recovered_85_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_85_reset || (((SR) === 1'bx) && (recovered_85_q == 1'b0))) recovered_85_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_85_q == (esc_dout_buf_8__i_1_n_0_fa8be1c)))) recovered_85_q <= (esc_dout_buf_8__i_1_n_0_fa8be1c);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_9_53daae6
  reg recovered_86_q = 1'b0;
  assign esc_dout_buf_reg_34__0_9cc5769 [9] = recovered_86_q;
  wire recovered_86_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_86_reset || (((SR) === 1'bx) && (recovered_86_q == 1'b0))) recovered_86_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_86_q == (esc_dout_buf_9__i_1_n_0_2baf451)))) recovered_86_q <= (esc_dout_buf_9__i_1_n_0_2baf451);
  end

  // Reconstructed LUT3: dout_valid_i_1
  assign dout_valid_i_1_n_0 = ((esc_bus_wide_gen_last_split_89b9056) ? (empty_n_reg_n_0) : (((beat_valid) ? (1'b1) : (empty_n_reg_n_0))));

  // Reconstructed FDRE: dout_valid_reg
  reg recovered_88_q = 1'b0;
  assign beat_valid = recovered_88_q;
  wire recovered_88_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_88_reset || (((SR) === 1'bx) && (recovered_88_q == 1'b0))) recovered_88_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_88_q == (dout_valid_i_1_n_0)))) recovered_88_q <= (dout_valid_i_1_n_0);
  end

  // Reconstructed LUT6: empty_n_i_1
  assign empty_n_i_1_n_0 = ((empty_n_reg_n_0) ? (((push) ? (1'b1) : (((pop) ? (((empty_n_i_3__0_n_0) ? (1'b1) : (((Q[4]) ? (1'b1) : (empty_n_i_2__0_n_0))))) : (1'b1))))) : (((push) ? (~(pop)) : (((pop) ? (((empty_n_i_3__0_n_0) ? (1'b1) : (((Q[4]) ? (1'b1) : (empty_n_i_2__0_n_0))))) : (1'b0))))));

  // Reconstructed LUT2: empty_n_i_2__0
  assign empty_n_i_2__0_n_0 = ((Q[3]) ? (1'b1) : (Q[2]));

  // Reconstructed LUT5: empty_n_i_3__0
  assign empty_n_i_3__0_n_0 = ((Q[1]) ? (1'b1) : (((Q[0]) ? (((Q[5]) ? (1'b1) : (((mOutPtr_reg[6]) ? (1'b1) : (mOutPtr_reg[7]))))) : (1'b1))));

  // Reconstructed FDRE: empty_n_reg
  reg recovered_92_q = 1'b0;
  assign empty_n_reg_n_0 = recovered_92_q;
  wire recovered_92_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_92_reset || (((SR) === 1'bx) && (recovered_92_q == 1'b0))) recovered_92_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_92_q == (empty_n_i_1_n_0)))) recovered_92_q <= (empty_n_i_1_n_0);
  end

  // Reconstructed LUT5: full_n_i_1
  assign full_n_i_1_n_0 = ((pop) ? (1'b1) : (((full_n_reg_0) ? (((m_axi_frame_RVALID) ? (((p_1_in) ? (1'b1) : (~(ap_rst_n)))) : (1'b1))) : (~(ap_rst_n)))));

  // Reconstructed LUT5: full_n_i_2__2
  assign p_1_in = ((full_n_i_3_n_0) ? (1'b1) : (((mOutPtr_reg[6]) ? (((mOutPtr_reg[7]) ? (((Q[5]) ? (~(Q[4])) : (1'b1))) : (1'b1))) : (1'b1))));

  // Reconstructed LUT4: full_n_i_3
  assign full_n_i_3_n_0 = ((Q[0]) ? (((Q[1]) ? (((Q[2]) ? (~(Q[3])) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed FDRE: full_n_reg
  reg recovered_96_q = 1'b1;
  assign full_n_reg_0 = recovered_96_q;
  wire recovered_96_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_96_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_96_q == 1'b0))) recovered_96_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_96_q == (full_n_i_1_n_0)))) recovered_96_q <= (full_n_i_1_n_0);
  end

  // Reconstructed LUT1: esc_mOutPtr_0__i_1_a8b2bd6
  assign esc_mOutPtr_0__i_1_n_0_bf14477 = ~(Q[0]);

  // Reconstructed LUT3: esc_mOutPtr_7__i_1_f6f2270
  assign esc_mOutPtr_7__i_1_n_0_d38cd53 = ((pop) ? (((m_axi_frame_RVALID) ? (~(full_n_reg_0)) : (1'b1))) : (((m_axi_frame_RVALID) ? (full_n_reg_0) : (1'b0))));

  // Reconstructed FDRE: esc_mOutPtr_reg_0_ffb8b5e
  reg recovered_99_q = 1'b0;
  assign Q[0] = recovered_99_q;
  wire recovered_99_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_99_reset || (((SR) === 1'bx) && (recovered_99_q == 1'b0))) recovered_99_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1_n_0_d38cd53) || ((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bz) || (((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bx) && (recovered_99_q == (esc_mOutPtr_0__i_1_n_0_bf14477)))) recovered_99_q <= (esc_mOutPtr_0__i_1_n_0_bf14477);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_1_9d1af5b
  reg recovered_100_q = 1'b0;
  assign Q[1] = recovered_100_q;
  wire recovered_100_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_100_reset || (((SR) === 1'bx) && (recovered_100_q == 1'b0))) recovered_100_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1_n_0_d38cd53) || ((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bz) || (((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bx) && (recovered_100_q == (D[0])))) recovered_100_q <= (D[0]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_2_6b8c13a
  reg recovered_101_q = 1'b0;
  assign Q[2] = recovered_101_q;
  wire recovered_101_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_101_reset || (((SR) === 1'bx) && (recovered_101_q == 1'b0))) recovered_101_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1_n_0_d38cd53) || ((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bz) || (((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bx) && (recovered_101_q == (D[1])))) recovered_101_q <= (D[1]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_3_0755ba0
  reg recovered_102_q = 1'b0;
  assign Q[3] = recovered_102_q;
  wire recovered_102_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_102_reset || (((SR) === 1'bx) && (recovered_102_q == 1'b0))) recovered_102_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1_n_0_d38cd53) || ((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bz) || (((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bx) && (recovered_102_q == (D[2])))) recovered_102_q <= (D[2]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_4_424d593
  reg recovered_103_q = 1'b0;
  assign Q[4] = recovered_103_q;
  wire recovered_103_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_103_reset || (((SR) === 1'bx) && (recovered_103_q == 1'b0))) recovered_103_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1_n_0_d38cd53) || ((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bz) || (((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bx) && (recovered_103_q == (D[3])))) recovered_103_q <= (D[3]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_5_4071cfb
  reg recovered_104_q = 1'b0;
  assign Q[5] = recovered_104_q;
  wire recovered_104_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_104_reset || (((SR) === 1'bx) && (recovered_104_q == 1'b0))) recovered_104_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1_n_0_d38cd53) || ((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bz) || (((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bx) && (recovered_104_q == (D[4])))) recovered_104_q <= (D[4]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_6_6a2a9db
  reg recovered_105_q = 1'b0;
  assign mOutPtr_reg[6] = recovered_105_q;
  wire recovered_105_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_105_reset || (((SR) === 1'bx) && (recovered_105_q == 1'b0))) recovered_105_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1_n_0_d38cd53) || ((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bz) || (((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bx) && (recovered_105_q == (D[5])))) recovered_105_q <= (D[5]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_7_e373a77
  reg recovered_106_q = 1'b0;
  assign mOutPtr_reg[7] = recovered_106_q;
  wire recovered_106_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_106_reset || (((SR) === 1'bx) && (recovered_106_q == 1'b0))) recovered_106_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1_n_0_d38cd53) || ((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bz) || (((esc_mOutPtr_7__i_1_n_0_d38cd53) === 1'bx) && (recovered_106_q == (D[6])))) recovered_106_q <= (D[6]);
  end

  RAMB18E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(18'h00000),
    .INIT_B(18'h00000),
    .INIT_FILE("NONE"),
    .RAM_MODE("SDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(36),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(18'h00000),
    .SRVAL_B(18'h00000),
    .WRITE_MODE_A("READ_FIRST"),
    .WRITE_MODE_B("READ_FIRST"),
    .WRITE_WIDTH_A(0),
    .WRITE_WIDTH_B(36)) 
    mem_reg
       (.ADDRARDADDR({esc_const1_c064970 ,rnext,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .ADDRBWRADDR({esc_const1_c064970 ,waddr,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .CLKARDCLK(ap_clk),
        .CLKBWRCLK(ap_clk),
        .DIADI(mem_reg_0[15:0]),
        .DIBDI(mem_reg_0[31:16]),
        .DIPADIP(m_axi_frame_RRESP),
        .DIPBDIP({esc_const1_c064970 ,mem_reg_0[32]}),
        .DOADO(q_buf[15:0]),
        .DOBDO(q_buf[31:16]),
        .DOPBDOP(q_buf[34]),
        .ENARDEN(esc_const1_c064970 ),
        .ENBWREN(full_n_reg_0),
        .REGCEAREGCE(esc_const0_a0cf646 ),
        .REGCEB(esc_const0_a0cf646 ),
        .RSTRAMARSTRAM(esc_const0_a0cf646 ),
        .RSTRAMB(esc_const0_a0cf646 ),
        .RSTREGARSTREG(esc_const0_a0cf646 ),
        .RSTREGB(esc_const0_a0cf646 ),
        .WEA({esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .WEBWE({m_axi_frame_RVALID,m_axi_frame_RVALID,m_axi_frame_RVALID,m_axi_frame_RVALID}));

  // Reconstructed LUT6: mem_reg_i_1
  assign rnext[7] = ((mem_reg_i_11_n_0) ? (((pop) ? (((raddr[6]) ? (~(raddr[7])) : (raddr[7]))) : (raddr[7]))) : (((pop) ? (((mem_reg_i_10_n_0) ? (raddr[7]) : (((mem_reg_i_9_n_0) ? (raddr[7]) : (((raddr[6]) ? (1'b0) : (raddr[7]))))))) : (raddr[7]))));

  // Reconstructed LUT4: mem_reg_i_10
  assign mem_reg_i_10_n_0 = ((raddr[5]) ? (((raddr[4]) ? (((raddr[3]) ? (~(raddr[2])) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT6: mem_reg_i_11
  assign mem_reg_i_11_n_0 = ((raddr[4]) ? (((raddr[2]) ? (((raddr[0]) ? (((raddr[1]) ? (((raddr[3]) ? (raddr[5]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT5: mem_reg_i_12
  assign mem_reg_i_12_n_0 = ((mem_reg_i_14_n_0) ? (1'b1) : (((raddr[2]) ? (((raddr[3]) ? (((raddr[4]) ? (~(raddr[5])) : (1'b1))) : (1'b1))) : (1'b1))));

  // Reconstructed LUT5: mem_reg_i_13
  assign mem_reg_i_13_n_0 = ((raddr[3]) ? (((raddr[1]) ? (((raddr[0]) ? (((raddr[2]) ? (raddr[4]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT4: mem_reg_i_14
  assign mem_reg_i_14_n_0 = ((raddr[1]) ? (((raddr[0]) ? (((raddr[6]) ? (~(raddr[7])) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT6: mem_reg_i_2
  assign rnext[6] = ((mem_reg_i_11_n_0) ? (((pop) ? (~(raddr[6])) : (raddr[6]))) : (((pop) ? (((mem_reg_i_10_n_0) ? (raddr[6]) : (((mem_reg_i_9_n_0) ? (raddr[6]) : (((raddr[6]) ? (~(raddr[7])) : (1'b0))))))) : (raddr[6]))));

  // Reconstructed LUT4: mem_reg_i_3
  assign rnext[5] = ((mem_reg_i_13_n_0) ? (((raddr[5]) ? (~(pop)) : (((pop) ? (mem_reg_i_12_n_0) : (1'b0))))) : (((raddr[5]) ? (((pop) ? (mem_reg_i_12_n_0) : (1'b1))) : (1'b0))));

  // Reconstructed LUT6: mem_reg_i_4
  assign rnext[4] = ((raddr[3]) ? (((mem_reg_i_9_n_0) ? (((raddr[4]) ? (((pop) ? (mem_reg_i_12_n_0) : (1'b1))) : (1'b0))) : (((raddr[2]) ? (((raddr[4]) ? (~(pop)) : (((pop) ? (mem_reg_i_12_n_0) : (1'b0))))) : (((raddr[4]) ? (((pop) ? (mem_reg_i_12_n_0) : (1'b1))) : (1'b0))))))) : (((raddr[4]) ? (((pop) ? (mem_reg_i_12_n_0) : (1'b1))) : (1'b0))));

  // Reconstructed LUT6: mem_reg_i_5
  assign rnext[3] = ((raddr[2]) ? (((raddr[0]) ? (((raddr[1]) ? (((raddr[3]) ? (~(pop)) : (((pop) ? (mem_reg_i_12_n_0) : (1'b0))))) : (((raddr[3]) ? (((pop) ? (mem_reg_i_12_n_0) : (1'b1))) : (1'b0))))) : (((raddr[3]) ? (((pop) ? (mem_reg_i_12_n_0) : (1'b1))) : (1'b0))))) : (((raddr[3]) ? (((pop) ? (mem_reg_i_12_n_0) : (1'b1))) : (1'b0))));

  // Reconstructed LUT6: mem_reg_i_6
  assign rnext[2] = ((raddr[2]) ? (((pop) ? (mem_reg_i_9_n_0) : (1'b1))) : (((pop) ? (((mem_reg_i_10_n_0) ? (~(mem_reg_i_9_n_0)) : (((mem_reg_i_9_n_0) ? (1'b0) : (((raddr[6]) ? (~(raddr[7])) : (1'b1))))))) : (1'b0))));

  // Reconstructed LUT3: mem_reg_i_7
  assign rnext[1] = ((pop) ? (((raddr[0]) ? (~(raddr[1])) : (raddr[1]))) : (raddr[1]));

  // Reconstructed LUT2: mem_reg_i_8
  assign rnext[0] = ((pop) ? (~(raddr[0])) : (raddr[0]));

  // Reconstructed LUT2: mem_reg_i_9
  assign mem_reg_i_9_n_0 = ((raddr[0]) ? (~(raddr[1])) : (1'b1));

  // Reconstructed LUT2: p_0_out_carry__0_i_1
  assign esc_mOutPtr_reg_6__0_995f4ea [2] = ((mOutPtr_reg[7]) ? (mOutPtr_reg[6]) : (~(mOutPtr_reg[6])));

  // Reconstructed LUT2: p_0_out_carry__0_i_2
  assign esc_mOutPtr_reg_6__0_995f4ea [1] = ((mOutPtr_reg[6]) ? (Q[5]) : (~(Q[5])));

  // Reconstructed LUT2: p_0_out_carry__0_i_3
  assign esc_mOutPtr_reg_6__0_995f4ea [0] = ((Q[5]) ? (Q[4]) : (~(Q[4])));

  // Reconstructed LUT3: p_0_out_carry_i_1
  assign DI = ((pop) ? (1'b0) : (((full_n_reg_0) ? (m_axi_frame_RVALID) : (1'b0))));

  // Reconstructed LUT2: p_0_out_carry_i_2
  assign S[3] = ((Q[4]) ? (Q[3]) : (~(Q[3])));

  // Reconstructed LUT2: p_0_out_carry_i_3
  assign S[2] = ((Q[3]) ? (Q[2]) : (~(Q[2])));

  // Reconstructed LUT2: p_0_out_carry_i_4
  assign S[1] = ((Q[2]) ? (Q[1]) : (~(Q[1])));

  // Reconstructed LUT4: p_0_out_carry_i_5
  assign S[0] = ((m_axi_frame_RVALID) ? (((full_n_reg_0) ? (((pop) ? (~(Q[1])) : (Q[1]))) : (~(Q[1])))) : (~(Q[1])));

  // Reconstructed FDRE: esc_q_tmp_reg_0_e5b75c2
  reg recovered_130_q = 1'b0;
  assign q_tmp[0] = recovered_130_q;
  wire recovered_130_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_130_reset || (((SR) === 1'bx) && (recovered_130_q == 1'b0))) recovered_130_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_130_q == (mem_reg_0[0])))) recovered_130_q <= (mem_reg_0[0]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_10_593161b
  reg recovered_131_q = 1'b0;
  assign q_tmp[10] = recovered_131_q;
  wire recovered_131_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_131_reset || (((SR) === 1'bx) && (recovered_131_q == 1'b0))) recovered_131_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_131_q == (mem_reg_0[10])))) recovered_131_q <= (mem_reg_0[10]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_11_1d4fe85
  reg recovered_132_q = 1'b0;
  assign q_tmp[11] = recovered_132_q;
  wire recovered_132_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_132_reset || (((SR) === 1'bx) && (recovered_132_q == 1'b0))) recovered_132_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_132_q == (mem_reg_0[11])))) recovered_132_q <= (mem_reg_0[11]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_12_19bc390
  reg recovered_133_q = 1'b0;
  assign q_tmp[12] = recovered_133_q;
  wire recovered_133_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_133_reset || (((SR) === 1'bx) && (recovered_133_q == 1'b0))) recovered_133_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_133_q == (mem_reg_0[12])))) recovered_133_q <= (mem_reg_0[12]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_13_7e90f9d
  reg recovered_134_q = 1'b0;
  assign q_tmp[13] = recovered_134_q;
  wire recovered_134_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_134_reset || (((SR) === 1'bx) && (recovered_134_q == 1'b0))) recovered_134_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_134_q == (mem_reg_0[13])))) recovered_134_q <= (mem_reg_0[13]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_14_6ed096b
  reg recovered_135_q = 1'b0;
  assign q_tmp[14] = recovered_135_q;
  wire recovered_135_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_135_reset || (((SR) === 1'bx) && (recovered_135_q == 1'b0))) recovered_135_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_135_q == (mem_reg_0[14])))) recovered_135_q <= (mem_reg_0[14]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_15_1ebc7c1
  reg recovered_136_q = 1'b0;
  assign q_tmp[15] = recovered_136_q;
  wire recovered_136_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_136_reset || (((SR) === 1'bx) && (recovered_136_q == 1'b0))) recovered_136_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_136_q == (mem_reg_0[15])))) recovered_136_q <= (mem_reg_0[15]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_16_81679ba
  reg recovered_137_q = 1'b0;
  assign q_tmp[16] = recovered_137_q;
  wire recovered_137_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_137_reset || (((SR) === 1'bx) && (recovered_137_q == 1'b0))) recovered_137_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_137_q == (mem_reg_0[16])))) recovered_137_q <= (mem_reg_0[16]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_17_131839b
  reg recovered_138_q = 1'b0;
  assign q_tmp[17] = recovered_138_q;
  wire recovered_138_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_138_reset || (((SR) === 1'bx) && (recovered_138_q == 1'b0))) recovered_138_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_138_q == (mem_reg_0[17])))) recovered_138_q <= (mem_reg_0[17]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_18_e9d1f25
  reg recovered_139_q = 1'b0;
  assign q_tmp[18] = recovered_139_q;
  wire recovered_139_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_139_reset || (((SR) === 1'bx) && (recovered_139_q == 1'b0))) recovered_139_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_139_q == (mem_reg_0[18])))) recovered_139_q <= (mem_reg_0[18]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_19_8907ae8
  reg recovered_140_q = 1'b0;
  assign q_tmp[19] = recovered_140_q;
  wire recovered_140_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_140_reset || (((SR) === 1'bx) && (recovered_140_q == 1'b0))) recovered_140_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_140_q == (mem_reg_0[19])))) recovered_140_q <= (mem_reg_0[19]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_1_891e06f
  reg recovered_141_q = 1'b0;
  assign q_tmp[1] = recovered_141_q;
  wire recovered_141_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_141_reset || (((SR) === 1'bx) && (recovered_141_q == 1'b0))) recovered_141_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_141_q == (mem_reg_0[1])))) recovered_141_q <= (mem_reg_0[1]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_20_4288a9b
  reg recovered_142_q = 1'b0;
  assign q_tmp[20] = recovered_142_q;
  wire recovered_142_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_142_reset || (((SR) === 1'bx) && (recovered_142_q == 1'b0))) recovered_142_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_142_q == (mem_reg_0[20])))) recovered_142_q <= (mem_reg_0[20]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_21_8024eb0
  reg recovered_143_q = 1'b0;
  assign q_tmp[21] = recovered_143_q;
  wire recovered_143_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_143_reset || (((SR) === 1'bx) && (recovered_143_q == 1'b0))) recovered_143_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_143_q == (mem_reg_0[21])))) recovered_143_q <= (mem_reg_0[21]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_22_6880a20
  reg recovered_144_q = 1'b0;
  assign q_tmp[22] = recovered_144_q;
  wire recovered_144_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_144_reset || (((SR) === 1'bx) && (recovered_144_q == 1'b0))) recovered_144_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_144_q == (mem_reg_0[22])))) recovered_144_q <= (mem_reg_0[22]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_23_e6e7dd3
  reg recovered_145_q = 1'b0;
  assign q_tmp[23] = recovered_145_q;
  wire recovered_145_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_145_reset || (((SR) === 1'bx) && (recovered_145_q == 1'b0))) recovered_145_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_145_q == (mem_reg_0[23])))) recovered_145_q <= (mem_reg_0[23]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_24_2ad1ba6
  reg recovered_146_q = 1'b0;
  assign q_tmp[24] = recovered_146_q;
  wire recovered_146_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_146_reset || (((SR) === 1'bx) && (recovered_146_q == 1'b0))) recovered_146_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_146_q == (mem_reg_0[24])))) recovered_146_q <= (mem_reg_0[24]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_25_808c812
  reg recovered_147_q = 1'b0;
  assign q_tmp[25] = recovered_147_q;
  wire recovered_147_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_147_reset || (((SR) === 1'bx) && (recovered_147_q == 1'b0))) recovered_147_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_147_q == (mem_reg_0[25])))) recovered_147_q <= (mem_reg_0[25]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_26_1a21fd6
  reg recovered_148_q = 1'b0;
  assign q_tmp[26] = recovered_148_q;
  wire recovered_148_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_148_reset || (((SR) === 1'bx) && (recovered_148_q == 1'b0))) recovered_148_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_148_q == (mem_reg_0[26])))) recovered_148_q <= (mem_reg_0[26]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_27_0564ab1
  reg recovered_149_q = 1'b0;
  assign q_tmp[27] = recovered_149_q;
  wire recovered_149_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_149_reset || (((SR) === 1'bx) && (recovered_149_q == 1'b0))) recovered_149_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_149_q == (mem_reg_0[27])))) recovered_149_q <= (mem_reg_0[27]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_28_05077d7
  reg recovered_150_q = 1'b0;
  assign q_tmp[28] = recovered_150_q;
  wire recovered_150_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_150_reset || (((SR) === 1'bx) && (recovered_150_q == 1'b0))) recovered_150_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_150_q == (mem_reg_0[28])))) recovered_150_q <= (mem_reg_0[28]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_29_8a059f6
  reg recovered_151_q = 1'b0;
  assign q_tmp[29] = recovered_151_q;
  wire recovered_151_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_151_reset || (((SR) === 1'bx) && (recovered_151_q == 1'b0))) recovered_151_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_151_q == (mem_reg_0[29])))) recovered_151_q <= (mem_reg_0[29]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_2_7b7dcbd
  reg recovered_152_q = 1'b0;
  assign q_tmp[2] = recovered_152_q;
  wire recovered_152_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_152_reset || (((SR) === 1'bx) && (recovered_152_q == 1'b0))) recovered_152_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_152_q == (mem_reg_0[2])))) recovered_152_q <= (mem_reg_0[2]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_30_26d447e
  reg recovered_153_q = 1'b0;
  assign q_tmp[30] = recovered_153_q;
  wire recovered_153_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_153_reset || (((SR) === 1'bx) && (recovered_153_q == 1'b0))) recovered_153_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_153_q == (mem_reg_0[30])))) recovered_153_q <= (mem_reg_0[30]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_31_31d8b9a
  reg recovered_154_q = 1'b0;
  assign q_tmp[31] = recovered_154_q;
  wire recovered_154_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_154_reset || (((SR) === 1'bx) && (recovered_154_q == 1'b0))) recovered_154_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_154_q == (mem_reg_0[31])))) recovered_154_q <= (mem_reg_0[31]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_34_b648bd4
  reg recovered_155_q = 1'b0;
  assign q_tmp[34] = recovered_155_q;
  wire recovered_155_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_155_reset || (((SR) === 1'bx) && (recovered_155_q == 1'b0))) recovered_155_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_155_q == (mem_reg_0[32])))) recovered_155_q <= (mem_reg_0[32]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_3_8edae5f
  reg recovered_156_q = 1'b0;
  assign q_tmp[3] = recovered_156_q;
  wire recovered_156_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_156_reset || (((SR) === 1'bx) && (recovered_156_q == 1'b0))) recovered_156_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_156_q == (mem_reg_0[3])))) recovered_156_q <= (mem_reg_0[3]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_4_66e5c00
  reg recovered_157_q = 1'b0;
  assign q_tmp[4] = recovered_157_q;
  wire recovered_157_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_157_reset || (((SR) === 1'bx) && (recovered_157_q == 1'b0))) recovered_157_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_157_q == (mem_reg_0[4])))) recovered_157_q <= (mem_reg_0[4]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_5_ddc7a94
  reg recovered_158_q = 1'b0;
  assign q_tmp[5] = recovered_158_q;
  wire recovered_158_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_158_reset || (((SR) === 1'bx) && (recovered_158_q == 1'b0))) recovered_158_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_158_q == (mem_reg_0[5])))) recovered_158_q <= (mem_reg_0[5]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_6_ff84a2c
  reg recovered_159_q = 1'b0;
  assign q_tmp[6] = recovered_159_q;
  wire recovered_159_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_159_reset || (((SR) === 1'bx) && (recovered_159_q == 1'b0))) recovered_159_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_159_q == (mem_reg_0[6])))) recovered_159_q <= (mem_reg_0[6]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_7_0aea2b6
  reg recovered_160_q = 1'b0;
  assign q_tmp[7] = recovered_160_q;
  wire recovered_160_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_160_reset || (((SR) === 1'bx) && (recovered_160_q == 1'b0))) recovered_160_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_160_q == (mem_reg_0[7])))) recovered_160_q <= (mem_reg_0[7]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_8_75d4846
  reg recovered_161_q = 1'b0;
  assign q_tmp[8] = recovered_161_q;
  wire recovered_161_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_161_reset || (((SR) === 1'bx) && (recovered_161_q == 1'b0))) recovered_161_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_161_q == (mem_reg_0[8])))) recovered_161_q <= (mem_reg_0[8]);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_9_a36dbd1
  reg recovered_162_q = 1'b0;
  assign q_tmp[9] = recovered_162_q;
  wire recovered_162_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_162_reset || (((SR) === 1'bx) && (recovered_162_q == 1'b0))) recovered_162_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_162_q == (mem_reg_0[9])))) recovered_162_q <= (mem_reg_0[9]);
  end

  // Reconstructed FDRE: esc_raddr_reg_0_bde3b2d
  reg recovered_163_q = 1'b0;
  assign raddr[0] = recovered_163_q;
  wire recovered_163_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_163_reset || (((SR) === 1'bx) && (recovered_163_q == 1'b0))) recovered_163_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_163_q == (rnext[0])))) recovered_163_q <= (rnext[0]);
  end

  // Reconstructed FDRE: esc_raddr_reg_1_eaca36b
  reg recovered_164_q = 1'b0;
  assign raddr[1] = recovered_164_q;
  wire recovered_164_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_164_reset || (((SR) === 1'bx) && (recovered_164_q == 1'b0))) recovered_164_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_164_q == (rnext[1])))) recovered_164_q <= (rnext[1]);
  end

  // Reconstructed FDRE: esc_raddr_reg_2_ae4dfd7
  reg recovered_165_q = 1'b0;
  assign raddr[2] = recovered_165_q;
  wire recovered_165_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_165_reset || (((SR) === 1'bx) && (recovered_165_q == 1'b0))) recovered_165_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_165_q == (rnext[2])))) recovered_165_q <= (rnext[2]);
  end

  // Reconstructed FDRE: esc_raddr_reg_3_2191f84
  reg recovered_166_q = 1'b0;
  assign raddr[3] = recovered_166_q;
  wire recovered_166_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_166_reset || (((SR) === 1'bx) && (recovered_166_q == 1'b0))) recovered_166_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_166_q == (rnext[3])))) recovered_166_q <= (rnext[3]);
  end

  // Reconstructed FDRE: esc_raddr_reg_4_8a1fcb0
  reg recovered_167_q = 1'b0;
  assign raddr[4] = recovered_167_q;
  wire recovered_167_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_167_reset || (((SR) === 1'bx) && (recovered_167_q == 1'b0))) recovered_167_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_167_q == (rnext[4])))) recovered_167_q <= (rnext[4]);
  end

  // Reconstructed FDRE: esc_raddr_reg_5_0929059
  reg recovered_168_q = 1'b0;
  assign raddr[5] = recovered_168_q;
  wire recovered_168_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_168_reset || (((SR) === 1'bx) && (recovered_168_q == 1'b0))) recovered_168_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_168_q == (rnext[5])))) recovered_168_q <= (rnext[5]);
  end

  // Reconstructed FDRE: esc_raddr_reg_6_6bfa800
  reg recovered_169_q = 1'b0;
  assign raddr[6] = recovered_169_q;
  wire recovered_169_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_169_reset || (((SR) === 1'bx) && (recovered_169_q == 1'b0))) recovered_169_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_169_q == (rnext[6])))) recovered_169_q <= (rnext[6]);
  end

  // Reconstructed FDRE: esc_raddr_reg_7_98ccdae
  reg recovered_170_q = 1'b0;
  assign raddr[7] = recovered_170_q;
  wire recovered_170_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_170_reset || (((SR) === 1'bx) && (recovered_170_q == 1'b0))) recovered_170_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_170_q == (rnext[7])))) recovered_170_q <= (rnext[7]);
  end

  // Reconstructed LUT6: show_ahead_i_1
  assign show_ahead0 = ((pop) ? (((Q[0]) ? (((show_ahead_i_2_n_0) ? (((Q[1]) ? (1'b0) : (((Q[2]) ? (1'b0) : (~(Q[3])))))) : (1'b0))) : (1'b0))) : (((Q[0]) ? (1'b0) : (((show_ahead_i_2_n_0) ? (((Q[1]) ? (1'b0) : (((Q[2]) ? (1'b0) : (~(Q[3])))))) : (1'b0))))));

  // Reconstructed LUT6: show_ahead_i_2
  assign show_ahead_i_2_n_0 = ((mOutPtr_reg[7]) ? (1'b0) : (((mOutPtr_reg[6]) ? (1'b0) : (((m_axi_frame_RVALID) ? (((full_n_reg_0) ? (((Q[5]) ? (1'b0) : (~(Q[4])))) : (1'b0))) : (1'b0))))));

  // Reconstructed FDRE: show_ahead_reg
  reg recovered_173_q = 1'b0;
  assign show_ahead = recovered_173_q;
  wire recovered_173_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_173_reset || (((SR) === 1'bx) && (recovered_173_q == 1'b0))) recovered_173_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_173_q == (show_ahead0)))) recovered_173_q <= (show_ahead0);
  end

  // Reconstructed LUT1: esc_waddr_0__i_1_21475af
  assign esc_waddr_0__i_1_n_0_3e6a2e1 = ~(waddr[0]);

  // Reconstructed LUT2: esc_waddr_1__i_1_2102fee
  assign esc_waddr_1__i_1_n_0_52694fb = ((waddr[1]) ? (~(waddr[0])) : (waddr[0]));

  // Reconstructed LUT3: esc_waddr_2__i_1_0e87434
  assign esc_waddr_2__i_1_n_0_0e06a9f = ((waddr[1]) ? (((waddr[0]) ? (~(waddr[2])) : (waddr[2]))) : (waddr[2]));

  // Reconstructed LUT4: esc_waddr_3__i_1_f043c0f
  assign esc_waddr_3__i_1_n_0_0174975 = ((waddr[2]) ? (((waddr[1]) ? (((waddr[0]) ? (~(waddr[3])) : (waddr[3]))) : (waddr[3]))) : (waddr[3]));

  // Reconstructed LUT5: esc_waddr_4__i_1_e3c2f7e
  assign esc_waddr_4__i_1_n_0_cd694eb = ((waddr[3]) ? (((waddr[0]) ? (((waddr[1]) ? (((waddr[2]) ? (~(waddr[4])) : (waddr[4]))) : (waddr[4]))) : (waddr[4]))) : (waddr[4]));

  // Reconstructed LUT6: esc_waddr_5__i_1__0_21dce36
  assign esc_waddr_5__i_1__0_n_0_cf6130a = ((waddr[4]) ? (((waddr[2]) ? (((waddr[1]) ? (((waddr[0]) ? (((waddr[3]) ? (~(waddr[5])) : (waddr[5]))) : (waddr[5]))) : (waddr[5]))) : (waddr[5]))) : (waddr[5]));

  // Reconstructed LUT6: esc_waddr_6__i_1_9a123ed
  assign esc_waddr_6__i_1_n_0_5490cbe = ((waddr[5]) ? (((waddr[3]) ? (((esc_waddr_6__i_2_n_0_228b923) ? (((waddr[2]) ? (((waddr[4]) ? (~(waddr[6])) : (waddr[6]))) : (waddr[6]))) : (waddr[6]))) : (waddr[6]))) : (waddr[6]));

  // Reconstructed LUT2: esc_waddr_6__i_2_942bba9
  assign esc_waddr_6__i_2_n_0_228b923 = ((waddr[0]) ? (waddr[1]) : (1'b0));

  // Reconstructed LUT2: esc_waddr_7__i_1_edbe34d
  assign push = ((m_axi_frame_RVALID) ? (full_n_reg_0) : (1'b0));

  // Reconstructed LUT4: esc_waddr_7__i_2_97a1912
  assign esc_waddr_7__i_2_n_0_7208898 = ((waddr[6]) ? (((esc_waddr_7__i_4_n_0_54af9cb) ? (((waddr[7]) ? (esc_waddr_7__i_3_n_0_02cd60d) : (1'b1))) : (((waddr[7]) ? (esc_waddr_7__i_3_n_0_02cd60d) : (1'b0))))) : (waddr[7]));

  // Reconstructed LUT6: esc_waddr_7__i_3_5574306
  assign esc_waddr_7__i_3_n_0_02cd60d = ((waddr[5]) ? (((waddr[3]) ? (((waddr[1]) ? (((waddr[0]) ? (((waddr[2]) ? (~(waddr[4])) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT6: esc_waddr_7__i_4_3a71fb3
  assign esc_waddr_7__i_4_n_0_54af9cb = ((waddr[5]) ? (((waddr[3]) ? (((waddr[0]) ? (((waddr[1]) ? (((waddr[2]) ? (waddr[4]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_waddr_reg_0_a5f0615
  reg recovered_186_q = 1'b0;
  assign waddr[0] = recovered_186_q;
  wire recovered_186_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_186_reset || (((SR) === 1'bx) && (recovered_186_q == 1'b0))) recovered_186_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_186_q == (esc_waddr_0__i_1_n_0_3e6a2e1)))) recovered_186_q <= (esc_waddr_0__i_1_n_0_3e6a2e1);
  end

  // Reconstructed FDRE: esc_waddr_reg_1_358bf4d
  reg recovered_187_q = 1'b0;
  assign waddr[1] = recovered_187_q;
  wire recovered_187_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_187_reset || (((SR) === 1'bx) && (recovered_187_q == 1'b0))) recovered_187_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_187_q == (esc_waddr_1__i_1_n_0_52694fb)))) recovered_187_q <= (esc_waddr_1__i_1_n_0_52694fb);
  end

  // Reconstructed FDRE: esc_waddr_reg_2_2c95dfb
  reg recovered_188_q = 1'b0;
  assign waddr[2] = recovered_188_q;
  wire recovered_188_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_188_reset || (((SR) === 1'bx) && (recovered_188_q == 1'b0))) recovered_188_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_188_q == (esc_waddr_2__i_1_n_0_0e06a9f)))) recovered_188_q <= (esc_waddr_2__i_1_n_0_0e06a9f);
  end

  // Reconstructed FDRE: esc_waddr_reg_3_aadf430
  reg recovered_189_q = 1'b0;
  assign waddr[3] = recovered_189_q;
  wire recovered_189_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_189_reset || (((SR) === 1'bx) && (recovered_189_q == 1'b0))) recovered_189_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_189_q == (esc_waddr_3__i_1_n_0_0174975)))) recovered_189_q <= (esc_waddr_3__i_1_n_0_0174975);
  end

  // Reconstructed FDRE: esc_waddr_reg_4_22508b6
  reg recovered_190_q = 1'b0;
  assign waddr[4] = recovered_190_q;
  wire recovered_190_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_190_reset || (((SR) === 1'bx) && (recovered_190_q == 1'b0))) recovered_190_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_190_q == (esc_waddr_4__i_1_n_0_cd694eb)))) recovered_190_q <= (esc_waddr_4__i_1_n_0_cd694eb);
  end

  // Reconstructed FDRE: esc_waddr_reg_5_a9127a4
  reg recovered_191_q = 1'b0;
  assign waddr[5] = recovered_191_q;
  wire recovered_191_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_191_reset || (((SR) === 1'bx) && (recovered_191_q == 1'b0))) recovered_191_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_191_q == (esc_waddr_5__i_1__0_n_0_cf6130a)))) recovered_191_q <= (esc_waddr_5__i_1__0_n_0_cf6130a);
  end

  // Reconstructed FDRE: esc_waddr_reg_6_07bbe0b
  reg recovered_192_q = 1'b0;
  assign waddr[6] = recovered_192_q;
  wire recovered_192_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_192_reset || (((SR) === 1'bx) && (recovered_192_q == 1'b0))) recovered_192_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_192_q == (esc_waddr_6__i_1_n_0_5490cbe)))) recovered_192_q <= (esc_waddr_6__i_1_n_0_5490cbe);
  end

  // Reconstructed FDRE: esc_waddr_reg_7_be3eb6c
  reg recovered_193_q = 1'b0;
  assign waddr[7] = recovered_193_q;
  wire recovered_193_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_193_reset || (((SR) === 1'bx) && (recovered_193_q == 1'b0))) recovered_193_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_193_q == (esc_waddr_7__i_2_n_0_7208898)))) recovered_193_q <= (esc_waddr_7__i_2_n_0_7208898);
  end

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_frame_m_axi_fifo
   (fifo_burst_ready,
    esc_q_reg_11__0_48c4400 ,
    ap_rst_n_0,
    esc_bus_wide_gen_last_split_89b9056 ,
    D,
    esc_bus_wide_gen_data_buf1__0_dc376b6 ,
    in,
    esc_sect_len_buf_reg_8_292d77b ,
    esc_sect_len_buf_reg_5_3f5b412 ,
    esc_bus_wide_gen_split_cnt_buf_reg_1_bb419a2 ,
    esc_bus_wide_gen_split_cnt_buf_reg_0_b096300 ,
    pout17_out,
    sel,
    esc_q_reg_11__1_c35c8fd ,
    esc_q_reg_11__2_353dfe5 ,
    esc_could_multi_bursts_loop_cnt_reg_2_93127d6 ,
    s_ready_t_reg,
    SR,
    ap_clk,
    ap_rst_n,
    esc_bus_wide_gen_data_buf_reg_15_983c842 ,
    Q,
    esc_pout_reg_3_c06edf1 ,
    esc_bus_wide_gen_data_buf_reg_14_70879f7 ,
    esc_bus_wide_gen_data_buf_reg_13_ac3a8ab ,
    esc_bus_wide_gen_data_buf_reg_12_1c76c13 ,
    esc_bus_wide_gen_data_buf_reg_11_e734296 ,
    esc_bus_wide_gen_data_buf_reg_10_7276198 ,
    esc_bus_wide_gen_data_buf_reg_9_0371e62 ,
    esc_bus_wide_gen_data_buf_reg_8_02e2baa ,
    esc_bus_wide_gen_data_buf01_in_ffc6cb2 ,
    esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 ,
    esc_q_reg_9__0_e788b02 ,
    esc_q_reg_8__0_55d20fe ,
    esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce ,
    esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5 ,
    beat_valid,
    esc_pout_reg_3__0_e61f14a ,
    esc_pout_reg_3__1_5c413a2 ,
    esc_bus_wide_gen_ready_for_data__0_fd98e5d ,
    esc_bus_wide_gen_len_cnt_reg_7_4438a0b ,
    esc_bus_wide_gen_data_buf_reg_16_5e7a22b ,
    esc_bus_wide_gen_data_buf_reg_17_e558b64 ,
    esc_bus_wide_gen_data_buf_reg_18_f7d120a ,
    esc_bus_wide_gen_data_buf_reg_19_d9d0d62 ,
    esc_bus_wide_gen_data_buf_reg_20_0435a6f ,
    esc_bus_wide_gen_data_buf_reg_21_cf4b721 ,
    esc_bus_wide_gen_data_buf_reg_22_d90b101 ,
    esc_bus_wide_gen_data_buf_reg_23_ecf86d9 ,
    esc_could_multi_bursts_next_loop_c288065 ,
    m_axi_frame_ARREADY,
    data_vld_reg_0,
    data_vld_reg_1,
    fifo_rctl_ready,
    esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd ,
    esc_q_reg_11__3_b623487 ,
    rdata_ack_t,
    esc_bus_wide_gen_rdata_valid_t_reg_1a57782 );
  output fifo_burst_ready;
  output esc_q_reg_11__0_48c4400 ;
  output [0:0]ap_rst_n_0;
  output esc_bus_wide_gen_last_split_89b9056 ;
  output [23:0]D;
  output esc_bus_wide_gen_data_buf1__0_dc376b6 ;
  output [3:0]in;
  output esc_sect_len_buf_reg_8_292d77b ;
  output esc_sect_len_buf_reg_5_3f5b412 ;
  output esc_bus_wide_gen_split_cnt_buf_reg_1_bb419a2 ;
  output esc_bus_wide_gen_split_cnt_buf_reg_0_b096300 ;
  output pout17_out;
  output sel;
  output [1:0]esc_q_reg_11__1_c35c8fd ;
  output esc_q_reg_11__2_353dfe5 ;
  output esc_could_multi_bursts_loop_cnt_reg_2_93127d6 ;
  output s_ready_t_reg;
  input [0:0]SR;
  input ap_clk;
  input ap_rst_n;
  input esc_bus_wide_gen_data_buf_reg_15_983c842 ;
  input [15:0]Q;
  input [32:0]esc_pout_reg_3_c06edf1 ;
  input esc_bus_wide_gen_data_buf_reg_14_70879f7 ;
  input esc_bus_wide_gen_data_buf_reg_13_ac3a8ab ;
  input esc_bus_wide_gen_data_buf_reg_12_1c76c13 ;
  input esc_bus_wide_gen_data_buf_reg_11_e734296 ;
  input esc_bus_wide_gen_data_buf_reg_10_7276198 ;
  input esc_bus_wide_gen_data_buf_reg_9_0371e62 ;
  input esc_bus_wide_gen_data_buf_reg_8_02e2baa ;
  input [7:0]esc_bus_wide_gen_data_buf01_in_ffc6cb2 ;
  input [9:0]esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 ;
  input esc_q_reg_9__0_e788b02 ;
  input esc_q_reg_8__0_55d20fe ;
  input esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce ;
  input esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5 ;
  input beat_valid;
  input esc_pout_reg_3__0_e61f14a ;
  input esc_pout_reg_3__1_5c413a2 ;
  input esc_bus_wide_gen_ready_for_data__0_fd98e5d ;
  input [7:0]esc_bus_wide_gen_len_cnt_reg_7_4438a0b ;
  input esc_bus_wide_gen_data_buf_reg_16_5e7a22b ;
  input esc_bus_wide_gen_data_buf_reg_17_e558b64 ;
  input esc_bus_wide_gen_data_buf_reg_18_f7d120a ;
  input esc_bus_wide_gen_data_buf_reg_19_d9d0d62 ;
  input esc_bus_wide_gen_data_buf_reg_20_0435a6f ;
  input esc_bus_wide_gen_data_buf_reg_21_cf4b721 ;
  input esc_bus_wide_gen_data_buf_reg_22_d90b101 ;
  input esc_bus_wide_gen_data_buf_reg_23_ecf86d9 ;
  input esc_could_multi_bursts_next_loop_c288065 ;
  input m_axi_frame_ARREADY;
  input data_vld_reg_0;
  input data_vld_reg_1;
  input fifo_rctl_ready;
  input [5:0]esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd ;
  input [1:0]esc_q_reg_11__3_b623487 ;
  input rdata_ack_t;
  input esc_bus_wide_gen_rdata_valid_t_reg_1a57782 ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [23:0]D;
  wire [15:0]Q;
  wire [0:0]SR;
  wire ap_clk;
  wire ap_rst_n;
  wire [0:0]ap_rst_n_0;
  wire beat_valid;
  wire burst_valid;
  wire [7:0]esc_bus_wide_gen_data_buf01_in_ffc6cb2 ;
  wire esc_bus_wide_gen_data_buf1__0_dc376b6 ;
  wire esc_bus_wide_gen_data_buf_15__i_5_n_0_1cd5223 ;
  wire esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277 ;
  wire esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0 ;
  wire esc_bus_wide_gen_data_buf_23__i_6_n_0_0d5c187 ;
  wire esc_bus_wide_gen_data_buf_23__i_8_n_0_6a2ac94 ;
  wire esc_bus_wide_gen_data_buf_reg_10_7276198 ;
  wire esc_bus_wide_gen_data_buf_reg_11_e734296 ;
  wire esc_bus_wide_gen_data_buf_reg_12_1c76c13 ;
  wire esc_bus_wide_gen_data_buf_reg_13_ac3a8ab ;
  wire esc_bus_wide_gen_data_buf_reg_14_70879f7 ;
  wire esc_bus_wide_gen_data_buf_reg_15_983c842 ;
  wire esc_bus_wide_gen_data_buf_reg_16_5e7a22b ;
  wire esc_bus_wide_gen_data_buf_reg_17_e558b64 ;
  wire esc_bus_wide_gen_data_buf_reg_18_f7d120a ;
  wire esc_bus_wide_gen_data_buf_reg_19_d9d0d62 ;
  wire esc_bus_wide_gen_data_buf_reg_20_0435a6f ;
  wire esc_bus_wide_gen_data_buf_reg_21_cf4b721 ;
  wire esc_bus_wide_gen_data_buf_reg_22_d90b101 ;
  wire esc_bus_wide_gen_data_buf_reg_23_ecf86d9 ;
  wire esc_bus_wide_gen_data_buf_reg_8_02e2baa ;
  wire esc_bus_wide_gen_data_buf_reg_9_0371e62 ;
  wire esc_bus_wide_gen_first_split_be3b6d8 ;
  wire esc_bus_wide_gen_last_beat__0_d3ac12a ;
  wire esc_bus_wide_gen_last_split_89b9056 ;
  wire [7:0]esc_bus_wide_gen_len_cnt_reg_7_4438a0b ;
  wire esc_bus_wide_gen_next_split__0_93984c3 ;
  wire esc_bus_wide_gen_rdata_valid_t_reg_1a57782 ;
  wire esc_bus_wide_gen_ready_for_data__0_fd98e5d ;
  wire [1:0]esc_bus_wide_gen_split_cnt__5_a46c1d2 ;
  wire esc_bus_wide_gen_split_cnt_buf_1__i_2_n_0_7ea5e4e ;
  wire esc_bus_wide_gen_split_cnt_buf_reg_0_b096300 ;
  wire esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5 ;
  wire esc_bus_wide_gen_split_cnt_buf_reg_1_bb419a2 ;
  wire esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce ;
  wire [1:0]esc_bus_wide_gen_tail_split_46d7a0d ;
  wire [11:8]esc_bus_wide_gen_tmp_burst_info_04e25c0 ;
  wire [9:0]esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 ;
  wire [5:0]esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd ;
  wire esc_could_multi_bursts_loop_cnt_reg_2_93127d6 ;
  wire esc_could_multi_bursts_next_loop_c288065 ;
  wire data_vld_i_1_n_0;
  wire data_vld_reg_0;
  wire data_vld_reg_1;
  wire data_vld_reg_n_0;
  wire empty_n_i_3_n_0;
  wire empty_n_i_4_n_0;
  wire fifo_burst_ready;
  wire fifo_rctl_ready;
  wire full_n_i_1__0_n_0;
  wire full_n_i_2_n_0;
  wire [3:0]in;
  wire m_axi_frame_ARREADY;
  wire esc_mem_reg_4__0__srl5_n_0_5b87500 ;
  wire esc_mem_reg_4__10__srl5_n_0_e247105 ;
  wire esc_mem_reg_4__11__srl5_n_0_27bf80c ;
  wire esc_mem_reg_4__1__srl5_n_0_24313a5 ;
  wire esc_mem_reg_4__2__srl5_n_0_f2676c6 ;
  wire esc_mem_reg_4__3__srl5_n_0_2b51a08 ;
  wire esc_mem_reg_4__8__srl5_n_0_2bf3955 ;
  wire esc_mem_reg_4__9__srl5_n_0_bab496c ;
  wire p_27_in;
  wire pop0;
  wire pout17_out;
  wire esc_pout_0__i_1_n_0_c71edc2 ;
  wire esc_pout_1__i_1_n_0_77ba36c ;
  wire esc_pout_2__i_1_n_0_bcda194 ;
  wire [32:0]esc_pout_reg_3_c06edf1 ;
  wire esc_pout_reg_3__0_e61f14a ;
  wire esc_pout_reg_3__1_5c413a2 ;
  wire esc_pout_reg_n_0__0_31a13ed ;
  wire esc_pout_reg_n_0__1_307d4bf ;
  wire esc_pout_reg_n_0__2_3685eef ;
  wire esc_q_reg_11__0_48c4400 ;
  wire [1:0]esc_q_reg_11__1_c35c8fd ;
  wire esc_q_reg_11__2_353dfe5 ;
  wire [1:0]esc_q_reg_11__3_b623487 ;
  wire esc_q_reg_8__0_55d20fe ;
  wire esc_q_reg_9__0_e788b02 ;
  wire esc_q_reg_n_0__0_a7da07b ;
  wire esc_q_reg_n_0__1_9ad9716 ;
  wire esc_q_reg_n_0__2_c6e7fb6 ;
  wire esc_q_reg_n_0__3_3eb90ff ;
  wire rdata_ack_t;
  wire s_ready_t_reg;
  wire esc_sect_len_buf_reg_5_3f5b412 ;
  wire esc_sect_len_buf_reg_8_292d77b ;
  wire sel;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_0__i_1_ad736bf
  assign D[0] = ((esc_bus_wide_gen_data_buf01_in_ffc6cb2 [0]) ? (((esc_pout_reg_3_c06edf1 [0]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[0]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf1__0_dc376b6) : (((Q[0]) ? (1'b1) : (esc_bus_wide_gen_data_buf1__0_dc376b6))))))) : (((esc_pout_reg_3_c06edf1 [0]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[0]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (Q[0]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_10__i_1_2c86de5
  assign D[10] = ((esc_pout_reg_3_c06edf1 [10]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf_reg_10_7276198) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))) : (((Q[10]) ? (1'b1) : (((esc_bus_wide_gen_data_buf_reg_10_7276198) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf_reg_10_7276198) : (((Q[10]) ? (1'b1) : (esc_bus_wide_gen_data_buf_reg_10_7276198))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_11__i_1_f806adc
  assign D[11] = ((esc_pout_reg_3_c06edf1 [11]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf_reg_11_e734296) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))) : (((Q[11]) ? (1'b1) : (((esc_bus_wide_gen_data_buf_reg_11_e734296) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf_reg_11_e734296) : (((Q[11]) ? (1'b1) : (esc_bus_wide_gen_data_buf_reg_11_e734296))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_12__i_1_53292c2
  assign D[12] = ((esc_pout_reg_3_c06edf1 [12]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf_reg_12_1c76c13) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))) : (((Q[12]) ? (1'b1) : (((esc_bus_wide_gen_data_buf_reg_12_1c76c13) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf_reg_12_1c76c13) : (((Q[12]) ? (1'b1) : (esc_bus_wide_gen_data_buf_reg_12_1c76c13))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_13__i_1_6dff721
  assign D[13] = ((esc_pout_reg_3_c06edf1 [13]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf_reg_13_ac3a8ab) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))) : (((Q[13]) ? (1'b1) : (((esc_bus_wide_gen_data_buf_reg_13_ac3a8ab) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf_reg_13_ac3a8ab) : (((Q[13]) ? (1'b1) : (esc_bus_wide_gen_data_buf_reg_13_ac3a8ab))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_14__i_1_ecd1c89
  assign D[14] = ((esc_pout_reg_3_c06edf1 [14]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf_reg_14_70879f7) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))) : (((Q[14]) ? (1'b1) : (((esc_bus_wide_gen_data_buf_reg_14_70879f7) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf_reg_14_70879f7) : (((Q[14]) ? (1'b1) : (esc_bus_wide_gen_data_buf_reg_14_70879f7))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_15__i_1_3c52938
  assign D[15] = ((esc_pout_reg_3_c06edf1 [15]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf_reg_15_983c842) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))) : (((Q[15]) ? (1'b1) : (((esc_bus_wide_gen_data_buf_reg_15_983c842) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf_reg_15_983c842) : (((Q[15]) ? (1'b1) : (esc_bus_wide_gen_data_buf_reg_15_983c842))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_15__i_2_e7f286d
  assign esc_bus_wide_gen_first_split_be3b6d8 = ((esc_bus_wide_gen_split_cnt__5_a46c1d2 [0]) ? (((esc_bus_wide_gen_ready_for_data__0_fd98e5d) ? (((p_27_in) ? (~(esc_bus_wide_gen_data_buf_15__i_5_n_0_1cd5223)) : (1'b0))) : (1'b0))) : (((esc_bus_wide_gen_split_cnt__5_a46c1d2 [1]) ? (((esc_bus_wide_gen_ready_for_data__0_fd98e5d) ? (((p_27_in) ? (~(esc_bus_wide_gen_data_buf_15__i_5_n_0_1cd5223)) : (1'b0))) : (1'b0))) : (((esc_bus_wide_gen_ready_for_data__0_fd98e5d) ? (((beat_valid) ? (((p_27_in) ? (~(esc_bus_wide_gen_data_buf_15__i_5_n_0_1cd5223)) : (1'b1))) : (((p_27_in) ? (~(esc_bus_wide_gen_data_buf_15__i_5_n_0_1cd5223)) : (1'b0))))) : (1'b0))))));

  // Reconstructed LUT3: esc_bus_wide_gen_data_buf_15__i_3_0906b86
  assign esc_bus_wide_gen_data_buf1__0_dc376b6 = ((esc_bus_wide_gen_data_buf_15__i_5_n_0_1cd5223) ? (1'b0) : (((p_27_in) ? (esc_bus_wide_gen_ready_for_data__0_fd98e5d) : (1'b0))));

  // Reconstructed LUT5: esc_bus_wide_gen_data_buf_15__i_5_5d70466
  assign esc_bus_wide_gen_data_buf_15__i_5_n_0_1cd5223 = ((p_27_in) ? (((esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5) ? (((esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce) ? (((esc_q_reg_11__1_c35c8fd [0]) ? (~(esc_q_reg_11__1_c35c8fd [1])) : (1'b1))) : (((esc_q_reg_11__1_c35c8fd [0]) ? (esc_q_reg_11__1_c35c8fd [1]) : (1'b1))))) : (((esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce) ? (((esc_q_reg_11__1_c35c8fd [0]) ? (1'b1) : (~(esc_q_reg_11__1_c35c8fd [1])))) : (1'b0))))) : (((esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5) ? (((esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce) ? (((esc_q_reg_11__1_c35c8fd [0]) ? (~(esc_q_reg_11__1_c35c8fd [1])) : (1'b1))) : (((esc_q_reg_11__1_c35c8fd [0]) ? (esc_q_reg_11__1_c35c8fd [1]) : (1'b1))))) : (((esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce) ? (((esc_q_reg_11__1_c35c8fd [0]) ? (1'b1) : (~(esc_q_reg_11__1_c35c8fd [1])))) : (((esc_q_reg_11__1_c35c8fd [0]) ? (1'b1) : (esc_q_reg_11__1_c35c8fd [1]))))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_16__i_1_6ce03a3
  assign D[16] = ((esc_bus_wide_gen_data_buf_23__i_6_n_0_0d5c187) ? (((esc_pout_reg_3_c06edf1 [24]) ? (1'b1) : (((esc_pout_reg_3_c06edf1 [16]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_16_5e7a22b))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_16_5e7a22b))))))) : (((esc_pout_reg_3_c06edf1 [16]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_16_5e7a22b))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_16_5e7a22b))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_17__i_1_fb001e9
  assign D[17] = ((esc_bus_wide_gen_data_buf_23__i_6_n_0_0d5c187) ? (((esc_pout_reg_3_c06edf1 [25]) ? (1'b1) : (((esc_pout_reg_3_c06edf1 [17]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_17_e558b64))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_17_e558b64))))))) : (((esc_pout_reg_3_c06edf1 [17]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_17_e558b64))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_17_e558b64))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_18__i_1_8578475
  assign D[18] = ((esc_bus_wide_gen_data_buf_23__i_6_n_0_0d5c187) ? (((esc_pout_reg_3_c06edf1 [26]) ? (1'b1) : (((esc_pout_reg_3_c06edf1 [18]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_18_f7d120a))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_18_f7d120a))))))) : (((esc_pout_reg_3_c06edf1 [18]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_18_f7d120a))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_18_f7d120a))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_19__i_1_5e903ed
  assign D[19] = ((esc_bus_wide_gen_data_buf_23__i_6_n_0_0d5c187) ? (((esc_pout_reg_3_c06edf1 [27]) ? (1'b1) : (((esc_pout_reg_3_c06edf1 [19]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_19_d9d0d62))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_19_d9d0d62))))))) : (((esc_pout_reg_3_c06edf1 [19]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_19_d9d0d62))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_19_d9d0d62))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_1__i_1_5f6b938
  assign D[1] = ((esc_bus_wide_gen_data_buf01_in_ffc6cb2 [1]) ? (((esc_pout_reg_3_c06edf1 [1]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[1]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf1__0_dc376b6) : (((Q[1]) ? (1'b1) : (esc_bus_wide_gen_data_buf1__0_dc376b6))))))) : (((esc_pout_reg_3_c06edf1 [1]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[1]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (Q[1]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_20__i_1_1181ab8
  assign D[20] = ((esc_bus_wide_gen_data_buf_23__i_6_n_0_0d5c187) ? (((esc_pout_reg_3_c06edf1 [28]) ? (1'b1) : (((esc_pout_reg_3_c06edf1 [20]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_20_0435a6f))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_20_0435a6f))))))) : (((esc_pout_reg_3_c06edf1 [20]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_20_0435a6f))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_20_0435a6f))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_21__i_1_4657e6a
  assign D[21] = ((esc_bus_wide_gen_data_buf_23__i_6_n_0_0d5c187) ? (((esc_pout_reg_3_c06edf1 [29]) ? (1'b1) : (((esc_pout_reg_3_c06edf1 [21]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_21_cf4b721))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_21_cf4b721))))))) : (((esc_pout_reg_3_c06edf1 [21]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_21_cf4b721))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_21_cf4b721))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_22__i_1_3304401
  assign D[22] = ((esc_bus_wide_gen_data_buf_23__i_6_n_0_0d5c187) ? (((esc_pout_reg_3_c06edf1 [30]) ? (1'b1) : (((esc_pout_reg_3_c06edf1 [22]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_22_d90b101))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_22_d90b101))))))) : (((esc_pout_reg_3_c06edf1 [22]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_22_d90b101))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_22_d90b101))))));

  // Reconstructed LUT2: esc_bus_wide_gen_data_buf_23__i_1_55df166
  assign esc_q_reg_11__2_353dfe5 = ((esc_bus_wide_gen_next_split__0_93984c3) ? (1'b1) : (esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_23__i_2_a496358
  assign D[23] = ((esc_bus_wide_gen_data_buf_23__i_6_n_0_0d5c187) ? (((esc_pout_reg_3_c06edf1 [31]) ? (1'b1) : (((esc_pout_reg_3_c06edf1 [23]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_23_ecf86d9))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_23_ecf86d9))))))) : (((esc_pout_reg_3_c06edf1 [23]) ? (((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b1) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_23_ecf86d9))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (esc_bus_wide_gen_data_buf_reg_23_ecf86d9))))));

  // Reconstructed LUT2: esc_bus_wide_gen_data_buf_23__i_3_a5ccccd
  assign esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277 = ((esc_bus_wide_gen_first_split_be3b6d8) ? (1'b1) : (esc_bus_wide_gen_data_buf1__0_dc376b6));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_23__i_4_ea19deb
  assign esc_bus_wide_gen_next_split__0_93984c3 = ((esc_bus_wide_gen_ready_for_data__0_fd98e5d) ? (((esc_q_reg_11__1_c35c8fd [0]) ? (((esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5) ? (((esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce) ? (((esc_q_reg_11__1_c35c8fd [1]) ? (~(p_27_in)) : (1'b1))) : (((esc_q_reg_11__1_c35c8fd [1]) ? (1'b1) : (~(p_27_in)))))) : (esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce))) : (((esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5) ? (1'b1) : (((esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce) ? (((esc_q_reg_11__1_c35c8fd [1]) ? (~(p_27_in)) : (1'b1))) : (1'b0))))))) : (1'b0));

  // Reconstructed LUT4: esc_bus_wide_gen_data_buf_23__i_5_f79b24d
  assign esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0 = ((esc_bus_wide_gen_first_split_be3b6d8) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_q_reg_11__1_c35c8fd [1]) ? (1'b0) : (~(esc_q_reg_11__1_c35c8fd [0])))) : (1'b1))) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (((esc_q_reg_11__1_c35c8fd [1]) ? (1'b0) : (~(esc_q_reg_11__1_c35c8fd [0])))) : (1'b0))));

  // Reconstructed LUT3: esc_bus_wide_gen_data_buf_23__i_6_4403790
  assign esc_bus_wide_gen_data_buf_23__i_6_n_0_0d5c187 = ((esc_q_reg_11__1_c35c8fd [1]) ? (1'b0) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (esc_q_reg_11__1_c35c8fd [0]) : (1'b0))));

  // Reconstructed LUT5: esc_bus_wide_gen_data_buf_23__i_7_31bd166
  assign p_27_in = ((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [1]) ? (1'b0) : (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [0]) ? (1'b0) : (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [3]) ? (1'b0) : (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [2]) ? (1'b0) : (esc_bus_wide_gen_data_buf_23__i_8_n_0_6a2ac94))))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_23__i_8_b6980b1
  assign esc_bus_wide_gen_data_buf_23__i_8_n_0_6a2ac94 = ((beat_valid) ? (((burst_valid) ? (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [7]) ? (1'b0) : (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [6]) ? (1'b0) : (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [4]) ? (1'b0) : (~(esc_bus_wide_gen_len_cnt_reg_7_4438a0b [5])))))))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_2__i_1_98797ad
  assign D[2] = ((esc_bus_wide_gen_data_buf01_in_ffc6cb2 [2]) ? (((esc_pout_reg_3_c06edf1 [2]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[2]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf1__0_dc376b6) : (((Q[2]) ? (1'b1) : (esc_bus_wide_gen_data_buf1__0_dc376b6))))))) : (((esc_pout_reg_3_c06edf1 [2]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[2]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (Q[2]))))));

  // Reconstructed LUT3: esc_bus_wide_gen_data_buf_31__i_1_39eeae5
  assign esc_q_reg_11__0_48c4400 = ((esc_bus_wide_gen_data_buf_23__i_5_n_0_049cdc0) ? (1'b0) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b1) : (esc_bus_wide_gen_next_split__0_93984c3))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_3__i_1_c5f5658
  assign D[3] = ((esc_bus_wide_gen_data_buf01_in_ffc6cb2 [3]) ? (((esc_pout_reg_3_c06edf1 [3]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[3]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf1__0_dc376b6) : (((Q[3]) ? (1'b1) : (esc_bus_wide_gen_data_buf1__0_dc376b6))))))) : (((esc_pout_reg_3_c06edf1 [3]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[3]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (Q[3]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_4__i_1_4594fba
  assign D[4] = ((esc_bus_wide_gen_data_buf01_in_ffc6cb2 [4]) ? (((esc_pout_reg_3_c06edf1 [4]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[4]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf1__0_dc376b6) : (((Q[4]) ? (1'b1) : (esc_bus_wide_gen_data_buf1__0_dc376b6))))))) : (((esc_pout_reg_3_c06edf1 [4]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[4]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (Q[4]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_5__i_1_3e2e864
  assign D[5] = ((esc_bus_wide_gen_data_buf01_in_ffc6cb2 [5]) ? (((esc_pout_reg_3_c06edf1 [5]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[5]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf1__0_dc376b6) : (((Q[5]) ? (1'b1) : (esc_bus_wide_gen_data_buf1__0_dc376b6))))))) : (((esc_pout_reg_3_c06edf1 [5]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[5]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (Q[5]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_6__i_1_24e89e7
  assign D[6] = ((esc_bus_wide_gen_data_buf01_in_ffc6cb2 [6]) ? (((esc_pout_reg_3_c06edf1 [6]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[6]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf1__0_dc376b6) : (((Q[6]) ? (1'b1) : (esc_bus_wide_gen_data_buf1__0_dc376b6))))))) : (((esc_pout_reg_3_c06edf1 [6]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[6]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (Q[6]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_7__i_1_fdad0b6
  assign D[7] = ((esc_bus_wide_gen_data_buf01_in_ffc6cb2 [7]) ? (((esc_pout_reg_3_c06edf1 [7]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[7]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf1__0_dc376b6) : (((Q[7]) ? (1'b1) : (esc_bus_wide_gen_data_buf1__0_dc376b6))))))) : (((esc_pout_reg_3_c06edf1 [7]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))) : (((Q[7]) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (1'b0) : (Q[7]))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_8__i_1_25dca13
  assign D[8] = ((esc_pout_reg_3_c06edf1 [8]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf_reg_8_02e2baa) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))) : (((Q[8]) ? (1'b1) : (((esc_bus_wide_gen_data_buf_reg_8_02e2baa) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf_reg_8_02e2baa) : (((Q[8]) ? (1'b1) : (esc_bus_wide_gen_data_buf_reg_8_02e2baa))))));

  // Reconstructed LUT6: esc_bus_wide_gen_data_buf_9__i_1_2ef0eea
  assign D[9] = ((esc_pout_reg_3_c06edf1 [9]) ? (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (((esc_bus_wide_gen_data_buf_reg_9_0371e62) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))) : (((Q[9]) ? (1'b1) : (((esc_bus_wide_gen_data_buf_reg_9_0371e62) ? (1'b1) : (((esc_bus_wide_gen_data_buf1__0_dc376b6) ? (1'b0) : (esc_bus_wide_gen_first_split_be3b6d8))))))))) : (((esc_bus_wide_gen_data_buf_23__i_3_n_0_f78a277) ? (esc_bus_wide_gen_data_buf_reg_9_0371e62) : (((Q[9]) ? (1'b1) : (esc_bus_wide_gen_data_buf_reg_9_0371e62))))));

  // Reconstructed LUT3: esc_bus_wide_gen_len_cnt_7__i_1_080b098
  assign ap_rst_n_0 = ((ap_rst_n) ? (((esc_bus_wide_gen_last_split_89b9056) ? (esc_bus_wide_gen_last_beat__0_d3ac12a) : (1'b0))) : (1'b1));

  // Reconstructed LUT6: esc_bus_wide_gen_len_cnt_7__i_2_d40d93b
  assign esc_bus_wide_gen_last_split_89b9056 = ((esc_bus_wide_gen_tail_split_46d7a0d [1]) ? (((esc_bus_wide_gen_split_cnt__5_a46c1d2 [1]) ? (((esc_bus_wide_gen_split_cnt__5_a46c1d2 [0]) ? (((esc_bus_wide_gen_tail_split_46d7a0d [0]) ? (esc_bus_wide_gen_ready_for_data__0_fd98e5d) : (((esc_bus_wide_gen_ready_for_data__0_fd98e5d) ? (~(esc_bus_wide_gen_last_beat__0_d3ac12a)) : (1'b0))))) : (((esc_bus_wide_gen_tail_split_46d7a0d [0]) ? (1'b0) : (((esc_bus_wide_gen_ready_for_data__0_fd98e5d) ? (esc_bus_wide_gen_last_beat__0_d3ac12a) : (1'b0))))))) : (1'b0))) : (((esc_bus_wide_gen_split_cnt__5_a46c1d2 [1]) ? (((esc_bus_wide_gen_split_cnt__5_a46c1d2 [0]) ? (((esc_bus_wide_gen_ready_for_data__0_fd98e5d) ? (~(esc_bus_wide_gen_last_beat__0_d3ac12a)) : (1'b0))) : (1'b0))) : (((esc_bus_wide_gen_split_cnt__5_a46c1d2 [0]) ? (((esc_bus_wide_gen_tail_split_46d7a0d [0]) ? (((esc_bus_wide_gen_ready_for_data__0_fd98e5d) ? (esc_bus_wide_gen_last_beat__0_d3ac12a) : (1'b0))) : (1'b0))) : (((esc_bus_wide_gen_tail_split_46d7a0d [0]) ? (1'b0) : (((esc_bus_wide_gen_ready_for_data__0_fd98e5d) ? (esc_bus_wide_gen_last_beat__0_d3ac12a) : (1'b0))))))))));

  // Reconstructed LUT4: esc_bus_wide_gen_rdata_valid_t_i_1_26e5aa7
  assign s_ready_t_reg = ((esc_bus_wide_gen_first_split_be3b6d8) ? (1'b1) : (((esc_bus_wide_gen_rdata_valid_t_reg_1a57782) ? (((rdata_ack_t) ? (esc_bus_wide_gen_next_split__0_93984c3) : (1'b1))) : (1'b0))));

  // Reconstructed LUT6: esc_bus_wide_gen_split_cnt_buf_0__i_1_74e8f98
  assign esc_bus_wide_gen_split_cnt_buf_reg_0_b096300 = ((esc_bus_wide_gen_last_split_89b9056) ? (1'b0) : (((ap_rst_n) ? (((esc_bus_wide_gen_split_cnt__5_a46c1d2 [0]) ? (((esc_bus_wide_gen_first_split_be3b6d8) ? (1'b0) : (((esc_bus_wide_gen_next_split__0_93984c3) ? (1'b0) : (esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5))))) : (((esc_bus_wide_gen_first_split_be3b6d8) ? (1'b1) : (((esc_bus_wide_gen_next_split__0_93984c3) ? (1'b1) : (esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5))))))) : (1'b0))));

  // Reconstructed LUT6: esc_bus_wide_gen_split_cnt_buf_1__i_1_928444d
  assign esc_bus_wide_gen_split_cnt_buf_reg_1_bb419a2 = ((esc_bus_wide_gen_last_split_89b9056) ? (1'b0) : (((ap_rst_n) ? (((esc_bus_wide_gen_split_cnt__5_a46c1d2 [0]) ? (((esc_bus_wide_gen_split_cnt__5_a46c1d2 [1]) ? (((esc_bus_wide_gen_split_cnt_buf_1__i_2_n_0_7ea5e4e) ? (1'b0) : (esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce))) : (((esc_bus_wide_gen_split_cnt_buf_1__i_2_n_0_7ea5e4e) ? (1'b1) : (esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce))))) : (((esc_bus_wide_gen_split_cnt__5_a46c1d2 [1]) ? (((esc_bus_wide_gen_split_cnt_buf_1__i_2_n_0_7ea5e4e) ? (1'b1) : (esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce))) : (((esc_bus_wide_gen_split_cnt_buf_1__i_2_n_0_7ea5e4e) ? (1'b0) : (esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce))))))) : (1'b0))));

  // Reconstructed LUT2: esc_bus_wide_gen_split_cnt_buf_1__i_2_6da6ad4
  assign esc_bus_wide_gen_split_cnt_buf_1__i_2_n_0_7ea5e4e = ((esc_bus_wide_gen_next_split__0_93984c3) ? (1'b1) : (esc_bus_wide_gen_first_split_be3b6d8));

  // Reconstructed LUT4: esc_bus_wide_gen_split_cnt_buf_1__i_3_b1b1d30
  assign esc_bus_wide_gen_split_cnt__5_a46c1d2 [1] = ((p_27_in) ? (((esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5) ? (esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce) : (((esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce) ? (1'b1) : (esc_q_reg_11__1_c35c8fd [1]))))) : (esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce));

  // Reconstructed LUT4: esc_bus_wide_gen_split_cnt_buf_1__i_4_8279c15
  assign esc_bus_wide_gen_split_cnt__5_a46c1d2 [0] = ((p_27_in) ? (((esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5) ? (1'b1) : (((esc_bus_wide_gen_split_cnt_buf_reg_1__0_8ce95ce) ? (1'b0) : (esc_q_reg_11__1_c35c8fd [0]))))) : (esc_bus_wide_gen_split_cnt_buf_reg_0__0_d1fccc5));

  // Reconstructed LUT6: esc_could_multi_bursts_araddr_buf_63__i_4_0f1a4ab
  assign esc_could_multi_bursts_loop_cnt_reg_2_93127d6 = ((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [4]) ? (1'b0) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [5]) ? (1'b0) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [1]) ? (1'b0) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [0]) ? (1'b0) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [3]) ? (1'b0) : (~(esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [2])))))))))));

  // Reconstructed LUT3: esc_could_multi_bursts_arlen_buf_0__i_1_a5f9771
  assign in[0] = ((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [0]) ? (1'b1) : (((esc_sect_len_buf_reg_5_3f5b412) ? (~(esc_sect_len_buf_reg_8_292d77b)) : (1'b1))));

  // Reconstructed LUT3: esc_could_multi_bursts_arlen_buf_1__i_1_226839e
  assign in[1] = ((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [1]) ? (1'b1) : (((esc_sect_len_buf_reg_5_3f5b412) ? (~(esc_sect_len_buf_reg_8_292d77b)) : (1'b1))));

  // Reconstructed LUT3: esc_could_multi_bursts_arlen_buf_2__i_1_81adca8
  assign in[2] = ((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [2]) ? (1'b1) : (((esc_sect_len_buf_reg_5_3f5b412) ? (~(esc_sect_len_buf_reg_8_292d77b)) : (1'b1))));

  // Reconstructed LUT3: esc_could_multi_bursts_arlen_buf_3__i_1_03b73b2
  assign in[3] = ((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [3]) ? (1'b1) : (((esc_sect_len_buf_reg_5_3f5b412) ? (~(esc_sect_len_buf_reg_8_292d77b)) : (1'b1))));

  // Reconstructed LUT6: esc_could_multi_bursts_arlen_buf_3__i_2_21137fb
  assign esc_sect_len_buf_reg_8_292d77b = ((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [9]) ? (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [5]) ? (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [3]) ? (((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [7]) ? (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [4]) ? (esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [8]) : (~(esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [8])))) : (1'b0))) : (((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [7]) ? (1'b0) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [4]) ? (esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [8]) : (~(esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [8])))))))) : (1'b0))) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [5]) ? (1'b0) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [3]) ? (((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [7]) ? (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [4]) ? (esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [8]) : (~(esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [8])))) : (1'b0))) : (((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [7]) ? (1'b0) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [4]) ? (esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [8]) : (~(esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [8])))))))))));

  // Reconstructed LUT6: esc_could_multi_bursts_arlen_buf_3__i_3_f2f61b4
  assign esc_sect_len_buf_reg_5_3f5b412 = ((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [6]) ? (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [2]) ? (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [0]) ? (((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [4]) ? (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [1]) ? (esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [5]) : (~(esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [5])))) : (1'b0))) : (((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [4]) ? (1'b0) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [1]) ? (esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [5]) : (~(esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [5])))))))) : (1'b0))) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [2]) ? (1'b0) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [0]) ? (((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [4]) ? (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [1]) ? (esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [5]) : (~(esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [5])))) : (1'b0))) : (((esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [4]) ? (1'b0) : (((esc_could_multi_bursts_arlen_buf_reg_3__0_974cdfd [1]) ? (esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [5]) : (~(esc_could_multi_bursts_arlen_buf_reg_3_4d03f10 [5])))))))))));

  // Reconstructed LUT6: data_vld_i_1
  assign data_vld_i_1_n_0 = ((sel) ? (1'b1) : (((pop0) ? (((data_vld_reg_n_0) ? (((esc_pout_reg_n_0__2_3685eef) ? (1'b1) : (((esc_pout_reg_n_0__1_307d4bf) ? (1'b1) : (esc_pout_reg_n_0__0_31a13ed))))) : (1'b0))) : (data_vld_reg_n_0))));

  // Reconstructed FDRE: data_vld_reg
  reg recovered_54_q = 1'b0;
  assign data_vld_reg_n_0 = recovered_54_q;
  wire recovered_54_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_54_reset || (((SR) === 1'bx) && (recovered_54_q == 1'b0))) recovered_54_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_54_q == (data_vld_i_1_n_0)))) recovered_54_q <= (data_vld_i_1_n_0);
  end

  // Reconstructed LUT3: empty_n_i_1
  assign pop0 = ((burst_valid) ? (((esc_bus_wide_gen_last_beat__0_d3ac12a) ? (esc_bus_wide_gen_last_split_89b9056) : (1'b0))) : (1'b1));

  // Reconstructed LUT6: empty_n_i_2
  assign esc_bus_wide_gen_last_beat__0_d3ac12a = ((empty_n_i_4_n_0) ? (1'b0) : (((empty_n_i_3_n_0) ? (1'b0) : (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [7]) ? (1'b0) : (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [6]) ? (1'b0) : (((burst_valid) ? (beat_valid) : (1'b0))))))))));

  // Reconstructed LUT4: empty_n_i_3
  assign empty_n_i_3_n_0 = ((esc_q_reg_n_0__1_9ad9716) ? (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [1]) ? (((esc_q_reg_n_0__2_c6e7fb6) ? (~(esc_bus_wide_gen_len_cnt_reg_7_4438a0b [2])) : (esc_bus_wide_gen_len_cnt_reg_7_4438a0b [2]))) : (1'b1))) : (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [1]) ? (1'b1) : (((esc_q_reg_n_0__2_c6e7fb6) ? (~(esc_bus_wide_gen_len_cnt_reg_7_4438a0b [2])) : (esc_bus_wide_gen_len_cnt_reg_7_4438a0b [2]))))));

  // Reconstructed LUT6: empty_n_i_4
  assign empty_n_i_4_n_0 = ((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [5]) ? (1'b1) : (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [4]) ? (1'b1) : (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [0]) ? (((esc_q_reg_n_0__0_a7da07b) ? (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [3]) ? (~(esc_q_reg_n_0__3_3eb90ff)) : (esc_q_reg_n_0__3_3eb90ff))) : (1'b1))) : (((esc_q_reg_n_0__0_a7da07b) ? (1'b1) : (((esc_bus_wide_gen_len_cnt_reg_7_4438a0b [3]) ? (~(esc_q_reg_n_0__3_3eb90ff)) : (esc_q_reg_n_0__3_3eb90ff))))))))));

  // Reconstructed FDRE: empty_n_reg
  reg recovered_59_q = 1'b0;
  assign burst_valid = recovered_59_q;
  wire recovered_59_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_59_reset || (((SR) === 1'bx) && (recovered_59_q == 1'b0))) recovered_59_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_59_q == (data_vld_reg_n_0)))) recovered_59_q <= (data_vld_reg_n_0);
  end

  // Reconstructed LUT5: full_n_i_1__0
  assign full_n_i_1__0_n_0 = ((fifo_burst_ready) ? (((data_vld_reg_n_0) ? (((pop0) ? (1'b1) : (((full_n_i_2_n_0) ? (~(ap_rst_n)) : (1'b1))))) : (((full_n_i_2_n_0) ? (~(ap_rst_n)) : (1'b1))))) : (((data_vld_reg_n_0) ? (((pop0) ? (1'b1) : (~(ap_rst_n)))) : (~(ap_rst_n)))));

  // Reconstructed LUT6: full_n_i_2
  assign full_n_i_2_n_0 = ((fifo_burst_ready) ? (((esc_could_multi_bursts_next_loop_c288065) ? (((esc_pout_reg_n_0__1_307d4bf) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((esc_pout_reg_n_0__2_3685eef) ? (1'b0) : (data_vld_reg_n_0))) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: full_n_reg
  reg recovered_62_q = 1'b0;
  assign fifo_burst_ready = recovered_62_q;
  wire recovered_62_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_62_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_62_q == 1'b0))) recovered_62_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_62_q == (full_n_i_1__0_n_0)))) recovered_62_q <= (full_n_i_1__0_n_0);
  end

  // Reconstructed SRL16E: esc_mem_reg_4__0__srl5_fa37281
  reg [15:0] recovered_63_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((sel) == 1'b1 || (sel) === 1'bz) recovered_63_shift <= {recovered_63_shift[14:0],in[0]};
  assign esc_mem_reg_4__0__srl5_n_0_5b87500 = recovered_63_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed LUT5: esc_mem_reg_4__0__srl5_i_1_450acd0
  assign sel = ((fifo_rctl_ready) ? (((data_vld_reg_1) ? (((fifo_burst_ready) ? (((data_vld_reg_0) ? (m_axi_frame_ARREADY) : (1'b1))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed SRL16E: esc_mem_reg_4__10__srl5_1f8e5dd
  reg [15:0] recovered_65_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((sel) == 1'b1 || (sel) === 1'bz) recovered_65_shift <= {recovered_65_shift[14:0],esc_bus_wide_gen_tmp_burst_info_04e25c0 [10]};
  assign esc_mem_reg_4__10__srl5_n_0_e247105 = recovered_65_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed LUT2: esc_mem_reg_4__10__srl5_i_1_76ffe80
  assign esc_bus_wide_gen_tmp_burst_info_04e25c0 [10] = ((esc_could_multi_bursts_loop_cnt_reg_2_93127d6) ? (esc_q_reg_11__3_b623487 [0]) : (1'b0));

  // Reconstructed SRL16E: esc_mem_reg_4__11__srl5_c193b80
  reg [15:0] recovered_67_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((sel) == 1'b1 || (sel) === 1'bz) recovered_67_shift <= {recovered_67_shift[14:0],esc_bus_wide_gen_tmp_burst_info_04e25c0 [11]};
  assign esc_mem_reg_4__11__srl5_n_0_27bf80c = recovered_67_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed LUT2: esc_mem_reg_4__11__srl5_i_1_4d8ba13
  assign esc_bus_wide_gen_tmp_burst_info_04e25c0 [11] = ((esc_could_multi_bursts_loop_cnt_reg_2_93127d6) ? (esc_q_reg_11__3_b623487 [1]) : (1'b0));

  // Reconstructed SRL16E: esc_mem_reg_4__1__srl5_a1df094
  reg [15:0] recovered_69_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((sel) == 1'b1 || (sel) === 1'bz) recovered_69_shift <= {recovered_69_shift[14:0],in[1]};
  assign esc_mem_reg_4__1__srl5_n_0_24313a5 = recovered_69_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__2__srl5_4e9d0ad
  reg [15:0] recovered_70_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((sel) == 1'b1 || (sel) === 1'bz) recovered_70_shift <= {recovered_70_shift[14:0],in[2]};
  assign esc_mem_reg_4__2__srl5_n_0_f2676c6 = recovered_70_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__3__srl5_8321240
  reg [15:0] recovered_71_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((sel) == 1'b1 || (sel) === 1'bz) recovered_71_shift <= {recovered_71_shift[14:0],in[3]};
  assign esc_mem_reg_4__3__srl5_n_0_2b51a08 = recovered_71_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__8__srl5_7729bfd
  reg [15:0] recovered_72_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((sel) == 1'b1 || (sel) === 1'bz) recovered_72_shift <= {recovered_72_shift[14:0],esc_bus_wide_gen_tmp_burst_info_04e25c0 [8]};
  assign esc_mem_reg_4__8__srl5_n_0_2bf3955 = recovered_72_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed LUT3: esc_mem_reg_4__8__srl5_i_1_cd960c1
  assign esc_bus_wide_gen_tmp_burst_info_04e25c0 [8] = ((esc_q_reg_8__0_55d20fe) ? (1'b1) : (((esc_sect_len_buf_reg_5_3f5b412) ? (~(esc_sect_len_buf_reg_8_292d77b)) : (1'b1))));

  // Reconstructed SRL16E: esc_mem_reg_4__9__srl5_35a0c21
  reg [15:0] recovered_74_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((sel) == 1'b1 || (sel) === 1'bz) recovered_74_shift <= {recovered_74_shift[14:0],esc_bus_wide_gen_tmp_burst_info_04e25c0 [9]};
  assign esc_mem_reg_4__9__srl5_n_0_bab496c = recovered_74_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed LUT3: esc_mem_reg_4__9__srl5_i_1_eca591b
  assign esc_bus_wide_gen_tmp_burst_info_04e25c0 [9] = ((esc_q_reg_9__0_e788b02) ? (1'b1) : (((esc_sect_len_buf_reg_5_3f5b412) ? (~(esc_sect_len_buf_reg_8_292d77b)) : (1'b1))));

  // Reconstructed LUT6: esc_pout_0__i_1_729e482
  assign esc_pout_0__i_1_n_0_c71edc2 = ((esc_pout_reg_n_0__0_31a13ed) ? (((data_vld_reg_n_0) ? (((pop0) ? (sel) : (~(sel)))) : (1'b1))) : (((esc_pout_reg_n_0__2_3685eef) ? (((data_vld_reg_n_0) ? (((pop0) ? (~(sel)) : (sel))) : (1'b0))) : (((esc_pout_reg_n_0__1_307d4bf) ? (((data_vld_reg_n_0) ? (((pop0) ? (~(sel)) : (sel))) : (1'b0))) : (((data_vld_reg_n_0) ? (((pop0) ? (1'b0) : (sel))) : (1'b0))))))));

  // Reconstructed LUT6: esc_pout_1__i_1_d213e77
  assign esc_pout_1__i_1_n_0_77ba36c = ((sel) ? (((pop0) ? (esc_pout_reg_n_0__1_307d4bf) : (((data_vld_reg_n_0) ? (((esc_pout_reg_n_0__0_31a13ed) ? (~(esc_pout_reg_n_0__1_307d4bf)) : (esc_pout_reg_n_0__1_307d4bf))) : (esc_pout_reg_n_0__1_307d4bf))))) : (((pop0) ? (((data_vld_reg_n_0) ? (((esc_pout_reg_n_0__0_31a13ed) ? (esc_pout_reg_n_0__1_307d4bf) : (((esc_pout_reg_n_0__1_307d4bf) ? (1'b0) : (esc_pout_reg_n_0__2_3685eef))))) : (esc_pout_reg_n_0__1_307d4bf))) : (esc_pout_reg_n_0__1_307d4bf))));

  // Reconstructed LUT6: esc_pout_2__i_1_9909dbc
  assign esc_pout_2__i_1_n_0_bcda194 = ((sel) ? (((pop0) ? (esc_pout_reg_n_0__2_3685eef) : (((data_vld_reg_n_0) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((esc_pout_reg_n_0__1_307d4bf) ? (~(esc_pout_reg_n_0__2_3685eef)) : (esc_pout_reg_n_0__2_3685eef))) : (esc_pout_reg_n_0__2_3685eef))) : (esc_pout_reg_n_0__2_3685eef))))) : (((pop0) ? (((data_vld_reg_n_0) ? (((esc_pout_reg_n_0__0_31a13ed) ? (esc_pout_reg_n_0__2_3685eef) : (((esc_pout_reg_n_0__1_307d4bf) ? (esc_pout_reg_n_0__2_3685eef) : (1'b0))))) : (esc_pout_reg_n_0__2_3685eef))) : (esc_pout_reg_n_0__2_3685eef))));

  // Reconstructed LUT6: esc_pout_3__i_5_28a4c7e
  assign pout17_out = ((esc_pout_reg_3__1_5c413a2) ? (((esc_pout_reg_3__0_e61f14a) ? (((beat_valid) ? (((esc_pout_reg_3_c06edf1 [32]) ? (((esc_bus_wide_gen_last_split_89b9056) ? (1'b0) : (sel))) : (sel))) : (sel))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_pout_reg_0_cd95a63
  reg recovered_80_q = 1'b0;
  assign esc_pout_reg_n_0__0_31a13ed = recovered_80_q;
  wire recovered_80_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_80_reset || (((SR) === 1'bx) && (recovered_80_q == 1'b0))) recovered_80_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_80_q == (esc_pout_0__i_1_n_0_c71edc2)))) recovered_80_q <= (esc_pout_0__i_1_n_0_c71edc2);
  end

  // Reconstructed FDRE: esc_pout_reg_1_325167f
  reg recovered_81_q = 1'b0;
  assign esc_pout_reg_n_0__1_307d4bf = recovered_81_q;
  wire recovered_81_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_81_reset || (((SR) === 1'bx) && (recovered_81_q == 1'b0))) recovered_81_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_81_q == (esc_pout_1__i_1_n_0_77ba36c)))) recovered_81_q <= (esc_pout_1__i_1_n_0_77ba36c);
  end

  // Reconstructed FDRE: esc_pout_reg_2_3108b14
  reg recovered_82_q = 1'b0;
  assign esc_pout_reg_n_0__2_3685eef = recovered_82_q;
  wire recovered_82_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_82_reset || (((SR) === 1'bx) && (recovered_82_q == 1'b0))) recovered_82_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_82_q == (esc_pout_2__i_1_n_0_bcda194)))) recovered_82_q <= (esc_pout_2__i_1_n_0_bcda194);
  end

  // Reconstructed FDRE: esc_q_reg_0_02a935c
  reg recovered_83_q = 1'b0;
  assign esc_q_reg_n_0__0_a7da07b = recovered_83_q;
  wire recovered_83_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_83_reset || (((SR) === 1'bx) && (recovered_83_q == 1'b0))) recovered_83_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_83_q == (esc_mem_reg_4__0__srl5_n_0_5b87500)))) recovered_83_q <= (esc_mem_reg_4__0__srl5_n_0_5b87500);
  end

  // Reconstructed FDRE: esc_q_reg_10_11878f1
  reg recovered_84_q = 1'b0;
  assign esc_q_reg_11__1_c35c8fd [0] = recovered_84_q;
  wire recovered_84_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_84_reset || (((SR) === 1'bx) && (recovered_84_q == 1'b0))) recovered_84_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_84_q == (esc_mem_reg_4__10__srl5_n_0_e247105)))) recovered_84_q <= (esc_mem_reg_4__10__srl5_n_0_e247105);
  end

  // Reconstructed FDRE: esc_q_reg_11_f6a1408
  reg recovered_85_q = 1'b0;
  assign esc_q_reg_11__1_c35c8fd [1] = recovered_85_q;
  wire recovered_85_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_85_reset || (((SR) === 1'bx) && (recovered_85_q == 1'b0))) recovered_85_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_85_q == (esc_mem_reg_4__11__srl5_n_0_27bf80c)))) recovered_85_q <= (esc_mem_reg_4__11__srl5_n_0_27bf80c);
  end

  // Reconstructed FDRE: esc_q_reg_1_2d13bdc
  reg recovered_86_q = 1'b0;
  assign esc_q_reg_n_0__1_9ad9716 = recovered_86_q;
  wire recovered_86_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_86_reset || (((SR) === 1'bx) && (recovered_86_q == 1'b0))) recovered_86_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_86_q == (esc_mem_reg_4__1__srl5_n_0_24313a5)))) recovered_86_q <= (esc_mem_reg_4__1__srl5_n_0_24313a5);
  end

  // Reconstructed FDRE: esc_q_reg_2_5a064fe
  reg recovered_87_q = 1'b0;
  assign esc_q_reg_n_0__2_c6e7fb6 = recovered_87_q;
  wire recovered_87_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_87_reset || (((SR) === 1'bx) && (recovered_87_q == 1'b0))) recovered_87_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_87_q == (esc_mem_reg_4__2__srl5_n_0_f2676c6)))) recovered_87_q <= (esc_mem_reg_4__2__srl5_n_0_f2676c6);
  end

  // Reconstructed FDRE: esc_q_reg_3_e0a3a92
  reg recovered_88_q = 1'b0;
  assign esc_q_reg_n_0__3_3eb90ff = recovered_88_q;
  wire recovered_88_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_88_reset || (((SR) === 1'bx) && (recovered_88_q == 1'b0))) recovered_88_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_88_q == (esc_mem_reg_4__3__srl5_n_0_2b51a08)))) recovered_88_q <= (esc_mem_reg_4__3__srl5_n_0_2b51a08);
  end

  // Reconstructed FDRE: esc_q_reg_8_7537f74
  reg recovered_89_q = 1'b0;
  assign esc_bus_wide_gen_tail_split_46d7a0d [0] = recovered_89_q;
  wire recovered_89_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_89_reset || (((SR) === 1'bx) && (recovered_89_q == 1'b0))) recovered_89_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_89_q == (esc_mem_reg_4__8__srl5_n_0_2bf3955)))) recovered_89_q <= (esc_mem_reg_4__8__srl5_n_0_2bf3955);
  end

  // Reconstructed FDRE: esc_q_reg_9_974df34
  reg recovered_90_q = 1'b0;
  assign esc_bus_wide_gen_tail_split_46d7a0d [1] = recovered_90_q;
  wire recovered_90_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_90_reset || (((SR) === 1'bx) && (recovered_90_q == 1'b0))) recovered_90_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_90_q == (esc_mem_reg_4__9__srl5_n_0_bab496c)))) recovered_90_q <= (esc_mem_reg_4__9__srl5_n_0_bab496c);
  end

endmodule

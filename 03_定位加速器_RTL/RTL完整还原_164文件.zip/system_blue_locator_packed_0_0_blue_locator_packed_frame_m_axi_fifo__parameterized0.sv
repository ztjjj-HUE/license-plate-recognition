// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_frame_m_axi_fifo__parameterized0
   (fifo_rreq_valid,
    rs2f_rreq_ack,
    S,
    next_rreq,
    E,
    D,
    esc_q_reg_80__0_7eb3a1d ,
    esc_q_reg_80__1_0f2d88b ,
    esc_q_reg_77__0_a86ebaf ,
    esc_q_reg_74__0_783987f ,
    invalid_len_event0,
    SR,
    ap_clk,
    Q,
    last_sect_carry__3,
    ap_rst_n,
    p_20_in,
    esc_sect_cnt_reg_51_7c99099 ,
    sect_cnt0,
    fifo_rreq_valid_buf_reg,
    fifo_rreq_valid_buf_reg_0,
    fifo_rreq_valid_buf_reg_1,
    full_n_reg_0,
    esc_q_reg_63__0_b4ed0ea );
  output fifo_rreq_valid;
  output rs2f_rreq_ack;
  output [1:0]S;
  output next_rreq;
  output [0:0]E;
  output [51:0]D;
  output [0:0]esc_q_reg_80__0_7eb3a1d ;
  output [67:0]esc_q_reg_80__1_0f2d88b ;
  output [1:0]esc_q_reg_77__0_a86ebaf ;
  output [0:0]esc_q_reg_74__0_783987f ;
  output invalid_len_event0;
  input [0:0]SR;
  input ap_clk;
  input [3:0]Q;
  input [4:0]last_sect_carry__3;
  input ap_rst_n;
  input p_20_in;
  input [51:0]esc_sect_cnt_reg_51_7c99099 ;
  input [50:0]sect_cnt0;
  input fifo_rreq_valid_buf_reg;
  input [0:0]fifo_rreq_valid_buf_reg_0;
  input fifo_rreq_valid_buf_reg_1;
  input [0:0]full_n_reg_0;
  input [63:0]esc_q_reg_63__0_b4ed0ea ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [51:0]D;
  wire [0:0]E;
  wire [3:0]Q;
  wire [1:0]S;
  wire [0:0]SR;
  wire ap_clk;
  wire ap_rst_n;
  wire data_vld_i_1__0_n_0;
  wire data_vld_reg_n_0;
  wire fifo_rreq_valid;
  wire fifo_rreq_valid_buf_reg;
  wire [0:0]fifo_rreq_valid_buf_reg_0;
  wire fifo_rreq_valid_buf_reg_1;
  wire full_n_i_1__2_n_0;
  wire full_n_i_2__0_n_0;
  wire [0:0]full_n_reg_0;
  wire invalid_len_event0;
  wire [4:0]last_sect_carry__3;
  wire esc_mem_reg_4__0__srl5_n_0_5b87500 ;
  wire esc_mem_reg_4__10__srl5_n_0_e247105 ;
  wire esc_mem_reg_4__11__srl5_n_0_27bf80c ;
  wire esc_mem_reg_4__12__srl5_n_0_997a3d0 ;
  wire esc_mem_reg_4__13__srl5_n_0_c14c677 ;
  wire esc_mem_reg_4__14__srl5_n_0_b5761f7 ;
  wire esc_mem_reg_4__15__srl5_n_0_76b0ea7 ;
  wire esc_mem_reg_4__16__srl5_n_0_3ede415 ;
  wire esc_mem_reg_4__17__srl5_n_0_223dae8 ;
  wire esc_mem_reg_4__18__srl5_n_0_0039e45 ;
  wire esc_mem_reg_4__19__srl5_n_0_b3b8abd ;
  wire esc_mem_reg_4__1__srl5_n_0_24313a5 ;
  wire esc_mem_reg_4__20__srl5_n_0_a7cb185 ;
  wire esc_mem_reg_4__21__srl5_n_0_1133f48 ;
  wire esc_mem_reg_4__22__srl5_n_0_9fdb6b1 ;
  wire esc_mem_reg_4__23__srl5_n_0_d387627 ;
  wire esc_mem_reg_4__24__srl5_n_0_113f629 ;
  wire esc_mem_reg_4__25__srl5_n_0_c2ea529 ;
  wire esc_mem_reg_4__26__srl5_n_0_58cac40 ;
  wire esc_mem_reg_4__27__srl5_n_0_724e83a ;
  wire esc_mem_reg_4__28__srl5_n_0_b25f46a ;
  wire esc_mem_reg_4__29__srl5_n_0_56756af ;
  wire esc_mem_reg_4__2__srl5_n_0_f2676c6 ;
  wire esc_mem_reg_4__30__srl5_n_0_2b5eac6 ;
  wire esc_mem_reg_4__31__srl5_n_0_163765c ;
  wire esc_mem_reg_4__32__srl5_n_0_7f3a683 ;
  wire esc_mem_reg_4__33__srl5_n_0_c4d4bcb ;
  wire esc_mem_reg_4__34__srl5_n_0_e917cf0 ;
  wire esc_mem_reg_4__35__srl5_n_0_d7054c7 ;
  wire esc_mem_reg_4__36__srl5_n_0_8180ba4 ;
  wire esc_mem_reg_4__37__srl5_n_0_e31fe08 ;
  wire esc_mem_reg_4__38__srl5_n_0_15d7c61 ;
  wire esc_mem_reg_4__39__srl5_n_0_aed7ba4 ;
  wire esc_mem_reg_4__3__srl5_n_0_2b51a08 ;
  wire esc_mem_reg_4__40__srl5_n_0_8d2fc8b ;
  wire esc_mem_reg_4__41__srl5_n_0_43f2c18 ;
  wire esc_mem_reg_4__42__srl5_n_0_5068a2c ;
  wire esc_mem_reg_4__43__srl5_n_0_2ccfd64 ;
  wire esc_mem_reg_4__44__srl5_n_0_81605ce ;
  wire esc_mem_reg_4__45__srl5_n_0_ca3fe15 ;
  wire esc_mem_reg_4__46__srl5_n_0_d1bde41 ;
  wire esc_mem_reg_4__47__srl5_n_0_812a5e0 ;
  wire esc_mem_reg_4__48__srl5_n_0_15ce78c ;
  wire esc_mem_reg_4__49__srl5_n_0_879ca8b ;
  wire esc_mem_reg_4__4__srl5_n_0_9ac6433 ;
  wire esc_mem_reg_4__50__srl5_n_0_1085b2a ;
  wire esc_mem_reg_4__51__srl5_n_0_074a965 ;
  wire esc_mem_reg_4__52__srl5_n_0_1c3bad9 ;
  wire esc_mem_reg_4__53__srl5_n_0_10fdae5 ;
  wire esc_mem_reg_4__54__srl5_n_0_d87cca8 ;
  wire esc_mem_reg_4__55__srl5_n_0_f34d6be ;
  wire esc_mem_reg_4__56__srl5_n_0_ff79cb7 ;
  wire esc_mem_reg_4__57__srl5_n_0_6945ac8 ;
  wire esc_mem_reg_4__58__srl5_n_0_0ceb6fa ;
  wire esc_mem_reg_4__59__srl5_n_0_818a395 ;
  wire esc_mem_reg_4__5__srl5_n_0_843e618 ;
  wire esc_mem_reg_4__60__srl5_n_0_783d111 ;
  wire esc_mem_reg_4__61__srl5_n_0_7362482 ;
  wire esc_mem_reg_4__62__srl5_n_0_aca8eb1 ;
  wire esc_mem_reg_4__63__srl5_n_0_27eb226 ;
  wire esc_mem_reg_4__6__srl5_n_0_b2b44f9 ;
  wire esc_mem_reg_4__74__srl5_n_0_2d74fec ;
  wire esc_mem_reg_4__75__srl5_n_0_f1a7b3e ;
  wire esc_mem_reg_4__77__srl5_n_0_4a4f8ac ;
  wire esc_mem_reg_4__7__srl5_n_0_c57737b ;
  wire esc_mem_reg_4__80__srl5_n_0_d3a98e4 ;
  wire esc_mem_reg_4__8__srl5_n_0_2bf3955 ;
  wire esc_mem_reg_4__9__srl5_n_0_bab496c ;
  wire next_rreq;
  wire p_20_in;
  wire pop0;
  wire esc_pout_0__i_1_n_0_c71edc2 ;
  wire esc_pout_1__i_1_n_0_77ba36c ;
  wire esc_pout_2__i_1_n_0_bcda194 ;
  wire esc_pout_reg_n_0__0_31a13ed ;
  wire esc_pout_reg_n_0__1_307d4bf ;
  wire esc_pout_reg_n_0__2_3685eef ;
  wire push;
  wire [63:0]esc_q_reg_63__0_b4ed0ea ;
  wire [0:0]esc_q_reg_74__0_783987f ;
  wire [1:0]esc_q_reg_77__0_a86ebaf ;
  wire [0:0]esc_q_reg_80__0_7eb3a1d ;
  wire [67:0]esc_q_reg_80__1_0f2d88b ;
  wire rs2f_rreq_ack;
  wire [50:0]sect_cnt0;
  wire [51:0]esc_sect_cnt_reg_51_7c99099 ;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT1: align_len0_carry__0_i_1
  assign esc_q_reg_80__0_7eb3a1d = ~(esc_q_reg_80__1_0f2d88b [67]);

  // Reconstructed LUT1: align_len0_carry_i_1
  assign esc_q_reg_77__0_a86ebaf [1] = ~(esc_q_reg_80__1_0f2d88b [66]);

  // Reconstructed LUT1: align_len0_carry_i_2
  assign esc_q_reg_77__0_a86ebaf [0] = ~(esc_q_reg_80__1_0f2d88b [65]);

  // Reconstructed LUT1: esc_align_len_10__i_1_bef920e
  assign esc_q_reg_74__0_783987f = ~(esc_q_reg_80__1_0f2d88b [64]);

  // Reconstructed LUT6: data_vld_i_1__0
  assign data_vld_i_1__0_n_0 = ((push) ? (1'b1) : (((pop0) ? (((data_vld_reg_n_0) ? (((esc_pout_reg_n_0__2_3685eef) ? (1'b1) : (((esc_pout_reg_n_0__1_307d4bf) ? (1'b1) : (esc_pout_reg_n_0__0_31a13ed))))) : (1'b0))) : (data_vld_reg_n_0))));

  // Reconstructed FDRE: data_vld_reg
  reg recovered_8_q = 1'b0;
  assign data_vld_reg_n_0 = recovered_8_q;
  wire recovered_8_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_8_reset || (((SR) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_8_q == (data_vld_i_1__0_n_0)))) recovered_8_q <= (data_vld_i_1__0_n_0);
  end

  // Reconstructed LUT2: empty_n_i_1__0
  assign pop0 = ((fifo_rreq_valid) ? (next_rreq) : (1'b1));

  // Reconstructed FDRE: empty_n_reg
  reg recovered_10_q = 1'b0;
  assign fifo_rreq_valid = recovered_10_q;
  wire recovered_10_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_10_reset || (((SR) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_10_q == (data_vld_reg_n_0)))) recovered_10_q <= (data_vld_reg_n_0);
  end

  // Reconstructed LUT5: fifo_rreq_valid_buf_i_1
  assign next_rreq = ((fifo_rreq_valid_buf_reg_1) ? (((p_20_in) ? (((fifo_rreq_valid_buf_reg_0) ? (((fifo_rreq_valid_buf_reg) ? (1'b1) : (fifo_rreq_valid))) : (1'b0))) : (1'b0))) : (((fifo_rreq_valid_buf_reg) ? (1'b1) : (fifo_rreq_valid))));

  // Reconstructed LUT6: full_n_i_1__2
  assign full_n_i_1__2_n_0 = ((rs2f_rreq_ack) ? (((data_vld_reg_n_0) ? (((fifo_rreq_valid) ? (((next_rreq) ? (1'b1) : (((full_n_i_2__0_n_0) ? (~(ap_rst_n)) : (1'b1))))) : (1'b1))) : (((full_n_i_2__0_n_0) ? (~(ap_rst_n)) : (1'b1))))) : (((data_vld_reg_n_0) ? (((fifo_rreq_valid) ? (((next_rreq) ? (1'b1) : (~(ap_rst_n)))) : (1'b1))) : (~(ap_rst_n)))));

  // Reconstructed LUT6: full_n_i_2__0
  assign full_n_i_2__0_n_0 = ((esc_pout_reg_n_0__1_307d4bf) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((esc_pout_reg_n_0__2_3685eef) ? (1'b0) : (((data_vld_reg_n_0) ? (((full_n_reg_0) ? (rs2f_rreq_ack) : (1'b0))) : (1'b0))))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: full_n_reg
  reg recovered_14_q = 1'b0;
  assign rs2f_rreq_ack = recovered_14_q;
  wire recovered_14_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_14_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_14_q == (full_n_i_1__2_n_0)))) recovered_14_q <= (full_n_i_1__2_n_0);
  end

  // Reconstructed LUT5: invalid_len_event_i_1
  assign invalid_len_event0 = ((fifo_rreq_valid) ? (((esc_q_reg_80__1_0f2d88b [67]) ? (1'b0) : (((esc_q_reg_80__1_0f2d88b [66]) ? (1'b0) : (((esc_q_reg_80__1_0f2d88b [65]) ? (1'b0) : (~(esc_q_reg_80__1_0f2d88b [64])))))))) : (1'b0));

  // Reconstructed LUT2: last_sect_carry__3_i_1
  assign S[1] = ((last_sect_carry__3[4]) ? (Q[3]) : (~(Q[3])));

  // Reconstructed LUT6: last_sect_carry__3_i_2
  assign S[0] = ((last_sect_carry__3[3]) ? (((Q[2]) ? (((Q[0]) ? (((last_sect_carry__3[1]) ? (((Q[1]) ? (last_sect_carry__3[2]) : (~(last_sect_carry__3[2])))) : (1'b0))) : (((last_sect_carry__3[1]) ? (1'b0) : (((Q[1]) ? (last_sect_carry__3[2]) : (~(last_sect_carry__3[2])))))))) : (1'b0))) : (((Q[2]) ? (1'b0) : (((Q[0]) ? (((last_sect_carry__3[1]) ? (((Q[1]) ? (last_sect_carry__3[2]) : (~(last_sect_carry__3[2])))) : (1'b0))) : (((last_sect_carry__3[1]) ? (1'b0) : (((Q[1]) ? (last_sect_carry__3[2]) : (~(last_sect_carry__3[2])))))))))));

  // Reconstructed SRL16E: esc_mem_reg_4__0__srl5_fa37281
  reg [15:0] recovered_18_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_18_shift <= {recovered_18_shift[14:0],esc_q_reg_63__0_b4ed0ea [0]};
  assign esc_mem_reg_4__0__srl5_n_0_5b87500 = recovered_18_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed LUT2: esc_mem_reg_4__0__srl5_i_1__0_a2a8845
  assign push = ((full_n_reg_0) ? (rs2f_rreq_ack) : (1'b0));

  // Reconstructed SRL16E: esc_mem_reg_4__10__srl5_1f8e5dd
  reg [15:0] recovered_20_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_20_shift <= {recovered_20_shift[14:0],esc_q_reg_63__0_b4ed0ea [10]};
  assign esc_mem_reg_4__10__srl5_n_0_e247105 = recovered_20_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__11__srl5_c193b80
  reg [15:0] recovered_21_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_21_shift <= {recovered_21_shift[14:0],esc_q_reg_63__0_b4ed0ea [11]};
  assign esc_mem_reg_4__11__srl5_n_0_27bf80c = recovered_21_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__12__srl5_c86ecf1
  reg [15:0] recovered_22_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_22_shift <= {recovered_22_shift[14:0],esc_q_reg_63__0_b4ed0ea [12]};
  assign esc_mem_reg_4__12__srl5_n_0_997a3d0 = recovered_22_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__13__srl5_9391e2f
  reg [15:0] recovered_23_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_23_shift <= {recovered_23_shift[14:0],esc_q_reg_63__0_b4ed0ea [13]};
  assign esc_mem_reg_4__13__srl5_n_0_c14c677 = recovered_23_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__14__srl5_fb3e32d
  reg [15:0] recovered_24_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_24_shift <= {recovered_24_shift[14:0],esc_q_reg_63__0_b4ed0ea [14]};
  assign esc_mem_reg_4__14__srl5_n_0_b5761f7 = recovered_24_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__15__srl5_fefac9b
  reg [15:0] recovered_25_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_25_shift <= {recovered_25_shift[14:0],esc_q_reg_63__0_b4ed0ea [15]};
  assign esc_mem_reg_4__15__srl5_n_0_76b0ea7 = recovered_25_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__16__srl5_a608e6a
  reg [15:0] recovered_26_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_26_shift <= {recovered_26_shift[14:0],esc_q_reg_63__0_b4ed0ea [16]};
  assign esc_mem_reg_4__16__srl5_n_0_3ede415 = recovered_26_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__17__srl5_f26e2f6
  reg [15:0] recovered_27_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_27_shift <= {recovered_27_shift[14:0],esc_q_reg_63__0_b4ed0ea [17]};
  assign esc_mem_reg_4__17__srl5_n_0_223dae8 = recovered_27_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__18__srl5_4c5170b
  reg [15:0] recovered_28_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_28_shift <= {recovered_28_shift[14:0],esc_q_reg_63__0_b4ed0ea [18]};
  assign esc_mem_reg_4__18__srl5_n_0_0039e45 = recovered_28_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__19__srl5_d074f81
  reg [15:0] recovered_29_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_29_shift <= {recovered_29_shift[14:0],esc_q_reg_63__0_b4ed0ea [19]};
  assign esc_mem_reg_4__19__srl5_n_0_b3b8abd = recovered_29_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__1__srl5_a1df094
  reg [15:0] recovered_30_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_30_shift <= {recovered_30_shift[14:0],esc_q_reg_63__0_b4ed0ea [1]};
  assign esc_mem_reg_4__1__srl5_n_0_24313a5 = recovered_30_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__20__srl5_5e430ee
  reg [15:0] recovered_31_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_31_shift <= {recovered_31_shift[14:0],esc_q_reg_63__0_b4ed0ea [20]};
  assign esc_mem_reg_4__20__srl5_n_0_a7cb185 = recovered_31_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__21__srl5_a7fe488
  reg [15:0] recovered_32_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_32_shift <= {recovered_32_shift[14:0],esc_q_reg_63__0_b4ed0ea [21]};
  assign esc_mem_reg_4__21__srl5_n_0_1133f48 = recovered_32_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__22__srl5_9662068
  reg [15:0] recovered_33_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_33_shift <= {recovered_33_shift[14:0],esc_q_reg_63__0_b4ed0ea [22]};
  assign esc_mem_reg_4__22__srl5_n_0_9fdb6b1 = recovered_33_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__23__srl5_de85f0c
  reg [15:0] recovered_34_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_34_shift <= {recovered_34_shift[14:0],esc_q_reg_63__0_b4ed0ea [23]};
  assign esc_mem_reg_4__23__srl5_n_0_d387627 = recovered_34_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__24__srl5_ccf8771
  reg [15:0] recovered_35_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_35_shift <= {recovered_35_shift[14:0],esc_q_reg_63__0_b4ed0ea [24]};
  assign esc_mem_reg_4__24__srl5_n_0_113f629 = recovered_35_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__25__srl5_1be6e34
  reg [15:0] recovered_36_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_36_shift <= {recovered_36_shift[14:0],esc_q_reg_63__0_b4ed0ea [25]};
  assign esc_mem_reg_4__25__srl5_n_0_c2ea529 = recovered_36_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__26__srl5_a8d2dd2
  reg [15:0] recovered_37_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_37_shift <= {recovered_37_shift[14:0],esc_q_reg_63__0_b4ed0ea [26]};
  assign esc_mem_reg_4__26__srl5_n_0_58cac40 = recovered_37_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__27__srl5_64f0d4b
  reg [15:0] recovered_38_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_38_shift <= {recovered_38_shift[14:0],esc_q_reg_63__0_b4ed0ea [27]};
  assign esc_mem_reg_4__27__srl5_n_0_724e83a = recovered_38_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__28__srl5_929699a
  reg [15:0] recovered_39_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_39_shift <= {recovered_39_shift[14:0],esc_q_reg_63__0_b4ed0ea [28]};
  assign esc_mem_reg_4__28__srl5_n_0_b25f46a = recovered_39_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__29__srl5_da0de23
  reg [15:0] recovered_40_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_40_shift <= {recovered_40_shift[14:0],esc_q_reg_63__0_b4ed0ea [29]};
  assign esc_mem_reg_4__29__srl5_n_0_56756af = recovered_40_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__2__srl5_4e9d0ad
  reg [15:0] recovered_41_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_41_shift <= {recovered_41_shift[14:0],esc_q_reg_63__0_b4ed0ea [2]};
  assign esc_mem_reg_4__2__srl5_n_0_f2676c6 = recovered_41_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__30__srl5_3848602
  reg [15:0] recovered_42_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_42_shift <= {recovered_42_shift[14:0],esc_q_reg_63__0_b4ed0ea [30]};
  assign esc_mem_reg_4__30__srl5_n_0_2b5eac6 = recovered_42_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__31__srl5_87ad1a5
  reg [15:0] recovered_43_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_43_shift <= {recovered_43_shift[14:0],esc_q_reg_63__0_b4ed0ea [31]};
  assign esc_mem_reg_4__31__srl5_n_0_163765c = recovered_43_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__32__srl5_0c7b907
  reg [15:0] recovered_44_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_44_shift <= {recovered_44_shift[14:0],esc_q_reg_63__0_b4ed0ea [32]};
  assign esc_mem_reg_4__32__srl5_n_0_7f3a683 = recovered_44_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__33__srl5_61c4ecd
  reg [15:0] recovered_45_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_45_shift <= {recovered_45_shift[14:0],esc_q_reg_63__0_b4ed0ea [33]};
  assign esc_mem_reg_4__33__srl5_n_0_c4d4bcb = recovered_45_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__34__srl5_7762b87
  reg [15:0] recovered_46_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_46_shift <= {recovered_46_shift[14:0],esc_q_reg_63__0_b4ed0ea [34]};
  assign esc_mem_reg_4__34__srl5_n_0_e917cf0 = recovered_46_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__35__srl5_888eace
  reg [15:0] recovered_47_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_47_shift <= {recovered_47_shift[14:0],esc_q_reg_63__0_b4ed0ea [35]};
  assign esc_mem_reg_4__35__srl5_n_0_d7054c7 = recovered_47_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__36__srl5_3f1efb9
  reg [15:0] recovered_48_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_48_shift <= {recovered_48_shift[14:0],esc_q_reg_63__0_b4ed0ea [36]};
  assign esc_mem_reg_4__36__srl5_n_0_8180ba4 = recovered_48_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__37__srl5_76d2ff9
  reg [15:0] recovered_49_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_49_shift <= {recovered_49_shift[14:0],esc_q_reg_63__0_b4ed0ea [37]};
  assign esc_mem_reg_4__37__srl5_n_0_e31fe08 = recovered_49_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__38__srl5_7d7f232
  reg [15:0] recovered_50_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_50_shift <= {recovered_50_shift[14:0],esc_q_reg_63__0_b4ed0ea [38]};
  assign esc_mem_reg_4__38__srl5_n_0_15d7c61 = recovered_50_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__39__srl5_fb392c1
  reg [15:0] recovered_51_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_51_shift <= {recovered_51_shift[14:0],esc_q_reg_63__0_b4ed0ea [39]};
  assign esc_mem_reg_4__39__srl5_n_0_aed7ba4 = recovered_51_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__3__srl5_8321240
  reg [15:0] recovered_52_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_52_shift <= {recovered_52_shift[14:0],esc_q_reg_63__0_b4ed0ea [3]};
  assign esc_mem_reg_4__3__srl5_n_0_2b51a08 = recovered_52_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__40__srl5_1c69807
  reg [15:0] recovered_53_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_53_shift <= {recovered_53_shift[14:0],esc_q_reg_63__0_b4ed0ea [40]};
  assign esc_mem_reg_4__40__srl5_n_0_8d2fc8b = recovered_53_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__41__srl5_ff76a4b
  reg [15:0] recovered_54_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_54_shift <= {recovered_54_shift[14:0],esc_q_reg_63__0_b4ed0ea [41]};
  assign esc_mem_reg_4__41__srl5_n_0_43f2c18 = recovered_54_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__42__srl5_210cc13
  reg [15:0] recovered_55_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_55_shift <= {recovered_55_shift[14:0],esc_q_reg_63__0_b4ed0ea [42]};
  assign esc_mem_reg_4__42__srl5_n_0_5068a2c = recovered_55_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__43__srl5_f733580
  reg [15:0] recovered_56_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_56_shift <= {recovered_56_shift[14:0],esc_q_reg_63__0_b4ed0ea [43]};
  assign esc_mem_reg_4__43__srl5_n_0_2ccfd64 = recovered_56_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__44__srl5_f55536e
  reg [15:0] recovered_57_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_57_shift <= {recovered_57_shift[14:0],esc_q_reg_63__0_b4ed0ea [44]};
  assign esc_mem_reg_4__44__srl5_n_0_81605ce = recovered_57_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__45__srl5_1c2c42c
  reg [15:0] recovered_58_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_58_shift <= {recovered_58_shift[14:0],esc_q_reg_63__0_b4ed0ea [45]};
  assign esc_mem_reg_4__45__srl5_n_0_ca3fe15 = recovered_58_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__46__srl5_d1ae599
  reg [15:0] recovered_59_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_59_shift <= {recovered_59_shift[14:0],esc_q_reg_63__0_b4ed0ea [46]};
  assign esc_mem_reg_4__46__srl5_n_0_d1bde41 = recovered_59_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__47__srl5_9f168bd
  reg [15:0] recovered_60_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_60_shift <= {recovered_60_shift[14:0],esc_q_reg_63__0_b4ed0ea [47]};
  assign esc_mem_reg_4__47__srl5_n_0_812a5e0 = recovered_60_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__48__srl5_5976007
  reg [15:0] recovered_61_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_61_shift <= {recovered_61_shift[14:0],esc_q_reg_63__0_b4ed0ea [48]};
  assign esc_mem_reg_4__48__srl5_n_0_15ce78c = recovered_61_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__49__srl5_7b88999
  reg [15:0] recovered_62_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_62_shift <= {recovered_62_shift[14:0],esc_q_reg_63__0_b4ed0ea [49]};
  assign esc_mem_reg_4__49__srl5_n_0_879ca8b = recovered_62_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__4__srl5_21c51a5
  reg [15:0] recovered_63_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_63_shift <= {recovered_63_shift[14:0],esc_q_reg_63__0_b4ed0ea [4]};
  assign esc_mem_reg_4__4__srl5_n_0_9ac6433 = recovered_63_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__50__srl5_1fdc800
  reg [15:0] recovered_64_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_64_shift <= {recovered_64_shift[14:0],esc_q_reg_63__0_b4ed0ea [50]};
  assign esc_mem_reg_4__50__srl5_n_0_1085b2a = recovered_64_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__51__srl5_155679b
  reg [15:0] recovered_65_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_65_shift <= {recovered_65_shift[14:0],esc_q_reg_63__0_b4ed0ea [51]};
  assign esc_mem_reg_4__51__srl5_n_0_074a965 = recovered_65_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__52__srl5_3763c35
  reg [15:0] recovered_66_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_66_shift <= {recovered_66_shift[14:0],esc_q_reg_63__0_b4ed0ea [52]};
  assign esc_mem_reg_4__52__srl5_n_0_1c3bad9 = recovered_66_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__53__srl5_140b83d
  reg [15:0] recovered_67_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_67_shift <= {recovered_67_shift[14:0],esc_q_reg_63__0_b4ed0ea [53]};
  assign esc_mem_reg_4__53__srl5_n_0_10fdae5 = recovered_67_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__54__srl5_e85f7cf
  reg [15:0] recovered_68_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_68_shift <= {recovered_68_shift[14:0],esc_q_reg_63__0_b4ed0ea [54]};
  assign esc_mem_reg_4__54__srl5_n_0_d87cca8 = recovered_68_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__55__srl5_7ed984a
  reg [15:0] recovered_69_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_69_shift <= {recovered_69_shift[14:0],esc_q_reg_63__0_b4ed0ea [55]};
  assign esc_mem_reg_4__55__srl5_n_0_f34d6be = recovered_69_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__56__srl5_414fa77
  reg [15:0] recovered_70_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_70_shift <= {recovered_70_shift[14:0],esc_q_reg_63__0_b4ed0ea [56]};
  assign esc_mem_reg_4__56__srl5_n_0_ff79cb7 = recovered_70_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__57__srl5_103b679
  reg [15:0] recovered_71_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_71_shift <= {recovered_71_shift[14:0],esc_q_reg_63__0_b4ed0ea [57]};
  assign esc_mem_reg_4__57__srl5_n_0_6945ac8 = recovered_71_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__58__srl5_a09f4ec
  reg [15:0] recovered_72_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_72_shift <= {recovered_72_shift[14:0],esc_q_reg_63__0_b4ed0ea [58]};
  assign esc_mem_reg_4__58__srl5_n_0_0ceb6fa = recovered_72_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__59__srl5_29230e4
  reg [15:0] recovered_73_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_73_shift <= {recovered_73_shift[14:0],esc_q_reg_63__0_b4ed0ea [59]};
  assign esc_mem_reg_4__59__srl5_n_0_818a395 = recovered_73_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__5__srl5_ba611f2
  reg [15:0] recovered_74_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_74_shift <= {recovered_74_shift[14:0],esc_q_reg_63__0_b4ed0ea [5]};
  assign esc_mem_reg_4__5__srl5_n_0_843e618 = recovered_74_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__60__srl5_099be26
  reg [15:0] recovered_75_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_75_shift <= {recovered_75_shift[14:0],esc_q_reg_63__0_b4ed0ea [60]};
  assign esc_mem_reg_4__60__srl5_n_0_783d111 = recovered_75_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__61__srl5_1c20ffc
  reg [15:0] recovered_76_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_76_shift <= {recovered_76_shift[14:0],esc_q_reg_63__0_b4ed0ea [61]};
  assign esc_mem_reg_4__61__srl5_n_0_7362482 = recovered_76_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__62__srl5_eb15ff7
  reg [15:0] recovered_77_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_77_shift <= {recovered_77_shift[14:0],esc_q_reg_63__0_b4ed0ea [62]};
  assign esc_mem_reg_4__62__srl5_n_0_aca8eb1 = recovered_77_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__63__srl5_637d8c8
  reg [15:0] recovered_78_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_78_shift <= {recovered_78_shift[14:0],esc_q_reg_63__0_b4ed0ea [63]};
  assign esc_mem_reg_4__63__srl5_n_0_27eb226 = recovered_78_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__6__srl5_02f549d
  reg [15:0] recovered_79_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_79_shift <= {recovered_79_shift[14:0],esc_q_reg_63__0_b4ed0ea [6]};
  assign esc_mem_reg_4__6__srl5_n_0_b2b44f9 = recovered_79_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__74__srl5_4e8ac0b
  reg [15:0] recovered_80_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_80_shift <= {recovered_80_shift[14:0],esc_const1_c064970};
  assign esc_mem_reg_4__74__srl5_n_0_2d74fec = recovered_80_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__75__srl5_d253f0a
  reg [15:0] recovered_81_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_81_shift <= {recovered_81_shift[14:0],esc_const1_c064970};
  assign esc_mem_reg_4__75__srl5_n_0_f1a7b3e = recovered_81_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__77__srl5_fee4edd
  reg [15:0] recovered_82_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_82_shift <= {recovered_82_shift[14:0],esc_const1_c064970};
  assign esc_mem_reg_4__77__srl5_n_0_4a4f8ac = recovered_82_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__7__srl5_4dabe5a
  reg [15:0] recovered_83_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_83_shift <= {recovered_83_shift[14:0],esc_q_reg_63__0_b4ed0ea [7]};
  assign esc_mem_reg_4__7__srl5_n_0_c57737b = recovered_83_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__80__srl5_465769d
  reg [15:0] recovered_84_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_84_shift <= {recovered_84_shift[14:0],esc_const1_c064970};
  assign esc_mem_reg_4__80__srl5_n_0_d3a98e4 = recovered_84_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__8__srl5_7729bfd
  reg [15:0] recovered_85_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_85_shift <= {recovered_85_shift[14:0],esc_q_reg_63__0_b4ed0ea [8]};
  assign esc_mem_reg_4__8__srl5_n_0_2bf3955 = recovered_85_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__9__srl5_35a0c21
  reg [15:0] recovered_86_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_86_shift <= {recovered_86_shift[14:0],esc_q_reg_63__0_b4ed0ea [9]};
  assign esc_mem_reg_4__9__srl5_n_0_bab496c = recovered_86_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed LUT6: esc_pout_0__i_1_729e482
  assign esc_pout_0__i_1_n_0_c71edc2 = ((esc_pout_reg_n_0__0_31a13ed) ? (((data_vld_reg_n_0) ? (((pop0) ? (push) : (~(push)))) : (1'b1))) : (((esc_pout_reg_n_0__2_3685eef) ? (((data_vld_reg_n_0) ? (((pop0) ? (~(push)) : (push))) : (1'b0))) : (((esc_pout_reg_n_0__1_307d4bf) ? (((data_vld_reg_n_0) ? (((pop0) ? (~(push)) : (push))) : (1'b0))) : (((data_vld_reg_n_0) ? (((pop0) ? (1'b0) : (push))) : (1'b0))))))));

  // Reconstructed LUT6: esc_pout_1__i_1_d213e77
  assign esc_pout_1__i_1_n_0_77ba36c = ((push) ? (((pop0) ? (esc_pout_reg_n_0__1_307d4bf) : (((data_vld_reg_n_0) ? (((esc_pout_reg_n_0__0_31a13ed) ? (~(esc_pout_reg_n_0__1_307d4bf)) : (esc_pout_reg_n_0__1_307d4bf))) : (esc_pout_reg_n_0__1_307d4bf))))) : (((pop0) ? (((data_vld_reg_n_0) ? (((esc_pout_reg_n_0__0_31a13ed) ? (esc_pout_reg_n_0__1_307d4bf) : (((esc_pout_reg_n_0__1_307d4bf) ? (1'b0) : (esc_pout_reg_n_0__2_3685eef))))) : (esc_pout_reg_n_0__1_307d4bf))) : (esc_pout_reg_n_0__1_307d4bf))));

  // Reconstructed LUT6: esc_pout_2__i_1_9909dbc
  assign esc_pout_2__i_1_n_0_bcda194 = ((push) ? (((pop0) ? (esc_pout_reg_n_0__2_3685eef) : (((data_vld_reg_n_0) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((esc_pout_reg_n_0__1_307d4bf) ? (~(esc_pout_reg_n_0__2_3685eef)) : (esc_pout_reg_n_0__2_3685eef))) : (esc_pout_reg_n_0__2_3685eef))) : (esc_pout_reg_n_0__2_3685eef))))) : (((pop0) ? (((data_vld_reg_n_0) ? (((esc_pout_reg_n_0__0_31a13ed) ? (esc_pout_reg_n_0__2_3685eef) : (((esc_pout_reg_n_0__1_307d4bf) ? (esc_pout_reg_n_0__2_3685eef) : (1'b0))))) : (esc_pout_reg_n_0__2_3685eef))) : (esc_pout_reg_n_0__2_3685eef))));

  // Reconstructed FDRE: esc_pout_reg_0_cd95a63
  reg recovered_90_q = 1'b0;
  assign esc_pout_reg_n_0__0_31a13ed = recovered_90_q;
  wire recovered_90_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_90_reset || (((SR) === 1'bx) && (recovered_90_q == 1'b0))) recovered_90_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_90_q == (esc_pout_0__i_1_n_0_c71edc2)))) recovered_90_q <= (esc_pout_0__i_1_n_0_c71edc2);
  end

  // Reconstructed FDRE: esc_pout_reg_1_325167f
  reg recovered_91_q = 1'b0;
  assign esc_pout_reg_n_0__1_307d4bf = recovered_91_q;
  wire recovered_91_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_91_reset || (((SR) === 1'bx) && (recovered_91_q == 1'b0))) recovered_91_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_91_q == (esc_pout_1__i_1_n_0_77ba36c)))) recovered_91_q <= (esc_pout_1__i_1_n_0_77ba36c);
  end

  // Reconstructed FDRE: esc_pout_reg_2_3108b14
  reg recovered_92_q = 1'b0;
  assign esc_pout_reg_n_0__2_3685eef = recovered_92_q;
  wire recovered_92_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_92_reset || (((SR) === 1'bx) && (recovered_92_q == 1'b0))) recovered_92_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_92_q == (esc_pout_2__i_1_n_0_bcda194)))) recovered_92_q <= (esc_pout_2__i_1_n_0_bcda194);
  end

  // Reconstructed FDRE: esc_q_reg_0_02a935c
  reg recovered_93_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [0] = recovered_93_q;
  wire recovered_93_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_93_reset || (((SR) === 1'bx) && (recovered_93_q == 1'b0))) recovered_93_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_93_q == (esc_mem_reg_4__0__srl5_n_0_5b87500)))) recovered_93_q <= (esc_mem_reg_4__0__srl5_n_0_5b87500);
  end

  // Reconstructed FDRE: esc_q_reg_10_11878f1
  reg recovered_94_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [10] = recovered_94_q;
  wire recovered_94_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_94_reset || (((SR) === 1'bx) && (recovered_94_q == 1'b0))) recovered_94_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_94_q == (esc_mem_reg_4__10__srl5_n_0_e247105)))) recovered_94_q <= (esc_mem_reg_4__10__srl5_n_0_e247105);
  end

  // Reconstructed FDRE: esc_q_reg_11_f6a1408
  reg recovered_95_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [11] = recovered_95_q;
  wire recovered_95_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_95_reset || (((SR) === 1'bx) && (recovered_95_q == 1'b0))) recovered_95_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_95_q == (esc_mem_reg_4__11__srl5_n_0_27bf80c)))) recovered_95_q <= (esc_mem_reg_4__11__srl5_n_0_27bf80c);
  end

  // Reconstructed FDRE: esc_q_reg_12_9a3857c
  reg recovered_96_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [12] = recovered_96_q;
  wire recovered_96_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_96_reset || (((SR) === 1'bx) && (recovered_96_q == 1'b0))) recovered_96_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_96_q == (esc_mem_reg_4__12__srl5_n_0_997a3d0)))) recovered_96_q <= (esc_mem_reg_4__12__srl5_n_0_997a3d0);
  end

  // Reconstructed FDRE: esc_q_reg_13_d9e0bb6
  reg recovered_97_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [13] = recovered_97_q;
  wire recovered_97_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_97_reset || (((SR) === 1'bx) && (recovered_97_q == 1'b0))) recovered_97_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_97_q == (esc_mem_reg_4__13__srl5_n_0_c14c677)))) recovered_97_q <= (esc_mem_reg_4__13__srl5_n_0_c14c677);
  end

  // Reconstructed FDRE: esc_q_reg_14_318a5ee
  reg recovered_98_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [14] = recovered_98_q;
  wire recovered_98_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_98_reset || (((SR) === 1'bx) && (recovered_98_q == 1'b0))) recovered_98_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_98_q == (esc_mem_reg_4__14__srl5_n_0_b5761f7)))) recovered_98_q <= (esc_mem_reg_4__14__srl5_n_0_b5761f7);
  end

  // Reconstructed FDRE: esc_q_reg_15_e009494
  reg recovered_99_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [15] = recovered_99_q;
  wire recovered_99_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_99_reset || (((SR) === 1'bx) && (recovered_99_q == 1'b0))) recovered_99_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_99_q == (esc_mem_reg_4__15__srl5_n_0_76b0ea7)))) recovered_99_q <= (esc_mem_reg_4__15__srl5_n_0_76b0ea7);
  end

  // Reconstructed FDRE: esc_q_reg_16_7ece9ed
  reg recovered_100_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [16] = recovered_100_q;
  wire recovered_100_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_100_reset || (((SR) === 1'bx) && (recovered_100_q == 1'b0))) recovered_100_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_100_q == (esc_mem_reg_4__16__srl5_n_0_3ede415)))) recovered_100_q <= (esc_mem_reg_4__16__srl5_n_0_3ede415);
  end

  // Reconstructed FDRE: esc_q_reg_17_cc914c6
  reg recovered_101_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [17] = recovered_101_q;
  wire recovered_101_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_101_reset || (((SR) === 1'bx) && (recovered_101_q == 1'b0))) recovered_101_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_101_q == (esc_mem_reg_4__17__srl5_n_0_223dae8)))) recovered_101_q <= (esc_mem_reg_4__17__srl5_n_0_223dae8);
  end

  // Reconstructed FDRE: esc_q_reg_18_17eea42
  reg recovered_102_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [18] = recovered_102_q;
  wire recovered_102_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_102_reset || (((SR) === 1'bx) && (recovered_102_q == 1'b0))) recovered_102_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_102_q == (esc_mem_reg_4__18__srl5_n_0_0039e45)))) recovered_102_q <= (esc_mem_reg_4__18__srl5_n_0_0039e45);
  end

  // Reconstructed FDRE: esc_q_reg_19_dda1a6d
  reg recovered_103_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [19] = recovered_103_q;
  wire recovered_103_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_103_reset || (((SR) === 1'bx) && (recovered_103_q == 1'b0))) recovered_103_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_103_q == (esc_mem_reg_4__19__srl5_n_0_b3b8abd)))) recovered_103_q <= (esc_mem_reg_4__19__srl5_n_0_b3b8abd);
  end

  // Reconstructed FDRE: esc_q_reg_1_2d13bdc
  reg recovered_104_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [1] = recovered_104_q;
  wire recovered_104_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_104_reset || (((SR) === 1'bx) && (recovered_104_q == 1'b0))) recovered_104_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_104_q == (esc_mem_reg_4__1__srl5_n_0_24313a5)))) recovered_104_q <= (esc_mem_reg_4__1__srl5_n_0_24313a5);
  end

  // Reconstructed FDRE: esc_q_reg_20_afca079
  reg recovered_105_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [20] = recovered_105_q;
  wire recovered_105_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_105_reset || (((SR) === 1'bx) && (recovered_105_q == 1'b0))) recovered_105_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_105_q == (esc_mem_reg_4__20__srl5_n_0_a7cb185)))) recovered_105_q <= (esc_mem_reg_4__20__srl5_n_0_a7cb185);
  end

  // Reconstructed FDRE: esc_q_reg_21_68af605
  reg recovered_106_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [21] = recovered_106_q;
  wire recovered_106_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_106_reset || (((SR) === 1'bx) && (recovered_106_q == 1'b0))) recovered_106_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_106_q == (esc_mem_reg_4__21__srl5_n_0_1133f48)))) recovered_106_q <= (esc_mem_reg_4__21__srl5_n_0_1133f48);
  end

  // Reconstructed FDRE: esc_q_reg_22_28bf575
  reg recovered_107_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [22] = recovered_107_q;
  wire recovered_107_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_107_reset || (((SR) === 1'bx) && (recovered_107_q == 1'b0))) recovered_107_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_107_q == (esc_mem_reg_4__22__srl5_n_0_9fdb6b1)))) recovered_107_q <= (esc_mem_reg_4__22__srl5_n_0_9fdb6b1);
  end

  // Reconstructed FDRE: esc_q_reg_23_86d6c20
  reg recovered_108_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [23] = recovered_108_q;
  wire recovered_108_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_108_reset || (((SR) === 1'bx) && (recovered_108_q == 1'b0))) recovered_108_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_108_q == (esc_mem_reg_4__23__srl5_n_0_d387627)))) recovered_108_q <= (esc_mem_reg_4__23__srl5_n_0_d387627);
  end

  // Reconstructed FDRE: esc_q_reg_24_472a3b8
  reg recovered_109_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [24] = recovered_109_q;
  wire recovered_109_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_109_reset || (((SR) === 1'bx) && (recovered_109_q == 1'b0))) recovered_109_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_109_q == (esc_mem_reg_4__24__srl5_n_0_113f629)))) recovered_109_q <= (esc_mem_reg_4__24__srl5_n_0_113f629);
  end

  // Reconstructed FDRE: esc_q_reg_25_f6017d4
  reg recovered_110_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [25] = recovered_110_q;
  wire recovered_110_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_110_reset || (((SR) === 1'bx) && (recovered_110_q == 1'b0))) recovered_110_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_110_q == (esc_mem_reg_4__25__srl5_n_0_c2ea529)))) recovered_110_q <= (esc_mem_reg_4__25__srl5_n_0_c2ea529);
  end

  // Reconstructed FDRE: esc_q_reg_26_458b137
  reg recovered_111_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [26] = recovered_111_q;
  wire recovered_111_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_111_reset || (((SR) === 1'bx) && (recovered_111_q == 1'b0))) recovered_111_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_111_q == (esc_mem_reg_4__26__srl5_n_0_58cac40)))) recovered_111_q <= (esc_mem_reg_4__26__srl5_n_0_58cac40);
  end

  // Reconstructed FDRE: esc_q_reg_27_ab04e4c
  reg recovered_112_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [27] = recovered_112_q;
  wire recovered_112_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_112_reset || (((SR) === 1'bx) && (recovered_112_q == 1'b0))) recovered_112_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_112_q == (esc_mem_reg_4__27__srl5_n_0_724e83a)))) recovered_112_q <= (esc_mem_reg_4__27__srl5_n_0_724e83a);
  end

  // Reconstructed FDRE: esc_q_reg_28_bec0646
  reg recovered_113_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [28] = recovered_113_q;
  wire recovered_113_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_113_reset || (((SR) === 1'bx) && (recovered_113_q == 1'b0))) recovered_113_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_113_q == (esc_mem_reg_4__28__srl5_n_0_b25f46a)))) recovered_113_q <= (esc_mem_reg_4__28__srl5_n_0_b25f46a);
  end

  // Reconstructed FDRE: esc_q_reg_29_8d713f6
  reg recovered_114_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [29] = recovered_114_q;
  wire recovered_114_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_114_reset || (((SR) === 1'bx) && (recovered_114_q == 1'b0))) recovered_114_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_114_q == (esc_mem_reg_4__29__srl5_n_0_56756af)))) recovered_114_q <= (esc_mem_reg_4__29__srl5_n_0_56756af);
  end

  // Reconstructed FDRE: esc_q_reg_2_5a064fe
  reg recovered_115_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [2] = recovered_115_q;
  wire recovered_115_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_115_reset || (((SR) === 1'bx) && (recovered_115_q == 1'b0))) recovered_115_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_115_q == (esc_mem_reg_4__2__srl5_n_0_f2676c6)))) recovered_115_q <= (esc_mem_reg_4__2__srl5_n_0_f2676c6);
  end

  // Reconstructed FDRE: esc_q_reg_30_a086ab3
  reg recovered_116_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [30] = recovered_116_q;
  wire recovered_116_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_116_reset || (((SR) === 1'bx) && (recovered_116_q == 1'b0))) recovered_116_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_116_q == (esc_mem_reg_4__30__srl5_n_0_2b5eac6)))) recovered_116_q <= (esc_mem_reg_4__30__srl5_n_0_2b5eac6);
  end

  // Reconstructed FDRE: esc_q_reg_31_45eeab8
  reg recovered_117_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [31] = recovered_117_q;
  wire recovered_117_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_117_reset || (((SR) === 1'bx) && (recovered_117_q == 1'b0))) recovered_117_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_117_q == (esc_mem_reg_4__31__srl5_n_0_163765c)))) recovered_117_q <= (esc_mem_reg_4__31__srl5_n_0_163765c);
  end

  // Reconstructed FDRE: esc_q_reg_32_bf913d9
  reg recovered_118_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [32] = recovered_118_q;
  wire recovered_118_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_118_reset || (((SR) === 1'bx) && (recovered_118_q == 1'b0))) recovered_118_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_118_q == (esc_mem_reg_4__32__srl5_n_0_7f3a683)))) recovered_118_q <= (esc_mem_reg_4__32__srl5_n_0_7f3a683);
  end

  // Reconstructed FDRE: esc_q_reg_33_df23a43
  reg recovered_119_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [33] = recovered_119_q;
  wire recovered_119_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_119_reset || (((SR) === 1'bx) && (recovered_119_q == 1'b0))) recovered_119_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_119_q == (esc_mem_reg_4__33__srl5_n_0_c4d4bcb)))) recovered_119_q <= (esc_mem_reg_4__33__srl5_n_0_c4d4bcb);
  end

  // Reconstructed FDRE: esc_q_reg_34_64f4f4f
  reg recovered_120_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [34] = recovered_120_q;
  wire recovered_120_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_120_reset || (((SR) === 1'bx) && (recovered_120_q == 1'b0))) recovered_120_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_120_q == (esc_mem_reg_4__34__srl5_n_0_e917cf0)))) recovered_120_q <= (esc_mem_reg_4__34__srl5_n_0_e917cf0);
  end

  // Reconstructed FDRE: esc_q_reg_35_744539d
  reg recovered_121_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [35] = recovered_121_q;
  wire recovered_121_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_121_reset || (((SR) === 1'bx) && (recovered_121_q == 1'b0))) recovered_121_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_121_q == (esc_mem_reg_4__35__srl5_n_0_d7054c7)))) recovered_121_q <= (esc_mem_reg_4__35__srl5_n_0_d7054c7);
  end

  // Reconstructed FDRE: esc_q_reg_36_32ef392
  reg recovered_122_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [36] = recovered_122_q;
  wire recovered_122_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_122_reset || (((SR) === 1'bx) && (recovered_122_q == 1'b0))) recovered_122_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_122_q == (esc_mem_reg_4__36__srl5_n_0_8180ba4)))) recovered_122_q <= (esc_mem_reg_4__36__srl5_n_0_8180ba4);
  end

  // Reconstructed FDRE: esc_q_reg_37_29c58b0
  reg recovered_123_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [37] = recovered_123_q;
  wire recovered_123_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_123_reset || (((SR) === 1'bx) && (recovered_123_q == 1'b0))) recovered_123_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_123_q == (esc_mem_reg_4__37__srl5_n_0_e31fe08)))) recovered_123_q <= (esc_mem_reg_4__37__srl5_n_0_e31fe08);
  end

  // Reconstructed FDRE: esc_q_reg_38_7a6baae
  reg recovered_124_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [38] = recovered_124_q;
  wire recovered_124_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_124_reset || (((SR) === 1'bx) && (recovered_124_q == 1'b0))) recovered_124_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_124_q == (esc_mem_reg_4__38__srl5_n_0_15d7c61)))) recovered_124_q <= (esc_mem_reg_4__38__srl5_n_0_15d7c61);
  end

  // Reconstructed FDRE: esc_q_reg_39_c419345
  reg recovered_125_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [39] = recovered_125_q;
  wire recovered_125_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_125_reset || (((SR) === 1'bx) && (recovered_125_q == 1'b0))) recovered_125_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_125_q == (esc_mem_reg_4__39__srl5_n_0_aed7ba4)))) recovered_125_q <= (esc_mem_reg_4__39__srl5_n_0_aed7ba4);
  end

  // Reconstructed FDRE: esc_q_reg_3_e0a3a92
  reg recovered_126_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [3] = recovered_126_q;
  wire recovered_126_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_126_reset || (((SR) === 1'bx) && (recovered_126_q == 1'b0))) recovered_126_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_126_q == (esc_mem_reg_4__3__srl5_n_0_2b51a08)))) recovered_126_q <= (esc_mem_reg_4__3__srl5_n_0_2b51a08);
  end

  // Reconstructed FDRE: esc_q_reg_40_a809484
  reg recovered_127_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [40] = recovered_127_q;
  wire recovered_127_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_127_reset || (((SR) === 1'bx) && (recovered_127_q == 1'b0))) recovered_127_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_127_q == (esc_mem_reg_4__40__srl5_n_0_8d2fc8b)))) recovered_127_q <= (esc_mem_reg_4__40__srl5_n_0_8d2fc8b);
  end

  // Reconstructed FDRE: esc_q_reg_41_498b0b4
  reg recovered_128_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [41] = recovered_128_q;
  wire recovered_128_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_128_reset || (((SR) === 1'bx) && (recovered_128_q == 1'b0))) recovered_128_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_128_q == (esc_mem_reg_4__41__srl5_n_0_43f2c18)))) recovered_128_q <= (esc_mem_reg_4__41__srl5_n_0_43f2c18);
  end

  // Reconstructed FDRE: esc_q_reg_42_e8d4492
  reg recovered_129_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [42] = recovered_129_q;
  wire recovered_129_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_129_reset || (((SR) === 1'bx) && (recovered_129_q == 1'b0))) recovered_129_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_129_q == (esc_mem_reg_4__42__srl5_n_0_5068a2c)))) recovered_129_q <= (esc_mem_reg_4__42__srl5_n_0_5068a2c);
  end

  // Reconstructed FDRE: esc_q_reg_43_97f880f
  reg recovered_130_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [43] = recovered_130_q;
  wire recovered_130_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_130_reset || (((SR) === 1'bx) && (recovered_130_q == 1'b0))) recovered_130_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_130_q == (esc_mem_reg_4__43__srl5_n_0_2ccfd64)))) recovered_130_q <= (esc_mem_reg_4__43__srl5_n_0_2ccfd64);
  end

  // Reconstructed FDRE: esc_q_reg_44_570ffb8
  reg recovered_131_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [44] = recovered_131_q;
  wire recovered_131_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_131_reset || (((SR) === 1'bx) && (recovered_131_q == 1'b0))) recovered_131_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_131_q == (esc_mem_reg_4__44__srl5_n_0_81605ce)))) recovered_131_q <= (esc_mem_reg_4__44__srl5_n_0_81605ce);
  end

  // Reconstructed FDRE: esc_q_reg_45_51c818a
  reg recovered_132_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [45] = recovered_132_q;
  wire recovered_132_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_132_reset || (((SR) === 1'bx) && (recovered_132_q == 1'b0))) recovered_132_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_132_q == (esc_mem_reg_4__45__srl5_n_0_ca3fe15)))) recovered_132_q <= (esc_mem_reg_4__45__srl5_n_0_ca3fe15);
  end

  // Reconstructed FDRE: esc_q_reg_46_5fd0a21
  reg recovered_133_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [46] = recovered_133_q;
  wire recovered_133_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_133_reset || (((SR) === 1'bx) && (recovered_133_q == 1'b0))) recovered_133_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_133_q == (esc_mem_reg_4__46__srl5_n_0_d1bde41)))) recovered_133_q <= (esc_mem_reg_4__46__srl5_n_0_d1bde41);
  end

  // Reconstructed FDRE: esc_q_reg_47_e20ed3d
  reg recovered_134_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [47] = recovered_134_q;
  wire recovered_134_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_134_reset || (((SR) === 1'bx) && (recovered_134_q == 1'b0))) recovered_134_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_134_q == (esc_mem_reg_4__47__srl5_n_0_812a5e0)))) recovered_134_q <= (esc_mem_reg_4__47__srl5_n_0_812a5e0);
  end

  // Reconstructed FDRE: esc_q_reg_48_6567581
  reg recovered_135_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [48] = recovered_135_q;
  wire recovered_135_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_135_reset || (((SR) === 1'bx) && (recovered_135_q == 1'b0))) recovered_135_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_135_q == (esc_mem_reg_4__48__srl5_n_0_15ce78c)))) recovered_135_q <= (esc_mem_reg_4__48__srl5_n_0_15ce78c);
  end

  // Reconstructed FDRE: esc_q_reg_49_87e3434
  reg recovered_136_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [49] = recovered_136_q;
  wire recovered_136_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_136_reset || (((SR) === 1'bx) && (recovered_136_q == 1'b0))) recovered_136_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_136_q == (esc_mem_reg_4__49__srl5_n_0_879ca8b)))) recovered_136_q <= (esc_mem_reg_4__49__srl5_n_0_879ca8b);
  end

  // Reconstructed FDRE: esc_q_reg_4_8d11328
  reg recovered_137_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [4] = recovered_137_q;
  wire recovered_137_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_137_reset || (((SR) === 1'bx) && (recovered_137_q == 1'b0))) recovered_137_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_137_q == (esc_mem_reg_4__4__srl5_n_0_9ac6433)))) recovered_137_q <= (esc_mem_reg_4__4__srl5_n_0_9ac6433);
  end

  // Reconstructed FDRE: esc_q_reg_50_0ef9e01
  reg recovered_138_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [50] = recovered_138_q;
  wire recovered_138_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_138_reset || (((SR) === 1'bx) && (recovered_138_q == 1'b0))) recovered_138_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_138_q == (esc_mem_reg_4__50__srl5_n_0_1085b2a)))) recovered_138_q <= (esc_mem_reg_4__50__srl5_n_0_1085b2a);
  end

  // Reconstructed FDRE: esc_q_reg_51_89442b3
  reg recovered_139_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [51] = recovered_139_q;
  wire recovered_139_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_139_reset || (((SR) === 1'bx) && (recovered_139_q == 1'b0))) recovered_139_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_139_q == (esc_mem_reg_4__51__srl5_n_0_074a965)))) recovered_139_q <= (esc_mem_reg_4__51__srl5_n_0_074a965);
  end

  // Reconstructed FDRE: esc_q_reg_52_4a1f9b6
  reg recovered_140_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [52] = recovered_140_q;
  wire recovered_140_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_140_reset || (((SR) === 1'bx) && (recovered_140_q == 1'b0))) recovered_140_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_140_q == (esc_mem_reg_4__52__srl5_n_0_1c3bad9)))) recovered_140_q <= (esc_mem_reg_4__52__srl5_n_0_1c3bad9);
  end

  // Reconstructed FDRE: esc_q_reg_53_00055e6
  reg recovered_141_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [53] = recovered_141_q;
  wire recovered_141_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_141_reset || (((SR) === 1'bx) && (recovered_141_q == 1'b0))) recovered_141_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_141_q == (esc_mem_reg_4__53__srl5_n_0_10fdae5)))) recovered_141_q <= (esc_mem_reg_4__53__srl5_n_0_10fdae5);
  end

  // Reconstructed FDRE: esc_q_reg_54_2c029c7
  reg recovered_142_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [54] = recovered_142_q;
  wire recovered_142_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_142_reset || (((SR) === 1'bx) && (recovered_142_q == 1'b0))) recovered_142_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_142_q == (esc_mem_reg_4__54__srl5_n_0_d87cca8)))) recovered_142_q <= (esc_mem_reg_4__54__srl5_n_0_d87cca8);
  end

  // Reconstructed FDRE: esc_q_reg_55_0772dfa
  reg recovered_143_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [55] = recovered_143_q;
  wire recovered_143_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_143_reset || (((SR) === 1'bx) && (recovered_143_q == 1'b0))) recovered_143_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_143_q == (esc_mem_reg_4__55__srl5_n_0_f34d6be)))) recovered_143_q <= (esc_mem_reg_4__55__srl5_n_0_f34d6be);
  end

  // Reconstructed FDRE: esc_q_reg_56_1bf8f39
  reg recovered_144_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [56] = recovered_144_q;
  wire recovered_144_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_144_reset || (((SR) === 1'bx) && (recovered_144_q == 1'b0))) recovered_144_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_144_q == (esc_mem_reg_4__56__srl5_n_0_ff79cb7)))) recovered_144_q <= (esc_mem_reg_4__56__srl5_n_0_ff79cb7);
  end

  // Reconstructed FDRE: esc_q_reg_57_943da1c
  reg recovered_145_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [57] = recovered_145_q;
  wire recovered_145_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_145_reset || (((SR) === 1'bx) && (recovered_145_q == 1'b0))) recovered_145_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_145_q == (esc_mem_reg_4__57__srl5_n_0_6945ac8)))) recovered_145_q <= (esc_mem_reg_4__57__srl5_n_0_6945ac8);
  end

  // Reconstructed FDRE: esc_q_reg_58_4b5adbb
  reg recovered_146_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [58] = recovered_146_q;
  wire recovered_146_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_146_reset || (((SR) === 1'bx) && (recovered_146_q == 1'b0))) recovered_146_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_146_q == (esc_mem_reg_4__58__srl5_n_0_0ceb6fa)))) recovered_146_q <= (esc_mem_reg_4__58__srl5_n_0_0ceb6fa);
  end

  // Reconstructed FDRE: esc_q_reg_59_e9de3ad
  reg recovered_147_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [59] = recovered_147_q;
  wire recovered_147_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_147_reset || (((SR) === 1'bx) && (recovered_147_q == 1'b0))) recovered_147_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_147_q == (esc_mem_reg_4__59__srl5_n_0_818a395)))) recovered_147_q <= (esc_mem_reg_4__59__srl5_n_0_818a395);
  end

  // Reconstructed FDRE: esc_q_reg_5_9e39b41
  reg recovered_148_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [5] = recovered_148_q;
  wire recovered_148_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_148_reset || (((SR) === 1'bx) && (recovered_148_q == 1'b0))) recovered_148_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_148_q == (esc_mem_reg_4__5__srl5_n_0_843e618)))) recovered_148_q <= (esc_mem_reg_4__5__srl5_n_0_843e618);
  end

  // Reconstructed FDRE: esc_q_reg_60_bb75099
  reg recovered_149_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [60] = recovered_149_q;
  wire recovered_149_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_149_reset || (((SR) === 1'bx) && (recovered_149_q == 1'b0))) recovered_149_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_149_q == (esc_mem_reg_4__60__srl5_n_0_783d111)))) recovered_149_q <= (esc_mem_reg_4__60__srl5_n_0_783d111);
  end

  // Reconstructed FDRE: esc_q_reg_61_9f43040
  reg recovered_150_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [61] = recovered_150_q;
  wire recovered_150_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_150_reset || (((SR) === 1'bx) && (recovered_150_q == 1'b0))) recovered_150_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_150_q == (esc_mem_reg_4__61__srl5_n_0_7362482)))) recovered_150_q <= (esc_mem_reg_4__61__srl5_n_0_7362482);
  end

  // Reconstructed FDRE: esc_q_reg_62_555a1e9
  reg recovered_151_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [62] = recovered_151_q;
  wire recovered_151_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_151_reset || (((SR) === 1'bx) && (recovered_151_q == 1'b0))) recovered_151_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_151_q == (esc_mem_reg_4__62__srl5_n_0_aca8eb1)))) recovered_151_q <= (esc_mem_reg_4__62__srl5_n_0_aca8eb1);
  end

  // Reconstructed FDRE: esc_q_reg_63_b0bd64b
  reg recovered_152_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [63] = recovered_152_q;
  wire recovered_152_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_152_reset || (((SR) === 1'bx) && (recovered_152_q == 1'b0))) recovered_152_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_152_q == (esc_mem_reg_4__63__srl5_n_0_27eb226)))) recovered_152_q <= (esc_mem_reg_4__63__srl5_n_0_27eb226);
  end

  // Reconstructed FDRE: esc_q_reg_6_e06484f
  reg recovered_153_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [6] = recovered_153_q;
  wire recovered_153_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_153_reset || (((SR) === 1'bx) && (recovered_153_q == 1'b0))) recovered_153_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_153_q == (esc_mem_reg_4__6__srl5_n_0_b2b44f9)))) recovered_153_q <= (esc_mem_reg_4__6__srl5_n_0_b2b44f9);
  end

  // Reconstructed FDRE: esc_q_reg_74_ab5295a
  reg recovered_154_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [64] = recovered_154_q;
  wire recovered_154_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_154_reset || (((SR) === 1'bx) && (recovered_154_q == 1'b0))) recovered_154_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_154_q == (esc_mem_reg_4__74__srl5_n_0_2d74fec)))) recovered_154_q <= (esc_mem_reg_4__74__srl5_n_0_2d74fec);
  end

  // Reconstructed FDRE: esc_q_reg_75_5f5b689
  reg recovered_155_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [65] = recovered_155_q;
  wire recovered_155_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_155_reset || (((SR) === 1'bx) && (recovered_155_q == 1'b0))) recovered_155_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_155_q == (esc_mem_reg_4__75__srl5_n_0_f1a7b3e)))) recovered_155_q <= (esc_mem_reg_4__75__srl5_n_0_f1a7b3e);
  end

  // Reconstructed FDRE: esc_q_reg_77_26a0205
  reg recovered_156_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [66] = recovered_156_q;
  wire recovered_156_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_156_reset || (((SR) === 1'bx) && (recovered_156_q == 1'b0))) recovered_156_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_156_q == (esc_mem_reg_4__77__srl5_n_0_4a4f8ac)))) recovered_156_q <= (esc_mem_reg_4__77__srl5_n_0_4a4f8ac);
  end

  // Reconstructed FDRE: esc_q_reg_7_ebc3ce4
  reg recovered_157_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [7] = recovered_157_q;
  wire recovered_157_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_157_reset || (((SR) === 1'bx) && (recovered_157_q == 1'b0))) recovered_157_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_157_q == (esc_mem_reg_4__7__srl5_n_0_c57737b)))) recovered_157_q <= (esc_mem_reg_4__7__srl5_n_0_c57737b);
  end

  // Reconstructed FDRE: esc_q_reg_80_8f9d16c
  reg recovered_158_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [67] = recovered_158_q;
  wire recovered_158_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_158_reset || (((SR) === 1'bx) && (recovered_158_q == 1'b0))) recovered_158_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_158_q == (esc_mem_reg_4__80__srl5_n_0_d3a98e4)))) recovered_158_q <= (esc_mem_reg_4__80__srl5_n_0_d3a98e4);
  end

  // Reconstructed FDRE: esc_q_reg_8_7537f74
  reg recovered_159_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [8] = recovered_159_q;
  wire recovered_159_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_159_reset || (((SR) === 1'bx) && (recovered_159_q == 1'b0))) recovered_159_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_159_q == (esc_mem_reg_4__8__srl5_n_0_2bf3955)))) recovered_159_q <= (esc_mem_reg_4__8__srl5_n_0_2bf3955);
  end

  // Reconstructed FDRE: esc_q_reg_9_974df34
  reg recovered_160_q = 1'b0;
  assign esc_q_reg_80__1_0f2d88b [9] = recovered_160_q;
  wire recovered_160_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_160_reset || (((SR) === 1'bx) && (recovered_160_q == 1'b0))) recovered_160_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_160_q == (esc_mem_reg_4__9__srl5_n_0_bab496c)))) recovered_160_q <= (esc_mem_reg_4__9__srl5_n_0_bab496c);
  end

  // Reconstructed LUT3: esc_sect_cnt_0__i_1_3a64a85
  assign D[0] = ((last_sect_carry__3[0]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [0]) : (1'b0))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [0]) : (1'b1))));

  // Reconstructed LUT3: esc_sect_cnt_10__i_1_d31f178
  assign D[10] = ((sect_cnt0[9]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [10]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [10]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_11__i_1_5d6ffaa
  assign D[11] = ((sect_cnt0[10]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [11]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [11]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_12__i_1_4e261cb
  assign D[12] = ((sect_cnt0[11]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [12]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [12]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_13__i_1_993c379
  assign D[13] = ((sect_cnt0[12]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [13]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [13]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_14__i_1_fead960
  assign D[14] = ((sect_cnt0[13]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [14]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [14]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_15__i_1_bb2af5f
  assign D[15] = ((sect_cnt0[14]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [15]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [15]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_16__i_1_b861e44
  assign D[16] = ((sect_cnt0[15]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [16]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [16]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_17__i_1_df1597b
  assign D[17] = ((sect_cnt0[16]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [17]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [17]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_18__i_1_1a408c7
  assign D[18] = ((sect_cnt0[17]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [18]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [18]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_19__i_1_0678fb8
  assign D[19] = ((sect_cnt0[18]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [19]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [19]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_1__i_1_4a343ee
  assign D[1] = ((sect_cnt0[0]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [1]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [1]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_20__i_1_00f1378
  assign D[20] = ((sect_cnt0[19]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [20]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [20]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_21__i_1_c8fbebe
  assign D[21] = ((sect_cnt0[20]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [21]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [21]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_22__i_1_8021359
  assign D[22] = ((sect_cnt0[21]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [22]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [22]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_23__i_1_66cd32b
  assign D[23] = ((sect_cnt0[22]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [23]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [23]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_24__i_1_4311446
  assign D[24] = ((sect_cnt0[23]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [24]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [24]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_25__i_1_c8dede0
  assign D[25] = ((sect_cnt0[24]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [25]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [25]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_26__i_1_17a899a
  assign D[26] = ((sect_cnt0[25]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [26]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [26]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_27__i_1_37285d1
  assign D[27] = ((sect_cnt0[26]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [27]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [27]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_28__i_1_a40bc53
  assign D[28] = ((sect_cnt0[27]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [28]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [28]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_29__i_1_c7836e9
  assign D[29] = ((sect_cnt0[28]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [29]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [29]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_2__i_1_0f42571
  assign D[2] = ((sect_cnt0[1]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [2]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [2]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_30__i_1_86e4a7c
  assign D[30] = ((sect_cnt0[29]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [30]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [30]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_31__i_1_21ede29
  assign D[31] = ((sect_cnt0[30]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [31]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [31]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_32__i_1_f7739a1
  assign D[32] = ((sect_cnt0[31]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [32]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [32]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_33__i_1_895adcb
  assign D[33] = ((sect_cnt0[32]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [33]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [33]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_34__i_1_69bbed3
  assign D[34] = ((sect_cnt0[33]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [34]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [34]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_35__i_1_95135fa
  assign D[35] = ((sect_cnt0[34]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [35]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [35]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_36__i_1_6594a36
  assign D[36] = ((sect_cnt0[35]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [36]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [36]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_37__i_1_fd6decb
  assign D[37] = ((sect_cnt0[36]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [37]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [37]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_38__i_1_7dd9b95
  assign D[38] = ((sect_cnt0[37]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [38]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [38]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_39__i_1_2fe9f7f
  assign D[39] = ((sect_cnt0[38]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [39]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [39]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_3__i_1_ae37923
  assign D[3] = ((sect_cnt0[2]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [3]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [3]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_40__i_1_0b4f8a8
  assign D[40] = ((sect_cnt0[39]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [40]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [40]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_41__i_1_f6d1d99
  assign D[41] = ((sect_cnt0[40]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [41]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [41]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_42__i_1_3b80868
  assign D[42] = ((sect_cnt0[41]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [42]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [42]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_43__i_1_2e8c6c9
  assign D[43] = ((sect_cnt0[42]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [43]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [43]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_44__i_1_128096d
  assign D[44] = ((sect_cnt0[43]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [44]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [44]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_45__i_1_0dfa17d
  assign D[45] = ((sect_cnt0[44]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [45]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [45]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_46__i_1_33d42ca
  assign D[46] = ((sect_cnt0[45]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [46]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [46]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_47__i_1_5f1b180
  assign D[47] = ((sect_cnt0[46]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [47]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [47]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_48__i_1_d93d2c2
  assign D[48] = ((sect_cnt0[47]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [48]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [48]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_49__i_1_1533379
  assign D[49] = ((sect_cnt0[48]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [49]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [49]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_4__i_1_282e86c
  assign D[4] = ((sect_cnt0[3]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [4]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [4]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_50__i_1_f833205
  assign D[50] = ((sect_cnt0[49]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [50]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [50]) : (1'b0))));

  // Reconstructed LUT2: esc_sect_cnt_51__i_1_a35699e
  assign E = ((p_20_in) ? (1'b1) : (next_rreq));

  // Reconstructed LUT3: esc_sect_cnt_51__i_2_3a018a4
  assign D[51] = ((sect_cnt0[50]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [51]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [51]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_5__i_1_433d6c9
  assign D[5] = ((sect_cnt0[4]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [5]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [5]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_6__i_1_cbd1eff
  assign D[6] = ((sect_cnt0[5]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [6]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [6]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_7__i_1_b689a3f
  assign D[7] = ((sect_cnt0[6]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [7]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [7]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_8__i_1_6a17efc
  assign D[8] = ((sect_cnt0[7]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [8]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [8]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_9__i_1_4fed376
  assign D[9] = ((sect_cnt0[8]) ? (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [9]) : (1'b1))) : (((next_rreq) ? (esc_sect_cnt_reg_51_7c99099 [9]) : (1'b0))));

endmodule

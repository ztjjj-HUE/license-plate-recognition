// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_frame_m_axi_fifo__parameterized1
   (fifo_rctl_ready,
    data_vld_reg_0,
    empty_n_reg_0,
    ap_rst_n_0,
    p_20_in,
    ap_rst_n_1,
    esc_could_multi_bursts_next_loop_c288065 ,
    esc_could_multi_bursts_sect_handling_reg_a60c95a ,
    esc_end_addr_buf_reg_1_d086d54 ,
    esc_end_addr_buf_reg_0_f3b7c01 ,
    esc_could_multi_bursts_ARVALID_Dummy_reg_7381e5f ,
    E,
    rreq_handling_reg,
    ap_clk,
    SR,
    ap_rst_n,
    CO,
    esc_sect_len_buf_reg_3_9899048 ,
    esc_sect_len_buf_reg_3__0_cb18dca ,
    esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc ,
    rreq_handling_reg_0,
    Q,
    esc_sect_end_buf_reg_1_e5e88ce ,
    esc_sect_end_buf_reg_1__0_b544ea2 ,
    esc_sect_end_buf_reg_0_721779d ,
    esc_could_multi_bursts_ARVALID_Dummy_reg_0_61f317f ,
    m_axi_frame_ARREADY,
    invalid_len_event_reg2,
    sel,
    pout17_out,
    beat_valid,
    empty_n_reg_1,
    esc_bus_wide_gen_last_split_89b9056 ,
    fifo_rreq_valid,
    fifo_burst_ready,
    invalid_len_event,
    rreq_handling_reg_1);
  output fifo_rctl_ready;
  output data_vld_reg_0;
  output empty_n_reg_0;
  output [0:0]ap_rst_n_0;
  output p_20_in;
  output [0:0]ap_rst_n_1;
  output esc_could_multi_bursts_next_loop_c288065 ;
  output esc_could_multi_bursts_sect_handling_reg_a60c95a ;
  output esc_end_addr_buf_reg_1_d086d54 ;
  output esc_end_addr_buf_reg_0_f3b7c01 ;
  output esc_could_multi_bursts_ARVALID_Dummy_reg_7381e5f ;
  output [0:0]E;
  output rreq_handling_reg;
  input ap_clk;
  input [0:0]SR;
  input ap_rst_n;
  input [0:0]CO;
  input esc_sect_len_buf_reg_3_9899048 ;
  input esc_sect_len_buf_reg_3__0_cb18dca ;
  input esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc ;
  input rreq_handling_reg_0;
  input [1:0]Q;
  input [0:0]esc_sect_end_buf_reg_1_e5e88ce ;
  input esc_sect_end_buf_reg_1__0_b544ea2 ;
  input esc_sect_end_buf_reg_0_721779d ;
  input esc_could_multi_bursts_ARVALID_Dummy_reg_0_61f317f ;
  input m_axi_frame_ARREADY;
  input invalid_len_event_reg2;
  input sel;
  input pout17_out;
  input beat_valid;
  input [0:0]empty_n_reg_1;
  input esc_bus_wide_gen_last_split_89b9056 ;
  input fifo_rreq_valid;
  input fifo_burst_ready;
  input invalid_len_event;
  input rreq_handling_reg_1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]CO;
  wire [0:0]E;
  wire [1:0]Q;
  wire [0:0]SR;
  wire ap_clk;
  wire ap_rst_n;
  wire [0:0]ap_rst_n_0;
  wire [0:0]ap_rst_n_1;
  wire beat_valid;
  wire esc_bus_wide_gen_last_split_89b9056 ;
  wire esc_could_multi_bursts_ARVALID_Dummy_reg_7381e5f ;
  wire esc_could_multi_bursts_ARVALID_Dummy_reg_0_61f317f ;
  wire esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc ;
  wire esc_could_multi_bursts_next_loop_c288065 ;
  wire esc_could_multi_bursts_sect_handling_reg_a60c95a ;
  wire data_vld1;
  wire data_vld_i_1__1_n_0;
  wire data_vld_reg_0;
  wire empty_n_i_1__1_n_0;
  wire empty_n_reg_0;
  wire [0:0]empty_n_reg_1;
  wire esc_end_addr_buf_reg_0_f3b7c01 ;
  wire esc_end_addr_buf_reg_1_d086d54 ;
  wire fifo_burst_ready;
  wire fifo_rctl_ready;
  wire fifo_rreq_valid;
  wire full_n_i_1__1_n_0;
  wire full_n_i_2__1_n_0;
  wire invalid_len_event;
  wire invalid_len_event_reg2;
  wire m_axi_frame_ARREADY;
  wire p_10_in;
  wire p_20_in;
  wire pout17_out;
  wire esc_pout_0__i_1_n_0_c71edc2 ;
  wire esc_pout_1__i_1_n_0_77ba36c ;
  wire esc_pout_2__i_1_n_0_bcda194 ;
  wire esc_pout_3__i_1_n_0_332e283 ;
  wire esc_pout_3__i_2_n_0_81a8813 ;
  wire [3:0]pout_reg;
  wire rreq_handling_reg;
  wire rreq_handling_reg_0;
  wire rreq_handling_reg_1;
  wire esc_sect_end_buf_reg_0_721779d ;
  wire [0:0]esc_sect_end_buf_reg_1_e5e88ce ;
  wire esc_sect_end_buf_reg_1__0_b544ea2 ;
  wire esc_sect_len_buf_reg_3_9899048 ;
  wire esc_sect_len_buf_reg_3__0_cb18dca ;
  wire sel;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT4: esc_align_len_31__i_1_8fd9a34
  assign E = ((fifo_rreq_valid) ? (((esc_sect_end_buf_reg_1_e5e88ce) ? (((p_20_in) ? (1'b1) : (~(rreq_handling_reg_0)))) : (~(rreq_handling_reg_0)))) : (1'b0));

  // Reconstructed LUT5: esc_could_multi_bursts_ARVALID_Dummy_i_1_6fffae0
  assign esc_could_multi_bursts_ARVALID_Dummy_reg_7381e5f = ((esc_could_multi_bursts_next_loop_c288065) ? (((invalid_len_event_reg2) ? (1'b0) : (ap_rst_n))) : (((ap_rst_n) ? (((m_axi_frame_ARREADY) ? (1'b0) : (esc_could_multi_bursts_ARVALID_Dummy_reg_0_61f317f))) : (1'b0))));

  // Reconstructed LUT5: esc_could_multi_bursts_araddr_buf_63__i_2_478d95d
  assign esc_could_multi_bursts_next_loop_c288065 = ((m_axi_frame_ARREADY) ? (((fifo_burst_ready) ? (((esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc) ? (fifo_rctl_ready) : (1'b0))) : (1'b0))) : (((esc_could_multi_bursts_ARVALID_Dummy_reg_0_61f317f) ? (1'b0) : (((fifo_burst_ready) ? (((esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc) ? (fifo_rctl_ready) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT2: esc_could_multi_bursts_loop_cnt_5__i_1_9506bd8
  assign ap_rst_n_0 = ((ap_rst_n) ? (p_20_in) : (1'b1));

  // Reconstructed LUT5: esc_could_multi_bursts_sect_handling_i_1__0_cb3384f
  assign esc_could_multi_bursts_sect_handling_reg_a60c95a = ((rreq_handling_reg_0) ? (1'b1) : (((esc_could_multi_bursts_next_loop_c288065) ? (((esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc) ? (((esc_sect_len_buf_reg_3__0_cb18dca) ? (~(esc_sect_len_buf_reg_3_9899048)) : (1'b1))) : (1'b0))) : (esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc))));

  // Reconstructed LUT5: data_vld_i_1__1
  assign data_vld_i_1__1_n_0 = ((data_vld_reg_0) ? (((fifo_rctl_ready) ? (((esc_could_multi_bursts_next_loop_c288065) ? (1'b1) : (((p_10_in) ? (~(data_vld1)) : (1'b1))))) : (((p_10_in) ? (~(data_vld1)) : (1'b1))))) : (((fifo_rctl_ready) ? (esc_could_multi_bursts_next_loop_c288065) : (1'b0))));

  // Reconstructed FDRE: data_vld_reg
  reg recovered_9_q = 1'b0;
  assign data_vld_reg_0 = recovered_9_q;
  wire recovered_9_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_9_reset || (((SR) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (data_vld_i_1__1_n_0)))) recovered_9_q <= (data_vld_i_1__1_n_0);
  end

  // Reconstructed LUT5: empty_n_i_1__1
  assign empty_n_i_1__1_n_0 = ((empty_n_reg_0) ? (((beat_valid) ? (((empty_n_reg_1) ? (((esc_bus_wide_gen_last_split_89b9056) ? (data_vld_reg_0) : (1'b1))) : (1'b1))) : (1'b1))) : (data_vld_reg_0));

  // Reconstructed FDRE: empty_n_reg
  reg recovered_11_q = 1'b0;
  assign empty_n_reg_0 = recovered_11_q;
  wire recovered_11_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_11_reset || (((SR) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_11_q == (empty_n_i_1__1_n_0)))) recovered_11_q <= (empty_n_i_1__1_n_0);
  end

  // Reconstructed LUT5: full_n_i_1__1
  assign full_n_i_1__1_n_0 = ((p_10_in) ? (1'b1) : (((full_n_i_2__1_n_0) ? (((esc_could_multi_bursts_next_loop_c288065) ? (~(ap_rst_n)) : (((fifo_rctl_ready) ? (1'b1) : (~(ap_rst_n)))))) : (((fifo_rctl_ready) ? (1'b1) : (~(ap_rst_n)))))));

  // Reconstructed LUT5: full_n_i_2__1
  assign full_n_i_2__1_n_0 = ((pout_reg[1]) ? (1'b0) : (((pout_reg[2]) ? (((data_vld_reg_0) ? (((pout_reg[3]) ? (pout_reg[0]) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed FDRE: full_n_reg
  reg recovered_14_q = 1'b0;
  assign fifo_rctl_ready = recovered_14_q;
  wire recovered_14_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_14_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_14_q == (full_n_i_1__1_n_0)))) recovered_14_q <= (full_n_i_1__1_n_0);
  end

  // Reconstructed LUT1: esc_pout_0__i_1_729e482
  assign esc_pout_0__i_1_n_0_c71edc2 = ~(pout_reg[0]);

  // Reconstructed LUT6: esc_pout_1__i_1_d213e77
  assign esc_pout_1__i_1_n_0_77ba36c = ((pout_reg[1]) ? (((data_vld_reg_0) ? (((fifo_rctl_ready) ? (((esc_could_multi_bursts_next_loop_c288065) ? (((p_10_in) ? (pout_reg[0]) : (~(pout_reg[0])))) : (pout_reg[0]))) : (pout_reg[0]))) : (pout_reg[0]))) : (((data_vld_reg_0) ? (((fifo_rctl_ready) ? (((esc_could_multi_bursts_next_loop_c288065) ? (((p_10_in) ? (~(pout_reg[0])) : (pout_reg[0]))) : (~(pout_reg[0])))) : (~(pout_reg[0])))) : (~(pout_reg[0])))));

  // Reconstructed LUT6: esc_pout_2__i_1_9909dbc
  assign esc_pout_2__i_1_n_0_bcda194 = ((pout_reg[1]) ? (((pout_reg[2]) ? (((pout_reg[0]) ? (((p_10_in) ? (1'b1) : (((sel) ? (~(data_vld_reg_0)) : (1'b1))))) : (1'b1))) : (((pout_reg[0]) ? (((p_10_in) ? (1'b0) : (((sel) ? (data_vld_reg_0) : (1'b0))))) : (1'b0))))) : (((pout_reg[2]) ? (((pout_reg[0]) ? (1'b1) : (((p_10_in) ? (1'b0) : (((sel) ? (data_vld_reg_0) : (1'b0))))))) : (((pout_reg[0]) ? (1'b0) : (((p_10_in) ? (1'b1) : (((sel) ? (~(data_vld_reg_0)) : (1'b1))))))))));

  // Reconstructed LUT5: esc_pout_3__i_1_e913d0e
  assign esc_pout_3__i_1_n_0_332e283 = ((data_vld_reg_0) ? (((fifo_rctl_ready) ? (((esc_could_multi_bursts_next_loop_c288065) ? (~(p_10_in)) : (((p_10_in) ? (~(data_vld1)) : (1'b0))))) : (((p_10_in) ? (~(data_vld1)) : (1'b0))))) : (((fifo_rctl_ready) ? (((esc_could_multi_bursts_next_loop_c288065) ? (1'b0) : (((p_10_in) ? (~(data_vld1)) : (1'b0))))) : (((p_10_in) ? (~(data_vld1)) : (1'b0))))));

  // Reconstructed LUT5: esc_pout_3__i_2_dd15e3f
  assign esc_pout_3__i_2_n_0_81a8813 = ((pout_reg[2]) ? (((pout_reg[3]) ? (((pout_reg[0]) ? (((pout17_out) ? (~(pout_reg[1])) : (1'b1))) : (1'b1))) : (((pout_reg[0]) ? (((pout17_out) ? (pout_reg[1]) : (1'b0))) : (1'b0))))) : (((pout_reg[3]) ? (((pout_reg[0]) ? (1'b1) : (((pout17_out) ? (1'b1) : (pout_reg[1]))))) : (((pout_reg[0]) ? (1'b0) : (((pout17_out) ? (1'b0) : (~(pout_reg[1])))))))));

  // Reconstructed LUT4: esc_pout_3__i_3_639b339
  assign data_vld1 = ((pout_reg[2]) ? (1'b0) : (((pout_reg[3]) ? (1'b0) : (((pout_reg[0]) ? (1'b0) : (~(pout_reg[1])))))));

  // Reconstructed LUT5: esc_pout_3__i_4_6e0552a
  assign p_10_in = ((esc_bus_wide_gen_last_split_89b9056) ? (((empty_n_reg_1) ? (((beat_valid) ? (data_vld_reg_0) : (((empty_n_reg_0) ? (1'b0) : (data_vld_reg_0))))) : (((empty_n_reg_0) ? (1'b0) : (data_vld_reg_0))))) : (((empty_n_reg_0) ? (1'b0) : (data_vld_reg_0))));

  // Reconstructed FDRE: esc_pout_reg_0_cd95a63
  reg recovered_22_q = 1'b0;
  assign pout_reg[0] = recovered_22_q;
  wire recovered_22_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_22_reset || (((SR) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((esc_pout_3__i_1_n_0_332e283) || ((esc_pout_3__i_1_n_0_332e283) === 1'bz) || (((esc_pout_3__i_1_n_0_332e283) === 1'bx) && (recovered_22_q == (esc_pout_0__i_1_n_0_c71edc2)))) recovered_22_q <= (esc_pout_0__i_1_n_0_c71edc2);
  end

  // Reconstructed FDRE: esc_pout_reg_1_325167f
  reg recovered_23_q = 1'b0;
  assign pout_reg[1] = recovered_23_q;
  wire recovered_23_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_23_reset || (((SR) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((esc_pout_3__i_1_n_0_332e283) || ((esc_pout_3__i_1_n_0_332e283) === 1'bz) || (((esc_pout_3__i_1_n_0_332e283) === 1'bx) && (recovered_23_q == (esc_pout_1__i_1_n_0_77ba36c)))) recovered_23_q <= (esc_pout_1__i_1_n_0_77ba36c);
  end

  // Reconstructed FDRE: esc_pout_reg_2_3108b14
  reg recovered_24_q = 1'b0;
  assign pout_reg[2] = recovered_24_q;
  wire recovered_24_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_24_reset || (((SR) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((esc_pout_3__i_1_n_0_332e283) || ((esc_pout_3__i_1_n_0_332e283) === 1'bz) || (((esc_pout_3__i_1_n_0_332e283) === 1'bx) && (recovered_24_q == (esc_pout_2__i_1_n_0_bcda194)))) recovered_24_q <= (esc_pout_2__i_1_n_0_bcda194);
  end

  // Reconstructed FDRE: esc_pout_reg_3_c06edf1
  reg recovered_25_q = 1'b0;
  assign pout_reg[3] = recovered_25_q;
  wire recovered_25_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_25_reset || (((SR) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((esc_pout_3__i_1_n_0_332e283) || ((esc_pout_3__i_1_n_0_332e283) === 1'bz) || (((esc_pout_3__i_1_n_0_332e283) === 1'bx) && (recovered_25_q == (esc_pout_3__i_2_n_0_81a8813)))) recovered_25_q <= (esc_pout_3__i_2_n_0_81a8813);
  end

  // Reconstructed LUT5: rreq_handling_i_1
  assign rreq_handling_reg = ((rreq_handling_reg_1) ? (((invalid_len_event) ? (((rreq_handling_reg_0) ? (((esc_sect_end_buf_reg_1_e5e88ce) ? (~(p_20_in)) : (1'b1))) : (1'b0))) : (1'b1))) : (((rreq_handling_reg_0) ? (((esc_sect_end_buf_reg_1_e5e88ce) ? (~(p_20_in)) : (1'b1))) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_11__i_1_0f78b85
  assign ap_rst_n_1 = ((ap_rst_n) ? (((p_20_in) ? (~(CO)) : (1'b0))) : (1'b1));

  // Reconstructed LUT4: esc_sect_end_buf_0__i_1_fb543e5
  assign esc_end_addr_buf_reg_0_f3b7c01 = ((esc_sect_end_buf_reg_0_721779d) ? (((p_20_in) ? (((esc_sect_end_buf_reg_1_e5e88ce) ? (Q[0]) : (1'b1))) : (1'b1))) : (((p_20_in) ? (((esc_sect_end_buf_reg_1_e5e88ce) ? (Q[0]) : (1'b1))) : (1'b0))));

  // Reconstructed LUT4: esc_sect_end_buf_1__i_1_66b5ab5
  assign esc_end_addr_buf_reg_1_d086d54 = ((esc_sect_end_buf_reg_1__0_b544ea2) ? (((p_20_in) ? (((esc_sect_end_buf_reg_1_e5e88ce) ? (Q[1]) : (1'b1))) : (1'b1))) : (((p_20_in) ? (((esc_sect_end_buf_reg_1_e5e88ce) ? (Q[1]) : (1'b1))) : (1'b0))));

  // Reconstructed LUT5: esc_sect_len_buf_9__i_1__0_cde6958
  assign p_20_in = ((rreq_handling_reg_0) ? (((esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc) ? (((esc_could_multi_bursts_next_loop_c288065) ? (((esc_sect_len_buf_reg_3__0_cb18dca) ? (esc_sect_len_buf_reg_3_9899048) : (1'b0))) : (1'b0))) : (1'b1))) : (1'b0));

endmodule

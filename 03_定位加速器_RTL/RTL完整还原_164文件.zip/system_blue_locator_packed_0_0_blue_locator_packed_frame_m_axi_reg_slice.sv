// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_frame_m_axi_reg_slice
   (D,
    esc_state_reg_0__0_c93a5dd ,
    esc_data_p1_reg_63__0_517eda5 ,
    SR,
    ap_clk,
    esc_ap_CS_fsm_reg_2_e63bcb7 ,
    Q,
    rs2f_rreq_ack,
    esc_data_p2_reg_63__0_b7561ac );
  output [1:0]D;
  output [0:0]esc_state_reg_0__0_c93a5dd ;
  output [63:0]esc_data_p1_reg_63__0_517eda5 ;
  input [0:0]SR;
  input ap_clk;
  input esc_ap_CS_fsm_reg_2_e63bcb7 ;
  input [1:0]Q;
  input rs2f_rreq_ack;
  input [63:0]esc_data_p2_reg_63__0_b7561ac ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [1:0]D;
  wire [1:0]Q;
  wire [0:0]SR;
  wire esc_ap_CS_fsm_reg_2_e63bcb7 ;
  wire ap_clk;
  wire esc_data_p1_0__i_1_n_0_7dcfe44 ;
  wire esc_data_p1_10__i_1_n_0_b7b73af ;
  wire esc_data_p1_11__i_1_n_0_708c194 ;
  wire esc_data_p1_12__i_1_n_0_792d5c4 ;
  wire esc_data_p1_13__i_1_n_0_2c91847 ;
  wire esc_data_p1_14__i_1_n_0_4403616 ;
  wire esc_data_p1_15__i_1_n_0_dd5fdfd ;
  wire esc_data_p1_16__i_1_n_0_5f42dca ;
  wire esc_data_p1_17__i_1_n_0_c83f426 ;
  wire esc_data_p1_18__i_1_n_0_7701074 ;
  wire esc_data_p1_19__i_1_n_0_a985fc1 ;
  wire esc_data_p1_1__i_1_n_0_049b0db ;
  wire esc_data_p1_20__i_1_n_0_cc4220b ;
  wire esc_data_p1_21__i_1_n_0_09504a0 ;
  wire esc_data_p1_22__i_1_n_0_7c1e19e ;
  wire esc_data_p1_23__i_1_n_0_3811def ;
  wire esc_data_p1_24__i_1_n_0_d85cddd ;
  wire esc_data_p1_25__i_1_n_0_5e66e7e ;
  wire esc_data_p1_26__i_1_n_0_de65112 ;
  wire esc_data_p1_27__i_1_n_0_42ebbcb ;
  wire esc_data_p1_28__i_1_n_0_241c139 ;
  wire esc_data_p1_29__i_1_n_0_f236ad3 ;
  wire esc_data_p1_2__i_1_n_0_2cab8b2 ;
  wire esc_data_p1_30__i_1_n_0_586ea66 ;
  wire esc_data_p1_31__i_1_n_0_f901432 ;
  wire esc_data_p1_32__i_1_n_0_c71404a ;
  wire esc_data_p1_33__i_1_n_0_fb214dd ;
  wire esc_data_p1_34__i_1_n_0_006ae63 ;
  wire esc_data_p1_35__i_1_n_0_d37c307 ;
  wire esc_data_p1_36__i_1_n_0_561c85f ;
  wire esc_data_p1_37__i_1_n_0_4b6f381 ;
  wire esc_data_p1_38__i_1_n_0_9776359 ;
  wire esc_data_p1_39__i_1_n_0_c8b2b6b ;
  wire esc_data_p1_3__i_1_n_0_b1ab4b5 ;
  wire esc_data_p1_40__i_1_n_0_f45dac5 ;
  wire esc_data_p1_41__i_1_n_0_51b9b04 ;
  wire esc_data_p1_42__i_1_n_0_ed056b6 ;
  wire esc_data_p1_43__i_1_n_0_a3e247a ;
  wire esc_data_p1_44__i_1_n_0_27544d3 ;
  wire esc_data_p1_45__i_1_n_0_ef32cb8 ;
  wire esc_data_p1_46__i_1_n_0_77705be ;
  wire esc_data_p1_47__i_1_n_0_5fbb7a3 ;
  wire esc_data_p1_48__i_1_n_0_c50166b ;
  wire esc_data_p1_49__i_1_n_0_7bab114 ;
  wire esc_data_p1_4__i_1_n_0_e45c5db ;
  wire esc_data_p1_50__i_1_n_0_b33cc9f ;
  wire esc_data_p1_51__i_1_n_0_d871838 ;
  wire esc_data_p1_52__i_1_n_0_a58d446 ;
  wire esc_data_p1_53__i_1_n_0_a996e37 ;
  wire esc_data_p1_54__i_1_n_0_324cc70 ;
  wire esc_data_p1_55__i_1_n_0_3fd21a0 ;
  wire esc_data_p1_56__i_1_n_0_a4b574e ;
  wire esc_data_p1_57__i_1_n_0_03d8fde ;
  wire esc_data_p1_58__i_1_n_0_0873eb1 ;
  wire esc_data_p1_59__i_1_n_0_088a8ec ;
  wire esc_data_p1_5__i_1_n_0_044800f ;
  wire esc_data_p1_60__i_1_n_0_5f4b7bf ;
  wire esc_data_p1_61__i_1_n_0_14db8b8 ;
  wire esc_data_p1_62__i_1_n_0_91aed61 ;
  wire esc_data_p1_63__i_2_n_0_b83484d ;
  wire esc_data_p1_6__i_1_n_0_330e460 ;
  wire esc_data_p1_7__i_1_n_0_05ccbe7 ;
  wire esc_data_p1_8__i_1_n_0_1e2bc6c ;
  wire esc_data_p1_9__i_1_n_0_19cd207 ;
  wire [63:0]esc_data_p1_reg_63__0_517eda5 ;
  wire [63:0]data_p2;
  wire [63:0]esc_data_p2_reg_63__0_b7561ac ;
  wire frame_ARREADY;
  wire load_p1;
  wire [1:0]next__0;
  wire rs2f_rreq_ack;
  wire s_ready_t_i_1_n_0;
  wire [1:1]state;
  wire esc_state_0__i_1_n_0_19586c4 ;
  wire esc_state_1__i_1_n_0_db32706 ;
  wire [1:0]state__0;
  wire [0:0]esc_state_reg_0__0_c93a5dd ;

  // Reconstructed LUT5: esc_FSM_sequential_state_0__i_1_c847423
  assign next__0[0] = ((state__0[1]) ? (((state__0[0]) ? (1'b0) : (((rs2f_rreq_ack) ? (1'b0) : (((frame_ARREADY) ? (Q[1]) : (1'b0))))))) : (((state__0[0]) ? (~(rs2f_rreq_ack)) : (1'b0))));

  // Reconstructed LUT5: esc_FSM_sequential_state_1__i_1_0114fae
  assign next__0[1] = ((frame_ARREADY) ? (((Q[1]) ? (((rs2f_rreq_ack) ? (((state__0[0]) ? (~(state__0[1])) : (1'b1))) : (((state__0[0]) ? (1'b0) : (~(state__0[1])))))) : (((rs2f_rreq_ack) ? (((state__0[0]) ? (~(state__0[1])) : (1'b0))) : (((state__0[0]) ? (1'b0) : (state__0[1]))))))) : (((rs2f_rreq_ack) ? (((state__0[0]) ? (~(state__0[1])) : (1'b0))) : (((state__0[0]) ? (1'b0) : (state__0[1]))))));

  // Reconstructed FDRE: esc_FSM_sequential_state_reg_0_392f9b0
  reg recovered_3_q = 1'b0;
  assign state__0[0] = recovered_3_q;
  wire recovered_3_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_3_reset || (((SR) === 1'bx) && (recovered_3_q == 1'b0))) recovered_3_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_3_q == (next__0[0])))) recovered_3_q <= (next__0[0]);
  end

  // Reconstructed FDRE: esc_FSM_sequential_state_reg_1_aa5780a
  reg recovered_4_q = 1'b0;
  assign state__0[1] = recovered_4_q;
  wire recovered_4_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_4_reset || (((SR) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (next__0[1])))) recovered_4_q <= (next__0[1]);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT4: esc_ap_CS_fsm_2__i_1_5105425
  assign D[0] = ((frame_ARREADY) ? (((Q[0]) ? (esc_ap_CS_fsm_reg_2_e63bcb7) : (1'b0))) : (((Q[1]) ? (((Q[0]) ? (esc_ap_CS_fsm_reg_2_e63bcb7) : (1'b1))) : (((Q[0]) ? (esc_ap_CS_fsm_reg_2_e63bcb7) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_0__i_1_9449866
  assign esc_data_p1_0__i_1_n_0_7dcfe44 = ((esc_data_p2_reg_63__0_b7561ac [0]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[0]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[0]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_10__i_1_3262956
  assign esc_data_p1_10__i_1_n_0_b7b73af = ((esc_data_p2_reg_63__0_b7561ac [10]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[10]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[10]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_11__i_1_de1b2a5
  assign esc_data_p1_11__i_1_n_0_708c194 = ((esc_data_p2_reg_63__0_b7561ac [11]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[11]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[11]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_12__i_1_0acbb3c
  assign esc_data_p1_12__i_1_n_0_792d5c4 = ((esc_data_p2_reg_63__0_b7561ac [12]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[12]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[12]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_13__i_1_8564270
  assign esc_data_p1_13__i_1_n_0_2c91847 = ((esc_data_p2_reg_63__0_b7561ac [13]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[13]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[13]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_14__i_1_b3282dd
  assign esc_data_p1_14__i_1_n_0_4403616 = ((esc_data_p2_reg_63__0_b7561ac [14]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[14]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[14]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_15__i_1_9804e94
  assign esc_data_p1_15__i_1_n_0_dd5fdfd = ((esc_data_p2_reg_63__0_b7561ac [15]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[15]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[15]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_16__i_1_cb2973f
  assign esc_data_p1_16__i_1_n_0_5f42dca = ((esc_data_p2_reg_63__0_b7561ac [16]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[16]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[16]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_17__i_1_28e2112
  assign esc_data_p1_17__i_1_n_0_c83f426 = ((esc_data_p2_reg_63__0_b7561ac [17]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[17]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[17]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_18__i_1_1d1a213
  assign esc_data_p1_18__i_1_n_0_7701074 = ((esc_data_p2_reg_63__0_b7561ac [18]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[18]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[18]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_19__i_1_0f96256
  assign esc_data_p1_19__i_1_n_0_a985fc1 = ((esc_data_p2_reg_63__0_b7561ac [19]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[19]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[19]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_1__i_1_ef5b9ba
  assign esc_data_p1_1__i_1_n_0_049b0db = ((esc_data_p2_reg_63__0_b7561ac [1]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[1]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[1]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_20__i_1_00b2325
  assign esc_data_p1_20__i_1_n_0_cc4220b = ((esc_data_p2_reg_63__0_b7561ac [20]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[20]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[20]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_21__i_1_b0f2e8f
  assign esc_data_p1_21__i_1_n_0_09504a0 = ((esc_data_p2_reg_63__0_b7561ac [21]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[21]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[21]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_22__i_1_0456de5
  assign esc_data_p1_22__i_1_n_0_7c1e19e = ((esc_data_p2_reg_63__0_b7561ac [22]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[22]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[22]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_23__i_1_4cece6d
  assign esc_data_p1_23__i_1_n_0_3811def = ((esc_data_p2_reg_63__0_b7561ac [23]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[23]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[23]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_24__i_1_4d822c9
  assign esc_data_p1_24__i_1_n_0_d85cddd = ((esc_data_p2_reg_63__0_b7561ac [24]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[24]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[24]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_25__i_1_68a1a37
  assign esc_data_p1_25__i_1_n_0_5e66e7e = ((esc_data_p2_reg_63__0_b7561ac [25]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[25]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[25]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_26__i_1_121829b
  assign esc_data_p1_26__i_1_n_0_de65112 = ((esc_data_p2_reg_63__0_b7561ac [26]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[26]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[26]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_27__i_1_f5c3047
  assign esc_data_p1_27__i_1_n_0_42ebbcb = ((esc_data_p2_reg_63__0_b7561ac [27]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[27]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[27]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_28__i_1_9f460dc
  assign esc_data_p1_28__i_1_n_0_241c139 = ((esc_data_p2_reg_63__0_b7561ac [28]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[28]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[28]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_29__i_1_7b46c22
  assign esc_data_p1_29__i_1_n_0_f236ad3 = ((esc_data_p2_reg_63__0_b7561ac [29]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[29]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[29]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_2__i_1_6d7d281
  assign esc_data_p1_2__i_1_n_0_2cab8b2 = ((esc_data_p2_reg_63__0_b7561ac [2]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[2]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[2]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_30__i_1_87a19dc
  assign esc_data_p1_30__i_1_n_0_586ea66 = ((esc_data_p2_reg_63__0_b7561ac [30]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[30]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[30]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_31__i_1_6d4a4b5
  assign esc_data_p1_31__i_1_n_0_f901432 = ((esc_data_p2_reg_63__0_b7561ac [31]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[31]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[31]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_32__i_1_7c039c1
  assign esc_data_p1_32__i_1_n_0_c71404a = ((esc_data_p2_reg_63__0_b7561ac [32]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[32]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[32]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_33__i_1_ecd1df1
  assign esc_data_p1_33__i_1_n_0_fb214dd = ((esc_data_p2_reg_63__0_b7561ac [33]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[33]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[33]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_34__i_1_03325d8
  assign esc_data_p1_34__i_1_n_0_006ae63 = ((esc_data_p2_reg_63__0_b7561ac [34]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[34]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[34]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_35__i_1_5bffca9
  assign esc_data_p1_35__i_1_n_0_d37c307 = ((esc_data_p2_reg_63__0_b7561ac [35]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[35]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[35]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_36__i_1_caa361b
  assign esc_data_p1_36__i_1_n_0_561c85f = ((esc_data_p2_reg_63__0_b7561ac [36]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[36]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[36]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_37__i_1_97571a3
  assign esc_data_p1_37__i_1_n_0_4b6f381 = ((esc_data_p2_reg_63__0_b7561ac [37]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[37]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[37]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_38__i_1_48986b1
  assign esc_data_p1_38__i_1_n_0_9776359 = ((esc_data_p2_reg_63__0_b7561ac [38]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[38]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[38]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_39__i_1_93d3e7f
  assign esc_data_p1_39__i_1_n_0_c8b2b6b = ((esc_data_p2_reg_63__0_b7561ac [39]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[39]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[39]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_3__i_1_e2b0eec
  assign esc_data_p1_3__i_1_n_0_b1ab4b5 = ((esc_data_p2_reg_63__0_b7561ac [3]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[3]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[3]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_40__i_1_83f3cfb
  assign esc_data_p1_40__i_1_n_0_f45dac5 = ((esc_data_p2_reg_63__0_b7561ac [40]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[40]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[40]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_41__i_1_edb425f
  assign esc_data_p1_41__i_1_n_0_51b9b04 = ((esc_data_p2_reg_63__0_b7561ac [41]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[41]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[41]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_42__i_1_9fe54a8
  assign esc_data_p1_42__i_1_n_0_ed056b6 = ((esc_data_p2_reg_63__0_b7561ac [42]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[42]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[42]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_43__i_1_494e405
  assign esc_data_p1_43__i_1_n_0_a3e247a = ((esc_data_p2_reg_63__0_b7561ac [43]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[43]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[43]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_44__i_1_bffb379
  assign esc_data_p1_44__i_1_n_0_27544d3 = ((esc_data_p2_reg_63__0_b7561ac [44]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[44]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[44]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_45__i_1_b0a28e0
  assign esc_data_p1_45__i_1_n_0_ef32cb8 = ((esc_data_p2_reg_63__0_b7561ac [45]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[45]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[45]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_46__i_1_0b55e67
  assign esc_data_p1_46__i_1_n_0_77705be = ((esc_data_p2_reg_63__0_b7561ac [46]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[46]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[46]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_47__i_1_deba231
  assign esc_data_p1_47__i_1_n_0_5fbb7a3 = ((esc_data_p2_reg_63__0_b7561ac [47]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[47]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[47]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_48__i_1_e55493c
  assign esc_data_p1_48__i_1_n_0_c50166b = ((esc_data_p2_reg_63__0_b7561ac [48]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[48]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[48]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_49__i_1_d7e5ce0
  assign esc_data_p1_49__i_1_n_0_7bab114 = ((esc_data_p2_reg_63__0_b7561ac [49]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[49]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[49]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_4__i_1_8cfb617
  assign esc_data_p1_4__i_1_n_0_e45c5db = ((esc_data_p2_reg_63__0_b7561ac [4]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[4]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[4]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_50__i_1_c68f099
  assign esc_data_p1_50__i_1_n_0_b33cc9f = ((esc_data_p2_reg_63__0_b7561ac [50]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[50]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[50]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_51__i_1_e252a33
  assign esc_data_p1_51__i_1_n_0_d871838 = ((esc_data_p2_reg_63__0_b7561ac [51]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[51]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[51]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_52__i_1_5c3772a
  assign esc_data_p1_52__i_1_n_0_a58d446 = ((esc_data_p2_reg_63__0_b7561ac [52]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[52]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[52]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_53__i_1_587caac
  assign esc_data_p1_53__i_1_n_0_a996e37 = ((esc_data_p2_reg_63__0_b7561ac [53]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[53]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[53]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_54__i_1_e47146f
  assign esc_data_p1_54__i_1_n_0_324cc70 = ((esc_data_p2_reg_63__0_b7561ac [54]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[54]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[54]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_55__i_1_a435a25
  assign esc_data_p1_55__i_1_n_0_3fd21a0 = ((esc_data_p2_reg_63__0_b7561ac [55]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[55]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[55]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_56__i_1_36f0487
  assign esc_data_p1_56__i_1_n_0_a4b574e = ((esc_data_p2_reg_63__0_b7561ac [56]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[56]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[56]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_57__i_1_6d775aa
  assign esc_data_p1_57__i_1_n_0_03d8fde = ((esc_data_p2_reg_63__0_b7561ac [57]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[57]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[57]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_58__i_1_c0b457c
  assign esc_data_p1_58__i_1_n_0_0873eb1 = ((esc_data_p2_reg_63__0_b7561ac [58]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[58]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[58]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_59__i_1_17bb6a5
  assign esc_data_p1_59__i_1_n_0_088a8ec = ((esc_data_p2_reg_63__0_b7561ac [59]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[59]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[59]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_5__i_1_3aec3fb
  assign esc_data_p1_5__i_1_n_0_044800f = ((esc_data_p2_reg_63__0_b7561ac [5]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[5]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[5]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_60__i_1_7fd5159
  assign esc_data_p1_60__i_1_n_0_5f4b7bf = ((esc_data_p2_reg_63__0_b7561ac [60]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[60]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[60]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_61__i_1_e5043a4
  assign esc_data_p1_61__i_1_n_0_14db8b8 = ((esc_data_p2_reg_63__0_b7561ac [61]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[61]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[61]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_62__i_1_ec73379
  assign esc_data_p1_62__i_1_n_0_91aed61 = ((esc_data_p2_reg_63__0_b7561ac [62]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[62]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[62]) : (1'b0))))));

  // Reconstructed LUT5: esc_data_p1_63__i_1_61c5575
  assign load_p1 = ((state__0[1]) ? (((state__0[0]) ? (1'b0) : (((rs2f_rreq_ack) ? (((Q[1]) ? (frame_ARREADY) : (1'b0))) : (1'b0))))) : (((state__0[0]) ? (rs2f_rreq_ack) : (((Q[1]) ? (frame_ARREADY) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_63__i_2_aa6e6ee
  assign esc_data_p1_63__i_2_n_0_b83484d = ((esc_data_p2_reg_63__0_b7561ac [63]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[63]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[63]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_6__i_1_e337179
  assign esc_data_p1_6__i_1_n_0_330e460 = ((esc_data_p2_reg_63__0_b7561ac [6]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[6]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[6]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_7__i_1_131d97f
  assign esc_data_p1_7__i_1_n_0_05ccbe7 = ((esc_data_p2_reg_63__0_b7561ac [7]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[7]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[7]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_8__i_1_4a01cf7
  assign esc_data_p1_8__i_1_n_0_1e2bc6c = ((esc_data_p2_reg_63__0_b7561ac [8]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[8]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[8]) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_9__i_1_8886446
  assign esc_data_p1_9__i_1_n_0_19cd207 = ((esc_data_p2_reg_63__0_b7561ac [9]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (data_p2[9]) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (data_p2[9]) : (1'b0))))));

  // Reconstructed FDRE: esc_data_p1_reg_0_91510d9
  reg recovered_73_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [0] = recovered_73_q;
  wire recovered_73_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_73_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_73_q == 1'b0))) recovered_73_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_73_q == (esc_data_p1_0__i_1_n_0_7dcfe44)))) recovered_73_q <= (esc_data_p1_0__i_1_n_0_7dcfe44);
  end

  // Reconstructed FDRE: esc_data_p1_reg_10_b99998e
  reg recovered_74_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [10] = recovered_74_q;
  wire recovered_74_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_74_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_74_q == 1'b0))) recovered_74_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_74_q == (esc_data_p1_10__i_1_n_0_b7b73af)))) recovered_74_q <= (esc_data_p1_10__i_1_n_0_b7b73af);
  end

  // Reconstructed FDRE: esc_data_p1_reg_11_1b83162
  reg recovered_75_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [11] = recovered_75_q;
  wire recovered_75_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_75_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_75_q == 1'b0))) recovered_75_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_75_q == (esc_data_p1_11__i_1_n_0_708c194)))) recovered_75_q <= (esc_data_p1_11__i_1_n_0_708c194);
  end

  // Reconstructed FDRE: esc_data_p1_reg_12_96523bc
  reg recovered_76_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [12] = recovered_76_q;
  wire recovered_76_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_76_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_76_q == 1'b0))) recovered_76_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_76_q == (esc_data_p1_12__i_1_n_0_792d5c4)))) recovered_76_q <= (esc_data_p1_12__i_1_n_0_792d5c4);
  end

  // Reconstructed FDRE: esc_data_p1_reg_13_0d69515
  reg recovered_77_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [13] = recovered_77_q;
  wire recovered_77_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_77_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_77_q == 1'b0))) recovered_77_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_77_q == (esc_data_p1_13__i_1_n_0_2c91847)))) recovered_77_q <= (esc_data_p1_13__i_1_n_0_2c91847);
  end

  // Reconstructed FDRE: esc_data_p1_reg_14_40953fa
  reg recovered_78_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [14] = recovered_78_q;
  wire recovered_78_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_78_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_78_q == 1'b0))) recovered_78_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_78_q == (esc_data_p1_14__i_1_n_0_4403616)))) recovered_78_q <= (esc_data_p1_14__i_1_n_0_4403616);
  end

  // Reconstructed FDRE: esc_data_p1_reg_15_9ed2026
  reg recovered_79_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [15] = recovered_79_q;
  wire recovered_79_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_79_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_79_q == 1'b0))) recovered_79_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_79_q == (esc_data_p1_15__i_1_n_0_dd5fdfd)))) recovered_79_q <= (esc_data_p1_15__i_1_n_0_dd5fdfd);
  end

  // Reconstructed FDRE: esc_data_p1_reg_16_6dd0cb2
  reg recovered_80_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [16] = recovered_80_q;
  wire recovered_80_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_80_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_80_q == 1'b0))) recovered_80_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_80_q == (esc_data_p1_16__i_1_n_0_5f42dca)))) recovered_80_q <= (esc_data_p1_16__i_1_n_0_5f42dca);
  end

  // Reconstructed FDRE: esc_data_p1_reg_17_da0fb0e
  reg recovered_81_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [17] = recovered_81_q;
  wire recovered_81_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_81_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_81_q == 1'b0))) recovered_81_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_81_q == (esc_data_p1_17__i_1_n_0_c83f426)))) recovered_81_q <= (esc_data_p1_17__i_1_n_0_c83f426);
  end

  // Reconstructed FDRE: esc_data_p1_reg_18_e139988
  reg recovered_82_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [18] = recovered_82_q;
  wire recovered_82_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_82_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_82_q == 1'b0))) recovered_82_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_82_q == (esc_data_p1_18__i_1_n_0_7701074)))) recovered_82_q <= (esc_data_p1_18__i_1_n_0_7701074);
  end

  // Reconstructed FDRE: esc_data_p1_reg_19_89de483
  reg recovered_83_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [19] = recovered_83_q;
  wire recovered_83_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_83_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_83_q == 1'b0))) recovered_83_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_83_q == (esc_data_p1_19__i_1_n_0_a985fc1)))) recovered_83_q <= (esc_data_p1_19__i_1_n_0_a985fc1);
  end

  // Reconstructed FDRE: esc_data_p1_reg_1_70ed420
  reg recovered_84_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [1] = recovered_84_q;
  wire recovered_84_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_84_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_84_q == 1'b0))) recovered_84_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_84_q == (esc_data_p1_1__i_1_n_0_049b0db)))) recovered_84_q <= (esc_data_p1_1__i_1_n_0_049b0db);
  end

  // Reconstructed FDRE: esc_data_p1_reg_20_35bac97
  reg recovered_85_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [20] = recovered_85_q;
  wire recovered_85_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_85_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_85_q == 1'b0))) recovered_85_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_85_q == (esc_data_p1_20__i_1_n_0_cc4220b)))) recovered_85_q <= (esc_data_p1_20__i_1_n_0_cc4220b);
  end

  // Reconstructed FDRE: esc_data_p1_reg_21_1245b5c
  reg recovered_86_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [21] = recovered_86_q;
  wire recovered_86_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_86_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_86_q == 1'b0))) recovered_86_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_86_q == (esc_data_p1_21__i_1_n_0_09504a0)))) recovered_86_q <= (esc_data_p1_21__i_1_n_0_09504a0);
  end

  // Reconstructed FDRE: esc_data_p1_reg_22_8639ba0
  reg recovered_87_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [22] = recovered_87_q;
  wire recovered_87_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_87_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_87_q == 1'b0))) recovered_87_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_87_q == (esc_data_p1_22__i_1_n_0_7c1e19e)))) recovered_87_q <= (esc_data_p1_22__i_1_n_0_7c1e19e);
  end

  // Reconstructed FDRE: esc_data_p1_reg_23_102c188
  reg recovered_88_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [23] = recovered_88_q;
  wire recovered_88_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_88_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_88_q == 1'b0))) recovered_88_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_88_q == (esc_data_p1_23__i_1_n_0_3811def)))) recovered_88_q <= (esc_data_p1_23__i_1_n_0_3811def);
  end

  // Reconstructed FDRE: esc_data_p1_reg_24_4de98a5
  reg recovered_89_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [24] = recovered_89_q;
  wire recovered_89_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_89_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_89_q == 1'b0))) recovered_89_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_89_q == (esc_data_p1_24__i_1_n_0_d85cddd)))) recovered_89_q <= (esc_data_p1_24__i_1_n_0_d85cddd);
  end

  // Reconstructed FDRE: esc_data_p1_reg_25_7e72b74
  reg recovered_90_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [25] = recovered_90_q;
  wire recovered_90_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_90_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_90_q == 1'b0))) recovered_90_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_90_q == (esc_data_p1_25__i_1_n_0_5e66e7e)))) recovered_90_q <= (esc_data_p1_25__i_1_n_0_5e66e7e);
  end

  // Reconstructed FDRE: esc_data_p1_reg_26_9845396
  reg recovered_91_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [26] = recovered_91_q;
  wire recovered_91_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_91_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_91_q == 1'b0))) recovered_91_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_91_q == (esc_data_p1_26__i_1_n_0_de65112)))) recovered_91_q <= (esc_data_p1_26__i_1_n_0_de65112);
  end

  // Reconstructed FDRE: esc_data_p1_reg_27_7634f47
  reg recovered_92_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [27] = recovered_92_q;
  wire recovered_92_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_92_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_92_q == 1'b0))) recovered_92_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_92_q == (esc_data_p1_27__i_1_n_0_42ebbcb)))) recovered_92_q <= (esc_data_p1_27__i_1_n_0_42ebbcb);
  end

  // Reconstructed FDRE: esc_data_p1_reg_28_516b5d9
  reg recovered_93_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [28] = recovered_93_q;
  wire recovered_93_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_93_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_93_q == 1'b0))) recovered_93_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_93_q == (esc_data_p1_28__i_1_n_0_241c139)))) recovered_93_q <= (esc_data_p1_28__i_1_n_0_241c139);
  end

  // Reconstructed FDRE: esc_data_p1_reg_29_818ed37
  reg recovered_94_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [29] = recovered_94_q;
  wire recovered_94_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_94_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_94_q == 1'b0))) recovered_94_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_94_q == (esc_data_p1_29__i_1_n_0_f236ad3)))) recovered_94_q <= (esc_data_p1_29__i_1_n_0_f236ad3);
  end

  // Reconstructed FDRE: esc_data_p1_reg_2_9d3c15b
  reg recovered_95_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [2] = recovered_95_q;
  wire recovered_95_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_95_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_95_q == 1'b0))) recovered_95_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_95_q == (esc_data_p1_2__i_1_n_0_2cab8b2)))) recovered_95_q <= (esc_data_p1_2__i_1_n_0_2cab8b2);
  end

  // Reconstructed FDRE: esc_data_p1_reg_30_f57e427
  reg recovered_96_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [30] = recovered_96_q;
  wire recovered_96_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_96_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_96_q == 1'b0))) recovered_96_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_96_q == (esc_data_p1_30__i_1_n_0_586ea66)))) recovered_96_q <= (esc_data_p1_30__i_1_n_0_586ea66);
  end

  // Reconstructed FDRE: esc_data_p1_reg_31_5599d56
  reg recovered_97_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [31] = recovered_97_q;
  wire recovered_97_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_97_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_97_q == 1'b0))) recovered_97_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_97_q == (esc_data_p1_31__i_1_n_0_f901432)))) recovered_97_q <= (esc_data_p1_31__i_1_n_0_f901432);
  end

  // Reconstructed FDRE: esc_data_p1_reg_32_599eaae
  reg recovered_98_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [32] = recovered_98_q;
  wire recovered_98_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_98_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_98_q == 1'b0))) recovered_98_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_98_q == (esc_data_p1_32__i_1_n_0_c71404a)))) recovered_98_q <= (esc_data_p1_32__i_1_n_0_c71404a);
  end

  // Reconstructed FDRE: esc_data_p1_reg_33_015c8f1
  reg recovered_99_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [33] = recovered_99_q;
  wire recovered_99_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_99_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_99_q == 1'b0))) recovered_99_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_99_q == (esc_data_p1_33__i_1_n_0_fb214dd)))) recovered_99_q <= (esc_data_p1_33__i_1_n_0_fb214dd);
  end

  // Reconstructed FDRE: esc_data_p1_reg_34_340fffc
  reg recovered_100_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [34] = recovered_100_q;
  wire recovered_100_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_100_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_100_q == 1'b0))) recovered_100_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_100_q == (esc_data_p1_34__i_1_n_0_006ae63)))) recovered_100_q <= (esc_data_p1_34__i_1_n_0_006ae63);
  end

  // Reconstructed FDRE: esc_data_p1_reg_35_593bddb
  reg recovered_101_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [35] = recovered_101_q;
  wire recovered_101_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_101_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_101_q == 1'b0))) recovered_101_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_101_q == (esc_data_p1_35__i_1_n_0_d37c307)))) recovered_101_q <= (esc_data_p1_35__i_1_n_0_d37c307);
  end

  // Reconstructed FDRE: esc_data_p1_reg_36_f8c7eac
  reg recovered_102_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [36] = recovered_102_q;
  wire recovered_102_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_102_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_102_q == 1'b0))) recovered_102_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_102_q == (esc_data_p1_36__i_1_n_0_561c85f)))) recovered_102_q <= (esc_data_p1_36__i_1_n_0_561c85f);
  end

  // Reconstructed FDRE: esc_data_p1_reg_37_a884e5c
  reg recovered_103_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [37] = recovered_103_q;
  wire recovered_103_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_103_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_103_q == 1'b0))) recovered_103_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_103_q == (esc_data_p1_37__i_1_n_0_4b6f381)))) recovered_103_q <= (esc_data_p1_37__i_1_n_0_4b6f381);
  end

  // Reconstructed FDRE: esc_data_p1_reg_38_a5b769f
  reg recovered_104_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [38] = recovered_104_q;
  wire recovered_104_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_104_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_104_q == 1'b0))) recovered_104_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_104_q == (esc_data_p1_38__i_1_n_0_9776359)))) recovered_104_q <= (esc_data_p1_38__i_1_n_0_9776359);
  end

  // Reconstructed FDRE: esc_data_p1_reg_39_7dfc81d
  reg recovered_105_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [39] = recovered_105_q;
  wire recovered_105_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_105_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_105_q == 1'b0))) recovered_105_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_105_q == (esc_data_p1_39__i_1_n_0_c8b2b6b)))) recovered_105_q <= (esc_data_p1_39__i_1_n_0_c8b2b6b);
  end

  // Reconstructed FDRE: esc_data_p1_reg_3_1b46385
  reg recovered_106_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [3] = recovered_106_q;
  wire recovered_106_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_106_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_106_q == 1'b0))) recovered_106_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_106_q == (esc_data_p1_3__i_1_n_0_b1ab4b5)))) recovered_106_q <= (esc_data_p1_3__i_1_n_0_b1ab4b5);
  end

  // Reconstructed FDRE: esc_data_p1_reg_40_98e1b59
  reg recovered_107_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [40] = recovered_107_q;
  wire recovered_107_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_107_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_107_q == 1'b0))) recovered_107_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_107_q == (esc_data_p1_40__i_1_n_0_f45dac5)))) recovered_107_q <= (esc_data_p1_40__i_1_n_0_f45dac5);
  end

  // Reconstructed FDRE: esc_data_p1_reg_41_da9b4c6
  reg recovered_108_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [41] = recovered_108_q;
  wire recovered_108_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_108_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_108_q == 1'b0))) recovered_108_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_108_q == (esc_data_p1_41__i_1_n_0_51b9b04)))) recovered_108_q <= (esc_data_p1_41__i_1_n_0_51b9b04);
  end

  // Reconstructed FDRE: esc_data_p1_reg_42_5f2276c
  reg recovered_109_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [42] = recovered_109_q;
  wire recovered_109_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_109_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_109_q == 1'b0))) recovered_109_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_109_q == (esc_data_p1_42__i_1_n_0_ed056b6)))) recovered_109_q <= (esc_data_p1_42__i_1_n_0_ed056b6);
  end

  // Reconstructed FDRE: esc_data_p1_reg_43_a884eb6
  reg recovered_110_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [43] = recovered_110_q;
  wire recovered_110_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_110_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_110_q == 1'b0))) recovered_110_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_110_q == (esc_data_p1_43__i_1_n_0_a3e247a)))) recovered_110_q <= (esc_data_p1_43__i_1_n_0_a3e247a);
  end

  // Reconstructed FDRE: esc_data_p1_reg_44_6a87874
  reg recovered_111_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [44] = recovered_111_q;
  wire recovered_111_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_111_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_111_q == 1'b0))) recovered_111_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_111_q == (esc_data_p1_44__i_1_n_0_27544d3)))) recovered_111_q <= (esc_data_p1_44__i_1_n_0_27544d3);
  end

  // Reconstructed FDRE: esc_data_p1_reg_45_99af2a3
  reg recovered_112_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [45] = recovered_112_q;
  wire recovered_112_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_112_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_112_q == 1'b0))) recovered_112_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_112_q == (esc_data_p1_45__i_1_n_0_ef32cb8)))) recovered_112_q <= (esc_data_p1_45__i_1_n_0_ef32cb8);
  end

  // Reconstructed FDRE: esc_data_p1_reg_46_87eac4b
  reg recovered_113_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [46] = recovered_113_q;
  wire recovered_113_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_113_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_113_q == 1'b0))) recovered_113_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_113_q == (esc_data_p1_46__i_1_n_0_77705be)))) recovered_113_q <= (esc_data_p1_46__i_1_n_0_77705be);
  end

  // Reconstructed FDRE: esc_data_p1_reg_47_5bd7eaa
  reg recovered_114_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [47] = recovered_114_q;
  wire recovered_114_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_114_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_114_q == 1'b0))) recovered_114_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_114_q == (esc_data_p1_47__i_1_n_0_5fbb7a3)))) recovered_114_q <= (esc_data_p1_47__i_1_n_0_5fbb7a3);
  end

  // Reconstructed FDRE: esc_data_p1_reg_48_f41191e
  reg recovered_115_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [48] = recovered_115_q;
  wire recovered_115_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_115_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_115_q == 1'b0))) recovered_115_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_115_q == (esc_data_p1_48__i_1_n_0_c50166b)))) recovered_115_q <= (esc_data_p1_48__i_1_n_0_c50166b);
  end

  // Reconstructed FDRE: esc_data_p1_reg_49_f0a21ba
  reg recovered_116_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [49] = recovered_116_q;
  wire recovered_116_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_116_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_116_q == 1'b0))) recovered_116_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_116_q == (esc_data_p1_49__i_1_n_0_7bab114)))) recovered_116_q <= (esc_data_p1_49__i_1_n_0_7bab114);
  end

  // Reconstructed FDRE: esc_data_p1_reg_4_edde18b
  reg recovered_117_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [4] = recovered_117_q;
  wire recovered_117_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_117_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_117_q == 1'b0))) recovered_117_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_117_q == (esc_data_p1_4__i_1_n_0_e45c5db)))) recovered_117_q <= (esc_data_p1_4__i_1_n_0_e45c5db);
  end

  // Reconstructed FDRE: esc_data_p1_reg_50_e525f0f
  reg recovered_118_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [50] = recovered_118_q;
  wire recovered_118_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_118_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_118_q == 1'b0))) recovered_118_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_118_q == (esc_data_p1_50__i_1_n_0_b33cc9f)))) recovered_118_q <= (esc_data_p1_50__i_1_n_0_b33cc9f);
  end

  // Reconstructed FDRE: esc_data_p1_reg_51_8ae63b0
  reg recovered_119_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [51] = recovered_119_q;
  wire recovered_119_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_119_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_119_q == 1'b0))) recovered_119_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_119_q == (esc_data_p1_51__i_1_n_0_d871838)))) recovered_119_q <= (esc_data_p1_51__i_1_n_0_d871838);
  end

  // Reconstructed FDRE: esc_data_p1_reg_52_d0ab373
  reg recovered_120_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [52] = recovered_120_q;
  wire recovered_120_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_120_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_120_q == 1'b0))) recovered_120_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_120_q == (esc_data_p1_52__i_1_n_0_a58d446)))) recovered_120_q <= (esc_data_p1_52__i_1_n_0_a58d446);
  end

  // Reconstructed FDRE: esc_data_p1_reg_53_d932ad2
  reg recovered_121_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [53] = recovered_121_q;
  wire recovered_121_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_121_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_121_q == 1'b0))) recovered_121_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_121_q == (esc_data_p1_53__i_1_n_0_a996e37)))) recovered_121_q <= (esc_data_p1_53__i_1_n_0_a996e37);
  end

  // Reconstructed FDRE: esc_data_p1_reg_54_2cd75bb
  reg recovered_122_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [54] = recovered_122_q;
  wire recovered_122_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_122_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_122_q == 1'b0))) recovered_122_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_122_q == (esc_data_p1_54__i_1_n_0_324cc70)))) recovered_122_q <= (esc_data_p1_54__i_1_n_0_324cc70);
  end

  // Reconstructed FDRE: esc_data_p1_reg_55_c04b6c4
  reg recovered_123_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [55] = recovered_123_q;
  wire recovered_123_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_123_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_123_q == 1'b0))) recovered_123_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_123_q == (esc_data_p1_55__i_1_n_0_3fd21a0)))) recovered_123_q <= (esc_data_p1_55__i_1_n_0_3fd21a0);
  end

  // Reconstructed FDRE: esc_data_p1_reg_56_55a557b
  reg recovered_124_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [56] = recovered_124_q;
  wire recovered_124_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_124_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_124_q == 1'b0))) recovered_124_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_124_q == (esc_data_p1_56__i_1_n_0_a4b574e)))) recovered_124_q <= (esc_data_p1_56__i_1_n_0_a4b574e);
  end

  // Reconstructed FDRE: esc_data_p1_reg_57_beea773
  reg recovered_125_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [57] = recovered_125_q;
  wire recovered_125_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_125_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_125_q == 1'b0))) recovered_125_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_125_q == (esc_data_p1_57__i_1_n_0_03d8fde)))) recovered_125_q <= (esc_data_p1_57__i_1_n_0_03d8fde);
  end

  // Reconstructed FDRE: esc_data_p1_reg_58_a8276af
  reg recovered_126_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [58] = recovered_126_q;
  wire recovered_126_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_126_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_126_q == 1'b0))) recovered_126_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_126_q == (esc_data_p1_58__i_1_n_0_0873eb1)))) recovered_126_q <= (esc_data_p1_58__i_1_n_0_0873eb1);
  end

  // Reconstructed FDRE: esc_data_p1_reg_59_7a7e4d4
  reg recovered_127_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [59] = recovered_127_q;
  wire recovered_127_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_127_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_127_q == 1'b0))) recovered_127_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_127_q == (esc_data_p1_59__i_1_n_0_088a8ec)))) recovered_127_q <= (esc_data_p1_59__i_1_n_0_088a8ec);
  end

  // Reconstructed FDRE: esc_data_p1_reg_5_2278d12
  reg recovered_128_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [5] = recovered_128_q;
  wire recovered_128_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_128_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_128_q == 1'b0))) recovered_128_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_128_q == (esc_data_p1_5__i_1_n_0_044800f)))) recovered_128_q <= (esc_data_p1_5__i_1_n_0_044800f);
  end

  // Reconstructed FDRE: esc_data_p1_reg_60_80f7dc5
  reg recovered_129_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [60] = recovered_129_q;
  wire recovered_129_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_129_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_129_q == 1'b0))) recovered_129_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_129_q == (esc_data_p1_60__i_1_n_0_5f4b7bf)))) recovered_129_q <= (esc_data_p1_60__i_1_n_0_5f4b7bf);
  end

  // Reconstructed FDRE: esc_data_p1_reg_61_0cb8739
  reg recovered_130_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [61] = recovered_130_q;
  wire recovered_130_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_130_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_130_q == 1'b0))) recovered_130_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_130_q == (esc_data_p1_61__i_1_n_0_14db8b8)))) recovered_130_q <= (esc_data_p1_61__i_1_n_0_14db8b8);
  end

  // Reconstructed FDRE: esc_data_p1_reg_62_672f733
  reg recovered_131_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [62] = recovered_131_q;
  wire recovered_131_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_131_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_131_q == 1'b0))) recovered_131_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_131_q == (esc_data_p1_62__i_1_n_0_91aed61)))) recovered_131_q <= (esc_data_p1_62__i_1_n_0_91aed61);
  end

  // Reconstructed FDRE: esc_data_p1_reg_63_18d2a48
  reg recovered_132_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [63] = recovered_132_q;
  wire recovered_132_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_132_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_132_q == 1'b0))) recovered_132_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_132_q == (esc_data_p1_63__i_2_n_0_b83484d)))) recovered_132_q <= (esc_data_p1_63__i_2_n_0_b83484d);
  end

  // Reconstructed FDRE: esc_data_p1_reg_6_f08fb72
  reg recovered_133_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [6] = recovered_133_q;
  wire recovered_133_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_133_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_133_q == 1'b0))) recovered_133_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_133_q == (esc_data_p1_6__i_1_n_0_330e460)))) recovered_133_q <= (esc_data_p1_6__i_1_n_0_330e460);
  end

  // Reconstructed FDRE: esc_data_p1_reg_7_98a71bc
  reg recovered_134_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [7] = recovered_134_q;
  wire recovered_134_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_134_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_134_q == 1'b0))) recovered_134_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_134_q == (esc_data_p1_7__i_1_n_0_05ccbe7)))) recovered_134_q <= (esc_data_p1_7__i_1_n_0_05ccbe7);
  end

  // Reconstructed FDRE: esc_data_p1_reg_8_3a36cac
  reg recovered_135_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [8] = recovered_135_q;
  wire recovered_135_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_135_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_135_q == 1'b0))) recovered_135_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_135_q == (esc_data_p1_8__i_1_n_0_1e2bc6c)))) recovered_135_q <= (esc_data_p1_8__i_1_n_0_1e2bc6c);
  end

  // Reconstructed FDRE: esc_data_p1_reg_9_9c5afbd
  reg recovered_136_q = 1'b0;
  assign esc_data_p1_reg_63__0_517eda5 [9] = recovered_136_q;
  wire recovered_136_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_136_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_136_q == 1'b0))) recovered_136_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_136_q == (esc_data_p1_9__i_1_n_0_19cd207)))) recovered_136_q <= (esc_data_p1_9__i_1_n_0_19cd207);
  end

  // Reconstructed LUT2: esc_data_p2_63__i_1_374e5b6
  assign D[1] = ((frame_ARREADY) ? (Q[1]) : (1'b0));

  // Reconstructed FDRE: esc_data_p2_reg_0_abd518c
  reg recovered_138_q = 1'b0;
  assign data_p2[0] = recovered_138_q;
  wire recovered_138_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_138_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_138_q == 1'b0))) recovered_138_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_138_q == (esc_data_p2_reg_63__0_b7561ac [0])))) recovered_138_q <= (esc_data_p2_reg_63__0_b7561ac [0]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_10_28dcc1e
  reg recovered_139_q = 1'b0;
  assign data_p2[10] = recovered_139_q;
  wire recovered_139_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_139_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_139_q == 1'b0))) recovered_139_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_139_q == (esc_data_p2_reg_63__0_b7561ac [10])))) recovered_139_q <= (esc_data_p2_reg_63__0_b7561ac [10]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_11_81b24b5
  reg recovered_140_q = 1'b0;
  assign data_p2[11] = recovered_140_q;
  wire recovered_140_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_140_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_140_q == 1'b0))) recovered_140_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_140_q == (esc_data_p2_reg_63__0_b7561ac [11])))) recovered_140_q <= (esc_data_p2_reg_63__0_b7561ac [11]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_12_0b84e50
  reg recovered_141_q = 1'b0;
  assign data_p2[12] = recovered_141_q;
  wire recovered_141_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_141_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_141_q == 1'b0))) recovered_141_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_141_q == (esc_data_p2_reg_63__0_b7561ac [12])))) recovered_141_q <= (esc_data_p2_reg_63__0_b7561ac [12]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_13_b136b27
  reg recovered_142_q = 1'b0;
  assign data_p2[13] = recovered_142_q;
  wire recovered_142_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_142_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_142_q == 1'b0))) recovered_142_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_142_q == (esc_data_p2_reg_63__0_b7561ac [13])))) recovered_142_q <= (esc_data_p2_reg_63__0_b7561ac [13]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_14_fc71e57
  reg recovered_143_q = 1'b0;
  assign data_p2[14] = recovered_143_q;
  wire recovered_143_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_143_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_143_q == 1'b0))) recovered_143_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_143_q == (esc_data_p2_reg_63__0_b7561ac [14])))) recovered_143_q <= (esc_data_p2_reg_63__0_b7561ac [14]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_15_d01f9d0
  reg recovered_144_q = 1'b0;
  assign data_p2[15] = recovered_144_q;
  wire recovered_144_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_144_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_144_q == 1'b0))) recovered_144_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_144_q == (esc_data_p2_reg_63__0_b7561ac [15])))) recovered_144_q <= (esc_data_p2_reg_63__0_b7561ac [15]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_16_16a4fc4
  reg recovered_145_q = 1'b0;
  assign data_p2[16] = recovered_145_q;
  wire recovered_145_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_145_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_145_q == 1'b0))) recovered_145_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_145_q == (esc_data_p2_reg_63__0_b7561ac [16])))) recovered_145_q <= (esc_data_p2_reg_63__0_b7561ac [16]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_17_6dc67b6
  reg recovered_146_q = 1'b0;
  assign data_p2[17] = recovered_146_q;
  wire recovered_146_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_146_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_146_q == 1'b0))) recovered_146_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_146_q == (esc_data_p2_reg_63__0_b7561ac [17])))) recovered_146_q <= (esc_data_p2_reg_63__0_b7561ac [17]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_18_9126a82
  reg recovered_147_q = 1'b0;
  assign data_p2[18] = recovered_147_q;
  wire recovered_147_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_147_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_147_q == 1'b0))) recovered_147_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_147_q == (esc_data_p2_reg_63__0_b7561ac [18])))) recovered_147_q <= (esc_data_p2_reg_63__0_b7561ac [18]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_19_e77ec78
  reg recovered_148_q = 1'b0;
  assign data_p2[19] = recovered_148_q;
  wire recovered_148_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_148_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_148_q == 1'b0))) recovered_148_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_148_q == (esc_data_p2_reg_63__0_b7561ac [19])))) recovered_148_q <= (esc_data_p2_reg_63__0_b7561ac [19]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_1_c9ae331
  reg recovered_149_q = 1'b0;
  assign data_p2[1] = recovered_149_q;
  wire recovered_149_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_149_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_149_q == 1'b0))) recovered_149_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_149_q == (esc_data_p2_reg_63__0_b7561ac [1])))) recovered_149_q <= (esc_data_p2_reg_63__0_b7561ac [1]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_20_62776cd
  reg recovered_150_q = 1'b0;
  assign data_p2[20] = recovered_150_q;
  wire recovered_150_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_150_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_150_q == 1'b0))) recovered_150_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_150_q == (esc_data_p2_reg_63__0_b7561ac [20])))) recovered_150_q <= (esc_data_p2_reg_63__0_b7561ac [20]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_21_b6e4de8
  reg recovered_151_q = 1'b0;
  assign data_p2[21] = recovered_151_q;
  wire recovered_151_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_151_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_151_q == 1'b0))) recovered_151_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_151_q == (esc_data_p2_reg_63__0_b7561ac [21])))) recovered_151_q <= (esc_data_p2_reg_63__0_b7561ac [21]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_22_a05d5ec
  reg recovered_152_q = 1'b0;
  assign data_p2[22] = recovered_152_q;
  wire recovered_152_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_152_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_152_q == 1'b0))) recovered_152_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_152_q == (esc_data_p2_reg_63__0_b7561ac [22])))) recovered_152_q <= (esc_data_p2_reg_63__0_b7561ac [22]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_23_0d92bcf
  reg recovered_153_q = 1'b0;
  assign data_p2[23] = recovered_153_q;
  wire recovered_153_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_153_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_153_q == 1'b0))) recovered_153_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_153_q == (esc_data_p2_reg_63__0_b7561ac [23])))) recovered_153_q <= (esc_data_p2_reg_63__0_b7561ac [23]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_24_08435a2
  reg recovered_154_q = 1'b0;
  assign data_p2[24] = recovered_154_q;
  wire recovered_154_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_154_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_154_q == 1'b0))) recovered_154_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_154_q == (esc_data_p2_reg_63__0_b7561ac [24])))) recovered_154_q <= (esc_data_p2_reg_63__0_b7561ac [24]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_25_bc3deb4
  reg recovered_155_q = 1'b0;
  assign data_p2[25] = recovered_155_q;
  wire recovered_155_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_155_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_155_q == 1'b0))) recovered_155_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_155_q == (esc_data_p2_reg_63__0_b7561ac [25])))) recovered_155_q <= (esc_data_p2_reg_63__0_b7561ac [25]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_26_26fcb01
  reg recovered_156_q = 1'b0;
  assign data_p2[26] = recovered_156_q;
  wire recovered_156_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_156_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_156_q == 1'b0))) recovered_156_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_156_q == (esc_data_p2_reg_63__0_b7561ac [26])))) recovered_156_q <= (esc_data_p2_reg_63__0_b7561ac [26]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_27_c5e60b1
  reg recovered_157_q = 1'b0;
  assign data_p2[27] = recovered_157_q;
  wire recovered_157_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_157_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_157_q == 1'b0))) recovered_157_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_157_q == (esc_data_p2_reg_63__0_b7561ac [27])))) recovered_157_q <= (esc_data_p2_reg_63__0_b7561ac [27]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_28_e572bf1
  reg recovered_158_q = 1'b0;
  assign data_p2[28] = recovered_158_q;
  wire recovered_158_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_158_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_158_q == 1'b0))) recovered_158_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_158_q == (esc_data_p2_reg_63__0_b7561ac [28])))) recovered_158_q <= (esc_data_p2_reg_63__0_b7561ac [28]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_29_1986c76
  reg recovered_159_q = 1'b0;
  assign data_p2[29] = recovered_159_q;
  wire recovered_159_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_159_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_159_q == 1'b0))) recovered_159_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_159_q == (esc_data_p2_reg_63__0_b7561ac [29])))) recovered_159_q <= (esc_data_p2_reg_63__0_b7561ac [29]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_2_e90455c
  reg recovered_160_q = 1'b0;
  assign data_p2[2] = recovered_160_q;
  wire recovered_160_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_160_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_160_q == 1'b0))) recovered_160_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_160_q == (esc_data_p2_reg_63__0_b7561ac [2])))) recovered_160_q <= (esc_data_p2_reg_63__0_b7561ac [2]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_30_6df1d7f
  reg recovered_161_q = 1'b0;
  assign data_p2[30] = recovered_161_q;
  wire recovered_161_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_161_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_161_q == 1'b0))) recovered_161_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_161_q == (esc_data_p2_reg_63__0_b7561ac [30])))) recovered_161_q <= (esc_data_p2_reg_63__0_b7561ac [30]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_31_ba6b1b9
  reg recovered_162_q = 1'b0;
  assign data_p2[31] = recovered_162_q;
  wire recovered_162_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_162_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_162_q == 1'b0))) recovered_162_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_162_q == (esc_data_p2_reg_63__0_b7561ac [31])))) recovered_162_q <= (esc_data_p2_reg_63__0_b7561ac [31]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_32_569cc27
  reg recovered_163_q = 1'b0;
  assign data_p2[32] = recovered_163_q;
  wire recovered_163_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_163_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_163_q == 1'b0))) recovered_163_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_163_q == (esc_data_p2_reg_63__0_b7561ac [32])))) recovered_163_q <= (esc_data_p2_reg_63__0_b7561ac [32]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_33_52e8db9
  reg recovered_164_q = 1'b0;
  assign data_p2[33] = recovered_164_q;
  wire recovered_164_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_164_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_164_q == 1'b0))) recovered_164_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_164_q == (esc_data_p2_reg_63__0_b7561ac [33])))) recovered_164_q <= (esc_data_p2_reg_63__0_b7561ac [33]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_34_f5172ca
  reg recovered_165_q = 1'b0;
  assign data_p2[34] = recovered_165_q;
  wire recovered_165_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_165_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_165_q == 1'b0))) recovered_165_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_165_q == (esc_data_p2_reg_63__0_b7561ac [34])))) recovered_165_q <= (esc_data_p2_reg_63__0_b7561ac [34]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_35_d475c0f
  reg recovered_166_q = 1'b0;
  assign data_p2[35] = recovered_166_q;
  wire recovered_166_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_166_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_166_q == 1'b0))) recovered_166_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_166_q == (esc_data_p2_reg_63__0_b7561ac [35])))) recovered_166_q <= (esc_data_p2_reg_63__0_b7561ac [35]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_36_79ca344
  reg recovered_167_q = 1'b0;
  assign data_p2[36] = recovered_167_q;
  wire recovered_167_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_167_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_167_q == 1'b0))) recovered_167_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_167_q == (esc_data_p2_reg_63__0_b7561ac [36])))) recovered_167_q <= (esc_data_p2_reg_63__0_b7561ac [36]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_37_b8cb6c5
  reg recovered_168_q = 1'b0;
  assign data_p2[37] = recovered_168_q;
  wire recovered_168_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_168_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_168_q == 1'b0))) recovered_168_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_168_q == (esc_data_p2_reg_63__0_b7561ac [37])))) recovered_168_q <= (esc_data_p2_reg_63__0_b7561ac [37]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_38_a06ed62
  reg recovered_169_q = 1'b0;
  assign data_p2[38] = recovered_169_q;
  wire recovered_169_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_169_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_169_q == 1'b0))) recovered_169_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_169_q == (esc_data_p2_reg_63__0_b7561ac [38])))) recovered_169_q <= (esc_data_p2_reg_63__0_b7561ac [38]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_39_cf69139
  reg recovered_170_q = 1'b0;
  assign data_p2[39] = recovered_170_q;
  wire recovered_170_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_170_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_170_q == 1'b0))) recovered_170_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_170_q == (esc_data_p2_reg_63__0_b7561ac [39])))) recovered_170_q <= (esc_data_p2_reg_63__0_b7561ac [39]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_3_900e4b0
  reg recovered_171_q = 1'b0;
  assign data_p2[3] = recovered_171_q;
  wire recovered_171_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_171_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_171_q == 1'b0))) recovered_171_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_171_q == (esc_data_p2_reg_63__0_b7561ac [3])))) recovered_171_q <= (esc_data_p2_reg_63__0_b7561ac [3]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_40_8c35b2b
  reg recovered_172_q = 1'b0;
  assign data_p2[40] = recovered_172_q;
  wire recovered_172_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_172_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_172_q == 1'b0))) recovered_172_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_172_q == (esc_data_p2_reg_63__0_b7561ac [40])))) recovered_172_q <= (esc_data_p2_reg_63__0_b7561ac [40]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_41_84fc704
  reg recovered_173_q = 1'b0;
  assign data_p2[41] = recovered_173_q;
  wire recovered_173_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_173_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_173_q == 1'b0))) recovered_173_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_173_q == (esc_data_p2_reg_63__0_b7561ac [41])))) recovered_173_q <= (esc_data_p2_reg_63__0_b7561ac [41]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_42_2807320
  reg recovered_174_q = 1'b0;
  assign data_p2[42] = recovered_174_q;
  wire recovered_174_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_174_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_174_q == 1'b0))) recovered_174_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_174_q == (esc_data_p2_reg_63__0_b7561ac [42])))) recovered_174_q <= (esc_data_p2_reg_63__0_b7561ac [42]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_43_c089859
  reg recovered_175_q = 1'b0;
  assign data_p2[43] = recovered_175_q;
  wire recovered_175_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_175_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_175_q == 1'b0))) recovered_175_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_175_q == (esc_data_p2_reg_63__0_b7561ac [43])))) recovered_175_q <= (esc_data_p2_reg_63__0_b7561ac [43]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_44_bda247d
  reg recovered_176_q = 1'b0;
  assign data_p2[44] = recovered_176_q;
  wire recovered_176_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_176_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_176_q == 1'b0))) recovered_176_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_176_q == (esc_data_p2_reg_63__0_b7561ac [44])))) recovered_176_q <= (esc_data_p2_reg_63__0_b7561ac [44]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_45_f4e0130
  reg recovered_177_q = 1'b0;
  assign data_p2[45] = recovered_177_q;
  wire recovered_177_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_177_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_177_q == 1'b0))) recovered_177_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_177_q == (esc_data_p2_reg_63__0_b7561ac [45])))) recovered_177_q <= (esc_data_p2_reg_63__0_b7561ac [45]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_46_1754e2e
  reg recovered_178_q = 1'b0;
  assign data_p2[46] = recovered_178_q;
  wire recovered_178_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_178_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_178_q == 1'b0))) recovered_178_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_178_q == (esc_data_p2_reg_63__0_b7561ac [46])))) recovered_178_q <= (esc_data_p2_reg_63__0_b7561ac [46]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_47_12c6fa9
  reg recovered_179_q = 1'b0;
  assign data_p2[47] = recovered_179_q;
  wire recovered_179_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_179_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_179_q == 1'b0))) recovered_179_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_179_q == (esc_data_p2_reg_63__0_b7561ac [47])))) recovered_179_q <= (esc_data_p2_reg_63__0_b7561ac [47]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_48_f1235f4
  reg recovered_180_q = 1'b0;
  assign data_p2[48] = recovered_180_q;
  wire recovered_180_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_180_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_180_q == 1'b0))) recovered_180_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_180_q == (esc_data_p2_reg_63__0_b7561ac [48])))) recovered_180_q <= (esc_data_p2_reg_63__0_b7561ac [48]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_49_cb484a5
  reg recovered_181_q = 1'b0;
  assign data_p2[49] = recovered_181_q;
  wire recovered_181_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_181_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_181_q == 1'b0))) recovered_181_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_181_q == (esc_data_p2_reg_63__0_b7561ac [49])))) recovered_181_q <= (esc_data_p2_reg_63__0_b7561ac [49]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_4_5844f0b
  reg recovered_182_q = 1'b0;
  assign data_p2[4] = recovered_182_q;
  wire recovered_182_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_182_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_182_q == 1'b0))) recovered_182_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_182_q == (esc_data_p2_reg_63__0_b7561ac [4])))) recovered_182_q <= (esc_data_p2_reg_63__0_b7561ac [4]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_50_2f085e8
  reg recovered_183_q = 1'b0;
  assign data_p2[50] = recovered_183_q;
  wire recovered_183_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_183_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_183_q == 1'b0))) recovered_183_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_183_q == (esc_data_p2_reg_63__0_b7561ac [50])))) recovered_183_q <= (esc_data_p2_reg_63__0_b7561ac [50]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_51_37e75eb
  reg recovered_184_q = 1'b0;
  assign data_p2[51] = recovered_184_q;
  wire recovered_184_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_184_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_184_q == 1'b0))) recovered_184_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_184_q == (esc_data_p2_reg_63__0_b7561ac [51])))) recovered_184_q <= (esc_data_p2_reg_63__0_b7561ac [51]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_52_6328fd0
  reg recovered_185_q = 1'b0;
  assign data_p2[52] = recovered_185_q;
  wire recovered_185_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_185_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_185_q == 1'b0))) recovered_185_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_185_q == (esc_data_p2_reg_63__0_b7561ac [52])))) recovered_185_q <= (esc_data_p2_reg_63__0_b7561ac [52]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_53_8a53b8d
  reg recovered_186_q = 1'b0;
  assign data_p2[53] = recovered_186_q;
  wire recovered_186_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_186_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_186_q == 1'b0))) recovered_186_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_186_q == (esc_data_p2_reg_63__0_b7561ac [53])))) recovered_186_q <= (esc_data_p2_reg_63__0_b7561ac [53]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_54_52dfc10
  reg recovered_187_q = 1'b0;
  assign data_p2[54] = recovered_187_q;
  wire recovered_187_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_187_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_187_q == 1'b0))) recovered_187_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_187_q == (esc_data_p2_reg_63__0_b7561ac [54])))) recovered_187_q <= (esc_data_p2_reg_63__0_b7561ac [54]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_55_6e461a2
  reg recovered_188_q = 1'b0;
  assign data_p2[55] = recovered_188_q;
  wire recovered_188_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_188_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_188_q == 1'b0))) recovered_188_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_188_q == (esc_data_p2_reg_63__0_b7561ac [55])))) recovered_188_q <= (esc_data_p2_reg_63__0_b7561ac [55]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_56_87d5a8f
  reg recovered_189_q = 1'b0;
  assign data_p2[56] = recovered_189_q;
  wire recovered_189_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_189_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_189_q == 1'b0))) recovered_189_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_189_q == (esc_data_p2_reg_63__0_b7561ac [56])))) recovered_189_q <= (esc_data_p2_reg_63__0_b7561ac [56]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_57_39b7117
  reg recovered_190_q = 1'b0;
  assign data_p2[57] = recovered_190_q;
  wire recovered_190_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_190_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_190_q == 1'b0))) recovered_190_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_190_q == (esc_data_p2_reg_63__0_b7561ac [57])))) recovered_190_q <= (esc_data_p2_reg_63__0_b7561ac [57]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_58_d79ef64
  reg recovered_191_q = 1'b0;
  assign data_p2[58] = recovered_191_q;
  wire recovered_191_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_191_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_191_q == 1'b0))) recovered_191_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_191_q == (esc_data_p2_reg_63__0_b7561ac [58])))) recovered_191_q <= (esc_data_p2_reg_63__0_b7561ac [58]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_59_06a329f
  reg recovered_192_q = 1'b0;
  assign data_p2[59] = recovered_192_q;
  wire recovered_192_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_192_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_192_q == 1'b0))) recovered_192_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_192_q == (esc_data_p2_reg_63__0_b7561ac [59])))) recovered_192_q <= (esc_data_p2_reg_63__0_b7561ac [59]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_5_15309ce
  reg recovered_193_q = 1'b0;
  assign data_p2[5] = recovered_193_q;
  wire recovered_193_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_193_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_193_q == 1'b0))) recovered_193_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_193_q == (esc_data_p2_reg_63__0_b7561ac [5])))) recovered_193_q <= (esc_data_p2_reg_63__0_b7561ac [5]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_60_820782e
  reg recovered_194_q = 1'b0;
  assign data_p2[60] = recovered_194_q;
  wire recovered_194_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_194_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_194_q == 1'b0))) recovered_194_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_194_q == (esc_data_p2_reg_63__0_b7561ac [60])))) recovered_194_q <= (esc_data_p2_reg_63__0_b7561ac [60]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_61_4692f8e
  reg recovered_195_q = 1'b0;
  assign data_p2[61] = recovered_195_q;
  wire recovered_195_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_195_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_195_q == 1'b0))) recovered_195_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_195_q == (esc_data_p2_reg_63__0_b7561ac [61])))) recovered_195_q <= (esc_data_p2_reg_63__0_b7561ac [61]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_62_d4b1ba3
  reg recovered_196_q = 1'b0;
  assign data_p2[62] = recovered_196_q;
  wire recovered_196_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_196_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_196_q == 1'b0))) recovered_196_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_196_q == (esc_data_p2_reg_63__0_b7561ac [62])))) recovered_196_q <= (esc_data_p2_reg_63__0_b7561ac [62]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_63_32ca137
  reg recovered_197_q = 1'b0;
  assign data_p2[63] = recovered_197_q;
  wire recovered_197_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_197_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_197_q == 1'b0))) recovered_197_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_197_q == (esc_data_p2_reg_63__0_b7561ac [63])))) recovered_197_q <= (esc_data_p2_reg_63__0_b7561ac [63]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_6_261c300
  reg recovered_198_q = 1'b0;
  assign data_p2[6] = recovered_198_q;
  wire recovered_198_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_198_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_198_q == 1'b0))) recovered_198_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_198_q == (esc_data_p2_reg_63__0_b7561ac [6])))) recovered_198_q <= (esc_data_p2_reg_63__0_b7561ac [6]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_7_c521434
  reg recovered_199_q = 1'b0;
  assign data_p2[7] = recovered_199_q;
  wire recovered_199_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_199_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_199_q == 1'b0))) recovered_199_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_199_q == (esc_data_p2_reg_63__0_b7561ac [7])))) recovered_199_q <= (esc_data_p2_reg_63__0_b7561ac [7]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_8_8336a66
  reg recovered_200_q = 1'b0;
  assign data_p2[8] = recovered_200_q;
  wire recovered_200_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_200_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_200_q == 1'b0))) recovered_200_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_200_q == (esc_data_p2_reg_63__0_b7561ac [8])))) recovered_200_q <= (esc_data_p2_reg_63__0_b7561ac [8]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_9_02d4977
  reg recovered_201_q = 1'b0;
  assign data_p2[9] = recovered_201_q;
  wire recovered_201_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_201_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_201_q == 1'b0))) recovered_201_q <= 1'b0;
    else if ((D[1]) || ((D[1]) === 1'bz) || (((D[1]) === 1'bx) && (recovered_201_q == (esc_data_p2_reg_63__0_b7561ac [9])))) recovered_201_q <= (esc_data_p2_reg_63__0_b7561ac [9]);
  end

  // Reconstructed LUT5: s_ready_t_i_1
  assign s_ready_t_i_1_n_0 = ((state__0[0]) ? (((state__0[1]) ? (frame_ARREADY) : (((rs2f_rreq_ack) ? (1'b1) : (frame_ARREADY))))) : (((state__0[1]) ? (((rs2f_rreq_ack) ? (frame_ARREADY) : (((frame_ARREADY) ? (~(Q[1])) : (1'b0))))) : (1'b1))));

  // Reconstructed FDRE: s_ready_t_reg
  reg recovered_203_q = 1'b0;
  assign frame_ARREADY = recovered_203_q;
  wire recovered_203_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_203_reset || (((SR) === 1'bx) && (recovered_203_q == 1'b0))) recovered_203_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_203_q == (s_ready_t_i_1_n_0)))) recovered_203_q <= (s_ready_t_i_1_n_0);
  end

  // Reconstructed LUT5: esc_state_0__i_1_f2073ed
  assign esc_state_0__i_1_n_0_19586c4 = ((esc_state_reg_0__0_c93a5dd) ? (((state) ? (((rs2f_rreq_ack) ? (((Q[1]) ? (frame_ARREADY) : (1'b0))) : (1'b1))) : (1'b1))) : (((state) ? (((Q[1]) ? (frame_ARREADY) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_state_1__i_1_bc88803
  assign esc_state_1__i_1_n_0_db32706 = ((frame_ARREADY) ? (((Q[1]) ? (((rs2f_rreq_ack) ? (1'b1) : (~(esc_state_reg_0__0_c93a5dd)))) : (((rs2f_rreq_ack) ? (1'b1) : (((state) ? (1'b1) : (~(esc_state_reg_0__0_c93a5dd)))))))) : (((rs2f_rreq_ack) ? (1'b1) : (((state) ? (1'b1) : (~(esc_state_reg_0__0_c93a5dd)))))));

  // Reconstructed FDRE: esc_state_reg_0_32e4467
  reg recovered_206_q = 1'b0;
  assign esc_state_reg_0__0_c93a5dd = recovered_206_q;
  wire recovered_206_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_206_reset || (((SR) === 1'bx) && (recovered_206_q == 1'b0))) recovered_206_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_206_q == (esc_state_0__i_1_n_0_19586c4)))) recovered_206_q <= (esc_state_0__i_1_n_0_19586c4);
  end

  // Reconstructed FDSE: esc_state_reg_1_a113b56
  reg recovered_207_q = 1'b1;
  assign state = recovered_207_q;
  wire recovered_207_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_207_reset || (((SR) === 1'bx) && (recovered_207_q == 1'b1))) recovered_207_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_207_q == (esc_state_1__i_1_n_0_db32706)))) recovered_207_q <= (esc_state_1__i_1_n_0_db32706);
  end

endmodule

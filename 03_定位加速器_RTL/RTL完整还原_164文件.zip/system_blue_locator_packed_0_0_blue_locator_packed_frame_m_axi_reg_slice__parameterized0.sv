// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_frame_m_axi_reg_slice__parameterized0
   (rdata_ack_t,
    blue_counts_ce0,
    D,
    edge_counts_ce0,
    E,
    WEA,
    esc_data_p1_reg_0__0_57af63d ,
    ap_enable_reg_pp1_iter0_reg,
    esc_bus_wide_gen_ready_for_data__0_fd98e5d ,
    esc_data_p1_reg_7__0_ea91abc ,
    SR,
    ap_clk,
    ram0_reg,
    Q,
    esc_state_reg_1__0_42315d6 ,
    ap_enable_reg_pp1_iter0,
    ram0_reg_0,
    esc_ap_CS_fsm_reg_10_0d2c375 ,
    ram0_reg_1,
    esc_ap_CS_fsm_reg_11_8288f29 ,
    y_reg_22970,
    icmp_ln57_reg_6825,
    and_ln57_reg_6829,
    previous_blue_1_reg_6804,
    s_ready_t_reg_0,
    esc_data_p2_reg_7__0_29fa183 );
  output rdata_ack_t;
  output blue_counts_ce0;
  output [1:0]D;
  output edge_counts_ce0;
  output [0:0]E;
  output [0:0]WEA;
  output esc_data_p1_reg_0__0_57af63d ;
  output [0:0]ap_enable_reg_pp1_iter0_reg;
  output esc_bus_wide_gen_ready_for_data__0_fd98e5d ;
  output [6:0]esc_data_p1_reg_7__0_ea91abc ;
  input [0:0]SR;
  input ap_clk;
  input ram0_reg;
  input [2:0]Q;
  input esc_state_reg_1__0_42315d6 ;
  input ap_enable_reg_pp1_iter0;
  input ram0_reg_0;
  input esc_ap_CS_fsm_reg_10_0d2c375 ;
  input ram0_reg_1;
  input esc_ap_CS_fsm_reg_11_8288f29 ;
  input y_reg_22970;
  input icmp_ln57_reg_6825;
  input and_ln57_reg_6829;
  input previous_blue_1_reg_6804;
  input s_ready_t_reg_0;
  input [7:0]esc_data_p2_reg_7__0_29fa183 ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [1:0]D;
  wire [0:0]E;
  wire [2:0]Q;
  wire [0:0]SR;
  wire [0:0]WEA;
  wire and_ln57_reg_6829;
  wire esc_ap_CS_fsm_reg_10_0d2c375 ;
  wire esc_ap_CS_fsm_reg_11_8288f29 ;
  wire ap_clk;
  wire ap_enable_reg_pp1_iter0;
  wire [0:0]ap_enable_reg_pp1_iter0_reg;
  wire blue_counts_ce0;
  wire esc_bus_wide_gen_ready_for_data__0_fd98e5d ;
  wire esc_data_p1_0__i_1__0_n_0_d551e65 ;
  wire esc_data_p1_1__i_1__0_n_0_778eec5 ;
  wire esc_data_p1_2__i_1__0_n_0_92cea4b ;
  wire esc_data_p1_3__i_1__0_n_0_652d218 ;
  wire esc_data_p1_4__i_1__0_n_0_4d5a065 ;
  wire esc_data_p1_5__i_1__0_n_0_4d81b4d ;
  wire esc_data_p1_6__i_1__0_n_0_b0bef91 ;
  wire esc_data_p1_7__i_2_n_0_bf5893b ;
  wire esc_data_p1_reg_0__0_57af63d ;
  wire [6:0]esc_data_p1_reg_7__0_ea91abc ;
  wire [7:0]esc_data_p2_reg_7__0_29fa183 ;
  wire esc_data_p2_reg_n_0__0_2cf2cd0 ;
  wire esc_data_p2_reg_n_0__1_701210f ;
  wire esc_data_p2_reg_n_0__2_5e0e489 ;
  wire esc_data_p2_reg_n_0__3_3146d05 ;
  wire esc_data_p2_reg_n_0__4_664c2c7 ;
  wire esc_data_p2_reg_n_0__5_96afe06 ;
  wire esc_data_p2_reg_n_0__6_7be3c52 ;
  wire esc_data_p2_reg_n_0__7_d3636f4 ;
  wire edge_counts_ce0;
  wire [0:0]frame_RDATA;
  wire frame_RREADY;
  wire frame_RVALID;
  wire icmp_ln57_reg_6825;
  wire load_p1;
  wire load_p2;
  wire [1:0]next__0;
  wire previous_blue_1_reg_6804;
  wire ram0_reg;
  wire ram0_reg_0;
  wire ram0_reg_1;
  wire ram0_reg_i_36__0_n_0;
  wire rdata_ack_t;
  wire s_ready_t_i_1__0_n_0;
  wire s_ready_t_reg_0;
  wire [1:1]state;
  wire esc_state_0__i_1__0_n_0_03a30e8 ;
  wire esc_state_1__i_1__0_n_0_eb87985 ;
  wire [1:0]state__0;
  wire esc_state_reg_1__0_42315d6 ;
  wire y_reg_22970;

  // Reconstructed LUT4: esc_FSM_sequential_state_0__i_1__0_8d9ad3c
  assign next__0[0] = ((state__0[1]) ? (((state__0[0]) ? (1'b0) : (((frame_RREADY) ? (1'b0) : (s_ready_t_reg_0))))) : (((state__0[0]) ? (~(frame_RREADY)) : (1'b0))));

  // Reconstructed LUT5: esc_FSM_sequential_state_1__i_1__0_5c8ebb8
  assign next__0[1] = ((s_ready_t_reg_0) ? (((frame_RREADY) ? (((state__0[0]) ? (~(state__0[1])) : (((state__0[1]) ? (1'b1) : (rdata_ack_t))))) : (((state__0[0]) ? (1'b0) : (((state__0[1]) ? (1'b0) : (rdata_ack_t))))))) : (((frame_RREADY) ? (((state__0[0]) ? (~(state__0[1])) : (1'b0))) : (((state__0[0]) ? (1'b0) : (state__0[1]))))));

  // Reconstructed LUT4: esc_FSM_sequential_state_1__i_2_0d612f0
  assign frame_RREADY = ((ap_enable_reg_pp1_iter0) ? (((Q[1]) ? (((esc_state_reg_1__0_42315d6) ? (1'b0) : (frame_RVALID))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_FSM_sequential_state_reg_0_392f9b0
  reg recovered_4_q = 1'b0;
  assign state__0[0] = recovered_4_q;
  wire recovered_4_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_4_reset || (((SR) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (next__0[0])))) recovered_4_q <= (next__0[0]);
  end

  // Reconstructed FDRE: esc_FSM_sequential_state_reg_1_aa5780a
  reg recovered_5_q = 1'b0;
  assign state__0[1] = recovered_5_q;
  wire recovered_5_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_5_reset || (((SR) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (next__0[1])))) recovered_5_q <= (next__0[1]);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_ap_CS_fsm_10__i_1_1318831
  assign D[0] = ((esc_ap_CS_fsm_reg_10_0d2c375) ? (1'b0) : (((Q[0]) ? (1'b1) : (((Q[1]) ? (((frame_RVALID) ? (1'b0) : (((ap_enable_reg_pp1_iter0) ? (~(esc_state_reg_1__0_42315d6)) : (1'b0))))) : (1'b0))))));

  // Reconstructed LUT5: esc_ap_CS_fsm_11__i_1_74562a2
  assign D[1] = ((frame_RVALID) ? (((esc_ap_CS_fsm_reg_11_8288f29) ? (((Q[1]) ? (ap_enable_reg_pp1_iter0) : (1'b0))) : (Q[1]))) : (((esc_state_reg_1__0_42315d6) ? (((esc_ap_CS_fsm_reg_11_8288f29) ? (((Q[1]) ? (ap_enable_reg_pp1_iter0) : (1'b0))) : (Q[1]))) : (((esc_ap_CS_fsm_reg_11_8288f29) ? (1'b0) : (((Q[1]) ? (~(ap_enable_reg_pp1_iter0)) : (1'b0))))))));

  // Reconstructed LUT5: esc_blue_counts_addr_1_reg_6815_10__i_1_707d218
  assign E = ((ap_enable_reg_pp1_iter0) ? (((frame_RVALID) ? (((esc_state_reg_1__0_42315d6) ? (1'b0) : (((Q[1]) ? (frame_RDATA) : (1'b0))))) : (1'b0))) : (((esc_state_reg_1__0_42315d6) ? (1'b0) : (((Q[1]) ? (frame_RDATA) : (1'b0))))));

  // Reconstructed LUT2: esc_bus_wide_gen_len_cnt_7__i_4_c22f1d2
  assign esc_bus_wide_gen_ready_for_data__0_fd98e5d = ((s_ready_t_reg_0) ? (rdata_ack_t) : (1'b1));

  // Reconstructed LUT4: esc_data_p1_0__i_1__0_9a45328
  assign esc_data_p1_0__i_1__0_n_0_d551e65 = ((esc_data_p2_reg_7__0_29fa183 [0]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (esc_data_p2_reg_n_0__0_2cf2cd0) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (esc_data_p2_reg_n_0__0_2cf2cd0) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_1__i_1__0_72bbcf0
  assign esc_data_p1_1__i_1__0_n_0_778eec5 = ((esc_data_p2_reg_7__0_29fa183 [1]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (esc_data_p2_reg_n_0__1_701210f) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (esc_data_p2_reg_n_0__1_701210f) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_2__i_1__0_caf47e7
  assign esc_data_p1_2__i_1__0_n_0_92cea4b = ((esc_data_p2_reg_7__0_29fa183 [2]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (esc_data_p2_reg_n_0__2_5e0e489) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (esc_data_p2_reg_n_0__2_5e0e489) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_3__i_1__0_d2ae2a1
  assign esc_data_p1_3__i_1__0_n_0_652d218 = ((esc_data_p2_reg_7__0_29fa183 [3]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (esc_data_p2_reg_n_0__3_3146d05) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (esc_data_p2_reg_n_0__3_3146d05) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_4__i_1__0_812f505
  assign esc_data_p1_4__i_1__0_n_0_4d5a065 = ((esc_data_p2_reg_7__0_29fa183 [4]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (esc_data_p2_reg_n_0__4_664c2c7) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (esc_data_p2_reg_n_0__4_664c2c7) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_5__i_1__0_86167ed
  assign esc_data_p1_5__i_1__0_n_0_4d81b4d = ((esc_data_p2_reg_7__0_29fa183 [5]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (esc_data_p2_reg_n_0__5_96afe06) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (esc_data_p2_reg_n_0__5_96afe06) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_6__i_1__0_e3a25e4
  assign esc_data_p1_6__i_1__0_n_0_b0bef91 = ((esc_data_p2_reg_7__0_29fa183 [6]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (esc_data_p2_reg_n_0__6_7be3c52) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (esc_data_p2_reg_n_0__6_7be3c52) : (1'b0))))));

  // Reconstructed LUT4: esc_data_p1_7__i_1__0_e9c4551
  assign load_p1 = ((state__0[1]) ? (((state__0[0]) ? (1'b0) : (((frame_RREADY) ? (s_ready_t_reg_0) : (1'b0))))) : (((state__0[0]) ? (frame_RREADY) : (s_ready_t_reg_0))));

  // Reconstructed LUT4: esc_data_p1_7__i_2_c994bf5
  assign esc_data_p1_7__i_2_n_0_bf5893b = ((esc_data_p2_reg_7__0_29fa183 [7]) ? (((state__0[1]) ? (1'b1) : (((state__0[0]) ? (esc_data_p2_reg_n_0__7_d3636f4) : (1'b1))))) : (((state__0[1]) ? (1'b0) : (((state__0[0]) ? (esc_data_p2_reg_n_0__7_d3636f4) : (1'b0))))));

  // Reconstructed FDRE: esc_data_p1_reg_0_91510d9
  reg recovered_21_q = 1'b0;
  assign frame_RDATA = recovered_21_q;
  wire recovered_21_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_21_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_21_q == (esc_data_p1_0__i_1__0_n_0_d551e65)))) recovered_21_q <= (esc_data_p1_0__i_1__0_n_0_d551e65);
  end

  // Reconstructed FDRE: esc_data_p1_reg_1_70ed420
  reg recovered_22_q = 1'b0;
  assign esc_data_p1_reg_7__0_ea91abc [0] = recovered_22_q;
  wire recovered_22_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_22_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_22_q == (esc_data_p1_1__i_1__0_n_0_778eec5)))) recovered_22_q <= (esc_data_p1_1__i_1__0_n_0_778eec5);
  end

  // Reconstructed FDRE: esc_data_p1_reg_2_9d3c15b
  reg recovered_23_q = 1'b0;
  assign esc_data_p1_reg_7__0_ea91abc [1] = recovered_23_q;
  wire recovered_23_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_23_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_23_q == (esc_data_p1_2__i_1__0_n_0_92cea4b)))) recovered_23_q <= (esc_data_p1_2__i_1__0_n_0_92cea4b);
  end

  // Reconstructed FDRE: esc_data_p1_reg_3_1b46385
  reg recovered_24_q = 1'b0;
  assign esc_data_p1_reg_7__0_ea91abc [2] = recovered_24_q;
  wire recovered_24_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_24_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_24_q == (esc_data_p1_3__i_1__0_n_0_652d218)))) recovered_24_q <= (esc_data_p1_3__i_1__0_n_0_652d218);
  end

  // Reconstructed FDRE: esc_data_p1_reg_4_edde18b
  reg recovered_25_q = 1'b0;
  assign esc_data_p1_reg_7__0_ea91abc [3] = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_25_q == (esc_data_p1_4__i_1__0_n_0_4d5a065)))) recovered_25_q <= (esc_data_p1_4__i_1__0_n_0_4d5a065);
  end

  // Reconstructed FDRE: esc_data_p1_reg_5_2278d12
  reg recovered_26_q = 1'b0;
  assign esc_data_p1_reg_7__0_ea91abc [4] = recovered_26_q;
  wire recovered_26_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_26_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_26_q == (esc_data_p1_5__i_1__0_n_0_4d81b4d)))) recovered_26_q <= (esc_data_p1_5__i_1__0_n_0_4d81b4d);
  end

  // Reconstructed FDRE: esc_data_p1_reg_6_f08fb72
  reg recovered_27_q = 1'b0;
  assign esc_data_p1_reg_7__0_ea91abc [5] = recovered_27_q;
  wire recovered_27_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_27_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_27_q == (esc_data_p1_6__i_1__0_n_0_b0bef91)))) recovered_27_q <= (esc_data_p1_6__i_1__0_n_0_b0bef91);
  end

  // Reconstructed FDRE: esc_data_p1_reg_7_98a71bc
  reg recovered_28_q = 1'b0;
  assign esc_data_p1_reg_7__0_ea91abc [6] = recovered_28_q;
  wire recovered_28_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_28_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_28_q == (esc_data_p1_7__i_2_n_0_bf5893b)))) recovered_28_q <= (esc_data_p1_7__i_2_n_0_bf5893b);
  end

  // Reconstructed LUT2: esc_data_p2_7__i_1_ea325da
  assign load_p2 = ((rdata_ack_t) ? (s_ready_t_reg_0) : (1'b0));

  // Reconstructed FDRE: esc_data_p2_reg_0_abd518c
  reg recovered_30_q = 1'b0;
  assign esc_data_p2_reg_n_0__0_2cf2cd0 = recovered_30_q;
  wire recovered_30_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_30_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_30_q == (esc_data_p2_reg_7__0_29fa183 [0])))) recovered_30_q <= (esc_data_p2_reg_7__0_29fa183 [0]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_1_c9ae331
  reg recovered_31_q = 1'b0;
  assign esc_data_p2_reg_n_0__1_701210f = recovered_31_q;
  wire recovered_31_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_31_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_31_q == (esc_data_p2_reg_7__0_29fa183 [1])))) recovered_31_q <= (esc_data_p2_reg_7__0_29fa183 [1]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_2_e90455c
  reg recovered_32_q = 1'b0;
  assign esc_data_p2_reg_n_0__2_5e0e489 = recovered_32_q;
  wire recovered_32_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_32_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_32_q == 1'b0))) recovered_32_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_32_q == (esc_data_p2_reg_7__0_29fa183 [2])))) recovered_32_q <= (esc_data_p2_reg_7__0_29fa183 [2]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_3_900e4b0
  reg recovered_33_q = 1'b0;
  assign esc_data_p2_reg_n_0__3_3146d05 = recovered_33_q;
  wire recovered_33_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_33_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_33_q == 1'b0))) recovered_33_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_33_q == (esc_data_p2_reg_7__0_29fa183 [3])))) recovered_33_q <= (esc_data_p2_reg_7__0_29fa183 [3]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_4_5844f0b
  reg recovered_34_q = 1'b0;
  assign esc_data_p2_reg_n_0__4_664c2c7 = recovered_34_q;
  wire recovered_34_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_34_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_34_q == 1'b0))) recovered_34_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_34_q == (esc_data_p2_reg_7__0_29fa183 [4])))) recovered_34_q <= (esc_data_p2_reg_7__0_29fa183 [4]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_5_15309ce
  reg recovered_35_q = 1'b0;
  assign esc_data_p2_reg_n_0__5_96afe06 = recovered_35_q;
  wire recovered_35_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_35_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_35_q == 1'b0))) recovered_35_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_35_q == (esc_data_p2_reg_7__0_29fa183 [5])))) recovered_35_q <= (esc_data_p2_reg_7__0_29fa183 [5]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_6_261c300
  reg recovered_36_q = 1'b0;
  assign esc_data_p2_reg_n_0__6_7be3c52 = recovered_36_q;
  wire recovered_36_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_36_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_36_q == 1'b0))) recovered_36_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_36_q == (esc_data_p2_reg_7__0_29fa183 [6])))) recovered_36_q <= (esc_data_p2_reg_7__0_29fa183 [6]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_7_c521434
  reg recovered_37_q = 1'b0;
  assign esc_data_p2_reg_n_0__7_d3636f4 = recovered_37_q;
  wire recovered_37_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_37_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_37_q == 1'b0))) recovered_37_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_37_q == (esc_data_p2_reg_7__0_29fa183 [7])))) recovered_37_q <= (esc_data_p2_reg_7__0_29fa183 [7]);
  end

  // Reconstructed LUT6: esc_previous_blue_1_reg_6804_0__i_1_8b6cffa
  assign esc_data_p1_reg_0__0_57af63d = ((previous_blue_1_reg_6804) ? (((ap_enable_reg_pp1_iter0) ? (((Q[1]) ? (((esc_state_reg_1__0_42315d6) ? (1'b1) : (((frame_RVALID) ? (frame_RDATA) : (1'b1))))) : (1'b1))) : (1'b1))) : (((ap_enable_reg_pp1_iter0) ? (((Q[1]) ? (((esc_state_reg_1__0_42315d6) ? (1'b0) : (((frame_RVALID) ? (frame_RDATA) : (1'b0))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: ram0_reg_i_1
  assign blue_counts_ce0 = ((ram0_reg_0) ? (1'b1) : (((frame_RVALID) ? (((ap_enable_reg_pp1_iter0) ? (((Q[1]) ? (1'b1) : (ram0_reg))) : (ram0_reg))) : (((ap_enable_reg_pp1_iter0) ? (((esc_state_reg_1__0_42315d6) ? (((Q[1]) ? (1'b1) : (ram0_reg))) : (ram0_reg))) : (ram0_reg))))));

  // Reconstructed LUT6: ram0_reg_i_1__0
  assign edge_counts_ce0 = ((frame_RVALID) ? (((ram0_reg_1) ? (1'b1) : (((Q[2]) ? (((ap_enable_reg_pp1_iter0) ? (1'b1) : (ram0_reg))) : (ram0_reg))))) : (((esc_state_reg_1__0_42315d6) ? (((ram0_reg_1) ? (1'b1) : (((Q[2]) ? (((ap_enable_reg_pp1_iter0) ? (1'b1) : (ram0_reg))) : (ram0_reg))))) : (((ram0_reg_1) ? (((Q[2]) ? (1'b1) : (((ap_enable_reg_pp1_iter0) ? (ram0_reg) : (1'b1))))) : (((Q[2]) ? (((ap_enable_reg_pp1_iter0) ? (1'b1) : (ram0_reg))) : (ram0_reg))))))));

  // Reconstructed LUT6: ram0_reg_i_21__0
  assign WEA = ((ram0_reg_i_36__0_n_0) ? (y_reg_22970) : (((esc_ap_CS_fsm_reg_11_8288f29) ? (((Q[1]) ? (((and_ln57_reg_6829) ? (((icmp_ln57_reg_6825) ? (y_reg_22970) : (1'b1))) : (y_reg_22970))) : (y_reg_22970))) : (y_reg_22970))));

  // Reconstructed LUT3: ram0_reg_i_36__0
  assign ram0_reg_i_36__0_n_0 = ((esc_state_reg_1__0_42315d6) ? (1'b0) : (((ap_enable_reg_pp1_iter0) ? (~(frame_RVALID)) : (1'b0))));

  // Reconstructed LUT5: s_ready_t_i_1__0
  assign s_ready_t_i_1__0_n_0 = ((state__0[0]) ? (((state__0[1]) ? (rdata_ack_t) : (((rdata_ack_t) ? (1'b1) : (frame_RREADY))))) : (((state__0[1]) ? (((rdata_ack_t) ? (((frame_RREADY) ? (1'b1) : (~(s_ready_t_reg_0)))) : (1'b0))) : (1'b1))));

  // Reconstructed FDRE: s_ready_t_reg
  reg recovered_44_q = 1'b0;
  assign rdata_ack_t = recovered_44_q;
  wire recovered_44_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_44_reset || (((SR) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_44_q == (s_ready_t_i_1__0_n_0)))) recovered_44_q <= (s_ready_t_i_1__0_n_0);
  end

  // Reconstructed LUT5: esc_state_0__i_1__0_73863fc
  assign esc_state_0__i_1__0_n_0_03a30e8 = ((frame_RVALID) ? (((state) ? (((frame_RREADY) ? (s_ready_t_reg_0) : (1'b1))) : (1'b1))) : (((state) ? (((s_ready_t_reg_0) ? (rdata_ack_t) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_state_1__i_1__0_71e6288
  assign esc_state_1__i_1__0_n_0_eb87985 = ((s_ready_t_reg_0) ? (((ap_enable_reg_pp1_iter0) ? (((Q[1]) ? (((esc_state_reg_1__0_42315d6) ? (~(frame_RVALID)) : (1'b1))) : (~(frame_RVALID)))) : (~(frame_RVALID)))) : (((ap_enable_reg_pp1_iter0) ? (((Q[1]) ? (((esc_state_reg_1__0_42315d6) ? (((frame_RVALID) ? (state) : (1'b1))) : (1'b1))) : (((frame_RVALID) ? (state) : (1'b1))))) : (((frame_RVALID) ? (state) : (1'b1))))));

  // Reconstructed FDRE: esc_state_reg_0_32e4467
  reg recovered_47_q = 1'b0;
  assign frame_RVALID = recovered_47_q;
  wire recovered_47_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_47_reset || (((SR) === 1'bx) && (recovered_47_q == 1'b0))) recovered_47_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_47_q == (esc_state_0__i_1__0_n_0_03a30e8)))) recovered_47_q <= (esc_state_0__i_1__0_n_0_03a30e8);
  end

  // Reconstructed FDSE: esc_state_reg_1_a113b56
  reg recovered_48_q = 1'b1;
  assign state = recovered_48_q;
  wire recovered_48_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_48_reset || (((SR) === 1'bx) && (recovered_48_q == 1'b1))) recovered_48_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_48_q == (esc_state_1__i_1__0_n_0_eb87985)))) recovered_48_q <= (esc_state_1__i_1__0_n_0_eb87985);
  end

  // Reconstructed LUT4: esc_tmp_4_reg_6810_6__i_1_09b823d
  assign ap_enable_reg_pp1_iter0_reg = ((Q[1]) ? (((esc_state_reg_1__0_42315d6) ? (1'b0) : (((frame_RVALID) ? (1'b1) : (~(ap_enable_reg_pp1_iter0)))))) : (1'b0));

endmodule

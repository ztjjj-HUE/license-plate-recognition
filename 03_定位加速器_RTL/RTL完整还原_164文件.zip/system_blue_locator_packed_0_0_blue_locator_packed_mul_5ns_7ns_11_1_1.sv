// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1
   (D,
    esc_y_2_reg_2385_reg_3_172fc4c ,
    esc_add_ln68_reg_8723_reg_0_37d4ac7 ,
    ap_phi_mux_y_2_phi_fu_2389_p4,
    esc_y_2_reg_2385_reg_4_1138322 ,
    esc_ap_CS_fsm_reg_15_c4b990a ,
    esc_add_ln74_reg_6855_reg_8_0e33662 ,
    Q,
    esc_y_2_reg_2385_reg_0_0bfbd5b ,
    esc_y_2_reg_2385_reg_0__0_43e4a8b ,
    esc_y_2_reg_2385_reg_0__1_811c36c ,
    esc_add_ln74_reg_6855_reg_7_6b2f341 ,
    esc_mul_ln215_reg_6908_reg_5_ca59d6b );
  output [8:0]D;
  output [1:0]esc_y_2_reg_2385_reg_3_172fc4c ;
  output esc_add_ln68_reg_8723_reg_0_37d4ac7 ;
  output [0:0]ap_phi_mux_y_2_phi_fu_2389_p4;
  output esc_y_2_reg_2385_reg_4_1138322 ;
  output esc_ap_CS_fsm_reg_15_c4b990a ;
  input [3:0]esc_add_ln74_reg_6855_reg_8_0e33662 ;
  input [4:0]Q;
  input esc_y_2_reg_2385_reg_0_0bfbd5b ;
  input esc_y_2_reg_2385_reg_0__0_43e4a8b ;
  input [0:0]esc_y_2_reg_2385_reg_0__1_811c36c ;
  input [4:0]esc_add_ln74_reg_6855_reg_7_6b2f341 ;
  input esc_mul_ln215_reg_6908_reg_5_ca59d6b ;

  wire [8:0]D;
  wire [4:0]Q;
  wire esc_add_ln68_reg_8723_reg_0_37d4ac7 ;
  wire [4:0]esc_add_ln74_reg_6855_reg_7_6b2f341 ;
  wire [3:0]esc_add_ln74_reg_6855_reg_8_0e33662 ;
  wire esc_ap_CS_fsm_reg_15_c4b990a ;
  wire [0:0]ap_phi_mux_y_2_phi_fu_2389_p4;
  wire esc_mul_ln215_reg_6908_reg_5_ca59d6b ;
  wire esc_y_2_reg_2385_reg_0_0bfbd5b ;
  wire esc_y_2_reg_2385_reg_0__0_43e4a8b ;
  wire [0:0]esc_y_2_reg_2385_reg_0__1_811c36c ;
  wire [1:0]esc_y_2_reg_2385_reg_3_172fc4c ;
  wire esc_y_2_reg_2385_reg_4_1138322 ;

  system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0_7 blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0_U
       (.D(D),
        .DI(esc_y_2_reg_2385_reg_3_172fc4c [1]),
        .Q(Q),
        .esc_add_ln68_reg_8723_reg_0_37d4ac7 (esc_add_ln68_reg_8723_reg_0_37d4ac7 ),
        .esc_add_ln68_reg_8723_reg_0__0_3d80198 (ap_phi_mux_y_2_phi_fu_2389_p4),
        .esc_add_ln74_reg_6855_reg_7_6b2f341 (esc_add_ln74_reg_6855_reg_7_6b2f341 ),
        .esc_add_ln74_reg_6855_reg_8_0e33662 (esc_add_ln74_reg_6855_reg_8_0e33662 ),
        .esc_ap_CS_fsm_reg_15_c4b990a (esc_ap_CS_fsm_reg_15_c4b990a ),
        .esc_mul_ln215_reg_6908_reg_5_ca59d6b (esc_mul_ln215_reg_6908_reg_5_ca59d6b ),
        .esc_y_2_reg_2385_reg_0_0bfbd5b (esc_y_2_reg_2385_reg_0_0bfbd5b ),
        .esc_y_2_reg_2385_reg_0__0_43e4a8b (esc_y_2_reg_2385_reg_0__0_43e4a8b ),
        .esc_y_2_reg_2385_reg_0__1_811c36c (esc_y_2_reg_2385_reg_0__1_811c36c ),
        .esc_y_2_reg_2385_reg_2_11e6904 (esc_y_2_reg_2385_reg_3_172fc4c [0]),
        .esc_y_2_reg_2385_reg_4_1138322 (esc_y_2_reg_2385_reg_4_1138322 ));
endmodule

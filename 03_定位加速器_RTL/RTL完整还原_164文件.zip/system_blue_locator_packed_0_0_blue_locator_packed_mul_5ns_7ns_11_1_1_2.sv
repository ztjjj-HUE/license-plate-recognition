// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1_2
   (D,
    Q);
  output [8:0]D;
  input [4:0]Q;

  wire [8:0]D;
  wire [4:0]Q;

  system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0_6 blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0_U
       (.D(D),
        .Q(Q));
endmodule

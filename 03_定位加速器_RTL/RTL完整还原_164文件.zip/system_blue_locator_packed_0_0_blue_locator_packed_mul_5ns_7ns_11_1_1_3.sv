// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1_3
   (D,
    esc_select_ln89_1_reg_8929_reg_3_a71ff2a ,
    esc_y_3_reg_2466_reg_1_60c8b0a ,
    esc_select_ln84_1_reg_8829_reg_6_df41fac ,
    esc_icmp_ln89_reg_8917_reg_0_d4d6839 ,
    esc_add_ln90_reg_8972_reg_5_c2be608 ,
    Q,
    ap_enable_reg_pp4_iter1,
    esc_indvar_flatten15_reg_2455_reg_11_5a608fe ,
    esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33 ,
    esc_select_ln89_1_reg_8929_reg_4_6c0fd6e ,
    esc_mul_ln215_1_reg_8936_reg_0_e99c137 ,
    esc_select_ln89_reg_8921_reg_5_0d551cf ,
    esc_select_ln89_reg_8921_reg_5__0_d2a50b8 );
  output [10:0]D;
  output [1:0]esc_select_ln89_1_reg_8929_reg_3_a71ff2a ;
  output esc_y_3_reg_2466_reg_1_60c8b0a ;
  output esc_select_ln84_1_reg_8829_reg_6_df41fac ;
  output esc_icmp_ln89_reg_8917_reg_0_d4d6839 ;
  output [4:0]esc_add_ln90_reg_8972_reg_5_c2be608 ;
  input [4:0]Q;
  input ap_enable_reg_pp4_iter1;
  input [0:0]esc_indvar_flatten15_reg_2455_reg_11_5a608fe ;
  input esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33 ;
  input [4:0]esc_select_ln89_1_reg_8929_reg_4_6c0fd6e ;
  input [6:0]esc_mul_ln215_1_reg_8936_reg_0_e99c137 ;
  input [5:0]esc_select_ln89_reg_8921_reg_5_0d551cf ;
  input [5:0]esc_select_ln89_reg_8921_reg_5__0_d2a50b8 ;

  wire [10:0]D;
  wire [4:0]Q;
  wire [4:0]esc_add_ln90_reg_8972_reg_5_c2be608 ;
  wire ap_enable_reg_pp4_iter1;
  wire esc_icmp_ln89_reg_8917_reg_0_d4d6839 ;
  wire [0:0]esc_indvar_flatten15_reg_2455_reg_11_5a608fe ;
  wire esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33 ;
  wire [6:0]esc_mul_ln215_1_reg_8936_reg_0_e99c137 ;
  wire esc_select_ln84_1_reg_8829_reg_6_df41fac ;
  wire [1:0]esc_select_ln89_1_reg_8929_reg_3_a71ff2a ;
  wire [4:0]esc_select_ln89_1_reg_8929_reg_4_6c0fd6e ;
  wire [5:0]esc_select_ln89_reg_8921_reg_5_0d551cf ;
  wire [5:0]esc_select_ln89_reg_8921_reg_5__0_d2a50b8 ;
  wire esc_y_3_reg_2466_reg_1_60c8b0a ;

  system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0_5 blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0_U
       (.D(D),
        .Q(Q),
        .esc_add_ln90_reg_8972_reg_5_c2be608 (esc_add_ln90_reg_8972_reg_5_c2be608 ),
        .ap_enable_reg_pp4_iter1(ap_enable_reg_pp4_iter1),
        .esc_icmp_ln89_reg_8917_reg_0_d4d6839 (esc_icmp_ln89_reg_8917_reg_0_d4d6839 ),
        .esc_indvar_flatten15_reg_2455_reg_11_5a608fe (esc_indvar_flatten15_reg_2455_reg_11_5a608fe ),
        .esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33 (esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33 ),
        .esc_mul_ln215_1_reg_8936_reg_0_e99c137 (esc_mul_ln215_1_reg_8936_reg_0_e99c137 ),
        .esc_select_ln84_1_reg_8829_reg_6_df41fac (esc_select_ln84_1_reg_8829_reg_6_df41fac ),
        .esc_select_ln89_1_reg_8929_reg_3_a71ff2a (esc_select_ln89_1_reg_8929_reg_3_a71ff2a ),
        .esc_select_ln89_1_reg_8929_reg_4_6c0fd6e (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e ),
        .esc_select_ln89_reg_8921_reg_5_0d551cf (esc_select_ln89_reg_8921_reg_5_0d551cf ),
        .esc_select_ln89_reg_8921_reg_5__0_d2a50b8 (esc_select_ln89_reg_8921_reg_5__0_d2a50b8 ),
        .esc_y_3_reg_2466_reg_1_60c8b0a (esc_y_3_reg_2466_reg_1_60c8b0a ));
endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1_4
   (D,
    p__3_carry__0,
    zext_ln215_95_fu_6208_p1,
    Q,
    S,
    esc_add_ln215_40_reg_8942_reg_3_5256bf7 ,
    p__3_carry,
    zext_ln84_3_reg_8846);
  output [10:0]D;
  output [10:0]p__3_carry__0;
  input [6:0]zext_ln215_95_fu_6208_p1;
  input [5:0]Q;
  input [1:0]S;
  input [1:0]esc_add_ln215_40_reg_8942_reg_3_5256bf7 ;
  input [4:0]p__3_carry;
  input [3:0]zext_ln84_3_reg_8846;

  wire [10:0]D;
  wire [5:0]Q;
  wire [1:0]S;
  wire [1:0]esc_add_ln215_40_reg_8942_reg_3_5256bf7 ;
  wire [4:0]p__3_carry;
  wire [10:0]p__3_carry__0;
  wire [6:0]zext_ln215_95_fu_6208_p1;
  wire [3:0]zext_ln84_3_reg_8846;

  system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0 blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0_U
       (.D(D),
        .Q(Q),
        .S(S),
        .esc_add_ln215_40_reg_8942_reg_3_5256bf7 (esc_add_ln215_40_reg_8942_reg_3_5256bf7 ),
        .p__3_carry_0(p__3_carry),
        .p__3_carry__0_0(p__3_carry__0),
        .zext_ln215_95_fu_6208_p1(zext_ln215_95_fu_6208_p1),
        .zext_ln84_3_reg_8846(zext_ln84_3_reg_8846));
endmodule

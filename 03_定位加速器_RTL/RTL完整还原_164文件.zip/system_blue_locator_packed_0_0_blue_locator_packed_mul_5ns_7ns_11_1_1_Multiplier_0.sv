// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0
   (D,
    p__3_carry__0_0,
    zext_ln215_95_fu_6208_p1,
    Q,
    S,
    esc_add_ln215_40_reg_8942_reg_3_5256bf7 ,
    p__3_carry_0,
    zext_ln84_3_reg_8846);
  output [10:0]D;
  output [10:0]p__3_carry__0_0;
  input [6:0]zext_ln215_95_fu_6208_p1;
  input [5:0]Q;
  input [1:0]S;
  input [1:0]esc_add_ln215_40_reg_8942_reg_3_5256bf7 ;
  input [4:0]p__3_carry_0;
  input [3:0]zext_ln84_3_reg_8846;

  wire esc_const0_a0cf646 ;
  wire [10:0]D;
  wire [5:0]Q;
  wire [1:0]S;
  wire esc_add_ln215_40_reg_8942_3__i_2_n_0_8afbe2a ;
  wire esc_add_ln215_40_reg_8942_3__i_3_n_0_d3188b9 ;
  wire esc_add_ln215_40_reg_8942_7__i_2_n_0_3623efa ;
  wire esc_add_ln215_40_reg_8942_7__i_3_n_0_a5bac73 ;
  wire [1:0]esc_add_ln215_40_reg_8942_reg_3_5256bf7 ;
  wire esc_add_ln215_40_reg_8942_reg_3__i_1_n_0_d478b77 ;
  wire esc_add_ln215_40_reg_8942_reg_7__i_1_n_0_11c47f9 ;
  wire esc_add_ln215_42_reg_8957_3__i_3_n_0_66028ad ;
  wire esc_add_ln215_42_reg_8957_3__i_4_n_0_e224cd2 ;
  wire esc_add_ln215_42_reg_8957_7__i_2_n_0_0ccb5ae ;
  wire esc_add_ln215_42_reg_8957_7__i_3_n_0_b300181 ;
  wire esc_add_ln215_42_reg_8957_7__i_4_n_0_bec9c41 ;
  wire esc_add_ln215_42_reg_8957_reg_3__i_1_n_0_13233a1 ;
  wire esc_add_ln215_42_reg_8957_reg_7__i_1_n_0_1d5be88 ;
  wire [4:0]p__3_carry_0;
  wire [10:0]p__3_carry__0_0;
  wire p__3_carry__0_i_1__1_n_0;
  wire p__3_carry__0_i_2__1_n_0;
  wire p__3_carry__0_i_3__1_n_0;
  wire p__3_carry__0_i_4__1_n_0;
  wire p__3_carry__0_i_5__1_n_0;
  wire p__3_carry__0_i_6__0_n_0;
  wire p__3_carry__0_i_7_n_0;
  wire p__3_carry__0_n_0;
  wire p__3_carry__0_n_4;
  wire p__3_carry__0_n_5;
  wire p__3_carry__0_n_6;
  wire p__3_carry__0_n_7;
  wire p__3_carry__1_i_1_n_0;
  wire p__3_carry__1_n_7;
  wire p__3_carry_i_1_n_0;
  wire p__3_carry_i_2__2_n_0;
  wire p__3_carry_i_3__1_n_0;
  wire p__3_carry_i_4_n_0;
  wire p__3_carry_i_5__0_n_0;
  wire p__3_carry_i_6__0_n_0;
  wire p__3_carry_i_7_n_0;
  wire p__3_carry_n_0;
  wire p__3_carry_n_4;
  wire p__3_carry_n_5;
  wire p__3_carry_n_6;
  wire p__3_carry_n_7;
  wire [6:0]zext_ln215_95_fu_6208_p1;
  wire [3:0]zext_ln84_3_reg_8846;
  wire [3:0]esc_NLW_add_ln215_40_reg_8942_reg_3__i_1_CO_UNCONNECTED_41a8f28 ;
  wire [3:0]esc_NLW_add_ln215_40_reg_8942_reg_7__i_1_CO_UNCONNECTED_051da3e ;
  wire [3:0]esc_NLW_add_ln215_42_reg_8957_reg_3__i_1_CO_UNCONNECTED_2b388d7 ;
  wire [3:0]esc_NLW_add_ln215_42_reg_8957_reg_7__i_1_CO_UNCONNECTED_153d1bd ;
  wire [3:0]NLW_p__3_carry_CO_UNCONNECTED;
  wire [3:0]NLW_p__3_carry__0_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed LUT2: esc_add_ln215_40_reg_8942_3__i_2_e39b583
  assign esc_add_ln215_40_reg_8942_3__i_2_n_0_8afbe2a = ((Q[3]) ? (~(p__3_carry_n_6)) : (p__3_carry_n_6));

  // Reconstructed LUT2: esc_add_ln215_40_reg_8942_3__i_3_f9d9e56
  assign esc_add_ln215_40_reg_8942_3__i_3_n_0_d3188b9 = ((Q[2]) ? (~(p__3_carry_n_7)) : (p__3_carry_n_7));

  // Reconstructed LUT2: esc_add_ln215_40_reg_8942_7__i_2_285ad77
  assign esc_add_ln215_40_reg_8942_7__i_2_n_0_3623efa = ((Q[5]) ? (~(p__3_carry_n_4)) : (p__3_carry_n_4));

  // Reconstructed LUT2: esc_add_ln215_40_reg_8942_7__i_3_3e17251
  assign esc_add_ln215_40_reg_8942_7__i_3_n_0_a5bac73 = ((Q[4]) ? (~(p__3_carry_n_5)) : (p__3_carry_n_5));

  // Reconstructed CARRY4: esc_add_ln215_40_reg_8942_reg_10__i_1_838d299
  wire [3:0] recovered_6_co, recovered_6_o, recovered_6_s, recovered_6_di;
  assign recovered_6_s = {esc_const0_a0cf646 ,p__3_carry__1_n_7,p__3_carry__0_n_4,p__3_carry__0_n_5};
  assign recovered_6_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_6_ci = ((esc_add_ln215_40_reg_8942_reg_7__i_1_n_0_11c47f9) !== 1'bz) && (esc_add_ln215_40_reg_8942_reg_7__i_1_n_0_11c47f9);
  wire recovered_6_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_6_o[0] = recovered_6_s[0] ^ (recovered_6_ci || recovered_6_cy);
  assign recovered_6_co[0] = (recovered_6_s[0] & (recovered_6_ci || recovered_6_cy)) | (~recovered_6_s[0] & recovered_6_di[0]);
  assign recovered_6_o[1] = recovered_6_s[1] ^ recovered_6_co[0];
  assign recovered_6_co[1] = (recovered_6_s[1] & recovered_6_co[0]) | (~recovered_6_s[1] & recovered_6_di[1]);
  assign recovered_6_o[2] = recovered_6_s[2] ^ recovered_6_co[1];
  assign recovered_6_co[2] = (recovered_6_s[2] & recovered_6_co[1]) | (~recovered_6_s[2] & recovered_6_di[2]);
  assign recovered_6_o[3] = recovered_6_s[3] ^ recovered_6_co[2];
  assign recovered_6_co[3] = (recovered_6_s[3] & recovered_6_co[2]) | (~recovered_6_s[3] & recovered_6_di[3]);
  assign p__3_carry__0_0[10:8] = recovered_6_o;

  // Reconstructed CARRY4: esc_add_ln215_40_reg_8942_reg_3__i_1_f104764
  wire [3:0] recovered_7_co, recovered_7_o, recovered_7_s, recovered_7_di;
  assign recovered_7_s = {esc_add_ln215_40_reg_8942_3__i_2_n_0_8afbe2a ,esc_add_ln215_40_reg_8942_3__i_3_n_0_d3188b9 ,esc_add_ln215_40_reg_8942_reg_3_5256bf7 };
  assign recovered_7_di = {p__3_carry_n_6,p__3_carry_n_7,Q[1:0]};
  wire recovered_7_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_7_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_7_o[0] = recovered_7_s[0] ^ (recovered_7_ci || recovered_7_cy);
  assign recovered_7_co[0] = (recovered_7_s[0] & (recovered_7_ci || recovered_7_cy)) | (~recovered_7_s[0] & recovered_7_di[0]);
  assign recovered_7_o[1] = recovered_7_s[1] ^ recovered_7_co[0];
  assign recovered_7_co[1] = (recovered_7_s[1] & recovered_7_co[0]) | (~recovered_7_s[1] & recovered_7_di[1]);
  assign recovered_7_o[2] = recovered_7_s[2] ^ recovered_7_co[1];
  assign recovered_7_co[2] = (recovered_7_s[2] & recovered_7_co[1]) | (~recovered_7_s[2] & recovered_7_di[2]);
  assign recovered_7_o[3] = recovered_7_s[3] ^ recovered_7_co[2];
  assign recovered_7_co[3] = (recovered_7_s[3] & recovered_7_co[2]) | (~recovered_7_s[3] & recovered_7_di[3]);
  assign {esc_add_ln215_40_reg_8942_reg_3__i_1_n_0_d478b77 ,esc_NLW_add_ln215_40_reg_8942_reg_3__i_1_CO_UNCONNECTED_41a8f28 [2:0]} = recovered_7_co;
  assign p__3_carry__0_0[3:0] = recovered_7_o;

  // Reconstructed CARRY4: esc_add_ln215_40_reg_8942_reg_7__i_1_d32fb6b
  wire [3:0] recovered_8_co, recovered_8_o, recovered_8_s, recovered_8_di;
  assign recovered_8_s = {p__3_carry__0_n_6,p__3_carry__0_n_7,esc_add_ln215_40_reg_8942_7__i_2_n_0_3623efa ,esc_add_ln215_40_reg_8942_7__i_3_n_0_a5bac73 };
  assign recovered_8_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,p__3_carry_n_4,p__3_carry_n_5};
  wire recovered_8_ci = ((esc_add_ln215_40_reg_8942_reg_3__i_1_n_0_d478b77) !== 1'bz) && (esc_add_ln215_40_reg_8942_reg_3__i_1_n_0_d478b77);
  wire recovered_8_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_8_o[0] = recovered_8_s[0] ^ (recovered_8_ci || recovered_8_cy);
  assign recovered_8_co[0] = (recovered_8_s[0] & (recovered_8_ci || recovered_8_cy)) | (~recovered_8_s[0] & recovered_8_di[0]);
  assign recovered_8_o[1] = recovered_8_s[1] ^ recovered_8_co[0];
  assign recovered_8_co[1] = (recovered_8_s[1] & recovered_8_co[0]) | (~recovered_8_s[1] & recovered_8_di[1]);
  assign recovered_8_o[2] = recovered_8_s[2] ^ recovered_8_co[1];
  assign recovered_8_co[2] = (recovered_8_s[2] & recovered_8_co[1]) | (~recovered_8_s[2] & recovered_8_di[2]);
  assign recovered_8_o[3] = recovered_8_s[3] ^ recovered_8_co[2];
  assign recovered_8_co[3] = (recovered_8_s[3] & recovered_8_co[2]) | (~recovered_8_s[3] & recovered_8_di[3]);
  assign {esc_add_ln215_40_reg_8942_reg_7__i_1_n_0_11c47f9 ,esc_NLW_add_ln215_40_reg_8942_reg_7__i_1_CO_UNCONNECTED_051da3e [2:0]} = recovered_8_co;
  assign p__3_carry__0_0[7:4] = recovered_8_o;

  // Reconstructed LUT2: esc_add_ln215_42_reg_8957_3__i_3_5e03eaf
  assign esc_add_ln215_42_reg_8957_3__i_3_n_0_66028ad = ((zext_ln215_95_fu_6208_p1[3]) ? (~(p__3_carry_n_6)) : (p__3_carry_n_6));

  // Reconstructed LUT2: esc_add_ln215_42_reg_8957_3__i_4_e606315
  assign esc_add_ln215_42_reg_8957_3__i_4_n_0_e224cd2 = ((zext_ln215_95_fu_6208_p1[2]) ? (~(p__3_carry_n_7)) : (p__3_carry_n_7));

  // Reconstructed LUT2: esc_add_ln215_42_reg_8957_7__i_2_d14caa7
  assign esc_add_ln215_42_reg_8957_7__i_2_n_0_0ccb5ae = ((zext_ln215_95_fu_6208_p1[6]) ? (~(p__3_carry__0_n_7)) : (p__3_carry__0_n_7));

  // Reconstructed LUT2: esc_add_ln215_42_reg_8957_7__i_3_e18e8dc
  assign esc_add_ln215_42_reg_8957_7__i_3_n_0_b300181 = ((zext_ln215_95_fu_6208_p1[5]) ? (~(p__3_carry_n_4)) : (p__3_carry_n_4));

  // Reconstructed LUT2: esc_add_ln215_42_reg_8957_7__i_4_127848e
  assign esc_add_ln215_42_reg_8957_7__i_4_n_0_bec9c41 = ((zext_ln215_95_fu_6208_p1[4]) ? (~(p__3_carry_n_5)) : (p__3_carry_n_5));

  // Reconstructed CARRY4: esc_add_ln215_42_reg_8957_reg_10__i_1_bb14488
  wire [3:0] recovered_14_co, recovered_14_o, recovered_14_s, recovered_14_di;
  assign recovered_14_s = {esc_const0_a0cf646 ,p__3_carry__1_n_7,p__3_carry__0_n_4,p__3_carry__0_n_5};
  assign recovered_14_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_14_ci = ((esc_add_ln215_42_reg_8957_reg_7__i_1_n_0_1d5be88) !== 1'bz) && (esc_add_ln215_42_reg_8957_reg_7__i_1_n_0_1d5be88);
  wire recovered_14_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_14_o[0] = recovered_14_s[0] ^ (recovered_14_ci || recovered_14_cy);
  assign recovered_14_co[0] = (recovered_14_s[0] & (recovered_14_ci || recovered_14_cy)) | (~recovered_14_s[0] & recovered_14_di[0]);
  assign recovered_14_o[1] = recovered_14_s[1] ^ recovered_14_co[0];
  assign recovered_14_co[1] = (recovered_14_s[1] & recovered_14_co[0]) | (~recovered_14_s[1] & recovered_14_di[1]);
  assign recovered_14_o[2] = recovered_14_s[2] ^ recovered_14_co[1];
  assign recovered_14_co[2] = (recovered_14_s[2] & recovered_14_co[1]) | (~recovered_14_s[2] & recovered_14_di[2]);
  assign recovered_14_o[3] = recovered_14_s[3] ^ recovered_14_co[2];
  assign recovered_14_co[3] = (recovered_14_s[3] & recovered_14_co[2]) | (~recovered_14_s[3] & recovered_14_di[3]);
  assign D[10:8] = recovered_14_o;

  // Reconstructed CARRY4: esc_add_ln215_42_reg_8957_reg_3__i_1_78b2ced
  wire [3:0] recovered_15_co, recovered_15_o, recovered_15_s, recovered_15_di;
  assign recovered_15_s = {esc_add_ln215_42_reg_8957_3__i_3_n_0_66028ad ,esc_add_ln215_42_reg_8957_3__i_4_n_0_e224cd2 ,S};
  assign recovered_15_di = {p__3_carry_n_6,p__3_carry_n_7,zext_ln215_95_fu_6208_p1[1:0]};
  wire recovered_15_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_15_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_15_o[0] = recovered_15_s[0] ^ (recovered_15_ci || recovered_15_cy);
  assign recovered_15_co[0] = (recovered_15_s[0] & (recovered_15_ci || recovered_15_cy)) | (~recovered_15_s[0] & recovered_15_di[0]);
  assign recovered_15_o[1] = recovered_15_s[1] ^ recovered_15_co[0];
  assign recovered_15_co[1] = (recovered_15_s[1] & recovered_15_co[0]) | (~recovered_15_s[1] & recovered_15_di[1]);
  assign recovered_15_o[2] = recovered_15_s[2] ^ recovered_15_co[1];
  assign recovered_15_co[2] = (recovered_15_s[2] & recovered_15_co[1]) | (~recovered_15_s[2] & recovered_15_di[2]);
  assign recovered_15_o[3] = recovered_15_s[3] ^ recovered_15_co[2];
  assign recovered_15_co[3] = (recovered_15_s[3] & recovered_15_co[2]) | (~recovered_15_s[3] & recovered_15_di[3]);
  assign {esc_add_ln215_42_reg_8957_reg_3__i_1_n_0_13233a1 ,esc_NLW_add_ln215_42_reg_8957_reg_3__i_1_CO_UNCONNECTED_2b388d7 [2:0]} = recovered_15_co;
  assign D[3:0] = recovered_15_o;

  // Reconstructed CARRY4: esc_add_ln215_42_reg_8957_reg_7__i_1_05d96ef
  wire [3:0] recovered_16_co, recovered_16_o, recovered_16_s, recovered_16_di;
  assign recovered_16_s = {p__3_carry__0_n_6,esc_add_ln215_42_reg_8957_7__i_2_n_0_0ccb5ae ,esc_add_ln215_42_reg_8957_7__i_3_n_0_b300181 ,esc_add_ln215_42_reg_8957_7__i_4_n_0_bec9c41 };
  assign recovered_16_di = {esc_const0_a0cf646 ,p__3_carry__0_n_7,p__3_carry_n_4,p__3_carry_n_5};
  wire recovered_16_ci = ((esc_add_ln215_42_reg_8957_reg_3__i_1_n_0_13233a1) !== 1'bz) && (esc_add_ln215_42_reg_8957_reg_3__i_1_n_0_13233a1);
  wire recovered_16_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_16_o[0] = recovered_16_s[0] ^ (recovered_16_ci || recovered_16_cy);
  assign recovered_16_co[0] = (recovered_16_s[0] & (recovered_16_ci || recovered_16_cy)) | (~recovered_16_s[0] & recovered_16_di[0]);
  assign recovered_16_o[1] = recovered_16_s[1] ^ recovered_16_co[0];
  assign recovered_16_co[1] = (recovered_16_s[1] & recovered_16_co[0]) | (~recovered_16_s[1] & recovered_16_di[1]);
  assign recovered_16_o[2] = recovered_16_s[2] ^ recovered_16_co[1];
  assign recovered_16_co[2] = (recovered_16_s[2] & recovered_16_co[1]) | (~recovered_16_s[2] & recovered_16_di[2]);
  assign recovered_16_o[3] = recovered_16_s[3] ^ recovered_16_co[2];
  assign recovered_16_co[3] = (recovered_16_s[3] & recovered_16_co[2]) | (~recovered_16_s[3] & recovered_16_di[3]);
  assign {esc_add_ln215_42_reg_8957_reg_7__i_1_n_0_1d5be88 ,esc_NLW_add_ln215_42_reg_8957_reg_7__i_1_CO_UNCONNECTED_153d1bd [2:0]} = recovered_16_co;
  assign D[7:4] = recovered_16_o;

  // Reconstructed CARRY4: p__3_carry
  wire [3:0] recovered_17_co, recovered_17_o, recovered_17_s, recovered_17_di;
  assign recovered_17_s = {p__3_carry_i_3__1_n_0,p__3_carry_i_4_n_0,p__3_carry_i_5__0_n_0,p__3_carry_i_6__0_n_0};
  assign recovered_17_di = {esc_const0_a0cf646 ,p__3_carry_i_1_n_0,p__3_carry_i_2__2_n_0,esc_const0_a0cf646 };
  wire recovered_17_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_17_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_17_o[0] = recovered_17_s[0] ^ (recovered_17_ci || recovered_17_cy);
  assign recovered_17_co[0] = (recovered_17_s[0] & (recovered_17_ci || recovered_17_cy)) | (~recovered_17_s[0] & recovered_17_di[0]);
  assign recovered_17_o[1] = recovered_17_s[1] ^ recovered_17_co[0];
  assign recovered_17_co[1] = (recovered_17_s[1] & recovered_17_co[0]) | (~recovered_17_s[1] & recovered_17_di[1]);
  assign recovered_17_o[2] = recovered_17_s[2] ^ recovered_17_co[1];
  assign recovered_17_co[2] = (recovered_17_s[2] & recovered_17_co[1]) | (~recovered_17_s[2] & recovered_17_di[2]);
  assign recovered_17_o[3] = recovered_17_s[3] ^ recovered_17_co[2];
  assign recovered_17_co[3] = (recovered_17_s[3] & recovered_17_co[2]) | (~recovered_17_s[3] & recovered_17_di[3]);
  assign {p__3_carry_n_0,NLW_p__3_carry_CO_UNCONNECTED[2:0]} = recovered_17_co;
  assign {p__3_carry_n_4,p__3_carry_n_5,p__3_carry_n_6,p__3_carry_n_7} = recovered_17_o;

  // Reconstructed CARRY4: p__3_carry__0
  wire [3:0] recovered_18_co, recovered_18_o, recovered_18_s, recovered_18_di;
  assign recovered_18_s = {p__3_carry__0_i_2__1_n_0,p__3_carry__0_i_3__1_n_0,p__3_carry__0_i_4__1_n_0,p__3_carry__0_i_5__1_n_0};
  assign recovered_18_di = {esc_const0_a0cf646 ,p__3_carry__0_i_1__1_n_0,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_18_ci = ((p__3_carry_n_0) !== 1'bz) && (p__3_carry_n_0);
  wire recovered_18_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_18_o[0] = recovered_18_s[0] ^ (recovered_18_ci || recovered_18_cy);
  assign recovered_18_co[0] = (recovered_18_s[0] & (recovered_18_ci || recovered_18_cy)) | (~recovered_18_s[0] & recovered_18_di[0]);
  assign recovered_18_o[1] = recovered_18_s[1] ^ recovered_18_co[0];
  assign recovered_18_co[1] = (recovered_18_s[1] & recovered_18_co[0]) | (~recovered_18_s[1] & recovered_18_di[1]);
  assign recovered_18_o[2] = recovered_18_s[2] ^ recovered_18_co[1];
  assign recovered_18_co[2] = (recovered_18_s[2] & recovered_18_co[1]) | (~recovered_18_s[2] & recovered_18_di[2]);
  assign recovered_18_o[3] = recovered_18_s[3] ^ recovered_18_co[2];
  assign recovered_18_co[3] = (recovered_18_s[3] & recovered_18_co[2]) | (~recovered_18_s[3] & recovered_18_di[3]);
  assign {p__3_carry__0_n_0,NLW_p__3_carry__0_CO_UNCONNECTED[2:0]} = recovered_18_co;
  assign {p__3_carry__0_n_4,p__3_carry__0_n_5,p__3_carry__0_n_6,p__3_carry__0_n_7} = recovered_18_o;

  // Reconstructed LUT6: p__3_carry__0_i_1__1
  assign p__3_carry__0_i_1__1_n_0 = ((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (((p__3_carry__0_i_7_n_0) ? (((p__3_carry_i_1_n_0) ? (((p__3_carry__0_i_6__0_n_0) ? (p__3_carry_i_2__2_n_0) : (1'b1))) : (((p__3_carry__0_i_6__0_n_0) ? (1'b1) : (~(p__3_carry_i_2__2_n_0)))))) : (((p__3_carry_i_1_n_0) ? (((p__3_carry__0_i_6__0_n_0) ? (p__3_carry_i_2__2_n_0) : (~(p__3_carry_i_2__2_n_0)))) : (~(p__3_carry_i_2__2_n_0)))))) : (((p__3_carry__0_i_7_n_0) ? (((p__3_carry_i_1_n_0) ? (((p__3_carry__0_i_6__0_n_0) ? (p__3_carry_i_2__2_n_0) : (1'b1))) : (((p__3_carry__0_i_6__0_n_0) ? (p__3_carry_i_2__2_n_0) : (~(p__3_carry_i_2__2_n_0)))))) : (((p__3_carry_i_1_n_0) ? (((p__3_carry__0_i_6__0_n_0) ? (p__3_carry_i_2__2_n_0) : (~(p__3_carry_i_2__2_n_0)))) : (((p__3_carry__0_i_6__0_n_0) ? (1'b1) : (~(p__3_carry_i_2__2_n_0)))))))))) : (((p__3_carry_0[0]) ? (((p__3_carry__0_i_7_n_0) ? (((p__3_carry_i_1_n_0) ? (((p__3_carry__0_i_6__0_n_0) ? (p__3_carry_i_2__2_n_0) : (1'b1))) : (((p__3_carry__0_i_6__0_n_0) ? (p__3_carry_i_2__2_n_0) : (~(p__3_carry_i_2__2_n_0)))))) : (((p__3_carry_i_1_n_0) ? (((p__3_carry__0_i_6__0_n_0) ? (p__3_carry_i_2__2_n_0) : (~(p__3_carry_i_2__2_n_0)))) : (((p__3_carry__0_i_6__0_n_0) ? (1'b1) : (~(p__3_carry_i_2__2_n_0)))))))) : (((p__3_carry__0_i_7_n_0) ? (((p__3_carry_i_1_n_0) ? (((p__3_carry__0_i_6__0_n_0) ? (p__3_carry_i_2__2_n_0) : (1'b1))) : (((p__3_carry__0_i_6__0_n_0) ? (1'b1) : (~(p__3_carry_i_2__2_n_0)))))) : (((p__3_carry_i_1_n_0) ? (((p__3_carry__0_i_6__0_n_0) ? (p__3_carry_i_2__2_n_0) : (~(p__3_carry_i_2__2_n_0)))) : (~(p__3_carry_i_2__2_n_0)))))))));

  // Reconstructed LUT6: p__3_carry__0_i_2__1
  assign p__3_carry__0_i_2__1_n_0 = ((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (((p__3_carry_i_2__2_n_0) ? (p__3_carry_i_1_n_0) : (((p__3_carry_i_1_n_0) ? (p__3_carry__0_i_6__0_n_0) : (1'b1))))) : (((p__3_carry__0_i_7_n_0) ? (((p__3_carry_i_2__2_n_0) ? (p__3_carry_i_1_n_0) : (((p__3_carry_i_1_n_0) ? (p__3_carry__0_i_6__0_n_0) : (~(p__3_carry__0_i_6__0_n_0)))))) : (((p__3_carry_i_2__2_n_0) ? (p__3_carry_i_1_n_0) : (((p__3_carry_i_1_n_0) ? (p__3_carry__0_i_6__0_n_0) : (1'b1))))))))) : (((p__3_carry_0[0]) ? (((p__3_carry__0_i_7_n_0) ? (((p__3_carry_i_2__2_n_0) ? (p__3_carry_i_1_n_0) : (((p__3_carry_i_1_n_0) ? (p__3_carry__0_i_6__0_n_0) : (~(p__3_carry__0_i_6__0_n_0)))))) : (((p__3_carry_i_2__2_n_0) ? (p__3_carry_i_1_n_0) : (((p__3_carry_i_1_n_0) ? (p__3_carry__0_i_6__0_n_0) : (1'b1))))))) : (((p__3_carry_i_2__2_n_0) ? (p__3_carry_i_1_n_0) : (((p__3_carry_i_1_n_0) ? (p__3_carry__0_i_6__0_n_0) : (1'b1))))))));

  // Reconstructed LUT6: p__3_carry__0_i_3__1
  assign p__3_carry__0_i_3__1_n_0 = ((p__3_carry_i_2__2_n_0) ? (((p__3_carry__0_i_6__0_n_0) ? (((p__3_carry_i_1_n_0) ? (1'b0) : (((p__3_carry__0_i_7_n_0) ? (1'b0) : (((p__3_carry_0[0]) ? (zext_ln84_3_reg_8846[0]) : (~(zext_ln84_3_reg_8846[0])))))))) : (((p__3_carry_i_1_n_0) ? (~(p__3_carry__0_i_7_n_0)) : (1'b1))))) : (((p__3_carry__0_i_6__0_n_0) ? (((p__3_carry_i_1_n_0) ? (1'b1) : (((p__3_carry__0_i_7_n_0) ? (((p__3_carry_0[0]) ? (~(zext_ln84_3_reg_8846[0])) : (zext_ln84_3_reg_8846[0]))) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: p__3_carry__0_i_4__1
  assign p__3_carry__0_i_4__1_n_0 = ((p__3_carry__0_i_6__0_n_0) ? (((p__3_carry_i_1_n_0) ? (((p__3_carry_i_2__2_n_0) ? (((p__3_carry__0_i_7_n_0) ? (1'b1) : (((p__3_carry_0[0]) ? (~(zext_ln84_3_reg_8846[0])) : (zext_ln84_3_reg_8846[0]))))) : (((p__3_carry__0_i_7_n_0) ? (((p__3_carry_0[0]) ? (~(zext_ln84_3_reg_8846[0])) : (zext_ln84_3_reg_8846[0]))) : (1'b0))))) : (((p__3_carry_i_2__2_n_0) ? (((p__3_carry__0_i_7_n_0) ? (1'b0) : (((p__3_carry_0[0]) ? (zext_ln84_3_reg_8846[0]) : (~(zext_ln84_3_reg_8846[0])))))) : (((p__3_carry__0_i_7_n_0) ? (((p__3_carry_0[0]) ? (zext_ln84_3_reg_8846[0]) : (~(zext_ln84_3_reg_8846[0])))) : (1'b1))))))) : (((p__3_carry_i_1_n_0) ? (((p__3_carry_i_2__2_n_0) ? (~(p__3_carry__0_i_7_n_0)) : (1'b1))) : (((p__3_carry_i_2__2_n_0) ? (p__3_carry__0_i_7_n_0) : (1'b0))))));

  // Reconstructed LUT6: p__3_carry__0_i_5__1
  assign p__3_carry__0_i_5__1_n_0 = ((p__3_carry_i_2__2_n_0) ? (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (1'b0) : (~(p__3_carry__0_i_6__0_n_0)))) : (((p__3_carry_0[0]) ? (~(p__3_carry__0_i_6__0_n_0)) : (1'b1))))) : (((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (1'b1) : (p__3_carry__0_i_6__0_n_0))) : (((p__3_carry_0[0]) ? (p__3_carry__0_i_6__0_n_0) : (1'b0))))))) : (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (1'b1) : (p__3_carry__0_i_6__0_n_0))) : (((p__3_carry_0[0]) ? (p__3_carry__0_i_6__0_n_0) : (1'b0))))) : (((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (1'b0) : (~(p__3_carry__0_i_6__0_n_0)))) : (((p__3_carry_0[0]) ? (~(p__3_carry__0_i_6__0_n_0)) : (1'b1))))))))) : (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (1'b1) : (p__3_carry__0_i_6__0_n_0))) : (((p__3_carry_0[0]) ? (p__3_carry__0_i_6__0_n_0) : (1'b0))))) : (((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (1'b0) : (~(p__3_carry__0_i_6__0_n_0)))) : (((p__3_carry_0[0]) ? (~(p__3_carry__0_i_6__0_n_0)) : (1'b1))))))) : (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (1'b0) : (~(p__3_carry__0_i_6__0_n_0)))) : (((p__3_carry_0[0]) ? (~(p__3_carry__0_i_6__0_n_0)) : (1'b1))))) : (((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (1'b1) : (p__3_carry__0_i_6__0_n_0))) : (((p__3_carry_0[0]) ? (p__3_carry__0_i_6__0_n_0) : (1'b0))))))))));

  // Reconstructed LUT6: p__3_carry__0_i_6__0
  assign p__3_carry__0_i_6__0_n_0 = ((p__3_carry_0[2]) ? (((zext_ln84_3_reg_8846[2]) ? (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[1]) ? (1'b1) : (((zext_ln84_3_reg_8846[0]) ? (p__3_carry_0[0]) : (1'b0))))) : (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (p__3_carry_0[0]) : (1'b0))) : (1'b0))))) : (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[1]) ? (1'b0) : (((zext_ln84_3_reg_8846[0]) ? (~(p__3_carry_0[0])) : (1'b1))))) : (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (~(p__3_carry_0[0])) : (1'b1))) : (1'b1))))))) : (((zext_ln84_3_reg_8846[2]) ? (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[1]) ? (1'b0) : (((zext_ln84_3_reg_8846[0]) ? (~(p__3_carry_0[0])) : (1'b1))))) : (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (~(p__3_carry_0[0])) : (1'b1))) : (1'b1))))) : (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[1]) ? (1'b1) : (((zext_ln84_3_reg_8846[0]) ? (p__3_carry_0[0]) : (1'b0))))) : (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (p__3_carry_0[0]) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT4: p__3_carry__0_i_7
  assign p__3_carry__0_i_7_n_0 = ((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (p__3_carry_0[0]) : (1'b0))) : (((zext_ln84_3_reg_8846[0]) ? (~(p__3_carry_0[0])) : (1'b1))))) : (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (~(p__3_carry_0[0])) : (1'b1))) : (((zext_ln84_3_reg_8846[0]) ? (p__3_carry_0[0]) : (1'b0))))));

  // Reconstructed CARRY4: p__3_carry__1
  wire [3:0] recovered_26_co, recovered_26_o, recovered_26_s, recovered_26_di;
  assign recovered_26_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,p__3_carry__1_i_1_n_0};
  assign recovered_26_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_26_ci = ((p__3_carry__0_n_0) !== 1'bz) && (p__3_carry__0_n_0);
  wire recovered_26_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_26_o[0] = recovered_26_s[0] ^ (recovered_26_ci || recovered_26_cy);
  assign recovered_26_co[0] = (recovered_26_s[0] & (recovered_26_ci || recovered_26_cy)) | (~recovered_26_s[0] & recovered_26_di[0]);
  assign recovered_26_o[1] = recovered_26_s[1] ^ recovered_26_co[0];
  assign recovered_26_co[1] = (recovered_26_s[1] & recovered_26_co[0]) | (~recovered_26_s[1] & recovered_26_di[1]);
  assign recovered_26_o[2] = recovered_26_s[2] ^ recovered_26_co[1];
  assign recovered_26_co[2] = (recovered_26_s[2] & recovered_26_co[1]) | (~recovered_26_s[2] & recovered_26_di[2]);
  assign recovered_26_o[3] = recovered_26_s[3] ^ recovered_26_co[2];
  assign recovered_26_co[3] = (recovered_26_s[3] & recovered_26_co[2]) | (~recovered_26_s[3] & recovered_26_di[3]);
  assign p__3_carry__1_n_7 = recovered_26_o;

  // Reconstructed LUT6: p__3_carry__1_i_1
  assign p__3_carry__1_i_1_n_0 = ((p__3_carry_i_1_n_0) ? (1'b0) : (((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (~(p__3_carry_i_2__2_n_0)) : (((p__3_carry__0_i_7_n_0) ? (((p__3_carry_i_2__2_n_0) ? (1'b0) : (~(p__3_carry__0_i_6__0_n_0)))) : (~(p__3_carry_i_2__2_n_0)))))) : (((p__3_carry_0[0]) ? (((p__3_carry__0_i_7_n_0) ? (((p__3_carry_i_2__2_n_0) ? (1'b0) : (~(p__3_carry__0_i_6__0_n_0)))) : (~(p__3_carry_i_2__2_n_0)))) : (~(p__3_carry_i_2__2_n_0)))))));

  // Reconstructed LUT4: p__3_carry_i_1
  assign p__3_carry_i_1_n_0 = ((p__3_carry_i_7_n_0) ? (((zext_ln84_3_reg_8846[3]) ? (((p__3_carry_0[3]) ? (~(p__3_carry_0[4])) : (p__3_carry_0[4]))) : (p__3_carry_0[4]))) : (((zext_ln84_3_reg_8846[3]) ? (~(p__3_carry_0[4])) : (((p__3_carry_0[3]) ? (~(p__3_carry_0[4])) : (p__3_carry_0[4]))))));

  // Reconstructed LUT3: p__3_carry_i_2__2
  assign p__3_carry_i_2__2_n_0 = ((p__3_carry_0[3]) ? (((zext_ln84_3_reg_8846[3]) ? (~(p__3_carry_i_7_n_0)) : (p__3_carry_i_7_n_0))) : (((zext_ln84_3_reg_8846[3]) ? (p__3_carry_i_7_n_0) : (~(p__3_carry_i_7_n_0)))));

  // Reconstructed LUT6: p__3_carry_i_3__1
  assign p__3_carry_i_3__1_n_0 = ((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[2]) ? (p__3_carry_0[2]) : (~(p__3_carry_0[2])))) : (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[2]) ? (p__3_carry_0[2]) : (~(p__3_carry_0[2])))) : (((zext_ln84_3_reg_8846[2]) ? (~(p__3_carry_0[2])) : (p__3_carry_0[2]))))))) : (((zext_ln84_3_reg_8846[1]) ? (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[2]) ? (~(p__3_carry_0[2])) : (p__3_carry_0[2]))) : (((zext_ln84_3_reg_8846[2]) ? (p__3_carry_0[2]) : (~(p__3_carry_0[2])))))) : (((zext_ln84_3_reg_8846[2]) ? (p__3_carry_0[2]) : (~(p__3_carry_0[2])))))))) : (((p__3_carry_0[0]) ? (((zext_ln84_3_reg_8846[1]) ? (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[2]) ? (~(p__3_carry_0[2])) : (p__3_carry_0[2]))) : (((zext_ln84_3_reg_8846[2]) ? (p__3_carry_0[2]) : (~(p__3_carry_0[2])))))) : (((zext_ln84_3_reg_8846[2]) ? (p__3_carry_0[2]) : (~(p__3_carry_0[2])))))) : (((zext_ln84_3_reg_8846[1]) ? (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[2]) ? (p__3_carry_0[2]) : (~(p__3_carry_0[2])))) : (((zext_ln84_3_reg_8846[2]) ? (~(p__3_carry_0[2])) : (p__3_carry_0[2]))))) : (((zext_ln84_3_reg_8846[2]) ? (~(p__3_carry_0[2])) : (p__3_carry_0[2]))))))));

  // Reconstructed LUT5: p__3_carry_i_4
  assign p__3_carry_i_4_n_0 = ((p__3_carry_0[0]) ? (((zext_ln84_3_reg_8846[0]) ? (((zext_ln84_3_reg_8846[1]) ? (((p__3_carry_0[1]) ? (~(p__3_carry_i_1_n_0)) : (p__3_carry_i_1_n_0))) : (((p__3_carry_0[1]) ? (p__3_carry_i_1_n_0) : (~(p__3_carry_i_1_n_0)))))) : (((zext_ln84_3_reg_8846[1]) ? (((p__3_carry_0[1]) ? (p__3_carry_i_1_n_0) : (~(p__3_carry_i_1_n_0)))) : (((p__3_carry_0[1]) ? (~(p__3_carry_i_1_n_0)) : (p__3_carry_i_1_n_0))))))) : (((zext_ln84_3_reg_8846[1]) ? (((p__3_carry_0[1]) ? (p__3_carry_i_1_n_0) : (~(p__3_carry_i_1_n_0)))) : (((p__3_carry_0[1]) ? (~(p__3_carry_i_1_n_0)) : (p__3_carry_i_1_n_0))))));

  // Reconstructed LUT3: p__3_carry_i_5__0
  assign p__3_carry_i_5__0_n_0 = ((zext_ln84_3_reg_8846[0]) ? (((p__3_carry_0[0]) ? (p__3_carry_i_2__2_n_0) : (~(p__3_carry_i_2__2_n_0)))) : (((p__3_carry_0[0]) ? (~(p__3_carry_i_2__2_n_0)) : (p__3_carry_i_2__2_n_0))));

  // Reconstructed LUT6: p__3_carry_i_6__0
  assign p__3_carry_i_6__0_n_0 = ((p__3_carry_0[2]) ? (((zext_ln84_3_reg_8846[2]) ? (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[1]) ? (1'b1) : (((zext_ln84_3_reg_8846[0]) ? (p__3_carry_0[0]) : (1'b0))))) : (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (p__3_carry_0[0]) : (1'b0))) : (1'b0))))) : (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[1]) ? (1'b0) : (((zext_ln84_3_reg_8846[0]) ? (~(p__3_carry_0[0])) : (1'b1))))) : (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (~(p__3_carry_0[0])) : (1'b1))) : (1'b1))))))) : (((zext_ln84_3_reg_8846[2]) ? (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[1]) ? (1'b0) : (((zext_ln84_3_reg_8846[0]) ? (~(p__3_carry_0[0])) : (1'b1))))) : (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (~(p__3_carry_0[0])) : (1'b1))) : (1'b1))))) : (((p__3_carry_0[1]) ? (((zext_ln84_3_reg_8846[1]) ? (1'b1) : (((zext_ln84_3_reg_8846[0]) ? (p__3_carry_0[0]) : (1'b0))))) : (((zext_ln84_3_reg_8846[1]) ? (((zext_ln84_3_reg_8846[0]) ? (p__3_carry_0[0]) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT6: p__3_carry_i_7
  assign p__3_carry_i_7_n_0 = ((zext_ln84_3_reg_8846[2]) ? (((p__3_carry_0[2]) ? (1'b0) : (((p__3_carry_0[0]) ? (((zext_ln84_3_reg_8846[0]) ? (((zext_ln84_3_reg_8846[1]) ? (1'b0) : (~(p__3_carry_0[1])))) : (((zext_ln84_3_reg_8846[1]) ? (~(p__3_carry_0[1])) : (1'b1))))) : (((zext_ln84_3_reg_8846[1]) ? (~(p__3_carry_0[1])) : (1'b1))))))) : (((p__3_carry_0[2]) ? (((p__3_carry_0[0]) ? (((zext_ln84_3_reg_8846[0]) ? (((zext_ln84_3_reg_8846[1]) ? (1'b0) : (~(p__3_carry_0[1])))) : (((zext_ln84_3_reg_8846[1]) ? (~(p__3_carry_0[1])) : (1'b1))))) : (((zext_ln84_3_reg_8846[1]) ? (~(p__3_carry_0[1])) : (1'b1))))) : (1'b1))));

endmodule

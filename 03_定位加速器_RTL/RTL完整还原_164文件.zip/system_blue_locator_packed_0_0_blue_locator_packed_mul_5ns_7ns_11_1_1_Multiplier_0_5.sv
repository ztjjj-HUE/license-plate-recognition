// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0_5
   (D,
    esc_select_ln89_1_reg_8929_reg_3_a71ff2a ,
    esc_y_3_reg_2466_reg_1_60c8b0a ,
    esc_select_ln84_1_reg_8829_reg_6_df41fac ,
    esc_icmp_ln89_reg_8917_reg_0_d4d6839 ,
    esc_add_ln90_reg_8972_reg_5_c2be608 ,
    Q,
    ap_enable_reg_pp4_iter1,
    esc_indvar_flatten15_reg_2455_reg_11_5a608fe ,
    esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33 ,
    esc_select_ln89_1_reg_8929_reg_4_6c0fd6e ,
    esc_mul_ln215_1_reg_8936_reg_0_e99c137 ,
    esc_select_ln89_reg_8921_reg_5_0d551cf ,
    esc_select_ln89_reg_8921_reg_5__0_d2a50b8 );
  output [10:0]D;
  output [1:0]esc_select_ln89_1_reg_8929_reg_3_a71ff2a ;
  output esc_y_3_reg_2466_reg_1_60c8b0a ;
  output esc_select_ln84_1_reg_8829_reg_6_df41fac ;
  output esc_icmp_ln89_reg_8917_reg_0_d4d6839 ;
  output [4:0]esc_add_ln90_reg_8972_reg_5_c2be608 ;
  input [4:0]Q;
  input ap_enable_reg_pp4_iter1;
  input [0:0]esc_indvar_flatten15_reg_2455_reg_11_5a608fe ;
  input esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33 ;
  input [4:0]esc_select_ln89_1_reg_8929_reg_4_6c0fd6e ;
  input [6:0]esc_mul_ln215_1_reg_8936_reg_0_e99c137 ;
  input [5:0]esc_select_ln89_reg_8921_reg_5_0d551cf ;
  input [5:0]esc_select_ln89_reg_8921_reg_5__0_d2a50b8 ;

  wire esc_const0_a0cf646 ;
  wire [10:0]D;
  wire [4:0]Q;
  wire [4:0]esc_add_ln90_reg_8972_reg_5_c2be608 ;
  wire ap_enable_reg_pp4_iter1;
  wire [4:2]ap_phi_mux_y_3_phi_fu_2470_p4;
  wire esc_icmp_ln89_reg_8917_reg_0_d4d6839 ;
  wire [0:0]esc_indvar_flatten15_reg_2455_reg_11_5a608fe ;
  wire esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33 ;
  wire esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207 ;
  wire [6:0]esc_mul_ln215_1_reg_8936_reg_0_e99c137 ;
  wire p__3_carry__0_i_1__0_n_0;
  wire p__3_carry__0_i_2__0_n_0;
  wire p__3_carry__0_i_3__0_n_0;
  wire p__3_carry__0_i_4__0_n_0;
  wire p__3_carry__0_i_5__0_n_0;
  wire p__3_carry__0_n_0;
  wire p__3_carry__1_i_1__0_n_0;
  wire p__3_carry_i_1__2_n_0;
  wire p__3_carry_i_2__1_n_0;
  wire p__3_carry_i_3__0_n_0;
  wire p__3_carry_i_4__0_n_0;
  wire p__3_carry_n_0;
  wire esc_select_ln84_1_reg_8829_reg_6_df41fac ;
  wire esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889 ;
  wire [1:0]esc_select_ln89_1_reg_8929_reg_3_a71ff2a ;
  wire [4:0]esc_select_ln89_1_reg_8929_reg_4_6c0fd6e ;
  wire esc_select_ln89_reg_8921_5__i_5_n_0_ee1cd6d ;
  wire esc_select_ln89_reg_8921_5__i_6_n_0_05a8b11 ;
  wire [5:0]esc_select_ln89_reg_8921_reg_5_0d551cf ;
  wire [5:0]esc_select_ln89_reg_8921_reg_5__0_d2a50b8 ;
  wire esc_y_3_reg_2466_reg_1_60c8b0a ;
  wire [3:0]NLW_p__3_carry_CO_UNCONNECTED;
  wire [3:0]NLW_p__3_carry__0_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed LUT3: esc_indvar_flatten15_reg_2455_11__i_2_f58c72a
  assign esc_icmp_ln89_reg_8917_reg_0_d4d6839 = ((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (~(esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33)) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: esc_mul_ln215_1_reg_8936_0__i_1_e347d15
  assign D[0] = ((esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [0]) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[0]) ? (esc_select_ln84_1_reg_8829_reg_6_df41fac) : (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (esc_select_ln84_1_reg_8829_reg_6_df41fac) : (((Q[0]) ? (esc_select_ln84_1_reg_8829_reg_6_df41fac) : (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)))))) : (((Q[0]) ? (esc_select_ln84_1_reg_8829_reg_6_df41fac) : (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)))))))) : (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[0]) ? (esc_select_ln84_1_reg_8829_reg_6_df41fac) : (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)) : (((Q[0]) ? (esc_select_ln84_1_reg_8829_reg_6_df41fac) : (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)))))) : (((Q[0]) ? (esc_select_ln84_1_reg_8829_reg_6_df41fac) : (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)))))))));

  // Reconstructed LUT6: esc_mul_ln215_1_reg_8936_1__i_1_a244345
  assign D[1] = ((esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [1]) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[1]) ? (~(esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207)) : (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (~(esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207)) : (((Q[1]) ? (~(esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207)) : (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207))))) : (((Q[1]) ? (~(esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207)) : (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207))))))) : (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[1]) ? (~(esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207)) : (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207) : (((Q[1]) ? (~(esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207)) : (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207))))) : (((Q[1]) ? (~(esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207)) : (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207))))))));

  // Reconstructed LUT6: esc_mul_ln215_1_reg_8936_1__i_2_0957117
  assign esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207 = ((esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [0]) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[0]) ? (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)) : (1'b0))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)) : (((Q[0]) ? (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)) : (1'b0))))) : (((Q[0]) ? (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)) : (1'b0))))))) : (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[0]) ? (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)) : (1'b0))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (1'b0) : (((Q[0]) ? (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)) : (1'b0))))) : (((Q[0]) ? (~(esc_select_ln84_1_reg_8829_reg_6_df41fac)) : (1'b0))))))));

  // Reconstructed CARRY4: p__3_carry
  wire [3:0] recovered_6_co, recovered_6_o, recovered_6_s, recovered_6_di;
  assign recovered_6_s = {p__3_carry_i_1__2_n_0,p__3_carry_i_2__1_n_0,p__3_carry_i_3__0_n_0,p__3_carry_i_4__0_n_0};
  assign recovered_6_di = {esc_const0_a0cf646 ,esc_select_ln89_1_reg_8929_reg_3_a71ff2a ,esc_const0_a0cf646 };
  wire recovered_6_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_6_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_6_o[0] = recovered_6_s[0] ^ (recovered_6_ci || recovered_6_cy);
  assign recovered_6_co[0] = (recovered_6_s[0] & (recovered_6_ci || recovered_6_cy)) | (~recovered_6_s[0] & recovered_6_di[0]);
  assign recovered_6_o[1] = recovered_6_s[1] ^ recovered_6_co[0];
  assign recovered_6_co[1] = (recovered_6_s[1] & recovered_6_co[0]) | (~recovered_6_s[1] & recovered_6_di[1]);
  assign recovered_6_o[2] = recovered_6_s[2] ^ recovered_6_co[1];
  assign recovered_6_co[2] = (recovered_6_s[2] & recovered_6_co[1]) | (~recovered_6_s[2] & recovered_6_di[2]);
  assign recovered_6_o[3] = recovered_6_s[3] ^ recovered_6_co[2];
  assign recovered_6_co[3] = (recovered_6_s[3] & recovered_6_co[2]) | (~recovered_6_s[3] & recovered_6_di[3]);
  assign {p__3_carry_n_0,NLW_p__3_carry_CO_UNCONNECTED[2:0]} = recovered_6_co;
  assign D[5:2] = recovered_6_o;

  // Reconstructed CARRY4: p__3_carry__0
  wire [3:0] recovered_7_co, recovered_7_o, recovered_7_s, recovered_7_di;
  assign recovered_7_s = {p__3_carry__0_i_2__0_n_0,p__3_carry__0_i_3__0_n_0,p__3_carry__0_i_4__0_n_0,p__3_carry__0_i_5__0_n_0};
  assign recovered_7_di = {esc_const0_a0cf646 ,p__3_carry__0_i_1__0_n_0,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_7_ci = ((p__3_carry_n_0) !== 1'bz) && (p__3_carry_n_0);
  wire recovered_7_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_7_o[0] = recovered_7_s[0] ^ (recovered_7_ci || recovered_7_cy);
  assign recovered_7_co[0] = (recovered_7_s[0] & (recovered_7_ci || recovered_7_cy)) | (~recovered_7_s[0] & recovered_7_di[0]);
  assign recovered_7_o[1] = recovered_7_s[1] ^ recovered_7_co[0];
  assign recovered_7_co[1] = (recovered_7_s[1] & recovered_7_co[0]) | (~recovered_7_s[1] & recovered_7_di[1]);
  assign recovered_7_o[2] = recovered_7_s[2] ^ recovered_7_co[1];
  assign recovered_7_co[2] = (recovered_7_s[2] & recovered_7_co[1]) | (~recovered_7_s[2] & recovered_7_di[2]);
  assign recovered_7_o[3] = recovered_7_s[3] ^ recovered_7_co[2];
  assign recovered_7_co[3] = (recovered_7_s[3] & recovered_7_co[2]) | (~recovered_7_s[3] & recovered_7_di[3]);
  assign {p__3_carry__0_n_0,NLW_p__3_carry__0_CO_UNCONNECTED[2:0]} = recovered_7_co;
  assign D[9:6] = recovered_7_o;

  // Reconstructed LUT6: p__3_carry__0_i_1__0
  assign p__3_carry__0_i_1__0_n_0 = ((ap_phi_mux_y_3_phi_fu_2470_p4[4]) ? (((D[1]) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (1'b1) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (ap_phi_mux_y_3_phi_fu_2470_p4[2]) : (~(ap_phi_mux_y_3_phi_fu_2470_p4[2])))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (1'b1) : (ap_phi_mux_y_3_phi_fu_2470_p4[2]))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (1'b0) : (~(ap_phi_mux_y_3_phi_fu_2470_p4[2])))))))) : (((D[1]) ? (((D[0]) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (1'b1) : (ap_phi_mux_y_3_phi_fu_2470_p4[2]))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (1'b0) : (~(ap_phi_mux_y_3_phi_fu_2470_p4[2])))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (1'b1) : (ap_phi_mux_y_3_phi_fu_2470_p4[2]))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (~(ap_phi_mux_y_3_phi_fu_2470_p4[2])) : (1'b1))))))) : (((D[0]) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (1'b1) : (ap_phi_mux_y_3_phi_fu_2470_p4[2]))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (~(ap_phi_mux_y_3_phi_fu_2470_p4[2])) : (1'b1))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (ap_phi_mux_y_3_phi_fu_2470_p4[2]) : (1'b0))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (~(ap_phi_mux_y_3_phi_fu_2470_p4[2])) : (1'b1))))))))));

  // Reconstructed LUT6: p__3_carry__0_i_2__0
  assign p__3_carry__0_i_2__0_n_0 = ((ap_phi_mux_y_3_phi_fu_2470_p4[4]) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (1'b1) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (1'b1) : (ap_phi_mux_y_3_phi_fu_2470_p4[2]))))) : (((D[1]) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (1'b0) : (((D[0]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (1'b0) : (~(ap_phi_mux_y_3_phi_fu_2470_p4[2])))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (~(ap_phi_mux_y_3_phi_fu_2470_p4[2])) : (1'b1))))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (1'b0) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (~(ap_phi_mux_y_3_phi_fu_2470_p4[2])) : (1'b1))))))));

  // Reconstructed LUT6: p__3_carry__0_i_3__0
  assign p__3_carry__0_i_3__0_n_0 = ((ap_phi_mux_y_3_phi_fu_2470_p4[2]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (1'b0) : (((D[1]) ? (~(ap_phi_mux_y_3_phi_fu_2470_p4[4])) : (1'b1))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((D[0]) ? (1'b0) : (((D[1]) ? (1'b0) : (~(ap_phi_mux_y_3_phi_fu_2470_p4[4])))))) : (((D[0]) ? (((D[1]) ? (1'b1) : (ap_phi_mux_y_3_phi_fu_2470_p4[4]))) : (ap_phi_mux_y_3_phi_fu_2470_p4[4]))))))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((D[0]) ? (1'b0) : (((D[1]) ? (1'b0) : (~(ap_phi_mux_y_3_phi_fu_2470_p4[4])))))) : (((D[0]) ? (((D[1]) ? (1'b1) : (ap_phi_mux_y_3_phi_fu_2470_p4[4]))) : (ap_phi_mux_y_3_phi_fu_2470_p4[4]))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((D[1]) ? (~(ap_phi_mux_y_3_phi_fu_2470_p4[4])) : (1'b1))) : (1'b0))))));

  // Reconstructed LUT6: p__3_carry__0_i_4__0
  assign p__3_carry__0_i_4__0_n_0 = ((ap_phi_mux_y_3_phi_fu_2470_p4[4]) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[2]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (1'b0) : (~(D[1])))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((D[0]) ? (1'b1) : (D[1]))) : (((D[0]) ? (D[1]) : (1'b0))))))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((D[0]) ? (1'b1) : (D[1]))) : (((D[0]) ? (D[1]) : (1'b0))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (~(D[1])) : (1'b1))))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[2]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (1'b1) : (D[1]))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((D[0]) ? (1'b0) : (~(D[1])))) : (((D[0]) ? (~(D[1])) : (1'b1))))))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((D[0]) ? (1'b0) : (~(D[1])))) : (((D[0]) ? (~(D[1])) : (1'b1))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (D[1]) : (1'b0))))))));

  // Reconstructed LUT5: p__3_carry__0_i_5__0
  assign p__3_carry__0_i_5__0_n_0 = ((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[2]) ? (D[1]) : (((D[1]) ? (D[0]) : (~(D[0])))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[2]) ? (((D[1]) ? (D[0]) : (~(D[0])))) : (~(D[1])))))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[2]) ? (~(D[1])) : (((D[1]) ? (~(D[0])) : (D[0]))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[2]) ? (((D[1]) ? (~(D[0])) : (D[0]))) : (D[1]))))));

  // Reconstructed LUT5: p__3_carry__0_i_6
  assign ap_phi_mux_y_3_phi_fu_2470_p4[2] = ((Q[2]) ? (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b1) : (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2]))) : (1'b1))) : (1'b1))) : (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b0) : (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2]))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: p__3_carry__0_i_7__0
  assign ap_phi_mux_y_3_phi_fu_2470_p4[4] = ((Q[4]) ? (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b1) : (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4]))) : (1'b1))) : (1'b1))) : (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b0) : (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4]))) : (1'b0))) : (1'b0))));

  // Reconstructed CARRY4: p__3_carry__1
  wire [3:0] recovered_15_co, recovered_15_o, recovered_15_s, recovered_15_di;
  assign recovered_15_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,p__3_carry__1_i_1__0_n_0};
  assign recovered_15_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_15_ci = ((p__3_carry__0_n_0) !== 1'bz) && (p__3_carry__0_n_0);
  wire recovered_15_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_15_o[0] = recovered_15_s[0] ^ (recovered_15_ci || recovered_15_cy);
  assign recovered_15_co[0] = (recovered_15_s[0] & (recovered_15_ci || recovered_15_cy)) | (~recovered_15_s[0] & recovered_15_di[0]);
  assign recovered_15_o[1] = recovered_15_s[1] ^ recovered_15_co[0];
  assign recovered_15_co[1] = (recovered_15_s[1] & recovered_15_co[0]) | (~recovered_15_s[1] & recovered_15_di[1]);
  assign recovered_15_o[2] = recovered_15_s[2] ^ recovered_15_co[1];
  assign recovered_15_co[2] = (recovered_15_s[2] & recovered_15_co[1]) | (~recovered_15_s[2] & recovered_15_di[2]);
  assign recovered_15_o[3] = recovered_15_s[3] ^ recovered_15_co[2];
  assign recovered_15_co[3] = (recovered_15_s[3] & recovered_15_co[2]) | (~recovered_15_s[3] & recovered_15_di[3]);
  assign D[10] = recovered_15_o;

  // Reconstructed LUT6: p__3_carry__1_i_1__0
  assign p__3_carry__1_i_1__0_n_0 = ((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[2]) ? (ap_phi_mux_y_3_phi_fu_2470_p4[4]) : (1'b0))) : (1'b0))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[2]) ? (1'b0) : (((ap_phi_mux_y_3_phi_fu_2470_p4[4]) ? (1'b0) : (((D[1]) ? (~(D[0])) : (1'b1))))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[2]) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[4]) ? (1'b0) : (((D[1]) ? (~(D[0])) : (1'b1))))) : (~(ap_phi_mux_y_3_phi_fu_2470_p4[4])))))));

  // Reconstructed LUT5: p__3_carry_i_1__2
  assign p__3_carry_i_1__2_n_0 = ((D[0]) ? (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((Q[2]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2]) : (1'b1))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2]) : (1'b0))))) : (((Q[2]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2])) : (1'b0))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2])) : (1'b1))))))) : (((esc_y_3_reg_2466_reg_1_60c8b0a) ? (((Q[2]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2])) : (1'b0))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2])) : (1'b1))))) : (((Q[2]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2]) : (1'b1))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2]) : (1'b0))))))));

  // Reconstructed LUT6: p__3_carry_i_2__1
  assign p__3_carry_i_2__1_n_0 = ((D[1]) ? (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889) ? (((Q[4]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4]) : (1'b1))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4]) : (1'b0))))) : (((Q[4]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4])) : (1'b0))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4])) : (1'b1))))))) : (((Q[4]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4])) : (1'b0))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4])) : (1'b1))))))) : (((ap_phi_mux_y_3_phi_fu_2470_p4[3]) ? (((esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889) ? (((Q[4]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4])) : (1'b0))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4])) : (1'b1))))) : (((Q[4]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4]) : (1'b1))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4]) : (1'b0))))))) : (((Q[4]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4]) : (1'b1))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4]) : (1'b0))))))));

  // Reconstructed LUT5: p__3_carry_i_3__0
  assign p__3_carry_i_3__0_n_0 = ((D[0]) ? (((esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889) ? (((Q[3]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3]) : (1'b1))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3]) : (1'b0))))) : (((Q[3]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3])) : (1'b0))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3])) : (1'b1))))))) : (((esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889) ? (((Q[3]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3])) : (1'b0))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3])) : (1'b1))))) : (((Q[3]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3]) : (1'b1))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3]) : (1'b0))))))));

  // Reconstructed LUT6: p__3_carry_i_4__0
  assign p__3_carry_i_4__0_n_0 = ((esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2]) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[2]) ? (~(esc_y_3_reg_2466_reg_1_60c8b0a)) : (esc_y_3_reg_2466_reg_1_60c8b0a))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (~(esc_y_3_reg_2466_reg_1_60c8b0a)) : (((Q[2]) ? (~(esc_y_3_reg_2466_reg_1_60c8b0a)) : (esc_y_3_reg_2466_reg_1_60c8b0a))))) : (((Q[2]) ? (~(esc_y_3_reg_2466_reg_1_60c8b0a)) : (esc_y_3_reg_2466_reg_1_60c8b0a))))))) : (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[2]) ? (~(esc_y_3_reg_2466_reg_1_60c8b0a)) : (esc_y_3_reg_2466_reg_1_60c8b0a))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (esc_y_3_reg_2466_reg_1_60c8b0a) : (((Q[2]) ? (~(esc_y_3_reg_2466_reg_1_60c8b0a)) : (esc_y_3_reg_2466_reg_1_60c8b0a))))) : (((Q[2]) ? (~(esc_y_3_reg_2466_reg_1_60c8b0a)) : (esc_y_3_reg_2466_reg_1_60c8b0a))))))));

  // Reconstructed LUT5: p__3_carry_i_5
  assign ap_phi_mux_y_3_phi_fu_2470_p4[3] = ((Q[3]) ? (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b1) : (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3]))) : (1'b1))) : (1'b1))) : (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b0) : (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3]))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_select_ln89_1_reg_8929_2__i_2_7f98d66
  assign esc_y_3_reg_2466_reg_1_60c8b0a = ((esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [1]) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[1]) ? (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207) : (1'b0))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207) : (((Q[1]) ? (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207) : (1'b0))))) : (((Q[1]) ? (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207) : (1'b0))))))) : (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[1]) ? (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207) : (1'b0))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (1'b0) : (((Q[1]) ? (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207) : (1'b0))))) : (((Q[1]) ? (esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207) : (1'b0))))))));

  // Reconstructed LUT6: esc_select_ln89_1_reg_8929_3__i_1_ce5e801
  assign esc_select_ln89_1_reg_8929_reg_3_a71ff2a [0] = ((esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3]) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[3]) ? (~(esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889)) : (esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (~(esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889)) : (((Q[3]) ? (~(esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889)) : (esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889))))) : (((Q[3]) ? (~(esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889)) : (esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889))))))) : (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (((Q[3]) ? (~(esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889)) : (esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889))) : (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((ap_enable_reg_pp4_iter1) ? (esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889) : (((Q[3]) ? (~(esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889)) : (esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889))))) : (((Q[3]) ? (~(esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889)) : (esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889))))))));

  // Reconstructed LUT6: esc_select_ln89_1_reg_8929_4__i_2_d26c87f
  assign esc_select_ln89_1_reg_8929_reg_3_a71ff2a [1] = ((esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [4]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (((esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889) ? (~(esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3])) : (1'b1))) : (((Q[4]) ? (((esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889) ? (~(Q[3])) : (1'b1))) : (((esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889) ? (Q[3]) : (1'b0))))))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (((esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [3]) : (1'b0))) : (((Q[4]) ? (((esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889) ? (~(Q[3])) : (1'b1))) : (((esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889) ? (Q[3]) : (1'b0))))))));

  // Reconstructed LUT6: esc_select_ln89_1_reg_8929_4__i_3_fe64257
  assign esc_select_ln89_1_reg_8929_4__i_3_n_0_95cf889 = ((esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [2]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (((esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207) ? (esc_select_ln89_1_reg_8929_reg_4_6c0fd6e [1]) : (1'b0))) : (((Q[2]) ? (((esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207) ? (Q[1]) : (1'b0))) : (1'b0))))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (1'b0) : (((Q[2]) ? (((esc_mul_ln215_1_reg_8936_1__i_2_n_0_4417207) ? (Q[1]) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: esc_select_ln89_reg_8921_0__i_1_e3ee616
  assign esc_add_ln90_reg_8972_reg_5_c2be608 [0] = ((esc_select_ln89_reg_8921_reg_5__0_d2a50b8 [0]) ? (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b1) : (esc_select_ln89_reg_8921_reg_5_0d551cf [0]))) : (1'b1))) : (1'b1))) : (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b0) : (esc_select_ln89_reg_8921_reg_5_0d551cf [0]))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_select_ln89_reg_8921_1__i_1_9296e31
  assign esc_add_ln90_reg_8972_reg_5_c2be608 [1] = ((esc_select_ln89_reg_8921_reg_5__0_d2a50b8 [1]) ? (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b1) : (esc_select_ln89_reg_8921_reg_5_0d551cf [1]))) : (1'b1))) : (1'b1))) : (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b0) : (esc_select_ln89_reg_8921_reg_5_0d551cf [1]))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_select_ln89_reg_8921_3__i_1_57328cf
  assign esc_add_ln90_reg_8972_reg_5_c2be608 [2] = ((esc_select_ln89_reg_8921_reg_5__0_d2a50b8 [3]) ? (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b1) : (esc_select_ln89_reg_8921_reg_5_0d551cf [3]))) : (1'b1))) : (1'b1))) : (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b0) : (esc_select_ln89_reg_8921_reg_5_0d551cf [3]))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_select_ln89_reg_8921_4__i_1_b9cf9d0
  assign esc_add_ln90_reg_8972_reg_5_c2be608 [3] = ((esc_select_ln89_reg_8921_reg_5__0_d2a50b8 [4]) ? (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b1) : (esc_select_ln89_reg_8921_reg_5_0d551cf [4]))) : (1'b1))) : (1'b1))) : (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b0) : (esc_select_ln89_reg_8921_reg_5_0d551cf [4]))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_select_ln89_reg_8921_5__i_3_73df2b8
  assign esc_add_ln90_reg_8972_reg_5_c2be608 [4] = ((esc_select_ln89_reg_8921_reg_5__0_d2a50b8 [5]) ? (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b1) : (esc_select_ln89_reg_8921_reg_5_0d551cf [5]))) : (1'b1))) : (1'b1))) : (((ap_enable_reg_pp4_iter1) ? (((esc_indvar_flatten15_reg_2455_reg_11_5a608fe) ? (((esc_indvar_flatten15_reg_2455_reg_11__0_c45ae33) ? (1'b0) : (esc_select_ln89_reg_8921_reg_5_0d551cf [5]))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_select_ln89_reg_8921_5__i_4_aa99465
  assign esc_select_ln84_1_reg_8829_reg_6_df41fac = ((esc_select_ln89_reg_8921_5__i_6_n_0_05a8b11) ? (1'b1) : (((esc_mul_ln215_1_reg_8936_reg_0_e99c137 [0]) ? (((esc_add_ln90_reg_8972_reg_5_c2be608 [0]) ? (((esc_select_ln89_reg_8921_5__i_5_n_0_ee1cd6d) ? (1'b1) : (esc_mul_ln215_1_reg_8936_reg_0_e99c137 [6]))) : (1'b1))) : (((esc_add_ln90_reg_8972_reg_5_c2be608 [0]) ? (1'b1) : (((esc_select_ln89_reg_8921_5__i_5_n_0_ee1cd6d) ? (1'b1) : (esc_mul_ln215_1_reg_8936_reg_0_e99c137 [6]))))))));

  // Reconstructed LUT6: esc_select_ln89_reg_8921_5__i_5_b40cf2d
  assign esc_select_ln89_reg_8921_5__i_5_n_0_ee1cd6d = ((esc_mul_ln215_1_reg_8936_reg_0_e99c137 [5]) ? (((esc_add_ln90_reg_8972_reg_5_c2be608 [4]) ? (((esc_add_ln90_reg_8972_reg_5_c2be608 [3]) ? (((esc_mul_ln215_1_reg_8936_reg_0_e99c137 [4]) ? (((esc_add_ln90_reg_8972_reg_5_c2be608 [2]) ? (~(esc_mul_ln215_1_reg_8936_reg_0_e99c137 [3])) : (esc_mul_ln215_1_reg_8936_reg_0_e99c137 [3]))) : (1'b1))) : (((esc_mul_ln215_1_reg_8936_reg_0_e99c137 [4]) ? (1'b1) : (((esc_add_ln90_reg_8972_reg_5_c2be608 [2]) ? (~(esc_mul_ln215_1_reg_8936_reg_0_e99c137 [3])) : (esc_mul_ln215_1_reg_8936_reg_0_e99c137 [3]))))))) : (1'b1))) : (((esc_add_ln90_reg_8972_reg_5_c2be608 [4]) ? (1'b1) : (((esc_add_ln90_reg_8972_reg_5_c2be608 [3]) ? (((esc_mul_ln215_1_reg_8936_reg_0_e99c137 [4]) ? (((esc_add_ln90_reg_8972_reg_5_c2be608 [2]) ? (~(esc_mul_ln215_1_reg_8936_reg_0_e99c137 [3])) : (esc_mul_ln215_1_reg_8936_reg_0_e99c137 [3]))) : (1'b1))) : (((esc_mul_ln215_1_reg_8936_reg_0_e99c137 [4]) ? (1'b1) : (((esc_add_ln90_reg_8972_reg_5_c2be608 [2]) ? (~(esc_mul_ln215_1_reg_8936_reg_0_e99c137 [3])) : (esc_mul_ln215_1_reg_8936_reg_0_e99c137 [3]))))))))));

  // Reconstructed LUT6: esc_select_ln89_reg_8921_5__i_6_29be317
  assign esc_select_ln89_reg_8921_5__i_6_n_0_05a8b11 = ((esc_mul_ln215_1_reg_8936_reg_0_e99c137 [1]) ? (((esc_add_ln90_reg_8972_reg_5_c2be608 [1]) ? (((esc_mul_ln215_1_reg_8936_reg_0_e99c137 [2]) ? (((esc_select_ln89_reg_8921_reg_5__0_d2a50b8 [2]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_reg_8921_reg_5_0d551cf [2])) : (1'b0))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_reg_8921_reg_5_0d551cf [2])) : (1'b1))))) : (((esc_select_ln89_reg_8921_reg_5__0_d2a50b8 [2]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_reg_8921_reg_5_0d551cf [2]) : (1'b1))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_reg_8921_reg_5_0d551cf [2]) : (1'b0))))))) : (1'b1))) : (((esc_add_ln90_reg_8972_reg_5_c2be608 [1]) ? (1'b1) : (((esc_mul_ln215_1_reg_8936_reg_0_e99c137 [2]) ? (((esc_select_ln89_reg_8921_reg_5__0_d2a50b8 [2]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_reg_8921_reg_5_0d551cf [2])) : (1'b0))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (~(esc_select_ln89_reg_8921_reg_5_0d551cf [2])) : (1'b1))))) : (((esc_select_ln89_reg_8921_reg_5__0_d2a50b8 [2]) ? (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_reg_8921_reg_5_0d551cf [2]) : (1'b1))) : (((esc_icmp_ln89_reg_8917_reg_0_d4d6839) ? (esc_select_ln89_reg_8921_reg_5_0d551cf [2]) : (1'b0))))))))));

endmodule

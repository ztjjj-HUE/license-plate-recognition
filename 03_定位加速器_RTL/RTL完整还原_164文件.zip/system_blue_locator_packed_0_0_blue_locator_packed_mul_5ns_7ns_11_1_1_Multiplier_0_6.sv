// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0_6
   (D,
    Q);
  output [8:0]D;
  input [4:0]Q;

  wire esc_const0_a0cf646 ;
  wire [8:0]D;
  wire [4:0]Q;
  wire p__3_carry__0_i_1_n_0;
  wire p__3_carry__0_i_2_n_0;
  wire p__3_carry__0_i_3_n_0;
  wire p__3_carry__0_i_4_n_0;
  wire p__3_carry__0_i_5_n_0;
  wire p__3_carry__0_n_0;
  wire p__3_carry__1_i_1__1_n_0;
  wire p__3_carry_i_1__1_n_0;
  wire p__3_carry_i_2__0_n_0;
  wire p__3_carry_i_3_n_0;
  wire p__3_carry_n_0;
  wire [3:0]NLW_p__3_carry_CO_UNCONNECTED;
  wire [3:0]NLW_p__3_carry__0_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed CARRY4: p__3_carry
  wire [3:0] recovered_2_co, recovered_2_o, recovered_2_s, recovered_2_di;
  assign recovered_2_s = {p__3_carry_i_1__1_n_0,p__3_carry_i_2__0_n_0,p__3_carry_i_3_n_0,Q[2]};
  assign recovered_2_di = {esc_const0_a0cf646 ,Q[4:3],esc_const0_a0cf646 };
  wire recovered_2_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_2_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_2_o[0] = recovered_2_s[0] ^ (recovered_2_ci || recovered_2_cy);
  assign recovered_2_co[0] = (recovered_2_s[0] & (recovered_2_ci || recovered_2_cy)) | (~recovered_2_s[0] & recovered_2_di[0]);
  assign recovered_2_o[1] = recovered_2_s[1] ^ recovered_2_co[0];
  assign recovered_2_co[1] = (recovered_2_s[1] & recovered_2_co[0]) | (~recovered_2_s[1] & recovered_2_di[1]);
  assign recovered_2_o[2] = recovered_2_s[2] ^ recovered_2_co[1];
  assign recovered_2_co[2] = (recovered_2_s[2] & recovered_2_co[1]) | (~recovered_2_s[2] & recovered_2_di[2]);
  assign recovered_2_o[3] = recovered_2_s[3] ^ recovered_2_co[2];
  assign recovered_2_co[3] = (recovered_2_s[3] & recovered_2_co[2]) | (~recovered_2_s[3] & recovered_2_di[3]);
  assign {p__3_carry_n_0,NLW_p__3_carry_CO_UNCONNECTED[2:0]} = recovered_2_co;
  assign D[3:0] = recovered_2_o;

  // Reconstructed CARRY4: p__3_carry__0
  wire [3:0] recovered_3_co, recovered_3_o, recovered_3_s, recovered_3_di;
  assign recovered_3_s = {p__3_carry__0_i_2_n_0,p__3_carry__0_i_3_n_0,p__3_carry__0_i_4_n_0,p__3_carry__0_i_5_n_0};
  assign recovered_3_di = {esc_const0_a0cf646 ,p__3_carry__0_i_1_n_0,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_3_ci = ((p__3_carry_n_0) !== 1'bz) && (p__3_carry_n_0);
  wire recovered_3_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_3_o[0] = recovered_3_s[0] ^ (recovered_3_ci || recovered_3_cy);
  assign recovered_3_co[0] = (recovered_3_s[0] & (recovered_3_ci || recovered_3_cy)) | (~recovered_3_s[0] & recovered_3_di[0]);
  assign recovered_3_o[1] = recovered_3_s[1] ^ recovered_3_co[0];
  assign recovered_3_co[1] = (recovered_3_s[1] & recovered_3_co[0]) | (~recovered_3_s[1] & recovered_3_di[1]);
  assign recovered_3_o[2] = recovered_3_s[2] ^ recovered_3_co[1];
  assign recovered_3_co[2] = (recovered_3_s[2] & recovered_3_co[1]) | (~recovered_3_s[2] & recovered_3_di[2]);
  assign recovered_3_o[3] = recovered_3_s[3] ^ recovered_3_co[2];
  assign recovered_3_co[3] = (recovered_3_s[3] & recovered_3_co[2]) | (~recovered_3_s[3] & recovered_3_di[3]);
  assign {p__3_carry__0_n_0,NLW_p__3_carry__0_CO_UNCONNECTED[2:0]} = recovered_3_co;
  assign D[7:4] = recovered_3_o;

  // Reconstructed LUT5: p__3_carry__0_i_1
  assign p__3_carry__0_i_1_n_0 = ((Q[0]) ? (((Q[1]) ? (((Q[4]) ? (((Q[2]) ? (Q[3]) : (1'b1))) : (((Q[2]) ? (Q[3]) : (~(Q[3])))))) : (((Q[4]) ? (((Q[2]) ? (Q[3]) : (~(Q[3])))) : (((Q[2]) ? (1'b1) : (~(Q[3])))))))) : (((Q[1]) ? (((Q[4]) ? (((Q[2]) ? (Q[3]) : (1'b1))) : (((Q[2]) ? (1'b1) : (~(Q[3])))))) : (((Q[4]) ? (((Q[2]) ? (Q[3]) : (~(Q[3])))) : (~(Q[3])))))));

  // Reconstructed LUT5: p__3_carry__0_i_2
  assign p__3_carry__0_i_2_n_0 = ((Q[0]) ? (((Q[1]) ? (((Q[3]) ? (Q[4]) : (((Q[4]) ? (Q[2]) : (~(Q[2])))))) : (((Q[3]) ? (Q[4]) : (((Q[4]) ? (Q[2]) : (1'b1))))))) : (((Q[3]) ? (Q[4]) : (((Q[4]) ? (Q[2]) : (1'b1))))));

  // Reconstructed LUT5: p__3_carry__0_i_3
  assign p__3_carry__0_i_3_n_0 = ((Q[3]) ? (((Q[2]) ? (((Q[4]) ? (1'b0) : (((Q[1]) ? (1'b0) : (~(Q[0])))))) : (((Q[4]) ? (~(Q[1])) : (1'b1))))) : (((Q[2]) ? (((Q[4]) ? (1'b1) : (((Q[1]) ? (Q[0]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT5: p__3_carry__0_i_4
  assign p__3_carry__0_i_4_n_0 = ((Q[2]) ? (((Q[4]) ? (((Q[3]) ? (((Q[1]) ? (1'b1) : (Q[0]))) : (((Q[1]) ? (Q[0]) : (1'b0))))) : (((Q[3]) ? (((Q[1]) ? (1'b0) : (~(Q[0])))) : (((Q[1]) ? (~(Q[0])) : (1'b1))))))) : (((Q[4]) ? (((Q[3]) ? (~(Q[1])) : (1'b1))) : (((Q[3]) ? (Q[1]) : (1'b0))))));

  // Reconstructed LUT4: p__3_carry__0_i_5
  assign p__3_carry__0_i_5_n_0 = ((Q[3]) ? (((Q[1]) ? (((Q[2]) ? (Q[0]) : (1'b0))) : (((Q[2]) ? (~(Q[0])) : (1'b1))))) : (((Q[1]) ? (((Q[2]) ? (~(Q[0])) : (1'b1))) : (((Q[2]) ? (Q[0]) : (1'b0))))));

  // Reconstructed CARRY4: p__3_carry__1
  wire [3:0] recovered_9_co, recovered_9_o, recovered_9_s, recovered_9_di;
  assign recovered_9_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,p__3_carry__1_i_1__1_n_0};
  assign recovered_9_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_9_ci = ((p__3_carry__0_n_0) !== 1'bz) && (p__3_carry__0_n_0);
  wire recovered_9_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_9_o[0] = recovered_9_s[0] ^ (recovered_9_ci || recovered_9_cy);
  assign recovered_9_co[0] = (recovered_9_s[0] & (recovered_9_ci || recovered_9_cy)) | (~recovered_9_s[0] & recovered_9_di[0]);
  assign recovered_9_o[1] = recovered_9_s[1] ^ recovered_9_co[0];
  assign recovered_9_co[1] = (recovered_9_s[1] & recovered_9_co[0]) | (~recovered_9_s[1] & recovered_9_di[1]);
  assign recovered_9_o[2] = recovered_9_s[2] ^ recovered_9_co[1];
  assign recovered_9_co[2] = (recovered_9_s[2] & recovered_9_co[1]) | (~recovered_9_s[2] & recovered_9_di[2]);
  assign recovered_9_o[3] = recovered_9_s[3] ^ recovered_9_co[2];
  assign recovered_9_co[3] = (recovered_9_s[3] & recovered_9_co[2]) | (~recovered_9_s[3] & recovered_9_di[3]);
  assign D[8] = recovered_9_o;

  // Reconstructed LUT5: p__3_carry__1_i_1__1
  assign p__3_carry__1_i_1__1_n_0 = ((Q[4]) ? (1'b0) : (((Q[0]) ? (((Q[1]) ? (((Q[3]) ? (1'b0) : (~(Q[2])))) : (~(Q[3])))) : (~(Q[3])))));

  // Reconstructed LUT2: p__3_carry_i_1__1
  assign p__3_carry_i_1__1_n_0 = ((Q[0]) ? (~(Q[2])) : (Q[2]));

  // Reconstructed LUT2: p__3_carry_i_2__0
  assign p__3_carry_i_2__0_n_0 = ((Q[1]) ? (~(Q[4])) : (Q[4]));

  // Reconstructed LUT2: p__3_carry_i_3
  assign p__3_carry_i_3_n_0 = ((Q[0]) ? (~(Q[3])) : (Q[3]));

endmodule

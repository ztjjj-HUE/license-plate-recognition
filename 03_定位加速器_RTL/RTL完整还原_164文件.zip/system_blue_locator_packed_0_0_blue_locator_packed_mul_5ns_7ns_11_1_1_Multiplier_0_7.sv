// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_5ns_7ns_11_1_1_Multiplier_0_7
   (D,
    DI,
    esc_add_ln68_reg_8723_reg_0_37d4ac7 ,
    esc_add_ln68_reg_8723_reg_0__0_3d80198 ,
    .esc_y_2_reg_2385_reg_4_1138322 (zext_ln74_2_fu_2977_p1),
    esc_ap_CS_fsm_reg_15_c4b990a ,
    esc_y_2_reg_2385_reg_2_11e6904 ,
    esc_add_ln74_reg_6855_reg_8_0e33662 ,
    Q,
    esc_y_2_reg_2385_reg_0_0bfbd5b ,
    esc_y_2_reg_2385_reg_0__0_43e4a8b ,
    esc_y_2_reg_2385_reg_0__1_811c36c ,
    esc_add_ln74_reg_6855_reg_7_6b2f341 ,
    esc_mul_ln215_reg_6908_reg_5_ca59d6b );
  output [8:0]D;
  output [0:0]DI;
  output esc_add_ln68_reg_8723_reg_0_37d4ac7 ;
  output esc_add_ln68_reg_8723_reg_0__0_3d80198 ;
  output esc_ap_CS_fsm_reg_15_c4b990a ;
  output [0:0]esc_y_2_reg_2385_reg_2_11e6904 ;
  input [3:0]esc_add_ln74_reg_6855_reg_8_0e33662 ;
  input [4:0]Q;
  input esc_y_2_reg_2385_reg_0_0bfbd5b ;
  input esc_y_2_reg_2385_reg_0__0_43e4a8b ;
  input [0:0]esc_y_2_reg_2385_reg_0__1_811c36c ;
  input [4:0]esc_add_ln74_reg_6855_reg_7_6b2f341 ;
  input esc_mul_ln215_reg_6908_reg_5_ca59d6b ;
     output [9:9]zext_ln74_2_fu_2977_p1;

  wire esc_const0_a0cf646 ;
  wire [8:0]D;
  wire [0:0]DI;
  wire [4:0]Q;
  wire esc_add_ln68_reg_8723_reg_0_37d4ac7 ;
  wire esc_add_ln68_reg_8723_reg_0__0_3d80198 ;
  wire [4:0]esc_add_ln74_reg_6855_reg_7_6b2f341 ;
  wire [3:0]esc_add_ln74_reg_6855_reg_8_0e33662 ;
  wire esc_ap_CS_fsm_reg_15_c4b990a ;
  wire esc_mul_ln215_reg_6908_reg_5_ca59d6b ;
  wire p__3_carry__0_i_1__2_n_0;
  wire p__3_carry__0_i_2__2_n_0;
  wire p__3_carry__0_i_3__2_n_0;
  wire p__3_carry__0_i_4__2_n_0;
  wire p__3_carry__0_i_5__2_n_0;
  wire p__3_carry__0_n_0;
  wire p__3_carry__1_i_1__2_n_0;
  wire p__3_carry_i_3__2_n_0;
  wire p__3_carry_i_4__1_n_0;
  wire p__3_carry_i_5__1_n_0;
  wire p__3_carry_i_6_n_0;
  wire p__3_carry_i_7__0_n_0;
  wire p__3_carry_n_0;
  wire esc_y_2_reg_2385_reg_0_0bfbd5b ;
  wire esc_y_2_reg_2385_reg_0__0_43e4a8b ;
  wire [0:0]esc_y_2_reg_2385_reg_0__1_811c36c ;
  wire [0:0]esc_y_2_reg_2385_reg_2_11e6904 ;
  wire [9:9]zext_ln74_2_fu_2977_p1;
  wire [3:0]NLW_p__3_carry_CO_UNCONNECTED;
  wire [3:0]NLW_p__3_carry__0_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed LUT6: esc_add_ln74_reg_6855_6__i_2_b85b434
  assign esc_y_2_reg_2385_reg_2_11e6904 = ((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (((esc_ap_CS_fsm_reg_15_c4b990a) ? (esc_add_ln74_reg_6855_reg_7_6b2f341 [2]) : (Q[2]))) : (((Q[1]) ? (((esc_ap_CS_fsm_reg_15_c4b990a) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [1]) ? (esc_add_ln74_reg_6855_reg_7_6b2f341 [2]) : (~(esc_add_ln74_reg_6855_reg_7_6b2f341 [2])))) : (Q[2]))) : (((esc_ap_CS_fsm_reg_15_c4b990a) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [1]) ? (esc_add_ln74_reg_6855_reg_7_6b2f341 [2]) : (~(esc_add_ln74_reg_6855_reg_7_6b2f341 [2])))) : (~(Q[2])))))));

  // Reconstructed LUT3: esc_add_ln74_reg_6855_6__i_3_6b6261e
  assign esc_ap_CS_fsm_reg_15_c4b990a = ((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (1'b0) : (((esc_y_2_reg_2385_reg_0__0_43e4a8b) ? (esc_y_2_reg_2385_reg_0__1_811c36c) : (1'b0))));

  // Reconstructed LUT6: esc_add_ln74_reg_6855_7__i_2_a31b0e4
  assign zext_ln74_2_fu_2977_p1 = ((p__3_carry_i_7__0_n_0) ? (((Q[3]) ? (((esc_ap_CS_fsm_reg_15_c4b990a) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [3]) ? (esc_add_ln74_reg_6855_reg_7_6b2f341 [4]) : (~(esc_add_ln74_reg_6855_reg_7_6b2f341 [4])))) : (Q[4]))) : (((esc_ap_CS_fsm_reg_15_c4b990a) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [3]) ? (esc_add_ln74_reg_6855_reg_7_6b2f341 [4]) : (~(esc_add_ln74_reg_6855_reg_7_6b2f341 [4])))) : (~(Q[4])))))) : (((esc_ap_CS_fsm_reg_15_c4b990a) ? (esc_add_ln74_reg_6855_reg_7_6b2f341 [4]) : (Q[4]))));

  // Reconstructed LUT5: esc_add_ln74_reg_6855_8__i_2_3e299b2
  assign esc_add_ln68_reg_8723_reg_0_37d4ac7 = ((esc_add_ln74_reg_6855_reg_8_0e33662 [3]) ? (((esc_add_ln74_reg_6855_reg_8_0e33662 [2]) ? (((esc_add_ln74_reg_6855_reg_8_0e33662 [0]) ? (((esc_add_ln74_reg_6855_reg_8_0e33662 [1]) ? (1'b0) : (~(esc_add_ln68_reg_8723_reg_0__0_3d80198)))) : (((esc_add_ln74_reg_6855_reg_8_0e33662 [1]) ? (1'b0) : (esc_add_ln68_reg_8723_reg_0__0_3d80198))))) : (((esc_add_ln74_reg_6855_reg_8_0e33662 [0]) ? (~(esc_add_ln74_reg_6855_reg_8_0e33662 [1])) : (((esc_add_ln74_reg_6855_reg_8_0e33662 [1]) ? (~(esc_add_ln68_reg_8723_reg_0__0_3d80198)) : (esc_add_ln68_reg_8723_reg_0__0_3d80198))))))) : (((esc_add_ln74_reg_6855_reg_8_0e33662 [2]) ? (((esc_add_ln74_reg_6855_reg_8_0e33662 [0]) ? (~(esc_add_ln74_reg_6855_reg_8_0e33662 [1])) : (((esc_add_ln74_reg_6855_reg_8_0e33662 [1]) ? (1'b1) : (esc_add_ln68_reg_8723_reg_0__0_3d80198))))) : (((esc_add_ln74_reg_6855_reg_8_0e33662 [0]) ? (1'b1) : (((esc_add_ln74_reg_6855_reg_8_0e33662 [1]) ? (1'b1) : (esc_add_ln68_reg_8723_reg_0__0_3d80198))))))));

  // Reconstructed CARRY4: p__3_carry
  wire [3:0] recovered_6_co, recovered_6_o, recovered_6_s, recovered_6_di;
  assign recovered_6_s = {p__3_carry_i_3__2_n_0,p__3_carry_i_4__1_n_0,p__3_carry_i_5__1_n_0,p__3_carry_i_6_n_0};
  assign recovered_6_di = {esc_const0_a0cf646 ,zext_ln74_2_fu_2977_p1,DI,esc_const0_a0cf646 };
  wire recovered_6_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_6_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_6_o[0] = recovered_6_s[0] ^ (recovered_6_ci || recovered_6_cy);
  assign recovered_6_co[0] = (recovered_6_s[0] & (recovered_6_ci || recovered_6_cy)) | (~recovered_6_s[0] & recovered_6_di[0]);
  assign recovered_6_o[1] = recovered_6_s[1] ^ recovered_6_co[0];
  assign recovered_6_co[1] = (recovered_6_s[1] & recovered_6_co[0]) | (~recovered_6_s[1] & recovered_6_di[1]);
  assign recovered_6_o[2] = recovered_6_s[2] ^ recovered_6_co[1];
  assign recovered_6_co[2] = (recovered_6_s[2] & recovered_6_co[1]) | (~recovered_6_s[2] & recovered_6_di[2]);
  assign recovered_6_o[3] = recovered_6_s[3] ^ recovered_6_co[2];
  assign recovered_6_co[3] = (recovered_6_s[3] & recovered_6_co[2]) | (~recovered_6_s[3] & recovered_6_di[3]);
  assign {p__3_carry_n_0,NLW_p__3_carry_CO_UNCONNECTED[2:0]} = recovered_6_co;
  assign D[3:0] = recovered_6_o;

  // Reconstructed CARRY4: p__3_carry__0
  wire [3:0] recovered_7_co, recovered_7_o, recovered_7_s, recovered_7_di;
  assign recovered_7_s = {p__3_carry__0_i_2__2_n_0,p__3_carry__0_i_3__2_n_0,p__3_carry__0_i_4__2_n_0,p__3_carry__0_i_5__2_n_0};
  assign recovered_7_di = {esc_const0_a0cf646 ,p__3_carry__0_i_1__2_n_0,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_7_ci = ((p__3_carry_n_0) !== 1'bz) && (p__3_carry_n_0);
  wire recovered_7_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_7_o[0] = recovered_7_s[0] ^ (recovered_7_ci || recovered_7_cy);
  assign recovered_7_co[0] = (recovered_7_s[0] & (recovered_7_ci || recovered_7_cy)) | (~recovered_7_s[0] & recovered_7_di[0]);
  assign recovered_7_o[1] = recovered_7_s[1] ^ recovered_7_co[0];
  assign recovered_7_co[1] = (recovered_7_s[1] & recovered_7_co[0]) | (~recovered_7_s[1] & recovered_7_di[1]);
  assign recovered_7_o[2] = recovered_7_s[2] ^ recovered_7_co[1];
  assign recovered_7_co[2] = (recovered_7_s[2] & recovered_7_co[1]) | (~recovered_7_s[2] & recovered_7_di[2]);
  assign recovered_7_o[3] = recovered_7_s[3] ^ recovered_7_co[2];
  assign recovered_7_co[3] = (recovered_7_s[3] & recovered_7_co[2]) | (~recovered_7_s[3] & recovered_7_di[3]);
  assign {p__3_carry__0_n_0,NLW_p__3_carry__0_CO_UNCONNECTED[2:0]} = recovered_7_co;
  assign D[7:4] = recovered_7_o;

  // Reconstructed LUT2: p__3_carry__0_i_1__2
  assign p__3_carry__0_i_1__2_n_0 = ((esc_add_ln68_reg_8723_reg_0_37d4ac7) ? (~(DI)) : (DI));

  // Reconstructed LUT3: p__3_carry__0_i_2__2
  assign p__3_carry__0_i_2__2_n_0 = ((esc_add_ln68_reg_8723_reg_0_37d4ac7) ? (((DI) ? (zext_ln74_2_fu_2977_p1) : (~(zext_ln74_2_fu_2977_p1)))) : (zext_ln74_2_fu_2977_p1));

  // Reconstructed LUT2: p__3_carry__0_i_3__2
  assign p__3_carry__0_i_3__2_n_0 = ((DI) ? (esc_add_ln68_reg_8723_reg_0_37d4ac7) : (~(esc_add_ln68_reg_8723_reg_0_37d4ac7)));

  // Reconstructed LUT5: p__3_carry__0_i_4__2
  assign p__3_carry__0_i_4__2_n_0 = ((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (((esc_add_ln74_reg_6855_reg_8_0e33662 [0]) ? (((esc_add_ln74_reg_6855_reg_8_0e33662 [1]) ? (((zext_ln74_2_fu_2977_p1) ? (esc_add_ln74_reg_6855_reg_8_0e33662 [2]) : (~(esc_add_ln74_reg_6855_reg_8_0e33662 [2])))) : (((zext_ln74_2_fu_2977_p1) ? (~(esc_add_ln74_reg_6855_reg_8_0e33662 [2])) : (esc_add_ln74_reg_6855_reg_8_0e33662 [2]))))) : (((esc_add_ln74_reg_6855_reg_8_0e33662 [1]) ? (~(zext_ln74_2_fu_2977_p1)) : (zext_ln74_2_fu_2977_p1))))) : (((esc_add_ln74_reg_6855_reg_8_0e33662 [0]) ? (((esc_add_ln74_reg_6855_reg_8_0e33662 [1]) ? (((zext_ln74_2_fu_2977_p1) ? (esc_add_ln74_reg_6855_reg_8_0e33662 [2]) : (~(esc_add_ln74_reg_6855_reg_8_0e33662 [2])))) : (zext_ln74_2_fu_2977_p1))) : (((esc_add_ln74_reg_6855_reg_8_0e33662 [1]) ? (((zext_ln74_2_fu_2977_p1) ? (~(esc_add_ln74_reg_6855_reg_8_0e33662 [2])) : (esc_add_ln74_reg_6855_reg_8_0e33662 [2]))) : (zext_ln74_2_fu_2977_p1))))));

  // Reconstructed LUT6: p__3_carry__0_i_5__2
  assign p__3_carry__0_i_5__2_n_0 = ((DI) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [1]) ? (((esc_ap_CS_fsm_reg_15_c4b990a) ? (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b0) : (~(esc_y_2_reg_2385_reg_2_11e6904)))) : (((Q[1]) ? (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b0) : (~(esc_y_2_reg_2385_reg_2_11e6904)))) : (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b1) : (esc_y_2_reg_2385_reg_2_11e6904))))))) : (((esc_ap_CS_fsm_reg_15_c4b990a) ? (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b1) : (esc_y_2_reg_2385_reg_2_11e6904))) : (((Q[1]) ? (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b0) : (~(esc_y_2_reg_2385_reg_2_11e6904)))) : (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b1) : (esc_y_2_reg_2385_reg_2_11e6904))))))))) : (((esc_add_ln74_reg_6855_reg_7_6b2f341 [1]) ? (((esc_ap_CS_fsm_reg_15_c4b990a) ? (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b1) : (esc_y_2_reg_2385_reg_2_11e6904))) : (((Q[1]) ? (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b1) : (esc_y_2_reg_2385_reg_2_11e6904))) : (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b0) : (~(esc_y_2_reg_2385_reg_2_11e6904)))))))) : (((esc_ap_CS_fsm_reg_15_c4b990a) ? (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b0) : (~(esc_y_2_reg_2385_reg_2_11e6904)))) : (((Q[1]) ? (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b1) : (esc_y_2_reg_2385_reg_2_11e6904))) : (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b0) : (~(esc_y_2_reg_2385_reg_2_11e6904)))))))))));

  // Reconstructed CARRY4: p__3_carry__1
  wire [3:0] recovered_13_co, recovered_13_o, recovered_13_s, recovered_13_di;
  assign recovered_13_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,p__3_carry__1_i_1__2_n_0};
  assign recovered_13_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_13_ci = ((p__3_carry__0_n_0) !== 1'bz) && (p__3_carry__0_n_0);
  wire recovered_13_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_13_o[0] = recovered_13_s[0] ^ (recovered_13_ci || recovered_13_cy);
  assign recovered_13_co[0] = (recovered_13_s[0] & (recovered_13_ci || recovered_13_cy)) | (~recovered_13_s[0] & recovered_13_di[0]);
  assign recovered_13_o[1] = recovered_13_s[1] ^ recovered_13_co[0];
  assign recovered_13_co[1] = (recovered_13_s[1] & recovered_13_co[0]) | (~recovered_13_s[1] & recovered_13_di[1]);
  assign recovered_13_o[2] = recovered_13_s[2] ^ recovered_13_co[1];
  assign recovered_13_co[2] = (recovered_13_s[2] & recovered_13_co[1]) | (~recovered_13_s[2] & recovered_13_di[2]);
  assign recovered_13_o[3] = recovered_13_s[3] ^ recovered_13_co[2];
  assign recovered_13_co[3] = (recovered_13_s[3] & recovered_13_co[2]) | (~recovered_13_s[3] & recovered_13_di[3]);
  assign D[8] = recovered_13_o;

  // Reconstructed LUT3: p__3_carry__1_i_1__2
  assign p__3_carry__1_i_1__2_n_0 = ((zext_ln74_2_fu_2977_p1) ? (1'b0) : (((esc_add_ln68_reg_8723_reg_0_37d4ac7) ? (~(DI)) : (1'b0))));

  // Reconstructed LUT6: p__3_carry_i_2
  assign DI = ((p__3_carry_i_7__0_n_0) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [3]) ? (((esc_y_2_reg_2385_reg_0__1_811c36c) ? (((esc_y_2_reg_2385_reg_0__0_43e4a8b) ? (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (~(Q[3])) : (1'b0))) : (~(Q[3])))) : (~(Q[3])))) : (((esc_y_2_reg_2385_reg_0__1_811c36c) ? (((esc_y_2_reg_2385_reg_0__0_43e4a8b) ? (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (~(Q[3])) : (1'b1))) : (~(Q[3])))) : (~(Q[3])))))) : (((esc_add_ln74_reg_6855_reg_7_6b2f341 [3]) ? (((esc_y_2_reg_2385_reg_0__1_811c36c) ? (((esc_y_2_reg_2385_reg_0__0_43e4a8b) ? (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (Q[3]) : (1'b1))) : (Q[3]))) : (Q[3]))) : (((esc_y_2_reg_2385_reg_0__1_811c36c) ? (((esc_y_2_reg_2385_reg_0__0_43e4a8b) ? (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (Q[3]) : (1'b0))) : (Q[3]))) : (Q[3]))))));

  // Reconstructed LUT6: p__3_carry_i_3__2
  assign p__3_carry_i_3__2_n_0 = ((esc_add_ln74_reg_6855_reg_7_6b2f341 [0]) ? (((esc_y_2_reg_2385_reg_0__1_811c36c) ? (((esc_y_2_reg_2385_reg_0__0_43e4a8b) ? (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (((Q[0]) ? (esc_y_2_reg_2385_reg_2_11e6904) : (~(esc_y_2_reg_2385_reg_2_11e6904)))) : (esc_y_2_reg_2385_reg_2_11e6904))) : (((Q[0]) ? (esc_y_2_reg_2385_reg_2_11e6904) : (~(esc_y_2_reg_2385_reg_2_11e6904)))))) : (((Q[0]) ? (esc_y_2_reg_2385_reg_2_11e6904) : (~(esc_y_2_reg_2385_reg_2_11e6904)))))) : (((esc_y_2_reg_2385_reg_0__1_811c36c) ? (((esc_y_2_reg_2385_reg_0__0_43e4a8b) ? (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (((Q[0]) ? (esc_y_2_reg_2385_reg_2_11e6904) : (~(esc_y_2_reg_2385_reg_2_11e6904)))) : (~(esc_y_2_reg_2385_reg_2_11e6904)))) : (((Q[0]) ? (esc_y_2_reg_2385_reg_2_11e6904) : (~(esc_y_2_reg_2385_reg_2_11e6904)))))) : (((Q[0]) ? (esc_y_2_reg_2385_reg_2_11e6904) : (~(esc_y_2_reg_2385_reg_2_11e6904)))))));

  // Reconstructed LUT6: p__3_carry_i_4__1
  assign p__3_carry_i_4__1_n_0 = ((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (((Q[1]) ? (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (~(zext_ln74_2_fu_2977_p1)) : (((esc_mul_ln215_reg_6908_reg_5_ca59d6b) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [1]) ? (~(zext_ln74_2_fu_2977_p1)) : (zext_ln74_2_fu_2977_p1))) : (~(zext_ln74_2_fu_2977_p1)))))) : (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (zext_ln74_2_fu_2977_p1) : (((esc_mul_ln215_reg_6908_reg_5_ca59d6b) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [1]) ? (~(zext_ln74_2_fu_2977_p1)) : (zext_ln74_2_fu_2977_p1))) : (zext_ln74_2_fu_2977_p1))))))) : (((Q[1]) ? (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (zext_ln74_2_fu_2977_p1) : (((esc_mul_ln215_reg_6908_reg_5_ca59d6b) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [1]) ? (zext_ln74_2_fu_2977_p1) : (~(zext_ln74_2_fu_2977_p1)))) : (zext_ln74_2_fu_2977_p1))))) : (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (~(zext_ln74_2_fu_2977_p1)) : (((esc_mul_ln215_reg_6908_reg_5_ca59d6b) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [1]) ? (zext_ln74_2_fu_2977_p1) : (~(zext_ln74_2_fu_2977_p1)))) : (~(zext_ln74_2_fu_2977_p1)))))))));

  // Reconstructed LUT6: p__3_carry_i_5__1
  assign p__3_carry_i_5__1_n_0 = ((esc_add_ln74_reg_6855_reg_7_6b2f341 [0]) ? (((esc_y_2_reg_2385_reg_0__1_811c36c) ? (((esc_y_2_reg_2385_reg_0__0_43e4a8b) ? (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (((Q[0]) ? (DI) : (~(DI)))) : (DI))) : (((Q[0]) ? (DI) : (~(DI)))))) : (((Q[0]) ? (DI) : (~(DI)))))) : (((esc_y_2_reg_2385_reg_0__1_811c36c) ? (((esc_y_2_reg_2385_reg_0__0_43e4a8b) ? (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (((Q[0]) ? (DI) : (~(DI)))) : (~(DI)))) : (((Q[0]) ? (DI) : (~(DI)))))) : (((Q[0]) ? (DI) : (~(DI)))))));

  // Reconstructed LUT6: p__3_carry_i_6
  assign p__3_carry_i_6_n_0 = ((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (((esc_ap_CS_fsm_reg_15_c4b990a) ? (esc_add_ln74_reg_6855_reg_7_6b2f341 [2]) : (Q[2]))) : (((Q[1]) ? (((esc_ap_CS_fsm_reg_15_c4b990a) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [1]) ? (esc_add_ln74_reg_6855_reg_7_6b2f341 [2]) : (~(esc_add_ln74_reg_6855_reg_7_6b2f341 [2])))) : (Q[2]))) : (((esc_ap_CS_fsm_reg_15_c4b990a) ? (((esc_add_ln74_reg_6855_reg_7_6b2f341 [1]) ? (esc_add_ln74_reg_6855_reg_7_6b2f341 [2]) : (~(esc_add_ln74_reg_6855_reg_7_6b2f341 [2])))) : (~(Q[2])))))));

  // Reconstructed LUT6: p__3_carry_i_7__0
  assign p__3_carry_i_7__0_n_0 = ((esc_add_ln74_reg_6855_reg_7_6b2f341 [2]) ? (((esc_ap_CS_fsm_reg_15_c4b990a) ? (1'b0) : (((Q[2]) ? (1'b0) : (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b0) : (~(Q[1])))))))) : (((esc_ap_CS_fsm_reg_15_c4b990a) ? (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b0) : (~(esc_add_ln74_reg_6855_reg_7_6b2f341 [1])))) : (((Q[2]) ? (1'b0) : (((esc_add_ln68_reg_8723_reg_0__0_3d80198) ? (1'b0) : (~(Q[1])))))))));

  // Reconstructed LUT5: esc_y_2_reg_2385_0__i_1_06bbb22
  assign esc_add_ln68_reg_8723_reg_0__0_3d80198 = ((Q[0]) ? (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (1'b1) : (((esc_y_2_reg_2385_reg_0__0_43e4a8b) ? (((esc_y_2_reg_2385_reg_0__1_811c36c) ? (esc_add_ln74_reg_6855_reg_7_6b2f341 [0]) : (1'b1))) : (1'b1))))) : (((esc_y_2_reg_2385_reg_0_0bfbd5b) ? (1'b0) : (((esc_y_2_reg_2385_reg_0__0_43e4a8b) ? (((esc_y_2_reg_2385_reg_0__1_811c36c) ? (esc_add_ln74_reg_6855_reg_7_6b2f341 [0]) : (1'b0))) : (1'b0))))));

endmodule

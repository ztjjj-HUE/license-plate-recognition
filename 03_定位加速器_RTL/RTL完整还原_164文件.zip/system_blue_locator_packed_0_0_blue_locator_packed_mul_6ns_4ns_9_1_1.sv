// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_6ns_4ns_9_1_1
   (D,
    esc_height_reg_2408_reg_3_28b5143 ,
    esc_icmp_ln85_reg_8793_reg_0_dd487cc ,
    mul_ln88_fu_6035_p1,
    Q,
    icmp_ln85_reg_8793,
    esc_mul_ln88_reg_8871_reg_8_56454d7 );
  output [8:0]D;
  output esc_height_reg_2408_reg_3_28b5143 ;
  output esc_icmp_ln85_reg_8793_reg_0_dd487cc ;
  output [1:0]mul_ln88_fu_6035_p1;
  input [3:0]Q;
  input icmp_ln85_reg_8793;
  input [5:0]esc_mul_ln88_reg_8871_reg_8_56454d7 ;

  wire [8:0]D;
  wire [3:0]Q;
  wire esc_height_reg_2408_reg_3_28b5143 ;
  wire icmp_ln85_reg_8793;
  wire esc_icmp_ln85_reg_8793_reg_0_dd487cc ;
  wire [1:0]mul_ln88_fu_6035_p1;
  wire [5:0]esc_mul_ln88_reg_8871_reg_8_56454d7 ;

  system_blue_locator_packed_0_0_blue_locator_packed_mul_6ns_4ns_9_1_1_Multiplier_1 blue_locator_packed_mul_6ns_4ns_9_1_1_Multiplier_1_U
       (.D(D),
        .Q(Q),
        .esc_height_reg_2408_reg_3_28b5143 (esc_height_reg_2408_reg_3_28b5143 ),
        .icmp_ln85_reg_8793(icmp_ln85_reg_8793),
        .esc_icmp_ln85_reg_8793_reg_0_dd487cc (esc_icmp_ln85_reg_8793_reg_0_dd487cc ),
        .esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24 (mul_ln88_fu_6035_p1[0]),
        .esc_icmp_ln85_reg_8793_reg_0__1_2aa9937 (mul_ln88_fu_6035_p1[1]),
        .esc_mul_ln88_reg_8871_reg_8_56454d7 (esc_mul_ln88_reg_8871_reg_8_56454d7 ));
endmodule

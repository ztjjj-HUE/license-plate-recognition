// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_6ns_4ns_9_1_1_Multiplier_1
   (D,
    esc_height_reg_2408_reg_3_28b5143 ,
    esc_icmp_ln85_reg_8793_reg_0_dd487cc ,
    esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24 ,
    esc_icmp_ln85_reg_8793_reg_0__1_2aa9937 ,
    Q,
    icmp_ln85_reg_8793,
    esc_mul_ln88_reg_8871_reg_8_56454d7 );
  output [8:0]D;
  output esc_height_reg_2408_reg_3_28b5143 ;
  output esc_icmp_ln85_reg_8793_reg_0_dd487cc ;
  output esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24 ;
  output esc_icmp_ln85_reg_8793_reg_0__1_2aa9937 ;
  input [3:0]Q;
  input icmp_ln85_reg_8793;
  input [5:0]esc_mul_ln88_reg_8871_reg_8_56454d7 ;

  wire esc_const0_a0cf646 ;
  wire [8:0]D;
  wire [3:0]Q;
  wire esc_height_reg_2408_reg_3_28b5143 ;
  wire icmp_ln85_reg_8793;
  wire esc_icmp_ln85_reg_8793_reg_0_dd487cc ;
  wire esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24 ;
  wire esc_icmp_ln85_reg_8793_reg_0__1_2aa9937 ;
  wire [5:0]esc_mul_ln88_reg_8871_reg_8_56454d7 ;
  wire p__0_carry__0_i_10_n_0;
  wire p__0_carry__0_i_1_n_0;
  wire p__0_carry__0_i_2_n_0;
  wire p__0_carry__0_i_3_n_0;
  wire p__0_carry__0_i_4_n_0;
  wire p__0_carry__0_i_5_n_0;
  wire p__0_carry__0_i_6_n_0;
  wire p__0_carry__0_i_7_n_0;
  wire p__0_carry__0_i_8_n_0;
  wire p__0_carry__0_i_9_n_0;
  wire p__0_carry__0_n_0;
  wire p__0_carry__0_n_4;
  wire p__0_carry__0_n_5;
  wire p__0_carry__0_n_6;
  wire p__0_carry__0_n_7;
  wire p__0_carry__1_i_1_n_0;
  wire p__0_carry__1_n_7;
  wire p__0_carry_i_1_n_0;
  wire p__0_carry_i_2_n_0;
  wire p__0_carry_i_3_n_0;
  wire p__0_carry_i_4_n_0;
  wire p__0_carry_i_5_n_0;
  wire p__0_carry_i_6_n_0;
  wire p__0_carry_i_7_n_0;
  wire p__0_carry_i_8_n_0;
  wire p__0_carry_n_0;
  wire p__0_carry_n_4;
  wire p__0_carry_n_5;
  wire p__24_carry__0_i_1_n_0;
  wire p__24_carry__0_i_2_n_0;
  wire p__24_carry__0_i_3_n_0;
  wire p__24_carry__0_i_4_n_0;
  wire p__24_carry_i_1_n_0;
  wire p__24_carry_i_2_n_0;
  wire p__24_carry_i_3_n_0;
  wire p__24_carry_n_0;
  wire [3:0]NLW_p__0_carry_CO_UNCONNECTED;
  wire [3:0]NLW_p__0_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_p__24_carry_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed LUT4: a_reg_reg_i_3
  assign esc_icmp_ln85_reg_8793_reg_0__1_2aa9937 = ((Q[1]) ? (((Q[0]) ? (((Q[2]) ? (icmp_ln85_reg_8793) : (~(icmp_ln85_reg_8793)))) : (Q[2]))) : (Q[2]));

  // Reconstructed LUT3: a_reg_reg_i_4
  assign esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24 = ((Q[0]) ? (((Q[1]) ? (icmp_ln85_reg_8793) : (~(icmp_ln85_reg_8793)))) : (Q[1]));

  // Reconstructed LUT2: a_reg_reg_i_5
  assign esc_icmp_ln85_reg_8793_reg_0_dd487cc = ((Q[0]) ? (icmp_ln85_reg_8793) : (~(icmp_ln85_reg_8793)));

  // Reconstructed CARRY4: p__0_carry
  wire [3:0] recovered_5_co, recovered_5_o, recovered_5_s, recovered_5_di;
  assign recovered_5_s = {p__0_carry_i_4_n_0,p__0_carry_i_5_n_0,p__0_carry_i_6_n_0,p__0_carry_i_7_n_0};
  assign recovered_5_di = {p__0_carry_i_1_n_0,p__0_carry_i_2_n_0,p__0_carry_i_3_n_0,esc_const0_a0cf646 };
  wire recovered_5_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_5_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_5_o[0] = recovered_5_s[0] ^ (recovered_5_ci || recovered_5_cy);
  assign recovered_5_co[0] = (recovered_5_s[0] & (recovered_5_ci || recovered_5_cy)) | (~recovered_5_s[0] & recovered_5_di[0]);
  assign recovered_5_o[1] = recovered_5_s[1] ^ recovered_5_co[0];
  assign recovered_5_co[1] = (recovered_5_s[1] & recovered_5_co[0]) | (~recovered_5_s[1] & recovered_5_di[1]);
  assign recovered_5_o[2] = recovered_5_s[2] ^ recovered_5_co[1];
  assign recovered_5_co[2] = (recovered_5_s[2] & recovered_5_co[1]) | (~recovered_5_s[2] & recovered_5_di[2]);
  assign recovered_5_o[3] = recovered_5_s[3] ^ recovered_5_co[2];
  assign recovered_5_co[3] = (recovered_5_s[3] & recovered_5_co[2]) | (~recovered_5_s[3] & recovered_5_di[3]);
  assign {p__0_carry_n_0,NLW_p__0_carry_CO_UNCONNECTED[2:0]} = recovered_5_co;
  assign {p__0_carry_n_4,p__0_carry_n_5,D[1:0]} = recovered_5_o;

  // Reconstructed CARRY4: p__0_carry__0
  wire [3:0] recovered_6_co, recovered_6_o, recovered_6_s, recovered_6_di;
  assign recovered_6_s = {p__0_carry__0_i_5_n_0,p__0_carry__0_i_6_n_0,p__0_carry__0_i_7_n_0,p__0_carry__0_i_8_n_0};
  assign recovered_6_di = {p__0_carry__0_i_1_n_0,p__0_carry__0_i_2_n_0,p__0_carry__0_i_3_n_0,p__0_carry__0_i_4_n_0};
  wire recovered_6_ci = ((p__0_carry_n_0) !== 1'bz) && (p__0_carry_n_0);
  wire recovered_6_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_6_o[0] = recovered_6_s[0] ^ (recovered_6_ci || recovered_6_cy);
  assign recovered_6_co[0] = (recovered_6_s[0] & (recovered_6_ci || recovered_6_cy)) | (~recovered_6_s[0] & recovered_6_di[0]);
  assign recovered_6_o[1] = recovered_6_s[1] ^ recovered_6_co[0];
  assign recovered_6_co[1] = (recovered_6_s[1] & recovered_6_co[0]) | (~recovered_6_s[1] & recovered_6_di[1]);
  assign recovered_6_o[2] = recovered_6_s[2] ^ recovered_6_co[1];
  assign recovered_6_co[2] = (recovered_6_s[2] & recovered_6_co[1]) | (~recovered_6_s[2] & recovered_6_di[2]);
  assign recovered_6_o[3] = recovered_6_s[3] ^ recovered_6_co[2];
  assign recovered_6_co[3] = (recovered_6_s[3] & recovered_6_co[2]) | (~recovered_6_s[3] & recovered_6_di[3]);
  assign {p__0_carry__0_n_0,NLW_p__0_carry__0_CO_UNCONNECTED[2:0]} = recovered_6_co;
  assign {p__0_carry__0_n_4,p__0_carry__0_n_5,p__0_carry__0_n_6,p__0_carry__0_n_7} = recovered_6_o;

  // Reconstructed LUT6: p__0_carry__0_i_1
  assign p__0_carry__0_i_1_n_0 = ((Q[0]) ? (((Q[1]) ? (((icmp_ln85_reg_8793) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (1'b1) : (((Q[2]) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) : (1'b0))))) : (((Q[2]) ? (1'b0) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [4]))))) : (((icmp_ln85_reg_8793) ? (((Q[2]) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) : (1'b0))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (1'b1) : (((Q[2]) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) : (1'b0))))))))) : (((Q[1]) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (1'b1) : (((Q[2]) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) : (1'b0))))) : (((Q[2]) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) : (1'b0))))));

  // Reconstructed LUT4: p__0_carry__0_i_10
  assign p__0_carry__0_i_10_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (((icmp_ln85_reg_8793) ? (Q[1]) : (((Q[1]) ? (~(Q[0])) : (Q[0]))))) : (1'b0));

  // Reconstructed LUT6: p__0_carry__0_i_2
  assign p__0_carry__0_i_2_n_0 = ((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (1'b1) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))) : (1'b0))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))) : (1'b0))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: p__0_carry__0_i_3
  assign p__0_carry__0_i_3_n_0 = ((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (1'b1) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))) : (1'b0))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))) : (1'b0))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: p__0_carry__0_i_4
  assign p__0_carry__0_i_4_n_0 = ((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [1]) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (1'b1) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))))) : (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))) : (1'b0))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [1]) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))) : (1'b0))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: p__0_carry__0_i_5
  assign p__0_carry__0_i_5_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (((Q[1]) ? (((Q[0]) ? (((Q[2]) ? (1'b1) : (((icmp_ln85_reg_8793) ? (1'b0) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [4]))))) : (Q[2]))) : (((Q[0]) ? (((Q[2]) ? (((icmp_ln85_reg_8793) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) : (1'b1))) : (icmp_ln85_reg_8793))) : (((Q[2]) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) : (1'b1))))))) : (((Q[1]) ? (((Q[0]) ? (((Q[2]) ? (((icmp_ln85_reg_8793) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [4])) : (1'b1))) : (((icmp_ln85_reg_8793) ? (1'b1) : (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [4])))))) : (((Q[2]) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [4])) : (1'b1))))) : (((Q[2]) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [4])) : (1'b1))))));

  // Reconstructed LUT6: p__0_carry__0_i_6
  assign p__0_carry__0_i_6_n_0 = ((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (1'b0) : (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [3])))) : (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) : (1'b0))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))))) : (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) : (1'b1))) : (1'b1))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) : (1'b0))) : (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [3])) : (1'b1))))) : (1'b1))) : (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [4])) : (1'b1))))));

  // Reconstructed LUT6: p__0_carry__0_i_7
  assign p__0_carry__0_i_7_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (((p__0_carry__0_i_9_n_0) ? (~(p__0_carry__0_i_3_n_0)) : (p__0_carry__0_i_3_n_0))) : (((p__0_carry__0_i_9_n_0) ? (p__0_carry__0_i_3_n_0) : (~(p__0_carry__0_i_3_n_0)))))) : (((p__0_carry__0_i_9_n_0) ? (p__0_carry__0_i_3_n_0) : (~(p__0_carry__0_i_3_n_0)))))) : (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (((p__0_carry__0_i_9_n_0) ? (p__0_carry__0_i_3_n_0) : (~(p__0_carry__0_i_3_n_0)))) : (((p__0_carry__0_i_9_n_0) ? (~(p__0_carry__0_i_3_n_0)) : (p__0_carry__0_i_3_n_0))))) : (((p__0_carry__0_i_9_n_0) ? (~(p__0_carry__0_i_3_n_0)) : (p__0_carry__0_i_3_n_0))))))) : (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (((p__0_carry__0_i_9_n_0) ? (p__0_carry__0_i_3_n_0) : (~(p__0_carry__0_i_3_n_0)))) : (((p__0_carry__0_i_9_n_0) ? (~(p__0_carry__0_i_3_n_0)) : (p__0_carry__0_i_3_n_0))))) : (((p__0_carry__0_i_9_n_0) ? (~(p__0_carry__0_i_3_n_0)) : (p__0_carry__0_i_3_n_0))))));

  // Reconstructed LUT6: p__0_carry__0_i_8
  assign p__0_carry__0_i_8_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (((p__0_carry__0_i_10_n_0) ? (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (~(p__0_carry__0_i_4_n_0)) : (p__0_carry__0_i_4_n_0))) : (p__0_carry__0_i_4_n_0))) : (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (p__0_carry__0_i_4_n_0) : (~(p__0_carry__0_i_4_n_0)))) : (~(p__0_carry__0_i_4_n_0)))))) : (((p__0_carry__0_i_10_n_0) ? (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (p__0_carry__0_i_4_n_0) : (~(p__0_carry__0_i_4_n_0)))) : (~(p__0_carry__0_i_4_n_0)))) : (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (~(p__0_carry__0_i_4_n_0)) : (p__0_carry__0_i_4_n_0))) : (p__0_carry__0_i_4_n_0))))))) : (((p__0_carry__0_i_10_n_0) ? (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (p__0_carry__0_i_4_n_0) : (~(p__0_carry__0_i_4_n_0)))) : (~(p__0_carry__0_i_4_n_0)))) : (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (~(p__0_carry__0_i_4_n_0)) : (p__0_carry__0_i_4_n_0))) : (p__0_carry__0_i_4_n_0))))));

  // Reconstructed LUT5: p__0_carry__0_i_9
  assign p__0_carry__0_i_9_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (((icmp_ln85_reg_8793) ? (Q[2]) : (((Q[2]) ? (((Q[0]) ? (~(Q[1])) : (1'b1))) : (((Q[0]) ? (Q[1]) : (1'b0))))))) : (1'b0));

  // Reconstructed CARRY4: p__0_carry__1
  wire [3:0] recovered_17_co, recovered_17_o, recovered_17_s, recovered_17_di;
  assign recovered_17_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,p__0_carry__1_i_1_n_0};
  assign recovered_17_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_17_ci = ((p__0_carry__0_n_0) !== 1'bz) && (p__0_carry__0_n_0);
  wire recovered_17_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_17_o[0] = recovered_17_s[0] ^ (recovered_17_ci || recovered_17_cy);
  assign recovered_17_co[0] = (recovered_17_s[0] & (recovered_17_ci || recovered_17_cy)) | (~recovered_17_s[0] & recovered_17_di[0]);
  assign recovered_17_o[1] = recovered_17_s[1] ^ recovered_17_co[0];
  assign recovered_17_co[1] = (recovered_17_s[1] & recovered_17_co[0]) | (~recovered_17_s[1] & recovered_17_di[1]);
  assign recovered_17_o[2] = recovered_17_s[2] ^ recovered_17_co[1];
  assign recovered_17_co[2] = (recovered_17_s[2] & recovered_17_co[1]) | (~recovered_17_s[2] & recovered_17_di[2]);
  assign recovered_17_o[3] = recovered_17_s[3] ^ recovered_17_co[2];
  assign recovered_17_co[3] = (recovered_17_s[3] & recovered_17_co[2]) | (~recovered_17_s[3] & recovered_17_di[3]);
  assign p__0_carry__1_n_7 = recovered_17_o;

  // Reconstructed LUT5: p__0_carry__1_i_1
  assign p__0_carry__1_i_1_n_0 = ((icmp_ln85_reg_8793) ? (((Q[2]) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [5])) : (1'b1))) : (((Q[2]) ? (((Q[0]) ? (((Q[1]) ? (1'b1) : (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [5])))) : (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [5])))) : (((Q[0]) ? (((Q[1]) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [5])) : (1'b1))) : (1'b1))))));

  // Reconstructed LUT6: p__0_carry_i_1
  assign p__0_carry_i_1_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [1]) ? (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) : (1'b0))) : (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [3])) : (1'b1))))) : (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [3])) : (1'b1))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [3])) : (1'b1))) : (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) : (1'b0))))) : (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) : (1'b0))))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [3])) : (1'b1))) : (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) : (1'b0))))) : (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) : (1'b0))))));

  // Reconstructed LUT6: p__0_carry_i_2
  assign p__0_carry_i_2_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) ? (((Q[1]) ? (((Q[0]) ? (((Q[2]) ? (((icmp_ln85_reg_8793) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [1])) : (1'b0))) : (((icmp_ln85_reg_8793) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [1]) : (1'b1))))) : (((Q[2]) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [1])) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [1]))))) : (((Q[0]) ? (((Q[2]) ? (((icmp_ln85_reg_8793) ? (1'b1) : (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [1])))) : (((icmp_ln85_reg_8793) ? (1'b0) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [1]))))) : (Q[2]))))) : (((Q[1]) ? (((Q[0]) ? (((icmp_ln85_reg_8793) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [1]) : (1'b0))) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [1]))) : (((Q[0]) ? (((icmp_ln85_reg_8793) ? (1'b0) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [1]))) : (1'b0))))));

  // Reconstructed LUT4: p__0_carry_i_3
  assign p__0_carry_i_3_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) ? (((icmp_ln85_reg_8793) ? (Q[1]) : (((Q[1]) ? (~(Q[0])) : (Q[0]))))) : (1'b0));

  // Reconstructed LUT6: p__0_carry_i_4
  assign p__0_carry_i_4_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [2])) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [2]))) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [2]))) : (((p__0_carry_i_8_n_0) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (~(esc_icmp_ln85_reg_8793_reg_0_dd487cc)) : (1'b1))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))))))) : (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((p__0_carry_i_8_n_0) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) : (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [2])))) : (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [2])))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [2])) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [2]))) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [2]))))) : (((p__0_carry_i_8_n_0) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (~(esc_icmp_ln85_reg_8793_reg_0_dd487cc)) : (1'b1))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (esc_icmp_ln85_reg_8793_reg_0_dd487cc) : (1'b0))))))));

  // Reconstructed LUT6: p__0_carry_i_5
  assign p__0_carry_i_5_n_0 = ((esc_icmp_ln85_reg_8793_reg_0_dd487cc) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [1]) ? (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) : (1'b0))) : (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [0])) : (1'b1))))) : (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [0])) : (1'b1))))) : (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [1]) ? (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [0])) : (1'b1))) : (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) : (1'b0))))) : (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) : (1'b0))))))) : (((esc_icmp_ln85_reg_8793_reg_0__0_4f8ef24) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [1]) ? (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [0])) : (1'b1))) : (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) : (1'b0))))) : (((esc_icmp_ln85_reg_8793_reg_0__1_2aa9937) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) : (1'b0))))));

  // Reconstructed LUT5: p__0_carry_i_6
  assign p__0_carry_i_6_n_0 = ((Q[0]) ? (((Q[1]) ? (((icmp_ln85_reg_8793) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [1])) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [1]))) : (1'b0))) : (((icmp_ln85_reg_8793) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [1]) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [0]))))) : (((Q[1]) ? (((icmp_ln85_reg_8793) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [1])) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [1]))))) : (((icmp_ln85_reg_8793) ? (1'b0) : (esc_mul_ln88_reg_8871_reg_8_56454d7 [1]))))));

  // Reconstructed LUT3: p__0_carry_i_7
  assign p__0_carry_i_7_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) ? (((icmp_ln85_reg_8793) ? (Q[0]) : (~(Q[0])))) : (1'b0));

  // Reconstructed LUT5: p__0_carry_i_8
  assign p__0_carry_i_8_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [1]) ? (((icmp_ln85_reg_8793) ? (Q[2]) : (((Q[2]) ? (((Q[0]) ? (~(Q[1])) : (1'b1))) : (((Q[0]) ? (Q[1]) : (1'b0))))))) : (1'b0));

  // Reconstructed CARRY4: p__24_carry
  wire [3:0] recovered_27_co, recovered_27_o, recovered_27_s, recovered_27_di;
  assign recovered_27_s = {p__24_carry_i_1_n_0,p__24_carry_i_2_n_0,p__24_carry_i_3_n_0,p__0_carry_n_5};
  assign recovered_27_di = {p__0_carry__0_n_6,p__0_carry__0_n_7,p__0_carry_n_4,esc_const0_a0cf646 };
  wire recovered_27_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_27_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_27_o[0] = recovered_27_s[0] ^ (recovered_27_ci || recovered_27_cy);
  assign recovered_27_co[0] = (recovered_27_s[0] & (recovered_27_ci || recovered_27_cy)) | (~recovered_27_s[0] & recovered_27_di[0]);
  assign recovered_27_o[1] = recovered_27_s[1] ^ recovered_27_co[0];
  assign recovered_27_co[1] = (recovered_27_s[1] & recovered_27_co[0]) | (~recovered_27_s[1] & recovered_27_di[1]);
  assign recovered_27_o[2] = recovered_27_s[2] ^ recovered_27_co[1];
  assign recovered_27_co[2] = (recovered_27_s[2] & recovered_27_co[1]) | (~recovered_27_s[2] & recovered_27_di[2]);
  assign recovered_27_o[3] = recovered_27_s[3] ^ recovered_27_co[2];
  assign recovered_27_co[3] = (recovered_27_s[3] & recovered_27_co[2]) | (~recovered_27_s[3] & recovered_27_di[3]);
  assign {p__24_carry_n_0,NLW_p__24_carry_CO_UNCONNECTED[2:0]} = recovered_27_co;
  assign D[5:2] = recovered_27_o;

  // Reconstructed CARRY4: p__24_carry__0
  wire [3:0] recovered_28_co, recovered_28_o, recovered_28_s, recovered_28_di;
  assign recovered_28_s = {esc_const0_a0cf646 ,p__24_carry__0_i_2_n_0,p__24_carry__0_i_3_n_0,p__24_carry__0_i_4_n_0};
  assign recovered_28_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,p__0_carry__0_n_5,p__24_carry__0_i_1_n_0};
  wire recovered_28_ci = ((p__24_carry_n_0) !== 1'bz) && (p__24_carry_n_0);
  wire recovered_28_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_28_o[0] = recovered_28_s[0] ^ (recovered_28_ci || recovered_28_cy);
  assign recovered_28_co[0] = (recovered_28_s[0] & (recovered_28_ci || recovered_28_cy)) | (~recovered_28_s[0] & recovered_28_di[0]);
  assign recovered_28_o[1] = recovered_28_s[1] ^ recovered_28_co[0];
  assign recovered_28_co[1] = (recovered_28_s[1] & recovered_28_co[0]) | (~recovered_28_s[1] & recovered_28_di[1]);
  assign recovered_28_o[2] = recovered_28_s[2] ^ recovered_28_co[1];
  assign recovered_28_co[2] = (recovered_28_s[2] & recovered_28_co[1]) | (~recovered_28_s[2] & recovered_28_di[2]);
  assign recovered_28_o[3] = recovered_28_s[3] ^ recovered_28_co[2];
  assign recovered_28_co[3] = (recovered_28_s[3] & recovered_28_co[2]) | (~recovered_28_s[3] & recovered_28_di[3]);
  assign D[8:6] = recovered_28_o;

  // Reconstructed LUT1: p__24_carry__0_i_1
  assign p__24_carry__0_i_1_n_0 = ~(p__0_carry__0_n_5);

  // Reconstructed LUT5: p__24_carry__0_i_2
  assign p__24_carry__0_i_2_n_0 = ((p__0_carry__1_n_7) ? (((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (((esc_height_reg_2408_reg_3_28b5143) ? (1'b1) : (((p__0_carry__0_n_4) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) : (1'b0))))) : (((esc_height_reg_2408_reg_3_28b5143) ? (1'b1) : (((p__0_carry__0_n_4) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [4])) : (1'b1))))))) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [5]) ? (((esc_height_reg_2408_reg_3_28b5143) ? (1'b0) : (((p__0_carry__0_n_4) ? (~(esc_mul_ln88_reg_8871_reg_8_56454d7 [4])) : (1'b1))))) : (((esc_height_reg_2408_reg_3_28b5143) ? (1'b0) : (((p__0_carry__0_n_4) ? (esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) : (1'b0))))))));

  // Reconstructed LUT4: p__24_carry__0_i_3
  assign p__24_carry__0_i_3_n_0 = ((p__0_carry__0_n_4) ? (((esc_height_reg_2408_reg_3_28b5143) ? (~(p__0_carry__0_n_5)) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (p__0_carry__0_n_5) : (~(p__0_carry__0_n_5)))))) : (((esc_height_reg_2408_reg_3_28b5143) ? (p__0_carry__0_n_5) : (((esc_mul_ln88_reg_8871_reg_8_56454d7 [4]) ? (~(p__0_carry__0_n_5)) : (p__0_carry__0_n_5))))));

  // Reconstructed LUT3: p__24_carry__0_i_4
  assign p__24_carry__0_i_4_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [3]) ? (((esc_height_reg_2408_reg_3_28b5143) ? (~(p__0_carry__0_n_5)) : (p__0_carry__0_n_5))) : (~(p__0_carry__0_n_5)));

  // Reconstructed LUT3: p__24_carry_i_1
  assign p__24_carry_i_1_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [2]) ? (((esc_height_reg_2408_reg_3_28b5143) ? (p__0_carry__0_n_6) : (~(p__0_carry__0_n_6)))) : (p__0_carry__0_n_6));

  // Reconstructed LUT3: p__24_carry_i_2
  assign p__24_carry_i_2_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [1]) ? (((esc_height_reg_2408_reg_3_28b5143) ? (p__0_carry__0_n_7) : (~(p__0_carry__0_n_7)))) : (p__0_carry__0_n_7));

  // Reconstructed LUT3: p__24_carry_i_3
  assign p__24_carry_i_3_n_0 = ((esc_mul_ln88_reg_8871_reg_8_56454d7 [0]) ? (((esc_height_reg_2408_reg_3_28b5143) ? (p__0_carry_n_4) : (~(p__0_carry_n_4)))) : (p__0_carry_n_4));

  // Reconstructed LUT5: p__24_carry_i_4
  assign esc_height_reg_2408_reg_3_28b5143 = ((icmp_ln85_reg_8793) ? (~(Q[3])) : (((Q[0]) ? (((Q[2]) ? (((Q[1]) ? (Q[3]) : (~(Q[3])))) : (~(Q[3])))) : (~(Q[3])))));

endmodule

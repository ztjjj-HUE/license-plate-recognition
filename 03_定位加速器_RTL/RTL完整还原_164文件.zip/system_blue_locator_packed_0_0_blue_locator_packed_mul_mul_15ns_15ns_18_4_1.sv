// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_15ns_15ns_18_4_1
   (P,
    ap_clk,
    A,
    Q,
    icmp_ln89_reg_8917_pp4_iter5_reg);
  output [17:0]P;
  input ap_clk;
  input [14:0]A;
  input [0:0]Q;
  input icmp_ln89_reg_8917_pp4_iter5_reg;

  wire [14:0]A;
  wire [17:0]P;
  wire [0:0]Q;
  wire ap_clk;
  wire icmp_ln89_reg_8917_pp4_iter5_reg;

  system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_15ns_15ns_18_4_1_DSP48_2 blue_locator_packed_mul_mul_15ns_15ns_18_4_1_DSP48_2_U
       (.A(A),
        .P(P),
        .Q(Q),
        .ap_clk(ap_clk),
        .icmp_ln89_reg_8917_pp4_iter5_reg(icmp_ln89_reg_8917_pp4_iter5_reg));
endmodule

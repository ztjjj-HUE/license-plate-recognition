// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_15ns_15ns_18_4_1_DSP48_2
   (P,
    ap_clk,
    A,
    Q,
    icmp_ln89_reg_8917_pp4_iter5_reg);
  output [17:0]P;
  input ap_clk;
  input [14:0]A;
  input [0:0]Q;
  input icmp_ln89_reg_8917_pp4_iter5_reg;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [14:0]A;
  wire GND_2;
  wire [17:0]P;
  wire [0:0]Q;
  wire VCC_2;
  wire ap_clk;
  wire edge_q8_reg_90430;
  wire icmp_ln89_reg_8917_pp4_iter5_reg;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed GND: GND_1
  assign GND_2 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed VCC: VCC_1
  assign VCC_2 = 1'b1;

  DSP48E1 #(
    .ACASCREG(2),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(2),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(2),
    .BREG(2),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(1),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    p_reg_reg
       (.A({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,A}),
        .ACIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .ALUMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .B({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,A}),
        .BCIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .C({VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2}),
        .CARRYCASCIN(esc_const0_a0cf646 ),
        .CARRYIN(esc_const0_a0cf646 ),
        .CARRYINSEL({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .CEA1(edge_q8_reg_90430),
        .CEA2(esc_const1_c064970 ),
        .CEAD(esc_const0_a0cf646 ),
        .CEALUMODE(esc_const0_a0cf646 ),
        .CEB1(edge_q8_reg_90430),
        .CEB2(esc_const1_c064970 ),
        .CEC(esc_const0_a0cf646 ),
        .CECARRYIN(esc_const0_a0cf646 ),
        .CECTRL(esc_const0_a0cf646 ),
        .CED(esc_const0_a0cf646 ),
        .CEINMODE(esc_const0_a0cf646 ),
        .CEM(esc_const1_c064970 ),
        .CEP(esc_const1_c064970 ),
        .CLK(ap_clk),
        .D({GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2}),
        .INMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .MULTSIGNIN(esc_const0_a0cf646 ),
        .OPMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 ,esc_const0_a0cf646 ,esc_const1_c064970 }),
        .P(P),
        .PCIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .RSTA(esc_const0_a0cf646 ),
        .RSTALLCARRYIN(esc_const0_a0cf646 ),
        .RSTALUMODE(esc_const0_a0cf646 ),
        .RSTB(esc_const0_a0cf646 ),
        .RSTC(esc_const0_a0cf646 ),
        .RSTCTRL(esc_const0_a0cf646 ),
        .RSTD(esc_const0_a0cf646 ),
        .RSTINMODE(esc_const0_a0cf646 ),
        .RSTM(esc_const0_a0cf646 ),
        .RSTP(esc_const0_a0cf646 ));

  // Reconstructed LUT2: p_reg_reg_i_1__1
  assign edge_q8_reg_90430 = ((icmp_ln89_reg_8917_pp4_iter5_reg) ? (1'b0) : (Q));

endmodule

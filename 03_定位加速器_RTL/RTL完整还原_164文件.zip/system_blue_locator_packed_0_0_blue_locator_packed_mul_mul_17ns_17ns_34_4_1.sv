// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_17ns_17ns_34_4_1
   (tmp_8_fu_6303_p4,
    D,
    p_reg_reg,
    Q,
    ap_clk,
    B,
    ret_4_fu_6266_p2,
    p_reg_reg_0);
  output [13:0]tmp_8_fu_6303_p4;
  output [14:0]D;
  output [14:0]p_reg_reg;
  input [0:0]Q;
  input ap_clk;
  input [16:0]B;
  input [14:0]ret_4_fu_6266_p2;
  input [14:0]p_reg_reg_0;

  wire [16:0]B;
  wire [14:0]D;
  wire [0:0]Q;
  wire ap_clk;
  wire [14:0]p_reg_reg;
  wire [14:0]p_reg_reg_0;
  wire [14:0]ret_4_fu_6266_p2;
  wire [13:0]tmp_8_fu_6303_p4;

  system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_17ns_17ns_34_4_1_DSP48_0 blue_locator_packed_mul_mul_17ns_17ns_34_4_1_DSP48_0_U
       (.B(B),
        .D(D),
        .Q(Q),
        .ap_clk(ap_clk),
        .p_reg_reg_0(p_reg_reg),
        .p_reg_reg_1(p_reg_reg_0),
        .ret_4_fu_6266_p2(ret_4_fu_6266_p2),
        .tmp_8_fu_6303_p4(tmp_8_fu_6303_p4));
endmodule

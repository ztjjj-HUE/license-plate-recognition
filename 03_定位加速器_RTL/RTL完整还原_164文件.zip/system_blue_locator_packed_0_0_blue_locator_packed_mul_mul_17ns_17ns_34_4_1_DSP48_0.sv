// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_17ns_17ns_34_4_1_DSP48_0
   (tmp_8_fu_6303_p4,
    D,
    p_reg_reg_0,
    Q,
    ap_clk,
    B,
    ret_4_fu_6266_p2,
    p_reg_reg_1);
  output [13:0]tmp_8_fu_6303_p4;
  output [14:0]D;
  output [14:0]p_reg_reg_0;
  input [0:0]Q;
  input ap_clk;
  input [16:0]B;
  input [14:0]ret_4_fu_6266_p2;
  input [14:0]p_reg_reg_1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [16:0]B;
  wire [14:0]D;
  wire GND_2;
  wire [0:0]Q;
  wire VCC_2;
  wire a_reg_reg_i_7_n_0;
  wire a_reg_reg_i_8_n_0;
  wire a_reg_reg_i_9_n_0;
  wire ap_clk;
  wire [14:0]p_reg_reg_0;
  wire [14:0]p_reg_reg_1;
  wire p_reg_reg_i_10_n_0;
  wire p_reg_reg_i_11_n_0;
  wire p_reg_reg_i_12_n_0;
  wire p_reg_reg_i_13_n_0;
  wire p_reg_reg_i_15_n_0;
  wire p_reg_reg_i_16_n_0;
  wire p_reg_reg_i_17_n_0;
  wire p_reg_reg_i_18_n_0;
  wire p_reg_reg_i_20_n_0;
  wire p_reg_reg_i_21_n_0;
  wire p_reg_reg_i_22_n_0;
  wire p_reg_reg_i_23__0_n_0;
  wire p_reg_reg_i_2_n_0;
  wire p_reg_reg_i_3_n_0;
  wire p_reg_reg_i_4_n_0;
  wire p_reg_reg_i_6_n_0;
  wire p_reg_reg_i_7_n_0;
  wire p_reg_reg_i_8_n_0;
  wire [14:0]ret_4_fu_6266_p2;
  wire [13:0]tmp_8_fu_6303_p4;
  wire [3:0]NLW_a_reg_reg_i_6_CO_UNCONNECTED;
  wire [3:0]NLW_a_reg_reg_i_7_CO_UNCONNECTED;
  wire [3:0]NLW_a_reg_reg_i_8_CO_UNCONNECTED;
  wire [3:0]NLW_a_reg_reg_i_9_CO_UNCONNECTED;
  wire [47:0]NLW_p_reg_reg_P_UNCONNECTED;
  wire [3:0]NLW_p_reg_reg_i_2_CO_UNCONNECTED;
  wire [3:0]NLW_p_reg_reg_i_3_CO_UNCONNECTED;
  wire [3:0]NLW_p_reg_reg_i_4_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed GND: GND_1
  assign GND_2 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed VCC: VCC_1
  assign VCC_2 = 1'b1;

  // Reconstructed LUT1: a_reg_reg_i_10
  assign p_reg_reg_0[0] = ~(tmp_8_fu_6303_p4[0]);

  // Reconstructed CARRY4: a_reg_reg_i_6
  wire [3:0] recovered_6_co, recovered_6_o, recovered_6_s, recovered_6_di;
  assign recovered_6_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 ,tmp_8_fu_6303_p4[13]};
  assign recovered_6_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_6_ci = ((a_reg_reg_i_7_n_0) !== 1'bz) && (a_reg_reg_i_7_n_0);
  wire recovered_6_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_6_o[0] = recovered_6_s[0] ^ (recovered_6_ci || recovered_6_cy);
  assign recovered_6_co[0] = (recovered_6_s[0] & (recovered_6_ci || recovered_6_cy)) | (~recovered_6_s[0] & recovered_6_di[0]);
  assign recovered_6_o[1] = recovered_6_s[1] ^ recovered_6_co[0];
  assign recovered_6_co[1] = (recovered_6_s[1] & recovered_6_co[0]) | (~recovered_6_s[1] & recovered_6_di[1]);
  assign recovered_6_o[2] = recovered_6_s[2] ^ recovered_6_co[1];
  assign recovered_6_co[2] = (recovered_6_s[2] & recovered_6_co[1]) | (~recovered_6_s[2] & recovered_6_di[2]);
  assign recovered_6_o[3] = recovered_6_s[3] ^ recovered_6_co[2];
  assign recovered_6_co[3] = (recovered_6_s[3] & recovered_6_co[2]) | (~recovered_6_s[3] & recovered_6_di[3]);
  assign {p_reg_reg_0[14],NLW_a_reg_reg_i_6_CO_UNCONNECTED[0]} = recovered_6_co;
  assign p_reg_reg_0[13] = recovered_6_o;

  // Reconstructed CARRY4: a_reg_reg_i_7
  wire [3:0] recovered_7_co, recovered_7_o, recovered_7_s, recovered_7_di;
  assign recovered_7_s = tmp_8_fu_6303_p4[12:9];
  assign recovered_7_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_7_ci = ((a_reg_reg_i_8_n_0) !== 1'bz) && (a_reg_reg_i_8_n_0);
  wire recovered_7_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_7_o[0] = recovered_7_s[0] ^ (recovered_7_ci || recovered_7_cy);
  assign recovered_7_co[0] = (recovered_7_s[0] & (recovered_7_ci || recovered_7_cy)) | (~recovered_7_s[0] & recovered_7_di[0]);
  assign recovered_7_o[1] = recovered_7_s[1] ^ recovered_7_co[0];
  assign recovered_7_co[1] = (recovered_7_s[1] & recovered_7_co[0]) | (~recovered_7_s[1] & recovered_7_di[1]);
  assign recovered_7_o[2] = recovered_7_s[2] ^ recovered_7_co[1];
  assign recovered_7_co[2] = (recovered_7_s[2] & recovered_7_co[1]) | (~recovered_7_s[2] & recovered_7_di[2]);
  assign recovered_7_o[3] = recovered_7_s[3] ^ recovered_7_co[2];
  assign recovered_7_co[3] = (recovered_7_s[3] & recovered_7_co[2]) | (~recovered_7_s[3] & recovered_7_di[3]);
  assign {a_reg_reg_i_7_n_0,NLW_a_reg_reg_i_7_CO_UNCONNECTED[2:0]} = recovered_7_co;
  assign p_reg_reg_0[12:9] = recovered_7_o;

  // Reconstructed CARRY4: a_reg_reg_i_8
  wire [3:0] recovered_8_co, recovered_8_o, recovered_8_s, recovered_8_di;
  assign recovered_8_s = tmp_8_fu_6303_p4[8:5];
  assign recovered_8_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_8_ci = ((a_reg_reg_i_9_n_0) !== 1'bz) && (a_reg_reg_i_9_n_0);
  wire recovered_8_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_8_o[0] = recovered_8_s[0] ^ (recovered_8_ci || recovered_8_cy);
  assign recovered_8_co[0] = (recovered_8_s[0] & (recovered_8_ci || recovered_8_cy)) | (~recovered_8_s[0] & recovered_8_di[0]);
  assign recovered_8_o[1] = recovered_8_s[1] ^ recovered_8_co[0];
  assign recovered_8_co[1] = (recovered_8_s[1] & recovered_8_co[0]) | (~recovered_8_s[1] & recovered_8_di[1]);
  assign recovered_8_o[2] = recovered_8_s[2] ^ recovered_8_co[1];
  assign recovered_8_co[2] = (recovered_8_s[2] & recovered_8_co[1]) | (~recovered_8_s[2] & recovered_8_di[2]);
  assign recovered_8_o[3] = recovered_8_s[3] ^ recovered_8_co[2];
  assign recovered_8_co[3] = (recovered_8_s[3] & recovered_8_co[2]) | (~recovered_8_s[3] & recovered_8_di[3]);
  assign {a_reg_reg_i_8_n_0,NLW_a_reg_reg_i_8_CO_UNCONNECTED[2:0]} = recovered_8_co;
  assign p_reg_reg_0[8:5] = recovered_8_o;

  // Reconstructed CARRY4: a_reg_reg_i_9
  wire [3:0] recovered_9_co, recovered_9_o, recovered_9_s, recovered_9_di;
  assign recovered_9_s = tmp_8_fu_6303_p4[4:1];
  assign recovered_9_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_9_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_9_cy = ((tmp_8_fu_6303_p4[0]) !== 1'bz) && (tmp_8_fu_6303_p4[0]);
  assign recovered_9_o[0] = recovered_9_s[0] ^ (recovered_9_ci || recovered_9_cy);
  assign recovered_9_co[0] = (recovered_9_s[0] & (recovered_9_ci || recovered_9_cy)) | (~recovered_9_s[0] & recovered_9_di[0]);
  assign recovered_9_o[1] = recovered_9_s[1] ^ recovered_9_co[0];
  assign recovered_9_co[1] = (recovered_9_s[1] & recovered_9_co[0]) | (~recovered_9_s[1] & recovered_9_di[1]);
  assign recovered_9_o[2] = recovered_9_s[2] ^ recovered_9_co[1];
  assign recovered_9_co[2] = (recovered_9_s[2] & recovered_9_co[1]) | (~recovered_9_s[2] & recovered_9_di[2]);
  assign recovered_9_o[3] = recovered_9_s[3] ^ recovered_9_co[2];
  assign recovered_9_co[3] = (recovered_9_s[3] & recovered_9_co[2]) | (~recovered_9_s[3] & recovered_9_di[3]);
  assign {a_reg_reg_i_9_n_0,NLW_a_reg_reg_i_9_CO_UNCONNECTED[2:0]} = recovered_9_co;
  assign p_reg_reg_0[4:1] = recovered_9_o;

  DSP48E1 #(
    .ACASCREG(1),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(1),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(2),
    .BREG(2),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(1),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    p_reg_reg
       (.A({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,D,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .ACIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .ALUMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .B({esc_const0_a0cf646 ,B}),
        .BCIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .C({VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2}),
        .CARRYCASCIN(esc_const0_a0cf646 ),
        .CARRYIN(esc_const0_a0cf646 ),
        .CARRYINSEL({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .CEA1(esc_const0_a0cf646 ),
        .CEA2(esc_const1_c064970 ),
        .CEAD(esc_const0_a0cf646 ),
        .CEALUMODE(esc_const0_a0cf646 ),
        .CEB1(Q),
        .CEB2(esc_const1_c064970 ),
        .CEC(esc_const0_a0cf646 ),
        .CECARRYIN(esc_const0_a0cf646 ),
        .CECTRL(esc_const0_a0cf646 ),
        .CED(esc_const0_a0cf646 ),
        .CEINMODE(esc_const0_a0cf646 ),
        .CEM(esc_const1_c064970 ),
        .CEP(esc_const1_c064970 ),
        .CLK(ap_clk),
        .D({GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2}),
        .INMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .MULTSIGNIN(esc_const0_a0cf646 ),
        .OPMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 ,esc_const0_a0cf646 ,esc_const1_c064970 }),
        .P({tmp_8_fu_6303_p4,NLW_p_reg_reg_P_UNCONNECTED[19:0]}),
        .PCIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .RSTA(esc_const0_a0cf646 ),
        .RSTALLCARRYIN(esc_const0_a0cf646 ),
        .RSTALUMODE(esc_const0_a0cf646 ),
        .RSTB(esc_const0_a0cf646 ),
        .RSTC(esc_const0_a0cf646 ),
        .RSTCTRL(esc_const0_a0cf646 ),
        .RSTD(esc_const0_a0cf646 ),
        .RSTINMODE(esc_const0_a0cf646 ),
        .RSTM(esc_const0_a0cf646 ),
        .RSTP(esc_const0_a0cf646 ));

  // Reconstructed CARRY4: p_reg_reg_i_1
  wire [3:0] recovered_11_co, recovered_11_o, recovered_11_s, recovered_11_di;
  assign recovered_11_s = {esc_const0_a0cf646 ,p_reg_reg_i_6_n_0,p_reg_reg_i_7_n_0,p_reg_reg_i_8_n_0};
  assign recovered_11_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,ret_4_fu_6266_p2[13:12]};
  wire recovered_11_ci = ((p_reg_reg_i_2_n_0) !== 1'bz) && (p_reg_reg_i_2_n_0);
  wire recovered_11_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_11_o[0] = recovered_11_s[0] ^ (recovered_11_ci || recovered_11_cy);
  assign recovered_11_co[0] = (recovered_11_s[0] & (recovered_11_ci || recovered_11_cy)) | (~recovered_11_s[0] & recovered_11_di[0]);
  assign recovered_11_o[1] = recovered_11_s[1] ^ recovered_11_co[0];
  assign recovered_11_co[1] = (recovered_11_s[1] & recovered_11_co[0]) | (~recovered_11_s[1] & recovered_11_di[1]);
  assign recovered_11_o[2] = recovered_11_s[2] ^ recovered_11_co[1];
  assign recovered_11_co[2] = (recovered_11_s[2] & recovered_11_co[1]) | (~recovered_11_s[2] & recovered_11_di[2]);
  assign recovered_11_o[3] = recovered_11_s[3] ^ recovered_11_co[2];
  assign recovered_11_co[3] = (recovered_11_s[3] & recovered_11_co[2]) | (~recovered_11_s[3] & recovered_11_di[3]);
  assign D[14:12] = recovered_11_o;

  // Reconstructed LUT2: p_reg_reg_i_10
  assign p_reg_reg_i_10_n_0 = ((p_reg_reg_1[11]) ? (~(ret_4_fu_6266_p2[11])) : (ret_4_fu_6266_p2[11]));

  // Reconstructed LUT2: p_reg_reg_i_11
  assign p_reg_reg_i_11_n_0 = ((p_reg_reg_1[10]) ? (~(ret_4_fu_6266_p2[10])) : (ret_4_fu_6266_p2[10]));

  // Reconstructed LUT2: p_reg_reg_i_12
  assign p_reg_reg_i_12_n_0 = ((p_reg_reg_1[9]) ? (~(ret_4_fu_6266_p2[9])) : (ret_4_fu_6266_p2[9]));

  // Reconstructed LUT2: p_reg_reg_i_13
  assign p_reg_reg_i_13_n_0 = ((p_reg_reg_1[8]) ? (~(ret_4_fu_6266_p2[8])) : (ret_4_fu_6266_p2[8]));

  // Reconstructed LUT2: p_reg_reg_i_15
  assign p_reg_reg_i_15_n_0 = ((p_reg_reg_1[7]) ? (~(ret_4_fu_6266_p2[7])) : (ret_4_fu_6266_p2[7]));

  // Reconstructed LUT2: p_reg_reg_i_16
  assign p_reg_reg_i_16_n_0 = ((p_reg_reg_1[6]) ? (~(ret_4_fu_6266_p2[6])) : (ret_4_fu_6266_p2[6]));

  // Reconstructed LUT2: p_reg_reg_i_17
  assign p_reg_reg_i_17_n_0 = ((p_reg_reg_1[5]) ? (~(ret_4_fu_6266_p2[5])) : (ret_4_fu_6266_p2[5]));

  // Reconstructed LUT2: p_reg_reg_i_18
  assign p_reg_reg_i_18_n_0 = ((p_reg_reg_1[4]) ? (~(ret_4_fu_6266_p2[4])) : (ret_4_fu_6266_p2[4]));

  // Reconstructed CARRY4: p_reg_reg_i_2
  wire [3:0] recovered_20_co, recovered_20_o, recovered_20_s, recovered_20_di;
  assign recovered_20_s = {p_reg_reg_i_10_n_0,p_reg_reg_i_11_n_0,p_reg_reg_i_12_n_0,p_reg_reg_i_13_n_0};
  assign recovered_20_di = ret_4_fu_6266_p2[11:8];
  wire recovered_20_ci = ((p_reg_reg_i_3_n_0) !== 1'bz) && (p_reg_reg_i_3_n_0);
  wire recovered_20_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_20_o[0] = recovered_20_s[0] ^ (recovered_20_ci || recovered_20_cy);
  assign recovered_20_co[0] = (recovered_20_s[0] & (recovered_20_ci || recovered_20_cy)) | (~recovered_20_s[0] & recovered_20_di[0]);
  assign recovered_20_o[1] = recovered_20_s[1] ^ recovered_20_co[0];
  assign recovered_20_co[1] = (recovered_20_s[1] & recovered_20_co[0]) | (~recovered_20_s[1] & recovered_20_di[1]);
  assign recovered_20_o[2] = recovered_20_s[2] ^ recovered_20_co[1];
  assign recovered_20_co[2] = (recovered_20_s[2] & recovered_20_co[1]) | (~recovered_20_s[2] & recovered_20_di[2]);
  assign recovered_20_o[3] = recovered_20_s[3] ^ recovered_20_co[2];
  assign recovered_20_co[3] = (recovered_20_s[3] & recovered_20_co[2]) | (~recovered_20_s[3] & recovered_20_di[3]);
  assign {p_reg_reg_i_2_n_0,NLW_p_reg_reg_i_2_CO_UNCONNECTED[2:0]} = recovered_20_co;
  assign D[11:8] = recovered_20_o;

  // Reconstructed LUT2: p_reg_reg_i_20
  assign p_reg_reg_i_20_n_0 = ((p_reg_reg_1[3]) ? (~(ret_4_fu_6266_p2[3])) : (ret_4_fu_6266_p2[3]));

  // Reconstructed LUT2: p_reg_reg_i_21
  assign p_reg_reg_i_21_n_0 = ((p_reg_reg_1[2]) ? (~(ret_4_fu_6266_p2[2])) : (ret_4_fu_6266_p2[2]));

  // Reconstructed LUT2: p_reg_reg_i_22
  assign p_reg_reg_i_22_n_0 = ((p_reg_reg_1[1]) ? (~(ret_4_fu_6266_p2[1])) : (ret_4_fu_6266_p2[1]));

  // Reconstructed LUT2: p_reg_reg_i_23__0
  assign p_reg_reg_i_23__0_n_0 = ((p_reg_reg_1[0]) ? (~(ret_4_fu_6266_p2[0])) : (ret_4_fu_6266_p2[0]));

  // Reconstructed CARRY4: p_reg_reg_i_3
  wire [3:0] recovered_25_co, recovered_25_o, recovered_25_s, recovered_25_di;
  assign recovered_25_s = {p_reg_reg_i_15_n_0,p_reg_reg_i_16_n_0,p_reg_reg_i_17_n_0,p_reg_reg_i_18_n_0};
  assign recovered_25_di = ret_4_fu_6266_p2[7:4];
  wire recovered_25_ci = ((p_reg_reg_i_4_n_0) !== 1'bz) && (p_reg_reg_i_4_n_0);
  wire recovered_25_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_25_o[0] = recovered_25_s[0] ^ (recovered_25_ci || recovered_25_cy);
  assign recovered_25_co[0] = (recovered_25_s[0] & (recovered_25_ci || recovered_25_cy)) | (~recovered_25_s[0] & recovered_25_di[0]);
  assign recovered_25_o[1] = recovered_25_s[1] ^ recovered_25_co[0];
  assign recovered_25_co[1] = (recovered_25_s[1] & recovered_25_co[0]) | (~recovered_25_s[1] & recovered_25_di[1]);
  assign recovered_25_o[2] = recovered_25_s[2] ^ recovered_25_co[1];
  assign recovered_25_co[2] = (recovered_25_s[2] & recovered_25_co[1]) | (~recovered_25_s[2] & recovered_25_di[2]);
  assign recovered_25_o[3] = recovered_25_s[3] ^ recovered_25_co[2];
  assign recovered_25_co[3] = (recovered_25_s[3] & recovered_25_co[2]) | (~recovered_25_s[3] & recovered_25_di[3]);
  assign {p_reg_reg_i_3_n_0,NLW_p_reg_reg_i_3_CO_UNCONNECTED[2:0]} = recovered_25_co;
  assign D[7:4] = recovered_25_o;

  // Reconstructed CARRY4: p_reg_reg_i_4
  wire [3:0] recovered_26_co, recovered_26_o, recovered_26_s, recovered_26_di;
  assign recovered_26_s = {p_reg_reg_i_20_n_0,p_reg_reg_i_21_n_0,p_reg_reg_i_22_n_0,p_reg_reg_i_23__0_n_0};
  assign recovered_26_di = ret_4_fu_6266_p2[3:0];
  wire recovered_26_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_26_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_26_o[0] = recovered_26_s[0] ^ (recovered_26_ci || recovered_26_cy);
  assign recovered_26_co[0] = (recovered_26_s[0] & (recovered_26_ci || recovered_26_cy)) | (~recovered_26_s[0] & recovered_26_di[0]);
  assign recovered_26_o[1] = recovered_26_s[1] ^ recovered_26_co[0];
  assign recovered_26_co[1] = (recovered_26_s[1] & recovered_26_co[0]) | (~recovered_26_s[1] & recovered_26_di[1]);
  assign recovered_26_o[2] = recovered_26_s[2] ^ recovered_26_co[1];
  assign recovered_26_co[2] = (recovered_26_s[2] & recovered_26_co[1]) | (~recovered_26_s[2] & recovered_26_di[2]);
  assign recovered_26_o[3] = recovered_26_s[3] ^ recovered_26_co[2];
  assign recovered_26_co[3] = (recovered_26_s[3] & recovered_26_co[2]) | (~recovered_26_s[3] & recovered_26_di[3]);
  assign {p_reg_reg_i_4_n_0,NLW_p_reg_reg_i_4_CO_UNCONNECTED[2:0]} = recovered_26_co;
  assign D[3:0] = recovered_26_o;

  // Reconstructed LUT2: p_reg_reg_i_6
  assign p_reg_reg_i_6_n_0 = ((ret_4_fu_6266_p2[14]) ? (~(p_reg_reg_1[14])) : (p_reg_reg_1[14]));

  // Reconstructed LUT2: p_reg_reg_i_7
  assign p_reg_reg_i_7_n_0 = ((p_reg_reg_1[13]) ? (~(ret_4_fu_6266_p2[13])) : (ret_4_fu_6266_p2[13]));

  // Reconstructed LUT2: p_reg_reg_i_8
  assign p_reg_reg_i_8_n_0 = ((p_reg_reg_1[12]) ? (~(ret_4_fu_6266_p2[12])) : (ret_4_fu_6266_p2[12]));

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_18ns_17ns_35_4_1
   (D,
    ap_clk,
    P,
    Q,
    ret_1_fu_6377_p2);
  output [34:0]D;
  input ap_clk;
  input [17:0]P;
  input [16:0]Q;
  input [16:0]ret_1_fu_6377_p2;

  wire [34:0]D;
  wire [17:0]P;
  wire [16:0]Q;
  wire ap_clk;
  wire [16:0]ret_1_fu_6377_p2;

  system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_18ns_17ns_35_4_1_DSP48_4 blue_locator_packed_mul_mul_18ns_17ns_35_4_1_DSP48_4_U
       (.D(D),
        .P(P),
        .Q(Q),
        .ap_clk(ap_clk),
        .ret_1_fu_6377_p2(ret_1_fu_6377_p2));
endmodule

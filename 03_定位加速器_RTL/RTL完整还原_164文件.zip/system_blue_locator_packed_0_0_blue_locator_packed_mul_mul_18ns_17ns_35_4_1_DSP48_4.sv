// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_18ns_17ns_35_4_1_DSP48_4
   (D,
    ap_clk,
    P,
    Q,
    ret_1_fu_6377_p2);
  output [34:0]D;
  input ap_clk;
  input [17:0]P;
  input [16:0]Q;
  input [16:0]ret_1_fu_6377_p2;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [34:0]D;
  wire GND_2;
  wire [17:0]P;
  wire [16:0]Q;
  wire VCC_2;
  wire ap_clk;
  wire [16:0]grp_fu_6713_p1;
  wire p_reg_reg_i_10__0_n_0;
  wire p_reg_reg_i_11__0_n_0;
  wire p_reg_reg_i_12__0_n_0;
  wire p_reg_reg_i_13__0_n_0;
  wire p_reg_reg_i_14__0_n_0;
  wire p_reg_reg_i_15__0_n_0;
  wire p_reg_reg_i_16__0_n_0;
  wire p_reg_reg_i_17__0_n_0;
  wire p_reg_reg_i_18__0_n_0;
  wire p_reg_reg_i_19__0_n_0;
  wire p_reg_reg_i_20__0_n_0;
  wire p_reg_reg_i_21__0_n_0;
  wire p_reg_reg_i_22__0_n_0;
  wire p_reg_reg_i_2__0_n_0;
  wire p_reg_reg_i_3__0_n_0;
  wire p_reg_reg_i_4__0_n_0;
  wire p_reg_reg_i_5__0_n_0;
  wire p_reg_reg_i_6__0_n_0;
  wire p_reg_reg_i_7__0_n_0;
  wire p_reg_reg_i_8__0_n_0;
  wire p_reg_reg_i_9__0_n_0;
  wire [16:0]ret_1_fu_6377_p2;
  wire [3:0]NLW_p_reg_reg_i_2__0_CO_UNCONNECTED;
  wire [3:0]NLW_p_reg_reg_i_3__0_CO_UNCONNECTED;
  wire [3:0]NLW_p_reg_reg_i_4__0_CO_UNCONNECTED;
  wire [3:0]NLW_p_reg_reg_i_5__0_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed GND: GND_1
  assign GND_2 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed VCC: VCC_1
  assign VCC_2 = 1'b1;

  DSP48E1 #(
    .ACASCREG(1),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(1),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(1),
    .BREG(1),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(1),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    p_reg_reg
       (.A({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,P}),
        .ACIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .ALUMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .B({esc_const0_a0cf646 ,grp_fu_6713_p1}),
        .BCIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .C({VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2}),
        .CARRYCASCIN(esc_const0_a0cf646 ),
        .CARRYIN(esc_const0_a0cf646 ),
        .CARRYINSEL({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .CEA1(esc_const0_a0cf646 ),
        .CEA2(esc_const1_c064970 ),
        .CEAD(esc_const0_a0cf646 ),
        .CEALUMODE(esc_const0_a0cf646 ),
        .CEB1(esc_const0_a0cf646 ),
        .CEB2(esc_const1_c064970 ),
        .CEC(esc_const0_a0cf646 ),
        .CECARRYIN(esc_const0_a0cf646 ),
        .CECTRL(esc_const0_a0cf646 ),
        .CED(esc_const0_a0cf646 ),
        .CEINMODE(esc_const0_a0cf646 ),
        .CEM(esc_const1_c064970 ),
        .CEP(esc_const1_c064970 ),
        .CLK(ap_clk),
        .D({GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2}),
        .INMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .MULTSIGNIN(esc_const0_a0cf646 ),
        .OPMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 ,esc_const0_a0cf646 ,esc_const1_c064970 }),
        .P(D),
        .PCIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .RSTA(esc_const0_a0cf646 ),
        .RSTALLCARRYIN(esc_const0_a0cf646 ),
        .RSTALUMODE(esc_const0_a0cf646 ),
        .RSTB(esc_const0_a0cf646 ),
        .RSTC(esc_const0_a0cf646 ),
        .RSTCTRL(esc_const0_a0cf646 ),
        .RSTD(esc_const0_a0cf646 ),
        .RSTINMODE(esc_const0_a0cf646 ),
        .RSTM(esc_const0_a0cf646 ),
        .RSTP(esc_const0_a0cf646 ));

  // Reconstructed LUT2: p_reg_reg_i_10__0
  assign p_reg_reg_i_10__0_n_0 = ((ret_1_fu_6377_p2[12]) ? (~(Q[12])) : (Q[12]));

  // Reconstructed LUT2: p_reg_reg_i_11__0
  assign p_reg_reg_i_11__0_n_0 = ((ret_1_fu_6377_p2[11]) ? (~(Q[11])) : (Q[11]));

  // Reconstructed LUT2: p_reg_reg_i_12__0
  assign p_reg_reg_i_12__0_n_0 = ((ret_1_fu_6377_p2[10]) ? (~(Q[10])) : (Q[10]));

  // Reconstructed LUT2: p_reg_reg_i_13__0
  assign p_reg_reg_i_13__0_n_0 = ((ret_1_fu_6377_p2[9]) ? (~(Q[9])) : (Q[9]));

  // Reconstructed LUT2: p_reg_reg_i_14__0
  assign p_reg_reg_i_14__0_n_0 = ((ret_1_fu_6377_p2[8]) ? (~(Q[8])) : (Q[8]));

  // Reconstructed LUT2: p_reg_reg_i_15__0
  assign p_reg_reg_i_15__0_n_0 = ((ret_1_fu_6377_p2[7]) ? (~(Q[7])) : (Q[7]));

  // Reconstructed LUT2: p_reg_reg_i_16__0
  assign p_reg_reg_i_16__0_n_0 = ((ret_1_fu_6377_p2[6]) ? (~(Q[6])) : (Q[6]));

  // Reconstructed LUT2: p_reg_reg_i_17__0
  assign p_reg_reg_i_17__0_n_0 = ((ret_1_fu_6377_p2[5]) ? (~(Q[5])) : (Q[5]));

  // Reconstructed LUT2: p_reg_reg_i_18__0
  assign p_reg_reg_i_18__0_n_0 = ((ret_1_fu_6377_p2[4]) ? (~(Q[4])) : (Q[4]));

  // Reconstructed LUT2: p_reg_reg_i_19__0
  assign p_reg_reg_i_19__0_n_0 = ((ret_1_fu_6377_p2[3]) ? (~(Q[3])) : (Q[3]));

  // Reconstructed CARRY4: p_reg_reg_i_1__0
  wire [3:0] recovered_16_co, recovered_16_o, recovered_16_s, recovered_16_di;
  assign recovered_16_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,p_reg_reg_i_6__0_n_0};
  assign recovered_16_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_16_ci = ((p_reg_reg_i_2__0_n_0) !== 1'bz) && (p_reg_reg_i_2__0_n_0);
  wire recovered_16_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_16_o[0] = recovered_16_s[0] ^ (recovered_16_ci || recovered_16_cy);
  assign recovered_16_co[0] = (recovered_16_s[0] & (recovered_16_ci || recovered_16_cy)) | (~recovered_16_s[0] & recovered_16_di[0]);
  assign recovered_16_o[1] = recovered_16_s[1] ^ recovered_16_co[0];
  assign recovered_16_co[1] = (recovered_16_s[1] & recovered_16_co[0]) | (~recovered_16_s[1] & recovered_16_di[1]);
  assign recovered_16_o[2] = recovered_16_s[2] ^ recovered_16_co[1];
  assign recovered_16_co[2] = (recovered_16_s[2] & recovered_16_co[1]) | (~recovered_16_s[2] & recovered_16_di[2]);
  assign recovered_16_o[3] = recovered_16_s[3] ^ recovered_16_co[2];
  assign recovered_16_co[3] = (recovered_16_s[3] & recovered_16_co[2]) | (~recovered_16_s[3] & recovered_16_di[3]);
  assign grp_fu_6713_p1[16] = recovered_16_o;

  // Reconstructed LUT2: p_reg_reg_i_20__0
  assign p_reg_reg_i_20__0_n_0 = ((ret_1_fu_6377_p2[2]) ? (~(Q[2])) : (Q[2]));

  // Reconstructed LUT2: p_reg_reg_i_21__0
  assign p_reg_reg_i_21__0_n_0 = ((ret_1_fu_6377_p2[1]) ? (~(Q[1])) : (Q[1]));

  // Reconstructed LUT2: p_reg_reg_i_22__0
  assign p_reg_reg_i_22__0_n_0 = ((ret_1_fu_6377_p2[0]) ? (~(Q[0])) : (Q[0]));

  // Reconstructed CARRY4: p_reg_reg_i_2__0
  wire [3:0] recovered_20_co, recovered_20_o, recovered_20_s, recovered_20_di;
  assign recovered_20_s = {p_reg_reg_i_7__0_n_0,p_reg_reg_i_8__0_n_0,p_reg_reg_i_9__0_n_0,p_reg_reg_i_10__0_n_0};
  assign recovered_20_di = Q[15:12];
  wire recovered_20_ci = ((p_reg_reg_i_3__0_n_0) !== 1'bz) && (p_reg_reg_i_3__0_n_0);
  wire recovered_20_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_20_o[0] = recovered_20_s[0] ^ (recovered_20_ci || recovered_20_cy);
  assign recovered_20_co[0] = (recovered_20_s[0] & (recovered_20_ci || recovered_20_cy)) | (~recovered_20_s[0] & recovered_20_di[0]);
  assign recovered_20_o[1] = recovered_20_s[1] ^ recovered_20_co[0];
  assign recovered_20_co[1] = (recovered_20_s[1] & recovered_20_co[0]) | (~recovered_20_s[1] & recovered_20_di[1]);
  assign recovered_20_o[2] = recovered_20_s[2] ^ recovered_20_co[1];
  assign recovered_20_co[2] = (recovered_20_s[2] & recovered_20_co[1]) | (~recovered_20_s[2] & recovered_20_di[2]);
  assign recovered_20_o[3] = recovered_20_s[3] ^ recovered_20_co[2];
  assign recovered_20_co[3] = (recovered_20_s[3] & recovered_20_co[2]) | (~recovered_20_s[3] & recovered_20_di[3]);
  assign {p_reg_reg_i_2__0_n_0,NLW_p_reg_reg_i_2__0_CO_UNCONNECTED[2:0]} = recovered_20_co;
  assign grp_fu_6713_p1[15:12] = recovered_20_o;

  // Reconstructed CARRY4: p_reg_reg_i_3__0
  wire [3:0] recovered_21_co, recovered_21_o, recovered_21_s, recovered_21_di;
  assign recovered_21_s = {p_reg_reg_i_11__0_n_0,p_reg_reg_i_12__0_n_0,p_reg_reg_i_13__0_n_0,p_reg_reg_i_14__0_n_0};
  assign recovered_21_di = Q[11:8];
  wire recovered_21_ci = ((p_reg_reg_i_4__0_n_0) !== 1'bz) && (p_reg_reg_i_4__0_n_0);
  wire recovered_21_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_21_o[0] = recovered_21_s[0] ^ (recovered_21_ci || recovered_21_cy);
  assign recovered_21_co[0] = (recovered_21_s[0] & (recovered_21_ci || recovered_21_cy)) | (~recovered_21_s[0] & recovered_21_di[0]);
  assign recovered_21_o[1] = recovered_21_s[1] ^ recovered_21_co[0];
  assign recovered_21_co[1] = (recovered_21_s[1] & recovered_21_co[0]) | (~recovered_21_s[1] & recovered_21_di[1]);
  assign recovered_21_o[2] = recovered_21_s[2] ^ recovered_21_co[1];
  assign recovered_21_co[2] = (recovered_21_s[2] & recovered_21_co[1]) | (~recovered_21_s[2] & recovered_21_di[2]);
  assign recovered_21_o[3] = recovered_21_s[3] ^ recovered_21_co[2];
  assign recovered_21_co[3] = (recovered_21_s[3] & recovered_21_co[2]) | (~recovered_21_s[3] & recovered_21_di[3]);
  assign {p_reg_reg_i_3__0_n_0,NLW_p_reg_reg_i_3__0_CO_UNCONNECTED[2:0]} = recovered_21_co;
  assign grp_fu_6713_p1[11:8] = recovered_21_o;

  // Reconstructed CARRY4: p_reg_reg_i_4__0
  wire [3:0] recovered_22_co, recovered_22_o, recovered_22_s, recovered_22_di;
  assign recovered_22_s = {p_reg_reg_i_15__0_n_0,p_reg_reg_i_16__0_n_0,p_reg_reg_i_17__0_n_0,p_reg_reg_i_18__0_n_0};
  assign recovered_22_di = Q[7:4];
  wire recovered_22_ci = ((p_reg_reg_i_5__0_n_0) !== 1'bz) && (p_reg_reg_i_5__0_n_0);
  wire recovered_22_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_22_o[0] = recovered_22_s[0] ^ (recovered_22_ci || recovered_22_cy);
  assign recovered_22_co[0] = (recovered_22_s[0] & (recovered_22_ci || recovered_22_cy)) | (~recovered_22_s[0] & recovered_22_di[0]);
  assign recovered_22_o[1] = recovered_22_s[1] ^ recovered_22_co[0];
  assign recovered_22_co[1] = (recovered_22_s[1] & recovered_22_co[0]) | (~recovered_22_s[1] & recovered_22_di[1]);
  assign recovered_22_o[2] = recovered_22_s[2] ^ recovered_22_co[1];
  assign recovered_22_co[2] = (recovered_22_s[2] & recovered_22_co[1]) | (~recovered_22_s[2] & recovered_22_di[2]);
  assign recovered_22_o[3] = recovered_22_s[3] ^ recovered_22_co[2];
  assign recovered_22_co[3] = (recovered_22_s[3] & recovered_22_co[2]) | (~recovered_22_s[3] & recovered_22_di[3]);
  assign {p_reg_reg_i_4__0_n_0,NLW_p_reg_reg_i_4__0_CO_UNCONNECTED[2:0]} = recovered_22_co;
  assign grp_fu_6713_p1[7:4] = recovered_22_o;

  // Reconstructed CARRY4: p_reg_reg_i_5__0
  wire [3:0] recovered_23_co, recovered_23_o, recovered_23_s, recovered_23_di;
  assign recovered_23_s = {p_reg_reg_i_19__0_n_0,p_reg_reg_i_20__0_n_0,p_reg_reg_i_21__0_n_0,p_reg_reg_i_22__0_n_0};
  assign recovered_23_di = Q[3:0];
  wire recovered_23_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_23_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_23_o[0] = recovered_23_s[0] ^ (recovered_23_ci || recovered_23_cy);
  assign recovered_23_co[0] = (recovered_23_s[0] & (recovered_23_ci || recovered_23_cy)) | (~recovered_23_s[0] & recovered_23_di[0]);
  assign recovered_23_o[1] = recovered_23_s[1] ^ recovered_23_co[0];
  assign recovered_23_co[1] = (recovered_23_s[1] & recovered_23_co[0]) | (~recovered_23_s[1] & recovered_23_di[1]);
  assign recovered_23_o[2] = recovered_23_s[2] ^ recovered_23_co[1];
  assign recovered_23_co[2] = (recovered_23_s[2] & recovered_23_co[1]) | (~recovered_23_s[2] & recovered_23_di[2]);
  assign recovered_23_o[3] = recovered_23_s[3] ^ recovered_23_co[2];
  assign recovered_23_co[3] = (recovered_23_s[3] & recovered_23_co[2]) | (~recovered_23_s[3] & recovered_23_di[3]);
  assign {p_reg_reg_i_5__0_n_0,NLW_p_reg_reg_i_5__0_CO_UNCONNECTED[2:0]} = recovered_23_co;
  assign grp_fu_6713_p1[3:0] = recovered_23_o;

  // Reconstructed LUT2: p_reg_reg_i_6__0
  assign p_reg_reg_i_6__0_n_0 = ((ret_1_fu_6377_p2[16]) ? (~(Q[16])) : (Q[16]));

  // Reconstructed LUT2: p_reg_reg_i_7__0
  assign p_reg_reg_i_7__0_n_0 = ((ret_1_fu_6377_p2[15]) ? (~(Q[15])) : (Q[15]));

  // Reconstructed LUT2: p_reg_reg_i_8__0
  assign p_reg_reg_i_8__0_n_0 = ((ret_1_fu_6377_p2[14]) ? (~(Q[14])) : (Q[14]));

  // Reconstructed LUT2: p_reg_reg_i_9__0
  assign p_reg_reg_i_9__0_n_0 = ((ret_1_fu_6377_p2[13]) ? (~(Q[13])) : (Q[13]));

endmodule

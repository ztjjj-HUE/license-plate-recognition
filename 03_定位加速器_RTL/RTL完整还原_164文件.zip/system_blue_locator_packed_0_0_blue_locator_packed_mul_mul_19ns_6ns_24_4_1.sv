// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_19ns_6ns_24_4_1
   (E,
    B,
    A,
    Q,
    ap_clk,
    a_reg_reg,
    D,
    p_reg_reg,
    icmp_ln85_reg_8793,
    a_reg_reg_0,
    icmp_ln89_reg_8917_pp4_iter3_reg,
    zext_ln890_fu_6333_p1,
    p_reg_reg_0,
    p_reg_reg_1);
  output [0:0]E;
  output [0:0]B;
  output [14:0]A;
  input [3:0]Q;
  input ap_clk;
  input [2:0]a_reg_reg;
  input [14:0]D;
  input [5:0]p_reg_reg;
  input icmp_ln85_reg_8793;
  input [3:0]a_reg_reg_0;
  input icmp_ln89_reg_8917_pp4_iter3_reg;
  input [14:0]zext_ln890_fu_6333_p1;
  input [14:0]p_reg_reg_0;
  input [13:0]p_reg_reg_1;

  wire [14:0]A;
  wire [0:0]B;
  wire [14:0]D;
  wire [0:0]E;
  wire [3:0]Q;
  wire [2:0]a_reg_reg;
  wire [3:0]a_reg_reg_0;
  wire ap_clk;
  wire icmp_ln85_reg_8793;
  wire icmp_ln89_reg_8917_pp4_iter3_reg;
  wire [5:0]p_reg_reg;
  wire [14:0]p_reg_reg_0;
  wire [13:0]p_reg_reg_1;
  wire [14:0]zext_ln890_fu_6333_p1;

  system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_19ns_6ns_24_4_1_DSP48_1 blue_locator_packed_mul_mul_19ns_6ns_24_4_1_DSP48_1_U
       (.A(A),
        .B(B),
        .D(D),
        .E(E),
        .Q(Q),
        .a_reg_reg_0(a_reg_reg),
        .a_reg_reg_1(a_reg_reg_0),
        .ap_clk(ap_clk),
        .icmp_ln85_reg_8793(icmp_ln85_reg_8793),
        .icmp_ln89_reg_8917_pp4_iter3_reg(icmp_ln89_reg_8917_pp4_iter3_reg),
        .p_reg_reg_0(p_reg_reg),
        .p_reg_reg_1(p_reg_reg_0),
        .p_reg_reg_2(p_reg_reg_1),
        .zext_ln890_fu_6333_p1(zext_ln890_fu_6333_p1));
endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_19ns_6ns_24_4_1_DSP48_1
   (E,
    B,
    A,
    Q,
    ap_clk,
    a_reg_reg_0,
    D,
    p_reg_reg_0,
    icmp_ln85_reg_8793,
    a_reg_reg_1,
    icmp_ln89_reg_8917_pp4_iter3_reg,
    zext_ln890_fu_6333_p1,
    p_reg_reg_1,
    p_reg_reg_2);
  output [0:0]E;
  output [0:0]B;
  output [14:0]A;
  input [3:0]Q;
  input ap_clk;
  input [2:0]a_reg_reg_0;
  input [14:0]D;
  input [5:0]p_reg_reg_0;
  input icmp_ln85_reg_8793;
  input [3:0]a_reg_reg_1;
  input icmp_ln89_reg_8917_pp4_iter3_reg;
  input [14:0]zext_ln890_fu_6333_p1;
  input [14:0]p_reg_reg_1;
  input [13:0]p_reg_reg_2;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [14:0]A;
  wire [0:0]B;
  wire [14:0]D;
  wire [0:0]E;
  wire GND_2;
  wire [3:0]Q;
  wire VCC_2;
  wire [2:0]a_reg_reg_0;
  wire [3:0]a_reg_reg_1;
  wire a_reg_reg_n_100;
  wire a_reg_reg_n_101;
  wire a_reg_reg_n_102;
  wire a_reg_reg_n_103;
  wire a_reg_reg_n_104;
  wire a_reg_reg_n_105;
  wire a_reg_reg_n_87;
  wire a_reg_reg_n_88;
  wire a_reg_reg_n_89;
  wire a_reg_reg_n_90;
  wire a_reg_reg_n_91;
  wire a_reg_reg_n_92;
  wire a_reg_reg_n_93;
  wire a_reg_reg_n_94;
  wire a_reg_reg_n_95;
  wire a_reg_reg_n_96;
  wire a_reg_reg_n_97;
  wire a_reg_reg_n_98;
  wire a_reg_reg_n_99;
  wire ap_clk;
  wire icmp_ln85_reg_8793;
  wire icmp_ln890_fu_6336_p2;
  wire icmp_ln89_reg_8917_pp4_iter3_reg;
  wire mul_ln108_reg_90330;
  wire [5:0]p_reg_reg_0;
  wire [14:0]p_reg_reg_1;
  wire [13:0]p_reg_reg_2;
  wire p_reg_reg_i_17__1_n_7;
  wire p_reg_reg_i_19__1_n_0;
  wire p_reg_reg_i_20__1_n_0;
  wire p_reg_reg_i_21__1_n_0;
  wire p_reg_reg_i_22__1_n_0;
  wire p_reg_reg_i_23__1_n_0;
  wire p_reg_reg_i_24__1_n_0;
  wire p_reg_reg_i_25__1_n_0;
  wire p_reg_reg_i_26__1_n_0;
  wire p_reg_reg_i_27__1_n_0;
  wire p_reg_reg_i_28_n_0;
  wire p_reg_reg_i_29_n_0;
  wire p_reg_reg_i_30_n_0;
  wire p_reg_reg_i_31_n_0;
  wire p_reg_reg_i_32_n_0;
  wire p_reg_reg_i_33_n_0;
  wire p_reg_reg_i_34_n_0;
  wire p_reg_reg_i_35_n_0;
  wire p_reg_reg_i_36_n_0;
  wire p_reg_reg_i_37_n_0;
  wire p_reg_reg_i_38_n_0;
  wire p_reg_reg_i_39_n_0;
  wire p_reg_reg_i_40_n_0;
  wire p_reg_reg_i_41_n_0;
  wire p_reg_reg_i_42_n_0;
  wire p_reg_reg_i_43_n_0;
  wire p_reg_reg_i_44__0_n_0;
  wire p_reg_reg_n_100;
  wire p_reg_reg_n_101;
  wire p_reg_reg_n_102;
  wire p_reg_reg_n_103;
  wire p_reg_reg_n_104;
  wire p_reg_reg_n_105;
  wire p_reg_reg_n_82;
  wire p_reg_reg_n_83;
  wire p_reg_reg_n_84;
  wire p_reg_reg_n_85;
  wire p_reg_reg_n_86;
  wire p_reg_reg_n_87;
  wire p_reg_reg_n_88;
  wire p_reg_reg_n_89;
  wire p_reg_reg_n_90;
  wire p_reg_reg_n_91;
  wire p_reg_reg_n_92;
  wire p_reg_reg_n_93;
  wire p_reg_reg_n_94;
  wire p_reg_reg_n_95;
  wire p_reg_reg_n_96;
  wire p_reg_reg_n_97;
  wire p_reg_reg_n_98;
  wire p_reg_reg_n_99;
  wire [14:0]zext_ln890_fu_6333_p1;
  wire [3:0]NLW_p_reg_reg_i_18__1_CO_UNCONNECTED;
  wire [3:0]NLW_p_reg_reg_i_19__1_CO_UNCONNECTED;
  wire [3:0]NLW_p_reg_reg_i_28_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed GND: GND_1
  assign GND_2 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed VCC: VCC_1
  assign VCC_2 = 1'b1;

  DSP48E1 #(
    .ACASCREG(1),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(1),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(1),
    .BREG(1),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(1),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    a_reg_reg
       (.A({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,D}),
        .ACIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .ALUMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .B({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,B,a_reg_reg_0}),
        .BCIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .C({VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2}),
        .CARRYCASCIN(esc_const0_a0cf646 ),
        .CARRYIN(esc_const0_a0cf646 ),
        .CARRYINSEL({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .CEA1(esc_const0_a0cf646 ),
        .CEA2(E),
        .CEAD(esc_const0_a0cf646 ),
        .CEALUMODE(esc_const0_a0cf646 ),
        .CEB1(esc_const0_a0cf646 ),
        .CEB2(Q[0]),
        .CEC(esc_const0_a0cf646 ),
        .CECARRYIN(esc_const0_a0cf646 ),
        .CECTRL(esc_const0_a0cf646 ),
        .CED(esc_const0_a0cf646 ),
        .CEINMODE(esc_const0_a0cf646 ),
        .CEM(mul_ln108_reg_90330),
        .CEP(esc_const1_c064970 ),
        .CLK(ap_clk),
        .D({GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2}),
        .INMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .MULTSIGNIN(esc_const0_a0cf646 ),
        .OPMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 ,esc_const0_a0cf646 ,esc_const1_c064970 }),
        .P({a_reg_reg_n_87,a_reg_reg_n_88,a_reg_reg_n_89,a_reg_reg_n_90,a_reg_reg_n_91,a_reg_reg_n_92,a_reg_reg_n_93,a_reg_reg_n_94,a_reg_reg_n_95,a_reg_reg_n_96,a_reg_reg_n_97,a_reg_reg_n_98,a_reg_reg_n_99,a_reg_reg_n_100,a_reg_reg_n_101,a_reg_reg_n_102,a_reg_reg_n_103,a_reg_reg_n_104,a_reg_reg_n_105}),
        .PCIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .RSTA(esc_const0_a0cf646 ),
        .RSTALLCARRYIN(esc_const0_a0cf646 ),
        .RSTALUMODE(esc_const0_a0cf646 ),
        .RSTB(esc_const0_a0cf646 ),
        .RSTC(esc_const0_a0cf646 ),
        .RSTCTRL(esc_const0_a0cf646 ),
        .RSTD(esc_const0_a0cf646 ),
        .RSTINMODE(esc_const0_a0cf646 ),
        .RSTM(esc_const0_a0cf646 ),
        .RSTP(esc_const0_a0cf646 ));

  // Reconstructed LUT2: a_reg_reg_i_1
  assign mul_ln108_reg_90330 = ((icmp_ln89_reg_8917_pp4_iter3_reg) ? (1'b0) : (Q[2]));

  // Reconstructed LUT5: a_reg_reg_i_2
  assign B = ((a_reg_reg_1[3]) ? (((a_reg_reg_1[1]) ? (((a_reg_reg_1[2]) ? (((a_reg_reg_1[0]) ? (icmp_ln85_reg_8793) : (1'b1))) : (1'b1))) : (1'b1))) : (((a_reg_reg_1[1]) ? (((a_reg_reg_1[2]) ? (((a_reg_reg_1[0]) ? (~(icmp_ln85_reg_8793)) : (1'b0))) : (1'b0))) : (1'b0))));

  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(2),
    .BREG(2),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(1),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    p_reg_reg
       (.A({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,a_reg_reg_n_87,a_reg_reg_n_88,a_reg_reg_n_89,a_reg_reg_n_90,a_reg_reg_n_91,a_reg_reg_n_92,a_reg_reg_n_93,a_reg_reg_n_94,a_reg_reg_n_95,a_reg_reg_n_96,a_reg_reg_n_97,a_reg_reg_n_98,a_reg_reg_n_99,a_reg_reg_n_100,a_reg_reg_n_101,a_reg_reg_n_102,a_reg_reg_n_103,a_reg_reg_n_104,a_reg_reg_n_105}),
        .ACIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .ALUMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .B({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,p_reg_reg_0}),
        .BCIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .C({VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2,VCC_2}),
        .CARRYCASCIN(esc_const0_a0cf646 ),
        .CARRYIN(esc_const0_a0cf646 ),
        .CARRYINSEL({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .CEA1(esc_const0_a0cf646 ),
        .CEA2(esc_const0_a0cf646 ),
        .CEAD(esc_const0_a0cf646 ),
        .CEALUMODE(esc_const0_a0cf646 ),
        .CEB1(Q[1]),
        .CEB2(esc_const1_c064970 ),
        .CEC(esc_const0_a0cf646 ),
        .CECARRYIN(esc_const0_a0cf646 ),
        .CECTRL(esc_const0_a0cf646 ),
        .CED(esc_const0_a0cf646 ),
        .CEINMODE(esc_const0_a0cf646 ),
        .CEM(esc_const1_c064970 ),
        .CEP(esc_const1_c064970 ),
        .CLK(ap_clk),
        .D({GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2,GND_2}),
        .INMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .MULTSIGNIN(esc_const0_a0cf646 ),
        .OPMODE({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 ,esc_const0_a0cf646 ,esc_const1_c064970 }),
        .P({p_reg_reg_n_82,p_reg_reg_n_83,p_reg_reg_n_84,p_reg_reg_n_85,p_reg_reg_n_86,p_reg_reg_n_87,p_reg_reg_n_88,p_reg_reg_n_89,p_reg_reg_n_90,p_reg_reg_n_91,p_reg_reg_n_92,p_reg_reg_n_93,p_reg_reg_n_94,p_reg_reg_n_95,p_reg_reg_n_96,p_reg_reg_n_97,p_reg_reg_n_98,p_reg_reg_n_99,p_reg_reg_n_100,p_reg_reg_n_101,p_reg_reg_n_102,p_reg_reg_n_103,p_reg_reg_n_104,p_reg_reg_n_105}),
        .PCIN({esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .RSTA(esc_const0_a0cf646 ),
        .RSTALLCARRYIN(esc_const0_a0cf646 ),
        .RSTALUMODE(esc_const0_a0cf646 ),
        .RSTB(esc_const0_a0cf646 ),
        .RSTC(esc_const0_a0cf646 ),
        .RSTCTRL(esc_const0_a0cf646 ),
        .RSTD(esc_const0_a0cf646 ),
        .RSTINMODE(esc_const0_a0cf646 ),
        .RSTM(esc_const0_a0cf646 ),
        .RSTP(esc_const0_a0cf646 ));

  // Reconstructed LUT3: p_reg_reg_i_10__1
  assign A[6] = ((p_reg_reg_2[6]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[6]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[6]) : (1'b0))));

  // Reconstructed LUT3: p_reg_reg_i_11__1
  assign A[5] = ((p_reg_reg_2[5]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[5]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[5]) : (1'b0))));

  // Reconstructed LUT3: p_reg_reg_i_12__1
  assign A[4] = ((p_reg_reg_2[4]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[4]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[4]) : (1'b0))));

  // Reconstructed LUT3: p_reg_reg_i_13__1
  assign A[3] = ((p_reg_reg_2[3]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[3]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[3]) : (1'b0))));

  // Reconstructed LUT3: p_reg_reg_i_14__1
  assign A[2] = ((p_reg_reg_2[2]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[2]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[2]) : (1'b0))));

  // Reconstructed LUT3: p_reg_reg_i_15__1
  assign A[1] = ((p_reg_reg_2[1]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[1]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[1]) : (1'b0))));

  // Reconstructed LUT3: p_reg_reg_i_16__1
  assign A[0] = ((p_reg_reg_2[0]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[0]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[0]) : (1'b0))));

  // Reconstructed CARRY4: p_reg_reg_i_17__1
  wire [3:0] recovered_16_co, recovered_16_o, recovered_16_s, recovered_16_di;
  assign recovered_16_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const1_c064970 };
  assign recovered_16_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_16_ci = ((icmp_ln890_fu_6336_p2) !== 1'bz) && (icmp_ln890_fu_6336_p2);
  wire recovered_16_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_16_o[0] = recovered_16_s[0] ^ (recovered_16_ci || recovered_16_cy);
  assign recovered_16_co[0] = (recovered_16_s[0] & (recovered_16_ci || recovered_16_cy)) | (~recovered_16_s[0] & recovered_16_di[0]);
  assign recovered_16_o[1] = recovered_16_s[1] ^ recovered_16_co[0];
  assign recovered_16_co[1] = (recovered_16_s[1] & recovered_16_co[0]) | (~recovered_16_s[1] & recovered_16_di[1]);
  assign recovered_16_o[2] = recovered_16_s[2] ^ recovered_16_co[1];
  assign recovered_16_co[2] = (recovered_16_s[2] & recovered_16_co[1]) | (~recovered_16_s[2] & recovered_16_di[2]);
  assign recovered_16_o[3] = recovered_16_s[3] ^ recovered_16_co[2];
  assign recovered_16_co[3] = (recovered_16_s[3] & recovered_16_co[2]) | (~recovered_16_s[3] & recovered_16_di[3]);
  assign p_reg_reg_i_17__1_n_7 = recovered_16_o;

  // Reconstructed CARRY4: p_reg_reg_i_18__1
  wire [3:0] recovered_17_co, recovered_17_o, recovered_17_s, recovered_17_di;
  assign recovered_17_s = {p_reg_reg_i_24__1_n_0,p_reg_reg_i_25__1_n_0,p_reg_reg_i_26__1_n_0,p_reg_reg_i_27__1_n_0};
  assign recovered_17_di = {p_reg_reg_i_20__1_n_0,p_reg_reg_i_21__1_n_0,p_reg_reg_i_22__1_n_0,p_reg_reg_i_23__1_n_0};
  wire recovered_17_ci = ((p_reg_reg_i_19__1_n_0) !== 1'bz) && (p_reg_reg_i_19__1_n_0);
  wire recovered_17_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_17_o[0] = recovered_17_s[0] ^ (recovered_17_ci || recovered_17_cy);
  assign recovered_17_co[0] = (recovered_17_s[0] & (recovered_17_ci || recovered_17_cy)) | (~recovered_17_s[0] & recovered_17_di[0]);
  assign recovered_17_o[1] = recovered_17_s[1] ^ recovered_17_co[0];
  assign recovered_17_co[1] = (recovered_17_s[1] & recovered_17_co[0]) | (~recovered_17_s[1] & recovered_17_di[1]);
  assign recovered_17_o[2] = recovered_17_s[2] ^ recovered_17_co[1];
  assign recovered_17_co[2] = (recovered_17_s[2] & recovered_17_co[1]) | (~recovered_17_s[2] & recovered_17_di[2]);
  assign recovered_17_o[3] = recovered_17_s[3] ^ recovered_17_co[2];
  assign recovered_17_co[3] = (recovered_17_s[3] & recovered_17_co[2]) | (~recovered_17_s[3] & recovered_17_di[3]);
  assign {icmp_ln890_fu_6336_p2,NLW_p_reg_reg_i_18__1_CO_UNCONNECTED[2:0]} = recovered_17_co;

  // Reconstructed CARRY4: p_reg_reg_i_19__1
  wire [3:0] recovered_18_co, recovered_18_o, recovered_18_s, recovered_18_di;
  assign recovered_18_s = {p_reg_reg_i_33_n_0,p_reg_reg_i_34_n_0,p_reg_reg_i_35_n_0,p_reg_reg_i_36_n_0};
  assign recovered_18_di = {p_reg_reg_i_29_n_0,p_reg_reg_i_30_n_0,p_reg_reg_i_31_n_0,p_reg_reg_i_32_n_0};
  wire recovered_18_ci = ((p_reg_reg_i_28_n_0) !== 1'bz) && (p_reg_reg_i_28_n_0);
  wire recovered_18_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_18_o[0] = recovered_18_s[0] ^ (recovered_18_ci || recovered_18_cy);
  assign recovered_18_co[0] = (recovered_18_s[0] & (recovered_18_ci || recovered_18_cy)) | (~recovered_18_s[0] & recovered_18_di[0]);
  assign recovered_18_o[1] = recovered_18_s[1] ^ recovered_18_co[0];
  assign recovered_18_co[1] = (recovered_18_s[1] & recovered_18_co[0]) | (~recovered_18_s[1] & recovered_18_di[1]);
  assign recovered_18_o[2] = recovered_18_s[2] ^ recovered_18_co[1];
  assign recovered_18_co[2] = (recovered_18_s[2] & recovered_18_co[1]) | (~recovered_18_s[2] & recovered_18_di[2]);
  assign recovered_18_o[3] = recovered_18_s[3] ^ recovered_18_co[2];
  assign recovered_18_co[3] = (recovered_18_s[3] & recovered_18_co[2]) | (~recovered_18_s[3] & recovered_18_di[3]);
  assign {p_reg_reg_i_19__1_n_0,NLW_p_reg_reg_i_19__1_CO_UNCONNECTED[2:0]} = recovered_18_co;

  // Reconstructed LUT2: p_reg_reg_i_20__1
  assign p_reg_reg_i_20__1_n_0 = ((p_reg_reg_n_82) ? (1'b1) : (p_reg_reg_n_83));

  // Reconstructed LUT2: p_reg_reg_i_21__1
  assign p_reg_reg_i_21__1_n_0 = ((p_reg_reg_n_84) ? (1'b1) : (p_reg_reg_n_85));

  // Reconstructed LUT2: p_reg_reg_i_22__1
  assign p_reg_reg_i_22__1_n_0 = ((p_reg_reg_n_86) ? (1'b1) : (p_reg_reg_n_87));

  // Reconstructed LUT3: p_reg_reg_i_23__1
  assign p_reg_reg_i_23__1_n_0 = ((p_reg_reg_n_88) ? (1'b1) : (((zext_ln890_fu_6333_p1[14]) ? (1'b0) : (p_reg_reg_n_89))));

  // Reconstructed LUT2: p_reg_reg_i_24__1
  assign p_reg_reg_i_24__1_n_0 = ((p_reg_reg_n_82) ? (1'b0) : (~(p_reg_reg_n_83)));

  // Reconstructed LUT2: p_reg_reg_i_25__1
  assign p_reg_reg_i_25__1_n_0 = ((p_reg_reg_n_84) ? (1'b0) : (~(p_reg_reg_n_85)));

  // Reconstructed LUT2: p_reg_reg_i_26__1
  assign p_reg_reg_i_26__1_n_0 = ((p_reg_reg_n_86) ? (1'b0) : (~(p_reg_reg_n_87)));

  // Reconstructed LUT3: p_reg_reg_i_27__1
  assign p_reg_reg_i_27__1_n_0 = ((p_reg_reg_n_88) ? (1'b0) : (((zext_ln890_fu_6333_p1[14]) ? (p_reg_reg_n_89) : (~(p_reg_reg_n_89)))));

  // Reconstructed CARRY4: p_reg_reg_i_28
  wire [3:0] recovered_27_co, recovered_27_o, recovered_27_s, recovered_27_di;
  assign recovered_27_s = {p_reg_reg_i_41_n_0,p_reg_reg_i_42_n_0,p_reg_reg_i_43_n_0,p_reg_reg_i_44__0_n_0};
  assign recovered_27_di = {p_reg_reg_i_37_n_0,p_reg_reg_i_38_n_0,p_reg_reg_i_39_n_0,p_reg_reg_i_40_n_0};
  wire recovered_27_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_27_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_27_o[0] = recovered_27_s[0] ^ (recovered_27_ci || recovered_27_cy);
  assign recovered_27_co[0] = (recovered_27_s[0] & (recovered_27_ci || recovered_27_cy)) | (~recovered_27_s[0] & recovered_27_di[0]);
  assign recovered_27_o[1] = recovered_27_s[1] ^ recovered_27_co[0];
  assign recovered_27_co[1] = (recovered_27_s[1] & recovered_27_co[0]) | (~recovered_27_s[1] & recovered_27_di[1]);
  assign recovered_27_o[2] = recovered_27_s[2] ^ recovered_27_co[1];
  assign recovered_27_co[2] = (recovered_27_s[2] & recovered_27_co[1]) | (~recovered_27_s[2] & recovered_27_di[2]);
  assign recovered_27_o[3] = recovered_27_s[3] ^ recovered_27_co[2];
  assign recovered_27_co[3] = (recovered_27_s[3] & recovered_27_co[2]) | (~recovered_27_s[3] & recovered_27_di[3]);
  assign {p_reg_reg_i_28_n_0,NLW_p_reg_reg_i_28_CO_UNCONNECTED[2:0]} = recovered_27_co;

  // Reconstructed LUT4: p_reg_reg_i_29
  assign p_reg_reg_i_29_n_0 = ((p_reg_reg_n_90) ? (((zext_ln890_fu_6333_p1[13]) ? (((zext_ln890_fu_6333_p1[12]) ? (1'b0) : (p_reg_reg_n_91))) : (1'b1))) : (((zext_ln890_fu_6333_p1[13]) ? (1'b0) : (((zext_ln890_fu_6333_p1[12]) ? (1'b0) : (p_reg_reg_n_91))))));

  // Reconstructed LUT2: p_reg_reg_i_2__1
  assign A[14] = ((p_reg_reg_1[14]) ? (p_reg_reg_i_17__1_n_7) : (1'b0));

  // Reconstructed LUT4: p_reg_reg_i_30
  assign p_reg_reg_i_30_n_0 = ((p_reg_reg_n_92) ? (((zext_ln890_fu_6333_p1[11]) ? (((zext_ln890_fu_6333_p1[10]) ? (1'b0) : (p_reg_reg_n_93))) : (1'b1))) : (((zext_ln890_fu_6333_p1[11]) ? (1'b0) : (((zext_ln890_fu_6333_p1[10]) ? (1'b0) : (p_reg_reg_n_93))))));

  // Reconstructed LUT4: p_reg_reg_i_31
  assign p_reg_reg_i_31_n_0 = ((p_reg_reg_n_94) ? (((zext_ln890_fu_6333_p1[9]) ? (((zext_ln890_fu_6333_p1[8]) ? (1'b0) : (p_reg_reg_n_95))) : (1'b1))) : (((zext_ln890_fu_6333_p1[9]) ? (1'b0) : (((zext_ln890_fu_6333_p1[8]) ? (1'b0) : (p_reg_reg_n_95))))));

  // Reconstructed LUT4: p_reg_reg_i_32
  assign p_reg_reg_i_32_n_0 = ((p_reg_reg_n_96) ? (((zext_ln890_fu_6333_p1[7]) ? (((zext_ln890_fu_6333_p1[6]) ? (1'b0) : (p_reg_reg_n_97))) : (1'b1))) : (((zext_ln890_fu_6333_p1[7]) ? (1'b0) : (((zext_ln890_fu_6333_p1[6]) ? (1'b0) : (p_reg_reg_n_97))))));

  // Reconstructed LUT4: p_reg_reg_i_33
  assign p_reg_reg_i_33_n_0 = ((zext_ln890_fu_6333_p1[13]) ? (((p_reg_reg_n_90) ? (((zext_ln890_fu_6333_p1[12]) ? (p_reg_reg_n_91) : (~(p_reg_reg_n_91)))) : (1'b0))) : (((p_reg_reg_n_90) ? (1'b0) : (((zext_ln890_fu_6333_p1[12]) ? (p_reg_reg_n_91) : (~(p_reg_reg_n_91)))))));

  // Reconstructed LUT4: p_reg_reg_i_34
  assign p_reg_reg_i_34_n_0 = ((zext_ln890_fu_6333_p1[11]) ? (((p_reg_reg_n_92) ? (((zext_ln890_fu_6333_p1[10]) ? (p_reg_reg_n_93) : (~(p_reg_reg_n_93)))) : (1'b0))) : (((p_reg_reg_n_92) ? (1'b0) : (((zext_ln890_fu_6333_p1[10]) ? (p_reg_reg_n_93) : (~(p_reg_reg_n_93)))))));

  // Reconstructed LUT4: p_reg_reg_i_35
  assign p_reg_reg_i_35_n_0 = ((zext_ln890_fu_6333_p1[9]) ? (((p_reg_reg_n_94) ? (((zext_ln890_fu_6333_p1[8]) ? (p_reg_reg_n_95) : (~(p_reg_reg_n_95)))) : (1'b0))) : (((p_reg_reg_n_94) ? (1'b0) : (((zext_ln890_fu_6333_p1[8]) ? (p_reg_reg_n_95) : (~(p_reg_reg_n_95)))))));

  // Reconstructed LUT4: p_reg_reg_i_36
  assign p_reg_reg_i_36_n_0 = ((zext_ln890_fu_6333_p1[7]) ? (((p_reg_reg_n_96) ? (((zext_ln890_fu_6333_p1[6]) ? (p_reg_reg_n_97) : (~(p_reg_reg_n_97)))) : (1'b0))) : (((p_reg_reg_n_96) ? (1'b0) : (((zext_ln890_fu_6333_p1[6]) ? (p_reg_reg_n_97) : (~(p_reg_reg_n_97)))))));

  // Reconstructed LUT4: p_reg_reg_i_37
  assign p_reg_reg_i_37_n_0 = ((p_reg_reg_n_98) ? (((zext_ln890_fu_6333_p1[5]) ? (((zext_ln890_fu_6333_p1[4]) ? (1'b0) : (p_reg_reg_n_99))) : (1'b1))) : (((zext_ln890_fu_6333_p1[5]) ? (1'b0) : (((zext_ln890_fu_6333_p1[4]) ? (1'b0) : (p_reg_reg_n_99))))));

  // Reconstructed LUT4: p_reg_reg_i_38
  assign p_reg_reg_i_38_n_0 = ((p_reg_reg_n_100) ? (((zext_ln890_fu_6333_p1[3]) ? (((zext_ln890_fu_6333_p1[2]) ? (1'b0) : (p_reg_reg_n_101))) : (1'b1))) : (((zext_ln890_fu_6333_p1[3]) ? (1'b0) : (((zext_ln890_fu_6333_p1[2]) ? (1'b0) : (p_reg_reg_n_101))))));

  // Reconstructed LUT4: p_reg_reg_i_39
  assign p_reg_reg_i_39_n_0 = ((p_reg_reg_n_102) ? (((zext_ln890_fu_6333_p1[1]) ? (((zext_ln890_fu_6333_p1[0]) ? (1'b0) : (p_reg_reg_n_103))) : (1'b1))) : (((zext_ln890_fu_6333_p1[1]) ? (1'b0) : (((zext_ln890_fu_6333_p1[0]) ? (1'b0) : (p_reg_reg_n_103))))));

  // Reconstructed LUT3: p_reg_reg_i_3__1
  assign A[13] = ((p_reg_reg_2[13]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[13]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[13]) : (1'b0))));

  // Reconstructed LUT2: p_reg_reg_i_40
  assign p_reg_reg_i_40_n_0 = ((p_reg_reg_n_104) ? (1'b1) : (p_reg_reg_n_105));

  // Reconstructed LUT4: p_reg_reg_i_41
  assign p_reg_reg_i_41_n_0 = ((zext_ln890_fu_6333_p1[5]) ? (((p_reg_reg_n_98) ? (((zext_ln890_fu_6333_p1[4]) ? (p_reg_reg_n_99) : (~(p_reg_reg_n_99)))) : (1'b0))) : (((p_reg_reg_n_98) ? (1'b0) : (((zext_ln890_fu_6333_p1[4]) ? (p_reg_reg_n_99) : (~(p_reg_reg_n_99)))))));

  // Reconstructed LUT4: p_reg_reg_i_42
  assign p_reg_reg_i_42_n_0 = ((zext_ln890_fu_6333_p1[3]) ? (((p_reg_reg_n_100) ? (((zext_ln890_fu_6333_p1[2]) ? (p_reg_reg_n_101) : (~(p_reg_reg_n_101)))) : (1'b0))) : (((p_reg_reg_n_100) ? (1'b0) : (((zext_ln890_fu_6333_p1[2]) ? (p_reg_reg_n_101) : (~(p_reg_reg_n_101)))))));

  // Reconstructed LUT4: p_reg_reg_i_43
  assign p_reg_reg_i_43_n_0 = ((zext_ln890_fu_6333_p1[1]) ? (((p_reg_reg_n_102) ? (((zext_ln890_fu_6333_p1[0]) ? (p_reg_reg_n_103) : (~(p_reg_reg_n_103)))) : (1'b0))) : (((p_reg_reg_n_102) ? (1'b0) : (((zext_ln890_fu_6333_p1[0]) ? (p_reg_reg_n_103) : (~(p_reg_reg_n_103)))))));

  // Reconstructed LUT2: p_reg_reg_i_44__0
  assign p_reg_reg_i_44__0_n_0 = ((p_reg_reg_n_104) ? (1'b0) : (~(p_reg_reg_n_105)));

  // Reconstructed LUT3: p_reg_reg_i_4__1
  assign A[12] = ((p_reg_reg_2[12]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[12]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[12]) : (1'b0))));

  // Reconstructed LUT3: p_reg_reg_i_5__1
  assign A[11] = ((p_reg_reg_2[11]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[11]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[11]) : (1'b0))));

  // Reconstructed LUT3: p_reg_reg_i_6__1
  assign A[10] = ((p_reg_reg_2[10]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[10]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[10]) : (1'b0))));

  // Reconstructed LUT3: p_reg_reg_i_7__1
  assign A[9] = ((p_reg_reg_2[9]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[9]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[9]) : (1'b0))));

  // Reconstructed LUT3: p_reg_reg_i_8__1
  assign A[8] = ((p_reg_reg_2[8]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[8]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[8]) : (1'b0))));

  // Reconstructed LUT3: p_reg_reg_i_9__1
  assign A[7] = ((p_reg_reg_2[7]) ? (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[7]) : (1'b1))) : (((p_reg_reg_i_17__1_n_7) ? (p_reg_reg_1[7]) : (1'b0))));

  // Reconstructed LUT2: esc_zext_ln107_reg_9022_13__i_1_7eef31f
  assign E = ((icmp_ln89_reg_8917_pp4_iter3_reg) ? (1'b0) : (Q[3]));

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_19s_8ns_26_4_1
   (or_ln101_fu_6471_p2,
    Q,
    ap_clk,
    A,
    shl_ln88_cast94_reg_8882,
    CO,
    esc_or_ln101_reg_9108_reg_0_0d077db );
  output or_ln101_fu_6471_p2;
  input [0:0]Q;
  input ap_clk;
  input [18:0]A;
  input [8:0]shl_ln88_cast94_reg_8882;
  input [0:0]CO;
  input esc_or_ln101_reg_9108_reg_0_0d077db ;

  wire [18:0]A;
  wire [0:0]CO;
  wire [0:0]Q;
  wire ap_clk;
  wire or_ln101_fu_6471_p2;
  wire esc_or_ln101_reg_9108_reg_0_0d077db ;
  wire [8:0]shl_ln88_cast94_reg_8882;

  system_blue_locator_packed_0_0_blue_locator_packed_mul_mul_19s_8ns_26_4_1_DSP48_3 blue_locator_packed_mul_mul_19s_8ns_26_4_1_DSP48_3_U
       (.A(A),
        .CO(CO),
        .Q(Q),
        .ap_clk(ap_clk),
        .or_ln101_fu_6471_p2(or_ln101_fu_6471_p2),
        .esc_or_ln101_reg_9108_reg_0_0d077db (esc_or_ln101_reg_9108_reg_0_0d077db ),
        .shl_ln88_cast94_reg_8882(shl_ln88_cast94_reg_8882));
endmodule

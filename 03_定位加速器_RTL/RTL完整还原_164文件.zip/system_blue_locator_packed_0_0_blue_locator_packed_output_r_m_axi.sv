// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi
   (D,
    output_r_BVALID,
    ap_done,
    full_n_reg,
    m_axi_output_r_AWADDR,
    AWLEN,
    m_axi_output_r_WLAST,
    m_axi_output_r_WDATA,
    m_axi_output_r_WSTRB,
    m_axi_output_r_AWVALID,
    m_axi_output_r_WVALID,
    full_n_reg_0,
    esc_ap_CS_fsm_reg_63_8ee7371 ,
    esc_ap_CS_fsm_reg_63__0_9fe4f39 ,
    Q,
    E,
    ap_start,
    esc_ap_CS_fsm_reg_63__1_dfe60b8 ,
    esc_ap_CS_fsm_63__i_4_789726b ,
    mem_reg,
    mem_reg_0,
    mem_reg_1,
    mem_reg_2,
    mem_reg_3,
    icmp_ln125_reg_9133,
    zext_ln125_reg_9138_reg,
    ap_rst_n,
    m_axi_output_r_RVALID,
    ap_clk,
    SR,
    esc_data_p2_reg_61_4692f8e ,
    m_axi_output_r_AWREADY,
    m_axi_output_r_WREADY,
    m_axi_output_r_BVALID);
  output [11:0]D;
  output output_r_BVALID;
  output ap_done;
  output full_n_reg;
  output [61:0]m_axi_output_r_AWADDR;
  output [3:0]AWLEN;
  output m_axi_output_r_WLAST;
  output [31:0]m_axi_output_r_WDATA;
  output [3:0]m_axi_output_r_WSTRB;
  output m_axi_output_r_AWVALID;
  output m_axi_output_r_WVALID;
  output full_n_reg_0;
  input esc_ap_CS_fsm_reg_63_8ee7371 ;
  input esc_ap_CS_fsm_reg_63__0_9fe4f39 ;
  input [18:0]Q;
  input [0:0]E;
  input ap_start;
  input esc_ap_CS_fsm_reg_63__1_dfe60b8 ;
  input esc_ap_CS_fsm_63__i_4_789726b ;
  input [18:0]mem_reg;
  input [5:0]mem_reg_0;
  input [6:0]mem_reg_1;
  input [4:0]mem_reg_2;
  input [5:0]mem_reg_3;
  input icmp_ln125_reg_9133;
  input zext_ln125_reg_9138_reg;
  input ap_rst_n;
  input m_axi_output_r_RVALID;
  input ap_clk;
  input [0:0]SR;
  input [61:0]esc_data_p2_reg_61_4692f8e ;
  input m_axi_output_r_AWREADY;
  input m_axi_output_r_WREADY;
  input m_axi_output_r_BVALID;

  wire [3:0]AWLEN;
  wire AWVALID_Dummy;
  wire [11:0]D;
  wire [0:0]E;
  wire [18:0]Q;
  wire [0:0]SR;
  wire WVALID_Dummy;
  wire esc_ap_CS_fsm_63__i_4_789726b ;
  wire esc_ap_CS_fsm_reg_63_8ee7371 ;
  wire esc_ap_CS_fsm_reg_63__0_9fe4f39 ;
  wire esc_ap_CS_fsm_reg_63__1_dfe60b8 ;
  wire ap_clk;
  wire ap_done;
  wire ap_rst_n;
  wire ap_start;
  wire [61:0]esc_data_p2_reg_61_4692f8e ;
  wire full_n_reg_0;
  wire icmp_ln125_reg_9133;
  wire [61:0]m_axi_output_r_AWADDR;
  wire m_axi_output_r_AWREADY;
  wire m_axi_output_r_AWVALID;
  wire m_axi_output_r_BVALID;
  wire [31:0]m_axi_output_r_WDATA;
  wire m_axi_output_r_WLAST;
  wire m_axi_output_r_WREADY;
  wire [3:0]m_axi_output_r_WSTRB;
  wire m_axi_output_r_WVALID;
  wire [18:0]mem_reg;
  wire [5:0]mem_reg_0;
  wire [6:0]mem_reg_1;
  wire [4:0]mem_reg_2;
  wire [5:0]mem_reg_3;
  wire output_r_BVALID;
  wire wreq_throttle_n_0;
  wire wreq_throttle_n_1;
  wire wreq_throttle_n_3;
  wire zext_ln125_reg_9138_reg;

  system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_write bus_write
       (.AWVALID_Dummy(AWVALID_Dummy),
        .D(D),
        .E(E),
        .Q(Q),
        .SR(SR),
        .WVALID_Dummy(WVALID_Dummy),
        .esc_ap_CS_fsm_63__i_4_789726b (esc_ap_CS_fsm_63__i_4_789726b ),
        .esc_ap_CS_fsm_reg_63_8ee7371 (esc_ap_CS_fsm_reg_63_8ee7371 ),
        .esc_ap_CS_fsm_reg_63__0_9fe4f39 (esc_ap_CS_fsm_reg_63__0_9fe4f39 ),
        .esc_ap_CS_fsm_reg_63__1_dfe60b8 (esc_ap_CS_fsm_reg_63__1_dfe60b8 ),
        .ap_clk(ap_clk),
        .ap_done(ap_done),
        .ap_rst_n(ap_rst_n),
        .ap_start(ap_start),
        .esc_bus_equal_gen_WLAST_Dummy_reg_0_a7eeff0 (wreq_throttle_n_3),
        .esc_could_multi_bursts_awlen_buf_reg_3__0_887186f (AWLEN),
        .esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938 (wreq_throttle_n_0),
        .esc_data_p2_reg_61_4692f8e (esc_data_p2_reg_61_4692f8e ),
        .empty_n_reg(output_r_BVALID),
        .full_n_reg(full_n_reg_0),
        .icmp_ln125_reg_9133(icmp_ln125_reg_9133),
        .m_axi_output_r_AWADDR(m_axi_output_r_AWADDR),
        .m_axi_output_r_AWVALID(m_axi_output_r_AWVALID),
        .m_axi_output_r_AWVALID_0(wreq_throttle_n_1),
        .m_axi_output_r_BVALID(m_axi_output_r_BVALID),
        .m_axi_output_r_WDATA(m_axi_output_r_WDATA),
        .m_axi_output_r_WLAST(m_axi_output_r_WLAST),
        .m_axi_output_r_WSTRB(m_axi_output_r_WSTRB),
        .mem_reg(mem_reg),
        .mem_reg_0(mem_reg_0),
        .mem_reg_1(mem_reg_1),
        .mem_reg_2(mem_reg_2),
        .mem_reg_3(mem_reg_3),
        .zext_ln125_reg_9138_reg(zext_ln125_reg_9138_reg));
  system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_throttle wreq_throttle
       (.AWVALID_Dummy(AWVALID_Dummy),
        .SR(SR),
        .WVALID_Dummy(WVALID_Dummy),
        .ap_clk(ap_clk),
        .esc_bus_equal_gen_WVALID_Dummy_reg_16556e5 (wreq_throttle_n_1),
        .esc_bus_equal_gen_WVALID_Dummy_reg_0_4657a23 (wreq_throttle_n_3),
        .m_axi_output_r_AWREADY(m_axi_output_r_AWREADY),
        .m_axi_output_r_AWREADY_0(wreq_throttle_n_0),
        .m_axi_output_r_WREADY(m_axi_output_r_WREADY),
        .m_axi_output_r_WVALID(m_axi_output_r_WVALID),
        .esc_throttl_cnt_reg_4__0_fd50aea (AWLEN));
endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_buffer
   (D,
    S,
    esc_mOutPtr_reg_5__0_51c21ea ,
    esc_mOutPtr_reg_3__0_af193d3 ,
    esc_bus_equal_gen_len_cnt_reg_6_460eec5 ,
    p_30_in,
    esc_bus_equal_gen_len_cnt_reg_6__0_d02ee1e ,
    DI,
    esc_bus_equal_gen_WVALID_Dummy_reg_16556e5 ,
    esc_dout_buf_reg_35__0_895f1d4 ,
    ap_clk,
    SR,
    Q,
    output_r_AWREADY,
    mem_reg_0,
    mem_reg_1,
    mem_reg_2,
    mem_reg_3,
    mem_reg_4,
    icmp_ln125_reg_9133,
    zext_ln125_reg_9138_reg,
    esc_bus_equal_gen_len_cnt_reg_7_077fe2f ,
    esc_bus_equal_gen_len_cnt_reg_7__0_df668b2 ,
    ap_rst_n,
    m_axi_output_r_WLAST,
    esc_bus_equal_gen_WLAST_Dummy_reg_daab610 ,
    burst_valid,
    WVALID_Dummy,
    esc_mOutPtr_reg_7__0_b1502f7 );
  output [8:0]D;
  output [2:0]S;
  output [5:0]esc_mOutPtr_reg_5__0_51c21ea ;
  output [3:0]esc_mOutPtr_reg_3__0_af193d3 ;
  output [0:0]esc_bus_equal_gen_len_cnt_reg_6_460eec5 ;
  output p_30_in;
  output esc_bus_equal_gen_len_cnt_reg_6__0_d02ee1e ;
  output [0:0]DI;
  output esc_bus_equal_gen_WVALID_Dummy_reg_16556e5 ;
  output [35:0]esc_dout_buf_reg_35__0_895f1d4 ;
  input ap_clk;
  input [0:0]SR;
  input [8:0]Q;
  input output_r_AWREADY;
  input [18:0]mem_reg_0;
  input [5:0]mem_reg_1;
  input [6:0]mem_reg_2;
  input [4:0]mem_reg_3;
  input [5:0]mem_reg_4;
  input icmp_ln125_reg_9133;
  input zext_ln125_reg_9138_reg;
  input [1:0]esc_bus_equal_gen_len_cnt_reg_7_077fe2f ;
  input esc_bus_equal_gen_len_cnt_reg_7__0_df668b2 ;
  input ap_rst_n;
  input m_axi_output_r_WLAST;
  input esc_bus_equal_gen_WLAST_Dummy_reg_daab610 ;
  input burst_valid;
  input WVALID_Dummy;
  input [6:0]esc_mOutPtr_reg_7__0_b1502f7 ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [8:0]D;
  wire [0:0]DI;
  wire [8:0]Q;
  wire [2:0]S;
  wire [0:0]SR;
  wire WVALID_Dummy;
  wire ap_clk;
  wire ap_rst_n;
  wire burst_valid;
  wire esc_bus_equal_gen_WLAST_Dummy_reg_daab610 ;
  wire esc_bus_equal_gen_WVALID_Dummy_reg_16556e5 ;
  wire [0:0]esc_bus_equal_gen_len_cnt_reg_6_460eec5 ;
  wire esc_bus_equal_gen_len_cnt_reg_6__0_d02ee1e ;
  wire [1:0]esc_bus_equal_gen_len_cnt_reg_7_077fe2f ;
  wire esc_bus_equal_gen_len_cnt_reg_7__0_df668b2 ;
  wire data_valid;
  wire esc_dout_buf_0__i_1_n_0_a416739 ;
  wire esc_dout_buf_10__i_1_n_0_86c44e6 ;
  wire esc_dout_buf_11__i_1_n_0_9481f99 ;
  wire esc_dout_buf_12__i_1_n_0_86ab95d ;
  wire esc_dout_buf_13__i_1_n_0_9f78cf9 ;
  wire esc_dout_buf_14__i_1_n_0_7dc461f ;
  wire esc_dout_buf_15__i_1_n_0_2bea0e4 ;
  wire esc_dout_buf_16__i_1_n_0_0c36ee8 ;
  wire esc_dout_buf_17__i_1_n_0_7e441d2 ;
  wire esc_dout_buf_18__i_1_n_0_6505df9 ;
  wire esc_dout_buf_19__i_1_n_0_edc3c7b ;
  wire esc_dout_buf_1__i_1_n_0_bcd7410 ;
  wire esc_dout_buf_20__i_1_n_0_ab4b624 ;
  wire esc_dout_buf_21__i_1_n_0_e1219ab ;
  wire esc_dout_buf_22__i_1_n_0_787b7ea ;
  wire esc_dout_buf_23__i_1_n_0_b99fea5 ;
  wire esc_dout_buf_24__i_1_n_0_f596885 ;
  wire esc_dout_buf_25__i_1_n_0_5604152 ;
  wire esc_dout_buf_26__i_1_n_0_eeac2a9 ;
  wire esc_dout_buf_27__i_1_n_0_600d618 ;
  wire esc_dout_buf_28__i_1_n_0_567ea32 ;
  wire esc_dout_buf_29__i_1_n_0_f8b40b3 ;
  wire esc_dout_buf_2__i_1_n_0_0388fd1 ;
  wire esc_dout_buf_30__i_1_n_0_b0eac95 ;
  wire esc_dout_buf_31__i_1_n_0_995d1e3 ;
  wire esc_dout_buf_32__i_1_n_0_3b28f63 ;
  wire esc_dout_buf_33__i_1_n_0_7e0957a ;
  wire esc_dout_buf_34__i_1_n_0_ce8d01c ;
  wire esc_dout_buf_35__i_2_n_0_b1fe098 ;
  wire esc_dout_buf_3__i_1_n_0_a1e89d1 ;
  wire esc_dout_buf_4__i_1_n_0_9790d5b ;
  wire esc_dout_buf_5__i_1_n_0_bcb4bd3 ;
  wire esc_dout_buf_6__i_1_n_0_122f0de ;
  wire esc_dout_buf_7__i_1_n_0_5c8c97d ;
  wire esc_dout_buf_8__i_1_n_0_fa8be1c ;
  wire esc_dout_buf_9__i_1_n_0_2baf451 ;
  wire [35:0]esc_dout_buf_reg_35__0_895f1d4 ;
  wire dout_valid_i_1__0_n_0;
  wire empty_n_i_1__6_n_0;
  wire empty_n_i_2__1_n_0;
  wire empty_n_i_3__1_n_0;
  wire empty_n_reg_n_0;
  wire full_n_i_1__8_n_0;
  wire full_n_i_3__1_n_0;
  wire icmp_ln125_reg_9133;
  wire esc_mOutPtr_0__i_1__0_n_0_6c8ae45 ;
  wire esc_mOutPtr_7__i_1__1_n_0_158cb4a ;
  wire [7:6]mOutPtr_reg;
  wire [3:0]esc_mOutPtr_reg_3__0_af193d3 ;
  wire [5:0]esc_mOutPtr_reg_5__0_51c21ea ;
  wire [6:0]esc_mOutPtr_reg_7__0_b1502f7 ;
  wire m_axi_output_r_WLAST;
  wire [18:0]mem_reg_0;
  wire [5:0]mem_reg_1;
  wire [6:0]mem_reg_2;
  wire [4:0]mem_reg_3;
  wire [5:0]mem_reg_4;
  wire mem_reg_i_10__0_n_0;
  wire mem_reg_i_11__0_n_0;
  wire mem_reg_i_12__0_n_0;
  wire mem_reg_i_13__0_n_0;
  wire mem_reg_i_14__0_n_0;
  wire mem_reg_i_15_n_0;
  wire mem_reg_i_16_n_0;
  wire mem_reg_i_17_n_0;
  wire mem_reg_i_18_n_0;
  wire mem_reg_i_19_n_0;
  wire mem_reg_i_20_n_0;
  wire mem_reg_i_21_n_0;
  wire mem_reg_i_22_n_0;
  wire mem_reg_i_23_n_0;
  wire mem_reg_i_24_n_0;
  wire mem_reg_i_25_n_0;
  wire mem_reg_i_26_n_0;
  wire mem_reg_i_27_n_0;
  wire mem_reg_i_29_n_0;
  wire mem_reg_i_30_n_0;
  wire mem_reg_i_31_n_0;
  wire mem_reg_i_32_n_0;
  wire mem_reg_i_33_n_0;
  wire mem_reg_i_34_n_0;
  wire mem_reg_i_35_n_0;
  wire mem_reg_i_36_n_0;
  wire mem_reg_i_37_n_0;
  wire mem_reg_i_38_n_0;
  wire mem_reg_i_39_n_0;
  wire mem_reg_i_40_n_0;
  wire mem_reg_i_41_n_0;
  wire mem_reg_i_42_n_0;
  wire mem_reg_i_9__0_n_0;
  wire output_r_AWREADY;
  wire output_r_WREADY;
  wire output_r_WVALID;
  wire p_1_in;
  wire p_30_in;
  wire pop;
  wire push;
  wire [35:0]q_buf;
  wire [35:0]q_tmp;
  wire [7:0]raddr;
  wire [7:0]rnext;
  wire show_ahead;
  wire show_ahead0;
  wire [7:0]waddr;
  wire esc_waddr_0__i_1__0_n_0_175f693 ;
  wire esc_waddr_1__i_1__0_n_0_cdd7208 ;
  wire esc_waddr_2__i_1__0_n_0_92c702f ;
  wire esc_waddr_3__i_1__0_n_0_761b3f4 ;
  wire esc_waddr_4__i_1__0_n_0_88347f4 ;
  wire esc_waddr_5__i_1__1_n_0_5199fa7 ;
  wire esc_waddr_6__i_1__0_n_0_4a579a1 ;
  wire esc_waddr_6__i_2__0_n_0_a8f19c2 ;
  wire esc_waddr_7__i_2__0_n_0_2b285d4 ;
  wire esc_waddr_7__i_3__0_n_0_cbdab48 ;
  wire esc_waddr_7__i_4__0_n_0_b84c479 ;
  wire zext_ln125_reg_9138_reg;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT4: esc_ap_CS_fsm_64__i_1_d14075f
  assign D[0] = ((output_r_AWREADY) ? (((Q[0]) ? (((Q[1]) ? (~(output_r_WREADY)) : (1'b1))) : (((Q[1]) ? (~(output_r_WREADY)) : (1'b0))))) : (((Q[1]) ? (~(output_r_WREADY)) : (1'b0))));

  // Reconstructed LUT3: esc_ap_CS_fsm_65__i_1_705a2c8
  assign D[1] = ((Q[1]) ? (((output_r_WREADY) ? (~(Q[2])) : (Q[2]))) : (((output_r_WREADY) ? (1'b0) : (Q[2]))));

  // Reconstructed LUT3: esc_ap_CS_fsm_66__i_1_68e97fb
  assign D[2] = ((Q[2]) ? (((output_r_WREADY) ? (~(Q[3])) : (Q[3]))) : (((output_r_WREADY) ? (1'b0) : (Q[3]))));

  // Reconstructed LUT3: esc_ap_CS_fsm_67__i_1_eca8b6a
  assign D[3] = ((output_r_WREADY) ? (((Q[3]) ? (~(Q[4])) : (1'b0))) : (Q[4]));

  // Reconstructed LUT3: esc_ap_CS_fsm_68__i_1_47e42d2
  assign D[4] = ((Q[4]) ? (((output_r_WREADY) ? (~(Q[5])) : (Q[5]))) : (((output_r_WREADY) ? (1'b0) : (Q[5]))));

  // Reconstructed LUT3: esc_ap_CS_fsm_69__i_1_2fc2577
  assign D[5] = ((Q[5]) ? (((output_r_WREADY) ? (~(Q[6])) : (Q[6]))) : (((output_r_WREADY) ? (1'b0) : (Q[6]))));

  // Reconstructed LUT3: esc_ap_CS_fsm_70__i_1_86e6a44
  assign D[6] = ((Q[6]) ? (((output_r_WREADY) ? (~(Q[7])) : (Q[7]))) : (((output_r_WREADY) ? (1'b0) : (Q[7]))));

  // Reconstructed LUT3: esc_ap_CS_fsm_71__i_1_d42094f
  assign D[7] = ((Q[7]) ? (((output_r_WREADY) ? (~(Q[8])) : (Q[8]))) : (((output_r_WREADY) ? (1'b0) : (Q[8]))));

  // Reconstructed LUT2: esc_ap_CS_fsm_72__i_1_2c2f2d0
  assign D[8] = ((Q[8]) ? (output_r_WREADY) : (1'b0));

  // Reconstructed LUT6: esc_bus_equal_gen_WLAST_Dummy_i_1_b4e0d82
  assign esc_bus_equal_gen_len_cnt_reg_6__0_d02ee1e = ((esc_bus_equal_gen_WLAST_Dummy_reg_daab610) ? (m_axi_output_r_WLAST) : (((esc_bus_equal_gen_len_cnt_reg_7__0_df668b2) ? (1'b0) : (((esc_bus_equal_gen_len_cnt_reg_7_077fe2f [1]) ? (1'b0) : (((esc_bus_equal_gen_len_cnt_reg_7_077fe2f [0]) ? (1'b0) : (p_30_in))))))));

  // Reconstructed LUT4: esc_bus_equal_gen_WVALID_Dummy_i_1_d3bee28
  assign esc_bus_equal_gen_WVALID_Dummy_reg_16556e5 = ((burst_valid) ? (((data_valid) ? (((esc_bus_equal_gen_WLAST_Dummy_reg_daab610) ? (WVALID_Dummy) : (1'b1))) : (((esc_bus_equal_gen_WLAST_Dummy_reg_daab610) ? (WVALID_Dummy) : (1'b0))))) : (((esc_bus_equal_gen_WLAST_Dummy_reg_daab610) ? (WVALID_Dummy) : (1'b0))));

  // Reconstructed LUT3: esc_bus_equal_gen_data_buf_31__i_1_56d58a4
  assign p_30_in = ((esc_bus_equal_gen_WLAST_Dummy_reg_daab610) ? (1'b0) : (((burst_valid) ? (data_valid) : (1'b0))));

  // Reconstructed LUT5: esc_bus_equal_gen_len_cnt_7__i_1_68c255c
  assign esc_bus_equal_gen_len_cnt_reg_6_460eec5 = ((ap_rst_n) ? (((esc_bus_equal_gen_len_cnt_reg_7__0_df668b2) ? (1'b0) : (((esc_bus_equal_gen_len_cnt_reg_7_077fe2f [1]) ? (1'b0) : (((esc_bus_equal_gen_len_cnt_reg_7_077fe2f [0]) ? (1'b0) : (p_30_in))))))) : (1'b1));

  // Reconstructed LUT3: esc_dout_buf_0__i_1_c652c5c
  assign esc_dout_buf_0__i_1_n_0_a416739 = ((show_ahead) ? (q_tmp[0]) : (q_buf[0]));

  // Reconstructed LUT3: esc_dout_buf_10__i_1_b412b36
  assign esc_dout_buf_10__i_1_n_0_86c44e6 = ((show_ahead) ? (q_tmp[10]) : (q_buf[10]));

  // Reconstructed LUT3: esc_dout_buf_11__i_1_a12fcb3
  assign esc_dout_buf_11__i_1_n_0_9481f99 = ((show_ahead) ? (q_tmp[11]) : (q_buf[11]));

  // Reconstructed LUT3: esc_dout_buf_12__i_1_384cce0
  assign esc_dout_buf_12__i_1_n_0_86ab95d = ((show_ahead) ? (q_tmp[12]) : (q_buf[12]));

  // Reconstructed LUT3: esc_dout_buf_13__i_1_0d19a71
  assign esc_dout_buf_13__i_1_n_0_9f78cf9 = ((show_ahead) ? (q_tmp[13]) : (q_buf[13]));

  // Reconstructed LUT3: esc_dout_buf_14__i_1_52852ec
  assign esc_dout_buf_14__i_1_n_0_7dc461f = ((show_ahead) ? (q_tmp[14]) : (q_buf[14]));

  // Reconstructed LUT3: esc_dout_buf_15__i_1_e0f83f2
  assign esc_dout_buf_15__i_1_n_0_2bea0e4 = ((show_ahead) ? (q_tmp[15]) : (q_buf[15]));

  // Reconstructed LUT3: esc_dout_buf_16__i_1_6b92668
  assign esc_dout_buf_16__i_1_n_0_0c36ee8 = ((show_ahead) ? (q_tmp[16]) : (q_buf[16]));

  // Reconstructed LUT3: esc_dout_buf_17__i_1_c385490
  assign esc_dout_buf_17__i_1_n_0_7e441d2 = ((show_ahead) ? (q_tmp[17]) : (q_buf[17]));

  // Reconstructed LUT3: esc_dout_buf_18__i_1_a3ce381
  assign esc_dout_buf_18__i_1_n_0_6505df9 = ((show_ahead) ? (q_tmp[31]) : (q_buf[18]));

  // Reconstructed LUT3: esc_dout_buf_19__i_1_183094b
  assign esc_dout_buf_19__i_1_n_0_edc3c7b = ((show_ahead) ? (q_tmp[31]) : (q_buf[19]));

  // Reconstructed LUT3: esc_dout_buf_1__i_1_b06e31a
  assign esc_dout_buf_1__i_1_n_0_bcd7410 = ((show_ahead) ? (q_tmp[1]) : (q_buf[1]));

  // Reconstructed LUT3: esc_dout_buf_20__i_1_11b7011
  assign esc_dout_buf_20__i_1_n_0_ab4b624 = ((show_ahead) ? (q_tmp[31]) : (q_buf[20]));

  // Reconstructed LUT3: esc_dout_buf_21__i_1_3eeb9bd
  assign esc_dout_buf_21__i_1_n_0_e1219ab = ((show_ahead) ? (q_tmp[31]) : (q_buf[21]));

  // Reconstructed LUT3: esc_dout_buf_22__i_1_3638525
  assign esc_dout_buf_22__i_1_n_0_787b7ea = ((show_ahead) ? (q_tmp[31]) : (q_buf[22]));

  // Reconstructed LUT3: esc_dout_buf_23__i_1_2d48561
  assign esc_dout_buf_23__i_1_n_0_b99fea5 = ((show_ahead) ? (q_tmp[31]) : (q_buf[23]));

  // Reconstructed LUT3: esc_dout_buf_24__i_1_0f8bc1b
  assign esc_dout_buf_24__i_1_n_0_f596885 = ((show_ahead) ? (q_tmp[31]) : (q_buf[24]));

  // Reconstructed LUT3: esc_dout_buf_25__i_1_f3b0b30
  assign esc_dout_buf_25__i_1_n_0_5604152 = ((show_ahead) ? (q_tmp[31]) : (q_buf[25]));

  // Reconstructed LUT3: esc_dout_buf_26__i_1_24bdd4b
  assign esc_dout_buf_26__i_1_n_0_eeac2a9 = ((show_ahead) ? (q_tmp[31]) : (q_buf[26]));

  // Reconstructed LUT3: esc_dout_buf_27__i_1_cd11586
  assign esc_dout_buf_27__i_1_n_0_600d618 = ((show_ahead) ? (q_tmp[31]) : (q_buf[27]));

  // Reconstructed LUT3: esc_dout_buf_28__i_1_2df00db
  assign esc_dout_buf_28__i_1_n_0_567ea32 = ((show_ahead) ? (q_tmp[31]) : (q_buf[28]));

  // Reconstructed LUT3: esc_dout_buf_29__i_1_2f55c43
  assign esc_dout_buf_29__i_1_n_0_f8b40b3 = ((show_ahead) ? (q_tmp[31]) : (q_buf[29]));

  // Reconstructed LUT3: esc_dout_buf_2__i_1_6fbe35f
  assign esc_dout_buf_2__i_1_n_0_0388fd1 = ((show_ahead) ? (q_tmp[2]) : (q_buf[2]));

  // Reconstructed LUT3: esc_dout_buf_30__i_1_1f87935
  assign esc_dout_buf_30__i_1_n_0_b0eac95 = ((show_ahead) ? (q_tmp[31]) : (q_buf[30]));

  // Reconstructed LUT3: esc_dout_buf_31__i_1_3c7f45c
  assign esc_dout_buf_31__i_1_n_0_995d1e3 = ((show_ahead) ? (q_tmp[31]) : (q_buf[31]));

  // Reconstructed LUT3: esc_dout_buf_32__i_1_ce65a39
  assign esc_dout_buf_32__i_1_n_0_3b28f63 = ((show_ahead) ? (q_tmp[35]) : (q_buf[32]));

  // Reconstructed LUT3: esc_dout_buf_33__i_1_601b7c4
  assign esc_dout_buf_33__i_1_n_0_7e0957a = ((show_ahead) ? (q_tmp[35]) : (q_buf[33]));

  // Reconstructed LUT3: esc_dout_buf_34__i_1_8701ce1
  assign esc_dout_buf_34__i_1_n_0_ce8d01c = ((show_ahead) ? (q_tmp[35]) : (q_buf[34]));

  // Reconstructed LUT4: esc_dout_buf_35__i_1_15d1e15
  assign pop = ((data_valid) ? (((burst_valid) ? (((esc_bus_equal_gen_WLAST_Dummy_reg_daab610) ? (1'b0) : (empty_n_reg_n_0))) : (1'b0))) : (empty_n_reg_n_0));

  // Reconstructed LUT3: esc_dout_buf_35__i_2_ed99da5
  assign esc_dout_buf_35__i_2_n_0_b1fe098 = ((show_ahead) ? (q_tmp[35]) : (q_buf[35]));

  // Reconstructed LUT3: esc_dout_buf_3__i_1_1debc9c
  assign esc_dout_buf_3__i_1_n_0_a1e89d1 = ((show_ahead) ? (q_tmp[3]) : (q_buf[3]));

  // Reconstructed LUT3: esc_dout_buf_4__i_1_eb55711
  assign esc_dout_buf_4__i_1_n_0_9790d5b = ((show_ahead) ? (q_tmp[4]) : (q_buf[4]));

  // Reconstructed LUT3: esc_dout_buf_5__i_1_761e744
  assign esc_dout_buf_5__i_1_n_0_bcb4bd3 = ((show_ahead) ? (q_tmp[5]) : (q_buf[5]));

  // Reconstructed LUT3: esc_dout_buf_6__i_1_2a8ca20
  assign esc_dout_buf_6__i_1_n_0_122f0de = ((show_ahead) ? (q_tmp[6]) : (q_buf[6]));

  // Reconstructed LUT3: esc_dout_buf_7__i_1_4f6f556
  assign esc_dout_buf_7__i_1_n_0_5c8c97d = ((show_ahead) ? (q_tmp[7]) : (q_buf[7]));

  // Reconstructed LUT3: esc_dout_buf_8__i_1_1c8dea4
  assign esc_dout_buf_8__i_1_n_0_fa8be1c = ((show_ahead) ? (q_tmp[8]) : (q_buf[8]));

  // Reconstructed LUT3: esc_dout_buf_9__i_1_b36d46c
  assign esc_dout_buf_9__i_1_n_0_2baf451 = ((show_ahead) ? (q_tmp[9]) : (q_buf[9]));

  // Reconstructed FDRE: esc_dout_buf_reg_0_73c858f
  reg recovered_53_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [0] = recovered_53_q;
  wire recovered_53_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_53_reset || (((SR) === 1'bx) && (recovered_53_q == 1'b0))) recovered_53_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_53_q == (esc_dout_buf_0__i_1_n_0_a416739)))) recovered_53_q <= (esc_dout_buf_0__i_1_n_0_a416739);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_10_f29ae94
  reg recovered_54_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [10] = recovered_54_q;
  wire recovered_54_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_54_reset || (((SR) === 1'bx) && (recovered_54_q == 1'b0))) recovered_54_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_54_q == (esc_dout_buf_10__i_1_n_0_86c44e6)))) recovered_54_q <= (esc_dout_buf_10__i_1_n_0_86c44e6);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_11_8b7e2c1
  reg recovered_55_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [11] = recovered_55_q;
  wire recovered_55_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_55_reset || (((SR) === 1'bx) && (recovered_55_q == 1'b0))) recovered_55_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_55_q == (esc_dout_buf_11__i_1_n_0_9481f99)))) recovered_55_q <= (esc_dout_buf_11__i_1_n_0_9481f99);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_12_7ca0f57
  reg recovered_56_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [12] = recovered_56_q;
  wire recovered_56_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_56_reset || (((SR) === 1'bx) && (recovered_56_q == 1'b0))) recovered_56_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_56_q == (esc_dout_buf_12__i_1_n_0_86ab95d)))) recovered_56_q <= (esc_dout_buf_12__i_1_n_0_86ab95d);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_13_30f5709
  reg recovered_57_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [13] = recovered_57_q;
  wire recovered_57_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_57_reset || (((SR) === 1'bx) && (recovered_57_q == 1'b0))) recovered_57_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_57_q == (esc_dout_buf_13__i_1_n_0_9f78cf9)))) recovered_57_q <= (esc_dout_buf_13__i_1_n_0_9f78cf9);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_14_afe27ef
  reg recovered_58_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [14] = recovered_58_q;
  wire recovered_58_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_58_reset || (((SR) === 1'bx) && (recovered_58_q == 1'b0))) recovered_58_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_58_q == (esc_dout_buf_14__i_1_n_0_7dc461f)))) recovered_58_q <= (esc_dout_buf_14__i_1_n_0_7dc461f);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_15_61438df
  reg recovered_59_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [15] = recovered_59_q;
  wire recovered_59_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_59_reset || (((SR) === 1'bx) && (recovered_59_q == 1'b0))) recovered_59_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_59_q == (esc_dout_buf_15__i_1_n_0_2bea0e4)))) recovered_59_q <= (esc_dout_buf_15__i_1_n_0_2bea0e4);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_16_41b0172
  reg recovered_60_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [16] = recovered_60_q;
  wire recovered_60_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_60_reset || (((SR) === 1'bx) && (recovered_60_q == 1'b0))) recovered_60_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_60_q == (esc_dout_buf_16__i_1_n_0_0c36ee8)))) recovered_60_q <= (esc_dout_buf_16__i_1_n_0_0c36ee8);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_17_f5a2fc8
  reg recovered_61_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [17] = recovered_61_q;
  wire recovered_61_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_61_reset || (((SR) === 1'bx) && (recovered_61_q == 1'b0))) recovered_61_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_61_q == (esc_dout_buf_17__i_1_n_0_7e441d2)))) recovered_61_q <= (esc_dout_buf_17__i_1_n_0_7e441d2);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_18_f551304
  reg recovered_62_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [18] = recovered_62_q;
  wire recovered_62_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_62_reset || (((SR) === 1'bx) && (recovered_62_q == 1'b0))) recovered_62_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_62_q == (esc_dout_buf_18__i_1_n_0_6505df9)))) recovered_62_q <= (esc_dout_buf_18__i_1_n_0_6505df9);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_19_bef1e0f
  reg recovered_63_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [19] = recovered_63_q;
  wire recovered_63_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_63_reset || (((SR) === 1'bx) && (recovered_63_q == 1'b0))) recovered_63_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_63_q == (esc_dout_buf_19__i_1_n_0_edc3c7b)))) recovered_63_q <= (esc_dout_buf_19__i_1_n_0_edc3c7b);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_1_65a567e
  reg recovered_64_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [1] = recovered_64_q;
  wire recovered_64_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_64_reset || (((SR) === 1'bx) && (recovered_64_q == 1'b0))) recovered_64_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_64_q == (esc_dout_buf_1__i_1_n_0_bcd7410)))) recovered_64_q <= (esc_dout_buf_1__i_1_n_0_bcd7410);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_20_167900f
  reg recovered_65_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [20] = recovered_65_q;
  wire recovered_65_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_65_reset || (((SR) === 1'bx) && (recovered_65_q == 1'b0))) recovered_65_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_65_q == (esc_dout_buf_20__i_1_n_0_ab4b624)))) recovered_65_q <= (esc_dout_buf_20__i_1_n_0_ab4b624);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_21_6459474
  reg recovered_66_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [21] = recovered_66_q;
  wire recovered_66_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_66_reset || (((SR) === 1'bx) && (recovered_66_q == 1'b0))) recovered_66_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_66_q == (esc_dout_buf_21__i_1_n_0_e1219ab)))) recovered_66_q <= (esc_dout_buf_21__i_1_n_0_e1219ab);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_22_9d17b17
  reg recovered_67_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [22] = recovered_67_q;
  wire recovered_67_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_67_reset || (((SR) === 1'bx) && (recovered_67_q == 1'b0))) recovered_67_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_67_q == (esc_dout_buf_22__i_1_n_0_787b7ea)))) recovered_67_q <= (esc_dout_buf_22__i_1_n_0_787b7ea);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_23_6933fe3
  reg recovered_68_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [23] = recovered_68_q;
  wire recovered_68_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_68_reset || (((SR) === 1'bx) && (recovered_68_q == 1'b0))) recovered_68_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_68_q == (esc_dout_buf_23__i_1_n_0_b99fea5)))) recovered_68_q <= (esc_dout_buf_23__i_1_n_0_b99fea5);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_24_fd28f8a
  reg recovered_69_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [24] = recovered_69_q;
  wire recovered_69_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_69_reset || (((SR) === 1'bx) && (recovered_69_q == 1'b0))) recovered_69_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_69_q == (esc_dout_buf_24__i_1_n_0_f596885)))) recovered_69_q <= (esc_dout_buf_24__i_1_n_0_f596885);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_25_0ea3461
  reg recovered_70_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [25] = recovered_70_q;
  wire recovered_70_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_70_reset || (((SR) === 1'bx) && (recovered_70_q == 1'b0))) recovered_70_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_70_q == (esc_dout_buf_25__i_1_n_0_5604152)))) recovered_70_q <= (esc_dout_buf_25__i_1_n_0_5604152);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_26_de71e31
  reg recovered_71_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [26] = recovered_71_q;
  wire recovered_71_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_71_reset || (((SR) === 1'bx) && (recovered_71_q == 1'b0))) recovered_71_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_71_q == (esc_dout_buf_26__i_1_n_0_eeac2a9)))) recovered_71_q <= (esc_dout_buf_26__i_1_n_0_eeac2a9);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_27_f2455fc
  reg recovered_72_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [27] = recovered_72_q;
  wire recovered_72_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_72_reset || (((SR) === 1'bx) && (recovered_72_q == 1'b0))) recovered_72_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_72_q == (esc_dout_buf_27__i_1_n_0_600d618)))) recovered_72_q <= (esc_dout_buf_27__i_1_n_0_600d618);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_28_7cd6c17
  reg recovered_73_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [28] = recovered_73_q;
  wire recovered_73_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_73_reset || (((SR) === 1'bx) && (recovered_73_q == 1'b0))) recovered_73_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_73_q == (esc_dout_buf_28__i_1_n_0_567ea32)))) recovered_73_q <= (esc_dout_buf_28__i_1_n_0_567ea32);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_29_f39ef91
  reg recovered_74_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [29] = recovered_74_q;
  wire recovered_74_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_74_reset || (((SR) === 1'bx) && (recovered_74_q == 1'b0))) recovered_74_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_74_q == (esc_dout_buf_29__i_1_n_0_f8b40b3)))) recovered_74_q <= (esc_dout_buf_29__i_1_n_0_f8b40b3);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_2_fbccf26
  reg recovered_75_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [2] = recovered_75_q;
  wire recovered_75_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_75_reset || (((SR) === 1'bx) && (recovered_75_q == 1'b0))) recovered_75_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_75_q == (esc_dout_buf_2__i_1_n_0_0388fd1)))) recovered_75_q <= (esc_dout_buf_2__i_1_n_0_0388fd1);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_30_8980b9d
  reg recovered_76_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [30] = recovered_76_q;
  wire recovered_76_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_76_reset || (((SR) === 1'bx) && (recovered_76_q == 1'b0))) recovered_76_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_76_q == (esc_dout_buf_30__i_1_n_0_b0eac95)))) recovered_76_q <= (esc_dout_buf_30__i_1_n_0_b0eac95);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_31_e6ee0ac
  reg recovered_77_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [31] = recovered_77_q;
  wire recovered_77_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_77_reset || (((SR) === 1'bx) && (recovered_77_q == 1'b0))) recovered_77_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_77_q == (esc_dout_buf_31__i_1_n_0_995d1e3)))) recovered_77_q <= (esc_dout_buf_31__i_1_n_0_995d1e3);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_32_c77a351
  reg recovered_78_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [32] = recovered_78_q;
  wire recovered_78_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_78_reset || (((SR) === 1'bx) && (recovered_78_q == 1'b0))) recovered_78_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_78_q == (esc_dout_buf_32__i_1_n_0_3b28f63)))) recovered_78_q <= (esc_dout_buf_32__i_1_n_0_3b28f63);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_33_1eb79bc
  reg recovered_79_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [33] = recovered_79_q;
  wire recovered_79_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_79_reset || (((SR) === 1'bx) && (recovered_79_q == 1'b0))) recovered_79_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_79_q == (esc_dout_buf_33__i_1_n_0_7e0957a)))) recovered_79_q <= (esc_dout_buf_33__i_1_n_0_7e0957a);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_34_de4e58b
  reg recovered_80_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [34] = recovered_80_q;
  wire recovered_80_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_80_reset || (((SR) === 1'bx) && (recovered_80_q == 1'b0))) recovered_80_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_80_q == (esc_dout_buf_34__i_1_n_0_ce8d01c)))) recovered_80_q <= (esc_dout_buf_34__i_1_n_0_ce8d01c);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_35_e14d208
  reg recovered_81_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [35] = recovered_81_q;
  wire recovered_81_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_81_reset || (((SR) === 1'bx) && (recovered_81_q == 1'b0))) recovered_81_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_81_q == (esc_dout_buf_35__i_2_n_0_b1fe098)))) recovered_81_q <= (esc_dout_buf_35__i_2_n_0_b1fe098);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_3_3968327
  reg recovered_82_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [3] = recovered_82_q;
  wire recovered_82_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_82_reset || (((SR) === 1'bx) && (recovered_82_q == 1'b0))) recovered_82_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_82_q == (esc_dout_buf_3__i_1_n_0_a1e89d1)))) recovered_82_q <= (esc_dout_buf_3__i_1_n_0_a1e89d1);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_4_3b55ddb
  reg recovered_83_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [4] = recovered_83_q;
  wire recovered_83_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_83_reset || (((SR) === 1'bx) && (recovered_83_q == 1'b0))) recovered_83_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_83_q == (esc_dout_buf_4__i_1_n_0_9790d5b)))) recovered_83_q <= (esc_dout_buf_4__i_1_n_0_9790d5b);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_5_cd471d4
  reg recovered_84_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [5] = recovered_84_q;
  wire recovered_84_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_84_reset || (((SR) === 1'bx) && (recovered_84_q == 1'b0))) recovered_84_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_84_q == (esc_dout_buf_5__i_1_n_0_bcb4bd3)))) recovered_84_q <= (esc_dout_buf_5__i_1_n_0_bcb4bd3);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_6_0e42e9e
  reg recovered_85_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [6] = recovered_85_q;
  wire recovered_85_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_85_reset || (((SR) === 1'bx) && (recovered_85_q == 1'b0))) recovered_85_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_85_q == (esc_dout_buf_6__i_1_n_0_122f0de)))) recovered_85_q <= (esc_dout_buf_6__i_1_n_0_122f0de);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_7_22216d7
  reg recovered_86_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [7] = recovered_86_q;
  wire recovered_86_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_86_reset || (((SR) === 1'bx) && (recovered_86_q == 1'b0))) recovered_86_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_86_q == (esc_dout_buf_7__i_1_n_0_5c8c97d)))) recovered_86_q <= (esc_dout_buf_7__i_1_n_0_5c8c97d);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_8_c0dc513
  reg recovered_87_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [8] = recovered_87_q;
  wire recovered_87_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_87_reset || (((SR) === 1'bx) && (recovered_87_q == 1'b0))) recovered_87_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_87_q == (esc_dout_buf_8__i_1_n_0_fa8be1c)))) recovered_87_q <= (esc_dout_buf_8__i_1_n_0_fa8be1c);
  end

  // Reconstructed FDRE: esc_dout_buf_reg_9_53daae6
  reg recovered_88_q = 1'b0;
  assign esc_dout_buf_reg_35__0_895f1d4 [9] = recovered_88_q;
  wire recovered_88_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_88_reset || (((SR) === 1'bx) && (recovered_88_q == 1'b0))) recovered_88_q <= 1'b0;
    else if ((pop) || ((pop) === 1'bz) || (((pop) === 1'bx) && (recovered_88_q == (esc_dout_buf_9__i_1_n_0_2baf451)))) recovered_88_q <= (esc_dout_buf_9__i_1_n_0_2baf451);
  end

  // Reconstructed LUT3: dout_valid_i_1__0
  assign dout_valid_i_1__0_n_0 = ((data_valid) ? (((pop) ? (1'b1) : (~(p_30_in)))) : (pop));

  // Reconstructed FDRE: dout_valid_reg
  reg recovered_90_q = 1'b0;
  assign data_valid = recovered_90_q;
  wire recovered_90_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_90_reset || (((SR) === 1'bx) && (recovered_90_q == 1'b0))) recovered_90_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_90_q == (dout_valid_i_1__0_n_0)))) recovered_90_q <= (dout_valid_i_1__0_n_0);
  end

  // Reconstructed LUT6: empty_n_i_1__6
  assign empty_n_i_1__6_n_0 = ((empty_n_reg_n_0) ? (((pop) ? (((empty_n_i_2__1_n_0) ? (1'b1) : (((esc_mOutPtr_reg_5__0_51c21ea [0]) ? (((output_r_WREADY) ? (output_r_WVALID) : (1'b0))) : (1'b1))))) : (1'b1))) : (((pop) ? (((empty_n_i_2__1_n_0) ? (((output_r_WREADY) ? (~(output_r_WVALID)) : (1'b1))) : (((esc_mOutPtr_reg_5__0_51c21ea [0]) ? (1'b0) : (((output_r_WREADY) ? (~(output_r_WVALID)) : (1'b1))))))) : (((output_r_WREADY) ? (output_r_WVALID) : (1'b0))))));

  // Reconstructed LUT4: empty_n_i_2__1
  assign empty_n_i_2__1_n_0 = ((empty_n_i_3__1_n_0) ? (1'b1) : (((esc_mOutPtr_reg_5__0_51c21ea [2]) ? (1'b1) : (((esc_mOutPtr_reg_5__0_51c21ea [3]) ? (1'b1) : (esc_mOutPtr_reg_5__0_51c21ea [5]))))));

  // Reconstructed LUT4: empty_n_i_3__1
  assign empty_n_i_3__1_n_0 = ((esc_mOutPtr_reg_5__0_51c21ea [4]) ? (1'b1) : (((esc_mOutPtr_reg_5__0_51c21ea [1]) ? (1'b1) : (((mOutPtr_reg[6]) ? (1'b1) : (mOutPtr_reg[7]))))));

  // Reconstructed FDRE: empty_n_reg
  reg recovered_94_q = 1'b0;
  assign empty_n_reg_n_0 = recovered_94_q;
  wire recovered_94_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_94_reset || (((SR) === 1'bx) && (recovered_94_q == 1'b0))) recovered_94_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_94_q == (empty_n_i_1__6_n_0)))) recovered_94_q <= (empty_n_i_1__6_n_0);
  end

  // Reconstructed LUT5: full_n_i_1__8
  assign full_n_i_1__8_n_0 = ((pop) ? (1'b1) : (((p_1_in) ? (((ap_rst_n) ? (output_r_WREADY) : (1'b1))) : (((ap_rst_n) ? (((output_r_WREADY) ? (~(output_r_WVALID)) : (1'b0))) : (1'b1))))));

  // Reconstructed LUT5: full_n_i_2__7
  assign p_1_in = ((full_n_i_3__1_n_0) ? (1'b1) : (((esc_mOutPtr_reg_5__0_51c21ea [2]) ? (((esc_mOutPtr_reg_5__0_51c21ea [5]) ? (((esc_mOutPtr_reg_5__0_51c21ea [3]) ? (~(esc_mOutPtr_reg_5__0_51c21ea [4])) : (1'b1))) : (1'b1))) : (1'b1))));

  // Reconstructed LUT4: full_n_i_3__1
  assign full_n_i_3__1_n_0 = ((esc_mOutPtr_reg_5__0_51c21ea [0]) ? (((esc_mOutPtr_reg_5__0_51c21ea [1]) ? (((mOutPtr_reg[6]) ? (~(mOutPtr_reg[7])) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed FDRE: full_n_reg
  reg recovered_98_q = 1'b1;
  assign output_r_WREADY = recovered_98_q;
  wire recovered_98_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_98_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_98_q == 1'b0))) recovered_98_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_98_q == (full_n_i_1__8_n_0)))) recovered_98_q <= (full_n_i_1__8_n_0);
  end

  // Reconstructed LUT1: esc_mOutPtr_0__i_1__0_ba6eb72
  assign esc_mOutPtr_0__i_1__0_n_0_6c8ae45 = ~(esc_mOutPtr_reg_5__0_51c21ea [0]);

  // Reconstructed LUT3: esc_mOutPtr_7__i_1__1_d001591
  assign esc_mOutPtr_7__i_1__1_n_0_158cb4a = ((pop) ? (((output_r_WREADY) ? (~(output_r_WVALID)) : (1'b1))) : (((output_r_WREADY) ? (output_r_WVALID) : (1'b0))));

  // Reconstructed FDRE: esc_mOutPtr_reg_0_ffb8b5e
  reg recovered_101_q = 1'b0;
  assign esc_mOutPtr_reg_5__0_51c21ea [0] = recovered_101_q;
  wire recovered_101_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_101_reset || (((SR) === 1'bx) && (recovered_101_q == 1'b0))) recovered_101_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) || ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bz) || (((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bx) && (recovered_101_q == (esc_mOutPtr_0__i_1__0_n_0_6c8ae45)))) recovered_101_q <= (esc_mOutPtr_0__i_1__0_n_0_6c8ae45);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_1_9d1af5b
  reg recovered_102_q = 1'b0;
  assign esc_mOutPtr_reg_5__0_51c21ea [1] = recovered_102_q;
  wire recovered_102_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_102_reset || (((SR) === 1'bx) && (recovered_102_q == 1'b0))) recovered_102_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) || ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bz) || (((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bx) && (recovered_102_q == (esc_mOutPtr_reg_7__0_b1502f7 [0])))) recovered_102_q <= (esc_mOutPtr_reg_7__0_b1502f7 [0]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_2_6b8c13a
  reg recovered_103_q = 1'b0;
  assign esc_mOutPtr_reg_5__0_51c21ea [2] = recovered_103_q;
  wire recovered_103_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_103_reset || (((SR) === 1'bx) && (recovered_103_q == 1'b0))) recovered_103_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) || ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bz) || (((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bx) && (recovered_103_q == (esc_mOutPtr_reg_7__0_b1502f7 [1])))) recovered_103_q <= (esc_mOutPtr_reg_7__0_b1502f7 [1]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_3_0755ba0
  reg recovered_104_q = 1'b0;
  assign esc_mOutPtr_reg_5__0_51c21ea [3] = recovered_104_q;
  wire recovered_104_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_104_reset || (((SR) === 1'bx) && (recovered_104_q == 1'b0))) recovered_104_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) || ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bz) || (((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bx) && (recovered_104_q == (esc_mOutPtr_reg_7__0_b1502f7 [2])))) recovered_104_q <= (esc_mOutPtr_reg_7__0_b1502f7 [2]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_4_424d593
  reg recovered_105_q = 1'b0;
  assign esc_mOutPtr_reg_5__0_51c21ea [4] = recovered_105_q;
  wire recovered_105_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_105_reset || (((SR) === 1'bx) && (recovered_105_q == 1'b0))) recovered_105_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) || ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bz) || (((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bx) && (recovered_105_q == (esc_mOutPtr_reg_7__0_b1502f7 [3])))) recovered_105_q <= (esc_mOutPtr_reg_7__0_b1502f7 [3]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_5_4071cfb
  reg recovered_106_q = 1'b0;
  assign esc_mOutPtr_reg_5__0_51c21ea [5] = recovered_106_q;
  wire recovered_106_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_106_reset || (((SR) === 1'bx) && (recovered_106_q == 1'b0))) recovered_106_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) || ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bz) || (((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bx) && (recovered_106_q == (esc_mOutPtr_reg_7__0_b1502f7 [4])))) recovered_106_q <= (esc_mOutPtr_reg_7__0_b1502f7 [4]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_6_6a2a9db
  reg recovered_107_q = 1'b0;
  assign mOutPtr_reg[6] = recovered_107_q;
  wire recovered_107_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_107_reset || (((SR) === 1'bx) && (recovered_107_q == 1'b0))) recovered_107_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) || ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bz) || (((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bx) && (recovered_107_q == (esc_mOutPtr_reg_7__0_b1502f7 [5])))) recovered_107_q <= (esc_mOutPtr_reg_7__0_b1502f7 [5]);
  end

  // Reconstructed FDRE: esc_mOutPtr_reg_7_e373a77
  reg recovered_108_q = 1'b0;
  assign mOutPtr_reg[7] = recovered_108_q;
  wire recovered_108_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_108_reset || (((SR) === 1'bx) && (recovered_108_q == 1'b0))) recovered_108_q <= 1'b0;
    else if ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) || ((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bz) || (((esc_mOutPtr_7__i_1__1_n_0_158cb4a) === 1'bx) && (recovered_108_q == (esc_mOutPtr_reg_7__0_b1502f7 [6])))) recovered_108_q <= (esc_mOutPtr_reg_7__0_b1502f7 [6]);
  end

  RAMB18E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(18'h00000),
    .INIT_B(18'h00000),
    .INIT_FILE("NONE"),
    .RAM_MODE("SDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(36),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(18'h00000),
    .SRVAL_B(18'h00000),
    .WRITE_MODE_A("READ_FIRST"),
    .WRITE_MODE_B("READ_FIRST"),
    .WRITE_WIDTH_A(0),
    .WRITE_WIDTH_B(36)) 
    mem_reg
       (.ADDRARDADDR({esc_const1_c064970 ,rnext,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .ADDRBWRADDR({esc_const1_c064970 ,waddr,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 ,esc_const1_c064970 }),
        .CLKARDCLK(ap_clk),
        .CLKBWRCLK(ap_clk),
        .DIADI({mem_reg_i_9__0_n_0,mem_reg_i_10__0_n_0,mem_reg_i_11__0_n_0,mem_reg_i_12__0_n_0,mem_reg_i_13__0_n_0,mem_reg_i_14__0_n_0,mem_reg_i_15_n_0,mem_reg_i_16_n_0,mem_reg_i_17_n_0,mem_reg_i_18_n_0,mem_reg_i_19_n_0,mem_reg_i_20_n_0,mem_reg_i_21_n_0,mem_reg_i_22_n_0,mem_reg_i_23_n_0,mem_reg_i_24_n_0}),
        .DIBDI({mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_25_n_0,mem_reg_i_26_n_0,mem_reg_i_27_n_0}),
        .DIPADIP({esc_const1_c064970 ,esc_const1_c064970 }),
        .DIPBDIP({esc_const1_c064970 ,esc_const1_c064970 }),
        .DOADO(q_buf[15:0]),
        .DOBDO(q_buf[31:16]),
        .DOPADOP(q_buf[33:32]),
        .DOPBDOP(q_buf[35:34]),
        .ENARDEN(esc_const1_c064970 ),
        .ENBWREN(output_r_WREADY),
        .REGCEAREGCE(esc_const0_a0cf646 ),
        .REGCEB(esc_const0_a0cf646 ),
        .RSTRAMARSTRAM(esc_const0_a0cf646 ),
        .RSTRAMB(esc_const0_a0cf646 ),
        .RSTREGARSTREG(esc_const0_a0cf646 ),
        .RSTREGB(esc_const0_a0cf646 ),
        .WEA({esc_const0_a0cf646 ,esc_const0_a0cf646 }),
        .WEBWE({output_r_WVALID,output_r_WVALID,output_r_WVALID,output_r_WVALID}));

  // Reconstructed LUT3: mem_reg_i_10__0
  assign mem_reg_i_10__0_n_0 = ((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[14]) : (1'b0))));

  // Reconstructed LUT3: mem_reg_i_11__0
  assign mem_reg_i_11__0_n_0 = ((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[13]) : (1'b0))));

  // Reconstructed LUT3: mem_reg_i_12__0
  assign mem_reg_i_12__0_n_0 = ((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[12]) : (1'b0))));

  // Reconstructed LUT3: mem_reg_i_13__0
  assign mem_reg_i_13__0_n_0 = ((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[11]) : (1'b0))));

  // Reconstructed LUT3: mem_reg_i_14__0
  assign mem_reg_i_14__0_n_0 = ((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[10]) : (1'b0))));

  // Reconstructed LUT6: mem_reg_i_15
  assign mem_reg_i_15_n_0 = ((Q[5]) ? (((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[9]) : (1'b0))))) : (((Q[4]) ? (((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[9]) : (mem_reg_2[6]))))) : (((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[9]) : (1'b0))))))));

  // Reconstructed LUT6: mem_reg_i_16
  assign mem_reg_i_16_n_0 = ((Q[6]) ? (((Q[8]) ? (1'b0) : (mem_reg_0[8]))) : (((Q[8]) ? (1'b0) : (((mem_reg_i_32_n_0) ? (1'b1) : (((mem_reg_i_31_n_0) ? (1'b0) : (mem_reg_1[5]))))))));

  // Reconstructed LUT6: mem_reg_i_17
  assign mem_reg_i_17_n_0 = ((Q[6]) ? (((Q[8]) ? (1'b0) : (mem_reg_0[7]))) : (((Q[8]) ? (1'b0) : (((mem_reg_i_33_n_0) ? (1'b1) : (((mem_reg_i_31_n_0) ? (1'b0) : (mem_reg_1[4]))))))));

  // Reconstructed LUT6: mem_reg_i_18
  assign mem_reg_i_18_n_0 = ((mem_reg_i_37_n_0) ? (((mem_reg_i_36_n_0) ? (((mem_reg_0[6]) ? (~(mem_reg_i_34_n_0)) : (1'b0))) : (((mem_reg_1[3]) ? (1'b1) : (((mem_reg_i_35_n_0) ? (1'b1) : (((mem_reg_0[6]) ? (~(mem_reg_i_34_n_0)) : (1'b0))))))))) : (((mem_reg_0[6]) ? (~(mem_reg_i_34_n_0)) : (1'b0))));

  // Reconstructed LUT6: mem_reg_i_19
  assign mem_reg_i_19_n_0 = ((mem_reg_i_38_n_0) ? (((mem_reg_1[2]) ? (((mem_reg_i_36_n_0) ? (((mem_reg_0[5]) ? (~(mem_reg_i_34_n_0)) : (1'b0))) : (1'b1))) : (((mem_reg_i_35_n_0) ? (((mem_reg_i_36_n_0) ? (((mem_reg_0[5]) ? (~(mem_reg_i_34_n_0)) : (1'b0))) : (1'b1))) : (((mem_reg_0[5]) ? (~(mem_reg_i_34_n_0)) : (1'b0))))))) : (((mem_reg_0[5]) ? (~(mem_reg_i_34_n_0)) : (1'b0))));

  // Reconstructed LUT4: mem_reg_i_1__0
  assign rnext[7] = ((pop) ? (((raddr[6]) ? (((mem_reg_i_29_n_0) ? (raddr[7]) : (~(raddr[7])))) : (raddr[7]))) : (raddr[7]));

  // Reconstructed LUT6: mem_reg_i_20
  assign mem_reg_i_20_n_0 = ((mem_reg_i_39_n_0) ? (((mem_reg_1[1]) ? (((mem_reg_i_36_n_0) ? (((mem_reg_0[4]) ? (~(mem_reg_i_34_n_0)) : (1'b0))) : (1'b1))) : (((mem_reg_i_35_n_0) ? (((mem_reg_i_36_n_0) ? (((mem_reg_0[4]) ? (~(mem_reg_i_34_n_0)) : (1'b0))) : (1'b1))) : (((mem_reg_0[4]) ? (~(mem_reg_i_34_n_0)) : (1'b0))))))) : (((mem_reg_0[4]) ? (~(mem_reg_i_34_n_0)) : (1'b0))));

  // Reconstructed LUT6: mem_reg_i_21
  assign mem_reg_i_21_n_0 = ((mem_reg_i_40_n_0) ? (((mem_reg_1[0]) ? (((mem_reg_i_36_n_0) ? (((mem_reg_0[3]) ? (~(mem_reg_i_34_n_0)) : (1'b0))) : (1'b1))) : (((mem_reg_i_35_n_0) ? (((mem_reg_i_36_n_0) ? (((mem_reg_0[3]) ? (~(mem_reg_i_34_n_0)) : (1'b0))) : (1'b1))) : (((mem_reg_0[3]) ? (~(mem_reg_i_34_n_0)) : (1'b0))))))) : (((mem_reg_0[3]) ? (~(mem_reg_i_34_n_0)) : (1'b0))));

  // Reconstructed LUT3: mem_reg_i_22
  assign mem_reg_i_22_n_0 = ((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[2]) : (1'b0))));

  // Reconstructed LUT3: mem_reg_i_23
  assign mem_reg_i_23_n_0 = ((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[1]) : (1'b0))));

  // Reconstructed LUT6: mem_reg_i_24
  assign mem_reg_i_24_n_0 = ((mem_reg_i_35_n_0) ? (((mem_reg_0[0]) ? (((Q[6]) ? (~(Q[8])) : (1'b0))) : (1'b0))) : (((Q[2]) ? (((mem_reg_0[0]) ? (((Q[6]) ? (~(Q[8])) : (1'b0))) : (1'b0))) : (((mem_reg_i_41_n_0) ? (((mem_reg_0[0]) ? (((Q[6]) ? (~(Q[8])) : (1'b0))) : (1'b0))) : (1'b1))))));

  // Reconstructed LUT3: mem_reg_i_25
  assign mem_reg_i_25_n_0 = ((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[18]) : (1'b0))));

  // Reconstructed LUT3: mem_reg_i_26
  assign mem_reg_i_26_n_0 = ((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[17]) : (1'b0))));

  // Reconstructed LUT3: mem_reg_i_27
  assign mem_reg_i_27_n_0 = ((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[16]) : (1'b0))));

  // Reconstructed LUT6: mem_reg_i_28
  assign output_r_WVALID = ((mem_reg_i_42_n_0) ? (1'b1) : (((Q[3]) ? (output_r_WREADY) : (((Q[8]) ? (output_r_WREADY) : (((output_r_WREADY) ? (((Q[2]) ? (1'b1) : (Q[7]))) : (1'b0))))))));

  // Reconstructed LUT6: mem_reg_i_29
  assign mem_reg_i_29_n_0 = ((raddr[5]) ? (((raddr[2]) ? (((raddr[1]) ? (((raddr[0]) ? (((raddr[3]) ? (~(raddr[4])) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT3: mem_reg_i_2__0
  assign rnext[6] = ((pop) ? (((mem_reg_i_29_n_0) ? (raddr[6]) : (~(raddr[6])))) : (raddr[6]));

  // Reconstructed LUT5: mem_reg_i_30
  assign mem_reg_i_30_n_0 = ((raddr[4]) ? (((raddr[3]) ? (((raddr[0]) ? (((raddr[1]) ? (~(raddr[2])) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT4: mem_reg_i_31
  assign mem_reg_i_31_n_0 = ((Q[2]) ? (((Q[3]) ? (1'b1) : (((Q[4]) ? (1'b1) : (Q[5]))))) : (1'b1));

  // Reconstructed LUT4: mem_reg_i_32
  assign mem_reg_i_32_n_0 = ((Q[5]) ? (mem_reg_4[5]) : (((mem_reg_2[5]) ? (Q[4]) : (1'b0))));

  // Reconstructed LUT6: mem_reg_i_33
  assign mem_reg_i_33_n_0 = ((mem_reg_4[4]) ? (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[4]) : (((mem_reg_3[4]) ? (Q[3]) : (1'b0))))))) : (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[4]) : (((mem_reg_3[4]) ? (Q[3]) : (1'b0))))))));

  // Reconstructed LUT2: mem_reg_i_34
  assign mem_reg_i_34_n_0 = ((Q[6]) ? (Q[8]) : (1'b1));

  // Reconstructed LUT3: mem_reg_i_35
  assign mem_reg_i_35_n_0 = ((Q[5]) ? (1'b1) : (((Q[4]) ? (1'b1) : (Q[3]))));

  // Reconstructed LUT6: mem_reg_i_36
  assign mem_reg_i_36_n_0 = ((Q[8]) ? (1'b1) : (((Q[6]) ? (1'b1) : (((Q[2]) ? (1'b0) : (((Q[5]) ? (1'b0) : (((Q[4]) ? (1'b0) : (~(Q[3])))))))))));

  // Reconstructed LUT6: mem_reg_i_37
  assign mem_reg_i_37_n_0 = ((mem_reg_4[3]) ? (((Q[3]) ? (((mem_reg_3[3]) ? (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[3]) : (1'b1))))) : (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[3]) : (1'b0))))))) : (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[3]) : (1'b1))))))) : (((Q[3]) ? (((mem_reg_3[3]) ? (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[3]) : (1'b1))))) : (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[3]) : (1'b0))))))) : (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[3]) : (1'b1))))))));

  // Reconstructed LUT6: mem_reg_i_38
  assign mem_reg_i_38_n_0 = ((mem_reg_4[2]) ? (((Q[3]) ? (((mem_reg_3[2]) ? (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[2]) : (1'b1))))) : (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[2]) : (1'b0))))))) : (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[2]) : (1'b1))))))) : (((Q[3]) ? (((mem_reg_3[2]) ? (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[2]) : (1'b1))))) : (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[2]) : (1'b0))))))) : (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[2]) : (1'b1))))))));

  // Reconstructed LUT6: mem_reg_i_39
  assign mem_reg_i_39_n_0 = ((mem_reg_4[1]) ? (((Q[3]) ? (((mem_reg_3[1]) ? (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[1]) : (1'b1))))) : (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[1]) : (1'b0))))))) : (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[1]) : (1'b1))))))) : (((Q[3]) ? (((mem_reg_3[1]) ? (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[1]) : (1'b1))))) : (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[1]) : (1'b0))))))) : (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[1]) : (1'b1))))))));

  // Reconstructed LUT3: mem_reg_i_3__0
  assign rnext[5] = ((pop) ? (((mem_reg_i_30_n_0) ? (raddr[5]) : (~(raddr[5])))) : (raddr[5]));

  // Reconstructed LUT6: mem_reg_i_40
  assign mem_reg_i_40_n_0 = ((mem_reg_4[0]) ? (((Q[3]) ? (((mem_reg_3[0]) ? (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[0]) : (1'b1))))) : (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[0]) : (1'b0))))))) : (((Q[5]) ? (1'b1) : (((Q[4]) ? (mem_reg_2[0]) : (1'b1))))))) : (((Q[3]) ? (((mem_reg_3[0]) ? (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[0]) : (1'b1))))) : (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[0]) : (1'b0))))))) : (((Q[5]) ? (1'b0) : (((Q[4]) ? (mem_reg_2[0]) : (1'b1))))))));

  // Reconstructed LUT5: mem_reg_i_41
  assign mem_reg_i_41_n_0 = ((zext_ln125_reg_9138_reg) ? (((Q[7]) ? (((Q[8]) ? (1'b1) : (Q[6]))) : (((icmp_ln125_reg_9133) ? (((Q[8]) ? (1'b1) : (Q[6]))) : (1'b1))))) : (((Q[7]) ? (1'b1) : (((icmp_ln125_reg_9133) ? (((Q[8]) ? (1'b1) : (Q[6]))) : (1'b1))))));

  // Reconstructed LUT5: mem_reg_i_42
  assign mem_reg_i_42_n_0 = ((Q[4]) ? (output_r_WREADY) : (((Q[5]) ? (output_r_WREADY) : (((Q[1]) ? (output_r_WREADY) : (((Q[6]) ? (output_r_WREADY) : (1'b0))))))));

  // Reconstructed LUT6: mem_reg_i_4__0
  assign rnext[4] = ((pop) ? (((raddr[2]) ? (((raddr[1]) ? (((raddr[0]) ? (((raddr[3]) ? (~(raddr[4])) : (raddr[4]))) : (raddr[4]))) : (raddr[4]))) : (raddr[4]))) : (raddr[4]));

  // Reconstructed LUT5: mem_reg_i_5__0
  assign rnext[3] = ((raddr[3]) ? (((pop) ? (((raddr[2]) ? (((raddr[1]) ? (~(raddr[0])) : (1'b1))) : (1'b1))) : (1'b1))) : (((pop) ? (((raddr[2]) ? (((raddr[1]) ? (raddr[0]) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: mem_reg_i_6__0
  assign rnext[2] = ((raddr[2]) ? (((pop) ? (((raddr[0]) ? (~(raddr[1])) : (1'b1))) : (1'b1))) : (((pop) ? (((raddr[0]) ? (raddr[1]) : (1'b0))) : (1'b0))));

  // Reconstructed LUT3: mem_reg_i_7__0
  assign rnext[1] = ((raddr[1]) ? (((pop) ? (~(raddr[0])) : (1'b1))) : (((pop) ? (raddr[0]) : (1'b0))));

  // Reconstructed LUT2: mem_reg_i_8__0
  assign rnext[0] = ((pop) ? (~(raddr[0])) : (raddr[0]));

  // Reconstructed LUT3: mem_reg_i_9__0
  assign mem_reg_i_9__0_n_0 = ((Q[8]) ? (1'b0) : (((Q[6]) ? (mem_reg_0[15]) : (1'b0))));

  // Reconstructed LUT2: p_0_out_carry__0_i_1__0
  assign S[2] = ((mOutPtr_reg[7]) ? (mOutPtr_reg[6]) : (~(mOutPtr_reg[6])));

  // Reconstructed LUT2: p_0_out_carry__0_i_2__0
  assign S[1] = ((mOutPtr_reg[6]) ? (esc_mOutPtr_reg_5__0_51c21ea [5]) : (~(esc_mOutPtr_reg_5__0_51c21ea [5])));

  // Reconstructed LUT2: p_0_out_carry__0_i_3__2
  assign S[0] = ((esc_mOutPtr_reg_5__0_51c21ea [5]) ? (esc_mOutPtr_reg_5__0_51c21ea [4]) : (~(esc_mOutPtr_reg_5__0_51c21ea [4])));

  // Reconstructed LUT1: p_0_out_carry_i_1__1
  assign DI = ~(esc_mOutPtr_reg_5__0_51c21ea [1]);

  // Reconstructed LUT2: p_0_out_carry_i_2__1
  assign esc_mOutPtr_reg_3__0_af193d3 [3] = ((esc_mOutPtr_reg_5__0_51c21ea [4]) ? (esc_mOutPtr_reg_5__0_51c21ea [3]) : (~(esc_mOutPtr_reg_5__0_51c21ea [3])));

  // Reconstructed LUT2: p_0_out_carry_i_3__1
  assign esc_mOutPtr_reg_3__0_af193d3 [2] = ((esc_mOutPtr_reg_5__0_51c21ea [3]) ? (esc_mOutPtr_reg_5__0_51c21ea [2]) : (~(esc_mOutPtr_reg_5__0_51c21ea [2])));

  // Reconstructed LUT2: p_0_out_carry_i_4__1
  assign esc_mOutPtr_reg_3__0_af193d3 [1] = ((esc_mOutPtr_reg_5__0_51c21ea [2]) ? (esc_mOutPtr_reg_5__0_51c21ea [1]) : (~(esc_mOutPtr_reg_5__0_51c21ea [1])));

  // Reconstructed LUT4: p_0_out_carry_i_5__1
  assign esc_mOutPtr_reg_3__0_af193d3 [0] = ((pop) ? (~(esc_mOutPtr_reg_5__0_51c21ea [1])) : (((esc_mOutPtr_reg_5__0_51c21ea [1]) ? (((output_r_WREADY) ? (output_r_WVALID) : (1'b0))) : (((output_r_WREADY) ? (~(output_r_WVALID)) : (1'b1))))));

  // Reconstructed FDRE: esc_q_tmp_reg_0_e5b75c2
  reg recovered_160_q = 1'b0;
  assign q_tmp[0] = recovered_160_q;
  wire recovered_160_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_160_reset || (((SR) === 1'bx) && (recovered_160_q == 1'b0))) recovered_160_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_160_q == (mem_reg_i_24_n_0)))) recovered_160_q <= (mem_reg_i_24_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_10_593161b
  reg recovered_161_q = 1'b0;
  assign q_tmp[10] = recovered_161_q;
  wire recovered_161_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_161_reset || (((SR) === 1'bx) && (recovered_161_q == 1'b0))) recovered_161_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_161_q == (mem_reg_i_14__0_n_0)))) recovered_161_q <= (mem_reg_i_14__0_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_11_1d4fe85
  reg recovered_162_q = 1'b0;
  assign q_tmp[11] = recovered_162_q;
  wire recovered_162_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_162_reset || (((SR) === 1'bx) && (recovered_162_q == 1'b0))) recovered_162_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_162_q == (mem_reg_i_13__0_n_0)))) recovered_162_q <= (mem_reg_i_13__0_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_12_19bc390
  reg recovered_163_q = 1'b0;
  assign q_tmp[12] = recovered_163_q;
  wire recovered_163_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_163_reset || (((SR) === 1'bx) && (recovered_163_q == 1'b0))) recovered_163_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_163_q == (mem_reg_i_12__0_n_0)))) recovered_163_q <= (mem_reg_i_12__0_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_13_7e90f9d
  reg recovered_164_q = 1'b0;
  assign q_tmp[13] = recovered_164_q;
  wire recovered_164_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_164_reset || (((SR) === 1'bx) && (recovered_164_q == 1'b0))) recovered_164_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_164_q == (mem_reg_i_11__0_n_0)))) recovered_164_q <= (mem_reg_i_11__0_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_14_6ed096b
  reg recovered_165_q = 1'b0;
  assign q_tmp[14] = recovered_165_q;
  wire recovered_165_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_165_reset || (((SR) === 1'bx) && (recovered_165_q == 1'b0))) recovered_165_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_165_q == (mem_reg_i_10__0_n_0)))) recovered_165_q <= (mem_reg_i_10__0_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_15_1ebc7c1
  reg recovered_166_q = 1'b0;
  assign q_tmp[15] = recovered_166_q;
  wire recovered_166_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_166_reset || (((SR) === 1'bx) && (recovered_166_q == 1'b0))) recovered_166_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_166_q == (mem_reg_i_9__0_n_0)))) recovered_166_q <= (mem_reg_i_9__0_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_16_81679ba
  reg recovered_167_q = 1'b0;
  assign q_tmp[16] = recovered_167_q;
  wire recovered_167_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_167_reset || (((SR) === 1'bx) && (recovered_167_q == 1'b0))) recovered_167_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_167_q == (mem_reg_i_27_n_0)))) recovered_167_q <= (mem_reg_i_27_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_17_131839b
  reg recovered_168_q = 1'b0;
  assign q_tmp[17] = recovered_168_q;
  wire recovered_168_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_168_reset || (((SR) === 1'bx) && (recovered_168_q == 1'b0))) recovered_168_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_168_q == (mem_reg_i_26_n_0)))) recovered_168_q <= (mem_reg_i_26_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_1_891e06f
  reg recovered_169_q = 1'b0;
  assign q_tmp[1] = recovered_169_q;
  wire recovered_169_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_169_reset || (((SR) === 1'bx) && (recovered_169_q == 1'b0))) recovered_169_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_169_q == (mem_reg_i_23_n_0)))) recovered_169_q <= (mem_reg_i_23_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_2_7b7dcbd
  reg recovered_170_q = 1'b0;
  assign q_tmp[2] = recovered_170_q;
  wire recovered_170_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_170_reset || (((SR) === 1'bx) && (recovered_170_q == 1'b0))) recovered_170_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_170_q == (mem_reg_i_22_n_0)))) recovered_170_q <= (mem_reg_i_22_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_31_31d8b9a
  reg recovered_171_q = 1'b0;
  assign q_tmp[31] = recovered_171_q;
  wire recovered_171_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_171_reset || (((SR) === 1'bx) && (recovered_171_q == 1'b0))) recovered_171_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_171_q == (mem_reg_i_25_n_0)))) recovered_171_q <= (mem_reg_i_25_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_35_c4aa480
  reg recovered_172_q = 1'b0;
  assign q_tmp[35] = recovered_172_q;
  wire recovered_172_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_172_reset || (((SR) === 1'bx) && (recovered_172_q == 1'b0))) recovered_172_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_172_q == (esc_const1_c064970)))) recovered_172_q <= (esc_const1_c064970);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_3_8edae5f
  reg recovered_173_q = 1'b0;
  assign q_tmp[3] = recovered_173_q;
  wire recovered_173_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_173_reset || (((SR) === 1'bx) && (recovered_173_q == 1'b0))) recovered_173_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_173_q == (mem_reg_i_21_n_0)))) recovered_173_q <= (mem_reg_i_21_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_4_66e5c00
  reg recovered_174_q = 1'b0;
  assign q_tmp[4] = recovered_174_q;
  wire recovered_174_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_174_reset || (((SR) === 1'bx) && (recovered_174_q == 1'b0))) recovered_174_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_174_q == (mem_reg_i_20_n_0)))) recovered_174_q <= (mem_reg_i_20_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_5_ddc7a94
  reg recovered_175_q = 1'b0;
  assign q_tmp[5] = recovered_175_q;
  wire recovered_175_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_175_reset || (((SR) === 1'bx) && (recovered_175_q == 1'b0))) recovered_175_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_175_q == (mem_reg_i_19_n_0)))) recovered_175_q <= (mem_reg_i_19_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_6_ff84a2c
  reg recovered_176_q = 1'b0;
  assign q_tmp[6] = recovered_176_q;
  wire recovered_176_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_176_reset || (((SR) === 1'bx) && (recovered_176_q == 1'b0))) recovered_176_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_176_q == (mem_reg_i_18_n_0)))) recovered_176_q <= (mem_reg_i_18_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_7_0aea2b6
  reg recovered_177_q = 1'b0;
  assign q_tmp[7] = recovered_177_q;
  wire recovered_177_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_177_reset || (((SR) === 1'bx) && (recovered_177_q == 1'b0))) recovered_177_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_177_q == (mem_reg_i_17_n_0)))) recovered_177_q <= (mem_reg_i_17_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_8_75d4846
  reg recovered_178_q = 1'b0;
  assign q_tmp[8] = recovered_178_q;
  wire recovered_178_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_178_reset || (((SR) === 1'bx) && (recovered_178_q == 1'b0))) recovered_178_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_178_q == (mem_reg_i_16_n_0)))) recovered_178_q <= (mem_reg_i_16_n_0);
  end

  // Reconstructed FDRE: esc_q_tmp_reg_9_a36dbd1
  reg recovered_179_q = 1'b0;
  assign q_tmp[9] = recovered_179_q;
  wire recovered_179_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_179_reset || (((SR) === 1'bx) && (recovered_179_q == 1'b0))) recovered_179_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_179_q == (mem_reg_i_15_n_0)))) recovered_179_q <= (mem_reg_i_15_n_0);
  end

  // Reconstructed FDRE: esc_raddr_reg_0_bde3b2d
  reg recovered_180_q = 1'b0;
  assign raddr[0] = recovered_180_q;
  wire recovered_180_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_180_reset || (((SR) === 1'bx) && (recovered_180_q == 1'b0))) recovered_180_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_180_q == (rnext[0])))) recovered_180_q <= (rnext[0]);
  end

  // Reconstructed FDRE: esc_raddr_reg_1_eaca36b
  reg recovered_181_q = 1'b0;
  assign raddr[1] = recovered_181_q;
  wire recovered_181_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_181_reset || (((SR) === 1'bx) && (recovered_181_q == 1'b0))) recovered_181_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_181_q == (rnext[1])))) recovered_181_q <= (rnext[1]);
  end

  // Reconstructed FDRE: esc_raddr_reg_2_ae4dfd7
  reg recovered_182_q = 1'b0;
  assign raddr[2] = recovered_182_q;
  wire recovered_182_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_182_reset || (((SR) === 1'bx) && (recovered_182_q == 1'b0))) recovered_182_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_182_q == (rnext[2])))) recovered_182_q <= (rnext[2]);
  end

  // Reconstructed FDRE: esc_raddr_reg_3_2191f84
  reg recovered_183_q = 1'b0;
  assign raddr[3] = recovered_183_q;
  wire recovered_183_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_183_reset || (((SR) === 1'bx) && (recovered_183_q == 1'b0))) recovered_183_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_183_q == (rnext[3])))) recovered_183_q <= (rnext[3]);
  end

  // Reconstructed FDRE: esc_raddr_reg_4_8a1fcb0
  reg recovered_184_q = 1'b0;
  assign raddr[4] = recovered_184_q;
  wire recovered_184_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_184_reset || (((SR) === 1'bx) && (recovered_184_q == 1'b0))) recovered_184_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_184_q == (rnext[4])))) recovered_184_q <= (rnext[4]);
  end

  // Reconstructed FDRE: esc_raddr_reg_5_0929059
  reg recovered_185_q = 1'b0;
  assign raddr[5] = recovered_185_q;
  wire recovered_185_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_185_reset || (((SR) === 1'bx) && (recovered_185_q == 1'b0))) recovered_185_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_185_q == (rnext[5])))) recovered_185_q <= (rnext[5]);
  end

  // Reconstructed FDRE: esc_raddr_reg_6_6bfa800
  reg recovered_186_q = 1'b0;
  assign raddr[6] = recovered_186_q;
  wire recovered_186_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_186_reset || (((SR) === 1'bx) && (recovered_186_q == 1'b0))) recovered_186_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_186_q == (rnext[6])))) recovered_186_q <= (rnext[6]);
  end

  // Reconstructed FDRE: esc_raddr_reg_7_98ccdae
  reg recovered_187_q = 1'b0;
  assign raddr[7] = recovered_187_q;
  wire recovered_187_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_187_reset || (((SR) === 1'bx) && (recovered_187_q == 1'b0))) recovered_187_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_187_q == (rnext[7])))) recovered_187_q <= (rnext[7]);
  end

  // Reconstructed LUT5: show_ahead_i_1__0
  assign show_ahead0 = ((pop) ? (((esc_mOutPtr_reg_5__0_51c21ea [0]) ? (((empty_n_i_2__1_n_0) ? (1'b0) : (((output_r_WREADY) ? (output_r_WVALID) : (1'b0))))) : (1'b0))) : (((esc_mOutPtr_reg_5__0_51c21ea [0]) ? (1'b0) : (((empty_n_i_2__1_n_0) ? (1'b0) : (((output_r_WREADY) ? (output_r_WVALID) : (1'b0))))))));

  // Reconstructed FDRE: show_ahead_reg
  reg recovered_189_q = 1'b0;
  assign show_ahead = recovered_189_q;
  wire recovered_189_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_189_reset || (((SR) === 1'bx) && (recovered_189_q == 1'b0))) recovered_189_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_189_q == (show_ahead0)))) recovered_189_q <= (show_ahead0);
  end

  // Reconstructed LUT1: esc_waddr_0__i_1__0_ea57964
  assign esc_waddr_0__i_1__0_n_0_175f693 = ~(waddr[0]);

  // Reconstructed LUT2: esc_waddr_1__i_1__0_ae1a13e
  assign esc_waddr_1__i_1__0_n_0_cdd7208 = ((waddr[1]) ? (~(waddr[0])) : (waddr[0]));

  // Reconstructed LUT3: esc_waddr_2__i_1__0_39184b5
  assign esc_waddr_2__i_1__0_n_0_92c702f = ((waddr[1]) ? (((waddr[0]) ? (~(waddr[2])) : (waddr[2]))) : (waddr[2]));

  // Reconstructed LUT4: esc_waddr_3__i_1__0_b69e5d1
  assign esc_waddr_3__i_1__0_n_0_761b3f4 = ((waddr[2]) ? (((waddr[1]) ? (((waddr[0]) ? (~(waddr[3])) : (waddr[3]))) : (waddr[3]))) : (waddr[3]));

  // Reconstructed LUT5: esc_waddr_4__i_1__0_05c8dc1
  assign esc_waddr_4__i_1__0_n_0_88347f4 = ((waddr[3]) ? (((waddr[0]) ? (((waddr[1]) ? (((waddr[2]) ? (~(waddr[4])) : (waddr[4]))) : (waddr[4]))) : (waddr[4]))) : (waddr[4]));

  // Reconstructed LUT6: esc_waddr_5__i_1__1_f1e8306
  assign esc_waddr_5__i_1__1_n_0_5199fa7 = ((waddr[4]) ? (((waddr[2]) ? (((waddr[1]) ? (((waddr[0]) ? (((waddr[3]) ? (~(waddr[5])) : (waddr[5]))) : (waddr[5]))) : (waddr[5]))) : (waddr[5]))) : (waddr[5]));

  // Reconstructed LUT6: esc_waddr_6__i_1__0_7a490b7
  assign esc_waddr_6__i_1__0_n_0_4a579a1 = ((waddr[5]) ? (((waddr[3]) ? (((esc_waddr_6__i_2__0_n_0_a8f19c2) ? (((waddr[2]) ? (((waddr[4]) ? (~(waddr[6])) : (waddr[6]))) : (waddr[6]))) : (waddr[6]))) : (waddr[6]))) : (waddr[6]));

  // Reconstructed LUT2: esc_waddr_6__i_2__0_0dcebba
  assign esc_waddr_6__i_2__0_n_0_a8f19c2 = ((waddr[0]) ? (waddr[1]) : (1'b0));

  // Reconstructed LUT2: esc_waddr_7__i_1__0_a27dde5
  assign push = ((output_r_WREADY) ? (output_r_WVALID) : (1'b0));

  // Reconstructed LUT4: esc_waddr_7__i_2__0_e8b5719
  assign esc_waddr_7__i_2__0_n_0_2b285d4 = ((waddr[6]) ? (((esc_waddr_7__i_4__0_n_0_b84c479) ? (((waddr[7]) ? (esc_waddr_7__i_3__0_n_0_cbdab48) : (1'b1))) : (((waddr[7]) ? (esc_waddr_7__i_3__0_n_0_cbdab48) : (1'b0))))) : (waddr[7]));

  // Reconstructed LUT6: esc_waddr_7__i_3__0_3abe118
  assign esc_waddr_7__i_3__0_n_0_cbdab48 = ((waddr[5]) ? (((waddr[3]) ? (((waddr[1]) ? (((waddr[0]) ? (((waddr[2]) ? (~(waddr[4])) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT6: esc_waddr_7__i_4__0_2113441
  assign esc_waddr_7__i_4__0_n_0_b84c479 = ((waddr[5]) ? (((waddr[3]) ? (((waddr[0]) ? (((waddr[1]) ? (((waddr[2]) ? (waddr[4]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_waddr_reg_0_a5f0615
  reg recovered_202_q = 1'b0;
  assign waddr[0] = recovered_202_q;
  wire recovered_202_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_202_reset || (((SR) === 1'bx) && (recovered_202_q == 1'b0))) recovered_202_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_202_q == (esc_waddr_0__i_1__0_n_0_175f693)))) recovered_202_q <= (esc_waddr_0__i_1__0_n_0_175f693);
  end

  // Reconstructed FDRE: esc_waddr_reg_1_358bf4d
  reg recovered_203_q = 1'b0;
  assign waddr[1] = recovered_203_q;
  wire recovered_203_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_203_reset || (((SR) === 1'bx) && (recovered_203_q == 1'b0))) recovered_203_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_203_q == (esc_waddr_1__i_1__0_n_0_cdd7208)))) recovered_203_q <= (esc_waddr_1__i_1__0_n_0_cdd7208);
  end

  // Reconstructed FDRE: esc_waddr_reg_2_2c95dfb
  reg recovered_204_q = 1'b0;
  assign waddr[2] = recovered_204_q;
  wire recovered_204_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_204_reset || (((SR) === 1'bx) && (recovered_204_q == 1'b0))) recovered_204_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_204_q == (esc_waddr_2__i_1__0_n_0_92c702f)))) recovered_204_q <= (esc_waddr_2__i_1__0_n_0_92c702f);
  end

  // Reconstructed FDRE: esc_waddr_reg_3_aadf430
  reg recovered_205_q = 1'b0;
  assign waddr[3] = recovered_205_q;
  wire recovered_205_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_205_reset || (((SR) === 1'bx) && (recovered_205_q == 1'b0))) recovered_205_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_205_q == (esc_waddr_3__i_1__0_n_0_761b3f4)))) recovered_205_q <= (esc_waddr_3__i_1__0_n_0_761b3f4);
  end

  // Reconstructed FDRE: esc_waddr_reg_4_22508b6
  reg recovered_206_q = 1'b0;
  assign waddr[4] = recovered_206_q;
  wire recovered_206_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_206_reset || (((SR) === 1'bx) && (recovered_206_q == 1'b0))) recovered_206_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_206_q == (esc_waddr_4__i_1__0_n_0_88347f4)))) recovered_206_q <= (esc_waddr_4__i_1__0_n_0_88347f4);
  end

  // Reconstructed FDRE: esc_waddr_reg_5_a9127a4
  reg recovered_207_q = 1'b0;
  assign waddr[5] = recovered_207_q;
  wire recovered_207_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_207_reset || (((SR) === 1'bx) && (recovered_207_q == 1'b0))) recovered_207_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_207_q == (esc_waddr_5__i_1__1_n_0_5199fa7)))) recovered_207_q <= (esc_waddr_5__i_1__1_n_0_5199fa7);
  end

  // Reconstructed FDRE: esc_waddr_reg_6_07bbe0b
  reg recovered_208_q = 1'b0;
  assign waddr[6] = recovered_208_q;
  wire recovered_208_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_208_reset || (((SR) === 1'bx) && (recovered_208_q == 1'b0))) recovered_208_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_208_q == (esc_waddr_6__i_1__0_n_0_4a579a1)))) recovered_208_q <= (esc_waddr_6__i_1__0_n_0_4a579a1);
  end

  // Reconstructed FDRE: esc_waddr_reg_7_be3eb6c
  reg recovered_209_q = 1'b0;
  assign waddr[7] = recovered_209_q;
  wire recovered_209_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_209_reset || (((SR) === 1'bx) && (recovered_209_q == 1'b0))) recovered_209_q <= 1'b0;
    else if ((push) || ((push) === 1'bz) || (((push) === 1'bx) && (recovered_209_q == (esc_waddr_7__i_2__0_n_0_2b285d4)))) recovered_209_q <= (esc_waddr_7__i_2__0_n_0_2b285d4);
  end

endmodule

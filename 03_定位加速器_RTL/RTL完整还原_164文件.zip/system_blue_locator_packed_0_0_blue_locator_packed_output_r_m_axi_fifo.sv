// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_fifo
   (burst_valid,
    fifo_burst_ready,
    ap_rst_n_0,
    last_sect_buf,
    ap_rst_n_1,
    esc_bus_equal_gen_len_cnt_reg_4_8139ef8 ,
    wreq_handling_reg,
    next_wreq,
    D,
    esc_sect_len_buf_reg_7_99d7f4c ,
    in,
    wreq_handling_reg_0,
    esc_could_multi_bursts_last_sect_buf_reg_5fd9311 ,
    SR,
    ap_clk,
    ap_rst_n,
    CO,
    E,
    Q,
    push,
    esc_sect_cnt_reg_51_7c99099 ,
    sect_cnt0,
    esc_sect_cnt_reg_0_053187c ,
    wreq_handling_reg_1,
    wreq_handling_reg_2,
    wreq_handling_reg_3,
    fifo_wreq_valid,
    esc_sect_len_buf_reg_3_9899048 ,
    esc_sect_len_buf_reg_3__0_cb18dca ,
    esc_sect_len_buf_reg_3__1_e5dcb06 ,
    fifo_resp_ready,
    esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 ,
    esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f ,
    esc_could_multi_bursts_last_sect_buf_reg_0_4134d6e );
  output burst_valid;
  output fifo_burst_ready;
  output [0:0]ap_rst_n_0;
  output last_sect_buf;
  output [0:0]ap_rst_n_1;
  output esc_bus_equal_gen_len_cnt_reg_4_8139ef8 ;
  output [0:0]wreq_handling_reg;
  output next_wreq;
  output [51:0]D;
  output esc_sect_len_buf_reg_7_99d7f4c ;
  output [3:0]in;
  output wreq_handling_reg_0;
  output esc_could_multi_bursts_last_sect_buf_reg_5fd9311 ;
  input [0:0]SR;
  input ap_clk;
  input ap_rst_n;
  input [0:0]CO;
  input [0:0]E;
  input [7:0]Q;
  input push;
  input [51:0]esc_sect_cnt_reg_51_7c99099 ;
  input [50:0]sect_cnt0;
  input [0:0]esc_sect_cnt_reg_0_053187c ;
  input wreq_handling_reg_1;
  input [0:0]wreq_handling_reg_2;
  input wreq_handling_reg_3;
  input fifo_wreq_valid;
  input esc_sect_len_buf_reg_3_9899048 ;
  input esc_sect_len_buf_reg_3__0_cb18dca ;
  input esc_sect_len_buf_reg_3__1_e5dcb06 ;
  input fifo_resp_ready;
  input [9:0]esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 ;
  input [5:0]esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f ;
  input esc_could_multi_bursts_last_sect_buf_reg_0_4134d6e ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]CO;
  wire [51:0]D;
  wire [0:0]E;
  wire [7:0]Q;
  wire [0:0]SR;
  wire ap_clk;
  wire ap_rst_n;
  wire [0:0]ap_rst_n_0;
  wire [0:0]ap_rst_n_1;
  wire burst_valid;
  wire esc_bus_equal_gen_WLAST_Dummy_i_3_n_0_15cb439 ;
  wire esc_bus_equal_gen_len_cnt_reg_4_8139ef8 ;
  wire [9:0]esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 ;
  wire [5:0]esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f ;
  wire esc_could_multi_bursts_awlen_buf_3__i_3_n_0_e129f0f ;
  wire esc_could_multi_bursts_awlen_buf_3__i_4_n_0_8177d00 ;
  wire esc_could_multi_bursts_last_sect_buf_reg_5fd9311 ;
  wire esc_could_multi_bursts_last_sect_buf_reg_0_4134d6e ;
  wire data_vld_i_1__2_n_0;
  wire data_vld_reg_n_0;
  wire empty_n_i_1__5_n_0;
  wire fifo_burst_ready;
  wire fifo_resp_ready;
  wire fifo_wreq_valid;
  wire full_n_i_1__4_n_0;
  wire full_n_i_2__4_n_0;
  wire [3:0]in;
  wire last_sect_buf;
  wire esc_mem_reg_4__0__srl5_n_0_5b87500 ;
  wire esc_mem_reg_4__1__srl5_n_0_24313a5 ;
  wire esc_mem_reg_4__2__srl5_n_0_f2676c6 ;
  wire esc_mem_reg_4__3__srl5_n_0_2b51a08 ;
  wire next_wreq;
  wire esc_pout_0__i_1_n_0_c71edc2 ;
  wire esc_pout_1__i_1_n_0_77ba36c ;
  wire esc_pout_2__i_1_n_0_bcda194 ;
  wire esc_pout_reg_n_0__0_31a13ed ;
  wire esc_pout_reg_n_0__1_307d4bf ;
  wire esc_pout_reg_n_0__2_3685eef ;
  wire push;
  wire [3:0]q;
  wire [50:0]sect_cnt0;
  wire [0:0]esc_sect_cnt_reg_0_053187c ;
  wire [51:0]esc_sect_cnt_reg_51_7c99099 ;
  wire esc_sect_len_buf_9__i_3_n_0_7474ab3 ;
  wire esc_sect_len_buf_reg_3_9899048 ;
  wire esc_sect_len_buf_reg_3__0_cb18dca ;
  wire esc_sect_len_buf_reg_3__1_e5dcb06 ;
  wire esc_sect_len_buf_reg_7_99d7f4c ;
  wire [0:0]wreq_handling_reg;
  wire wreq_handling_reg_0;
  wire wreq_handling_reg_1;
  wire [0:0]wreq_handling_reg_2;
  wire wreq_handling_reg_3;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT5: esc_bus_equal_gen_WLAST_Dummy_i_2_070e146
  assign esc_bus_equal_gen_len_cnt_reg_4_8139ef8 = ((esc_bus_equal_gen_WLAST_Dummy_i_3_n_0_15cb439) ? (1'b1) : (((q[3]) ? (((Q[3]) ? (((Q[5]) ? (1'b1) : (Q[4]))) : (1'b1))) : (((Q[3]) ? (1'b1) : (((Q[5]) ? (1'b1) : (Q[4]))))))));

  // Reconstructed LUT6: esc_bus_equal_gen_WLAST_Dummy_i_3_2a36e92
  assign esc_bus_equal_gen_WLAST_Dummy_i_3_n_0_15cb439 = ((q[2]) ? (((Q[2]) ? (((q[1]) ? (((Q[1]) ? (((Q[0]) ? (~(q[0])) : (q[0]))) : (1'b1))) : (((Q[1]) ? (1'b1) : (((Q[0]) ? (~(q[0])) : (q[0]))))))) : (1'b1))) : (((Q[2]) ? (1'b1) : (((q[1]) ? (((Q[1]) ? (((Q[0]) ? (~(q[0])) : (q[0]))) : (1'b1))) : (((Q[1]) ? (1'b1) : (((Q[0]) ? (~(q[0])) : (q[0]))))))))));

  // Reconstructed LUT2: esc_could_multi_bursts_awlen_buf_0__i_1_6372a66
  assign in[0] = ((esc_sect_len_buf_reg_7_99d7f4c) ? (1'b1) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [0]));

  // Reconstructed LUT2: esc_could_multi_bursts_awlen_buf_1__i_1_58c4a10
  assign in[1] = ((esc_sect_len_buf_reg_7_99d7f4c) ? (1'b1) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [1]));

  // Reconstructed LUT2: esc_could_multi_bursts_awlen_buf_2__i_1_ab607f0
  assign in[2] = ((esc_sect_len_buf_reg_7_99d7f4c) ? (1'b1) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [2]));

  // Reconstructed LUT2: esc_could_multi_bursts_awlen_buf_3__i_1_90f5d14
  assign in[3] = ((esc_sect_len_buf_reg_7_99d7f4c) ? (1'b1) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [3]));

  // Reconstructed LUT2: esc_could_multi_bursts_awlen_buf_3__i_2_2abf531
  assign esc_sect_len_buf_reg_7_99d7f4c = ((esc_could_multi_bursts_awlen_buf_3__i_4_n_0_8177d00) ? (1'b1) : (esc_could_multi_bursts_awlen_buf_3__i_3_n_0_e129f0f));

  // Reconstructed LUT6: esc_could_multi_bursts_awlen_buf_3__i_3_00a0d89
  assign esc_could_multi_bursts_awlen_buf_3__i_3_n_0_e129f0f = ((esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [9]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [5]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [8]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [4]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [3]) ? (~(esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [7])) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [7]))) : (1'b1))) : (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [4]) ? (1'b1) : (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [3]) ? (~(esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [7])) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [7]))))))) : (1'b1))) : (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [5]) ? (1'b1) : (((esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [8]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [4]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [3]) ? (~(esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [7])) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [7]))) : (1'b1))) : (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [4]) ? (1'b1) : (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [3]) ? (~(esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [7])) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [7]))))))))));

  // Reconstructed LUT6: esc_could_multi_bursts_awlen_buf_3__i_4_4fb9d6d
  assign esc_could_multi_bursts_awlen_buf_3__i_4_n_0_8177d00 = ((esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [6]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [2]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [5]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [1]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [0]) ? (~(esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [4])) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [4]))) : (1'b1))) : (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [1]) ? (1'b1) : (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [0]) ? (~(esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [4])) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [4]))))))) : (1'b1))) : (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [2]) ? (1'b1) : (((esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [5]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [1]) ? (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [0]) ? (~(esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [4])) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [4]))) : (1'b1))) : (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [1]) ? (1'b1) : (((esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f [0]) ? (~(esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [4])) : (esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 [4]))))))))));

  // Reconstructed LUT3: esc_could_multi_bursts_last_sect_buf_i_1_3e39d45
  assign esc_could_multi_bursts_last_sect_buf_reg_5fd9311 = ((esc_could_multi_bursts_last_sect_buf_reg_0_4134d6e) ? (((last_sect_buf) ? (wreq_handling_reg_2) : (1'b1))) : (((last_sect_buf) ? (wreq_handling_reg_2) : (1'b0))));

  // Reconstructed LUT2: esc_could_multi_bursts_loop_cnt_5__i_1__0_f8dd546
  assign ap_rst_n_0 = ((ap_rst_n) ? (last_sect_buf) : (1'b1));

  // Reconstructed LUT6: data_vld_i_1__2
  assign data_vld_i_1__2_n_0 = ((data_vld_reg_n_0) ? (((empty_n_i_1__5_n_0) ? (((esc_pout_reg_n_0__2_3685eef) ? (1'b1) : (((esc_pout_reg_n_0__0_31a13ed) ? (1'b1) : (((esc_pout_reg_n_0__1_307d4bf) ? (1'b1) : (push))))))) : (1'b1))) : (push));

  // Reconstructed FDRE: data_vld_reg
  reg recovered_15_q = 1'b0;
  assign data_vld_reg_n_0 = recovered_15_q;
  wire recovered_15_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_15_reset || (((SR) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_15_q == (data_vld_i_1__2_n_0)))) recovered_15_q <= (data_vld_i_1__2_n_0);
  end

  // Reconstructed LUT5: empty_n_i_1__5
  assign empty_n_i_1__5_n_0 = ((burst_valid) ? (((esc_bus_equal_gen_len_cnt_reg_4_8139ef8) ? (1'b0) : (((Q[7]) ? (1'b0) : (((Q[6]) ? (1'b0) : (E))))))) : (1'b1));

  // Reconstructed FDRE: empty_n_reg
  reg recovered_17_q = 1'b0;
  assign burst_valid = recovered_17_q;
  wire recovered_17_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_17_reset || (((SR) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((empty_n_i_1__5_n_0) || ((empty_n_i_1__5_n_0) === 1'bz) || (((empty_n_i_1__5_n_0) === 1'bx) && (recovered_17_q == (data_vld_reg_n_0)))) recovered_17_q <= (data_vld_reg_n_0);
  end

  // Reconstructed LUT5: fifo_wreq_valid_buf_i_1
  assign next_wreq = ((fifo_wreq_valid) ? (((last_sect_buf) ? (((wreq_handling_reg_2) ? (1'b1) : (~(wreq_handling_reg_1)))) : (~(wreq_handling_reg_1)))) : (((wreq_handling_reg_3) ? (((last_sect_buf) ? (((wreq_handling_reg_2) ? (1'b1) : (~(wreq_handling_reg_1)))) : (~(wreq_handling_reg_1)))) : (1'b0))));

  // Reconstructed LUT6: full_n_i_1__4
  assign full_n_i_1__4_n_0 = ((data_vld_reg_n_0) ? (((empty_n_i_1__5_n_0) ? (1'b1) : (((push) ? (((full_n_i_2__4_n_0) ? (((fifo_burst_ready) ? (1'b1) : (~(ap_rst_n)))) : (~(ap_rst_n)))) : (((fifo_burst_ready) ? (1'b1) : (~(ap_rst_n)))))))) : (((fifo_burst_ready) ? (1'b1) : (~(ap_rst_n)))));

  // Reconstructed LUT3: full_n_i_2__4
  assign full_n_i_2__4_n_0 = ((esc_pout_reg_n_0__0_31a13ed) ? (((esc_pout_reg_n_0__1_307d4bf) ? (esc_pout_reg_n_0__2_3685eef) : (1'b1))) : (1'b1));

  // Reconstructed FDRE: full_n_reg
  reg recovered_21_q = 1'b0;
  assign fifo_burst_ready = recovered_21_q;
  wire recovered_21_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_21_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_21_q == (full_n_i_1__4_n_0)))) recovered_21_q <= (full_n_i_1__4_n_0);
  end

  // Reconstructed SRL16E: esc_mem_reg_4__0__srl5_fa37281
  reg [15:0] recovered_22_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_22_shift <= {recovered_22_shift[14:0],in[0]};
  assign esc_mem_reg_4__0__srl5_n_0_5b87500 = recovered_22_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__1__srl5_a1df094
  reg [15:0] recovered_23_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_23_shift <= {recovered_23_shift[14:0],in[1]};
  assign esc_mem_reg_4__1__srl5_n_0_24313a5 = recovered_23_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__2__srl5_4e9d0ad
  reg [15:0] recovered_24_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_24_shift <= {recovered_24_shift[14:0],in[2]};
  assign esc_mem_reg_4__2__srl5_n_0_f2676c6 = recovered_24_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__3__srl5_8321240
  reg [15:0] recovered_25_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_25_shift <= {recovered_25_shift[14:0],in[3]};
  assign esc_mem_reg_4__3__srl5_n_0_2b51a08 = recovered_25_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed LUT6: esc_pout_0__i_1_729e482
  assign esc_pout_0__i_1_n_0_c71edc2 = ((esc_pout_reg_n_0__0_31a13ed) ? (((push) ? (((data_vld_reg_n_0) ? (empty_n_i_1__5_n_0) : (1'b1))) : (((data_vld_reg_n_0) ? (~(empty_n_i_1__5_n_0)) : (1'b1))))) : (((push) ? (((data_vld_reg_n_0) ? (~(empty_n_i_1__5_n_0)) : (1'b0))) : (((data_vld_reg_n_0) ? (((empty_n_i_1__5_n_0) ? (((esc_pout_reg_n_0__2_3685eef) ? (1'b1) : (esc_pout_reg_n_0__1_307d4bf))) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT6: esc_pout_1__i_1_d213e77
  assign esc_pout_1__i_1_n_0_77ba36c = ((esc_pout_reg_n_0__1_307d4bf) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((empty_n_i_1__5_n_0) ? (1'b1) : (((data_vld_reg_n_0) ? (~(push)) : (1'b1))))) : (((empty_n_i_1__5_n_0) ? (((data_vld_reg_n_0) ? (push) : (1'b1))) : (1'b1))))) : (((esc_pout_reg_n_0__0_31a13ed) ? (((empty_n_i_1__5_n_0) ? (1'b0) : (((data_vld_reg_n_0) ? (push) : (1'b0))))) : (((esc_pout_reg_n_0__2_3685eef) ? (((empty_n_i_1__5_n_0) ? (((data_vld_reg_n_0) ? (~(push)) : (1'b0))) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT6: esc_pout_2__i_1_9909dbc
  assign esc_pout_2__i_1_n_0_bcda194 = ((esc_pout_reg_n_0__1_307d4bf) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((esc_pout_reg_n_0__2_3685eef) ? (((empty_n_i_1__5_n_0) ? (1'b1) : (((data_vld_reg_n_0) ? (~(push)) : (1'b1))))) : (((empty_n_i_1__5_n_0) ? (1'b0) : (((data_vld_reg_n_0) ? (push) : (1'b0))))))) : (esc_pout_reg_n_0__2_3685eef))) : (((esc_pout_reg_n_0__0_31a13ed) ? (esc_pout_reg_n_0__2_3685eef) : (((esc_pout_reg_n_0__2_3685eef) ? (((empty_n_i_1__5_n_0) ? (((data_vld_reg_n_0) ? (push) : (1'b1))) : (1'b1))) : (1'b0))))));

  // Reconstructed FDRE: esc_pout_reg_0_cd95a63
  reg recovered_29_q = 1'b0;
  assign esc_pout_reg_n_0__0_31a13ed = recovered_29_q;
  wire recovered_29_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_29_reset || (((SR) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_29_q == (esc_pout_0__i_1_n_0_c71edc2)))) recovered_29_q <= (esc_pout_0__i_1_n_0_c71edc2);
  end

  // Reconstructed FDRE: esc_pout_reg_1_325167f
  reg recovered_30_q = 1'b0;
  assign esc_pout_reg_n_0__1_307d4bf = recovered_30_q;
  wire recovered_30_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_30_reset || (((SR) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_30_q == (esc_pout_1__i_1_n_0_77ba36c)))) recovered_30_q <= (esc_pout_1__i_1_n_0_77ba36c);
  end

  // Reconstructed FDRE: esc_pout_reg_2_3108b14
  reg recovered_31_q = 1'b0;
  assign esc_pout_reg_n_0__2_3685eef = recovered_31_q;
  wire recovered_31_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_31_reset || (((SR) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_31_q == (esc_pout_2__i_1_n_0_bcda194)))) recovered_31_q <= (esc_pout_2__i_1_n_0_bcda194);
  end

  // Reconstructed FDRE: esc_q_reg_0_02a935c
  reg recovered_32_q = 1'b0;
  assign q[0] = recovered_32_q;
  wire recovered_32_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_32_reset || (((SR) === 1'bx) && (recovered_32_q == 1'b0))) recovered_32_q <= 1'b0;
    else if ((empty_n_i_1__5_n_0) || ((empty_n_i_1__5_n_0) === 1'bz) || (((empty_n_i_1__5_n_0) === 1'bx) && (recovered_32_q == (esc_mem_reg_4__0__srl5_n_0_5b87500)))) recovered_32_q <= (esc_mem_reg_4__0__srl5_n_0_5b87500);
  end

  // Reconstructed FDRE: esc_q_reg_1_2d13bdc
  reg recovered_33_q = 1'b0;
  assign q[1] = recovered_33_q;
  wire recovered_33_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_33_reset || (((SR) === 1'bx) && (recovered_33_q == 1'b0))) recovered_33_q <= 1'b0;
    else if ((empty_n_i_1__5_n_0) || ((empty_n_i_1__5_n_0) === 1'bz) || (((empty_n_i_1__5_n_0) === 1'bx) && (recovered_33_q == (esc_mem_reg_4__1__srl5_n_0_24313a5)))) recovered_33_q <= (esc_mem_reg_4__1__srl5_n_0_24313a5);
  end

  // Reconstructed FDRE: esc_q_reg_2_5a064fe
  reg recovered_34_q = 1'b0;
  assign q[2] = recovered_34_q;
  wire recovered_34_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_34_reset || (((SR) === 1'bx) && (recovered_34_q == 1'b0))) recovered_34_q <= 1'b0;
    else if ((empty_n_i_1__5_n_0) || ((empty_n_i_1__5_n_0) === 1'bz) || (((empty_n_i_1__5_n_0) === 1'bx) && (recovered_34_q == (esc_mem_reg_4__2__srl5_n_0_f2676c6)))) recovered_34_q <= (esc_mem_reg_4__2__srl5_n_0_f2676c6);
  end

  // Reconstructed FDRE: esc_q_reg_3_e0a3a92
  reg recovered_35_q = 1'b0;
  assign q[3] = recovered_35_q;
  wire recovered_35_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_35_reset || (((SR) === 1'bx) && (recovered_35_q == 1'b0))) recovered_35_q <= 1'b0;
    else if ((empty_n_i_1__5_n_0) || ((empty_n_i_1__5_n_0) === 1'bz) || (((empty_n_i_1__5_n_0) === 1'bx) && (recovered_35_q == (esc_mem_reg_4__3__srl5_n_0_2b51a08)))) recovered_35_q <= (esc_mem_reg_4__3__srl5_n_0_2b51a08);
  end

  // Reconstructed LUT3: esc_sect_addr_buf_11__i_1__0_aa664b4
  assign ap_rst_n_1 = ((ap_rst_n) ? (((last_sect_buf) ? (~(CO)) : (1'b0))) : (1'b1));

  // Reconstructed LUT3: esc_sect_cnt_0__i_1__0_e409fdd
  assign D[0] = ((esc_sect_cnt_reg_0_053187c) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [0]) : (1'b0))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [0]) : (1'b1))));

  // Reconstructed LUT3: esc_sect_cnt_10__i_1__0_c262894
  assign D[10] = ((sect_cnt0[9]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [10]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [10]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_11__i_1__0_1596b60
  assign D[11] = ((sect_cnt0[10]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [11]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [11]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_12__i_1__0_be981a6
  assign D[12] = ((sect_cnt0[11]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [12]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [12]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_13__i_1__0_4cf5032
  assign D[13] = ((sect_cnt0[12]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [13]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [13]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_14__i_1__0_13bdb6e
  assign D[14] = ((sect_cnt0[13]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [14]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [14]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_15__i_1__0_02a79de
  assign D[15] = ((sect_cnt0[14]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [15]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [15]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_16__i_1__0_1c27d6e
  assign D[16] = ((sect_cnt0[15]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [16]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [16]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_17__i_1__0_1106464
  assign D[17] = ((sect_cnt0[16]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [17]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [17]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_18__i_1__0_e955c54
  assign D[18] = ((sect_cnt0[17]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [18]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [18]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_19__i_1__0_ead1a35
  assign D[19] = ((sect_cnt0[18]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [19]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [19]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_1__i_1__0_dd18116
  assign D[1] = ((sect_cnt0[0]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [1]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [1]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_20__i_1__0_334f79e
  assign D[20] = ((sect_cnt0[19]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [20]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [20]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_21__i_1__0_99f2a60
  assign D[21] = ((sect_cnt0[20]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [21]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [21]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_22__i_1__0_539f49d
  assign D[22] = ((sect_cnt0[21]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [22]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [22]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_23__i_1__0_9133a85
  assign D[23] = ((sect_cnt0[22]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [23]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [23]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_24__i_1__0_3d44499
  assign D[24] = ((sect_cnt0[23]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [24]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [24]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_25__i_1__0_a6e839c
  assign D[25] = ((sect_cnt0[24]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [25]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [25]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_26__i_1__0_6745edd
  assign D[26] = ((sect_cnt0[25]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [26]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [26]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_27__i_1__0_6079a73
  assign D[27] = ((sect_cnt0[26]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [27]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [27]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_28__i_1__0_47bd97f
  assign D[28] = ((sect_cnt0[27]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [28]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [28]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_29__i_1__0_734234a
  assign D[29] = ((sect_cnt0[28]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [29]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [29]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_2__i_1__0_90a3291
  assign D[2] = ((sect_cnt0[1]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [2]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [2]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_30__i_1__0_ad2b323
  assign D[30] = ((sect_cnt0[29]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [30]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [30]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_31__i_1__0_40aa9c7
  assign D[31] = ((sect_cnt0[30]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [31]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [31]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_32__i_1__0_bf87d7e
  assign D[32] = ((sect_cnt0[31]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [32]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [32]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_33__i_1__0_9215d63
  assign D[33] = ((sect_cnt0[32]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [33]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [33]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_34__i_1__0_4652c18
  assign D[34] = ((sect_cnt0[33]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [34]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [34]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_35__i_1__0_a14921c
  assign D[35] = ((sect_cnt0[34]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [35]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [35]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_36__i_1__0_058d51e
  assign D[36] = ((sect_cnt0[35]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [36]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [36]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_37__i_1__0_59f55a0
  assign D[37] = ((sect_cnt0[36]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [37]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [37]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_38__i_1__0_f206f61
  assign D[38] = ((sect_cnt0[37]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [38]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [38]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_39__i_1__0_ef7fafb
  assign D[39] = ((sect_cnt0[38]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [39]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [39]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_3__i_1__0_ae67f6e
  assign D[3] = ((sect_cnt0[2]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [3]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [3]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_40__i_1__0_03e67d2
  assign D[40] = ((sect_cnt0[39]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [40]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [40]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_41__i_1__0_d84be54
  assign D[41] = ((sect_cnt0[40]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [41]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [41]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_42__i_1__0_2ef5119
  assign D[42] = ((sect_cnt0[41]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [42]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [42]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_43__i_1__0_bf9c37e
  assign D[43] = ((sect_cnt0[42]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [43]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [43]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_44__i_1__0_fe384b6
  assign D[44] = ((sect_cnt0[43]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [44]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [44]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_45__i_1__0_d65964a
  assign D[45] = ((sect_cnt0[44]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [45]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [45]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_46__i_1__0_366a127
  assign D[46] = ((sect_cnt0[45]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [46]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [46]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_47__i_1__0_7808d49
  assign D[47] = ((sect_cnt0[46]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [47]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [47]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_48__i_1__0_3017c80
  assign D[48] = ((sect_cnt0[47]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [48]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [48]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_49__i_1__0_95991c9
  assign D[49] = ((sect_cnt0[48]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [49]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [49]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_4__i_1__0_fb0af93
  assign D[4] = ((sect_cnt0[3]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [4]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [4]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_50__i_1__0_cdac2e6
  assign D[50] = ((sect_cnt0[49]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [50]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [50]) : (1'b0))));

  // Reconstructed LUT2: esc_sect_cnt_51__i_1__0_8b16549
  assign wreq_handling_reg = ((next_wreq) ? (1'b1) : (last_sect_buf));

  // Reconstructed LUT3: esc_sect_cnt_51__i_2__0_28dd2dc
  assign D[51] = ((sect_cnt0[50]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [51]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [51]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_5__i_1__0_063dfbe
  assign D[5] = ((sect_cnt0[4]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [5]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [5]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_6__i_1__0_e8df3eb
  assign D[6] = ((sect_cnt0[5]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [6]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [6]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_7__i_1__0_330073e
  assign D[7] = ((sect_cnt0[6]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [7]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [7]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_8__i_1__0_170f30e
  assign D[8] = ((sect_cnt0[7]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [8]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [8]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_cnt_9__i_1__0_199c4f5
  assign D[9] = ((sect_cnt0[8]) ? (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [9]) : (1'b1))) : (((next_wreq) ? (esc_sect_cnt_reg_51_7c99099 [9]) : (1'b0))));

  // Reconstructed LUT6: esc_sect_len_buf_9__i_1_c9c74cc
  assign last_sect_buf = ((esc_sect_len_buf_reg_3__1_e5dcb06) ? (((esc_sect_len_buf_reg_7_99d7f4c) ? (1'b0) : (((esc_sect_len_buf_reg_3__0_cb18dca) ? (((esc_sect_len_buf_reg_3_9899048) ? (((esc_sect_len_buf_9__i_3_n_0_7474ab3) ? (1'b0) : (wreq_handling_reg_1))) : (1'b0))) : (((esc_sect_len_buf_9__i_3_n_0_7474ab3) ? (1'b0) : (wreq_handling_reg_1))))))) : (wreq_handling_reg_1));

  // Reconstructed LUT3: esc_sect_len_buf_9__i_3_32d2060
  assign esc_sect_len_buf_9__i_3_n_0_7474ab3 = ((fifo_resp_ready) ? (((esc_sect_len_buf_reg_3__1_e5dcb06) ? (~(fifo_burst_ready)) : (1'b1))) : (1'b1));

  // Reconstructed LUT4: wreq_handling_i_1
  assign wreq_handling_reg_0 = ((last_sect_buf) ? (((wreq_handling_reg_2) ? (wreq_handling_reg_3) : (((wreq_handling_reg_3) ? (1'b1) : (wreq_handling_reg_1))))) : (((wreq_handling_reg_3) ? (1'b1) : (wreq_handling_reg_1))));

endmodule

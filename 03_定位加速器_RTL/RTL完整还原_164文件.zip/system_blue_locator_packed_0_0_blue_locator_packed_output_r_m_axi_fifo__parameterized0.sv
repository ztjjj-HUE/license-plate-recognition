// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_fifo__parameterized0
   (fifo_wreq_valid,
    rs2f_wreq_ack,
    S,
    empty_n_reg_0,
    esc_q_reg_67__0_7bacafd ,
    E,
    empty_n_reg_1,
    esc_q_reg_67__1_0bf6791 ,
    SR,
    ap_clk,
    Q,
    last_sect_carry__3,
    last_sect_buf,
    esc_q_reg_0__0_4378569 ,
    esc_q_reg_0__1_c6877f4 ,
    ap_rst_n,
    esc_pout_reg_1__0_e33da39 ,
    esc_q_reg_61__0_805b7b0 );
  output fifo_wreq_valid;
  output rs2f_wreq_ack;
  output [1:0]S;
  output [0:0]empty_n_reg_0;
  output [62:0]esc_q_reg_67__0_7bacafd ;
  output [0:0]E;
  output empty_n_reg_1;
  output [0:0]esc_q_reg_67__1_0bf6791 ;
  input [0:0]SR;
  input ap_clk;
  input [3:0]Q;
  input [3:0]last_sect_carry__3;
  input last_sect_buf;
  input [0:0]esc_q_reg_0__0_4378569 ;
  input esc_q_reg_0__1_c6877f4 ;
  input ap_rst_n;
  input [0:0]esc_pout_reg_1__0_e33da39 ;
  input [61:0]esc_q_reg_61__0_805b7b0 ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]E;
  wire [3:0]Q;
  wire [1:0]S;
  wire [0:0]SR;
  wire ap_clk;
  wire ap_rst_n;
  wire data_vld_i_1__3_n_0;
  wire data_vld_reg_n_0;
  wire [0:0]empty_n_reg_0;
  wire empty_n_reg_1;
  wire fifo_wreq_valid;
  wire full_n_i_1__6_n_0;
  wire full_n_i_2__5_n_0;
  wire last_sect_buf;
  wire [3:0]last_sect_carry__3;
  wire esc_mem_reg_4__0__srl5_n_0_5b87500 ;
  wire esc_mem_reg_4__10__srl5_n_0_e247105 ;
  wire esc_mem_reg_4__11__srl5_n_0_27bf80c ;
  wire esc_mem_reg_4__12__srl5_n_0_997a3d0 ;
  wire esc_mem_reg_4__13__srl5_n_0_c14c677 ;
  wire esc_mem_reg_4__14__srl5_n_0_b5761f7 ;
  wire esc_mem_reg_4__15__srl5_n_0_76b0ea7 ;
  wire esc_mem_reg_4__16__srl5_n_0_3ede415 ;
  wire esc_mem_reg_4__17__srl5_n_0_223dae8 ;
  wire esc_mem_reg_4__18__srl5_n_0_0039e45 ;
  wire esc_mem_reg_4__19__srl5_n_0_b3b8abd ;
  wire esc_mem_reg_4__1__srl5_n_0_24313a5 ;
  wire esc_mem_reg_4__20__srl5_n_0_a7cb185 ;
  wire esc_mem_reg_4__21__srl5_n_0_1133f48 ;
  wire esc_mem_reg_4__22__srl5_n_0_9fdb6b1 ;
  wire esc_mem_reg_4__23__srl5_n_0_d387627 ;
  wire esc_mem_reg_4__24__srl5_n_0_113f629 ;
  wire esc_mem_reg_4__25__srl5_n_0_c2ea529 ;
  wire esc_mem_reg_4__26__srl5_n_0_58cac40 ;
  wire esc_mem_reg_4__27__srl5_n_0_724e83a ;
  wire esc_mem_reg_4__28__srl5_n_0_b25f46a ;
  wire esc_mem_reg_4__29__srl5_n_0_56756af ;
  wire esc_mem_reg_4__2__srl5_n_0_f2676c6 ;
  wire esc_mem_reg_4__30__srl5_n_0_2b5eac6 ;
  wire esc_mem_reg_4__31__srl5_n_0_163765c ;
  wire esc_mem_reg_4__32__srl5_n_0_7f3a683 ;
  wire esc_mem_reg_4__33__srl5_n_0_c4d4bcb ;
  wire esc_mem_reg_4__34__srl5_n_0_e917cf0 ;
  wire esc_mem_reg_4__35__srl5_n_0_d7054c7 ;
  wire esc_mem_reg_4__36__srl5_n_0_8180ba4 ;
  wire esc_mem_reg_4__37__srl5_n_0_e31fe08 ;
  wire esc_mem_reg_4__38__srl5_n_0_15d7c61 ;
  wire esc_mem_reg_4__39__srl5_n_0_aed7ba4 ;
  wire esc_mem_reg_4__3__srl5_n_0_2b51a08 ;
  wire esc_mem_reg_4__40__srl5_n_0_8d2fc8b ;
  wire esc_mem_reg_4__41__srl5_n_0_43f2c18 ;
  wire esc_mem_reg_4__42__srl5_n_0_5068a2c ;
  wire esc_mem_reg_4__43__srl5_n_0_2ccfd64 ;
  wire esc_mem_reg_4__44__srl5_n_0_81605ce ;
  wire esc_mem_reg_4__45__srl5_n_0_ca3fe15 ;
  wire esc_mem_reg_4__46__srl5_n_0_d1bde41 ;
  wire esc_mem_reg_4__47__srl5_n_0_812a5e0 ;
  wire esc_mem_reg_4__48__srl5_n_0_15ce78c ;
  wire esc_mem_reg_4__49__srl5_n_0_879ca8b ;
  wire esc_mem_reg_4__4__srl5_n_0_9ac6433 ;
  wire esc_mem_reg_4__50__srl5_n_0_1085b2a ;
  wire esc_mem_reg_4__51__srl5_n_0_074a965 ;
  wire esc_mem_reg_4__52__srl5_n_0_1c3bad9 ;
  wire esc_mem_reg_4__53__srl5_n_0_10fdae5 ;
  wire esc_mem_reg_4__54__srl5_n_0_d87cca8 ;
  wire esc_mem_reg_4__55__srl5_n_0_f34d6be ;
  wire esc_mem_reg_4__56__srl5_n_0_ff79cb7 ;
  wire esc_mem_reg_4__57__srl5_n_0_6945ac8 ;
  wire esc_mem_reg_4__58__srl5_n_0_0ceb6fa ;
  wire esc_mem_reg_4__59__srl5_n_0_818a395 ;
  wire esc_mem_reg_4__5__srl5_n_0_843e618 ;
  wire esc_mem_reg_4__60__srl5_n_0_783d111 ;
  wire esc_mem_reg_4__61__srl5_n_0_7362482 ;
  wire esc_mem_reg_4__67__srl5_n_0_b6c00a7 ;
  wire esc_mem_reg_4__6__srl5_n_0_b2b44f9 ;
  wire esc_mem_reg_4__7__srl5_n_0_c57737b ;
  wire esc_mem_reg_4__8__srl5_n_0_2bf3955 ;
  wire esc_mem_reg_4__9__srl5_n_0_bab496c ;
  wire pop0;
  wire esc_pout_0__i_1_n_0_c71edc2 ;
  wire esc_pout_0__i_2_n_0_965276f ;
  wire esc_pout_1__i_1_n_0_77ba36c ;
  wire esc_pout_1__i_2_n_0_544f363 ;
  wire esc_pout_1__i_3_n_0_903af15 ;
  wire esc_pout_2__i_1_n_0_bcda194 ;
  wire esc_pout_2__i_2_n_0_8e0ffbe ;
  wire esc_pout_2__i_3_n_0_c02873e ;
  wire esc_pout_2__i_4_n_0_46213eb ;
  wire [0:0]esc_pout_reg_1__0_e33da39 ;
  wire esc_pout_reg_n_0__0_31a13ed ;
  wire esc_pout_reg_n_0__1_307d4bf ;
  wire esc_pout_reg_n_0__2_3685eef ;
  wire push;
  wire [0:0]esc_q_reg_0__0_4378569 ;
  wire esc_q_reg_0__1_c6877f4 ;
  wire [61:0]esc_q_reg_61__0_805b7b0 ;
  wire [62:0]esc_q_reg_67__0_7bacafd ;
  wire [0:0]esc_q_reg_67__1_0bf6791 ;
  wire rs2f_wreq_ack;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_align_len_31__i_1__0_00f21c1
  assign empty_n_reg_0 = ((ap_rst_n) ? (((esc_q_reg_67__0_7bacafd [62]) ? (1'b0) : (((esc_q_reg_0__1_c6877f4) ? (((esc_q_reg_0__0_4378569) ? (((last_sect_buf) ? (fifo_wreq_valid) : (1'b0))) : (1'b0))) : (fifo_wreq_valid))))) : (1'b1));

  // Reconstructed LUT4: esc_align_len_31__i_2_dcb8bbb
  assign E = ((esc_q_reg_0__1_c6877f4) ? (((esc_q_reg_0__0_4378569) ? (((last_sect_buf) ? (fifo_wreq_valid) : (1'b0))) : (1'b0))) : (fifo_wreq_valid));

  // Reconstructed LUT6: data_vld_i_1__3
  assign data_vld_i_1__3_n_0 = ((data_vld_reg_n_0) ? (((esc_pout_1__i_3_n_0_903af15) ? (((esc_pout_reg_n_0__2_3685eef) ? (1'b1) : (((esc_pout_reg_n_0__0_31a13ed) ? (1'b1) : (((esc_pout_reg_n_0__1_307d4bf) ? (1'b1) : (push))))))) : (1'b1))) : (push));

  // Reconstructed FDRE: data_vld_reg
  reg recovered_6_q = 1'b0;
  assign data_vld_reg_n_0 = recovered_6_q;
  wire recovered_6_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_6_reset || (((SR) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (data_vld_i_1__3_n_0)))) recovered_6_q <= (data_vld_i_1__3_n_0);
  end

  // Reconstructed LUT4: empty_n_i_1__2
  assign pop0 = ((esc_q_reg_0__1_c6877f4) ? (((esc_q_reg_0__0_4378569) ? (((last_sect_buf) ? (1'b1) : (~(fifo_wreq_valid)))) : (~(fifo_wreq_valid)))) : (1'b1));

  // Reconstructed FDRE: empty_n_reg
  reg recovered_8_q = 1'b0;
  assign fifo_wreq_valid = recovered_8_q;
  wire recovered_8_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_8_reset || (((SR) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_8_q == (data_vld_reg_n_0)))) recovered_8_q <= (data_vld_reg_n_0);
  end

  // Reconstructed LUT6: full_n_i_1__6
  assign full_n_i_1__6_n_0 = ((esc_pout_2__i_3_n_0_c02873e) ? (((full_n_i_2__5_n_0) ? (((esc_pout_reg_n_0__2_3685eef) ? (((rs2f_wreq_ack) ? (1'b1) : (((ap_rst_n) ? (esc_pout_1__i_3_n_0_903af15) : (1'b1))))) : (((ap_rst_n) ? (esc_pout_1__i_3_n_0_903af15) : (1'b1))))) : (((rs2f_wreq_ack) ? (1'b1) : (((ap_rst_n) ? (esc_pout_1__i_3_n_0_903af15) : (1'b1))))))) : (((rs2f_wreq_ack) ? (1'b1) : (((ap_rst_n) ? (esc_pout_1__i_3_n_0_903af15) : (1'b1))))));

  // Reconstructed LUT2: full_n_i_2__5
  assign full_n_i_2__5_n_0 = ((esc_pout_reg_n_0__1_307d4bf) ? (esc_pout_reg_n_0__0_31a13ed) : (1'b0));

  // Reconstructed FDRE: full_n_reg
  reg recovered_11_q = 1'b0;
  assign rs2f_wreq_ack = recovered_11_q;
  wire recovered_11_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_11_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_11_q == (full_n_i_1__6_n_0)))) recovered_11_q <= (full_n_i_1__6_n_0);
  end

  // Reconstructed LUT1: i__carry_i_1
  assign esc_q_reg_67__1_0bf6791 = ~(esc_q_reg_67__0_7bacafd [62]);

  // Reconstructed LUT2: invalid_len_event_i_1__0
  assign empty_n_reg_1 = ((esc_q_reg_67__0_7bacafd [62]) ? (1'b0) : (fifo_wreq_valid));

  // Reconstructed LUT2: last_sect_carry__3_i_1__0
  assign S[1] = ((last_sect_carry__3[3]) ? (Q[3]) : (~(Q[3])));

  // Reconstructed LUT6: last_sect_carry__3_i_2__0
  assign S[0] = ((Q[1]) ? (((last_sect_carry__3[1]) ? (((Q[0]) ? (((last_sect_carry__3[0]) ? (((last_sect_carry__3[2]) ? (Q[2]) : (~(Q[2])))) : (1'b0))) : (((last_sect_carry__3[0]) ? (1'b0) : (((last_sect_carry__3[2]) ? (Q[2]) : (~(Q[2])))))))) : (1'b0))) : (((last_sect_carry__3[1]) ? (1'b0) : (((Q[0]) ? (((last_sect_carry__3[0]) ? (((last_sect_carry__3[2]) ? (Q[2]) : (~(Q[2])))) : (1'b0))) : (((last_sect_carry__3[0]) ? (1'b0) : (((last_sect_carry__3[2]) ? (Q[2]) : (~(Q[2])))))))))));

  // Reconstructed SRL16E: esc_mem_reg_4__0__srl5_fa37281
  reg [15:0] recovered_16_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_16_shift <= {recovered_16_shift[14:0],esc_q_reg_61__0_805b7b0 [0]};
  assign esc_mem_reg_4__0__srl5_n_0_5b87500 = recovered_16_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed LUT2: esc_mem_reg_4__0__srl5_i_1__2_9459c36
  assign push = ((esc_pout_reg_1__0_e33da39) ? (rs2f_wreq_ack) : (1'b0));

  // Reconstructed SRL16E: esc_mem_reg_4__10__srl5_1f8e5dd
  reg [15:0] recovered_18_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_18_shift <= {recovered_18_shift[14:0],esc_q_reg_61__0_805b7b0 [10]};
  assign esc_mem_reg_4__10__srl5_n_0_e247105 = recovered_18_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__11__srl5_c193b80
  reg [15:0] recovered_19_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_19_shift <= {recovered_19_shift[14:0],esc_q_reg_61__0_805b7b0 [11]};
  assign esc_mem_reg_4__11__srl5_n_0_27bf80c = recovered_19_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__12__srl5_c86ecf1
  reg [15:0] recovered_20_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_20_shift <= {recovered_20_shift[14:0],esc_q_reg_61__0_805b7b0 [12]};
  assign esc_mem_reg_4__12__srl5_n_0_997a3d0 = recovered_20_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__13__srl5_9391e2f
  reg [15:0] recovered_21_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_21_shift <= {recovered_21_shift[14:0],esc_q_reg_61__0_805b7b0 [13]};
  assign esc_mem_reg_4__13__srl5_n_0_c14c677 = recovered_21_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__14__srl5_fb3e32d
  reg [15:0] recovered_22_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_22_shift <= {recovered_22_shift[14:0],esc_q_reg_61__0_805b7b0 [14]};
  assign esc_mem_reg_4__14__srl5_n_0_b5761f7 = recovered_22_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__15__srl5_fefac9b
  reg [15:0] recovered_23_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_23_shift <= {recovered_23_shift[14:0],esc_q_reg_61__0_805b7b0 [15]};
  assign esc_mem_reg_4__15__srl5_n_0_76b0ea7 = recovered_23_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__16__srl5_a608e6a
  reg [15:0] recovered_24_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_24_shift <= {recovered_24_shift[14:0],esc_q_reg_61__0_805b7b0 [16]};
  assign esc_mem_reg_4__16__srl5_n_0_3ede415 = recovered_24_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__17__srl5_f26e2f6
  reg [15:0] recovered_25_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_25_shift <= {recovered_25_shift[14:0],esc_q_reg_61__0_805b7b0 [17]};
  assign esc_mem_reg_4__17__srl5_n_0_223dae8 = recovered_25_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__18__srl5_4c5170b
  reg [15:0] recovered_26_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_26_shift <= {recovered_26_shift[14:0],esc_q_reg_61__0_805b7b0 [18]};
  assign esc_mem_reg_4__18__srl5_n_0_0039e45 = recovered_26_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__19__srl5_d074f81
  reg [15:0] recovered_27_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_27_shift <= {recovered_27_shift[14:0],esc_q_reg_61__0_805b7b0 [19]};
  assign esc_mem_reg_4__19__srl5_n_0_b3b8abd = recovered_27_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__1__srl5_a1df094
  reg [15:0] recovered_28_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_28_shift <= {recovered_28_shift[14:0],esc_q_reg_61__0_805b7b0 [1]};
  assign esc_mem_reg_4__1__srl5_n_0_24313a5 = recovered_28_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__20__srl5_5e430ee
  reg [15:0] recovered_29_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_29_shift <= {recovered_29_shift[14:0],esc_q_reg_61__0_805b7b0 [20]};
  assign esc_mem_reg_4__20__srl5_n_0_a7cb185 = recovered_29_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__21__srl5_a7fe488
  reg [15:0] recovered_30_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_30_shift <= {recovered_30_shift[14:0],esc_q_reg_61__0_805b7b0 [21]};
  assign esc_mem_reg_4__21__srl5_n_0_1133f48 = recovered_30_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__22__srl5_9662068
  reg [15:0] recovered_31_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_31_shift <= {recovered_31_shift[14:0],esc_q_reg_61__0_805b7b0 [22]};
  assign esc_mem_reg_4__22__srl5_n_0_9fdb6b1 = recovered_31_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__23__srl5_de85f0c
  reg [15:0] recovered_32_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_32_shift <= {recovered_32_shift[14:0],esc_q_reg_61__0_805b7b0 [23]};
  assign esc_mem_reg_4__23__srl5_n_0_d387627 = recovered_32_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__24__srl5_ccf8771
  reg [15:0] recovered_33_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_33_shift <= {recovered_33_shift[14:0],esc_q_reg_61__0_805b7b0 [24]};
  assign esc_mem_reg_4__24__srl5_n_0_113f629 = recovered_33_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__25__srl5_1be6e34
  reg [15:0] recovered_34_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_34_shift <= {recovered_34_shift[14:0],esc_q_reg_61__0_805b7b0 [25]};
  assign esc_mem_reg_4__25__srl5_n_0_c2ea529 = recovered_34_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__26__srl5_a8d2dd2
  reg [15:0] recovered_35_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_35_shift <= {recovered_35_shift[14:0],esc_q_reg_61__0_805b7b0 [26]};
  assign esc_mem_reg_4__26__srl5_n_0_58cac40 = recovered_35_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__27__srl5_64f0d4b
  reg [15:0] recovered_36_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_36_shift <= {recovered_36_shift[14:0],esc_q_reg_61__0_805b7b0 [27]};
  assign esc_mem_reg_4__27__srl5_n_0_724e83a = recovered_36_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__28__srl5_929699a
  reg [15:0] recovered_37_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_37_shift <= {recovered_37_shift[14:0],esc_q_reg_61__0_805b7b0 [28]};
  assign esc_mem_reg_4__28__srl5_n_0_b25f46a = recovered_37_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__29__srl5_da0de23
  reg [15:0] recovered_38_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_38_shift <= {recovered_38_shift[14:0],esc_q_reg_61__0_805b7b0 [29]};
  assign esc_mem_reg_4__29__srl5_n_0_56756af = recovered_38_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__2__srl5_4e9d0ad
  reg [15:0] recovered_39_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_39_shift <= {recovered_39_shift[14:0],esc_q_reg_61__0_805b7b0 [2]};
  assign esc_mem_reg_4__2__srl5_n_0_f2676c6 = recovered_39_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__30__srl5_3848602
  reg [15:0] recovered_40_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_40_shift <= {recovered_40_shift[14:0],esc_q_reg_61__0_805b7b0 [30]};
  assign esc_mem_reg_4__30__srl5_n_0_2b5eac6 = recovered_40_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__31__srl5_87ad1a5
  reg [15:0] recovered_41_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_41_shift <= {recovered_41_shift[14:0],esc_q_reg_61__0_805b7b0 [31]};
  assign esc_mem_reg_4__31__srl5_n_0_163765c = recovered_41_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__32__srl5_0c7b907
  reg [15:0] recovered_42_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_42_shift <= {recovered_42_shift[14:0],esc_q_reg_61__0_805b7b0 [32]};
  assign esc_mem_reg_4__32__srl5_n_0_7f3a683 = recovered_42_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__33__srl5_61c4ecd
  reg [15:0] recovered_43_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_43_shift <= {recovered_43_shift[14:0],esc_q_reg_61__0_805b7b0 [33]};
  assign esc_mem_reg_4__33__srl5_n_0_c4d4bcb = recovered_43_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__34__srl5_7762b87
  reg [15:0] recovered_44_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_44_shift <= {recovered_44_shift[14:0],esc_q_reg_61__0_805b7b0 [34]};
  assign esc_mem_reg_4__34__srl5_n_0_e917cf0 = recovered_44_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__35__srl5_888eace
  reg [15:0] recovered_45_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_45_shift <= {recovered_45_shift[14:0],esc_q_reg_61__0_805b7b0 [35]};
  assign esc_mem_reg_4__35__srl5_n_0_d7054c7 = recovered_45_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__36__srl5_3f1efb9
  reg [15:0] recovered_46_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_46_shift <= {recovered_46_shift[14:0],esc_q_reg_61__0_805b7b0 [36]};
  assign esc_mem_reg_4__36__srl5_n_0_8180ba4 = recovered_46_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__37__srl5_76d2ff9
  reg [15:0] recovered_47_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_47_shift <= {recovered_47_shift[14:0],esc_q_reg_61__0_805b7b0 [37]};
  assign esc_mem_reg_4__37__srl5_n_0_e31fe08 = recovered_47_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__38__srl5_7d7f232
  reg [15:0] recovered_48_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_48_shift <= {recovered_48_shift[14:0],esc_q_reg_61__0_805b7b0 [38]};
  assign esc_mem_reg_4__38__srl5_n_0_15d7c61 = recovered_48_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__39__srl5_fb392c1
  reg [15:0] recovered_49_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_49_shift <= {recovered_49_shift[14:0],esc_q_reg_61__0_805b7b0 [39]};
  assign esc_mem_reg_4__39__srl5_n_0_aed7ba4 = recovered_49_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__3__srl5_8321240
  reg [15:0] recovered_50_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_50_shift <= {recovered_50_shift[14:0],esc_q_reg_61__0_805b7b0 [3]};
  assign esc_mem_reg_4__3__srl5_n_0_2b51a08 = recovered_50_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__40__srl5_1c69807
  reg [15:0] recovered_51_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_51_shift <= {recovered_51_shift[14:0],esc_q_reg_61__0_805b7b0 [40]};
  assign esc_mem_reg_4__40__srl5_n_0_8d2fc8b = recovered_51_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__41__srl5_ff76a4b
  reg [15:0] recovered_52_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_52_shift <= {recovered_52_shift[14:0],esc_q_reg_61__0_805b7b0 [41]};
  assign esc_mem_reg_4__41__srl5_n_0_43f2c18 = recovered_52_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__42__srl5_210cc13
  reg [15:0] recovered_53_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_53_shift <= {recovered_53_shift[14:0],esc_q_reg_61__0_805b7b0 [42]};
  assign esc_mem_reg_4__42__srl5_n_0_5068a2c = recovered_53_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__43__srl5_f733580
  reg [15:0] recovered_54_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_54_shift <= {recovered_54_shift[14:0],esc_q_reg_61__0_805b7b0 [43]};
  assign esc_mem_reg_4__43__srl5_n_0_2ccfd64 = recovered_54_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__44__srl5_f55536e
  reg [15:0] recovered_55_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_55_shift <= {recovered_55_shift[14:0],esc_q_reg_61__0_805b7b0 [44]};
  assign esc_mem_reg_4__44__srl5_n_0_81605ce = recovered_55_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__45__srl5_1c2c42c
  reg [15:0] recovered_56_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_56_shift <= {recovered_56_shift[14:0],esc_q_reg_61__0_805b7b0 [45]};
  assign esc_mem_reg_4__45__srl5_n_0_ca3fe15 = recovered_56_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__46__srl5_d1ae599
  reg [15:0] recovered_57_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_57_shift <= {recovered_57_shift[14:0],esc_q_reg_61__0_805b7b0 [46]};
  assign esc_mem_reg_4__46__srl5_n_0_d1bde41 = recovered_57_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__47__srl5_9f168bd
  reg [15:0] recovered_58_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_58_shift <= {recovered_58_shift[14:0],esc_q_reg_61__0_805b7b0 [47]};
  assign esc_mem_reg_4__47__srl5_n_0_812a5e0 = recovered_58_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__48__srl5_5976007
  reg [15:0] recovered_59_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_59_shift <= {recovered_59_shift[14:0],esc_q_reg_61__0_805b7b0 [48]};
  assign esc_mem_reg_4__48__srl5_n_0_15ce78c = recovered_59_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__49__srl5_7b88999
  reg [15:0] recovered_60_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_60_shift <= {recovered_60_shift[14:0],esc_q_reg_61__0_805b7b0 [49]};
  assign esc_mem_reg_4__49__srl5_n_0_879ca8b = recovered_60_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__4__srl5_21c51a5
  reg [15:0] recovered_61_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_61_shift <= {recovered_61_shift[14:0],esc_q_reg_61__0_805b7b0 [4]};
  assign esc_mem_reg_4__4__srl5_n_0_9ac6433 = recovered_61_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__50__srl5_1fdc800
  reg [15:0] recovered_62_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_62_shift <= {recovered_62_shift[14:0],esc_q_reg_61__0_805b7b0 [50]};
  assign esc_mem_reg_4__50__srl5_n_0_1085b2a = recovered_62_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__51__srl5_155679b
  reg [15:0] recovered_63_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_63_shift <= {recovered_63_shift[14:0],esc_q_reg_61__0_805b7b0 [51]};
  assign esc_mem_reg_4__51__srl5_n_0_074a965 = recovered_63_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__52__srl5_3763c35
  reg [15:0] recovered_64_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_64_shift <= {recovered_64_shift[14:0],esc_q_reg_61__0_805b7b0 [52]};
  assign esc_mem_reg_4__52__srl5_n_0_1c3bad9 = recovered_64_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__53__srl5_140b83d
  reg [15:0] recovered_65_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_65_shift <= {recovered_65_shift[14:0],esc_q_reg_61__0_805b7b0 [53]};
  assign esc_mem_reg_4__53__srl5_n_0_10fdae5 = recovered_65_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__54__srl5_e85f7cf
  reg [15:0] recovered_66_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_66_shift <= {recovered_66_shift[14:0],esc_q_reg_61__0_805b7b0 [54]};
  assign esc_mem_reg_4__54__srl5_n_0_d87cca8 = recovered_66_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__55__srl5_7ed984a
  reg [15:0] recovered_67_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_67_shift <= {recovered_67_shift[14:0],esc_q_reg_61__0_805b7b0 [55]};
  assign esc_mem_reg_4__55__srl5_n_0_f34d6be = recovered_67_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__56__srl5_414fa77
  reg [15:0] recovered_68_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_68_shift <= {recovered_68_shift[14:0],esc_q_reg_61__0_805b7b0 [56]};
  assign esc_mem_reg_4__56__srl5_n_0_ff79cb7 = recovered_68_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__57__srl5_103b679
  reg [15:0] recovered_69_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_69_shift <= {recovered_69_shift[14:0],esc_q_reg_61__0_805b7b0 [57]};
  assign esc_mem_reg_4__57__srl5_n_0_6945ac8 = recovered_69_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__58__srl5_a09f4ec
  reg [15:0] recovered_70_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_70_shift <= {recovered_70_shift[14:0],esc_q_reg_61__0_805b7b0 [58]};
  assign esc_mem_reg_4__58__srl5_n_0_0ceb6fa = recovered_70_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__59__srl5_29230e4
  reg [15:0] recovered_71_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_71_shift <= {recovered_71_shift[14:0],esc_q_reg_61__0_805b7b0 [59]};
  assign esc_mem_reg_4__59__srl5_n_0_818a395 = recovered_71_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__5__srl5_ba611f2
  reg [15:0] recovered_72_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_72_shift <= {recovered_72_shift[14:0],esc_q_reg_61__0_805b7b0 [5]};
  assign esc_mem_reg_4__5__srl5_n_0_843e618 = recovered_72_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__60__srl5_099be26
  reg [15:0] recovered_73_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_73_shift <= {recovered_73_shift[14:0],esc_q_reg_61__0_805b7b0 [60]};
  assign esc_mem_reg_4__60__srl5_n_0_783d111 = recovered_73_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__61__srl5_1c20ffc
  reg [15:0] recovered_74_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_74_shift <= {recovered_74_shift[14:0],esc_q_reg_61__0_805b7b0 [61]};
  assign esc_mem_reg_4__61__srl5_n_0_7362482 = recovered_74_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__67__srl5_59009e1
  reg [15:0] recovered_75_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_75_shift <= {recovered_75_shift[14:0],esc_const1_c064970};
  assign esc_mem_reg_4__67__srl5_n_0_b6c00a7 = recovered_75_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__6__srl5_02f549d
  reg [15:0] recovered_76_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_76_shift <= {recovered_76_shift[14:0],esc_q_reg_61__0_805b7b0 [6]};
  assign esc_mem_reg_4__6__srl5_n_0_b2b44f9 = recovered_76_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__7__srl5_4dabe5a
  reg [15:0] recovered_77_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_77_shift <= {recovered_77_shift[14:0],esc_q_reg_61__0_805b7b0 [7]};
  assign esc_mem_reg_4__7__srl5_n_0_c57737b = recovered_77_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__8__srl5_7729bfd
  reg [15:0] recovered_78_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_78_shift <= {recovered_78_shift[14:0],esc_q_reg_61__0_805b7b0 [8]};
  assign esc_mem_reg_4__8__srl5_n_0_2bf3955 = recovered_78_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed SRL16E: esc_mem_reg_4__9__srl5_35a0c21
  reg [15:0] recovered_79_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_79_shift <= {recovered_79_shift[14:0],esc_q_reg_61__0_805b7b0 [9]};
  assign esc_mem_reg_4__9__srl5_n_0_bab496c = recovered_79_shift[{esc_const0_a0cf646,esc_pout_reg_n_0__2_3685eef,esc_pout_reg_n_0__1_307d4bf,esc_pout_reg_n_0__0_31a13ed}];

  // Reconstructed LUT6: esc_pout_0__i_1_729e482
  assign esc_pout_0__i_1_n_0_c71edc2 = ((esc_pout_reg_n_0__0_31a13ed) ? (((push) ? (((data_vld_reg_n_0) ? (~(esc_pout_0__i_2_n_0_965276f)) : (1'b1))) : (((data_vld_reg_n_0) ? (esc_pout_0__i_2_n_0_965276f) : (1'b1))))) : (((push) ? (((data_vld_reg_n_0) ? (esc_pout_0__i_2_n_0_965276f) : (1'b0))) : (((esc_pout_reg_n_0__2_3685eef) ? (((data_vld_reg_n_0) ? (~(esc_pout_0__i_2_n_0_965276f)) : (1'b0))) : (((esc_pout_reg_n_0__1_307d4bf) ? (((data_vld_reg_n_0) ? (~(esc_pout_0__i_2_n_0_965276f)) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT4: esc_pout_0__i_2_ffde150
  assign esc_pout_0__i_2_n_0_965276f = ((last_sect_buf) ? (((esc_q_reg_0__0_4378569) ? (1'b0) : (((esc_q_reg_0__1_c6877f4) ? (fifo_wreq_valid) : (1'b0))))) : (((esc_q_reg_0__1_c6877f4) ? (fifo_wreq_valid) : (1'b0))));

  // Reconstructed LUT6: esc_pout_1__i_1_d213e77
  assign esc_pout_1__i_1_n_0_77ba36c = ((esc_pout_reg_n_0__1_307d4bf) ? (((esc_pout_1__i_3_n_0_903af15) ? (((esc_pout_1__i_2_n_0_544f363) ? (((esc_pout_2__i_3_n_0_c02873e) ? (((esc_pout_reg_n_0__0_31a13ed) ? (esc_pout_2__i_2_n_0_8e0ffbe) : (~(esc_pout_2__i_2_n_0_8e0ffbe)))) : (1'b1))) : (((esc_pout_reg_n_0__0_31a13ed) ? (esc_pout_2__i_2_n_0_8e0ffbe) : (~(esc_pout_2__i_2_n_0_8e0ffbe)))))) : (((esc_pout_2__i_3_n_0_c02873e) ? (((esc_pout_reg_n_0__0_31a13ed) ? (esc_pout_2__i_2_n_0_8e0ffbe) : (~(esc_pout_2__i_2_n_0_8e0ffbe)))) : (1'b1))))) : (((esc_pout_1__i_3_n_0_903af15) ? (((esc_pout_1__i_2_n_0_544f363) ? (((esc_pout_2__i_3_n_0_c02873e) ? (((esc_pout_reg_n_0__0_31a13ed) ? (~(esc_pout_2__i_2_n_0_8e0ffbe)) : (esc_pout_2__i_2_n_0_8e0ffbe))) : (1'b0))) : (((esc_pout_reg_n_0__0_31a13ed) ? (~(esc_pout_2__i_2_n_0_8e0ffbe)) : (esc_pout_2__i_2_n_0_8e0ffbe))))) : (((esc_pout_2__i_3_n_0_c02873e) ? (((esc_pout_reg_n_0__0_31a13ed) ? (~(esc_pout_2__i_2_n_0_8e0ffbe)) : (esc_pout_2__i_2_n_0_8e0ffbe))) : (1'b0))))));

  // Reconstructed LUT5: esc_pout_1__i_2_cf20d14
  assign esc_pout_1__i_2_n_0_544f363 = ((esc_pout_reg_n_0__1_307d4bf) ? (((rs2f_wreq_ack) ? (esc_pout_reg_1__0_e33da39) : (1'b0))) : (((esc_pout_reg_n_0__0_31a13ed) ? (((rs2f_wreq_ack) ? (esc_pout_reg_1__0_e33da39) : (1'b0))) : (((esc_pout_reg_n_0__2_3685eef) ? (((rs2f_wreq_ack) ? (esc_pout_reg_1__0_e33da39) : (1'b0))) : (1'b1))))));

  // Reconstructed LUT5: esc_pout_1__i_3_c4d08c6
  assign esc_pout_1__i_3_n_0_903af15 = ((fifo_wreq_valid) ? (((esc_q_reg_0__1_c6877f4) ? (((esc_q_reg_0__0_4378569) ? (((last_sect_buf) ? (data_vld_reg_n_0) : (1'b0))) : (1'b0))) : (data_vld_reg_n_0))) : (data_vld_reg_n_0));

  // Reconstructed LUT6: esc_pout_2__i_1_9909dbc
  assign esc_pout_2__i_1_n_0_bcda194 = ((esc_pout_reg_n_0__2_3685eef) ? (((esc_pout_2__i_4_n_0_46213eb) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((esc_pout_reg_n_0__1_307d4bf) ? (esc_pout_2__i_2_n_0_8e0ffbe) : (1'b1))) : (((esc_pout_reg_n_0__1_307d4bf) ? (1'b1) : (~(esc_pout_2__i_2_n_0_8e0ffbe)))))) : (((esc_pout_2__i_3_n_0_c02873e) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((esc_pout_reg_n_0__1_307d4bf) ? (esc_pout_2__i_2_n_0_8e0ffbe) : (1'b1))) : (((esc_pout_reg_n_0__1_307d4bf) ? (1'b1) : (~(esc_pout_2__i_2_n_0_8e0ffbe)))))) : (1'b1))))) : (((esc_pout_2__i_4_n_0_46213eb) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((esc_pout_reg_n_0__1_307d4bf) ? (~(esc_pout_2__i_2_n_0_8e0ffbe)) : (1'b0))) : (((esc_pout_reg_n_0__1_307d4bf) ? (1'b0) : (esc_pout_2__i_2_n_0_8e0ffbe))))) : (((esc_pout_2__i_3_n_0_c02873e) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((esc_pout_reg_n_0__1_307d4bf) ? (~(esc_pout_2__i_2_n_0_8e0ffbe)) : (1'b0))) : (((esc_pout_reg_n_0__1_307d4bf) ? (1'b0) : (esc_pout_2__i_2_n_0_8e0ffbe))))) : (1'b0))))));

  // Reconstructed LUT6: esc_pout_2__i_2_68cb818
  assign esc_pout_2__i_2_n_0_8e0ffbe = ((data_vld_reg_n_0) ? (((push) ? (((fifo_wreq_valid) ? (((last_sect_buf) ? (((esc_q_reg_0__0_4378569) ? (1'b1) : (~(esc_q_reg_0__1_c6877f4)))) : (~(esc_q_reg_0__1_c6877f4)))) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT6: esc_pout_2__i_3_e7eeaf7
  assign esc_pout_2__i_3_n_0_c02873e = ((data_vld_reg_n_0) ? (((push) ? (((fifo_wreq_valid) ? (((esc_q_reg_0__1_c6877f4) ? (((esc_q_reg_0__0_4378569) ? (~(last_sect_buf)) : (1'b1))) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: esc_pout_2__i_4_0257bd8
  assign esc_pout_2__i_4_n_0_46213eb = ((esc_pout_1__i_2_n_0_544f363) ? (1'b0) : (((data_vld_reg_n_0) ? (((last_sect_buf) ? (((esc_q_reg_0__0_4378569) ? (1'b1) : (((esc_q_reg_0__1_c6877f4) ? (~(fifo_wreq_valid)) : (1'b1))))) : (((esc_q_reg_0__1_c6877f4) ? (~(fifo_wreq_valid)) : (1'b1))))) : (1'b0))));

  // Reconstructed FDRE: esc_pout_reg_0_cd95a63
  reg recovered_89_q = 1'b0;
  assign esc_pout_reg_n_0__0_31a13ed = recovered_89_q;
  wire recovered_89_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_89_reset || (((SR) === 1'bx) && (recovered_89_q == 1'b0))) recovered_89_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_89_q == (esc_pout_0__i_1_n_0_c71edc2)))) recovered_89_q <= (esc_pout_0__i_1_n_0_c71edc2);
  end

  // Reconstructed FDRE: esc_pout_reg_1_325167f
  reg recovered_90_q = 1'b0;
  assign esc_pout_reg_n_0__1_307d4bf = recovered_90_q;
  wire recovered_90_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_90_reset || (((SR) === 1'bx) && (recovered_90_q == 1'b0))) recovered_90_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_90_q == (esc_pout_1__i_1_n_0_77ba36c)))) recovered_90_q <= (esc_pout_1__i_1_n_0_77ba36c);
  end

  // Reconstructed FDRE: esc_pout_reg_2_3108b14
  reg recovered_91_q = 1'b0;
  assign esc_pout_reg_n_0__2_3685eef = recovered_91_q;
  wire recovered_91_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_91_reset || (((SR) === 1'bx) && (recovered_91_q == 1'b0))) recovered_91_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_91_q == (esc_pout_2__i_1_n_0_bcda194)))) recovered_91_q <= (esc_pout_2__i_1_n_0_bcda194);
  end

  // Reconstructed FDRE: esc_q_reg_0_02a935c
  reg recovered_92_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [0] = recovered_92_q;
  wire recovered_92_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_92_reset || (((SR) === 1'bx) && (recovered_92_q == 1'b0))) recovered_92_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_92_q == (esc_mem_reg_4__0__srl5_n_0_5b87500)))) recovered_92_q <= (esc_mem_reg_4__0__srl5_n_0_5b87500);
  end

  // Reconstructed FDRE: esc_q_reg_10_11878f1
  reg recovered_93_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [10] = recovered_93_q;
  wire recovered_93_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_93_reset || (((SR) === 1'bx) && (recovered_93_q == 1'b0))) recovered_93_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_93_q == (esc_mem_reg_4__10__srl5_n_0_e247105)))) recovered_93_q <= (esc_mem_reg_4__10__srl5_n_0_e247105);
  end

  // Reconstructed FDRE: esc_q_reg_11_f6a1408
  reg recovered_94_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [11] = recovered_94_q;
  wire recovered_94_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_94_reset || (((SR) === 1'bx) && (recovered_94_q == 1'b0))) recovered_94_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_94_q == (esc_mem_reg_4__11__srl5_n_0_27bf80c)))) recovered_94_q <= (esc_mem_reg_4__11__srl5_n_0_27bf80c);
  end

  // Reconstructed FDRE: esc_q_reg_12_9a3857c
  reg recovered_95_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [12] = recovered_95_q;
  wire recovered_95_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_95_reset || (((SR) === 1'bx) && (recovered_95_q == 1'b0))) recovered_95_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_95_q == (esc_mem_reg_4__12__srl5_n_0_997a3d0)))) recovered_95_q <= (esc_mem_reg_4__12__srl5_n_0_997a3d0);
  end

  // Reconstructed FDRE: esc_q_reg_13_d9e0bb6
  reg recovered_96_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [13] = recovered_96_q;
  wire recovered_96_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_96_reset || (((SR) === 1'bx) && (recovered_96_q == 1'b0))) recovered_96_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_96_q == (esc_mem_reg_4__13__srl5_n_0_c14c677)))) recovered_96_q <= (esc_mem_reg_4__13__srl5_n_0_c14c677);
  end

  // Reconstructed FDRE: esc_q_reg_14_318a5ee
  reg recovered_97_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [14] = recovered_97_q;
  wire recovered_97_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_97_reset || (((SR) === 1'bx) && (recovered_97_q == 1'b0))) recovered_97_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_97_q == (esc_mem_reg_4__14__srl5_n_0_b5761f7)))) recovered_97_q <= (esc_mem_reg_4__14__srl5_n_0_b5761f7);
  end

  // Reconstructed FDRE: esc_q_reg_15_e009494
  reg recovered_98_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [15] = recovered_98_q;
  wire recovered_98_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_98_reset || (((SR) === 1'bx) && (recovered_98_q == 1'b0))) recovered_98_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_98_q == (esc_mem_reg_4__15__srl5_n_0_76b0ea7)))) recovered_98_q <= (esc_mem_reg_4__15__srl5_n_0_76b0ea7);
  end

  // Reconstructed FDRE: esc_q_reg_16_7ece9ed
  reg recovered_99_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [16] = recovered_99_q;
  wire recovered_99_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_99_reset || (((SR) === 1'bx) && (recovered_99_q == 1'b0))) recovered_99_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_99_q == (esc_mem_reg_4__16__srl5_n_0_3ede415)))) recovered_99_q <= (esc_mem_reg_4__16__srl5_n_0_3ede415);
  end

  // Reconstructed FDRE: esc_q_reg_17_cc914c6
  reg recovered_100_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [17] = recovered_100_q;
  wire recovered_100_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_100_reset || (((SR) === 1'bx) && (recovered_100_q == 1'b0))) recovered_100_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_100_q == (esc_mem_reg_4__17__srl5_n_0_223dae8)))) recovered_100_q <= (esc_mem_reg_4__17__srl5_n_0_223dae8);
  end

  // Reconstructed FDRE: esc_q_reg_18_17eea42
  reg recovered_101_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [18] = recovered_101_q;
  wire recovered_101_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_101_reset || (((SR) === 1'bx) && (recovered_101_q == 1'b0))) recovered_101_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_101_q == (esc_mem_reg_4__18__srl5_n_0_0039e45)))) recovered_101_q <= (esc_mem_reg_4__18__srl5_n_0_0039e45);
  end

  // Reconstructed FDRE: esc_q_reg_19_dda1a6d
  reg recovered_102_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [19] = recovered_102_q;
  wire recovered_102_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_102_reset || (((SR) === 1'bx) && (recovered_102_q == 1'b0))) recovered_102_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_102_q == (esc_mem_reg_4__19__srl5_n_0_b3b8abd)))) recovered_102_q <= (esc_mem_reg_4__19__srl5_n_0_b3b8abd);
  end

  // Reconstructed FDRE: esc_q_reg_1_2d13bdc
  reg recovered_103_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [1] = recovered_103_q;
  wire recovered_103_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_103_reset || (((SR) === 1'bx) && (recovered_103_q == 1'b0))) recovered_103_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_103_q == (esc_mem_reg_4__1__srl5_n_0_24313a5)))) recovered_103_q <= (esc_mem_reg_4__1__srl5_n_0_24313a5);
  end

  // Reconstructed FDRE: esc_q_reg_20_afca079
  reg recovered_104_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [20] = recovered_104_q;
  wire recovered_104_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_104_reset || (((SR) === 1'bx) && (recovered_104_q == 1'b0))) recovered_104_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_104_q == (esc_mem_reg_4__20__srl5_n_0_a7cb185)))) recovered_104_q <= (esc_mem_reg_4__20__srl5_n_0_a7cb185);
  end

  // Reconstructed FDRE: esc_q_reg_21_68af605
  reg recovered_105_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [21] = recovered_105_q;
  wire recovered_105_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_105_reset || (((SR) === 1'bx) && (recovered_105_q == 1'b0))) recovered_105_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_105_q == (esc_mem_reg_4__21__srl5_n_0_1133f48)))) recovered_105_q <= (esc_mem_reg_4__21__srl5_n_0_1133f48);
  end

  // Reconstructed FDRE: esc_q_reg_22_28bf575
  reg recovered_106_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [22] = recovered_106_q;
  wire recovered_106_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_106_reset || (((SR) === 1'bx) && (recovered_106_q == 1'b0))) recovered_106_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_106_q == (esc_mem_reg_4__22__srl5_n_0_9fdb6b1)))) recovered_106_q <= (esc_mem_reg_4__22__srl5_n_0_9fdb6b1);
  end

  // Reconstructed FDRE: esc_q_reg_23_86d6c20
  reg recovered_107_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [23] = recovered_107_q;
  wire recovered_107_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_107_reset || (((SR) === 1'bx) && (recovered_107_q == 1'b0))) recovered_107_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_107_q == (esc_mem_reg_4__23__srl5_n_0_d387627)))) recovered_107_q <= (esc_mem_reg_4__23__srl5_n_0_d387627);
  end

  // Reconstructed FDRE: esc_q_reg_24_472a3b8
  reg recovered_108_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [24] = recovered_108_q;
  wire recovered_108_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_108_reset || (((SR) === 1'bx) && (recovered_108_q == 1'b0))) recovered_108_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_108_q == (esc_mem_reg_4__24__srl5_n_0_113f629)))) recovered_108_q <= (esc_mem_reg_4__24__srl5_n_0_113f629);
  end

  // Reconstructed FDRE: esc_q_reg_25_f6017d4
  reg recovered_109_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [25] = recovered_109_q;
  wire recovered_109_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_109_reset || (((SR) === 1'bx) && (recovered_109_q == 1'b0))) recovered_109_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_109_q == (esc_mem_reg_4__25__srl5_n_0_c2ea529)))) recovered_109_q <= (esc_mem_reg_4__25__srl5_n_0_c2ea529);
  end

  // Reconstructed FDRE: esc_q_reg_26_458b137
  reg recovered_110_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [26] = recovered_110_q;
  wire recovered_110_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_110_reset || (((SR) === 1'bx) && (recovered_110_q == 1'b0))) recovered_110_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_110_q == (esc_mem_reg_4__26__srl5_n_0_58cac40)))) recovered_110_q <= (esc_mem_reg_4__26__srl5_n_0_58cac40);
  end

  // Reconstructed FDRE: esc_q_reg_27_ab04e4c
  reg recovered_111_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [27] = recovered_111_q;
  wire recovered_111_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_111_reset || (((SR) === 1'bx) && (recovered_111_q == 1'b0))) recovered_111_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_111_q == (esc_mem_reg_4__27__srl5_n_0_724e83a)))) recovered_111_q <= (esc_mem_reg_4__27__srl5_n_0_724e83a);
  end

  // Reconstructed FDRE: esc_q_reg_28_bec0646
  reg recovered_112_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [28] = recovered_112_q;
  wire recovered_112_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_112_reset || (((SR) === 1'bx) && (recovered_112_q == 1'b0))) recovered_112_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_112_q == (esc_mem_reg_4__28__srl5_n_0_b25f46a)))) recovered_112_q <= (esc_mem_reg_4__28__srl5_n_0_b25f46a);
  end

  // Reconstructed FDRE: esc_q_reg_29_8d713f6
  reg recovered_113_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [29] = recovered_113_q;
  wire recovered_113_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_113_reset || (((SR) === 1'bx) && (recovered_113_q == 1'b0))) recovered_113_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_113_q == (esc_mem_reg_4__29__srl5_n_0_56756af)))) recovered_113_q <= (esc_mem_reg_4__29__srl5_n_0_56756af);
  end

  // Reconstructed FDRE: esc_q_reg_2_5a064fe
  reg recovered_114_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [2] = recovered_114_q;
  wire recovered_114_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_114_reset || (((SR) === 1'bx) && (recovered_114_q == 1'b0))) recovered_114_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_114_q == (esc_mem_reg_4__2__srl5_n_0_f2676c6)))) recovered_114_q <= (esc_mem_reg_4__2__srl5_n_0_f2676c6);
  end

  // Reconstructed FDRE: esc_q_reg_30_a086ab3
  reg recovered_115_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [30] = recovered_115_q;
  wire recovered_115_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_115_reset || (((SR) === 1'bx) && (recovered_115_q == 1'b0))) recovered_115_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_115_q == (esc_mem_reg_4__30__srl5_n_0_2b5eac6)))) recovered_115_q <= (esc_mem_reg_4__30__srl5_n_0_2b5eac6);
  end

  // Reconstructed FDRE: esc_q_reg_31_45eeab8
  reg recovered_116_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [31] = recovered_116_q;
  wire recovered_116_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_116_reset || (((SR) === 1'bx) && (recovered_116_q == 1'b0))) recovered_116_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_116_q == (esc_mem_reg_4__31__srl5_n_0_163765c)))) recovered_116_q <= (esc_mem_reg_4__31__srl5_n_0_163765c);
  end

  // Reconstructed FDRE: esc_q_reg_32_bf913d9
  reg recovered_117_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [32] = recovered_117_q;
  wire recovered_117_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_117_reset || (((SR) === 1'bx) && (recovered_117_q == 1'b0))) recovered_117_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_117_q == (esc_mem_reg_4__32__srl5_n_0_7f3a683)))) recovered_117_q <= (esc_mem_reg_4__32__srl5_n_0_7f3a683);
  end

  // Reconstructed FDRE: esc_q_reg_33_df23a43
  reg recovered_118_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [33] = recovered_118_q;
  wire recovered_118_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_118_reset || (((SR) === 1'bx) && (recovered_118_q == 1'b0))) recovered_118_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_118_q == (esc_mem_reg_4__33__srl5_n_0_c4d4bcb)))) recovered_118_q <= (esc_mem_reg_4__33__srl5_n_0_c4d4bcb);
  end

  // Reconstructed FDRE: esc_q_reg_34_64f4f4f
  reg recovered_119_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [34] = recovered_119_q;
  wire recovered_119_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_119_reset || (((SR) === 1'bx) && (recovered_119_q == 1'b0))) recovered_119_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_119_q == (esc_mem_reg_4__34__srl5_n_0_e917cf0)))) recovered_119_q <= (esc_mem_reg_4__34__srl5_n_0_e917cf0);
  end

  // Reconstructed FDRE: esc_q_reg_35_744539d
  reg recovered_120_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [35] = recovered_120_q;
  wire recovered_120_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_120_reset || (((SR) === 1'bx) && (recovered_120_q == 1'b0))) recovered_120_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_120_q == (esc_mem_reg_4__35__srl5_n_0_d7054c7)))) recovered_120_q <= (esc_mem_reg_4__35__srl5_n_0_d7054c7);
  end

  // Reconstructed FDRE: esc_q_reg_36_32ef392
  reg recovered_121_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [36] = recovered_121_q;
  wire recovered_121_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_121_reset || (((SR) === 1'bx) && (recovered_121_q == 1'b0))) recovered_121_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_121_q == (esc_mem_reg_4__36__srl5_n_0_8180ba4)))) recovered_121_q <= (esc_mem_reg_4__36__srl5_n_0_8180ba4);
  end

  // Reconstructed FDRE: esc_q_reg_37_29c58b0
  reg recovered_122_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [37] = recovered_122_q;
  wire recovered_122_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_122_reset || (((SR) === 1'bx) && (recovered_122_q == 1'b0))) recovered_122_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_122_q == (esc_mem_reg_4__37__srl5_n_0_e31fe08)))) recovered_122_q <= (esc_mem_reg_4__37__srl5_n_0_e31fe08);
  end

  // Reconstructed FDRE: esc_q_reg_38_7a6baae
  reg recovered_123_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [38] = recovered_123_q;
  wire recovered_123_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_123_reset || (((SR) === 1'bx) && (recovered_123_q == 1'b0))) recovered_123_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_123_q == (esc_mem_reg_4__38__srl5_n_0_15d7c61)))) recovered_123_q <= (esc_mem_reg_4__38__srl5_n_0_15d7c61);
  end

  // Reconstructed FDRE: esc_q_reg_39_c419345
  reg recovered_124_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [39] = recovered_124_q;
  wire recovered_124_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_124_reset || (((SR) === 1'bx) && (recovered_124_q == 1'b0))) recovered_124_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_124_q == (esc_mem_reg_4__39__srl5_n_0_aed7ba4)))) recovered_124_q <= (esc_mem_reg_4__39__srl5_n_0_aed7ba4);
  end

  // Reconstructed FDRE: esc_q_reg_3_e0a3a92
  reg recovered_125_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [3] = recovered_125_q;
  wire recovered_125_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_125_reset || (((SR) === 1'bx) && (recovered_125_q == 1'b0))) recovered_125_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_125_q == (esc_mem_reg_4__3__srl5_n_0_2b51a08)))) recovered_125_q <= (esc_mem_reg_4__3__srl5_n_0_2b51a08);
  end

  // Reconstructed FDRE: esc_q_reg_40_a809484
  reg recovered_126_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [40] = recovered_126_q;
  wire recovered_126_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_126_reset || (((SR) === 1'bx) && (recovered_126_q == 1'b0))) recovered_126_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_126_q == (esc_mem_reg_4__40__srl5_n_0_8d2fc8b)))) recovered_126_q <= (esc_mem_reg_4__40__srl5_n_0_8d2fc8b);
  end

  // Reconstructed FDRE: esc_q_reg_41_498b0b4
  reg recovered_127_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [41] = recovered_127_q;
  wire recovered_127_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_127_reset || (((SR) === 1'bx) && (recovered_127_q == 1'b0))) recovered_127_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_127_q == (esc_mem_reg_4__41__srl5_n_0_43f2c18)))) recovered_127_q <= (esc_mem_reg_4__41__srl5_n_0_43f2c18);
  end

  // Reconstructed FDRE: esc_q_reg_42_e8d4492
  reg recovered_128_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [42] = recovered_128_q;
  wire recovered_128_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_128_reset || (((SR) === 1'bx) && (recovered_128_q == 1'b0))) recovered_128_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_128_q == (esc_mem_reg_4__42__srl5_n_0_5068a2c)))) recovered_128_q <= (esc_mem_reg_4__42__srl5_n_0_5068a2c);
  end

  // Reconstructed FDRE: esc_q_reg_43_97f880f
  reg recovered_129_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [43] = recovered_129_q;
  wire recovered_129_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_129_reset || (((SR) === 1'bx) && (recovered_129_q == 1'b0))) recovered_129_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_129_q == (esc_mem_reg_4__43__srl5_n_0_2ccfd64)))) recovered_129_q <= (esc_mem_reg_4__43__srl5_n_0_2ccfd64);
  end

  // Reconstructed FDRE: esc_q_reg_44_570ffb8
  reg recovered_130_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [44] = recovered_130_q;
  wire recovered_130_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_130_reset || (((SR) === 1'bx) && (recovered_130_q == 1'b0))) recovered_130_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_130_q == (esc_mem_reg_4__44__srl5_n_0_81605ce)))) recovered_130_q <= (esc_mem_reg_4__44__srl5_n_0_81605ce);
  end

  // Reconstructed FDRE: esc_q_reg_45_51c818a
  reg recovered_131_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [45] = recovered_131_q;
  wire recovered_131_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_131_reset || (((SR) === 1'bx) && (recovered_131_q == 1'b0))) recovered_131_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_131_q == (esc_mem_reg_4__45__srl5_n_0_ca3fe15)))) recovered_131_q <= (esc_mem_reg_4__45__srl5_n_0_ca3fe15);
  end

  // Reconstructed FDRE: esc_q_reg_46_5fd0a21
  reg recovered_132_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [46] = recovered_132_q;
  wire recovered_132_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_132_reset || (((SR) === 1'bx) && (recovered_132_q == 1'b0))) recovered_132_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_132_q == (esc_mem_reg_4__46__srl5_n_0_d1bde41)))) recovered_132_q <= (esc_mem_reg_4__46__srl5_n_0_d1bde41);
  end

  // Reconstructed FDRE: esc_q_reg_47_e20ed3d
  reg recovered_133_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [47] = recovered_133_q;
  wire recovered_133_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_133_reset || (((SR) === 1'bx) && (recovered_133_q == 1'b0))) recovered_133_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_133_q == (esc_mem_reg_4__47__srl5_n_0_812a5e0)))) recovered_133_q <= (esc_mem_reg_4__47__srl5_n_0_812a5e0);
  end

  // Reconstructed FDRE: esc_q_reg_48_6567581
  reg recovered_134_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [48] = recovered_134_q;
  wire recovered_134_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_134_reset || (((SR) === 1'bx) && (recovered_134_q == 1'b0))) recovered_134_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_134_q == (esc_mem_reg_4__48__srl5_n_0_15ce78c)))) recovered_134_q <= (esc_mem_reg_4__48__srl5_n_0_15ce78c);
  end

  // Reconstructed FDRE: esc_q_reg_49_87e3434
  reg recovered_135_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [49] = recovered_135_q;
  wire recovered_135_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_135_reset || (((SR) === 1'bx) && (recovered_135_q == 1'b0))) recovered_135_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_135_q == (esc_mem_reg_4__49__srl5_n_0_879ca8b)))) recovered_135_q <= (esc_mem_reg_4__49__srl5_n_0_879ca8b);
  end

  // Reconstructed FDRE: esc_q_reg_4_8d11328
  reg recovered_136_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [4] = recovered_136_q;
  wire recovered_136_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_136_reset || (((SR) === 1'bx) && (recovered_136_q == 1'b0))) recovered_136_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_136_q == (esc_mem_reg_4__4__srl5_n_0_9ac6433)))) recovered_136_q <= (esc_mem_reg_4__4__srl5_n_0_9ac6433);
  end

  // Reconstructed FDRE: esc_q_reg_50_0ef9e01
  reg recovered_137_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [50] = recovered_137_q;
  wire recovered_137_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_137_reset || (((SR) === 1'bx) && (recovered_137_q == 1'b0))) recovered_137_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_137_q == (esc_mem_reg_4__50__srl5_n_0_1085b2a)))) recovered_137_q <= (esc_mem_reg_4__50__srl5_n_0_1085b2a);
  end

  // Reconstructed FDRE: esc_q_reg_51_89442b3
  reg recovered_138_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [51] = recovered_138_q;
  wire recovered_138_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_138_reset || (((SR) === 1'bx) && (recovered_138_q == 1'b0))) recovered_138_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_138_q == (esc_mem_reg_4__51__srl5_n_0_074a965)))) recovered_138_q <= (esc_mem_reg_4__51__srl5_n_0_074a965);
  end

  // Reconstructed FDRE: esc_q_reg_52_4a1f9b6
  reg recovered_139_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [52] = recovered_139_q;
  wire recovered_139_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_139_reset || (((SR) === 1'bx) && (recovered_139_q == 1'b0))) recovered_139_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_139_q == (esc_mem_reg_4__52__srl5_n_0_1c3bad9)))) recovered_139_q <= (esc_mem_reg_4__52__srl5_n_0_1c3bad9);
  end

  // Reconstructed FDRE: esc_q_reg_53_00055e6
  reg recovered_140_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [53] = recovered_140_q;
  wire recovered_140_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_140_reset || (((SR) === 1'bx) && (recovered_140_q == 1'b0))) recovered_140_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_140_q == (esc_mem_reg_4__53__srl5_n_0_10fdae5)))) recovered_140_q <= (esc_mem_reg_4__53__srl5_n_0_10fdae5);
  end

  // Reconstructed FDRE: esc_q_reg_54_2c029c7
  reg recovered_141_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [54] = recovered_141_q;
  wire recovered_141_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_141_reset || (((SR) === 1'bx) && (recovered_141_q == 1'b0))) recovered_141_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_141_q == (esc_mem_reg_4__54__srl5_n_0_d87cca8)))) recovered_141_q <= (esc_mem_reg_4__54__srl5_n_0_d87cca8);
  end

  // Reconstructed FDRE: esc_q_reg_55_0772dfa
  reg recovered_142_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [55] = recovered_142_q;
  wire recovered_142_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_142_reset || (((SR) === 1'bx) && (recovered_142_q == 1'b0))) recovered_142_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_142_q == (esc_mem_reg_4__55__srl5_n_0_f34d6be)))) recovered_142_q <= (esc_mem_reg_4__55__srl5_n_0_f34d6be);
  end

  // Reconstructed FDRE: esc_q_reg_56_1bf8f39
  reg recovered_143_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [56] = recovered_143_q;
  wire recovered_143_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_143_reset || (((SR) === 1'bx) && (recovered_143_q == 1'b0))) recovered_143_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_143_q == (esc_mem_reg_4__56__srl5_n_0_ff79cb7)))) recovered_143_q <= (esc_mem_reg_4__56__srl5_n_0_ff79cb7);
  end

  // Reconstructed FDRE: esc_q_reg_57_943da1c
  reg recovered_144_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [57] = recovered_144_q;
  wire recovered_144_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_144_reset || (((SR) === 1'bx) && (recovered_144_q == 1'b0))) recovered_144_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_144_q == (esc_mem_reg_4__57__srl5_n_0_6945ac8)))) recovered_144_q <= (esc_mem_reg_4__57__srl5_n_0_6945ac8);
  end

  // Reconstructed FDRE: esc_q_reg_58_4b5adbb
  reg recovered_145_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [58] = recovered_145_q;
  wire recovered_145_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_145_reset || (((SR) === 1'bx) && (recovered_145_q == 1'b0))) recovered_145_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_145_q == (esc_mem_reg_4__58__srl5_n_0_0ceb6fa)))) recovered_145_q <= (esc_mem_reg_4__58__srl5_n_0_0ceb6fa);
  end

  // Reconstructed FDRE: esc_q_reg_59_e9de3ad
  reg recovered_146_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [59] = recovered_146_q;
  wire recovered_146_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_146_reset || (((SR) === 1'bx) && (recovered_146_q == 1'b0))) recovered_146_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_146_q == (esc_mem_reg_4__59__srl5_n_0_818a395)))) recovered_146_q <= (esc_mem_reg_4__59__srl5_n_0_818a395);
  end

  // Reconstructed FDRE: esc_q_reg_5_9e39b41
  reg recovered_147_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [5] = recovered_147_q;
  wire recovered_147_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_147_reset || (((SR) === 1'bx) && (recovered_147_q == 1'b0))) recovered_147_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_147_q == (esc_mem_reg_4__5__srl5_n_0_843e618)))) recovered_147_q <= (esc_mem_reg_4__5__srl5_n_0_843e618);
  end

  // Reconstructed FDRE: esc_q_reg_60_bb75099
  reg recovered_148_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [60] = recovered_148_q;
  wire recovered_148_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_148_reset || (((SR) === 1'bx) && (recovered_148_q == 1'b0))) recovered_148_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_148_q == (esc_mem_reg_4__60__srl5_n_0_783d111)))) recovered_148_q <= (esc_mem_reg_4__60__srl5_n_0_783d111);
  end

  // Reconstructed FDRE: esc_q_reg_61_9f43040
  reg recovered_149_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [61] = recovered_149_q;
  wire recovered_149_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_149_reset || (((SR) === 1'bx) && (recovered_149_q == 1'b0))) recovered_149_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_149_q == (esc_mem_reg_4__61__srl5_n_0_7362482)))) recovered_149_q <= (esc_mem_reg_4__61__srl5_n_0_7362482);
  end

  // Reconstructed FDRE: esc_q_reg_67_5122ea0
  reg recovered_150_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [62] = recovered_150_q;
  wire recovered_150_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_150_reset || (((SR) === 1'bx) && (recovered_150_q == 1'b0))) recovered_150_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_150_q == (esc_mem_reg_4__67__srl5_n_0_b6c00a7)))) recovered_150_q <= (esc_mem_reg_4__67__srl5_n_0_b6c00a7);
  end

  // Reconstructed FDRE: esc_q_reg_6_e06484f
  reg recovered_151_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [6] = recovered_151_q;
  wire recovered_151_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_151_reset || (((SR) === 1'bx) && (recovered_151_q == 1'b0))) recovered_151_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_151_q == (esc_mem_reg_4__6__srl5_n_0_b2b44f9)))) recovered_151_q <= (esc_mem_reg_4__6__srl5_n_0_b2b44f9);
  end

  // Reconstructed FDRE: esc_q_reg_7_ebc3ce4
  reg recovered_152_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [7] = recovered_152_q;
  wire recovered_152_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_152_reset || (((SR) === 1'bx) && (recovered_152_q == 1'b0))) recovered_152_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_152_q == (esc_mem_reg_4__7__srl5_n_0_c57737b)))) recovered_152_q <= (esc_mem_reg_4__7__srl5_n_0_c57737b);
  end

  // Reconstructed FDRE: esc_q_reg_8_7537f74
  reg recovered_153_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [8] = recovered_153_q;
  wire recovered_153_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_153_reset || (((SR) === 1'bx) && (recovered_153_q == 1'b0))) recovered_153_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_153_q == (esc_mem_reg_4__8__srl5_n_0_2bf3955)))) recovered_153_q <= (esc_mem_reg_4__8__srl5_n_0_2bf3955);
  end

  // Reconstructed FDRE: esc_q_reg_9_974df34
  reg recovered_154_q = 1'b0;
  assign esc_q_reg_67__0_7bacafd [9] = recovered_154_q;
  wire recovered_154_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_154_reset || (((SR) === 1'bx) && (recovered_154_q == 1'b0))) recovered_154_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_154_q == (esc_mem_reg_4__9__srl5_n_0_bab496c)))) recovered_154_q <= (esc_mem_reg_4__9__srl5_n_0_bab496c);
  end

endmodule

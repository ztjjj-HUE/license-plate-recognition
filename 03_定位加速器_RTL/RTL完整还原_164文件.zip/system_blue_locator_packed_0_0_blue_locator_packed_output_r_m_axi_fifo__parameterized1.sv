// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_fifo__parameterized1
   (fifo_resp_ready,
    esc_could_multi_bursts_next_loop_c288065 ,
    invalid_len_event_reg2_reg,
    push,
    next_resp0,
    push_0,
    esc_could_multi_bursts_sect_handling_reg_a60c95a ,
    ap_clk,
    SR,
    next_resp,
    in,
    esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc ,
    esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938 ,
    ap_rst_n,
    esc_could_multi_bursts_sect_handling_reg_0_f501666 ,
    fifo_burst_ready,
    esc_q_reg_1__0_d7f3451 ,
    esc_could_multi_bursts_sect_handling_reg_1_bec7600 ,
    m_axi_output_r_BVALID,
    next_resp_reg,
    esc_could_multi_bursts_sect_handling_reg_2_ba13788 );
  output fifo_resp_ready;
  output esc_could_multi_bursts_next_loop_c288065 ;
  output invalid_len_event_reg2_reg;
  output push;
  output next_resp0;
  output push_0;
  output esc_could_multi_bursts_sect_handling_reg_a60c95a ;
  input ap_clk;
  input [0:0]SR;
  input next_resp;
  input [0:0]in;
  input esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc ;
  input esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938 ;
  input ap_rst_n;
  input esc_could_multi_bursts_sect_handling_reg_0_f501666 ;
  input fifo_burst_ready;
  input esc_q_reg_1__0_d7f3451 ;
  input esc_could_multi_bursts_sect_handling_reg_1_bec7600 ;
  input m_axi_output_r_BVALID;
  input next_resp_reg;
  input esc_could_multi_bursts_sect_handling_reg_2_ba13788 ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]SR;
  wire ap_clk;
  wire ap_rst_n;
  wire [1:1]aw2b_awdata;
  wire [1:0]aw2b_bdata;
  wire esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc ;
  wire esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938 ;
  wire esc_could_multi_bursts_next_loop_c288065 ;
  wire esc_could_multi_bursts_sect_handling_reg_a60c95a ;
  wire esc_could_multi_bursts_sect_handling_reg_0_f501666 ;
  wire esc_could_multi_bursts_sect_handling_reg_1_bec7600 ;
  wire esc_could_multi_bursts_sect_handling_reg_2_ba13788 ;
  wire data_vld_i_1__4_n_0;
  wire data_vld_reg_n_0;
  wire empty_n_i_1__4_n_0;
  wire fifo_burst_ready;
  wire fifo_resp_ready;
  wire full_n_i_1__5_n_0;
  wire full_n_i_2__6_n_0;
  wire [0:0]in;
  wire invalid_len_event_reg2_reg;
  wire m_axi_output_r_BVALID;
  wire esc_mem_reg_14__0__srl15_n_0_a83b94a ;
  wire esc_mem_reg_14__1__srl15_n_0_35f89c7 ;
  wire need_wrsp;
  wire next_resp;
  wire next_resp0;
  wire next_resp_reg;
  wire pop0;
  wire esc_pout_0__i_1__0_n_0_5f9ed9c ;
  wire esc_pout_1__i_1__0_n_0_12808b1 ;
  wire esc_pout_2__i_1__0_n_0_4dcb0b7 ;
  wire esc_pout_3__i_1__0_n_0_5ae9e2a ;
  wire esc_pout_3__i_2__0_n_0_54a002d ;
  wire esc_pout_3__i_3__0_n_0_f2d9658 ;
  wire esc_pout_3__i_4__0_n_0_ac45933 ;
  wire [3:0]pout_reg;
  wire push;
  wire push_0;
  wire esc_q_reg_1__0_d7f3451 ;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT5: esc_could_multi_bursts_AWVALID_Dummy_i_1_b3c087d
  assign invalid_len_event_reg2_reg = ((ap_rst_n) ? (((esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938) ? (((esc_could_multi_bursts_next_loop_c288065) ? (~(in)) : (~(esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc)))) : (((esc_could_multi_bursts_next_loop_c288065) ? (~(in)) : (1'b0))))) : (1'b0));

  // Reconstructed LUT5: esc_could_multi_bursts_awaddr_buf_63__i_1_fbaf940
  assign esc_could_multi_bursts_next_loop_c288065 = ((fifo_burst_ready) ? (((esc_could_multi_bursts_sect_handling_reg_0_f501666) ? (((fifo_resp_ready) ? (((esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc) ? (1'b1) : (~(esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938)))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT4: esc_could_multi_bursts_sect_handling_i_1_2f7e142
  assign esc_could_multi_bursts_sect_handling_reg_a60c95a = ((esc_could_multi_bursts_sect_handling_reg_1_bec7600) ? (((esc_could_multi_bursts_sect_handling_reg_2_ba13788) ? (1'b1) : (esc_could_multi_bursts_sect_handling_reg_0_f501666))) : (((esc_could_multi_bursts_next_loop_c288065) ? (esc_could_multi_bursts_sect_handling_reg_2_ba13788) : (((esc_could_multi_bursts_sect_handling_reg_2_ba13788) ? (1'b1) : (esc_could_multi_bursts_sect_handling_reg_0_f501666))))));

  // Reconstructed LUT5: data_vld_i_1__4
  assign data_vld_i_1__4_n_0 = ((next_resp) ? (((data_vld_reg_n_0) ? (((esc_pout_3__i_3__0_n_0_f2d9658) ? (esc_could_multi_bursts_next_loop_c288065) : (1'b1))) : (esc_could_multi_bursts_next_loop_c288065))) : (((need_wrsp) ? (((data_vld_reg_n_0) ? (1'b1) : (esc_could_multi_bursts_next_loop_c288065))) : (((data_vld_reg_n_0) ? (((esc_pout_3__i_3__0_n_0_f2d9658) ? (esc_could_multi_bursts_next_loop_c288065) : (1'b1))) : (esc_could_multi_bursts_next_loop_c288065))))));

  // Reconstructed FDRE: data_vld_reg
  reg recovered_7_q = 1'b0;
  assign data_vld_reg_n_0 = recovered_7_q;
  wire recovered_7_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_7_reset || (((SR) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (data_vld_i_1__4_n_0)))) recovered_7_q <= (data_vld_i_1__4_n_0);
  end

  // Reconstructed LUT3: empty_n_i_1__4
  assign empty_n_i_1__4_n_0 = ((need_wrsp) ? (((next_resp) ? (data_vld_reg_n_0) : (1'b1))) : (data_vld_reg_n_0));

  // Reconstructed FDRE: empty_n_reg
  reg recovered_9_q = 1'b0;
  assign need_wrsp = recovered_9_q;
  wire recovered_9_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_9_reset || (((SR) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (empty_n_i_1__4_n_0)))) recovered_9_q <= (empty_n_i_1__4_n_0);
  end

  // Reconstructed LUT6: full_n_i_1__5
  assign full_n_i_1__5_n_0 = ((data_vld_reg_n_0) ? (((pop0) ? (1'b1) : (((esc_could_multi_bursts_next_loop_c288065) ? (((full_n_i_2__6_n_0) ? (((fifo_resp_ready) ? (1'b1) : (~(ap_rst_n)))) : (~(ap_rst_n)))) : (((fifo_resp_ready) ? (1'b1) : (~(ap_rst_n)))))))) : (((fifo_resp_ready) ? (1'b1) : (~(ap_rst_n)))));

  // Reconstructed LUT4: full_n_i_2__6
  assign full_n_i_2__6_n_0 = ((pout_reg[1]) ? (1'b1) : (((pout_reg[0]) ? (((pout_reg[2]) ? (~(pout_reg[3])) : (1'b1))) : (1'b1))));

  // Reconstructed FDRE: full_n_reg
  reg recovered_12_q = 1'b0;
  assign fifo_resp_ready = recovered_12_q;
  wire recovered_12_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_12_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_12_q == (full_n_i_1__5_n_0)))) recovered_12_q <= (full_n_i_1__5_n_0);
  end

  // Reconstructed SRL16E: esc_mem_reg_14__0__srl15_2dc5e35
  reg [15:0] recovered_13_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((esc_could_multi_bursts_next_loop_c288065) == 1'b1 || (esc_could_multi_bursts_next_loop_c288065) === 1'bz) recovered_13_shift <= {recovered_13_shift[14:0],in};
  assign esc_mem_reg_14__0__srl15_n_0_a83b94a = recovered_13_shift[{pout_reg[3],pout_reg[2],pout_reg[1],pout_reg[0]}];

  // Reconstructed SRL16E: esc_mem_reg_14__1__srl15_692277d
  reg [15:0] recovered_14_shift = 16'h0000;
  always @(posedge ap_clk)
    if ((esc_could_multi_bursts_next_loop_c288065) == 1'b1 || (esc_could_multi_bursts_next_loop_c288065) === 1'bz) recovered_14_shift <= {recovered_14_shift[14:0],aw2b_awdata};
  assign esc_mem_reg_14__1__srl15_n_0_35f89c7 = recovered_14_shift[{pout_reg[3],pout_reg[2],pout_reg[1],pout_reg[0]}];

  // Reconstructed LUT2: esc_mem_reg_14__1__srl15_i_1_6c9838e
  assign aw2b_awdata = ((esc_could_multi_bursts_sect_handling_reg_1_bec7600) ? (1'b0) : (esc_q_reg_1__0_d7f3451));

  // Reconstructed LUT2: esc_mem_reg_4__0__srl5_i_1__1_d6b3a5e
  assign push = ((in) ? (1'b0) : (esc_could_multi_bursts_next_loop_c288065));

  // Reconstructed LUT5: next_resp_i_1
  assign next_resp0 = ((next_resp_reg) ? (((m_axi_output_r_BVALID) ? (1'b1) : (((aw2b_bdata[0]) ? (((need_wrsp) ? (~(next_resp)) : (1'b0))) : (1'b0))))) : (((aw2b_bdata[0]) ? (((need_wrsp) ? (~(next_resp)) : (1'b0))) : (1'b0))));

  // Reconstructed LUT1: esc_pout_0__i_1__0_3efb094
  assign esc_pout_0__i_1__0_n_0_5f9ed9c = ~(pout_reg[0]);

  // Reconstructed LUT5: esc_pout_1__i_1__0_d57fda5
  assign esc_pout_1__i_1__0_n_0_12808b1 = ((pout_reg[1]) ? (((pout_reg[0]) ? (((esc_could_multi_bursts_next_loop_c288065) ? (((next_resp) ? (1'b1) : (~(need_wrsp)))) : (1'b1))) : (((esc_could_multi_bursts_next_loop_c288065) ? (((next_resp) ? (1'b0) : (need_wrsp))) : (1'b0))))) : (((pout_reg[0]) ? (((esc_could_multi_bursts_next_loop_c288065) ? (((next_resp) ? (1'b0) : (need_wrsp))) : (1'b0))) : (((esc_could_multi_bursts_next_loop_c288065) ? (((next_resp) ? (1'b1) : (~(need_wrsp)))) : (1'b1))))));

  // Reconstructed LUT5: esc_pout_2__i_1__0_27de624
  assign esc_pout_2__i_1__0_n_0_4dcb0b7 = ((pout_reg[1]) ? (((pout_reg[2]) ? (((pop0) ? (1'b1) : (((esc_could_multi_bursts_next_loop_c288065) ? (~(pout_reg[0])) : (1'b1))))) : (((pop0) ? (1'b0) : (((esc_could_multi_bursts_next_loop_c288065) ? (pout_reg[0]) : (1'b0))))))) : (((pout_reg[2]) ? (((pop0) ? (pout_reg[0]) : (((esc_could_multi_bursts_next_loop_c288065) ? (1'b1) : (pout_reg[0]))))) : (((pop0) ? (~(pout_reg[0])) : (((esc_could_multi_bursts_next_loop_c288065) ? (1'b0) : (~(pout_reg[0])))))))));

  // Reconstructed LUT5: esc_pout_2__i_2__0_0c814a3
  assign push_0 = ((next_resp_reg) ? (((next_resp) ? (((need_wrsp) ? (((aw2b_bdata[0]) ? (1'b1) : (aw2b_bdata[1]))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT5: esc_pout_3__i_1__0_1e086b8
  assign esc_pout_3__i_1__0_n_0_5ae9e2a = ((esc_pout_3__i_3__0_n_0_f2d9658) ? (((data_vld_reg_n_0) ? (((need_wrsp) ? (((next_resp) ? (1'b0) : (esc_could_multi_bursts_next_loop_c288065))) : (1'b0))) : (1'b0))) : (((data_vld_reg_n_0) ? (((need_wrsp) ? (((next_resp) ? (~(esc_could_multi_bursts_next_loop_c288065)) : (esc_could_multi_bursts_next_loop_c288065))) : (~(esc_could_multi_bursts_next_loop_c288065)))) : (1'b0))));

  // Reconstructed LUT5: esc_pout_3__i_2__0_b74d827
  assign esc_pout_3__i_2__0_n_0_54a002d = ((pout_reg[0]) ? (((pout_reg[1]) ? (((esc_pout_3__i_4__0_n_0_ac45933) ? (((pout_reg[2]) ? (~(pout_reg[3])) : (pout_reg[3]))) : (pout_reg[3]))) : (pout_reg[3]))) : (((pout_reg[1]) ? (pout_reg[3]) : (((esc_pout_3__i_4__0_n_0_ac45933) ? (pout_reg[3]) : (((pout_reg[2]) ? (pout_reg[3]) : (~(pout_reg[3])))))))));

  // Reconstructed LUT4: esc_pout_3__i_3__0_023d0bd
  assign esc_pout_3__i_3__0_n_0_f2d9658 = ((pout_reg[2]) ? (1'b0) : (((pout_reg[3]) ? (1'b0) : (((pout_reg[1]) ? (1'b0) : (~(pout_reg[0])))))));

  // Reconstructed LUT4: esc_pout_3__i_4__0_9bdbf06
  assign esc_pout_3__i_4__0_n_0_ac45933 = ((data_vld_reg_n_0) ? (((need_wrsp) ? (((next_resp) ? (1'b0) : (esc_could_multi_bursts_next_loop_c288065))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_pout_reg_0_cd95a63
  reg recovered_26_q = 1'b0;
  assign pout_reg[0] = recovered_26_q;
  wire recovered_26_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_26_reset || (((SR) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((esc_pout_3__i_1__0_n_0_5ae9e2a) || ((esc_pout_3__i_1__0_n_0_5ae9e2a) === 1'bz) || (((esc_pout_3__i_1__0_n_0_5ae9e2a) === 1'bx) && (recovered_26_q == (esc_pout_0__i_1__0_n_0_5f9ed9c)))) recovered_26_q <= (esc_pout_0__i_1__0_n_0_5f9ed9c);
  end

  // Reconstructed FDRE: esc_pout_reg_1_325167f
  reg recovered_27_q = 1'b0;
  assign pout_reg[1] = recovered_27_q;
  wire recovered_27_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_27_reset || (((SR) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((esc_pout_3__i_1__0_n_0_5ae9e2a) || ((esc_pout_3__i_1__0_n_0_5ae9e2a) === 1'bz) || (((esc_pout_3__i_1__0_n_0_5ae9e2a) === 1'bx) && (recovered_27_q == (esc_pout_1__i_1__0_n_0_12808b1)))) recovered_27_q <= (esc_pout_1__i_1__0_n_0_12808b1);
  end

  // Reconstructed FDRE: esc_pout_reg_2_3108b14
  reg recovered_28_q = 1'b0;
  assign pout_reg[2] = recovered_28_q;
  wire recovered_28_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_28_reset || (((SR) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((esc_pout_3__i_1__0_n_0_5ae9e2a) || ((esc_pout_3__i_1__0_n_0_5ae9e2a) === 1'bz) || (((esc_pout_3__i_1__0_n_0_5ae9e2a) === 1'bx) && (recovered_28_q == (esc_pout_2__i_1__0_n_0_4dcb0b7)))) recovered_28_q <= (esc_pout_2__i_1__0_n_0_4dcb0b7);
  end

  // Reconstructed FDRE: esc_pout_reg_3_c06edf1
  reg recovered_29_q = 1'b0;
  assign pout_reg[3] = recovered_29_q;
  wire recovered_29_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_29_reset || (((SR) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((esc_pout_3__i_1__0_n_0_5ae9e2a) || ((esc_pout_3__i_1__0_n_0_5ae9e2a) === 1'bz) || (((esc_pout_3__i_1__0_n_0_5ae9e2a) === 1'bx) && (recovered_29_q == (esc_pout_3__i_2__0_n_0_54a002d)))) recovered_29_q <= (esc_pout_3__i_2__0_n_0_54a002d);
  end

  // Reconstructed LUT2: esc_q_1__i_1_9c6ff88
  assign pop0 = ((need_wrsp) ? (next_resp) : (1'b1));

  // Reconstructed FDRE: esc_q_reg_0_02a935c
  reg recovered_31_q = 1'b0;
  assign aw2b_bdata[0] = recovered_31_q;
  wire recovered_31_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_31_reset || (((SR) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_31_q == (esc_mem_reg_14__0__srl15_n_0_a83b94a)))) recovered_31_q <= (esc_mem_reg_14__0__srl15_n_0_a83b94a);
  end

  // Reconstructed FDRE: esc_q_reg_1_2d13bdc
  reg recovered_32_q = 1'b0;
  assign aw2b_bdata[1] = recovered_32_q;
  wire recovered_32_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_32_reset || (((SR) === 1'bx) && (recovered_32_q == 1'b0))) recovered_32_q <= 1'b0;
    else if ((pop0) || ((pop0) === 1'bz) || (((pop0) === 1'bx) && (recovered_32_q == (esc_mem_reg_14__1__srl15_n_0_35f89c7)))) recovered_32_q <= (esc_mem_reg_14__1__srl15_n_0_35f89c7);
  end

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_fifo__parameterized2
   (full_n_reg_0,
    empty_n_reg_0,
    D,
    ap_done,
    ap_clk,
    SR,
    Q,
    ap_start,
    push,
    ap_rst_n);
  output full_n_reg_0;
  output empty_n_reg_0;
  output [1:0]D;
  output ap_done;
  input ap_clk;
  input [0:0]SR;
  input [2:0]Q;
  input ap_start;
  input push;
  input ap_rst_n;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [1:0]D;
  wire [2:0]Q;
  wire [0:0]SR;
  wire ap_clk;
  wire ap_done;
  wire ap_rst_n;
  wire ap_start;
  wire data_vld_i_1__5_n_0;
  wire data_vld_reg_n_0;
  wire empty_n_i_1__3_n_0;
  wire empty_n_reg_0;
  wire full_n_i_1__7_n_0;
  wire full_n_i_2__3_n_0;
  wire full_n_i_3__0_n_0;
  wire full_n_i_4_n_0;
  wire full_n_reg_0;
  wire pop0;
  wire esc_pout_0__i_1__1_n_0_6bb9451 ;
  wire esc_pout_1__i_1_n_0_77ba36c ;
  wire esc_pout_2__i_1_n_0_bcda194 ;
  wire esc_pout_reg_n_0__0_31a13ed ;
  wire esc_pout_reg_n_0__1_307d4bf ;
  wire esc_pout_reg_n_0__2_3685eef ;
  wire push;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT4: esc_ap_CS_fsm_0__i_1_d4b1daf
  assign D[0] = ((Q[0]) ? (((ap_start) ? (((Q[2]) ? (empty_n_reg_0) : (1'b0))) : (1'b1))) : (((Q[2]) ? (empty_n_reg_0) : (1'b0))));

  // Reconstructed LUT3: esc_ap_CS_fsm_76__i_1_bca128f
  assign D[1] = ((Q[2]) ? (~(empty_n_reg_0)) : (Q[1]));

  // Reconstructed LUT6: data_vld_i_1__5
  assign data_vld_i_1__5_n_0 = ((data_vld_reg_n_0) ? (((full_n_i_2__3_n_0) ? (((esc_pout_reg_n_0__2_3685eef) ? (1'b1) : (((esc_pout_reg_n_0__0_31a13ed) ? (1'b1) : (((esc_pout_reg_n_0__1_307d4bf) ? (1'b1) : (push))))))) : (1'b1))) : (push));

  // Reconstructed FDRE: data_vld_reg
  reg recovered_6_q = 1'b0;
  assign data_vld_reg_n_0 = recovered_6_q;
  wire recovered_6_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_6_reset || (((SR) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (data_vld_i_1__5_n_0)))) recovered_6_q <= (data_vld_i_1__5_n_0);
  end

  // Reconstructed LUT3: empty_n_i_1__3
  assign empty_n_i_1__3_n_0 = ((empty_n_reg_0) ? (((Q[2]) ? (data_vld_reg_n_0) : (1'b1))) : (data_vld_reg_n_0));

  // Reconstructed FDRE: empty_n_reg
  reg recovered_8_q = 1'b0;
  assign empty_n_reg_0 = recovered_8_q;
  wire recovered_8_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_8_reset || (((SR) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_8_q == (empty_n_i_1__3_n_0)))) recovered_8_q <= (empty_n_i_1__3_n_0);
  end

  // Reconstructed LUT6: full_n_i_1__7
  assign full_n_i_1__7_n_0 = ((full_n_i_4_n_0) ? (((full_n_i_3__0_n_0) ? (((esc_pout_reg_n_0__2_3685eef) ? (((full_n_reg_0) ? (1'b1) : (((ap_rst_n) ? (full_n_i_2__3_n_0) : (1'b1))))) : (((ap_rst_n) ? (full_n_i_2__3_n_0) : (1'b1))))) : (((full_n_reg_0) ? (1'b1) : (((ap_rst_n) ? (full_n_i_2__3_n_0) : (1'b1))))))) : (((full_n_reg_0) ? (1'b1) : (((ap_rst_n) ? (full_n_i_2__3_n_0) : (1'b1))))));

  // Reconstructed LUT3: full_n_i_2__3
  assign full_n_i_2__3_n_0 = ((Q[2]) ? (data_vld_reg_n_0) : (((empty_n_reg_0) ? (1'b0) : (data_vld_reg_n_0))));

  // Reconstructed LUT2: full_n_i_3__0
  assign full_n_i_3__0_n_0 = ((esc_pout_reg_n_0__1_307d4bf) ? (esc_pout_reg_n_0__0_31a13ed) : (1'b0));

  // Reconstructed LUT4: full_n_i_4
  assign full_n_i_4_n_0 = ((data_vld_reg_n_0) ? (((empty_n_reg_0) ? (((Q[2]) ? (1'b0) : (push))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: full_n_reg
  reg recovered_13_q = 1'b0;
  assign full_n_reg_0 = recovered_13_q;
  wire recovered_13_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_13_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_13_q == (full_n_i_1__7_n_0)))) recovered_13_q <= (full_n_i_1__7_n_0);
  end

  // Reconstructed LUT2: int_ap_ready_i_1
  assign ap_done = ((empty_n_reg_0) ? (Q[2]) : (1'b0));

  // Reconstructed LUT6: esc_pout_0__i_1__1_a514997
  assign esc_pout_0__i_1__1_n_0_6bb9451 = ((esc_pout_reg_n_0__1_307d4bf) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((data_vld_reg_n_0) ? (((pop0) ? (push) : (~(push)))) : (1'b1))) : (((data_vld_reg_n_0) ? (((pop0) ? (~(push)) : (push))) : (1'b0))))) : (((esc_pout_reg_n_0__0_31a13ed) ? (((data_vld_reg_n_0) ? (((pop0) ? (push) : (~(push)))) : (1'b1))) : (((esc_pout_reg_n_0__2_3685eef) ? (((data_vld_reg_n_0) ? (((pop0) ? (~(push)) : (push))) : (1'b0))) : (((data_vld_reg_n_0) ? (((pop0) ? (1'b0) : (push))) : (1'b0))))))));

  // Reconstructed LUT6: esc_pout_1__i_1_d213e77
  assign esc_pout_1__i_1_n_0_77ba36c = ((esc_pout_reg_n_0__1_307d4bf) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((data_vld_reg_n_0) ? (((pop0) ? (1'b1) : (~(push)))) : (1'b1))) : (((data_vld_reg_n_0) ? (((pop0) ? (push) : (1'b1))) : (1'b1))))) : (((esc_pout_reg_n_0__0_31a13ed) ? (((data_vld_reg_n_0) ? (((pop0) ? (1'b0) : (push))) : (1'b0))) : (((esc_pout_reg_n_0__2_3685eef) ? (((data_vld_reg_n_0) ? (((pop0) ? (~(push)) : (1'b0))) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT6: esc_pout_2__i_1_9909dbc
  assign esc_pout_2__i_1_n_0_bcda194 = ((esc_pout_reg_n_0__1_307d4bf) ? (((esc_pout_reg_n_0__0_31a13ed) ? (((esc_pout_reg_n_0__2_3685eef) ? (((data_vld_reg_n_0) ? (((pop0) ? (1'b1) : (~(push)))) : (1'b1))) : (((data_vld_reg_n_0) ? (((pop0) ? (1'b0) : (push))) : (1'b0))))) : (esc_pout_reg_n_0__2_3685eef))) : (((esc_pout_reg_n_0__0_31a13ed) ? (esc_pout_reg_n_0__2_3685eef) : (((esc_pout_reg_n_0__2_3685eef) ? (((data_vld_reg_n_0) ? (((pop0) ? (push) : (1'b1))) : (1'b1))) : (1'b0))))));

  // Reconstructed LUT2: esc_pout_2__i_3__0_2c10111
  assign pop0 = ((empty_n_reg_0) ? (Q[2]) : (1'b1));

  // Reconstructed FDRE: esc_pout_reg_0_cd95a63
  reg recovered_19_q = 1'b0;
  assign esc_pout_reg_n_0__0_31a13ed = recovered_19_q;
  wire recovered_19_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_19_reset || (((SR) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_19_q == (esc_pout_0__i_1__1_n_0_6bb9451)))) recovered_19_q <= (esc_pout_0__i_1__1_n_0_6bb9451);
  end

  // Reconstructed FDRE: esc_pout_reg_1_325167f
  reg recovered_20_q = 1'b0;
  assign esc_pout_reg_n_0__1_307d4bf = recovered_20_q;
  wire recovered_20_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_20_reset || (((SR) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_20_q == (esc_pout_1__i_1_n_0_77ba36c)))) recovered_20_q <= (esc_pout_1__i_1_n_0_77ba36c);
  end

  // Reconstructed FDRE: esc_pout_reg_2_3108b14
  reg recovered_21_q = 1'b0;
  assign esc_pout_reg_n_0__2_3685eef = recovered_21_q;
  wire recovered_21_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_21_reset || (((SR) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_21_q == (esc_pout_2__i_1_n_0_bcda194)))) recovered_21_q <= (esc_pout_2__i_1_n_0_bcda194);
  end

endmodule

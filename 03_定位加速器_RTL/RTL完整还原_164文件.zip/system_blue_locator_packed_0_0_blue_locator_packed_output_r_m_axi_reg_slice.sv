// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_reg_slice
   (output_r_AWREADY,
    D,
    esc_state_reg_0__0_c93a5dd ,
    esc_data_p1_reg_61__0_8907fe4 ,
    SR,
    ap_clk,
    esc_ap_CS_fsm_reg_63_8ee7371 ,
    esc_ap_CS_fsm_reg_63__0_9fe4f39 ,
    Q,
    E,
    esc_ap_CS_fsm_reg_63__1_dfe60b8 ,
    esc_ap_CS_fsm_63__i_4_0_636870a ,
    rs2f_wreq_ack,
    esc_data_p2_reg_61__0_36955cb );
  output output_r_AWREADY;
  output [0:0]D;
  output [0:0]esc_state_reg_0__0_c93a5dd ;
  output [61:0]esc_data_p1_reg_61__0_8907fe4 ;
  input [0:0]SR;
  input ap_clk;
  input esc_ap_CS_fsm_reg_63_8ee7371 ;
  input esc_ap_CS_fsm_reg_63__0_9fe4f39 ;
  input [8:0]Q;
  input [0:0]E;
  input esc_ap_CS_fsm_reg_63__1_dfe60b8 ;
  input esc_ap_CS_fsm_63__i_4_0_636870a ;
  input rs2f_wreq_ack;
  input [61:0]esc_data_p2_reg_61__0_36955cb ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]D;
  wire [0:0]E;
  wire [8:0]Q;
  wire [0:0]SR;
  wire esc_ap_CS_fsm_63__i_10_n_0_e50f964 ;
  wire esc_ap_CS_fsm_63__i_4_0_636870a ;
  wire esc_ap_CS_fsm_63__i_4_n_0_e28db7b ;
  wire esc_ap_CS_fsm_reg_63_8ee7371 ;
  wire esc_ap_CS_fsm_reg_63__0_9fe4f39 ;
  wire esc_ap_CS_fsm_reg_63__1_dfe60b8 ;
  wire ap_clk;
  wire esc_data_p1_0__i_1__1_n_0_1e9e47d ;
  wire esc_data_p1_10__i_1__0_n_0_2fc61f2 ;
  wire esc_data_p1_11__i_1__0_n_0_a8dcc97 ;
  wire esc_data_p1_12__i_1__0_n_0_1783902 ;
  wire esc_data_p1_13__i_1__0_n_0_adf89df ;
  wire esc_data_p1_14__i_1__0_n_0_914606f ;
  wire esc_data_p1_15__i_1__0_n_0_8d4dd1f ;
  wire esc_data_p1_16__i_1__0_n_0_78c6a41 ;
  wire esc_data_p1_17__i_1__0_n_0_9405661 ;
  wire esc_data_p1_18__i_1__0_n_0_ae2e1d6 ;
  wire esc_data_p1_19__i_1__0_n_0_d887c68 ;
  wire esc_data_p1_1__i_1__1_n_0_88d91d3 ;
  wire esc_data_p1_20__i_1__0_n_0_34aec03 ;
  wire esc_data_p1_21__i_1__0_n_0_5813e43 ;
  wire esc_data_p1_22__i_1__0_n_0_20ab203 ;
  wire esc_data_p1_23__i_1__0_n_0_ca3d783 ;
  wire esc_data_p1_24__i_1__0_n_0_b9883b1 ;
  wire esc_data_p1_25__i_1__0_n_0_b2f6b29 ;
  wire esc_data_p1_26__i_1__0_n_0_ac9066b ;
  wire esc_data_p1_27__i_1__0_n_0_1870883 ;
  wire esc_data_p1_28__i_1__0_n_0_fb3f6a4 ;
  wire esc_data_p1_29__i_1__0_n_0_feaca4d ;
  wire esc_data_p1_2__i_1__1_n_0_70be94c ;
  wire esc_data_p1_30__i_1__0_n_0_89e1a9b ;
  wire esc_data_p1_31__i_1__0_n_0_aa43bd7 ;
  wire esc_data_p1_32__i_1__0_n_0_78215f3 ;
  wire esc_data_p1_33__i_1__0_n_0_e05cd37 ;
  wire esc_data_p1_34__i_1__0_n_0_645eadf ;
  wire esc_data_p1_35__i_1__0_n_0_cc68309 ;
  wire esc_data_p1_36__i_1__0_n_0_9a24774 ;
  wire esc_data_p1_37__i_1__0_n_0_1327dc4 ;
  wire esc_data_p1_38__i_1__0_n_0_82d9454 ;
  wire esc_data_p1_39__i_1__0_n_0_890c2b9 ;
  wire esc_data_p1_3__i_1__1_n_0_095f722 ;
  wire esc_data_p1_40__i_1__0_n_0_d965a99 ;
  wire esc_data_p1_41__i_1__0_n_0_442963b ;
  wire esc_data_p1_42__i_1__0_n_0_758bf09 ;
  wire esc_data_p1_43__i_1__0_n_0_1648e74 ;
  wire esc_data_p1_44__i_1__0_n_0_154aaa3 ;
  wire esc_data_p1_45__i_1__0_n_0_405f95b ;
  wire esc_data_p1_46__i_1__0_n_0_32018ec ;
  wire esc_data_p1_47__i_1__0_n_0_c7c152e ;
  wire esc_data_p1_48__i_1__0_n_0_c490e9c ;
  wire esc_data_p1_49__i_1__0_n_0_9184dc0 ;
  wire esc_data_p1_4__i_1__1_n_0_5743fb5 ;
  wire esc_data_p1_50__i_1__0_n_0_5dc7411 ;
  wire esc_data_p1_51__i_1__0_n_0_e0b36e2 ;
  wire esc_data_p1_52__i_1__0_n_0_b889030 ;
  wire esc_data_p1_53__i_1__0_n_0_b2b32ef ;
  wire esc_data_p1_54__i_1__0_n_0_3d23e47 ;
  wire esc_data_p1_55__i_1__0_n_0_efc59a6 ;
  wire esc_data_p1_56__i_1__0_n_0_fcb89f4 ;
  wire esc_data_p1_57__i_1__0_n_0_082b2a4 ;
  wire esc_data_p1_58__i_1__0_n_0_15a8112 ;
  wire esc_data_p1_59__i_1__0_n_0_9b2c6c7 ;
  wire esc_data_p1_5__i_1__1_n_0_2c3e2c4 ;
  wire esc_data_p1_60__i_1__0_n_0_aea389c ;
  wire esc_data_p1_61__i_2_n_0_ca3130f ;
  wire esc_data_p1_6__i_1__1_n_0_c4789c0 ;
  wire esc_data_p1_7__i_1__1_n_0_9792d35 ;
  wire esc_data_p1_8__i_1__0_n_0_6f62549 ;
  wire esc_data_p1_9__i_1__0_n_0_61e2211 ;
  wire [61:0]esc_data_p1_reg_61__0_8907fe4 ;
  wire [61:0]data_p2;
  wire [61:0]esc_data_p2_reg_61__0_36955cb ;
  wire load_p1;
  wire load_p2;
  wire [1:0]next__0;
  wire output_r_AWREADY;
  wire output_r_AWVALID;
  wire rs2f_wreq_ack;
  wire s_ready_t_i_1__1_n_0;
  wire [1:1]state;
  wire esc_state_0__i_1__1_n_0_fcb670e ;
  wire esc_state_1__i_1__1_n_0_83cc659 ;
  wire [1:0]state__0;
  wire [0:0]esc_state_reg_0__0_c93a5dd ;

  // Reconstructed LUT5: esc_FSM_sequential_state_0__i_1__1_e3f221c
  assign next__0[0] = ((rs2f_wreq_ack) ? (1'b0) : (((state__0[1]) ? (((state__0[0]) ? (1'b0) : (((Q[7]) ? (output_r_AWREADY) : (1'b0))))) : (state__0[0]))));

  // Reconstructed LUT5: esc_FSM_sequential_state_1__i_1__1_d00398a
  assign next__0[1] = ((rs2f_wreq_ack) ? (((state__0[1]) ? (((state__0[0]) ? (1'b0) : (((Q[7]) ? (output_r_AWREADY) : (1'b0))))) : (((state__0[0]) ? (1'b1) : (((Q[7]) ? (output_r_AWREADY) : (1'b0))))))) : (((state__0[1]) ? (((state__0[0]) ? (1'b0) : (((Q[7]) ? (~(output_r_AWREADY)) : (1'b1))))) : (((state__0[0]) ? (1'b0) : (((Q[7]) ? (output_r_AWREADY) : (1'b0))))))));

  // Reconstructed FDRE: esc_FSM_sequential_state_reg_0_392f9b0
  reg recovered_3_q = 1'b0;
  assign state__0[0] = recovered_3_q;
  wire recovered_3_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_3_reset || (((SR) === 1'bx) && (recovered_3_q == 1'b0))) recovered_3_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_3_q == (next__0[0])))) recovered_3_q <= (next__0[0]);
  end

  // Reconstructed FDRE: esc_FSM_sequential_state_reg_1_aa5780a
  reg recovered_4_q = 1'b0;
  assign state__0[1] = recovered_4_q;
  wire recovered_4_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_4_reset || (((SR) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (next__0[1])))) recovered_4_q <= (next__0[1]);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT5: esc_ap_CS_fsm_63__i_1_d8ca999
  assign D = ((E) ? (((esc_ap_CS_fsm_63__i_4_n_0_e28db7b) ? (1'b0) : (((esc_ap_CS_fsm_reg_63__0_9fe4f39) ? (1'b0) : (esc_ap_CS_fsm_reg_63_8ee7371))))) : (((Q[7]) ? (((esc_ap_CS_fsm_63__i_4_n_0_e28db7b) ? (1'b0) : (((esc_ap_CS_fsm_reg_63__0_9fe4f39) ? (1'b0) : (esc_ap_CS_fsm_reg_63_8ee7371))))) : (1'b0))));

  // Reconstructed LUT6: esc_ap_CS_fsm_63__i_10_b48976b
  assign esc_ap_CS_fsm_63__i_10_n_0_e50f964 = ((output_r_AWVALID) ? (1'b1) : (((esc_ap_CS_fsm_63__i_4_0_636870a) ? (((Q[5]) ? (1'b1) : (((Q[8]) ? (1'b1) : (((Q[1]) ? (1'b1) : (Q[0]))))))) : (1'b1))));

  // Reconstructed LUT2: esc_ap_CS_fsm_63__i_16_cf3996b
  assign output_r_AWVALID = ((output_r_AWREADY) ? (Q[7]) : (1'b0));

  // Reconstructed LUT6: esc_ap_CS_fsm_63__i_4_789726b
  assign esc_ap_CS_fsm_63__i_4_n_0_e28db7b = ((Q[6]) ? (1'b1) : (((Q[3]) ? (1'b1) : (((Q[4]) ? (1'b1) : (((Q[2]) ? (1'b1) : (((esc_ap_CS_fsm_reg_63__1_dfe60b8) ? (esc_ap_CS_fsm_63__i_10_n_0_e50f964) : (1'b1))))))))));

  // Reconstructed LUT4: esc_data_p1_0__i_1__1_70511af
  assign esc_data_p1_0__i_1__1_n_0_1e9e47d = ((data_p2[0]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [0]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [0]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [0]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [0]))));

  // Reconstructed LUT4: esc_data_p1_10__i_1__0_5aaf3c5
  assign esc_data_p1_10__i_1__0_n_0_2fc61f2 = ((data_p2[10]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [10]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [10]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [10]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [10]))));

  // Reconstructed LUT4: esc_data_p1_11__i_1__0_f2f17be
  assign esc_data_p1_11__i_1__0_n_0_a8dcc97 = ((data_p2[11]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [11]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [11]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [11]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [11]))));

  // Reconstructed LUT4: esc_data_p1_12__i_1__0_d0a1727
  assign esc_data_p1_12__i_1__0_n_0_1783902 = ((data_p2[12]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [12]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [12]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [12]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [12]))));

  // Reconstructed LUT4: esc_data_p1_13__i_1__0_3b2cdd7
  assign esc_data_p1_13__i_1__0_n_0_adf89df = ((data_p2[13]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [13]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [13]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [13]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [13]))));

  // Reconstructed LUT4: esc_data_p1_14__i_1__0_5cb6755
  assign esc_data_p1_14__i_1__0_n_0_914606f = ((data_p2[14]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [14]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [14]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [14]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [14]))));

  // Reconstructed LUT4: esc_data_p1_15__i_1__0_5725cf6
  assign esc_data_p1_15__i_1__0_n_0_8d4dd1f = ((data_p2[15]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [15]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [15]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [15]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [15]))));

  // Reconstructed LUT4: esc_data_p1_16__i_1__0_ad41837
  assign esc_data_p1_16__i_1__0_n_0_78c6a41 = ((data_p2[16]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [16]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [16]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [16]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [16]))));

  // Reconstructed LUT4: esc_data_p1_17__i_1__0_c49f652
  assign esc_data_p1_17__i_1__0_n_0_9405661 = ((data_p2[17]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [17]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [17]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [17]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [17]))));

  // Reconstructed LUT4: esc_data_p1_18__i_1__0_55ddcc5
  assign esc_data_p1_18__i_1__0_n_0_ae2e1d6 = ((data_p2[18]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [18]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [18]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [18]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [18]))));

  // Reconstructed LUT4: esc_data_p1_19__i_1__0_1c2348c
  assign esc_data_p1_19__i_1__0_n_0_d887c68 = ((data_p2[19]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [19]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [19]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [19]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [19]))));

  // Reconstructed LUT4: esc_data_p1_1__i_1__1_acd5136
  assign esc_data_p1_1__i_1__1_n_0_88d91d3 = ((data_p2[1]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [1]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [1]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [1]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [1]))));

  // Reconstructed LUT4: esc_data_p1_20__i_1__0_b3e7512
  assign esc_data_p1_20__i_1__0_n_0_34aec03 = ((data_p2[20]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [20]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [20]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [20]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [20]))));

  // Reconstructed LUT4: esc_data_p1_21__i_1__0_0ae403c
  assign esc_data_p1_21__i_1__0_n_0_5813e43 = ((data_p2[21]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [21]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [21]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [21]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [21]))));

  // Reconstructed LUT4: esc_data_p1_22__i_1__0_5f41680
  assign esc_data_p1_22__i_1__0_n_0_20ab203 = ((data_p2[22]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [22]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [22]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [22]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [22]))));

  // Reconstructed LUT4: esc_data_p1_23__i_1__0_66f856d
  assign esc_data_p1_23__i_1__0_n_0_ca3d783 = ((data_p2[23]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [23]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [23]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [23]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [23]))));

  // Reconstructed LUT4: esc_data_p1_24__i_1__0_1b631bf
  assign esc_data_p1_24__i_1__0_n_0_b9883b1 = ((data_p2[24]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [24]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [24]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [24]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [24]))));

  // Reconstructed LUT4: esc_data_p1_25__i_1__0_33617f3
  assign esc_data_p1_25__i_1__0_n_0_b2f6b29 = ((data_p2[25]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [25]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [25]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [25]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [25]))));

  // Reconstructed LUT4: esc_data_p1_26__i_1__0_a8cd160
  assign esc_data_p1_26__i_1__0_n_0_ac9066b = ((data_p2[26]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [26]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [26]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [26]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [26]))));

  // Reconstructed LUT4: esc_data_p1_27__i_1__0_d4ee2ce
  assign esc_data_p1_27__i_1__0_n_0_1870883 = ((data_p2[27]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [27]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [27]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [27]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [27]))));

  // Reconstructed LUT4: esc_data_p1_28__i_1__0_d0458b2
  assign esc_data_p1_28__i_1__0_n_0_fb3f6a4 = ((data_p2[28]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [28]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [28]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [28]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [28]))));

  // Reconstructed LUT4: esc_data_p1_29__i_1__0_2896c21
  assign esc_data_p1_29__i_1__0_n_0_feaca4d = ((data_p2[29]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [29]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [29]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [29]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [29]))));

  // Reconstructed LUT4: esc_data_p1_2__i_1__1_9aee495
  assign esc_data_p1_2__i_1__1_n_0_70be94c = ((data_p2[2]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [2]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [2]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [2]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [2]))));

  // Reconstructed LUT4: esc_data_p1_30__i_1__0_c421ea3
  assign esc_data_p1_30__i_1__0_n_0_89e1a9b = ((data_p2[30]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [30]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [30]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [30]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [30]))));

  // Reconstructed LUT4: esc_data_p1_31__i_1__0_0be7e6d
  assign esc_data_p1_31__i_1__0_n_0_aa43bd7 = ((data_p2[31]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [31]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [31]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [31]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [31]))));

  // Reconstructed LUT4: esc_data_p1_32__i_1__0_8ce8da1
  assign esc_data_p1_32__i_1__0_n_0_78215f3 = ((data_p2[32]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [32]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [32]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [32]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [32]))));

  // Reconstructed LUT4: esc_data_p1_33__i_1__0_8c15a1a
  assign esc_data_p1_33__i_1__0_n_0_e05cd37 = ((data_p2[33]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [33]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [33]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [33]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [33]))));

  // Reconstructed LUT4: esc_data_p1_34__i_1__0_1ac8105
  assign esc_data_p1_34__i_1__0_n_0_645eadf = ((data_p2[34]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [34]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [34]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [34]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [34]))));

  // Reconstructed LUT4: esc_data_p1_35__i_1__0_05ad353
  assign esc_data_p1_35__i_1__0_n_0_cc68309 = ((data_p2[35]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [35]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [35]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [35]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [35]))));

  // Reconstructed LUT4: esc_data_p1_36__i_1__0_aaadd53
  assign esc_data_p1_36__i_1__0_n_0_9a24774 = ((data_p2[36]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [36]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [36]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [36]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [36]))));

  // Reconstructed LUT4: esc_data_p1_37__i_1__0_b4b9adf
  assign esc_data_p1_37__i_1__0_n_0_1327dc4 = ((data_p2[37]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [37]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [37]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [37]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [37]))));

  // Reconstructed LUT4: esc_data_p1_38__i_1__0_5de3466
  assign esc_data_p1_38__i_1__0_n_0_82d9454 = ((data_p2[38]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [38]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [38]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [38]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [38]))));

  // Reconstructed LUT4: esc_data_p1_39__i_1__0_f0e8aaf
  assign esc_data_p1_39__i_1__0_n_0_890c2b9 = ((data_p2[39]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [39]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [39]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [39]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [39]))));

  // Reconstructed LUT4: esc_data_p1_3__i_1__1_9dc605d
  assign esc_data_p1_3__i_1__1_n_0_095f722 = ((data_p2[3]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [3]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [3]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [3]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [3]))));

  // Reconstructed LUT4: esc_data_p1_40__i_1__0_3d28098
  assign esc_data_p1_40__i_1__0_n_0_d965a99 = ((data_p2[40]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [40]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [40]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [40]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [40]))));

  // Reconstructed LUT4: esc_data_p1_41__i_1__0_2bcfde7
  assign esc_data_p1_41__i_1__0_n_0_442963b = ((data_p2[41]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [41]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [41]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [41]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [41]))));

  // Reconstructed LUT4: esc_data_p1_42__i_1__0_1813eac
  assign esc_data_p1_42__i_1__0_n_0_758bf09 = ((data_p2[42]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [42]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [42]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [42]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [42]))));

  // Reconstructed LUT4: esc_data_p1_43__i_1__0_1e6f2a8
  assign esc_data_p1_43__i_1__0_n_0_1648e74 = ((data_p2[43]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [43]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [43]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [43]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [43]))));

  // Reconstructed LUT4: esc_data_p1_44__i_1__0_2960ae8
  assign esc_data_p1_44__i_1__0_n_0_154aaa3 = ((data_p2[44]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [44]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [44]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [44]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [44]))));

  // Reconstructed LUT4: esc_data_p1_45__i_1__0_8b78d07
  assign esc_data_p1_45__i_1__0_n_0_405f95b = ((data_p2[45]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [45]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [45]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [45]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [45]))));

  // Reconstructed LUT4: esc_data_p1_46__i_1__0_d884d12
  assign esc_data_p1_46__i_1__0_n_0_32018ec = ((data_p2[46]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [46]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [46]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [46]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [46]))));

  // Reconstructed LUT4: esc_data_p1_47__i_1__0_d501b8f
  assign esc_data_p1_47__i_1__0_n_0_c7c152e = ((data_p2[47]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [47]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [47]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [47]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [47]))));

  // Reconstructed LUT4: esc_data_p1_48__i_1__0_f4cdf5d
  assign esc_data_p1_48__i_1__0_n_0_c490e9c = ((data_p2[48]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [48]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [48]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [48]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [48]))));

  // Reconstructed LUT4: esc_data_p1_49__i_1__0_4e65874
  assign esc_data_p1_49__i_1__0_n_0_9184dc0 = ((data_p2[49]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [49]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [49]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [49]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [49]))));

  // Reconstructed LUT4: esc_data_p1_4__i_1__1_fa9a656
  assign esc_data_p1_4__i_1__1_n_0_5743fb5 = ((data_p2[4]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [4]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [4]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [4]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [4]))));

  // Reconstructed LUT4: esc_data_p1_50__i_1__0_6aa90ee
  assign esc_data_p1_50__i_1__0_n_0_5dc7411 = ((data_p2[50]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [50]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [50]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [50]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [50]))));

  // Reconstructed LUT4: esc_data_p1_51__i_1__0_bfb9779
  assign esc_data_p1_51__i_1__0_n_0_e0b36e2 = ((data_p2[51]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [51]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [51]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [51]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [51]))));

  // Reconstructed LUT4: esc_data_p1_52__i_1__0_ec6f846
  assign esc_data_p1_52__i_1__0_n_0_b889030 = ((data_p2[52]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [52]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [52]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [52]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [52]))));

  // Reconstructed LUT4: esc_data_p1_53__i_1__0_382718b
  assign esc_data_p1_53__i_1__0_n_0_b2b32ef = ((data_p2[53]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [53]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [53]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [53]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [53]))));

  // Reconstructed LUT4: esc_data_p1_54__i_1__0_6efa988
  assign esc_data_p1_54__i_1__0_n_0_3d23e47 = ((data_p2[54]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [54]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [54]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [54]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [54]))));

  // Reconstructed LUT4: esc_data_p1_55__i_1__0_ef1088f
  assign esc_data_p1_55__i_1__0_n_0_efc59a6 = ((data_p2[55]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [55]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [55]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [55]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [55]))));

  // Reconstructed LUT4: esc_data_p1_56__i_1__0_95afc57
  assign esc_data_p1_56__i_1__0_n_0_fcb89f4 = ((data_p2[56]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [56]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [56]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [56]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [56]))));

  // Reconstructed LUT4: esc_data_p1_57__i_1__0_0a5e76a
  assign esc_data_p1_57__i_1__0_n_0_082b2a4 = ((data_p2[57]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [57]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [57]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [57]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [57]))));

  // Reconstructed LUT4: esc_data_p1_58__i_1__0_808e0cf
  assign esc_data_p1_58__i_1__0_n_0_15a8112 = ((data_p2[58]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [58]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [58]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [58]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [58]))));

  // Reconstructed LUT4: esc_data_p1_59__i_1__0_2b3d61d
  assign esc_data_p1_59__i_1__0_n_0_9b2c6c7 = ((data_p2[59]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [59]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [59]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [59]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [59]))));

  // Reconstructed LUT4: esc_data_p1_5__i_1__1_7df2a77
  assign esc_data_p1_5__i_1__1_n_0_2c3e2c4 = ((data_p2[5]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [5]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [5]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [5]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [5]))));

  // Reconstructed LUT4: esc_data_p1_60__i_1__0_95d2529
  assign esc_data_p1_60__i_1__0_n_0_aea389c = ((data_p2[60]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [60]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [60]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [60]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [60]))));

  // Reconstructed LUT5: esc_data_p1_61__i_1__0_f0fe96a
  assign load_p1 = ((Q[7]) ? (((output_r_AWREADY) ? (((state__0[0]) ? (((rs2f_wreq_ack) ? (~(state__0[1])) : (1'b0))) : (((rs2f_wreq_ack) ? (1'b1) : (~(state__0[1])))))) : (((state__0[0]) ? (((rs2f_wreq_ack) ? (~(state__0[1])) : (1'b0))) : (1'b0))))) : (((state__0[0]) ? (((rs2f_wreq_ack) ? (~(state__0[1])) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: esc_data_p1_61__i_2_4edc44e
  assign esc_data_p1_61__i_2_n_0_ca3130f = ((data_p2[61]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [61]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [61]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [61]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [61]))));

  // Reconstructed LUT4: esc_data_p1_6__i_1__1_4dbc229
  assign esc_data_p1_6__i_1__1_n_0_c4789c0 = ((data_p2[6]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [6]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [6]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [6]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [6]))));

  // Reconstructed LUT4: esc_data_p1_7__i_1__1_1ed7b16
  assign esc_data_p1_7__i_1__1_n_0_9792d35 = ((data_p2[7]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [7]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [7]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [7]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [7]))));

  // Reconstructed LUT4: esc_data_p1_8__i_1__0_e02ba2b
  assign esc_data_p1_8__i_1__0_n_0_6f62549 = ((data_p2[8]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [8]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [8]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [8]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [8]))));

  // Reconstructed LUT4: esc_data_p1_9__i_1__0_51d0be5
  assign esc_data_p1_9__i_1__0_n_0_61e2211 = ((data_p2[9]) ? (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [9]) : (1'b1))) : (esc_data_p2_reg_61__0_36955cb [9]))) : (((state__0[0]) ? (((state__0[1]) ? (esc_data_p2_reg_61__0_36955cb [9]) : (1'b0))) : (esc_data_p2_reg_61__0_36955cb [9]))));

  // Reconstructed FDRE: esc_data_p1_reg_0_91510d9
  reg recovered_74_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [0] = recovered_74_q;
  wire recovered_74_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_74_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_74_q == 1'b0))) recovered_74_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_74_q == (esc_data_p1_0__i_1__1_n_0_1e9e47d)))) recovered_74_q <= (esc_data_p1_0__i_1__1_n_0_1e9e47d);
  end

  // Reconstructed FDRE: esc_data_p1_reg_10_b99998e
  reg recovered_75_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [10] = recovered_75_q;
  wire recovered_75_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_75_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_75_q == 1'b0))) recovered_75_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_75_q == (esc_data_p1_10__i_1__0_n_0_2fc61f2)))) recovered_75_q <= (esc_data_p1_10__i_1__0_n_0_2fc61f2);
  end

  // Reconstructed FDRE: esc_data_p1_reg_11_1b83162
  reg recovered_76_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [11] = recovered_76_q;
  wire recovered_76_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_76_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_76_q == 1'b0))) recovered_76_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_76_q == (esc_data_p1_11__i_1__0_n_0_a8dcc97)))) recovered_76_q <= (esc_data_p1_11__i_1__0_n_0_a8dcc97);
  end

  // Reconstructed FDRE: esc_data_p1_reg_12_96523bc
  reg recovered_77_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [12] = recovered_77_q;
  wire recovered_77_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_77_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_77_q == 1'b0))) recovered_77_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_77_q == (esc_data_p1_12__i_1__0_n_0_1783902)))) recovered_77_q <= (esc_data_p1_12__i_1__0_n_0_1783902);
  end

  // Reconstructed FDRE: esc_data_p1_reg_13_0d69515
  reg recovered_78_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [13] = recovered_78_q;
  wire recovered_78_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_78_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_78_q == 1'b0))) recovered_78_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_78_q == (esc_data_p1_13__i_1__0_n_0_adf89df)))) recovered_78_q <= (esc_data_p1_13__i_1__0_n_0_adf89df);
  end

  // Reconstructed FDRE: esc_data_p1_reg_14_40953fa
  reg recovered_79_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [14] = recovered_79_q;
  wire recovered_79_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_79_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_79_q == 1'b0))) recovered_79_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_79_q == (esc_data_p1_14__i_1__0_n_0_914606f)))) recovered_79_q <= (esc_data_p1_14__i_1__0_n_0_914606f);
  end

  // Reconstructed FDRE: esc_data_p1_reg_15_9ed2026
  reg recovered_80_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [15] = recovered_80_q;
  wire recovered_80_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_80_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_80_q == 1'b0))) recovered_80_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_80_q == (esc_data_p1_15__i_1__0_n_0_8d4dd1f)))) recovered_80_q <= (esc_data_p1_15__i_1__0_n_0_8d4dd1f);
  end

  // Reconstructed FDRE: esc_data_p1_reg_16_6dd0cb2
  reg recovered_81_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [16] = recovered_81_q;
  wire recovered_81_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_81_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_81_q == 1'b0))) recovered_81_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_81_q == (esc_data_p1_16__i_1__0_n_0_78c6a41)))) recovered_81_q <= (esc_data_p1_16__i_1__0_n_0_78c6a41);
  end

  // Reconstructed FDRE: esc_data_p1_reg_17_da0fb0e
  reg recovered_82_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [17] = recovered_82_q;
  wire recovered_82_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_82_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_82_q == 1'b0))) recovered_82_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_82_q == (esc_data_p1_17__i_1__0_n_0_9405661)))) recovered_82_q <= (esc_data_p1_17__i_1__0_n_0_9405661);
  end

  // Reconstructed FDRE: esc_data_p1_reg_18_e139988
  reg recovered_83_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [18] = recovered_83_q;
  wire recovered_83_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_83_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_83_q == 1'b0))) recovered_83_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_83_q == (esc_data_p1_18__i_1__0_n_0_ae2e1d6)))) recovered_83_q <= (esc_data_p1_18__i_1__0_n_0_ae2e1d6);
  end

  // Reconstructed FDRE: esc_data_p1_reg_19_89de483
  reg recovered_84_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [19] = recovered_84_q;
  wire recovered_84_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_84_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_84_q == 1'b0))) recovered_84_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_84_q == (esc_data_p1_19__i_1__0_n_0_d887c68)))) recovered_84_q <= (esc_data_p1_19__i_1__0_n_0_d887c68);
  end

  // Reconstructed FDRE: esc_data_p1_reg_1_70ed420
  reg recovered_85_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [1] = recovered_85_q;
  wire recovered_85_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_85_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_85_q == 1'b0))) recovered_85_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_85_q == (esc_data_p1_1__i_1__1_n_0_88d91d3)))) recovered_85_q <= (esc_data_p1_1__i_1__1_n_0_88d91d3);
  end

  // Reconstructed FDRE: esc_data_p1_reg_20_35bac97
  reg recovered_86_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [20] = recovered_86_q;
  wire recovered_86_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_86_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_86_q == 1'b0))) recovered_86_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_86_q == (esc_data_p1_20__i_1__0_n_0_34aec03)))) recovered_86_q <= (esc_data_p1_20__i_1__0_n_0_34aec03);
  end

  // Reconstructed FDRE: esc_data_p1_reg_21_1245b5c
  reg recovered_87_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [21] = recovered_87_q;
  wire recovered_87_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_87_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_87_q == 1'b0))) recovered_87_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_87_q == (esc_data_p1_21__i_1__0_n_0_5813e43)))) recovered_87_q <= (esc_data_p1_21__i_1__0_n_0_5813e43);
  end

  // Reconstructed FDRE: esc_data_p1_reg_22_8639ba0
  reg recovered_88_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [22] = recovered_88_q;
  wire recovered_88_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_88_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_88_q == 1'b0))) recovered_88_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_88_q == (esc_data_p1_22__i_1__0_n_0_20ab203)))) recovered_88_q <= (esc_data_p1_22__i_1__0_n_0_20ab203);
  end

  // Reconstructed FDRE: esc_data_p1_reg_23_102c188
  reg recovered_89_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [23] = recovered_89_q;
  wire recovered_89_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_89_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_89_q == 1'b0))) recovered_89_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_89_q == (esc_data_p1_23__i_1__0_n_0_ca3d783)))) recovered_89_q <= (esc_data_p1_23__i_1__0_n_0_ca3d783);
  end

  // Reconstructed FDRE: esc_data_p1_reg_24_4de98a5
  reg recovered_90_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [24] = recovered_90_q;
  wire recovered_90_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_90_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_90_q == 1'b0))) recovered_90_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_90_q == (esc_data_p1_24__i_1__0_n_0_b9883b1)))) recovered_90_q <= (esc_data_p1_24__i_1__0_n_0_b9883b1);
  end

  // Reconstructed FDRE: esc_data_p1_reg_25_7e72b74
  reg recovered_91_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [25] = recovered_91_q;
  wire recovered_91_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_91_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_91_q == 1'b0))) recovered_91_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_91_q == (esc_data_p1_25__i_1__0_n_0_b2f6b29)))) recovered_91_q <= (esc_data_p1_25__i_1__0_n_0_b2f6b29);
  end

  // Reconstructed FDRE: esc_data_p1_reg_26_9845396
  reg recovered_92_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [26] = recovered_92_q;
  wire recovered_92_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_92_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_92_q == 1'b0))) recovered_92_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_92_q == (esc_data_p1_26__i_1__0_n_0_ac9066b)))) recovered_92_q <= (esc_data_p1_26__i_1__0_n_0_ac9066b);
  end

  // Reconstructed FDRE: esc_data_p1_reg_27_7634f47
  reg recovered_93_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [27] = recovered_93_q;
  wire recovered_93_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_93_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_93_q == 1'b0))) recovered_93_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_93_q == (esc_data_p1_27__i_1__0_n_0_1870883)))) recovered_93_q <= (esc_data_p1_27__i_1__0_n_0_1870883);
  end

  // Reconstructed FDRE: esc_data_p1_reg_28_516b5d9
  reg recovered_94_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [28] = recovered_94_q;
  wire recovered_94_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_94_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_94_q == 1'b0))) recovered_94_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_94_q == (esc_data_p1_28__i_1__0_n_0_fb3f6a4)))) recovered_94_q <= (esc_data_p1_28__i_1__0_n_0_fb3f6a4);
  end

  // Reconstructed FDRE: esc_data_p1_reg_29_818ed37
  reg recovered_95_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [29] = recovered_95_q;
  wire recovered_95_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_95_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_95_q == 1'b0))) recovered_95_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_95_q == (esc_data_p1_29__i_1__0_n_0_feaca4d)))) recovered_95_q <= (esc_data_p1_29__i_1__0_n_0_feaca4d);
  end

  // Reconstructed FDRE: esc_data_p1_reg_2_9d3c15b
  reg recovered_96_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [2] = recovered_96_q;
  wire recovered_96_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_96_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_96_q == 1'b0))) recovered_96_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_96_q == (esc_data_p1_2__i_1__1_n_0_70be94c)))) recovered_96_q <= (esc_data_p1_2__i_1__1_n_0_70be94c);
  end

  // Reconstructed FDRE: esc_data_p1_reg_30_f57e427
  reg recovered_97_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [30] = recovered_97_q;
  wire recovered_97_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_97_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_97_q == 1'b0))) recovered_97_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_97_q == (esc_data_p1_30__i_1__0_n_0_89e1a9b)))) recovered_97_q <= (esc_data_p1_30__i_1__0_n_0_89e1a9b);
  end

  // Reconstructed FDRE: esc_data_p1_reg_31_5599d56
  reg recovered_98_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [31] = recovered_98_q;
  wire recovered_98_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_98_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_98_q == 1'b0))) recovered_98_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_98_q == (esc_data_p1_31__i_1__0_n_0_aa43bd7)))) recovered_98_q <= (esc_data_p1_31__i_1__0_n_0_aa43bd7);
  end

  // Reconstructed FDRE: esc_data_p1_reg_32_599eaae
  reg recovered_99_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [32] = recovered_99_q;
  wire recovered_99_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_99_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_99_q == 1'b0))) recovered_99_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_99_q == (esc_data_p1_32__i_1__0_n_0_78215f3)))) recovered_99_q <= (esc_data_p1_32__i_1__0_n_0_78215f3);
  end

  // Reconstructed FDRE: esc_data_p1_reg_33_015c8f1
  reg recovered_100_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [33] = recovered_100_q;
  wire recovered_100_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_100_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_100_q == 1'b0))) recovered_100_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_100_q == (esc_data_p1_33__i_1__0_n_0_e05cd37)))) recovered_100_q <= (esc_data_p1_33__i_1__0_n_0_e05cd37);
  end

  // Reconstructed FDRE: esc_data_p1_reg_34_340fffc
  reg recovered_101_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [34] = recovered_101_q;
  wire recovered_101_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_101_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_101_q == 1'b0))) recovered_101_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_101_q == (esc_data_p1_34__i_1__0_n_0_645eadf)))) recovered_101_q <= (esc_data_p1_34__i_1__0_n_0_645eadf);
  end

  // Reconstructed FDRE: esc_data_p1_reg_35_593bddb
  reg recovered_102_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [35] = recovered_102_q;
  wire recovered_102_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_102_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_102_q == 1'b0))) recovered_102_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_102_q == (esc_data_p1_35__i_1__0_n_0_cc68309)))) recovered_102_q <= (esc_data_p1_35__i_1__0_n_0_cc68309);
  end

  // Reconstructed FDRE: esc_data_p1_reg_36_f8c7eac
  reg recovered_103_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [36] = recovered_103_q;
  wire recovered_103_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_103_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_103_q == 1'b0))) recovered_103_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_103_q == (esc_data_p1_36__i_1__0_n_0_9a24774)))) recovered_103_q <= (esc_data_p1_36__i_1__0_n_0_9a24774);
  end

  // Reconstructed FDRE: esc_data_p1_reg_37_a884e5c
  reg recovered_104_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [37] = recovered_104_q;
  wire recovered_104_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_104_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_104_q == 1'b0))) recovered_104_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_104_q == (esc_data_p1_37__i_1__0_n_0_1327dc4)))) recovered_104_q <= (esc_data_p1_37__i_1__0_n_0_1327dc4);
  end

  // Reconstructed FDRE: esc_data_p1_reg_38_a5b769f
  reg recovered_105_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [38] = recovered_105_q;
  wire recovered_105_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_105_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_105_q == 1'b0))) recovered_105_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_105_q == (esc_data_p1_38__i_1__0_n_0_82d9454)))) recovered_105_q <= (esc_data_p1_38__i_1__0_n_0_82d9454);
  end

  // Reconstructed FDRE: esc_data_p1_reg_39_7dfc81d
  reg recovered_106_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [39] = recovered_106_q;
  wire recovered_106_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_106_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_106_q == 1'b0))) recovered_106_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_106_q == (esc_data_p1_39__i_1__0_n_0_890c2b9)))) recovered_106_q <= (esc_data_p1_39__i_1__0_n_0_890c2b9);
  end

  // Reconstructed FDRE: esc_data_p1_reg_3_1b46385
  reg recovered_107_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [3] = recovered_107_q;
  wire recovered_107_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_107_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_107_q == 1'b0))) recovered_107_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_107_q == (esc_data_p1_3__i_1__1_n_0_095f722)))) recovered_107_q <= (esc_data_p1_3__i_1__1_n_0_095f722);
  end

  // Reconstructed FDRE: esc_data_p1_reg_40_98e1b59
  reg recovered_108_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [40] = recovered_108_q;
  wire recovered_108_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_108_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_108_q == 1'b0))) recovered_108_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_108_q == (esc_data_p1_40__i_1__0_n_0_d965a99)))) recovered_108_q <= (esc_data_p1_40__i_1__0_n_0_d965a99);
  end

  // Reconstructed FDRE: esc_data_p1_reg_41_da9b4c6
  reg recovered_109_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [41] = recovered_109_q;
  wire recovered_109_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_109_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_109_q == 1'b0))) recovered_109_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_109_q == (esc_data_p1_41__i_1__0_n_0_442963b)))) recovered_109_q <= (esc_data_p1_41__i_1__0_n_0_442963b);
  end

  // Reconstructed FDRE: esc_data_p1_reg_42_5f2276c
  reg recovered_110_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [42] = recovered_110_q;
  wire recovered_110_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_110_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_110_q == 1'b0))) recovered_110_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_110_q == (esc_data_p1_42__i_1__0_n_0_758bf09)))) recovered_110_q <= (esc_data_p1_42__i_1__0_n_0_758bf09);
  end

  // Reconstructed FDRE: esc_data_p1_reg_43_a884eb6
  reg recovered_111_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [43] = recovered_111_q;
  wire recovered_111_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_111_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_111_q == 1'b0))) recovered_111_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_111_q == (esc_data_p1_43__i_1__0_n_0_1648e74)))) recovered_111_q <= (esc_data_p1_43__i_1__0_n_0_1648e74);
  end

  // Reconstructed FDRE: esc_data_p1_reg_44_6a87874
  reg recovered_112_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [44] = recovered_112_q;
  wire recovered_112_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_112_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_112_q == 1'b0))) recovered_112_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_112_q == (esc_data_p1_44__i_1__0_n_0_154aaa3)))) recovered_112_q <= (esc_data_p1_44__i_1__0_n_0_154aaa3);
  end

  // Reconstructed FDRE: esc_data_p1_reg_45_99af2a3
  reg recovered_113_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [45] = recovered_113_q;
  wire recovered_113_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_113_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_113_q == 1'b0))) recovered_113_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_113_q == (esc_data_p1_45__i_1__0_n_0_405f95b)))) recovered_113_q <= (esc_data_p1_45__i_1__0_n_0_405f95b);
  end

  // Reconstructed FDRE: esc_data_p1_reg_46_87eac4b
  reg recovered_114_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [46] = recovered_114_q;
  wire recovered_114_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_114_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_114_q == 1'b0))) recovered_114_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_114_q == (esc_data_p1_46__i_1__0_n_0_32018ec)))) recovered_114_q <= (esc_data_p1_46__i_1__0_n_0_32018ec);
  end

  // Reconstructed FDRE: esc_data_p1_reg_47_5bd7eaa
  reg recovered_115_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [47] = recovered_115_q;
  wire recovered_115_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_115_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_115_q == 1'b0))) recovered_115_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_115_q == (esc_data_p1_47__i_1__0_n_0_c7c152e)))) recovered_115_q <= (esc_data_p1_47__i_1__0_n_0_c7c152e);
  end

  // Reconstructed FDRE: esc_data_p1_reg_48_f41191e
  reg recovered_116_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [48] = recovered_116_q;
  wire recovered_116_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_116_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_116_q == 1'b0))) recovered_116_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_116_q == (esc_data_p1_48__i_1__0_n_0_c490e9c)))) recovered_116_q <= (esc_data_p1_48__i_1__0_n_0_c490e9c);
  end

  // Reconstructed FDRE: esc_data_p1_reg_49_f0a21ba
  reg recovered_117_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [49] = recovered_117_q;
  wire recovered_117_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_117_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_117_q == 1'b0))) recovered_117_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_117_q == (esc_data_p1_49__i_1__0_n_0_9184dc0)))) recovered_117_q <= (esc_data_p1_49__i_1__0_n_0_9184dc0);
  end

  // Reconstructed FDRE: esc_data_p1_reg_4_edde18b
  reg recovered_118_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [4] = recovered_118_q;
  wire recovered_118_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_118_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_118_q == 1'b0))) recovered_118_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_118_q == (esc_data_p1_4__i_1__1_n_0_5743fb5)))) recovered_118_q <= (esc_data_p1_4__i_1__1_n_0_5743fb5);
  end

  // Reconstructed FDRE: esc_data_p1_reg_50_e525f0f
  reg recovered_119_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [50] = recovered_119_q;
  wire recovered_119_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_119_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_119_q == 1'b0))) recovered_119_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_119_q == (esc_data_p1_50__i_1__0_n_0_5dc7411)))) recovered_119_q <= (esc_data_p1_50__i_1__0_n_0_5dc7411);
  end

  // Reconstructed FDRE: esc_data_p1_reg_51_8ae63b0
  reg recovered_120_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [51] = recovered_120_q;
  wire recovered_120_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_120_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_120_q == 1'b0))) recovered_120_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_120_q == (esc_data_p1_51__i_1__0_n_0_e0b36e2)))) recovered_120_q <= (esc_data_p1_51__i_1__0_n_0_e0b36e2);
  end

  // Reconstructed FDRE: esc_data_p1_reg_52_d0ab373
  reg recovered_121_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [52] = recovered_121_q;
  wire recovered_121_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_121_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_121_q == 1'b0))) recovered_121_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_121_q == (esc_data_p1_52__i_1__0_n_0_b889030)))) recovered_121_q <= (esc_data_p1_52__i_1__0_n_0_b889030);
  end

  // Reconstructed FDRE: esc_data_p1_reg_53_d932ad2
  reg recovered_122_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [53] = recovered_122_q;
  wire recovered_122_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_122_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_122_q == 1'b0))) recovered_122_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_122_q == (esc_data_p1_53__i_1__0_n_0_b2b32ef)))) recovered_122_q <= (esc_data_p1_53__i_1__0_n_0_b2b32ef);
  end

  // Reconstructed FDRE: esc_data_p1_reg_54_2cd75bb
  reg recovered_123_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [54] = recovered_123_q;
  wire recovered_123_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_123_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_123_q == 1'b0))) recovered_123_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_123_q == (esc_data_p1_54__i_1__0_n_0_3d23e47)))) recovered_123_q <= (esc_data_p1_54__i_1__0_n_0_3d23e47);
  end

  // Reconstructed FDRE: esc_data_p1_reg_55_c04b6c4
  reg recovered_124_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [55] = recovered_124_q;
  wire recovered_124_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_124_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_124_q == 1'b0))) recovered_124_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_124_q == (esc_data_p1_55__i_1__0_n_0_efc59a6)))) recovered_124_q <= (esc_data_p1_55__i_1__0_n_0_efc59a6);
  end

  // Reconstructed FDRE: esc_data_p1_reg_56_55a557b
  reg recovered_125_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [56] = recovered_125_q;
  wire recovered_125_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_125_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_125_q == 1'b0))) recovered_125_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_125_q == (esc_data_p1_56__i_1__0_n_0_fcb89f4)))) recovered_125_q <= (esc_data_p1_56__i_1__0_n_0_fcb89f4);
  end

  // Reconstructed FDRE: esc_data_p1_reg_57_beea773
  reg recovered_126_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [57] = recovered_126_q;
  wire recovered_126_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_126_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_126_q == 1'b0))) recovered_126_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_126_q == (esc_data_p1_57__i_1__0_n_0_082b2a4)))) recovered_126_q <= (esc_data_p1_57__i_1__0_n_0_082b2a4);
  end

  // Reconstructed FDRE: esc_data_p1_reg_58_a8276af
  reg recovered_127_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [58] = recovered_127_q;
  wire recovered_127_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_127_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_127_q == 1'b0))) recovered_127_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_127_q == (esc_data_p1_58__i_1__0_n_0_15a8112)))) recovered_127_q <= (esc_data_p1_58__i_1__0_n_0_15a8112);
  end

  // Reconstructed FDRE: esc_data_p1_reg_59_7a7e4d4
  reg recovered_128_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [59] = recovered_128_q;
  wire recovered_128_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_128_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_128_q == 1'b0))) recovered_128_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_128_q == (esc_data_p1_59__i_1__0_n_0_9b2c6c7)))) recovered_128_q <= (esc_data_p1_59__i_1__0_n_0_9b2c6c7);
  end

  // Reconstructed FDRE: esc_data_p1_reg_5_2278d12
  reg recovered_129_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [5] = recovered_129_q;
  wire recovered_129_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_129_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_129_q == 1'b0))) recovered_129_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_129_q == (esc_data_p1_5__i_1__1_n_0_2c3e2c4)))) recovered_129_q <= (esc_data_p1_5__i_1__1_n_0_2c3e2c4);
  end

  // Reconstructed FDRE: esc_data_p1_reg_60_80f7dc5
  reg recovered_130_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [60] = recovered_130_q;
  wire recovered_130_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_130_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_130_q == 1'b0))) recovered_130_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_130_q == (esc_data_p1_60__i_1__0_n_0_aea389c)))) recovered_130_q <= (esc_data_p1_60__i_1__0_n_0_aea389c);
  end

  // Reconstructed FDRE: esc_data_p1_reg_61_0cb8739
  reg recovered_131_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [61] = recovered_131_q;
  wire recovered_131_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_131_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_131_q == 1'b0))) recovered_131_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_131_q == (esc_data_p1_61__i_2_n_0_ca3130f)))) recovered_131_q <= (esc_data_p1_61__i_2_n_0_ca3130f);
  end

  // Reconstructed FDRE: esc_data_p1_reg_6_f08fb72
  reg recovered_132_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [6] = recovered_132_q;
  wire recovered_132_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_132_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_132_q == 1'b0))) recovered_132_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_132_q == (esc_data_p1_6__i_1__1_n_0_c4789c0)))) recovered_132_q <= (esc_data_p1_6__i_1__1_n_0_c4789c0);
  end

  // Reconstructed FDRE: esc_data_p1_reg_7_98a71bc
  reg recovered_133_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [7] = recovered_133_q;
  wire recovered_133_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_133_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_133_q == 1'b0))) recovered_133_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_133_q == (esc_data_p1_7__i_1__1_n_0_9792d35)))) recovered_133_q <= (esc_data_p1_7__i_1__1_n_0_9792d35);
  end

  // Reconstructed FDRE: esc_data_p1_reg_8_3a36cac
  reg recovered_134_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [8] = recovered_134_q;
  wire recovered_134_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_134_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_134_q == 1'b0))) recovered_134_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_134_q == (esc_data_p1_8__i_1__0_n_0_6f62549)))) recovered_134_q <= (esc_data_p1_8__i_1__0_n_0_6f62549);
  end

  // Reconstructed FDRE: esc_data_p1_reg_9_9c5afbd
  reg recovered_135_q = 1'b0;
  assign esc_data_p1_reg_61__0_8907fe4 [9] = recovered_135_q;
  wire recovered_135_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_135_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_135_q == 1'b0))) recovered_135_q <= 1'b0;
    else if ((load_p1) || ((load_p1) === 1'bz) || (((load_p1) === 1'bx) && (recovered_135_q == (esc_data_p1_9__i_1__0_n_0_61e2211)))) recovered_135_q <= (esc_data_p1_9__i_1__0_n_0_61e2211);
  end

  // Reconstructed LUT2: esc_data_p2_61__i_1_c0f37f0
  assign load_p2 = ((Q[7]) ? (output_r_AWREADY) : (1'b0));

  // Reconstructed FDRE: esc_data_p2_reg_0_abd518c
  reg recovered_137_q = 1'b0;
  assign data_p2[0] = recovered_137_q;
  wire recovered_137_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_137_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_137_q == 1'b0))) recovered_137_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_137_q == (esc_data_p2_reg_61__0_36955cb [0])))) recovered_137_q <= (esc_data_p2_reg_61__0_36955cb [0]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_10_28dcc1e
  reg recovered_138_q = 1'b0;
  assign data_p2[10] = recovered_138_q;
  wire recovered_138_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_138_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_138_q == 1'b0))) recovered_138_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_138_q == (esc_data_p2_reg_61__0_36955cb [10])))) recovered_138_q <= (esc_data_p2_reg_61__0_36955cb [10]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_11_81b24b5
  reg recovered_139_q = 1'b0;
  assign data_p2[11] = recovered_139_q;
  wire recovered_139_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_139_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_139_q == 1'b0))) recovered_139_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_139_q == (esc_data_p2_reg_61__0_36955cb [11])))) recovered_139_q <= (esc_data_p2_reg_61__0_36955cb [11]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_12_0b84e50
  reg recovered_140_q = 1'b0;
  assign data_p2[12] = recovered_140_q;
  wire recovered_140_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_140_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_140_q == 1'b0))) recovered_140_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_140_q == (esc_data_p2_reg_61__0_36955cb [12])))) recovered_140_q <= (esc_data_p2_reg_61__0_36955cb [12]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_13_b136b27
  reg recovered_141_q = 1'b0;
  assign data_p2[13] = recovered_141_q;
  wire recovered_141_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_141_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_141_q == 1'b0))) recovered_141_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_141_q == (esc_data_p2_reg_61__0_36955cb [13])))) recovered_141_q <= (esc_data_p2_reg_61__0_36955cb [13]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_14_fc71e57
  reg recovered_142_q = 1'b0;
  assign data_p2[14] = recovered_142_q;
  wire recovered_142_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_142_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_142_q == 1'b0))) recovered_142_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_142_q == (esc_data_p2_reg_61__0_36955cb [14])))) recovered_142_q <= (esc_data_p2_reg_61__0_36955cb [14]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_15_d01f9d0
  reg recovered_143_q = 1'b0;
  assign data_p2[15] = recovered_143_q;
  wire recovered_143_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_143_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_143_q == 1'b0))) recovered_143_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_143_q == (esc_data_p2_reg_61__0_36955cb [15])))) recovered_143_q <= (esc_data_p2_reg_61__0_36955cb [15]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_16_16a4fc4
  reg recovered_144_q = 1'b0;
  assign data_p2[16] = recovered_144_q;
  wire recovered_144_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_144_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_144_q == 1'b0))) recovered_144_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_144_q == (esc_data_p2_reg_61__0_36955cb [16])))) recovered_144_q <= (esc_data_p2_reg_61__0_36955cb [16]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_17_6dc67b6
  reg recovered_145_q = 1'b0;
  assign data_p2[17] = recovered_145_q;
  wire recovered_145_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_145_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_145_q == 1'b0))) recovered_145_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_145_q == (esc_data_p2_reg_61__0_36955cb [17])))) recovered_145_q <= (esc_data_p2_reg_61__0_36955cb [17]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_18_9126a82
  reg recovered_146_q = 1'b0;
  assign data_p2[18] = recovered_146_q;
  wire recovered_146_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_146_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_146_q == 1'b0))) recovered_146_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_146_q == (esc_data_p2_reg_61__0_36955cb [18])))) recovered_146_q <= (esc_data_p2_reg_61__0_36955cb [18]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_19_e77ec78
  reg recovered_147_q = 1'b0;
  assign data_p2[19] = recovered_147_q;
  wire recovered_147_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_147_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_147_q == 1'b0))) recovered_147_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_147_q == (esc_data_p2_reg_61__0_36955cb [19])))) recovered_147_q <= (esc_data_p2_reg_61__0_36955cb [19]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_1_c9ae331
  reg recovered_148_q = 1'b0;
  assign data_p2[1] = recovered_148_q;
  wire recovered_148_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_148_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_148_q == 1'b0))) recovered_148_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_148_q == (esc_data_p2_reg_61__0_36955cb [1])))) recovered_148_q <= (esc_data_p2_reg_61__0_36955cb [1]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_20_62776cd
  reg recovered_149_q = 1'b0;
  assign data_p2[20] = recovered_149_q;
  wire recovered_149_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_149_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_149_q == 1'b0))) recovered_149_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_149_q == (esc_data_p2_reg_61__0_36955cb [20])))) recovered_149_q <= (esc_data_p2_reg_61__0_36955cb [20]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_21_b6e4de8
  reg recovered_150_q = 1'b0;
  assign data_p2[21] = recovered_150_q;
  wire recovered_150_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_150_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_150_q == 1'b0))) recovered_150_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_150_q == (esc_data_p2_reg_61__0_36955cb [21])))) recovered_150_q <= (esc_data_p2_reg_61__0_36955cb [21]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_22_a05d5ec
  reg recovered_151_q = 1'b0;
  assign data_p2[22] = recovered_151_q;
  wire recovered_151_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_151_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_151_q == 1'b0))) recovered_151_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_151_q == (esc_data_p2_reg_61__0_36955cb [22])))) recovered_151_q <= (esc_data_p2_reg_61__0_36955cb [22]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_23_0d92bcf
  reg recovered_152_q = 1'b0;
  assign data_p2[23] = recovered_152_q;
  wire recovered_152_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_152_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_152_q == 1'b0))) recovered_152_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_152_q == (esc_data_p2_reg_61__0_36955cb [23])))) recovered_152_q <= (esc_data_p2_reg_61__0_36955cb [23]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_24_08435a2
  reg recovered_153_q = 1'b0;
  assign data_p2[24] = recovered_153_q;
  wire recovered_153_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_153_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_153_q == 1'b0))) recovered_153_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_153_q == (esc_data_p2_reg_61__0_36955cb [24])))) recovered_153_q <= (esc_data_p2_reg_61__0_36955cb [24]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_25_bc3deb4
  reg recovered_154_q = 1'b0;
  assign data_p2[25] = recovered_154_q;
  wire recovered_154_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_154_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_154_q == 1'b0))) recovered_154_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_154_q == (esc_data_p2_reg_61__0_36955cb [25])))) recovered_154_q <= (esc_data_p2_reg_61__0_36955cb [25]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_26_26fcb01
  reg recovered_155_q = 1'b0;
  assign data_p2[26] = recovered_155_q;
  wire recovered_155_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_155_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_155_q == 1'b0))) recovered_155_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_155_q == (esc_data_p2_reg_61__0_36955cb [26])))) recovered_155_q <= (esc_data_p2_reg_61__0_36955cb [26]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_27_c5e60b1
  reg recovered_156_q = 1'b0;
  assign data_p2[27] = recovered_156_q;
  wire recovered_156_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_156_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_156_q == 1'b0))) recovered_156_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_156_q == (esc_data_p2_reg_61__0_36955cb [27])))) recovered_156_q <= (esc_data_p2_reg_61__0_36955cb [27]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_28_e572bf1
  reg recovered_157_q = 1'b0;
  assign data_p2[28] = recovered_157_q;
  wire recovered_157_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_157_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_157_q == 1'b0))) recovered_157_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_157_q == (esc_data_p2_reg_61__0_36955cb [28])))) recovered_157_q <= (esc_data_p2_reg_61__0_36955cb [28]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_29_1986c76
  reg recovered_158_q = 1'b0;
  assign data_p2[29] = recovered_158_q;
  wire recovered_158_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_158_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_158_q == 1'b0))) recovered_158_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_158_q == (esc_data_p2_reg_61__0_36955cb [29])))) recovered_158_q <= (esc_data_p2_reg_61__0_36955cb [29]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_2_e90455c
  reg recovered_159_q = 1'b0;
  assign data_p2[2] = recovered_159_q;
  wire recovered_159_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_159_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_159_q == 1'b0))) recovered_159_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_159_q == (esc_data_p2_reg_61__0_36955cb [2])))) recovered_159_q <= (esc_data_p2_reg_61__0_36955cb [2]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_30_6df1d7f
  reg recovered_160_q = 1'b0;
  assign data_p2[30] = recovered_160_q;
  wire recovered_160_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_160_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_160_q == 1'b0))) recovered_160_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_160_q == (esc_data_p2_reg_61__0_36955cb [30])))) recovered_160_q <= (esc_data_p2_reg_61__0_36955cb [30]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_31_ba6b1b9
  reg recovered_161_q = 1'b0;
  assign data_p2[31] = recovered_161_q;
  wire recovered_161_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_161_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_161_q == 1'b0))) recovered_161_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_161_q == (esc_data_p2_reg_61__0_36955cb [31])))) recovered_161_q <= (esc_data_p2_reg_61__0_36955cb [31]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_32_569cc27
  reg recovered_162_q = 1'b0;
  assign data_p2[32] = recovered_162_q;
  wire recovered_162_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_162_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_162_q == 1'b0))) recovered_162_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_162_q == (esc_data_p2_reg_61__0_36955cb [32])))) recovered_162_q <= (esc_data_p2_reg_61__0_36955cb [32]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_33_52e8db9
  reg recovered_163_q = 1'b0;
  assign data_p2[33] = recovered_163_q;
  wire recovered_163_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_163_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_163_q == 1'b0))) recovered_163_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_163_q == (esc_data_p2_reg_61__0_36955cb [33])))) recovered_163_q <= (esc_data_p2_reg_61__0_36955cb [33]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_34_f5172ca
  reg recovered_164_q = 1'b0;
  assign data_p2[34] = recovered_164_q;
  wire recovered_164_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_164_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_164_q == 1'b0))) recovered_164_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_164_q == (esc_data_p2_reg_61__0_36955cb [34])))) recovered_164_q <= (esc_data_p2_reg_61__0_36955cb [34]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_35_d475c0f
  reg recovered_165_q = 1'b0;
  assign data_p2[35] = recovered_165_q;
  wire recovered_165_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_165_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_165_q == 1'b0))) recovered_165_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_165_q == (esc_data_p2_reg_61__0_36955cb [35])))) recovered_165_q <= (esc_data_p2_reg_61__0_36955cb [35]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_36_79ca344
  reg recovered_166_q = 1'b0;
  assign data_p2[36] = recovered_166_q;
  wire recovered_166_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_166_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_166_q == 1'b0))) recovered_166_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_166_q == (esc_data_p2_reg_61__0_36955cb [36])))) recovered_166_q <= (esc_data_p2_reg_61__0_36955cb [36]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_37_b8cb6c5
  reg recovered_167_q = 1'b0;
  assign data_p2[37] = recovered_167_q;
  wire recovered_167_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_167_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_167_q == 1'b0))) recovered_167_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_167_q == (esc_data_p2_reg_61__0_36955cb [37])))) recovered_167_q <= (esc_data_p2_reg_61__0_36955cb [37]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_38_a06ed62
  reg recovered_168_q = 1'b0;
  assign data_p2[38] = recovered_168_q;
  wire recovered_168_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_168_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_168_q == 1'b0))) recovered_168_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_168_q == (esc_data_p2_reg_61__0_36955cb [38])))) recovered_168_q <= (esc_data_p2_reg_61__0_36955cb [38]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_39_cf69139
  reg recovered_169_q = 1'b0;
  assign data_p2[39] = recovered_169_q;
  wire recovered_169_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_169_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_169_q == 1'b0))) recovered_169_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_169_q == (esc_data_p2_reg_61__0_36955cb [39])))) recovered_169_q <= (esc_data_p2_reg_61__0_36955cb [39]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_3_900e4b0
  reg recovered_170_q = 1'b0;
  assign data_p2[3] = recovered_170_q;
  wire recovered_170_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_170_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_170_q == 1'b0))) recovered_170_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_170_q == (esc_data_p2_reg_61__0_36955cb [3])))) recovered_170_q <= (esc_data_p2_reg_61__0_36955cb [3]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_40_8c35b2b
  reg recovered_171_q = 1'b0;
  assign data_p2[40] = recovered_171_q;
  wire recovered_171_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_171_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_171_q == 1'b0))) recovered_171_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_171_q == (esc_data_p2_reg_61__0_36955cb [40])))) recovered_171_q <= (esc_data_p2_reg_61__0_36955cb [40]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_41_84fc704
  reg recovered_172_q = 1'b0;
  assign data_p2[41] = recovered_172_q;
  wire recovered_172_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_172_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_172_q == 1'b0))) recovered_172_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_172_q == (esc_data_p2_reg_61__0_36955cb [41])))) recovered_172_q <= (esc_data_p2_reg_61__0_36955cb [41]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_42_2807320
  reg recovered_173_q = 1'b0;
  assign data_p2[42] = recovered_173_q;
  wire recovered_173_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_173_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_173_q == 1'b0))) recovered_173_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_173_q == (esc_data_p2_reg_61__0_36955cb [42])))) recovered_173_q <= (esc_data_p2_reg_61__0_36955cb [42]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_43_c089859
  reg recovered_174_q = 1'b0;
  assign data_p2[43] = recovered_174_q;
  wire recovered_174_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_174_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_174_q == 1'b0))) recovered_174_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_174_q == (esc_data_p2_reg_61__0_36955cb [43])))) recovered_174_q <= (esc_data_p2_reg_61__0_36955cb [43]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_44_bda247d
  reg recovered_175_q = 1'b0;
  assign data_p2[44] = recovered_175_q;
  wire recovered_175_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_175_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_175_q == 1'b0))) recovered_175_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_175_q == (esc_data_p2_reg_61__0_36955cb [44])))) recovered_175_q <= (esc_data_p2_reg_61__0_36955cb [44]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_45_f4e0130
  reg recovered_176_q = 1'b0;
  assign data_p2[45] = recovered_176_q;
  wire recovered_176_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_176_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_176_q == 1'b0))) recovered_176_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_176_q == (esc_data_p2_reg_61__0_36955cb [45])))) recovered_176_q <= (esc_data_p2_reg_61__0_36955cb [45]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_46_1754e2e
  reg recovered_177_q = 1'b0;
  assign data_p2[46] = recovered_177_q;
  wire recovered_177_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_177_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_177_q == 1'b0))) recovered_177_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_177_q == (esc_data_p2_reg_61__0_36955cb [46])))) recovered_177_q <= (esc_data_p2_reg_61__0_36955cb [46]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_47_12c6fa9
  reg recovered_178_q = 1'b0;
  assign data_p2[47] = recovered_178_q;
  wire recovered_178_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_178_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_178_q == 1'b0))) recovered_178_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_178_q == (esc_data_p2_reg_61__0_36955cb [47])))) recovered_178_q <= (esc_data_p2_reg_61__0_36955cb [47]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_48_f1235f4
  reg recovered_179_q = 1'b0;
  assign data_p2[48] = recovered_179_q;
  wire recovered_179_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_179_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_179_q == 1'b0))) recovered_179_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_179_q == (esc_data_p2_reg_61__0_36955cb [48])))) recovered_179_q <= (esc_data_p2_reg_61__0_36955cb [48]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_49_cb484a5
  reg recovered_180_q = 1'b0;
  assign data_p2[49] = recovered_180_q;
  wire recovered_180_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_180_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_180_q == 1'b0))) recovered_180_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_180_q == (esc_data_p2_reg_61__0_36955cb [49])))) recovered_180_q <= (esc_data_p2_reg_61__0_36955cb [49]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_4_5844f0b
  reg recovered_181_q = 1'b0;
  assign data_p2[4] = recovered_181_q;
  wire recovered_181_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_181_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_181_q == 1'b0))) recovered_181_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_181_q == (esc_data_p2_reg_61__0_36955cb [4])))) recovered_181_q <= (esc_data_p2_reg_61__0_36955cb [4]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_50_2f085e8
  reg recovered_182_q = 1'b0;
  assign data_p2[50] = recovered_182_q;
  wire recovered_182_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_182_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_182_q == 1'b0))) recovered_182_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_182_q == (esc_data_p2_reg_61__0_36955cb [50])))) recovered_182_q <= (esc_data_p2_reg_61__0_36955cb [50]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_51_37e75eb
  reg recovered_183_q = 1'b0;
  assign data_p2[51] = recovered_183_q;
  wire recovered_183_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_183_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_183_q == 1'b0))) recovered_183_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_183_q == (esc_data_p2_reg_61__0_36955cb [51])))) recovered_183_q <= (esc_data_p2_reg_61__0_36955cb [51]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_52_6328fd0
  reg recovered_184_q = 1'b0;
  assign data_p2[52] = recovered_184_q;
  wire recovered_184_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_184_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_184_q == 1'b0))) recovered_184_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_184_q == (esc_data_p2_reg_61__0_36955cb [52])))) recovered_184_q <= (esc_data_p2_reg_61__0_36955cb [52]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_53_8a53b8d
  reg recovered_185_q = 1'b0;
  assign data_p2[53] = recovered_185_q;
  wire recovered_185_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_185_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_185_q == 1'b0))) recovered_185_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_185_q == (esc_data_p2_reg_61__0_36955cb [53])))) recovered_185_q <= (esc_data_p2_reg_61__0_36955cb [53]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_54_52dfc10
  reg recovered_186_q = 1'b0;
  assign data_p2[54] = recovered_186_q;
  wire recovered_186_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_186_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_186_q == 1'b0))) recovered_186_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_186_q == (esc_data_p2_reg_61__0_36955cb [54])))) recovered_186_q <= (esc_data_p2_reg_61__0_36955cb [54]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_55_6e461a2
  reg recovered_187_q = 1'b0;
  assign data_p2[55] = recovered_187_q;
  wire recovered_187_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_187_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_187_q == 1'b0))) recovered_187_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_187_q == (esc_data_p2_reg_61__0_36955cb [55])))) recovered_187_q <= (esc_data_p2_reg_61__0_36955cb [55]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_56_87d5a8f
  reg recovered_188_q = 1'b0;
  assign data_p2[56] = recovered_188_q;
  wire recovered_188_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_188_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_188_q == 1'b0))) recovered_188_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_188_q == (esc_data_p2_reg_61__0_36955cb [56])))) recovered_188_q <= (esc_data_p2_reg_61__0_36955cb [56]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_57_39b7117
  reg recovered_189_q = 1'b0;
  assign data_p2[57] = recovered_189_q;
  wire recovered_189_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_189_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_189_q == 1'b0))) recovered_189_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_189_q == (esc_data_p2_reg_61__0_36955cb [57])))) recovered_189_q <= (esc_data_p2_reg_61__0_36955cb [57]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_58_d79ef64
  reg recovered_190_q = 1'b0;
  assign data_p2[58] = recovered_190_q;
  wire recovered_190_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_190_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_190_q == 1'b0))) recovered_190_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_190_q == (esc_data_p2_reg_61__0_36955cb [58])))) recovered_190_q <= (esc_data_p2_reg_61__0_36955cb [58]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_59_06a329f
  reg recovered_191_q = 1'b0;
  assign data_p2[59] = recovered_191_q;
  wire recovered_191_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_191_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_191_q == 1'b0))) recovered_191_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_191_q == (esc_data_p2_reg_61__0_36955cb [59])))) recovered_191_q <= (esc_data_p2_reg_61__0_36955cb [59]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_5_15309ce
  reg recovered_192_q = 1'b0;
  assign data_p2[5] = recovered_192_q;
  wire recovered_192_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_192_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_192_q == 1'b0))) recovered_192_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_192_q == (esc_data_p2_reg_61__0_36955cb [5])))) recovered_192_q <= (esc_data_p2_reg_61__0_36955cb [5]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_60_820782e
  reg recovered_193_q = 1'b0;
  assign data_p2[60] = recovered_193_q;
  wire recovered_193_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_193_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_193_q == 1'b0))) recovered_193_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_193_q == (esc_data_p2_reg_61__0_36955cb [60])))) recovered_193_q <= (esc_data_p2_reg_61__0_36955cb [60]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_61_4692f8e
  reg recovered_194_q = 1'b0;
  assign data_p2[61] = recovered_194_q;
  wire recovered_194_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_194_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_194_q == 1'b0))) recovered_194_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_194_q == (esc_data_p2_reg_61__0_36955cb [61])))) recovered_194_q <= (esc_data_p2_reg_61__0_36955cb [61]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_6_261c300
  reg recovered_195_q = 1'b0;
  assign data_p2[6] = recovered_195_q;
  wire recovered_195_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_195_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_195_q == 1'b0))) recovered_195_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_195_q == (esc_data_p2_reg_61__0_36955cb [6])))) recovered_195_q <= (esc_data_p2_reg_61__0_36955cb [6]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_7_c521434
  reg recovered_196_q = 1'b0;
  assign data_p2[7] = recovered_196_q;
  wire recovered_196_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_196_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_196_q == 1'b0))) recovered_196_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_196_q == (esc_data_p2_reg_61__0_36955cb [7])))) recovered_196_q <= (esc_data_p2_reg_61__0_36955cb [7]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_8_8336a66
  reg recovered_197_q = 1'b0;
  assign data_p2[8] = recovered_197_q;
  wire recovered_197_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_197_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_197_q == 1'b0))) recovered_197_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_197_q == (esc_data_p2_reg_61__0_36955cb [8])))) recovered_197_q <= (esc_data_p2_reg_61__0_36955cb [8]);
  end

  // Reconstructed FDRE: esc_data_p2_reg_9_02d4977
  reg recovered_198_q = 1'b0;
  assign data_p2[9] = recovered_198_q;
  wire recovered_198_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_198_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_198_q == 1'b0))) recovered_198_q <= 1'b0;
    else if ((load_p2) || ((load_p2) === 1'bz) || (((load_p2) === 1'bx) && (recovered_198_q == (esc_data_p2_reg_61__0_36955cb [9])))) recovered_198_q <= (esc_data_p2_reg_61__0_36955cb [9]);
  end

  // Reconstructed LUT5: s_ready_t_i_1__1
  assign s_ready_t_i_1__1_n_0 = ((state__0[0]) ? (((rs2f_wreq_ack) ? (((state__0[1]) ? (output_r_AWREADY) : (1'b1))) : (output_r_AWREADY))) : (((rs2f_wreq_ack) ? (((state__0[1]) ? (output_r_AWREADY) : (1'b1))) : (((state__0[1]) ? (((Q[7]) ? (1'b0) : (output_r_AWREADY))) : (1'b1))))));

  // Reconstructed FDRE: s_ready_t_reg
  reg recovered_200_q = 1'b0;
  assign output_r_AWREADY = recovered_200_q;
  wire recovered_200_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_200_reset || (((SR) === 1'bx) && (recovered_200_q == 1'b0))) recovered_200_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_200_q == (s_ready_t_i_1__1_n_0)))) recovered_200_q <= (s_ready_t_i_1__1_n_0);
  end

  // Reconstructed LUT5: esc_state_0__i_1__1_46cadf3
  assign esc_state_0__i_1__1_n_0_fcb670e = ((output_r_AWREADY) ? (((Q[7]) ? (((state) ? (1'b1) : (esc_state_reg_0__0_c93a5dd))) : (((state) ? (((esc_state_reg_0__0_c93a5dd) ? (~(rs2f_wreq_ack)) : (1'b0))) : (esc_state_reg_0__0_c93a5dd))))) : (((state) ? (((esc_state_reg_0__0_c93a5dd) ? (~(rs2f_wreq_ack)) : (1'b0))) : (esc_state_reg_0__0_c93a5dd))));

  // Reconstructed LUT5: esc_state_1__i_1__1_38f2280
  assign esc_state_1__i_1__1_n_0_83cc659 = ((rs2f_wreq_ack) ? (1'b1) : (((esc_state_reg_0__0_c93a5dd) ? (((state) ? (((output_r_AWREADY) ? (~(Q[7])) : (1'b1))) : (1'b0))) : (1'b1))));

  // Reconstructed FDRE: esc_state_reg_0_32e4467
  reg recovered_203_q = 1'b0;
  assign esc_state_reg_0__0_c93a5dd = recovered_203_q;
  wire recovered_203_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_203_reset || (((SR) === 1'bx) && (recovered_203_q == 1'b0))) recovered_203_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_203_q == (esc_state_0__i_1__1_n_0_fcb670e)))) recovered_203_q <= (esc_state_0__i_1__1_n_0_fcb670e);
  end

  // Reconstructed FDSE: esc_state_reg_1_a113b56
  reg recovered_204_q = 1'b1;
  assign state = recovered_204_q;
  wire recovered_204_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_204_reset || (((SR) === 1'bx) && (recovered_204_q == 1'b1))) recovered_204_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_204_q == (esc_state_1__i_1__1_n_0_83cc659)))) recovered_204_q <= (esc_state_1__i_1__1_n_0_83cc659);
  end

endmodule

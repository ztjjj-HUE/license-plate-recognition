// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_throttle
   (m_axi_output_r_AWREADY_0,
    esc_bus_equal_gen_WVALID_Dummy_reg_16556e5 ,
    m_axi_output_r_WVALID,
    esc_bus_equal_gen_WVALID_Dummy_reg_0_4657a23 ,
    AWVALID_Dummy,
    esc_throttl_cnt_reg_4__0_fd50aea ,
    m_axi_output_r_AWREADY,
    WVALID_Dummy,
    m_axi_output_r_WREADY,
    SR,
    ap_clk);
  output m_axi_output_r_AWREADY_0;
  output esc_bus_equal_gen_WVALID_Dummy_reg_16556e5 ;
  output m_axi_output_r_WVALID;
  output esc_bus_equal_gen_WVALID_Dummy_reg_0_4657a23 ;
  input AWVALID_Dummy;
  input [3:0]esc_throttl_cnt_reg_4__0_fd50aea ;
  input m_axi_output_r_AWREADY;
  input WVALID_Dummy;
  input m_axi_output_r_WREADY;
  input [0:0]SR;
  input ap_clk;

  wire esc_const0_a0cf646 ;
  wire [3:0]A;
  wire AWVALID_Dummy;
  wire [0:0]SR;
  wire WVALID_Dummy;
  wire ap_clk;
  wire esc_bus_equal_gen_WVALID_Dummy_reg_16556e5 ;
  wire esc_bus_equal_gen_WVALID_Dummy_reg_0_4657a23 ;
  wire m_axi_output_r_AWREADY;
  wire m_axi_output_r_AWREADY_0;
  wire m_axi_output_r_WREADY;
  wire m_axi_output_r_WVALID;
  wire m_axi_output_r_WVALID_INST_0_i_1_n_0;
  wire p_0_out_carry__0_i_1__2_n_0;
  wire p_0_out_carry__0_i_2__2_n_0;
  wire p_0_out_carry__0_i_3__1_n_0;
  wire p_0_out_carry__0_i_4_n_0;
  wire p_0_out_carry__0_n_4;
  wire p_0_out_carry__0_n_5;
  wire p_0_out_carry__0_n_6;
  wire p_0_out_carry__0_n_7;
  wire p_0_out_carry_i_3__2_n_0;
  wire p_0_out_carry_i_4__2_n_0;
  wire p_0_out_carry_i_5__2_n_0;
  wire p_0_out_carry_i_6_n_0;
  wire p_0_out_carry_i_7_n_0;
  wire p_0_out_carry_i_8_n_0;
  wire p_0_out_carry_i_9_n_0;
  wire p_0_out_carry_n_0;
  wire p_0_out_carry_n_4;
  wire p_0_out_carry_n_5;
  wire p_0_out_carry_n_6;
  wire p_0_out_carry_n_7;
  wire esc_throttl_cnt_0__i_1_n_0_6127ad7 ;
  wire esc_throttl_cnt_8__i_1_n_0_4b606eb ;
  wire esc_throttl_cnt_8__i_2_n_0_df862e3 ;
  wire [8:0]throttl_cnt_reg;
  wire [3:0]esc_throttl_cnt_reg_4__0_fd50aea ;
  wire [3:0]NLW_p_0_out_carry_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed LUT6: esc_bus_equal_gen_data_buf_31__i_2_4556fee
  assign esc_bus_equal_gen_WVALID_Dummy_reg_0_4657a23 = ((m_axi_output_r_WVALID_INST_0_i_1_n_0) ? (((m_axi_output_r_WREADY) ? (1'b0) : (WVALID_Dummy))) : (((throttl_cnt_reg[0]) ? (((m_axi_output_r_WREADY) ? (1'b0) : (WVALID_Dummy))) : (((throttl_cnt_reg[6]) ? (((m_axi_output_r_WREADY) ? (1'b0) : (WVALID_Dummy))) : (((throttl_cnt_reg[1]) ? (((m_axi_output_r_WREADY) ? (1'b0) : (WVALID_Dummy))) : (WVALID_Dummy))))))));

  // Reconstructed LUT2: esc_could_multi_bursts_awaddr_buf_63__i_3_ab50314
  assign m_axi_output_r_AWREADY_0 = ((esc_bus_equal_gen_WVALID_Dummy_reg_16556e5) ? (1'b0) : (m_axi_output_r_AWREADY));

  // Reconstructed LUT6: m_axi_output_r_AWVALID_INST_0_i_1
  assign esc_bus_equal_gen_WVALID_Dummy_reg_16556e5 = ((m_axi_output_r_WVALID_INST_0_i_1_n_0) ? (1'b1) : (((throttl_cnt_reg[0]) ? (((throttl_cnt_reg[6]) ? (1'b1) : (((throttl_cnt_reg[1]) ? (1'b1) : (((m_axi_output_r_WREADY) ? (~(WVALID_Dummy)) : (1'b1))))))) : (((throttl_cnt_reg[6]) ? (1'b1) : (throttl_cnt_reg[1]))))));

  // Reconstructed LUT5: m_axi_output_r_WVALID_INST_0
  assign m_axi_output_r_WVALID = ((throttl_cnt_reg[1]) ? (WVALID_Dummy) : (((throttl_cnt_reg[6]) ? (WVALID_Dummy) : (((throttl_cnt_reg[0]) ? (WVALID_Dummy) : (((m_axi_output_r_WVALID_INST_0_i_1_n_0) ? (WVALID_Dummy) : (1'b0))))))));

  // Reconstructed LUT6: m_axi_output_r_WVALID_INST_0_i_1
  assign m_axi_output_r_WVALID_INST_0_i_1_n_0 = ((throttl_cnt_reg[4]) ? (1'b1) : (((throttl_cnt_reg[5]) ? (1'b1) : (((throttl_cnt_reg[3]) ? (1'b1) : (((throttl_cnt_reg[2]) ? (1'b1) : (((throttl_cnt_reg[8]) ? (1'b1) : (throttl_cnt_reg[7]))))))))));

  // Reconstructed CARRY4: p_0_out_carry
  wire [3:0] recovered_7_co, recovered_7_o, recovered_7_s, recovered_7_di;
  assign recovered_7_s = {p_0_out_carry_i_6_n_0,p_0_out_carry_i_7_n_0,p_0_out_carry_i_8_n_0,p_0_out_carry_i_9_n_0};
  assign recovered_7_di = {A[3],p_0_out_carry_i_3__2_n_0,p_0_out_carry_i_4__2_n_0,p_0_out_carry_i_5__2_n_0};
  wire recovered_7_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_7_cy = ((A[0]) !== 1'bz) && (A[0]);
  assign recovered_7_o[0] = recovered_7_s[0] ^ (recovered_7_ci || recovered_7_cy);
  assign recovered_7_co[0] = (recovered_7_s[0] & (recovered_7_ci || recovered_7_cy)) | (~recovered_7_s[0] & recovered_7_di[0]);
  assign recovered_7_o[1] = recovered_7_s[1] ^ recovered_7_co[0];
  assign recovered_7_co[1] = (recovered_7_s[1] & recovered_7_co[0]) | (~recovered_7_s[1] & recovered_7_di[1]);
  assign recovered_7_o[2] = recovered_7_s[2] ^ recovered_7_co[1];
  assign recovered_7_co[2] = (recovered_7_s[2] & recovered_7_co[1]) | (~recovered_7_s[2] & recovered_7_di[2]);
  assign recovered_7_o[3] = recovered_7_s[3] ^ recovered_7_co[2];
  assign recovered_7_co[3] = (recovered_7_s[3] & recovered_7_co[2]) | (~recovered_7_s[3] & recovered_7_di[3]);
  assign {p_0_out_carry_n_0,NLW_p_0_out_carry_CO_UNCONNECTED[2:0]} = recovered_7_co;
  assign {p_0_out_carry_n_4,p_0_out_carry_n_5,p_0_out_carry_n_6,p_0_out_carry_n_7} = recovered_7_o;

  // Reconstructed CARRY4: p_0_out_carry__0
  wire [3:0] recovered_8_co, recovered_8_o, recovered_8_s, recovered_8_di;
  assign recovered_8_s = {p_0_out_carry__0_i_1__2_n_0,p_0_out_carry__0_i_2__2_n_0,p_0_out_carry__0_i_3__1_n_0,p_0_out_carry__0_i_4_n_0};
  assign recovered_8_di = {esc_const0_a0cf646 ,throttl_cnt_reg[6:4]};
  wire recovered_8_ci = ((p_0_out_carry_n_0) !== 1'bz) && (p_0_out_carry_n_0);
  wire recovered_8_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_8_o[0] = recovered_8_s[0] ^ (recovered_8_ci || recovered_8_cy);
  assign recovered_8_co[0] = (recovered_8_s[0] & (recovered_8_ci || recovered_8_cy)) | (~recovered_8_s[0] & recovered_8_di[0]);
  assign recovered_8_o[1] = recovered_8_s[1] ^ recovered_8_co[0];
  assign recovered_8_co[1] = (recovered_8_s[1] & recovered_8_co[0]) | (~recovered_8_s[1] & recovered_8_di[1]);
  assign recovered_8_o[2] = recovered_8_s[2] ^ recovered_8_co[1];
  assign recovered_8_co[2] = (recovered_8_s[2] & recovered_8_co[1]) | (~recovered_8_s[2] & recovered_8_di[2]);
  assign recovered_8_o[3] = recovered_8_s[3] ^ recovered_8_co[2];
  assign recovered_8_co[3] = (recovered_8_s[3] & recovered_8_co[2]) | (~recovered_8_s[3] & recovered_8_di[3]);
  assign {p_0_out_carry__0_n_4,p_0_out_carry__0_n_5,p_0_out_carry__0_n_6,p_0_out_carry__0_n_7} = recovered_8_o;

  // Reconstructed LUT2: p_0_out_carry__0_i_1__2
  assign p_0_out_carry__0_i_1__2_n_0 = ((throttl_cnt_reg[7]) ? (throttl_cnt_reg[8]) : (~(throttl_cnt_reg[8])));

  // Reconstructed LUT2: p_0_out_carry__0_i_2__2
  assign p_0_out_carry__0_i_2__2_n_0 = ((throttl_cnt_reg[7]) ? (throttl_cnt_reg[6]) : (~(throttl_cnt_reg[6])));

  // Reconstructed LUT2: p_0_out_carry__0_i_3__1
  assign p_0_out_carry__0_i_3__1_n_0 = ((throttl_cnt_reg[6]) ? (throttl_cnt_reg[5]) : (~(throttl_cnt_reg[5])));

  // Reconstructed LUT2: p_0_out_carry__0_i_4
  assign p_0_out_carry__0_i_4_n_0 = ((throttl_cnt_reg[5]) ? (throttl_cnt_reg[4]) : (~(throttl_cnt_reg[4])));

  // Reconstructed LUT4: p_0_out_carry_i_1__2
  assign A[0] = ((esc_throttl_cnt_reg_4__0_fd50aea [0]) ? (((throttl_cnt_reg[0]) ? (1'b1) : (((AWVALID_Dummy) ? (m_axi_output_r_AWREADY_0) : (1'b0))))) : (((throttl_cnt_reg[0]) ? (((AWVALID_Dummy) ? (~(m_axi_output_r_AWREADY_0)) : (1'b1))) : (1'b0))));

  // Reconstructed LUT4: p_0_out_carry_i_2__2
  assign A[3] = ((throttl_cnt_reg[3]) ? (1'b1) : (((esc_throttl_cnt_reg_4__0_fd50aea [3]) ? (((AWVALID_Dummy) ? (m_axi_output_r_AWREADY_0) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: p_0_out_carry_i_3__2
  assign p_0_out_carry_i_3__2_n_0 = ((esc_throttl_cnt_reg_4__0_fd50aea [3]) ? (((throttl_cnt_reg[3]) ? (1'b0) : (((AWVALID_Dummy) ? (~(m_axi_output_r_AWREADY_0)) : (1'b1))))) : (~(throttl_cnt_reg[3])));

  // Reconstructed LUT4: p_0_out_carry_i_4__2
  assign p_0_out_carry_i_4__2_n_0 = ((esc_throttl_cnt_reg_4__0_fd50aea [2]) ? (((throttl_cnt_reg[2]) ? (1'b0) : (((AWVALID_Dummy) ? (~(m_axi_output_r_AWREADY_0)) : (1'b1))))) : (~(throttl_cnt_reg[2])));

  // Reconstructed LUT4: p_0_out_carry_i_5__2
  assign p_0_out_carry_i_5__2_n_0 = ((esc_throttl_cnt_reg_4__0_fd50aea [1]) ? (((throttl_cnt_reg[1]) ? (1'b0) : (((AWVALID_Dummy) ? (~(m_axi_output_r_AWREADY_0)) : (1'b1))))) : (~(throttl_cnt_reg[1])));

  // Reconstructed LUT5: p_0_out_carry_i_6
  assign p_0_out_carry_i_6_n_0 = ((throttl_cnt_reg[4]) ? (((throttl_cnt_reg[3]) ? (1'b1) : (((esc_throttl_cnt_reg_4__0_fd50aea [3]) ? (((AWVALID_Dummy) ? (m_axi_output_r_AWREADY_0) : (1'b0))) : (1'b0))))) : (((throttl_cnt_reg[3]) ? (1'b0) : (((esc_throttl_cnt_reg_4__0_fd50aea [3]) ? (((AWVALID_Dummy) ? (~(m_axi_output_r_AWREADY_0)) : (1'b1))) : (1'b1))))));

  // Reconstructed LUT6: p_0_out_carry_i_7
  assign p_0_out_carry_i_7_n_0 = ((throttl_cnt_reg[3]) ? (((throttl_cnt_reg[2]) ? (1'b1) : (((esc_throttl_cnt_reg_4__0_fd50aea [2]) ? (((AWVALID_Dummy) ? (m_axi_output_r_AWREADY_0) : (1'b0))) : (1'b0))))) : (((esc_throttl_cnt_reg_4__0_fd50aea [3]) ? (((throttl_cnt_reg[2]) ? (((AWVALID_Dummy) ? (m_axi_output_r_AWREADY_0) : (1'b0))) : (((esc_throttl_cnt_reg_4__0_fd50aea [2]) ? (1'b1) : (((AWVALID_Dummy) ? (~(m_axi_output_r_AWREADY_0)) : (1'b1))))))) : (((throttl_cnt_reg[2]) ? (1'b0) : (((esc_throttl_cnt_reg_4__0_fd50aea [2]) ? (((AWVALID_Dummy) ? (~(m_axi_output_r_AWREADY_0)) : (1'b1))) : (1'b1))))))));

  // Reconstructed LUT6: p_0_out_carry_i_8
  assign p_0_out_carry_i_8_n_0 = ((throttl_cnt_reg[2]) ? (((throttl_cnt_reg[1]) ? (1'b1) : (((esc_throttl_cnt_reg_4__0_fd50aea [1]) ? (((AWVALID_Dummy) ? (m_axi_output_r_AWREADY_0) : (1'b0))) : (1'b0))))) : (((esc_throttl_cnt_reg_4__0_fd50aea [2]) ? (((throttl_cnt_reg[1]) ? (((AWVALID_Dummy) ? (m_axi_output_r_AWREADY_0) : (1'b0))) : (((esc_throttl_cnt_reg_4__0_fd50aea [1]) ? (1'b1) : (((AWVALID_Dummy) ? (~(m_axi_output_r_AWREADY_0)) : (1'b1))))))) : (((throttl_cnt_reg[1]) ? (1'b0) : (((esc_throttl_cnt_reg_4__0_fd50aea [1]) ? (((AWVALID_Dummy) ? (~(m_axi_output_r_AWREADY_0)) : (1'b1))) : (1'b1))))))));

  // Reconstructed LUT4: p_0_out_carry_i_9
  assign p_0_out_carry_i_9_n_0 = ((throttl_cnt_reg[1]) ? (((AWVALID_Dummy) ? (m_axi_output_r_AWREADY_0) : (1'b0))) : (((esc_throttl_cnt_reg_4__0_fd50aea [1]) ? (1'b1) : (((AWVALID_Dummy) ? (~(m_axi_output_r_AWREADY_0)) : (1'b1))))));

  // Reconstructed LUT4: esc_throttl_cnt_0__i_1_445d49e
  assign esc_throttl_cnt_0__i_1_n_0_6127ad7 = ((throttl_cnt_reg[0]) ? (((esc_throttl_cnt_reg_4__0_fd50aea [0]) ? (1'b0) : (((AWVALID_Dummy) ? (m_axi_output_r_AWREADY_0) : (1'b0))))) : (((esc_throttl_cnt_reg_4__0_fd50aea [0]) ? (((AWVALID_Dummy) ? (~(m_axi_output_r_AWREADY_0)) : (1'b1))) : (1'b1))));

  // Reconstructed LUT3: esc_throttl_cnt_8__i_1_7b3c4a5
  assign esc_throttl_cnt_8__i_1_n_0_4b606eb = ((esc_throttl_cnt_8__i_2_n_0_df862e3) ? (1'b1) : (((AWVALID_Dummy) ? (m_axi_output_r_AWREADY_0) : (1'b0))));

  // Reconstructed LUT6: esc_throttl_cnt_8__i_2_c4924f6
  assign esc_throttl_cnt_8__i_2_n_0_df862e3 = ((m_axi_output_r_WVALID_INST_0_i_1_n_0) ? (((m_axi_output_r_WREADY) ? (WVALID_Dummy) : (1'b0))) : (((throttl_cnt_reg[0]) ? (((m_axi_output_r_WREADY) ? (WVALID_Dummy) : (1'b0))) : (((throttl_cnt_reg[6]) ? (((m_axi_output_r_WREADY) ? (WVALID_Dummy) : (1'b0))) : (((throttl_cnt_reg[1]) ? (((m_axi_output_r_WREADY) ? (WVALID_Dummy) : (1'b0))) : (1'b0))))))));

  // Reconstructed FDRE: esc_throttl_cnt_reg_0_18e4929
  reg recovered_25_q = 1'b0;
  assign throttl_cnt_reg[0] = recovered_25_q;
  wire recovered_25_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_25_reset || (((SR) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((esc_throttl_cnt_8__i_1_n_0_4b606eb) || ((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bz) || (((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bx) && (recovered_25_q == (esc_throttl_cnt_0__i_1_n_0_6127ad7)))) recovered_25_q <= (esc_throttl_cnt_0__i_1_n_0_6127ad7);
  end

  // Reconstructed FDRE: esc_throttl_cnt_reg_1_bb4908b
  reg recovered_26_q = 1'b0;
  assign throttl_cnt_reg[1] = recovered_26_q;
  wire recovered_26_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_26_reset || (((SR) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((esc_throttl_cnt_8__i_1_n_0_4b606eb) || ((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bz) || (((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bx) && (recovered_26_q == (p_0_out_carry_n_7)))) recovered_26_q <= (p_0_out_carry_n_7);
  end

  // Reconstructed FDRE: esc_throttl_cnt_reg_2_21954ab
  reg recovered_27_q = 1'b0;
  assign throttl_cnt_reg[2] = recovered_27_q;
  wire recovered_27_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_27_reset || (((SR) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((esc_throttl_cnt_8__i_1_n_0_4b606eb) || ((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bz) || (((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bx) && (recovered_27_q == (p_0_out_carry_n_6)))) recovered_27_q <= (p_0_out_carry_n_6);
  end

  // Reconstructed FDRE: esc_throttl_cnt_reg_3_2dfd300
  reg recovered_28_q = 1'b0;
  assign throttl_cnt_reg[3] = recovered_28_q;
  wire recovered_28_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_28_reset || (((SR) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((esc_throttl_cnt_8__i_1_n_0_4b606eb) || ((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bz) || (((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bx) && (recovered_28_q == (p_0_out_carry_n_5)))) recovered_28_q <= (p_0_out_carry_n_5);
  end

  // Reconstructed FDRE: esc_throttl_cnt_reg_4_bc7c07a
  reg recovered_29_q = 1'b0;
  assign throttl_cnt_reg[4] = recovered_29_q;
  wire recovered_29_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_29_reset || (((SR) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((esc_throttl_cnt_8__i_1_n_0_4b606eb) || ((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bz) || (((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bx) && (recovered_29_q == (p_0_out_carry_n_4)))) recovered_29_q <= (p_0_out_carry_n_4);
  end

  // Reconstructed FDRE: esc_throttl_cnt_reg_5_eabfc8b
  reg recovered_30_q = 1'b0;
  assign throttl_cnt_reg[5] = recovered_30_q;
  wire recovered_30_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_30_reset || (((SR) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((esc_throttl_cnt_8__i_1_n_0_4b606eb) || ((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bz) || (((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bx) && (recovered_30_q == (p_0_out_carry__0_n_7)))) recovered_30_q <= (p_0_out_carry__0_n_7);
  end

  // Reconstructed FDRE: esc_throttl_cnt_reg_6_8e0e320
  reg recovered_31_q = 1'b0;
  assign throttl_cnt_reg[6] = recovered_31_q;
  wire recovered_31_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_31_reset || (((SR) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((esc_throttl_cnt_8__i_1_n_0_4b606eb) || ((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bz) || (((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bx) && (recovered_31_q == (p_0_out_carry__0_n_6)))) recovered_31_q <= (p_0_out_carry__0_n_6);
  end

  // Reconstructed FDRE: esc_throttl_cnt_reg_7_27f03df
  reg recovered_32_q = 1'b0;
  assign throttl_cnt_reg[7] = recovered_32_q;
  wire recovered_32_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_32_reset || (((SR) === 1'bx) && (recovered_32_q == 1'b0))) recovered_32_q <= 1'b0;
    else if ((esc_throttl_cnt_8__i_1_n_0_4b606eb) || ((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bz) || (((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bx) && (recovered_32_q == (p_0_out_carry__0_n_5)))) recovered_32_q <= (p_0_out_carry__0_n_5);
  end

  // Reconstructed FDRE: esc_throttl_cnt_reg_8_245ecc1
  reg recovered_33_q = 1'b0;
  assign throttl_cnt_reg[8] = recovered_33_q;
  wire recovered_33_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_33_reset || (((SR) === 1'bx) && (recovered_33_q == 1'b0))) recovered_33_q <= 1'b0;
    else if ((esc_throttl_cnt_8__i_1_n_0_4b606eb) || ((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bz) || (((esc_throttl_cnt_8__i_1_n_0_4b606eb) === 1'bx) && (recovered_33_q == (p_0_out_carry__0_n_4)))) recovered_33_q <= (p_0_out_carry__0_n_4);
  end

endmodule

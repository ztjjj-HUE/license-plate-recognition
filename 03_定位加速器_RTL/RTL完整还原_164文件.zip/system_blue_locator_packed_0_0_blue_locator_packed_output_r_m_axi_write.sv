// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_write
   (full_n_reg,
    empty_n_reg,
    AWVALID_Dummy,
    WVALID_Dummy,
    m_axi_output_r_WLAST,
    D,
    ap_done,
    m_axi_output_r_AWADDR,
    esc_could_multi_bursts_awlen_buf_reg_3__0_887186f ,
    m_axi_output_r_AWVALID,
    m_axi_output_r_WDATA,
    m_axi_output_r_WSTRB,
    ap_clk,
    SR,
    esc_ap_CS_fsm_reg_63_8ee7371 ,
    esc_ap_CS_fsm_reg_63__0_9fe4f39 ,
    Q,
    E,
    ap_start,
    esc_ap_CS_fsm_reg_63__1_dfe60b8 ,
    esc_ap_CS_fsm_63__i_4_789726b ,
    mem_reg,
    mem_reg_0,
    mem_reg_1,
    mem_reg_2,
    mem_reg_3,
    icmp_ln125_reg_9133,
    zext_ln125_reg_9138_reg,
    ap_rst_n,
    esc_bus_equal_gen_WLAST_Dummy_reg_0_a7eeff0 ,
    esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938 ,
    m_axi_output_r_AWVALID_0,
    m_axi_output_r_BVALID,
    esc_data_p2_reg_61_4692f8e );
  output full_n_reg;
  output empty_n_reg;
  output AWVALID_Dummy;
  output WVALID_Dummy;
  output m_axi_output_r_WLAST;
  output [11:0]D;
  output ap_done;
  output [61:0]m_axi_output_r_AWADDR;
  output [3:0]esc_could_multi_bursts_awlen_buf_reg_3__0_887186f ;
  output m_axi_output_r_AWVALID;
  output [31:0]m_axi_output_r_WDATA;
  output [3:0]m_axi_output_r_WSTRB;
  input ap_clk;
  input [0:0]SR;
  input esc_ap_CS_fsm_reg_63_8ee7371 ;
  input esc_ap_CS_fsm_reg_63__0_9fe4f39 ;
  input [18:0]Q;
  input [0:0]E;
  input ap_start;
  input esc_ap_CS_fsm_reg_63__1_dfe60b8 ;
  input esc_ap_CS_fsm_63__i_4_789726b ;
  input [18:0]mem_reg;
  input [5:0]mem_reg_0;
  input [6:0]mem_reg_1;
  input [4:0]mem_reg_2;
  input [5:0]mem_reg_3;
  input icmp_ln125_reg_9133;
  input zext_ln125_reg_9138_reg;
  input ap_rst_n;
  input esc_bus_equal_gen_WLAST_Dummy_reg_0_a7eeff0 ;
  input esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938 ;
  input m_axi_output_r_AWVALID_0;
  input m_axi_output_r_BVALID;
  input [61:0]esc_data_p2_reg_61_4692f8e ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire AWVALID_Dummy;
  wire [11:0]D;
  wire [0:0]E;
  wire ONE;
  wire [18:0]Q;
  wire [0:0]SR;
  wire WVALID_Dummy;
  wire align_len0;
  wire [31:4]align_len0__0;
  wire esc_align_len_reg_n_0__31_e5660d3 ;
  wire esc_align_len_reg_n_0__4_9fa0be1 ;
  wire esc_align_len_reg_n_0__5_511b982 ;
  wire esc_ap_CS_fsm_63__i_4_789726b ;
  wire esc_ap_CS_fsm_reg_63_8ee7371 ;
  wire esc_ap_CS_fsm_reg_63__0_9fe4f39 ;
  wire esc_ap_CS_fsm_reg_63__1_dfe60b8 ;
  wire ap_clk;
  wire ap_done;
  wire ap_rst_n;
  wire ap_start;
  wire [63:2]awaddr_tmp;
  wire [3:0]awlen_tmp;
  wire [9:2]beat_len_buf;
  wire buff_wdata_n_10;
  wire buff_wdata_n_11;
  wire buff_wdata_n_18;
  wire buff_wdata_n_19;
  wire buff_wdata_n_20;
  wire buff_wdata_n_21;
  wire buff_wdata_n_22;
  wire buff_wdata_n_24;
  wire buff_wdata_n_25;
  wire buff_wdata_n_26;
  wire buff_wdata_n_31;
  wire buff_wdata_n_32;
  wire buff_wdata_n_33;
  wire buff_wdata_n_34;
  wire buff_wdata_n_35;
  wire buff_wdata_n_36;
  wire buff_wdata_n_37;
  wire buff_wdata_n_38;
  wire buff_wdata_n_39;
  wire buff_wdata_n_40;
  wire buff_wdata_n_41;
  wire buff_wdata_n_42;
  wire buff_wdata_n_43;
  wire buff_wdata_n_44;
  wire buff_wdata_n_45;
  wire buff_wdata_n_46;
  wire buff_wdata_n_47;
  wire buff_wdata_n_48;
  wire buff_wdata_n_49;
  wire buff_wdata_n_50;
  wire buff_wdata_n_51;
  wire buff_wdata_n_52;
  wire buff_wdata_n_53;
  wire buff_wdata_n_54;
  wire buff_wdata_n_55;
  wire buff_wdata_n_56;
  wire buff_wdata_n_57;
  wire buff_wdata_n_58;
  wire buff_wdata_n_59;
  wire buff_wdata_n_60;
  wire buff_wdata_n_61;
  wire buff_wdata_n_62;
  wire buff_wdata_n_9;
  wire burst_valid;
  wire esc_bus_equal_gen_WLAST_Dummy_reg_0_a7eeff0 ;
  wire esc_bus_equal_gen_fifo_burst_n_10_7c8bbbb ;
  wire esc_bus_equal_gen_fifo_burst_n_11_5909e96 ;
  wire esc_bus_equal_gen_fifo_burst_n_12_34a69c8 ;
  wire esc_bus_equal_gen_fifo_burst_n_13_c26be9e ;
  wire esc_bus_equal_gen_fifo_burst_n_14_c065c5d ;
  wire esc_bus_equal_gen_fifo_burst_n_15_d6b39e8 ;
  wire esc_bus_equal_gen_fifo_burst_n_16_c3236d4 ;
  wire esc_bus_equal_gen_fifo_burst_n_17_5894e72 ;
  wire esc_bus_equal_gen_fifo_burst_n_18_6956e12 ;
  wire esc_bus_equal_gen_fifo_burst_n_19_f40abca ;
  wire esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d ;
  wire esc_bus_equal_gen_fifo_burst_n_20_8b50e36 ;
  wire esc_bus_equal_gen_fifo_burst_n_21_3f82d63 ;
  wire esc_bus_equal_gen_fifo_burst_n_22_9956bb3 ;
  wire esc_bus_equal_gen_fifo_burst_n_23_6ad7282 ;
  wire esc_bus_equal_gen_fifo_burst_n_24_4d7c0c3 ;
  wire esc_bus_equal_gen_fifo_burst_n_25_a348518 ;
  wire esc_bus_equal_gen_fifo_burst_n_26_4e81909 ;
  wire esc_bus_equal_gen_fifo_burst_n_27_cb0a1f0 ;
  wire esc_bus_equal_gen_fifo_burst_n_28_e7e2550 ;
  wire esc_bus_equal_gen_fifo_burst_n_29_d494d59 ;
  wire esc_bus_equal_gen_fifo_burst_n_30_b84bdbf ;
  wire esc_bus_equal_gen_fifo_burst_n_31_721a394 ;
  wire esc_bus_equal_gen_fifo_burst_n_32_c31df3c ;
  wire esc_bus_equal_gen_fifo_burst_n_33_772e8d0 ;
  wire esc_bus_equal_gen_fifo_burst_n_34_cc12236 ;
  wire esc_bus_equal_gen_fifo_burst_n_35_6521daf ;
  wire esc_bus_equal_gen_fifo_burst_n_36_445bf3c ;
  wire esc_bus_equal_gen_fifo_burst_n_37_820fc59 ;
  wire esc_bus_equal_gen_fifo_burst_n_38_b60cdf7 ;
  wire esc_bus_equal_gen_fifo_burst_n_39_aa82d48 ;
  wire esc_bus_equal_gen_fifo_burst_n_4_d747600 ;
  wire esc_bus_equal_gen_fifo_burst_n_40_8b7cec1 ;
  wire esc_bus_equal_gen_fifo_burst_n_41_b94ba92 ;
  wire esc_bus_equal_gen_fifo_burst_n_42_dd23c0f ;
  wire esc_bus_equal_gen_fifo_burst_n_43_14e72d2 ;
  wire esc_bus_equal_gen_fifo_burst_n_44_1c0cfaa ;
  wire esc_bus_equal_gen_fifo_burst_n_45_b80267f ;
  wire esc_bus_equal_gen_fifo_burst_n_46_d2c1907 ;
  wire esc_bus_equal_gen_fifo_burst_n_47_3855ff4 ;
  wire esc_bus_equal_gen_fifo_burst_n_48_e40cb2f ;
  wire esc_bus_equal_gen_fifo_burst_n_49_f86f51b ;
  wire esc_bus_equal_gen_fifo_burst_n_5_f6765b8 ;
  wire esc_bus_equal_gen_fifo_burst_n_50_a32939e ;
  wire esc_bus_equal_gen_fifo_burst_n_51_8547d41 ;
  wire esc_bus_equal_gen_fifo_burst_n_52_cc1c008 ;
  wire esc_bus_equal_gen_fifo_burst_n_53_ef2bee6 ;
  wire esc_bus_equal_gen_fifo_burst_n_54_207fdd9 ;
  wire esc_bus_equal_gen_fifo_burst_n_55_415c1c4 ;
  wire esc_bus_equal_gen_fifo_burst_n_56_02927c8 ;
  wire esc_bus_equal_gen_fifo_burst_n_57_9a24566 ;
  wire esc_bus_equal_gen_fifo_burst_n_58_0a624b0 ;
  wire esc_bus_equal_gen_fifo_burst_n_59_97d1831 ;
  wire esc_bus_equal_gen_fifo_burst_n_6_0b78b36 ;
  wire esc_bus_equal_gen_fifo_burst_n_60_ce9cee6 ;
  wire esc_bus_equal_gen_fifo_burst_n_65_9824fa3 ;
  wire esc_bus_equal_gen_fifo_burst_n_66_97f8224 ;
  wire esc_bus_equal_gen_fifo_burst_n_8_17dc7bd ;
  wire esc_bus_equal_gen_fifo_burst_n_9_8007697 ;
  wire esc_bus_equal_gen_len_cnt_7__i_3_n_0_f6425e9 ;
  wire [7:0]esc_bus_equal_gen_len_cnt_reg_755484c ;
  wire esc_could_multi_bursts_awaddr_buf_4__i_3_n_0_a1e332e ;
  wire esc_could_multi_bursts_awaddr_buf_4__i_4_n_0_cf5f918 ;
  wire esc_could_multi_bursts_awaddr_buf_4__i_5_n_0_638540b ;
  wire esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf ;
  wire esc_could_multi_bursts_awaddr_buf_8__i_3_n_0_12d65fb ;
  wire esc_could_multi_bursts_awaddr_buf_8__i_4_n_0_266e921 ;
  wire esc_could_multi_bursts_awaddr_buf_reg_12__i_2_n_0_f6b7f01 ;
  wire esc_could_multi_bursts_awaddr_buf_reg_16__i_2_n_0_1d1f725 ;
  wire esc_could_multi_bursts_awaddr_buf_reg_20__i_2_n_0_6c82cc5 ;
  wire esc_could_multi_bursts_awaddr_buf_reg_24__i_2_n_0_29c4085 ;
  wire esc_could_multi_bursts_awaddr_buf_reg_28__i_2_n_0_d122103 ;
  wire esc_could_multi_bursts_awaddr_buf_reg_32__i_2_n_0_153a3d7 ;
  wire esc_could_multi_bursts_awaddr_buf_reg_36__i_2_n_0_76b475d ;
  wire esc_could_multi_bursts_awaddr_buf_reg_40__i_2_n_0_6bf6a9d ;
  wire esc_could_multi_bursts_awaddr_buf_reg_44__i_2_n_0_2975f13 ;
  wire esc_could_multi_bursts_awaddr_buf_reg_48__i_2_n_0_ed7cb93 ;
  wire esc_could_multi_bursts_awaddr_buf_reg_4__i_2_n_0_72e231b ;
  wire esc_could_multi_bursts_awaddr_buf_reg_52__i_2_n_0_0e57cff ;
  wire esc_could_multi_bursts_awaddr_buf_reg_56__i_2_n_0_41e1c5e ;
  wire esc_could_multi_bursts_awaddr_buf_reg_60__i_2_n_0_49c4f87 ;
  wire esc_could_multi_bursts_awaddr_buf_reg_8__i_2_n_0_7bbebf8 ;
  wire [3:0]esc_could_multi_bursts_awlen_buf_reg_3__0_887186f ;
  wire esc_could_multi_bursts_last_sect_buf_reg_n_0_659f5fa ;
  wire [5:0]esc_could_multi_bursts_loop_cnt_reg_275e801 ;
  wire esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938 ;
  wire esc_could_multi_bursts_next_loop_c288065 ;
  wire esc_could_multi_bursts_sect_handling_reg_n_0_737ec10 ;
  wire [63:2]data1;
  wire [61:0]esc_data_p2_reg_61_4692f8e ;
  wire empty_n_reg;
  wire [63:2]end_addr;
  wire esc_end_addr_buf_13__i_2_n_0_aa6d7cc ;
  wire esc_end_addr_buf_13__i_3_n_0_79d8b5e ;
  wire esc_end_addr_buf_13__i_4_n_0_5117aa6 ;
  wire esc_end_addr_buf_13__i_5_n_0_83a716d ;
  wire esc_end_addr_buf_17__i_2_n_0_35ae088 ;
  wire esc_end_addr_buf_17__i_3_n_0_8f8554a ;
  wire esc_end_addr_buf_17__i_4_n_0_f4e92de ;
  wire esc_end_addr_buf_17__i_5_n_0_3646b5a ;
  wire esc_end_addr_buf_21__i_2_n_0_8c345c2 ;
  wire esc_end_addr_buf_21__i_3_n_0_14647fd ;
  wire esc_end_addr_buf_21__i_4_n_0_fc38406 ;
  wire esc_end_addr_buf_21__i_5_n_0_5cf9081 ;
  wire esc_end_addr_buf_25__i_2_n_0_b8fef88 ;
  wire esc_end_addr_buf_25__i_3_n_0_c486315 ;
  wire esc_end_addr_buf_25__i_4_n_0_3133667 ;
  wire esc_end_addr_buf_25__i_5_n_0_76e97aa ;
  wire esc_end_addr_buf_29__i_2_n_0_a234efd ;
  wire esc_end_addr_buf_29__i_3_n_0_0c408fa ;
  wire esc_end_addr_buf_29__i_4_n_0_eb1deb1 ;
  wire esc_end_addr_buf_29__i_5_n_0_673bcfd ;
  wire esc_end_addr_buf_33__i_2_n_0_ba38cf6 ;
  wire esc_end_addr_buf_33__i_3_n_0_1b00089 ;
  wire esc_end_addr_buf_5__i_2_n_0_c358dc5 ;
  wire esc_end_addr_buf_5__i_3_n_0_05b3eae ;
  wire esc_end_addr_buf_5__i_4_n_0_c7750ab ;
  wire esc_end_addr_buf_5__i_5_n_0_54f3e3c ;
  wire esc_end_addr_buf_9__i_2_n_0_db68aa3 ;
  wire esc_end_addr_buf_9__i_3_n_0_34ed475 ;
  wire esc_end_addr_buf_9__i_4_n_0_5bc5846 ;
  wire esc_end_addr_buf_9__i_5_n_0_fbd85c8 ;
  wire esc_end_addr_buf_reg_13__i_1_n_0_3c8fe49 ;
  wire esc_end_addr_buf_reg_17__i_1_n_0_11987eb ;
  wire esc_end_addr_buf_reg_21__i_1_n_0_e5cb45d ;
  wire esc_end_addr_buf_reg_25__i_1_n_0_86db6f3 ;
  wire esc_end_addr_buf_reg_29__i_1_n_0_cf4fd44 ;
  wire esc_end_addr_buf_reg_33__i_1_n_0_0ed11e6 ;
  wire esc_end_addr_buf_reg_37__i_1_n_0_f5b0379 ;
  wire esc_end_addr_buf_reg_41__i_1_n_0_6d8bcd2 ;
  wire esc_end_addr_buf_reg_45__i_1_n_0_8ea948c ;
  wire esc_end_addr_buf_reg_49__i_1_n_0_04a4c49 ;
  wire esc_end_addr_buf_reg_53__i_1_n_0_9807381 ;
  wire esc_end_addr_buf_reg_57__i_1_n_0_c02405a ;
  wire esc_end_addr_buf_reg_5__i_1_n_0_871a7e6 ;
  wire esc_end_addr_buf_reg_61__i_1_n_0_7fe6a00 ;
  wire esc_end_addr_buf_reg_9__i_1_n_0_c524ea0 ;
  wire esc_end_addr_buf_reg_n_0__10_c0d12d1 ;
  wire esc_end_addr_buf_reg_n_0__11_d1748fe ;
  wire esc_end_addr_buf_reg_n_0__2_e2f5013 ;
  wire esc_end_addr_buf_reg_n_0__3_01f6baa ;
  wire esc_end_addr_buf_reg_n_0__4_96f56e3 ;
  wire esc_end_addr_buf_reg_n_0__5_8aa7b13 ;
  wire esc_end_addr_buf_reg_n_0__6_728119e ;
  wire esc_end_addr_buf_reg_n_0__7_a09c043 ;
  wire esc_end_addr_buf_reg_n_0__8_b6d3b5f ;
  wire esc_end_addr_buf_reg_n_0__9_a87511a ;
  wire fifo_burst_ready;
  wire fifo_resp_n_2;
  wire fifo_resp_n_6;
  wire fifo_resp_ready;
  wire [67:67]fifo_wreq_data;
  wire fifo_wreq_n_10;
  wire fifo_wreq_n_11;
  wire fifo_wreq_n_12;
  wire fifo_wreq_n_13;
  wire fifo_wreq_n_14;
  wire fifo_wreq_n_15;
  wire fifo_wreq_n_16;
  wire fifo_wreq_n_17;
  wire fifo_wreq_n_18;
  wire fifo_wreq_n_19;
  wire fifo_wreq_n_2;
  wire fifo_wreq_n_20;
  wire fifo_wreq_n_21;
  wire fifo_wreq_n_22;
  wire fifo_wreq_n_23;
  wire fifo_wreq_n_24;
  wire fifo_wreq_n_25;
  wire fifo_wreq_n_26;
  wire fifo_wreq_n_27;
  wire fifo_wreq_n_28;
  wire fifo_wreq_n_29;
  wire fifo_wreq_n_3;
  wire fifo_wreq_n_30;
  wire fifo_wreq_n_31;
  wire fifo_wreq_n_32;
  wire fifo_wreq_n_33;
  wire fifo_wreq_n_34;
  wire fifo_wreq_n_35;
  wire fifo_wreq_n_36;
  wire fifo_wreq_n_37;
  wire fifo_wreq_n_38;
  wire fifo_wreq_n_39;
  wire fifo_wreq_n_4;
  wire fifo_wreq_n_40;
  wire fifo_wreq_n_41;
  wire fifo_wreq_n_42;
  wire fifo_wreq_n_43;
  wire fifo_wreq_n_44;
  wire fifo_wreq_n_45;
  wire fifo_wreq_n_46;
  wire fifo_wreq_n_47;
  wire fifo_wreq_n_48;
  wire fifo_wreq_n_49;
  wire fifo_wreq_n_50;
  wire fifo_wreq_n_51;
  wire fifo_wreq_n_52;
  wire fifo_wreq_n_53;
  wire fifo_wreq_n_54;
  wire fifo_wreq_n_55;
  wire fifo_wreq_n_56;
  wire fifo_wreq_n_57;
  wire fifo_wreq_n_58;
  wire fifo_wreq_n_59;
  wire fifo_wreq_n_6;
  wire fifo_wreq_n_60;
  wire fifo_wreq_n_61;
  wire fifo_wreq_n_62;
  wire fifo_wreq_n_63;
  wire fifo_wreq_n_64;
  wire fifo_wreq_n_65;
  wire fifo_wreq_n_66;
  wire fifo_wreq_n_67;
  wire fifo_wreq_n_69;
  wire fifo_wreq_n_7;
  wire fifo_wreq_n_8;
  wire fifo_wreq_n_9;
  wire fifo_wreq_valid;
  wire fifo_wreq_valid_buf_reg_n_0;
  wire first_sect;
  wire first_sect_carry__0_i_1__0_n_0;
  wire first_sect_carry__0_i_2__0_n_0;
  wire first_sect_carry__0_i_3__0_n_0;
  wire first_sect_carry__0_i_4__0_n_0;
  wire first_sect_carry__0_n_0;
  wire first_sect_carry__1_i_1__0_n_0;
  wire first_sect_carry__1_i_2__0_n_0;
  wire first_sect_carry__1_i_3__0_n_0;
  wire first_sect_carry__1_i_4__0_n_0;
  wire first_sect_carry__1_n_0;
  wire first_sect_carry__2_i_1__0_n_0;
  wire first_sect_carry__2_i_2__0_n_0;
  wire first_sect_carry__2_i_3__0_n_0;
  wire first_sect_carry__2_i_4__0_n_0;
  wire first_sect_carry__2_n_0;
  wire first_sect_carry__3_i_1__0_n_0;
  wire first_sect_carry__3_i_2__0_n_0;
  wire first_sect_carry_i_1__0_n_0;
  wire first_sect_carry_i_2__0_n_0;
  wire first_sect_carry_i_3__0_n_0;
  wire first_sect_carry_i_4__0_n_0;
  wire first_sect_carry_n_0;
  wire full_n_reg;
  wire icmp_ln125_reg_9133;
  wire invalid_len_event;
  wire invalid_len_event_reg1;
  wire invalid_len_event_reg2;
  wire last_sect;
  wire last_sect_buf;
  wire last_sect_carry__0_i_1__0_n_0;
  wire last_sect_carry__0_i_2__0_n_0;
  wire last_sect_carry__0_i_3__0_n_0;
  wire last_sect_carry__0_i_4__0_n_0;
  wire last_sect_carry__0_n_0;
  wire last_sect_carry__1_i_1__0_n_0;
  wire last_sect_carry__1_i_2__0_n_0;
  wire last_sect_carry__1_i_3__0_n_0;
  wire last_sect_carry__1_i_4__0_n_0;
  wire last_sect_carry__1_n_0;
  wire last_sect_carry__2_i_1__0_n_0;
  wire last_sect_carry__2_i_2__0_n_0;
  wire last_sect_carry__2_i_3__0_n_0;
  wire last_sect_carry__2_i_4__0_n_0;
  wire last_sect_carry__2_n_0;
  wire last_sect_carry_i_1__0_n_0;
  wire last_sect_carry_i_2__0_n_0;
  wire last_sect_carry_i_3__0_n_0;
  wire last_sect_carry_i_4__0_n_0;
  wire last_sect_carry_n_0;
  wire [5:0]mOutPtr_reg;
  wire [61:0]m_axi_output_r_AWADDR;
  wire m_axi_output_r_AWVALID;
  wire m_axi_output_r_AWVALID_0;
  wire m_axi_output_r_BVALID;
  wire [31:0]m_axi_output_r_WDATA;
  wire m_axi_output_r_WLAST;
  wire [3:0]m_axi_output_r_WSTRB;
  wire [18:0]mem_reg;
  wire [5:0]mem_reg_0;
  wire [6:0]mem_reg_1;
  wire [4:0]mem_reg_2;
  wire [5:0]mem_reg_3;
  wire next_resp;
  wire next_resp0;
  wire next_wreq;
  wire output_r_AWREADY;
  wire [5:0]p_0_in;
  wire [51:0]p_0_in0_in;
  wire [51:0]p_0_in_0;
  wire [7:0]p_0_in__0;
  wire p_0_out_carry__0_n_5;
  wire p_0_out_carry__0_n_6;
  wire p_0_out_carry__0_n_7;
  wire p_0_out_carry_n_0;
  wire p_0_out_carry_n_4;
  wire p_0_out_carry_n_5;
  wire p_0_out_carry_n_6;
  wire p_0_out_carry_n_7;
  wire p_30_in;
  wire push;
  wire push_0;
  wire rs2f_wreq_ack;
  wire [61:0]rs2f_wreq_data;
  wire rs2f_wreq_valid;
  wire [63:2]sect_addr;
  wire esc_sect_addr_buf_reg_n_0__10_870b69d ;
  wire esc_sect_addr_buf_reg_n_0__11_3acc932 ;
  wire esc_sect_addr_buf_reg_n_0__12_3345b33 ;
  wire esc_sect_addr_buf_reg_n_0__13_c419bb0 ;
  wire esc_sect_addr_buf_reg_n_0__14_be30b67 ;
  wire esc_sect_addr_buf_reg_n_0__15_83b1580 ;
  wire esc_sect_addr_buf_reg_n_0__16_8d80ab0 ;
  wire esc_sect_addr_buf_reg_n_0__17_b463da9 ;
  wire esc_sect_addr_buf_reg_n_0__18_8f1b7e0 ;
  wire esc_sect_addr_buf_reg_n_0__19_205beba ;
  wire esc_sect_addr_buf_reg_n_0__20_64eade7 ;
  wire esc_sect_addr_buf_reg_n_0__21_15c29c5 ;
  wire esc_sect_addr_buf_reg_n_0__22_b0a0c3d ;
  wire esc_sect_addr_buf_reg_n_0__23_31ab99b ;
  wire esc_sect_addr_buf_reg_n_0__24_9a91ab6 ;
  wire esc_sect_addr_buf_reg_n_0__25_fd4334d ;
  wire esc_sect_addr_buf_reg_n_0__26_4b2b197 ;
  wire esc_sect_addr_buf_reg_n_0__27_dc5c286 ;
  wire esc_sect_addr_buf_reg_n_0__28_ab688cc ;
  wire esc_sect_addr_buf_reg_n_0__29_5fda2c0 ;
  wire esc_sect_addr_buf_reg_n_0__2_c2c1041 ;
  wire esc_sect_addr_buf_reg_n_0__30_160e1b6 ;
  wire esc_sect_addr_buf_reg_n_0__31_f1a8fbc ;
  wire esc_sect_addr_buf_reg_n_0__32_c7aeb52 ;
  wire esc_sect_addr_buf_reg_n_0__33_3443c27 ;
  wire esc_sect_addr_buf_reg_n_0__34_c59005e ;
  wire esc_sect_addr_buf_reg_n_0__35_4d0f93d ;
  wire esc_sect_addr_buf_reg_n_0__36_d80e692 ;
  wire esc_sect_addr_buf_reg_n_0__37_18b7f7b ;
  wire esc_sect_addr_buf_reg_n_0__38_a55959a ;
  wire esc_sect_addr_buf_reg_n_0__39_bee2ecd ;
  wire esc_sect_addr_buf_reg_n_0__3_fe3572f ;
  wire esc_sect_addr_buf_reg_n_0__40_1eb7798 ;
  wire esc_sect_addr_buf_reg_n_0__41_2d6e174 ;
  wire esc_sect_addr_buf_reg_n_0__42_6a4a4fb ;
  wire esc_sect_addr_buf_reg_n_0__43_99fa7a2 ;
  wire esc_sect_addr_buf_reg_n_0__44_46a4975 ;
  wire esc_sect_addr_buf_reg_n_0__45_97ae151 ;
  wire esc_sect_addr_buf_reg_n_0__46_c8d2917 ;
  wire esc_sect_addr_buf_reg_n_0__47_205d244 ;
  wire esc_sect_addr_buf_reg_n_0__48_870c0bb ;
  wire esc_sect_addr_buf_reg_n_0__49_ee79105 ;
  wire esc_sect_addr_buf_reg_n_0__4_363722f ;
  wire esc_sect_addr_buf_reg_n_0__50_4c8d65a ;
  wire esc_sect_addr_buf_reg_n_0__51_d4fe5b5 ;
  wire esc_sect_addr_buf_reg_n_0__52_9d48c85 ;
  wire esc_sect_addr_buf_reg_n_0__53_7d93328 ;
  wire esc_sect_addr_buf_reg_n_0__54_7071cc2 ;
  wire esc_sect_addr_buf_reg_n_0__55_fa58e13 ;
  wire esc_sect_addr_buf_reg_n_0__56_697e16f ;
  wire esc_sect_addr_buf_reg_n_0__57_288be70 ;
  wire esc_sect_addr_buf_reg_n_0__58_a7911e8 ;
  wire esc_sect_addr_buf_reg_n_0__59_73bc156 ;
  wire esc_sect_addr_buf_reg_n_0__5_e2303ea ;
  wire esc_sect_addr_buf_reg_n_0__60_537e0e3 ;
  wire esc_sect_addr_buf_reg_n_0__61_0fe6dc2 ;
  wire esc_sect_addr_buf_reg_n_0__62_7a67c6d ;
  wire esc_sect_addr_buf_reg_n_0__63_ebd5f7d ;
  wire esc_sect_addr_buf_reg_n_0__6_a42bc93 ;
  wire esc_sect_addr_buf_reg_n_0__7_f3397b7 ;
  wire esc_sect_addr_buf_reg_n_0__8_2d0930b ;
  wire esc_sect_addr_buf_reg_n_0__9_dd7820d ;
  wire [51:1]sect_cnt0;
  wire sect_cnt0_carry__0_n_0;
  wire sect_cnt0_carry__10_n_0;
  wire sect_cnt0_carry__1_n_0;
  wire sect_cnt0_carry__2_n_0;
  wire sect_cnt0_carry__3_n_0;
  wire sect_cnt0_carry__4_n_0;
  wire sect_cnt0_carry__5_n_0;
  wire sect_cnt0_carry__6_n_0;
  wire sect_cnt0_carry__7_n_0;
  wire sect_cnt0_carry__8_n_0;
  wire sect_cnt0_carry__9_n_0;
  wire sect_cnt0_carry_n_0;
  wire esc_sect_cnt_reg_n_0__0_cf5038d ;
  wire esc_sect_cnt_reg_n_0__10_8129e9e ;
  wire esc_sect_cnt_reg_n_0__11_2134eea ;
  wire esc_sect_cnt_reg_n_0__12_b408e9b ;
  wire esc_sect_cnt_reg_n_0__13_f728c1e ;
  wire esc_sect_cnt_reg_n_0__14_3816884 ;
  wire esc_sect_cnt_reg_n_0__15_baa501c ;
  wire esc_sect_cnt_reg_n_0__16_e0e6bd3 ;
  wire esc_sect_cnt_reg_n_0__17_60004ee ;
  wire esc_sect_cnt_reg_n_0__18_2b2ad13 ;
  wire esc_sect_cnt_reg_n_0__19_d3501e6 ;
  wire esc_sect_cnt_reg_n_0__1_6d680f9 ;
  wire esc_sect_cnt_reg_n_0__20_44e2780 ;
  wire esc_sect_cnt_reg_n_0__21_2affd71 ;
  wire esc_sect_cnt_reg_n_0__22_fc0a11f ;
  wire esc_sect_cnt_reg_n_0__23_b356fba ;
  wire esc_sect_cnt_reg_n_0__24_f384316 ;
  wire esc_sect_cnt_reg_n_0__25_b6c1707 ;
  wire esc_sect_cnt_reg_n_0__26_b4e21e4 ;
  wire esc_sect_cnt_reg_n_0__27_131810a ;
  wire esc_sect_cnt_reg_n_0__28_78b1845 ;
  wire esc_sect_cnt_reg_n_0__29_2ed533d ;
  wire esc_sect_cnt_reg_n_0__2_15d4d8f ;
  wire esc_sect_cnt_reg_n_0__30_38a695a ;
  wire esc_sect_cnt_reg_n_0__31_0c2dac2 ;
  wire esc_sect_cnt_reg_n_0__32_e54430d ;
  wire esc_sect_cnt_reg_n_0__33_8cbf4a8 ;
  wire esc_sect_cnt_reg_n_0__34_3d99c4c ;
  wire esc_sect_cnt_reg_n_0__35_5818df7 ;
  wire esc_sect_cnt_reg_n_0__36_b6ea0ad ;
  wire esc_sect_cnt_reg_n_0__37_b1ebede ;
  wire esc_sect_cnt_reg_n_0__38_d27d0e3 ;
  wire esc_sect_cnt_reg_n_0__39_1a62409 ;
  wire esc_sect_cnt_reg_n_0__3_e4b1820 ;
  wire esc_sect_cnt_reg_n_0__40_c7f7402 ;
  wire esc_sect_cnt_reg_n_0__41_827f3d3 ;
  wire esc_sect_cnt_reg_n_0__42_dc2ac0b ;
  wire esc_sect_cnt_reg_n_0__43_b2f91b4 ;
  wire esc_sect_cnt_reg_n_0__44_ae87890 ;
  wire esc_sect_cnt_reg_n_0__45_028cd3e ;
  wire esc_sect_cnt_reg_n_0__46_bc6350d ;
  wire esc_sect_cnt_reg_n_0__47_be2c9ea ;
  wire esc_sect_cnt_reg_n_0__48_c5dc410 ;
  wire esc_sect_cnt_reg_n_0__49_ac3ce58 ;
  wire esc_sect_cnt_reg_n_0__4_2216bae ;
  wire esc_sect_cnt_reg_n_0__50_aee544d ;
  wire esc_sect_cnt_reg_n_0__51_b4f8fa6 ;
  wire esc_sect_cnt_reg_n_0__5_5ca388c ;
  wire esc_sect_cnt_reg_n_0__6_8f7c601 ;
  wire esc_sect_cnt_reg_n_0__7_5d37ab6 ;
  wire esc_sect_cnt_reg_n_0__8_9af08b3 ;
  wire esc_sect_cnt_reg_n_0__9_46ce72e ;
  wire esc_sect_len_buf_0__i_1__0_n_0_c1a0e8b ;
  wire esc_sect_len_buf_1__i_1__0_n_0_2a82972 ;
  wire esc_sect_len_buf_2__i_1__0_n_0_fbde65b ;
  wire esc_sect_len_buf_3__i_1__0_n_0_2d844a1 ;
  wire esc_sect_len_buf_4__i_1__0_n_0_261435d ;
  wire esc_sect_len_buf_5__i_1__0_n_0_5bfe42b ;
  wire esc_sect_len_buf_6__i_1__0_n_0_8a4705a ;
  wire esc_sect_len_buf_7__i_1__0_n_0_dcebc07 ;
  wire esc_sect_len_buf_8__i_1__0_n_0_7eddd71 ;
  wire esc_sect_len_buf_9__i_2__0_n_0_f63edb6 ;
  wire esc_sect_len_buf_reg_n_0__0_2f5bb85 ;
  wire esc_sect_len_buf_reg_n_0__1_fa0e016 ;
  wire esc_sect_len_buf_reg_n_0__2_64bffbf ;
  wire esc_sect_len_buf_reg_n_0__3_4003b8b ;
  wire esc_sect_len_buf_reg_n_0__4_7dfbe71 ;
  wire esc_sect_len_buf_reg_n_0__5_f880a64 ;
  wire esc_sect_len_buf_reg_n_0__6_00ec5ef ;
  wire esc_sect_len_buf_reg_n_0__7_8a87bd5 ;
  wire esc_sect_len_buf_reg_n_0__8_c195217 ;
  wire esc_sect_len_buf_reg_n_0__9_679de8d ;
  wire esc_start_addr_buf_reg_n_0__10_1323f7f ;
  wire esc_start_addr_buf_reg_n_0__11_3e2416d ;
  wire esc_start_addr_buf_reg_n_0__2_9c5ad66 ;
  wire esc_start_addr_buf_reg_n_0__3_6d1c7eb ;
  wire esc_start_addr_buf_reg_n_0__4_55d009f ;
  wire esc_start_addr_buf_reg_n_0__5_f6b4823 ;
  wire esc_start_addr_buf_reg_n_0__6_5592b8e ;
  wire esc_start_addr_buf_reg_n_0__7_8e93ddd ;
  wire esc_start_addr_buf_reg_n_0__8_3056d1d ;
  wire esc_start_addr_buf_reg_n_0__9_d78d0ac ;
  wire esc_start_addr_reg_n_0__10_7dfdb33 ;
  wire esc_start_addr_reg_n_0__11_93897a8 ;
  wire esc_start_addr_reg_n_0__12_0ffbef5 ;
  wire esc_start_addr_reg_n_0__13_f3dfe34 ;
  wire esc_start_addr_reg_n_0__14_726da08 ;
  wire esc_start_addr_reg_n_0__15_3a25f9c ;
  wire esc_start_addr_reg_n_0__16_c2276cc ;
  wire esc_start_addr_reg_n_0__17_a7c7f14 ;
  wire esc_start_addr_reg_n_0__18_7d4f45f ;
  wire esc_start_addr_reg_n_0__19_3510eae ;
  wire esc_start_addr_reg_n_0__20_a055fe3 ;
  wire esc_start_addr_reg_n_0__21_9efa866 ;
  wire esc_start_addr_reg_n_0__22_ba17a60 ;
  wire esc_start_addr_reg_n_0__23_907ba78 ;
  wire esc_start_addr_reg_n_0__24_1d34d3b ;
  wire esc_start_addr_reg_n_0__25_b477c1e ;
  wire esc_start_addr_reg_n_0__26_5efe7d3 ;
  wire esc_start_addr_reg_n_0__27_4bb8d27 ;
  wire esc_start_addr_reg_n_0__28_0abd4bb ;
  wire esc_start_addr_reg_n_0__29_aa2b4b7 ;
  wire esc_start_addr_reg_n_0__2_825dc7f ;
  wire esc_start_addr_reg_n_0__30_fa7e7f5 ;
  wire esc_start_addr_reg_n_0__31_6881f62 ;
  wire esc_start_addr_reg_n_0__32_d304ae3 ;
  wire esc_start_addr_reg_n_0__33_e2508d5 ;
  wire esc_start_addr_reg_n_0__34_7048a69 ;
  wire esc_start_addr_reg_n_0__35_e55187f ;
  wire esc_start_addr_reg_n_0__36_1b35e42 ;
  wire esc_start_addr_reg_n_0__37_49e2d9d ;
  wire esc_start_addr_reg_n_0__38_abcede3 ;
  wire esc_start_addr_reg_n_0__39_9f399ca ;
  wire esc_start_addr_reg_n_0__3_d6f6925 ;
  wire esc_start_addr_reg_n_0__40_44358a2 ;
  wire esc_start_addr_reg_n_0__41_aca3f17 ;
  wire esc_start_addr_reg_n_0__42_a3d52cc ;
  wire esc_start_addr_reg_n_0__43_eeeef11 ;
  wire esc_start_addr_reg_n_0__44_91d3e92 ;
  wire esc_start_addr_reg_n_0__45_c02f4ba ;
  wire esc_start_addr_reg_n_0__46_ffff99b ;
  wire esc_start_addr_reg_n_0__47_38b6f54 ;
  wire esc_start_addr_reg_n_0__48_bba970f ;
  wire esc_start_addr_reg_n_0__49_f51d0fb ;
  wire esc_start_addr_reg_n_0__4_35bfd51 ;
  wire esc_start_addr_reg_n_0__50_4a0d627 ;
  wire esc_start_addr_reg_n_0__51_71ee3d6 ;
  wire esc_start_addr_reg_n_0__52_4ddab7f ;
  wire esc_start_addr_reg_n_0__53_391e956 ;
  wire esc_start_addr_reg_n_0__54_6ca5236 ;
  wire esc_start_addr_reg_n_0__55_f2a438b ;
  wire esc_start_addr_reg_n_0__56_ed05e9e ;
  wire esc_start_addr_reg_n_0__57_897c5a0 ;
  wire esc_start_addr_reg_n_0__58_94d4f4b ;
  wire esc_start_addr_reg_n_0__59_91cd7d0 ;
  wire esc_start_addr_reg_n_0__5_51bdd86 ;
  wire esc_start_addr_reg_n_0__60_9bfecb1 ;
  wire esc_start_addr_reg_n_0__61_d0861cf ;
  wire esc_start_addr_reg_n_0__62_067c30f ;
  wire esc_start_addr_reg_n_0__63_6c9d71f ;
  wire esc_start_addr_reg_n_0__6_85a28ac ;
  wire esc_start_addr_reg_n_0__7_2aaf228 ;
  wire esc_start_addr_reg_n_0__8_22baed7 ;
  wire esc_start_addr_reg_n_0__9_b0ff003 ;
  wire [3:0]tmp_strb;
  wire wreq_handling_reg_n_0;
  wire zero_len_event0;
  wire zext_ln125_reg_9138_reg;
  wire [3:0]esc_NLW_align_len0_inferred__1_i__carry_O_UNCONNECTED_83cf436 ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_12__i_2_CO_UNCONNECTED_d0c471f ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_16__i_2_CO_UNCONNECTED_61c8e35 ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_20__i_2_CO_UNCONNECTED_0a83d0f ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_24__i_2_CO_UNCONNECTED_05a6bad ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_28__i_2_CO_UNCONNECTED_596e833 ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_32__i_2_CO_UNCONNECTED_babed89 ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_36__i_2_CO_UNCONNECTED_49832ff ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_40__i_2_CO_UNCONNECTED_8ca4683 ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_44__i_2_CO_UNCONNECTED_13380d9 ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_48__i_2_CO_UNCONNECTED_716918e ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_4__i_2_CO_UNCONNECTED_66bd01c ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_4__i_2_O_UNCONNECTED_219d49a ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_52__i_2_CO_UNCONNECTED_cc7715f ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_56__i_2_CO_UNCONNECTED_1287321 ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_60__i_2_CO_UNCONNECTED_39c6f65 ;
  wire [3:0]esc_NLW_could_multi_bursts_awaddr_buf_reg_8__i_2_CO_UNCONNECTED_6074f2b ;
  wire [3:0]esc_NLW_end_addr_buf_reg_13__i_1_CO_UNCONNECTED_6c20db1 ;
  wire [3:0]esc_NLW_end_addr_buf_reg_17__i_1_CO_UNCONNECTED_7ee3189 ;
  wire [3:0]esc_NLW_end_addr_buf_reg_21__i_1_CO_UNCONNECTED_43d0ce0 ;
  wire [3:0]esc_NLW_end_addr_buf_reg_25__i_1_CO_UNCONNECTED_fd986b6 ;
  wire [3:0]esc_NLW_end_addr_buf_reg_29__i_1_CO_UNCONNECTED_63efa90 ;
  wire [3:0]esc_NLW_end_addr_buf_reg_33__i_1_CO_UNCONNECTED_5fc7d63 ;
  wire [3:0]esc_NLW_end_addr_buf_reg_37__i_1_CO_UNCONNECTED_5af208f ;
  wire [3:0]esc_NLW_end_addr_buf_reg_41__i_1_CO_UNCONNECTED_f8d7e91 ;
  wire [3:0]esc_NLW_end_addr_buf_reg_45__i_1_CO_UNCONNECTED_3779586 ;
  wire [3:0]esc_NLW_end_addr_buf_reg_49__i_1_CO_UNCONNECTED_9c2b774 ;
  wire [3:0]esc_NLW_end_addr_buf_reg_53__i_1_CO_UNCONNECTED_0c406db ;
  wire [3:0]esc_NLW_end_addr_buf_reg_57__i_1_CO_UNCONNECTED_12bb8d1 ;
  wire [3:0]esc_NLW_end_addr_buf_reg_5__i_1_CO_UNCONNECTED_6ee8ade ;
  wire [3:0]esc_NLW_end_addr_buf_reg_5__i_1_O_UNCONNECTED_35eced8 ;
  wire [3:0]esc_NLW_end_addr_buf_reg_61__i_1_CO_UNCONNECTED_c48edce ;
  wire [3:0]esc_NLW_end_addr_buf_reg_9__i_1_CO_UNCONNECTED_df4a3a2 ;
  wire [3:0]NLW_first_sect_carry_CO_UNCONNECTED;
  wire [3:0]NLW_first_sect_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_first_sect_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_first_sect_carry__2_CO_UNCONNECTED;
  wire [3:0]NLW_first_sect_carry__3_CO_UNCONNECTED;
  wire [3:0]NLW_last_sect_carry_CO_UNCONNECTED;
  wire [3:0]NLW_last_sect_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_last_sect_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_last_sect_carry__2_CO_UNCONNECTED;
  wire [3:0]NLW_last_sect_carry__3_CO_UNCONNECTED;
  wire [3:0]NLW_p_0_out_carry_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry__10_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry__2_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry__3_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry__4_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry__5_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry__6_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry__7_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry__8_CO_UNCONNECTED;
  wire [3:0]NLW_sect_cnt0_carry__9_CO_UNCONNECTED;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed VCC: VCC_1
  assign ONE = 1'b1;

  // Reconstructed CARRY4: esc_align_len0_inferred__1_i__carry_dd11b10
  wire [3:0] recovered_4_co, recovered_4_o, recovered_4_s, recovered_4_di;
  assign recovered_4_s = {esc_const1_c064970 ,zero_len_event0,esc_const1_c064970 ,esc_const1_c064970 };
  assign recovered_4_di = {esc_const0_a0cf646 ,fifo_wreq_data,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_4_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_4_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_4_o[0] = recovered_4_s[0] ^ (recovered_4_ci || recovered_4_cy);
  assign recovered_4_co[0] = (recovered_4_s[0] & (recovered_4_ci || recovered_4_cy)) | (~recovered_4_s[0] & recovered_4_di[0]);
  assign recovered_4_o[1] = recovered_4_s[1] ^ recovered_4_co[0];
  assign recovered_4_co[1] = (recovered_4_s[1] & recovered_4_co[0]) | (~recovered_4_s[1] & recovered_4_di[1]);
  assign recovered_4_o[2] = recovered_4_s[2] ^ recovered_4_co[1];
  assign recovered_4_co[2] = (recovered_4_s[2] & recovered_4_co[1]) | (~recovered_4_s[2] & recovered_4_di[2]);
  assign recovered_4_o[3] = recovered_4_s[3] ^ recovered_4_co[2];
  assign recovered_4_co[3] = (recovered_4_s[3] & recovered_4_co[2]) | (~recovered_4_s[3] & recovered_4_di[3]);
  assign {align_len0__0[31],align_len0__0[5],esc_NLW_align_len0_inferred__1_i__carry_O_UNCONNECTED_83cf436 [1:0]} = recovered_4_o;

  // Reconstructed FDRE: esc_align_len_reg_31_14aea02
  reg recovered_5_q = 1'b0;
  assign esc_align_len_reg_n_0__31_e5660d3 = recovered_5_q;
  wire recovered_5_reset = ((fifo_wreq_n_4)) && ((fifo_wreq_n_4) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_5_reset || (((fifo_wreq_n_4) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_5_q == (align_len0__0[31])))) recovered_5_q <= (align_len0__0[31]);
  end

  // Reconstructed FDRE: esc_align_len_reg_4_6ec20b0
  reg recovered_6_q = 1'b0;
  assign esc_align_len_reg_n_0__4_9fa0be1 = recovered_6_q;
  wire recovered_6_reset = ((fifo_wreq_n_4)) && ((fifo_wreq_n_4) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_6_reset || (((fifo_wreq_n_4) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_6_q == (ONE)))) recovered_6_q <= (ONE);
  end

  // Reconstructed FDRE: esc_align_len_reg_5_103b026
  reg recovered_7_q = 1'b0;
  assign esc_align_len_reg_n_0__5_511b982 = recovered_7_q;
  wire recovered_7_reset = ((fifo_wreq_n_4)) && ((fifo_wreq_n_4) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_7_reset || (((fifo_wreq_n_4) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_7_q == (align_len0__0[5])))) recovered_7_q <= (align_len0__0[5]);
  end

  // Reconstructed FDRE: esc_beat_len_buf_reg_2_ecf4a43
  reg recovered_8_q = 1'b0;
  assign beat_len_buf[2] = recovered_8_q;
  wire recovered_8_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_8_reset || (((SR) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_8_q == (esc_align_len_reg_n_0__4_9fa0be1)))) recovered_8_q <= (esc_align_len_reg_n_0__4_9fa0be1);
  end

  // Reconstructed FDRE: esc_beat_len_buf_reg_3_ba17e92
  reg recovered_9_q = 1'b0;
  assign beat_len_buf[3] = recovered_9_q;
  wire recovered_9_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_9_reset || (((SR) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_9_q == (esc_align_len_reg_n_0__5_511b982)))) recovered_9_q <= (esc_align_len_reg_n_0__5_511b982);
  end

  // Reconstructed FDRE: esc_beat_len_buf_reg_9_b01c471
  reg recovered_10_q = 1'b0;
  assign beat_len_buf[9] = recovered_10_q;
  wire recovered_10_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_10_reset || (((SR) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_10_q == (esc_align_len_reg_n_0__31_e5660d3)))) recovered_10_q <= (esc_align_len_reg_n_0__31_e5660d3);
  end

  system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_buffer buff_wdata
       (.D(D[10:2]),
        .DI(buff_wdata_n_25),
        .Q(Q[16:8]),
        .S({buff_wdata_n_9,buff_wdata_n_10,buff_wdata_n_11}),
        .SR(SR),
        .WVALID_Dummy(WVALID_Dummy),
        .ap_clk(ap_clk),
        .ap_rst_n(ap_rst_n),
        .burst_valid(burst_valid),
        .esc_bus_equal_gen_WLAST_Dummy_reg_daab610 (esc_bus_equal_gen_WLAST_Dummy_reg_0_a7eeff0 ),
        .esc_bus_equal_gen_WVALID_Dummy_reg_16556e5 (buff_wdata_n_26),
        .esc_bus_equal_gen_len_cnt_reg_6_460eec5 (buff_wdata_n_22),
        .esc_bus_equal_gen_len_cnt_reg_6__0_d02ee1e (buff_wdata_n_24),
        .esc_bus_equal_gen_len_cnt_reg_7_077fe2f (esc_bus_equal_gen_len_cnt_reg_755484c [7:6]),
        .esc_bus_equal_gen_len_cnt_reg_7__0_df668b2 (esc_bus_equal_gen_fifo_burst_n_5_f6765b8 ),
        .esc_dout_buf_reg_35__0_895f1d4 ({tmp_strb,buff_wdata_n_31,buff_wdata_n_32,buff_wdata_n_33,buff_wdata_n_34,buff_wdata_n_35,buff_wdata_n_36,buff_wdata_n_37,buff_wdata_n_38,buff_wdata_n_39,buff_wdata_n_40,buff_wdata_n_41,buff_wdata_n_42,buff_wdata_n_43,buff_wdata_n_44,buff_wdata_n_45,buff_wdata_n_46,buff_wdata_n_47,buff_wdata_n_48,buff_wdata_n_49,buff_wdata_n_50,buff_wdata_n_51,buff_wdata_n_52,buff_wdata_n_53,buff_wdata_n_54,buff_wdata_n_55,buff_wdata_n_56,buff_wdata_n_57,buff_wdata_n_58,buff_wdata_n_59,buff_wdata_n_60,buff_wdata_n_61,buff_wdata_n_62}),
        .icmp_ln125_reg_9133(icmp_ln125_reg_9133),
        .esc_mOutPtr_reg_3__0_af193d3 ({buff_wdata_n_18,buff_wdata_n_19,buff_wdata_n_20,buff_wdata_n_21}),
        .esc_mOutPtr_reg_5__0_51c21ea (mOutPtr_reg),
        .esc_mOutPtr_reg_7__0_b1502f7 ({p_0_out_carry__0_n_5,p_0_out_carry__0_n_6,p_0_out_carry__0_n_7,p_0_out_carry_n_4,p_0_out_carry_n_5,p_0_out_carry_n_6,p_0_out_carry_n_7}),
        .m_axi_output_r_WLAST(m_axi_output_r_WLAST),
        .mem_reg_0(mem_reg),
        .mem_reg_1(mem_reg_0),
        .mem_reg_2(mem_reg_1),
        .mem_reg_3(mem_reg_2),
        .mem_reg_4(mem_reg_3),
        .output_r_AWREADY(output_r_AWREADY),
        .p_30_in(p_30_in),
        .zext_ln125_reg_9138_reg(zext_ln125_reg_9138_reg));

  // Reconstructed FDRE: esc_bus_equal_gen_WLAST_Dummy_reg_daab610
  reg recovered_12_q = 1'b0;
  assign m_axi_output_r_WLAST = recovered_12_q;
  wire recovered_12_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_12_reset || (((SR) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_12_q == (buff_wdata_n_24)))) recovered_12_q <= (buff_wdata_n_24);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_WVALID_Dummy_reg_16556e5
  reg recovered_13_q = 1'b0;
  assign WVALID_Dummy = recovered_13_q;
  wire recovered_13_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_13_reset || (((SR) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_13_q == (buff_wdata_n_26)))) recovered_13_q <= (buff_wdata_n_26);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_0_354b52b
  reg recovered_14_q = 1'b0;
  assign m_axi_output_r_WDATA[0] = recovered_14_q;
  wire recovered_14_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_14_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_14_q == (buff_wdata_n_62)))) recovered_14_q <= (buff_wdata_n_62);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_10_de63c74
  reg recovered_15_q = 1'b0;
  assign m_axi_output_r_WDATA[10] = recovered_15_q;
  wire recovered_15_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_15_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_15_q == (buff_wdata_n_52)))) recovered_15_q <= (buff_wdata_n_52);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_11_d482fe4
  reg recovered_16_q = 1'b0;
  assign m_axi_output_r_WDATA[11] = recovered_16_q;
  wire recovered_16_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_16_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_16_q == (buff_wdata_n_51)))) recovered_16_q <= (buff_wdata_n_51);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_12_5de34f2
  reg recovered_17_q = 1'b0;
  assign m_axi_output_r_WDATA[12] = recovered_17_q;
  wire recovered_17_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_17_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_17_q == (buff_wdata_n_50)))) recovered_17_q <= (buff_wdata_n_50);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_13_8d4f3de
  reg recovered_18_q = 1'b0;
  assign m_axi_output_r_WDATA[13] = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_18_q == (buff_wdata_n_49)))) recovered_18_q <= (buff_wdata_n_49);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_14_bbad256
  reg recovered_19_q = 1'b0;
  assign m_axi_output_r_WDATA[14] = recovered_19_q;
  wire recovered_19_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_19_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_19_q == (buff_wdata_n_48)))) recovered_19_q <= (buff_wdata_n_48);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_15_a7efb50
  reg recovered_20_q = 1'b0;
  assign m_axi_output_r_WDATA[15] = recovered_20_q;
  wire recovered_20_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_20_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_20_q == (buff_wdata_n_47)))) recovered_20_q <= (buff_wdata_n_47);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_16_020d955
  reg recovered_21_q = 1'b0;
  assign m_axi_output_r_WDATA[16] = recovered_21_q;
  wire recovered_21_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_21_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_21_q == (buff_wdata_n_46)))) recovered_21_q <= (buff_wdata_n_46);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_17_4233786
  reg recovered_22_q = 1'b0;
  assign m_axi_output_r_WDATA[17] = recovered_22_q;
  wire recovered_22_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_22_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_22_q == (buff_wdata_n_45)))) recovered_22_q <= (buff_wdata_n_45);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_18_eabe1d8
  reg recovered_23_q = 1'b0;
  assign m_axi_output_r_WDATA[18] = recovered_23_q;
  wire recovered_23_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_23_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_23_q == (buff_wdata_n_44)))) recovered_23_q <= (buff_wdata_n_44);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_19_6926503
  reg recovered_24_q = 1'b0;
  assign m_axi_output_r_WDATA[19] = recovered_24_q;
  wire recovered_24_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_24_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_24_q == (buff_wdata_n_43)))) recovered_24_q <= (buff_wdata_n_43);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_1_af5abcb
  reg recovered_25_q = 1'b0;
  assign m_axi_output_r_WDATA[1] = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_25_q == (buff_wdata_n_61)))) recovered_25_q <= (buff_wdata_n_61);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_20_f687c91
  reg recovered_26_q = 1'b0;
  assign m_axi_output_r_WDATA[20] = recovered_26_q;
  wire recovered_26_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_26_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_26_q == (buff_wdata_n_42)))) recovered_26_q <= (buff_wdata_n_42);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_21_e2654c7
  reg recovered_27_q = 1'b0;
  assign m_axi_output_r_WDATA[21] = recovered_27_q;
  wire recovered_27_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_27_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_27_q == (buff_wdata_n_41)))) recovered_27_q <= (buff_wdata_n_41);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_22_9a9f34d
  reg recovered_28_q = 1'b0;
  assign m_axi_output_r_WDATA[22] = recovered_28_q;
  wire recovered_28_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_28_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_28_q == (buff_wdata_n_40)))) recovered_28_q <= (buff_wdata_n_40);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_23_8a0af48
  reg recovered_29_q = 1'b0;
  assign m_axi_output_r_WDATA[23] = recovered_29_q;
  wire recovered_29_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_29_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_29_q == (buff_wdata_n_39)))) recovered_29_q <= (buff_wdata_n_39);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_24_0497a6c
  reg recovered_30_q = 1'b0;
  assign m_axi_output_r_WDATA[24] = recovered_30_q;
  wire recovered_30_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_30_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_30_q == (buff_wdata_n_38)))) recovered_30_q <= (buff_wdata_n_38);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_25_beba22f
  reg recovered_31_q = 1'b0;
  assign m_axi_output_r_WDATA[25] = recovered_31_q;
  wire recovered_31_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_31_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_31_q == (buff_wdata_n_37)))) recovered_31_q <= (buff_wdata_n_37);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_26_c945c72
  reg recovered_32_q = 1'b0;
  assign m_axi_output_r_WDATA[26] = recovered_32_q;
  wire recovered_32_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_32_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_32_q == 1'b0))) recovered_32_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_32_q == (buff_wdata_n_36)))) recovered_32_q <= (buff_wdata_n_36);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_27_b02e5e9
  reg recovered_33_q = 1'b0;
  assign m_axi_output_r_WDATA[27] = recovered_33_q;
  wire recovered_33_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_33_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_33_q == 1'b0))) recovered_33_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_33_q == (buff_wdata_n_35)))) recovered_33_q <= (buff_wdata_n_35);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_28_fe98b5d
  reg recovered_34_q = 1'b0;
  assign m_axi_output_r_WDATA[28] = recovered_34_q;
  wire recovered_34_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_34_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_34_q == 1'b0))) recovered_34_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_34_q == (buff_wdata_n_34)))) recovered_34_q <= (buff_wdata_n_34);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_29_c3baf80
  reg recovered_35_q = 1'b0;
  assign m_axi_output_r_WDATA[29] = recovered_35_q;
  wire recovered_35_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_35_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_35_q == 1'b0))) recovered_35_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_35_q == (buff_wdata_n_33)))) recovered_35_q <= (buff_wdata_n_33);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_2_f0b93ea
  reg recovered_36_q = 1'b0;
  assign m_axi_output_r_WDATA[2] = recovered_36_q;
  wire recovered_36_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_36_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_36_q == 1'b0))) recovered_36_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_36_q == (buff_wdata_n_60)))) recovered_36_q <= (buff_wdata_n_60);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_30_9b4b384
  reg recovered_37_q = 1'b0;
  assign m_axi_output_r_WDATA[30] = recovered_37_q;
  wire recovered_37_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_37_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_37_q == 1'b0))) recovered_37_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_37_q == (buff_wdata_n_32)))) recovered_37_q <= (buff_wdata_n_32);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_31_accbecf
  reg recovered_38_q = 1'b0;
  assign m_axi_output_r_WDATA[31] = recovered_38_q;
  wire recovered_38_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_38_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_38_q == 1'b0))) recovered_38_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_38_q == (buff_wdata_n_31)))) recovered_38_q <= (buff_wdata_n_31);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_3_e401113
  reg recovered_39_q = 1'b0;
  assign m_axi_output_r_WDATA[3] = recovered_39_q;
  wire recovered_39_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_39_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_39_q == 1'b0))) recovered_39_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_39_q == (buff_wdata_n_59)))) recovered_39_q <= (buff_wdata_n_59);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_4_e988420
  reg recovered_40_q = 1'b0;
  assign m_axi_output_r_WDATA[4] = recovered_40_q;
  wire recovered_40_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_40_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_40_q == 1'b0))) recovered_40_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_40_q == (buff_wdata_n_58)))) recovered_40_q <= (buff_wdata_n_58);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_5_18517c5
  reg recovered_41_q = 1'b0;
  assign m_axi_output_r_WDATA[5] = recovered_41_q;
  wire recovered_41_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_41_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_41_q == 1'b0))) recovered_41_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_41_q == (buff_wdata_n_57)))) recovered_41_q <= (buff_wdata_n_57);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_6_d90793c
  reg recovered_42_q = 1'b0;
  assign m_axi_output_r_WDATA[6] = recovered_42_q;
  wire recovered_42_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_42_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_42_q == 1'b0))) recovered_42_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_42_q == (buff_wdata_n_56)))) recovered_42_q <= (buff_wdata_n_56);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_7_06a7cf4
  reg recovered_43_q = 1'b0;
  assign m_axi_output_r_WDATA[7] = recovered_43_q;
  wire recovered_43_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_43_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_43_q == (buff_wdata_n_55)))) recovered_43_q <= (buff_wdata_n_55);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_8_61d7ccc
  reg recovered_44_q = 1'b0;
  assign m_axi_output_r_WDATA[8] = recovered_44_q;
  wire recovered_44_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_44_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_44_q == (buff_wdata_n_54)))) recovered_44_q <= (buff_wdata_n_54);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_data_buf_reg_9_c72e1b8
  reg recovered_45_q = 1'b0;
  assign m_axi_output_r_WDATA[9] = recovered_45_q;
  wire recovered_45_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_45_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_45_q == 1'b0))) recovered_45_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_45_q == (buff_wdata_n_53)))) recovered_45_q <= (buff_wdata_n_53);
  end

  system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_fifo esc_bus_equal_gen_fifo_burst_2697071 
       (.CO(first_sect),
        .D({esc_bus_equal_gen_fifo_burst_n_8_17dc7bd ,esc_bus_equal_gen_fifo_burst_n_9_8007697 ,esc_bus_equal_gen_fifo_burst_n_10_7c8bbbb ,esc_bus_equal_gen_fifo_burst_n_11_5909e96 ,esc_bus_equal_gen_fifo_burst_n_12_34a69c8 ,esc_bus_equal_gen_fifo_burst_n_13_c26be9e ,esc_bus_equal_gen_fifo_burst_n_14_c065c5d ,esc_bus_equal_gen_fifo_burst_n_15_d6b39e8 ,esc_bus_equal_gen_fifo_burst_n_16_c3236d4 ,esc_bus_equal_gen_fifo_burst_n_17_5894e72 ,esc_bus_equal_gen_fifo_burst_n_18_6956e12 ,esc_bus_equal_gen_fifo_burst_n_19_f40abca ,esc_bus_equal_gen_fifo_burst_n_20_8b50e36 ,esc_bus_equal_gen_fifo_burst_n_21_3f82d63 ,esc_bus_equal_gen_fifo_burst_n_22_9956bb3 ,esc_bus_equal_gen_fifo_burst_n_23_6ad7282 ,esc_bus_equal_gen_fifo_burst_n_24_4d7c0c3 ,esc_bus_equal_gen_fifo_burst_n_25_a348518 ,esc_bus_equal_gen_fifo_burst_n_26_4e81909 ,esc_bus_equal_gen_fifo_burst_n_27_cb0a1f0 ,esc_bus_equal_gen_fifo_burst_n_28_e7e2550 ,esc_bus_equal_gen_fifo_burst_n_29_d494d59 ,esc_bus_equal_gen_fifo_burst_n_30_b84bdbf ,esc_bus_equal_gen_fifo_burst_n_31_721a394 ,esc_bus_equal_gen_fifo_burst_n_32_c31df3c ,esc_bus_equal_gen_fifo_burst_n_33_772e8d0 ,esc_bus_equal_gen_fifo_burst_n_34_cc12236 ,esc_bus_equal_gen_fifo_burst_n_35_6521daf ,esc_bus_equal_gen_fifo_burst_n_36_445bf3c ,esc_bus_equal_gen_fifo_burst_n_37_820fc59 ,esc_bus_equal_gen_fifo_burst_n_38_b60cdf7 ,esc_bus_equal_gen_fifo_burst_n_39_aa82d48 ,esc_bus_equal_gen_fifo_burst_n_40_8b7cec1 ,esc_bus_equal_gen_fifo_burst_n_41_b94ba92 ,esc_bus_equal_gen_fifo_burst_n_42_dd23c0f ,esc_bus_equal_gen_fifo_burst_n_43_14e72d2 ,esc_bus_equal_gen_fifo_burst_n_44_1c0cfaa ,esc_bus_equal_gen_fifo_burst_n_45_b80267f ,esc_bus_equal_gen_fifo_burst_n_46_d2c1907 ,esc_bus_equal_gen_fifo_burst_n_47_3855ff4 ,esc_bus_equal_gen_fifo_burst_n_48_e40cb2f ,esc_bus_equal_gen_fifo_burst_n_49_f86f51b ,esc_bus_equal_gen_fifo_burst_n_50_a32939e ,esc_bus_equal_gen_fifo_burst_n_51_8547d41 ,esc_bus_equal_gen_fifo_burst_n_52_cc1c008 ,esc_bus_equal_gen_fifo_burst_n_53_ef2bee6 ,esc_bus_equal_gen_fifo_burst_n_54_207fdd9 ,esc_bus_equal_gen_fifo_burst_n_55_415c1c4 ,esc_bus_equal_gen_fifo_burst_n_56_02927c8 ,esc_bus_equal_gen_fifo_burst_n_57_9a24566 ,esc_bus_equal_gen_fifo_burst_n_58_0a624b0 ,esc_bus_equal_gen_fifo_burst_n_59_97d1831 }),
        .E(p_30_in),
        .Q(esc_bus_equal_gen_len_cnt_reg_755484c ),
        .SR(SR),
        .ap_clk(ap_clk),
        .ap_rst_n(ap_rst_n),
        .ap_rst_n_0(esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d ),
        .ap_rst_n_1(esc_bus_equal_gen_fifo_burst_n_4_d747600 ),
        .burst_valid(burst_valid),
        .esc_bus_equal_gen_len_cnt_reg_4_8139ef8 (esc_bus_equal_gen_fifo_burst_n_5_f6765b8 ),
        .esc_could_multi_bursts_awlen_buf_3__i_2_0_6ff1426 ({esc_sect_len_buf_reg_n_0__9_679de8d ,esc_sect_len_buf_reg_n_0__8_c195217 ,esc_sect_len_buf_reg_n_0__7_8a87bd5 ,esc_sect_len_buf_reg_n_0__6_00ec5ef ,esc_sect_len_buf_reg_n_0__5_f880a64 ,esc_sect_len_buf_reg_n_0__4_7dfbe71 ,esc_sect_len_buf_reg_n_0__3_4003b8b ,esc_sect_len_buf_reg_n_0__2_64bffbf ,esc_sect_len_buf_reg_n_0__1_fa0e016 ,esc_sect_len_buf_reg_n_0__0_2f5bb85 }),
        .esc_could_multi_bursts_awlen_buf_3__i_2_1_e13bd3f (esc_could_multi_bursts_loop_cnt_reg_275e801 ),
        .esc_could_multi_bursts_last_sect_buf_reg_5fd9311 (esc_bus_equal_gen_fifo_burst_n_66_97f8224 ),
        .esc_could_multi_bursts_last_sect_buf_reg_0_4134d6e (esc_could_multi_bursts_last_sect_buf_reg_n_0_659f5fa ),
        .fifo_burst_ready(fifo_burst_ready),
        .fifo_resp_ready(fifo_resp_ready),
        .fifo_wreq_valid(fifo_wreq_valid),
        .in(awlen_tmp),
        .last_sect_buf(last_sect_buf),
        .next_wreq(next_wreq),
        .push(push_0),
        .sect_cnt0(sect_cnt0),
        .esc_sect_cnt_reg_0_053187c (esc_sect_cnt_reg_n_0__0_cf5038d ),
        .esc_sect_cnt_reg_51_7c99099 ({esc_start_addr_reg_n_0__63_6c9d71f ,esc_start_addr_reg_n_0__62_067c30f ,esc_start_addr_reg_n_0__61_d0861cf ,esc_start_addr_reg_n_0__60_9bfecb1 ,esc_start_addr_reg_n_0__59_91cd7d0 ,esc_start_addr_reg_n_0__58_94d4f4b ,esc_start_addr_reg_n_0__57_897c5a0 ,esc_start_addr_reg_n_0__56_ed05e9e ,esc_start_addr_reg_n_0__55_f2a438b ,esc_start_addr_reg_n_0__54_6ca5236 ,esc_start_addr_reg_n_0__53_391e956 ,esc_start_addr_reg_n_0__52_4ddab7f ,esc_start_addr_reg_n_0__51_71ee3d6 ,esc_start_addr_reg_n_0__50_4a0d627 ,esc_start_addr_reg_n_0__49_f51d0fb ,esc_start_addr_reg_n_0__48_bba970f ,esc_start_addr_reg_n_0__47_38b6f54 ,esc_start_addr_reg_n_0__46_ffff99b ,esc_start_addr_reg_n_0__45_c02f4ba ,esc_start_addr_reg_n_0__44_91d3e92 ,esc_start_addr_reg_n_0__43_eeeef11 ,esc_start_addr_reg_n_0__42_a3d52cc ,esc_start_addr_reg_n_0__41_aca3f17 ,esc_start_addr_reg_n_0__40_44358a2 ,esc_start_addr_reg_n_0__39_9f399ca ,esc_start_addr_reg_n_0__38_abcede3 ,esc_start_addr_reg_n_0__37_49e2d9d ,esc_start_addr_reg_n_0__36_1b35e42 ,esc_start_addr_reg_n_0__35_e55187f ,esc_start_addr_reg_n_0__34_7048a69 ,esc_start_addr_reg_n_0__33_e2508d5 ,esc_start_addr_reg_n_0__32_d304ae3 ,esc_start_addr_reg_n_0__31_6881f62 ,esc_start_addr_reg_n_0__30_fa7e7f5 ,esc_start_addr_reg_n_0__29_aa2b4b7 ,esc_start_addr_reg_n_0__28_0abd4bb ,esc_start_addr_reg_n_0__27_4bb8d27 ,esc_start_addr_reg_n_0__26_5efe7d3 ,esc_start_addr_reg_n_0__25_b477c1e ,esc_start_addr_reg_n_0__24_1d34d3b ,esc_start_addr_reg_n_0__23_907ba78 ,esc_start_addr_reg_n_0__22_ba17a60 ,esc_start_addr_reg_n_0__21_9efa866 ,esc_start_addr_reg_n_0__20_a055fe3 ,esc_start_addr_reg_n_0__19_3510eae ,esc_start_addr_reg_n_0__18_7d4f45f ,esc_start_addr_reg_n_0__17_a7c7f14 ,esc_start_addr_reg_n_0__16_c2276cc ,esc_start_addr_reg_n_0__15_3a25f9c ,esc_start_addr_reg_n_0__14_726da08 ,esc_start_addr_reg_n_0__13_f3dfe34 ,esc_start_addr_reg_n_0__12_0ffbef5 }),
        .esc_sect_len_buf_reg_3_9899048 (esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938 ),
        .esc_sect_len_buf_reg_3__0_cb18dca (AWVALID_Dummy),
        .esc_sect_len_buf_reg_3__1_e5dcb06 (esc_could_multi_bursts_sect_handling_reg_n_0_737ec10 ),
        .esc_sect_len_buf_reg_7_99d7f4c (esc_bus_equal_gen_fifo_burst_n_60_ce9cee6 ),
        .wreq_handling_reg(esc_bus_equal_gen_fifo_burst_n_6_0b78b36 ),
        .wreq_handling_reg_0(esc_bus_equal_gen_fifo_burst_n_65_9824fa3 ),
        .wreq_handling_reg_1(wreq_handling_reg_n_0),
        .wreq_handling_reg_2(last_sect),
        .wreq_handling_reg_3(fifo_wreq_valid_buf_reg_n_0));

  // Reconstructed LUT1: esc_bus_equal_gen_len_cnt_0__i_1_382cc53
  assign p_0_in__0[0] = ~(esc_bus_equal_gen_len_cnt_reg_755484c [0]);

  // Reconstructed LUT2: esc_bus_equal_gen_len_cnt_1__i_1_2a1f875
  assign p_0_in__0[1] = ((esc_bus_equal_gen_len_cnt_reg_755484c [1]) ? (~(esc_bus_equal_gen_len_cnt_reg_755484c [0])) : (esc_bus_equal_gen_len_cnt_reg_755484c [0]));

  // Reconstructed LUT3: esc_bus_equal_gen_len_cnt_2__i_1_6d97c18
  assign p_0_in__0[2] = ((esc_bus_equal_gen_len_cnt_reg_755484c [0]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [1]) ? (~(esc_bus_equal_gen_len_cnt_reg_755484c [2])) : (esc_bus_equal_gen_len_cnt_reg_755484c [2]))) : (esc_bus_equal_gen_len_cnt_reg_755484c [2]));

  // Reconstructed LUT4: esc_bus_equal_gen_len_cnt_3__i_1_74adf2f
  assign p_0_in__0[3] = ((esc_bus_equal_gen_len_cnt_reg_755484c [2]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [1]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [0]) ? (~(esc_bus_equal_gen_len_cnt_reg_755484c [3])) : (esc_bus_equal_gen_len_cnt_reg_755484c [3]))) : (esc_bus_equal_gen_len_cnt_reg_755484c [3]))) : (esc_bus_equal_gen_len_cnt_reg_755484c [3]));

  // Reconstructed LUT5: esc_bus_equal_gen_len_cnt_4__i_1_487c14b
  assign p_0_in__0[4] = ((esc_bus_equal_gen_len_cnt_reg_755484c [3]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [0]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [1]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [2]) ? (~(esc_bus_equal_gen_len_cnt_reg_755484c [4])) : (esc_bus_equal_gen_len_cnt_reg_755484c [4]))) : (esc_bus_equal_gen_len_cnt_reg_755484c [4]))) : (esc_bus_equal_gen_len_cnt_reg_755484c [4]))) : (esc_bus_equal_gen_len_cnt_reg_755484c [4]));

  // Reconstructed LUT6: esc_bus_equal_gen_len_cnt_5__i_1_d86a667
  assign p_0_in__0[5] = ((esc_bus_equal_gen_len_cnt_reg_755484c [4]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [2]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [1]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [0]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [3]) ? (~(esc_bus_equal_gen_len_cnt_reg_755484c [5])) : (esc_bus_equal_gen_len_cnt_reg_755484c [5]))) : (esc_bus_equal_gen_len_cnt_reg_755484c [5]))) : (esc_bus_equal_gen_len_cnt_reg_755484c [5]))) : (esc_bus_equal_gen_len_cnt_reg_755484c [5]))) : (esc_bus_equal_gen_len_cnt_reg_755484c [5]));

  // Reconstructed LUT2: esc_bus_equal_gen_len_cnt_6__i_1_357646b
  assign p_0_in__0[6] = ((esc_bus_equal_gen_len_cnt_7__i_3_n_0_f6425e9) ? (~(esc_bus_equal_gen_len_cnt_reg_755484c [6])) : (esc_bus_equal_gen_len_cnt_reg_755484c [6]));

  // Reconstructed LUT3: esc_bus_equal_gen_len_cnt_7__i_2_c0e7a41
  assign p_0_in__0[7] = ((esc_bus_equal_gen_len_cnt_reg_755484c [6]) ? (((esc_bus_equal_gen_len_cnt_7__i_3_n_0_f6425e9) ? (~(esc_bus_equal_gen_len_cnt_reg_755484c [7])) : (esc_bus_equal_gen_len_cnt_reg_755484c [7]))) : (esc_bus_equal_gen_len_cnt_reg_755484c [7]));

  // Reconstructed LUT6: esc_bus_equal_gen_len_cnt_7__i_3_efb8c33
  assign esc_bus_equal_gen_len_cnt_7__i_3_n_0_f6425e9 = ((esc_bus_equal_gen_len_cnt_reg_755484c [4]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [2]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [1]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [0]) ? (((esc_bus_equal_gen_len_cnt_reg_755484c [3]) ? (esc_bus_equal_gen_len_cnt_reg_755484c [5]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_bus_equal_gen_len_cnt_reg_0_1064a06
  reg recovered_56_q = 1'b0;
  assign esc_bus_equal_gen_len_cnt_reg_755484c [0] = recovered_56_q;
  wire recovered_56_reset = ((buff_wdata_n_22)) && ((buff_wdata_n_22) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_56_reset || (((buff_wdata_n_22) === 1'bx) && (recovered_56_q == 1'b0))) recovered_56_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_56_q == (p_0_in__0[0])))) recovered_56_q <= (p_0_in__0[0]);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_len_cnt_reg_1_20b1544
  reg recovered_57_q = 1'b0;
  assign esc_bus_equal_gen_len_cnt_reg_755484c [1] = recovered_57_q;
  wire recovered_57_reset = ((buff_wdata_n_22)) && ((buff_wdata_n_22) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_57_reset || (((buff_wdata_n_22) === 1'bx) && (recovered_57_q == 1'b0))) recovered_57_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_57_q == (p_0_in__0[1])))) recovered_57_q <= (p_0_in__0[1]);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_len_cnt_reg_2_fc74c9e
  reg recovered_58_q = 1'b0;
  assign esc_bus_equal_gen_len_cnt_reg_755484c [2] = recovered_58_q;
  wire recovered_58_reset = ((buff_wdata_n_22)) && ((buff_wdata_n_22) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_58_reset || (((buff_wdata_n_22) === 1'bx) && (recovered_58_q == 1'b0))) recovered_58_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_58_q == (p_0_in__0[2])))) recovered_58_q <= (p_0_in__0[2]);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_len_cnt_reg_3_e3ed3de
  reg recovered_59_q = 1'b0;
  assign esc_bus_equal_gen_len_cnt_reg_755484c [3] = recovered_59_q;
  wire recovered_59_reset = ((buff_wdata_n_22)) && ((buff_wdata_n_22) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_59_reset || (((buff_wdata_n_22) === 1'bx) && (recovered_59_q == 1'b0))) recovered_59_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_59_q == (p_0_in__0[3])))) recovered_59_q <= (p_0_in__0[3]);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_len_cnt_reg_4_8139ef8
  reg recovered_60_q = 1'b0;
  assign esc_bus_equal_gen_len_cnt_reg_755484c [4] = recovered_60_q;
  wire recovered_60_reset = ((buff_wdata_n_22)) && ((buff_wdata_n_22) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_60_reset || (((buff_wdata_n_22) === 1'bx) && (recovered_60_q == 1'b0))) recovered_60_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_60_q == (p_0_in__0[4])))) recovered_60_q <= (p_0_in__0[4]);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_len_cnt_reg_5_d72365b
  reg recovered_61_q = 1'b0;
  assign esc_bus_equal_gen_len_cnt_reg_755484c [5] = recovered_61_q;
  wire recovered_61_reset = ((buff_wdata_n_22)) && ((buff_wdata_n_22) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_61_reset || (((buff_wdata_n_22) === 1'bx) && (recovered_61_q == 1'b0))) recovered_61_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_61_q == (p_0_in__0[5])))) recovered_61_q <= (p_0_in__0[5]);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_len_cnt_reg_6_460eec5
  reg recovered_62_q = 1'b0;
  assign esc_bus_equal_gen_len_cnt_reg_755484c [6] = recovered_62_q;
  wire recovered_62_reset = ((buff_wdata_n_22)) && ((buff_wdata_n_22) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_62_reset || (((buff_wdata_n_22) === 1'bx) && (recovered_62_q == 1'b0))) recovered_62_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_62_q == (p_0_in__0[6])))) recovered_62_q <= (p_0_in__0[6]);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_len_cnt_reg_7_077fe2f
  reg recovered_63_q = 1'b0;
  assign esc_bus_equal_gen_len_cnt_reg_755484c [7] = recovered_63_q;
  wire recovered_63_reset = ((buff_wdata_n_22)) && ((buff_wdata_n_22) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_63_reset || (((buff_wdata_n_22) === 1'bx) && (recovered_63_q == 1'b0))) recovered_63_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_63_q == (p_0_in__0[7])))) recovered_63_q <= (p_0_in__0[7]);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_strb_buf_reg_0_6e7acad
  reg recovered_64_q = 1'b0;
  assign m_axi_output_r_WSTRB[0] = recovered_64_q;
  wire recovered_64_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_64_reset || (((SR) === 1'bx) && (recovered_64_q == 1'b0))) recovered_64_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_64_q == (tmp_strb[0])))) recovered_64_q <= (tmp_strb[0]);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_strb_buf_reg_1_c475019
  reg recovered_65_q = 1'b0;
  assign m_axi_output_r_WSTRB[1] = recovered_65_q;
  wire recovered_65_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_65_reset || (((SR) === 1'bx) && (recovered_65_q == 1'b0))) recovered_65_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_65_q == (tmp_strb[1])))) recovered_65_q <= (tmp_strb[1]);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_strb_buf_reg_2_ffa3511
  reg recovered_66_q = 1'b0;
  assign m_axi_output_r_WSTRB[2] = recovered_66_q;
  wire recovered_66_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_66_reset || (((SR) === 1'bx) && (recovered_66_q == 1'b0))) recovered_66_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_66_q == (tmp_strb[2])))) recovered_66_q <= (tmp_strb[2]);
  end

  // Reconstructed FDRE: esc_bus_equal_gen_strb_buf_reg_3_6eee9a7
  reg recovered_67_q = 1'b0;
  assign m_axi_output_r_WSTRB[3] = recovered_67_q;
  wire recovered_67_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_67_reset || (((SR) === 1'bx) && (recovered_67_q == 1'b0))) recovered_67_q <= 1'b0;
    else if ((p_30_in) || ((p_30_in) === 1'bz) || (((p_30_in) === 1'bx) && (recovered_67_q == (tmp_strb[3])))) recovered_67_q <= (tmp_strb[3]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_AWVALID_Dummy_reg_9706e3b
  reg recovered_68_q = 1'b0;
  assign AWVALID_Dummy = recovered_68_q;
  wire recovered_68_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_68_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_68_q == 1'b0))) recovered_68_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_68_q == (fifo_resp_n_2)))) recovered_68_q <= (fifo_resp_n_2);
  end

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_10__i_1_844790e
  assign awaddr_tmp[10] = ((data1[10]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__10_870b69d) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__10_870b69d) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_11__i_1_f7e0875
  assign awaddr_tmp[11] = ((data1[11]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__11_3acc932) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__11_3acc932) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_12__i_1_cebde15
  assign awaddr_tmp[12] = ((data1[12]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__12_3345b33) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__12_3345b33) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_13__i_1_38019ce
  assign awaddr_tmp[13] = ((data1[13]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__13_c419bb0) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__13_c419bb0) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_14__i_1_5b26ada
  assign awaddr_tmp[14] = ((data1[14]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__14_be30b67) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__14_be30b67) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_15__i_1_02eee2e
  assign awaddr_tmp[15] = ((data1[15]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__15_83b1580) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__15_83b1580) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_16__i_1_cb190d3
  assign awaddr_tmp[16] = ((data1[16]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__16_8d80ab0) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__16_8d80ab0) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_17__i_1_0181305
  assign awaddr_tmp[17] = ((data1[17]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__17_b463da9) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__17_b463da9) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_18__i_1_1021fae
  assign awaddr_tmp[18] = ((data1[18]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__18_8f1b7e0) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__18_8f1b7e0) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_19__i_1_d1d0792
  assign awaddr_tmp[19] = ((data1[19]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__19_205beba) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__19_205beba) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_20__i_1_62a8ec3
  assign awaddr_tmp[20] = ((data1[20]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__20_64eade7) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__20_64eade7) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_21__i_1_c8c451e
  assign awaddr_tmp[21] = ((data1[21]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__21_15c29c5) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__21_15c29c5) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_22__i_1_d14b686
  assign awaddr_tmp[22] = ((data1[22]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__22_b0a0c3d) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__22_b0a0c3d) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_23__i_1_f54e0f5
  assign awaddr_tmp[23] = ((data1[23]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__23_31ab99b) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__23_31ab99b) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_24__i_1_f8666d1
  assign awaddr_tmp[24] = ((data1[24]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__24_9a91ab6) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__24_9a91ab6) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_25__i_1_ccbbc98
  assign awaddr_tmp[25] = ((data1[25]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__25_fd4334d) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__25_fd4334d) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_26__i_1_10a76e3
  assign awaddr_tmp[26] = ((data1[26]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__26_4b2b197) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__26_4b2b197) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_27__i_1_b050dc6
  assign awaddr_tmp[27] = ((data1[27]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__27_dc5c286) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__27_dc5c286) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_28__i_1_b645cd6
  assign awaddr_tmp[28] = ((data1[28]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__28_ab688cc) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__28_ab688cc) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_29__i_1_b1e9f13
  assign awaddr_tmp[29] = ((data1[29]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__29_5fda2c0) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__29_5fda2c0) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_2__i_1_cde1777
  assign awaddr_tmp[2] = ((data1[2]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__2_c2c1041) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__2_c2c1041) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_30__i_1_4bbf945
  assign awaddr_tmp[30] = ((data1[30]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__30_160e1b6) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__30_160e1b6) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_31__i_1_051d984
  assign awaddr_tmp[31] = ((data1[31]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__31_f1a8fbc) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__31_f1a8fbc) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_32__i_1_f1fdfe9
  assign awaddr_tmp[32] = ((data1[32]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__32_c7aeb52) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__32_c7aeb52) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_33__i_1_6d489e6
  assign awaddr_tmp[33] = ((data1[33]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__33_3443c27) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__33_3443c27) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_34__i_1_ea7726c
  assign awaddr_tmp[34] = ((data1[34]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__34_c59005e) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__34_c59005e) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_35__i_1_6d55029
  assign awaddr_tmp[35] = ((data1[35]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__35_4d0f93d) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__35_4d0f93d) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_36__i_1_19ba604
  assign awaddr_tmp[36] = ((data1[36]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__36_d80e692) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__36_d80e692) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_37__i_1_38524da
  assign awaddr_tmp[37] = ((data1[37]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__37_18b7f7b) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__37_18b7f7b) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_38__i_1_3e05f1c
  assign awaddr_tmp[38] = ((data1[38]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__38_a55959a) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__38_a55959a) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_39__i_1_e093724
  assign awaddr_tmp[39] = ((data1[39]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__39_bee2ecd) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__39_bee2ecd) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_3__i_1_834c3dc
  assign awaddr_tmp[3] = ((data1[3]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__3_fe3572f) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__3_fe3572f) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_40__i_1_0e2740c
  assign awaddr_tmp[40] = ((data1[40]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__40_1eb7798) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__40_1eb7798) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_41__i_1_8585d0a
  assign awaddr_tmp[41] = ((data1[41]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__41_2d6e174) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__41_2d6e174) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_42__i_1_98cce07
  assign awaddr_tmp[42] = ((data1[42]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__42_6a4a4fb) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__42_6a4a4fb) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_43__i_1_5d5ad9d
  assign awaddr_tmp[43] = ((data1[43]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__43_99fa7a2) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__43_99fa7a2) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_44__i_1_7d708bf
  assign awaddr_tmp[44] = ((data1[44]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__44_46a4975) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__44_46a4975) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_45__i_1_dbf707b
  assign awaddr_tmp[45] = ((data1[45]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__45_97ae151) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__45_97ae151) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_46__i_1_f809bdf
  assign awaddr_tmp[46] = ((data1[46]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__46_c8d2917) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__46_c8d2917) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_47__i_1_bfeae06
  assign awaddr_tmp[47] = ((data1[47]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__47_205d244) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__47_205d244) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_48__i_1_5b4fffc
  assign awaddr_tmp[48] = ((data1[48]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__48_870c0bb) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__48_870c0bb) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_49__i_1_81f5cf1
  assign awaddr_tmp[49] = ((data1[49]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__49_ee79105) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__49_ee79105) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_4__i_1_652cd9a
  assign awaddr_tmp[4] = ((data1[4]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__4_363722f) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__4_363722f) : (1'b0))));

  // Reconstructed LUT4: esc_could_multi_bursts_awaddr_buf_4__i_3_20728e2
  assign esc_could_multi_bursts_awaddr_buf_4__i_3_n_0_a1e332e = ((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [2]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [1]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [0]) ? (m_axi_output_r_AWADDR[2]) : (~(m_axi_output_r_AWADDR[2])))) : (~(m_axi_output_r_AWADDR[2])))) : (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [1]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [0]) ? (~(m_axi_output_r_AWADDR[2])) : (m_axi_output_r_AWADDR[2]))) : (m_axi_output_r_AWADDR[2]))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_4__i_4_05e5b9c
  assign esc_could_multi_bursts_awaddr_buf_4__i_4_n_0_cf5f918 = ((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [0]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [1]) ? (m_axi_output_r_AWADDR[1]) : (~(m_axi_output_r_AWADDR[1])))) : (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [1]) ? (~(m_axi_output_r_AWADDR[1])) : (m_axi_output_r_AWADDR[1]))));

  // Reconstructed LUT2: esc_could_multi_bursts_awaddr_buf_4__i_5_fe9c861
  assign esc_could_multi_bursts_awaddr_buf_4__i_5_n_0_638540b = ((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [0]) ? (m_axi_output_r_AWADDR[0]) : (~(m_axi_output_r_AWADDR[0])));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_50__i_1_9e01c30
  assign awaddr_tmp[50] = ((data1[50]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__50_4c8d65a) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__50_4c8d65a) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_51__i_1_c156f77
  assign awaddr_tmp[51] = ((data1[51]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__51_d4fe5b5) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__51_d4fe5b5) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_52__i_1_9d0e87e
  assign awaddr_tmp[52] = ((data1[52]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__52_9d48c85) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__52_9d48c85) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_53__i_1_248d8c3
  assign awaddr_tmp[53] = ((data1[53]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__53_7d93328) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__53_7d93328) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_54__i_1_55c1a2d
  assign awaddr_tmp[54] = ((data1[54]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__54_7071cc2) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__54_7071cc2) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_55__i_1_32e7d82
  assign awaddr_tmp[55] = ((data1[55]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__55_fa58e13) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__55_fa58e13) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_56__i_1_435caf8
  assign awaddr_tmp[56] = ((data1[56]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__56_697e16f) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__56_697e16f) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_57__i_1_70245e2
  assign awaddr_tmp[57] = ((data1[57]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__57_288be70) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__57_288be70) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_58__i_1_a19c1ac
  assign awaddr_tmp[58] = ((data1[58]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__58_a7911e8) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__58_a7911e8) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_59__i_1_93f5318
  assign awaddr_tmp[59] = ((data1[59]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__59_73bc156) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__59_73bc156) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_5__i_1_2e3819b
  assign awaddr_tmp[5] = ((data1[5]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__5_e2303ea) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__5_e2303ea) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_60__i_1_4538c50
  assign awaddr_tmp[60] = ((data1[60]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__60_537e0e3) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__60_537e0e3) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_61__i_1_21b233d
  assign awaddr_tmp[61] = ((data1[61]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__61_0fe6dc2) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__61_0fe6dc2) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_62__i_1_d323aaa
  assign awaddr_tmp[62] = ((data1[62]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__62_7a67c6d) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__62_7a67c6d) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_63__i_2_95c076e
  assign awaddr_tmp[63] = ((data1[63]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__63_ebd5f7d) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__63_ebd5f7d) : (1'b0))));

  // Reconstructed LUT6: esc_could_multi_bursts_awaddr_buf_63__i_4_537a92e
  assign esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf = ((esc_could_multi_bursts_loop_cnt_reg_275e801 [5]) ? (1'b0) : (((esc_could_multi_bursts_loop_cnt_reg_275e801 [4]) ? (1'b0) : (((esc_could_multi_bursts_loop_cnt_reg_275e801 [3]) ? (1'b0) : (((esc_could_multi_bursts_loop_cnt_reg_275e801 [2]) ? (1'b0) : (((esc_could_multi_bursts_loop_cnt_reg_275e801 [0]) ? (1'b0) : (~(esc_could_multi_bursts_loop_cnt_reg_275e801 [1])))))))))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_6__i_1_5993af8
  assign awaddr_tmp[6] = ((data1[6]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__6_a42bc93) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__6_a42bc93) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_7__i_1_3c1f802
  assign awaddr_tmp[7] = ((data1[7]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__7_f3397b7) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__7_f3397b7) : (1'b0))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_8__i_1_c21a42d
  assign awaddr_tmp[8] = ((data1[8]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__8_2d0930b) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__8_2d0930b) : (1'b0))));

  // Reconstructed LUT5: esc_could_multi_bursts_awaddr_buf_8__i_3_2cc1ec9
  assign esc_could_multi_bursts_awaddr_buf_8__i_3_n_0_12d65fb = ((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [3]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [2]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [0]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [1]) ? (~(m_axi_output_r_AWADDR[4])) : (m_axi_output_r_AWADDR[4]))) : (m_axi_output_r_AWADDR[4]))) : (m_axi_output_r_AWADDR[4]))) : (m_axi_output_r_AWADDR[4]));

  // Reconstructed LUT5: esc_could_multi_bursts_awaddr_buf_8__i_4_a47bf33
  assign esc_could_multi_bursts_awaddr_buf_8__i_4_n_0_266e921 = ((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [3]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [2]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [0]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [1]) ? (m_axi_output_r_AWADDR[3]) : (~(m_axi_output_r_AWADDR[3])))) : (~(m_axi_output_r_AWADDR[3])))) : (~(m_axi_output_r_AWADDR[3])))) : (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [2]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [0]) ? (((esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [1]) ? (~(m_axi_output_r_AWADDR[3])) : (m_axi_output_r_AWADDR[3]))) : (m_axi_output_r_AWADDR[3]))) : (m_axi_output_r_AWADDR[3]))));

  // Reconstructed LUT3: esc_could_multi_bursts_awaddr_buf_9__i_1_952b9c5
  assign awaddr_tmp[9] = ((data1[9]) ? (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__9_dd7820d) : (1'b1))) : (((esc_could_multi_bursts_awaddr_buf_63__i_4_n_0_13574cf) ? (esc_sect_addr_buf_reg_n_0__9_dd7820d) : (1'b0))));

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_10_be2b7e4
  reg recovered_137_q = 1'b0;
  assign m_axi_output_r_AWADDR[8] = recovered_137_q;
  wire recovered_137_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_137_reset || (((SR) === 1'bx) && (recovered_137_q == 1'b0))) recovered_137_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_137_q == (awaddr_tmp[10])))) recovered_137_q <= (awaddr_tmp[10]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_11_e84e31d
  reg recovered_138_q = 1'b0;
  assign m_axi_output_r_AWADDR[9] = recovered_138_q;
  wire recovered_138_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_138_reset || (((SR) === 1'bx) && (recovered_138_q == 1'b0))) recovered_138_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_138_q == (awaddr_tmp[11])))) recovered_138_q <= (awaddr_tmp[11]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_12_7191000
  reg recovered_139_q = 1'b0;
  assign m_axi_output_r_AWADDR[10] = recovered_139_q;
  wire recovered_139_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_139_reset || (((SR) === 1'bx) && (recovered_139_q == 1'b0))) recovered_139_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_139_q == (awaddr_tmp[12])))) recovered_139_q <= (awaddr_tmp[12]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_12__i_2_da25a01
  wire [3:0] recovered_140_co, recovered_140_o, recovered_140_s, recovered_140_di;
  assign recovered_140_s = m_axi_output_r_AWADDR[10:7];
  assign recovered_140_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,m_axi_output_r_AWADDR[8:7]};
  wire recovered_140_ci = ((esc_could_multi_bursts_awaddr_buf_reg_8__i_2_n_0_7bbebf8) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_8__i_2_n_0_7bbebf8);
  wire recovered_140_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_140_o[0] = recovered_140_s[0] ^ (recovered_140_ci || recovered_140_cy);
  assign recovered_140_co[0] = (recovered_140_s[0] & (recovered_140_ci || recovered_140_cy)) | (~recovered_140_s[0] & recovered_140_di[0]);
  assign recovered_140_o[1] = recovered_140_s[1] ^ recovered_140_co[0];
  assign recovered_140_co[1] = (recovered_140_s[1] & recovered_140_co[0]) | (~recovered_140_s[1] & recovered_140_di[1]);
  assign recovered_140_o[2] = recovered_140_s[2] ^ recovered_140_co[1];
  assign recovered_140_co[2] = (recovered_140_s[2] & recovered_140_co[1]) | (~recovered_140_s[2] & recovered_140_di[2]);
  assign recovered_140_o[3] = recovered_140_s[3] ^ recovered_140_co[2];
  assign recovered_140_co[3] = (recovered_140_s[3] & recovered_140_co[2]) | (~recovered_140_s[3] & recovered_140_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_12__i_2_n_0_f6b7f01 ,esc_NLW_could_multi_bursts_awaddr_buf_reg_12__i_2_CO_UNCONNECTED_d0c471f [2:0]} = recovered_140_co;
  assign data1[12:9] = recovered_140_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_13_1dc0b27
  reg recovered_141_q = 1'b0;
  assign m_axi_output_r_AWADDR[11] = recovered_141_q;
  wire recovered_141_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_141_reset || (((SR) === 1'bx) && (recovered_141_q == 1'b0))) recovered_141_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_141_q == (awaddr_tmp[13])))) recovered_141_q <= (awaddr_tmp[13]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_14_9ea6e4a
  reg recovered_142_q = 1'b0;
  assign m_axi_output_r_AWADDR[12] = recovered_142_q;
  wire recovered_142_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_142_reset || (((SR) === 1'bx) && (recovered_142_q == 1'b0))) recovered_142_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_142_q == (awaddr_tmp[14])))) recovered_142_q <= (awaddr_tmp[14]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_15_58aa630
  reg recovered_143_q = 1'b0;
  assign m_axi_output_r_AWADDR[13] = recovered_143_q;
  wire recovered_143_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_143_reset || (((SR) === 1'bx) && (recovered_143_q == 1'b0))) recovered_143_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_143_q == (awaddr_tmp[15])))) recovered_143_q <= (awaddr_tmp[15]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_16_f23fa72
  reg recovered_144_q = 1'b0;
  assign m_axi_output_r_AWADDR[14] = recovered_144_q;
  wire recovered_144_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_144_reset || (((SR) === 1'bx) && (recovered_144_q == 1'b0))) recovered_144_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_144_q == (awaddr_tmp[16])))) recovered_144_q <= (awaddr_tmp[16]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_16__i_2_e3b1454
  wire [3:0] recovered_145_co, recovered_145_o, recovered_145_s, recovered_145_di;
  assign recovered_145_s = m_axi_output_r_AWADDR[14:11];
  assign recovered_145_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_145_ci = ((esc_could_multi_bursts_awaddr_buf_reg_12__i_2_n_0_f6b7f01) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_12__i_2_n_0_f6b7f01);
  wire recovered_145_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_145_o[0] = recovered_145_s[0] ^ (recovered_145_ci || recovered_145_cy);
  assign recovered_145_co[0] = (recovered_145_s[0] & (recovered_145_ci || recovered_145_cy)) | (~recovered_145_s[0] & recovered_145_di[0]);
  assign recovered_145_o[1] = recovered_145_s[1] ^ recovered_145_co[0];
  assign recovered_145_co[1] = (recovered_145_s[1] & recovered_145_co[0]) | (~recovered_145_s[1] & recovered_145_di[1]);
  assign recovered_145_o[2] = recovered_145_s[2] ^ recovered_145_co[1];
  assign recovered_145_co[2] = (recovered_145_s[2] & recovered_145_co[1]) | (~recovered_145_s[2] & recovered_145_di[2]);
  assign recovered_145_o[3] = recovered_145_s[3] ^ recovered_145_co[2];
  assign recovered_145_co[3] = (recovered_145_s[3] & recovered_145_co[2]) | (~recovered_145_s[3] & recovered_145_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_16__i_2_n_0_1d1f725 ,esc_NLW_could_multi_bursts_awaddr_buf_reg_16__i_2_CO_UNCONNECTED_61c8e35 [2:0]} = recovered_145_co;
  assign data1[16:13] = recovered_145_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_17_e56bfc9
  reg recovered_146_q = 1'b0;
  assign m_axi_output_r_AWADDR[15] = recovered_146_q;
  wire recovered_146_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_146_reset || (((SR) === 1'bx) && (recovered_146_q == 1'b0))) recovered_146_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_146_q == (awaddr_tmp[17])))) recovered_146_q <= (awaddr_tmp[17]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_18_f350bed
  reg recovered_147_q = 1'b0;
  assign m_axi_output_r_AWADDR[16] = recovered_147_q;
  wire recovered_147_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_147_reset || (((SR) === 1'bx) && (recovered_147_q == 1'b0))) recovered_147_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_147_q == (awaddr_tmp[18])))) recovered_147_q <= (awaddr_tmp[18]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_19_8462024
  reg recovered_148_q = 1'b0;
  assign m_axi_output_r_AWADDR[17] = recovered_148_q;
  wire recovered_148_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_148_reset || (((SR) === 1'bx) && (recovered_148_q == 1'b0))) recovered_148_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_148_q == (awaddr_tmp[19])))) recovered_148_q <= (awaddr_tmp[19]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_20_93c8ad4
  reg recovered_149_q = 1'b0;
  assign m_axi_output_r_AWADDR[18] = recovered_149_q;
  wire recovered_149_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_149_reset || (((SR) === 1'bx) && (recovered_149_q == 1'b0))) recovered_149_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_149_q == (awaddr_tmp[20])))) recovered_149_q <= (awaddr_tmp[20]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_20__i_2_3ab2c78
  wire [3:0] recovered_150_co, recovered_150_o, recovered_150_s, recovered_150_di;
  assign recovered_150_s = m_axi_output_r_AWADDR[18:15];
  assign recovered_150_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_150_ci = ((esc_could_multi_bursts_awaddr_buf_reg_16__i_2_n_0_1d1f725) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_16__i_2_n_0_1d1f725);
  wire recovered_150_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_150_o[0] = recovered_150_s[0] ^ (recovered_150_ci || recovered_150_cy);
  assign recovered_150_co[0] = (recovered_150_s[0] & (recovered_150_ci || recovered_150_cy)) | (~recovered_150_s[0] & recovered_150_di[0]);
  assign recovered_150_o[1] = recovered_150_s[1] ^ recovered_150_co[0];
  assign recovered_150_co[1] = (recovered_150_s[1] & recovered_150_co[0]) | (~recovered_150_s[1] & recovered_150_di[1]);
  assign recovered_150_o[2] = recovered_150_s[2] ^ recovered_150_co[1];
  assign recovered_150_co[2] = (recovered_150_s[2] & recovered_150_co[1]) | (~recovered_150_s[2] & recovered_150_di[2]);
  assign recovered_150_o[3] = recovered_150_s[3] ^ recovered_150_co[2];
  assign recovered_150_co[3] = (recovered_150_s[3] & recovered_150_co[2]) | (~recovered_150_s[3] & recovered_150_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_20__i_2_n_0_6c82cc5 ,esc_NLW_could_multi_bursts_awaddr_buf_reg_20__i_2_CO_UNCONNECTED_0a83d0f [2:0]} = recovered_150_co;
  assign data1[20:17] = recovered_150_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_21_6d9e790
  reg recovered_151_q = 1'b0;
  assign m_axi_output_r_AWADDR[19] = recovered_151_q;
  wire recovered_151_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_151_reset || (((SR) === 1'bx) && (recovered_151_q == 1'b0))) recovered_151_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_151_q == (awaddr_tmp[21])))) recovered_151_q <= (awaddr_tmp[21]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_22_9336625
  reg recovered_152_q = 1'b0;
  assign m_axi_output_r_AWADDR[20] = recovered_152_q;
  wire recovered_152_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_152_reset || (((SR) === 1'bx) && (recovered_152_q == 1'b0))) recovered_152_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_152_q == (awaddr_tmp[22])))) recovered_152_q <= (awaddr_tmp[22]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_23_2e59007
  reg recovered_153_q = 1'b0;
  assign m_axi_output_r_AWADDR[21] = recovered_153_q;
  wire recovered_153_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_153_reset || (((SR) === 1'bx) && (recovered_153_q == 1'b0))) recovered_153_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_153_q == (awaddr_tmp[23])))) recovered_153_q <= (awaddr_tmp[23]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_24_d1bd7f6
  reg recovered_154_q = 1'b0;
  assign m_axi_output_r_AWADDR[22] = recovered_154_q;
  wire recovered_154_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_154_reset || (((SR) === 1'bx) && (recovered_154_q == 1'b0))) recovered_154_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_154_q == (awaddr_tmp[24])))) recovered_154_q <= (awaddr_tmp[24]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_24__i_2_cd8d422
  wire [3:0] recovered_155_co, recovered_155_o, recovered_155_s, recovered_155_di;
  assign recovered_155_s = m_axi_output_r_AWADDR[22:19];
  assign recovered_155_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_155_ci = ((esc_could_multi_bursts_awaddr_buf_reg_20__i_2_n_0_6c82cc5) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_20__i_2_n_0_6c82cc5);
  wire recovered_155_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_155_o[0] = recovered_155_s[0] ^ (recovered_155_ci || recovered_155_cy);
  assign recovered_155_co[0] = (recovered_155_s[0] & (recovered_155_ci || recovered_155_cy)) | (~recovered_155_s[0] & recovered_155_di[0]);
  assign recovered_155_o[1] = recovered_155_s[1] ^ recovered_155_co[0];
  assign recovered_155_co[1] = (recovered_155_s[1] & recovered_155_co[0]) | (~recovered_155_s[1] & recovered_155_di[1]);
  assign recovered_155_o[2] = recovered_155_s[2] ^ recovered_155_co[1];
  assign recovered_155_co[2] = (recovered_155_s[2] & recovered_155_co[1]) | (~recovered_155_s[2] & recovered_155_di[2]);
  assign recovered_155_o[3] = recovered_155_s[3] ^ recovered_155_co[2];
  assign recovered_155_co[3] = (recovered_155_s[3] & recovered_155_co[2]) | (~recovered_155_s[3] & recovered_155_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_24__i_2_n_0_29c4085 ,esc_NLW_could_multi_bursts_awaddr_buf_reg_24__i_2_CO_UNCONNECTED_05a6bad [2:0]} = recovered_155_co;
  assign data1[24:21] = recovered_155_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_25_208e640
  reg recovered_156_q = 1'b0;
  assign m_axi_output_r_AWADDR[23] = recovered_156_q;
  wire recovered_156_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_156_reset || (((SR) === 1'bx) && (recovered_156_q == 1'b0))) recovered_156_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_156_q == (awaddr_tmp[25])))) recovered_156_q <= (awaddr_tmp[25]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_26_3b16d0f
  reg recovered_157_q = 1'b0;
  assign m_axi_output_r_AWADDR[24] = recovered_157_q;
  wire recovered_157_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_157_reset || (((SR) === 1'bx) && (recovered_157_q == 1'b0))) recovered_157_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_157_q == (awaddr_tmp[26])))) recovered_157_q <= (awaddr_tmp[26]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_27_81d68f8
  reg recovered_158_q = 1'b0;
  assign m_axi_output_r_AWADDR[25] = recovered_158_q;
  wire recovered_158_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_158_reset || (((SR) === 1'bx) && (recovered_158_q == 1'b0))) recovered_158_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_158_q == (awaddr_tmp[27])))) recovered_158_q <= (awaddr_tmp[27]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_28_b546804
  reg recovered_159_q = 1'b0;
  assign m_axi_output_r_AWADDR[26] = recovered_159_q;
  wire recovered_159_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_159_reset || (((SR) === 1'bx) && (recovered_159_q == 1'b0))) recovered_159_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_159_q == (awaddr_tmp[28])))) recovered_159_q <= (awaddr_tmp[28]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_28__i_2_20dd836
  wire [3:0] recovered_160_co, recovered_160_o, recovered_160_s, recovered_160_di;
  assign recovered_160_s = m_axi_output_r_AWADDR[26:23];
  assign recovered_160_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_160_ci = ((esc_could_multi_bursts_awaddr_buf_reg_24__i_2_n_0_29c4085) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_24__i_2_n_0_29c4085);
  wire recovered_160_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_160_o[0] = recovered_160_s[0] ^ (recovered_160_ci || recovered_160_cy);
  assign recovered_160_co[0] = (recovered_160_s[0] & (recovered_160_ci || recovered_160_cy)) | (~recovered_160_s[0] & recovered_160_di[0]);
  assign recovered_160_o[1] = recovered_160_s[1] ^ recovered_160_co[0];
  assign recovered_160_co[1] = (recovered_160_s[1] & recovered_160_co[0]) | (~recovered_160_s[1] & recovered_160_di[1]);
  assign recovered_160_o[2] = recovered_160_s[2] ^ recovered_160_co[1];
  assign recovered_160_co[2] = (recovered_160_s[2] & recovered_160_co[1]) | (~recovered_160_s[2] & recovered_160_di[2]);
  assign recovered_160_o[3] = recovered_160_s[3] ^ recovered_160_co[2];
  assign recovered_160_co[3] = (recovered_160_s[3] & recovered_160_co[2]) | (~recovered_160_s[3] & recovered_160_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_28__i_2_n_0_d122103 ,esc_NLW_could_multi_bursts_awaddr_buf_reg_28__i_2_CO_UNCONNECTED_596e833 [2:0]} = recovered_160_co;
  assign data1[28:25] = recovered_160_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_29_a7854ba
  reg recovered_161_q = 1'b0;
  assign m_axi_output_r_AWADDR[27] = recovered_161_q;
  wire recovered_161_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_161_reset || (((SR) === 1'bx) && (recovered_161_q == 1'b0))) recovered_161_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_161_q == (awaddr_tmp[29])))) recovered_161_q <= (awaddr_tmp[29]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_2_4212328
  reg recovered_162_q = 1'b0;
  assign m_axi_output_r_AWADDR[0] = recovered_162_q;
  wire recovered_162_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_162_reset || (((SR) === 1'bx) && (recovered_162_q == 1'b0))) recovered_162_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_162_q == (awaddr_tmp[2])))) recovered_162_q <= (awaddr_tmp[2]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_30_3e9f805
  reg recovered_163_q = 1'b0;
  assign m_axi_output_r_AWADDR[28] = recovered_163_q;
  wire recovered_163_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_163_reset || (((SR) === 1'bx) && (recovered_163_q == 1'b0))) recovered_163_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_163_q == (awaddr_tmp[30])))) recovered_163_q <= (awaddr_tmp[30]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_31_1b154ea
  reg recovered_164_q = 1'b0;
  assign m_axi_output_r_AWADDR[29] = recovered_164_q;
  wire recovered_164_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_164_reset || (((SR) === 1'bx) && (recovered_164_q == 1'b0))) recovered_164_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_164_q == (awaddr_tmp[31])))) recovered_164_q <= (awaddr_tmp[31]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_32_a58a898
  reg recovered_165_q = 1'b0;
  assign m_axi_output_r_AWADDR[30] = recovered_165_q;
  wire recovered_165_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_165_reset || (((SR) === 1'bx) && (recovered_165_q == 1'b0))) recovered_165_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_165_q == (awaddr_tmp[32])))) recovered_165_q <= (awaddr_tmp[32]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_32__i_2_40a56cd
  wire [3:0] recovered_166_co, recovered_166_o, recovered_166_s, recovered_166_di;
  assign recovered_166_s = m_axi_output_r_AWADDR[30:27];
  assign recovered_166_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_166_ci = ((esc_could_multi_bursts_awaddr_buf_reg_28__i_2_n_0_d122103) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_28__i_2_n_0_d122103);
  wire recovered_166_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_166_o[0] = recovered_166_s[0] ^ (recovered_166_ci || recovered_166_cy);
  assign recovered_166_co[0] = (recovered_166_s[0] & (recovered_166_ci || recovered_166_cy)) | (~recovered_166_s[0] & recovered_166_di[0]);
  assign recovered_166_o[1] = recovered_166_s[1] ^ recovered_166_co[0];
  assign recovered_166_co[1] = (recovered_166_s[1] & recovered_166_co[0]) | (~recovered_166_s[1] & recovered_166_di[1]);
  assign recovered_166_o[2] = recovered_166_s[2] ^ recovered_166_co[1];
  assign recovered_166_co[2] = (recovered_166_s[2] & recovered_166_co[1]) | (~recovered_166_s[2] & recovered_166_di[2]);
  assign recovered_166_o[3] = recovered_166_s[3] ^ recovered_166_co[2];
  assign recovered_166_co[3] = (recovered_166_s[3] & recovered_166_co[2]) | (~recovered_166_s[3] & recovered_166_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_32__i_2_n_0_153a3d7 ,esc_NLW_could_multi_bursts_awaddr_buf_reg_32__i_2_CO_UNCONNECTED_babed89 [2:0]} = recovered_166_co;
  assign data1[32:29] = recovered_166_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_33_e644634
  reg recovered_167_q = 1'b0;
  assign m_axi_output_r_AWADDR[31] = recovered_167_q;
  wire recovered_167_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_167_reset || (((SR) === 1'bx) && (recovered_167_q == 1'b0))) recovered_167_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_167_q == (awaddr_tmp[33])))) recovered_167_q <= (awaddr_tmp[33]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_34_1c0687c
  reg recovered_168_q = 1'b0;
  assign m_axi_output_r_AWADDR[32] = recovered_168_q;
  wire recovered_168_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_168_reset || (((SR) === 1'bx) && (recovered_168_q == 1'b0))) recovered_168_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_168_q == (awaddr_tmp[34])))) recovered_168_q <= (awaddr_tmp[34]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_35_c5df60c
  reg recovered_169_q = 1'b0;
  assign m_axi_output_r_AWADDR[33] = recovered_169_q;
  wire recovered_169_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_169_reset || (((SR) === 1'bx) && (recovered_169_q == 1'b0))) recovered_169_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_169_q == (awaddr_tmp[35])))) recovered_169_q <= (awaddr_tmp[35]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_36_d1fe6e9
  reg recovered_170_q = 1'b0;
  assign m_axi_output_r_AWADDR[34] = recovered_170_q;
  wire recovered_170_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_170_reset || (((SR) === 1'bx) && (recovered_170_q == 1'b0))) recovered_170_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_170_q == (awaddr_tmp[36])))) recovered_170_q <= (awaddr_tmp[36]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_36__i_2_7cdc09e
  wire [3:0] recovered_171_co, recovered_171_o, recovered_171_s, recovered_171_di;
  assign recovered_171_s = m_axi_output_r_AWADDR[34:31];
  assign recovered_171_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_171_ci = ((esc_could_multi_bursts_awaddr_buf_reg_32__i_2_n_0_153a3d7) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_32__i_2_n_0_153a3d7);
  wire recovered_171_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_171_o[0] = recovered_171_s[0] ^ (recovered_171_ci || recovered_171_cy);
  assign recovered_171_co[0] = (recovered_171_s[0] & (recovered_171_ci || recovered_171_cy)) | (~recovered_171_s[0] & recovered_171_di[0]);
  assign recovered_171_o[1] = recovered_171_s[1] ^ recovered_171_co[0];
  assign recovered_171_co[1] = (recovered_171_s[1] & recovered_171_co[0]) | (~recovered_171_s[1] & recovered_171_di[1]);
  assign recovered_171_o[2] = recovered_171_s[2] ^ recovered_171_co[1];
  assign recovered_171_co[2] = (recovered_171_s[2] & recovered_171_co[1]) | (~recovered_171_s[2] & recovered_171_di[2]);
  assign recovered_171_o[3] = recovered_171_s[3] ^ recovered_171_co[2];
  assign recovered_171_co[3] = (recovered_171_s[3] & recovered_171_co[2]) | (~recovered_171_s[3] & recovered_171_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_36__i_2_n_0_76b475d ,esc_NLW_could_multi_bursts_awaddr_buf_reg_36__i_2_CO_UNCONNECTED_49832ff [2:0]} = recovered_171_co;
  assign data1[36:33] = recovered_171_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_37_bf9400f
  reg recovered_172_q = 1'b0;
  assign m_axi_output_r_AWADDR[35] = recovered_172_q;
  wire recovered_172_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_172_reset || (((SR) === 1'bx) && (recovered_172_q == 1'b0))) recovered_172_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_172_q == (awaddr_tmp[37])))) recovered_172_q <= (awaddr_tmp[37]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_38_670c4ac
  reg recovered_173_q = 1'b0;
  assign m_axi_output_r_AWADDR[36] = recovered_173_q;
  wire recovered_173_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_173_reset || (((SR) === 1'bx) && (recovered_173_q == 1'b0))) recovered_173_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_173_q == (awaddr_tmp[38])))) recovered_173_q <= (awaddr_tmp[38]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_39_998af71
  reg recovered_174_q = 1'b0;
  assign m_axi_output_r_AWADDR[37] = recovered_174_q;
  wire recovered_174_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_174_reset || (((SR) === 1'bx) && (recovered_174_q == 1'b0))) recovered_174_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_174_q == (awaddr_tmp[39])))) recovered_174_q <= (awaddr_tmp[39]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_3_0755551
  reg recovered_175_q = 1'b0;
  assign m_axi_output_r_AWADDR[1] = recovered_175_q;
  wire recovered_175_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_175_reset || (((SR) === 1'bx) && (recovered_175_q == 1'b0))) recovered_175_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_175_q == (awaddr_tmp[3])))) recovered_175_q <= (awaddr_tmp[3]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_40_5383be4
  reg recovered_176_q = 1'b0;
  assign m_axi_output_r_AWADDR[38] = recovered_176_q;
  wire recovered_176_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_176_reset || (((SR) === 1'bx) && (recovered_176_q == 1'b0))) recovered_176_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_176_q == (awaddr_tmp[40])))) recovered_176_q <= (awaddr_tmp[40]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_40__i_2_e791101
  wire [3:0] recovered_177_co, recovered_177_o, recovered_177_s, recovered_177_di;
  assign recovered_177_s = m_axi_output_r_AWADDR[38:35];
  assign recovered_177_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_177_ci = ((esc_could_multi_bursts_awaddr_buf_reg_36__i_2_n_0_76b475d) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_36__i_2_n_0_76b475d);
  wire recovered_177_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_177_o[0] = recovered_177_s[0] ^ (recovered_177_ci || recovered_177_cy);
  assign recovered_177_co[0] = (recovered_177_s[0] & (recovered_177_ci || recovered_177_cy)) | (~recovered_177_s[0] & recovered_177_di[0]);
  assign recovered_177_o[1] = recovered_177_s[1] ^ recovered_177_co[0];
  assign recovered_177_co[1] = (recovered_177_s[1] & recovered_177_co[0]) | (~recovered_177_s[1] & recovered_177_di[1]);
  assign recovered_177_o[2] = recovered_177_s[2] ^ recovered_177_co[1];
  assign recovered_177_co[2] = (recovered_177_s[2] & recovered_177_co[1]) | (~recovered_177_s[2] & recovered_177_di[2]);
  assign recovered_177_o[3] = recovered_177_s[3] ^ recovered_177_co[2];
  assign recovered_177_co[3] = (recovered_177_s[3] & recovered_177_co[2]) | (~recovered_177_s[3] & recovered_177_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_40__i_2_n_0_6bf6a9d ,esc_NLW_could_multi_bursts_awaddr_buf_reg_40__i_2_CO_UNCONNECTED_8ca4683 [2:0]} = recovered_177_co;
  assign data1[40:37] = recovered_177_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_41_8d4d664
  reg recovered_178_q = 1'b0;
  assign m_axi_output_r_AWADDR[39] = recovered_178_q;
  wire recovered_178_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_178_reset || (((SR) === 1'bx) && (recovered_178_q == 1'b0))) recovered_178_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_178_q == (awaddr_tmp[41])))) recovered_178_q <= (awaddr_tmp[41]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_42_2e11b51
  reg recovered_179_q = 1'b0;
  assign m_axi_output_r_AWADDR[40] = recovered_179_q;
  wire recovered_179_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_179_reset || (((SR) === 1'bx) && (recovered_179_q == 1'b0))) recovered_179_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_179_q == (awaddr_tmp[42])))) recovered_179_q <= (awaddr_tmp[42]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_43_ad23235
  reg recovered_180_q = 1'b0;
  assign m_axi_output_r_AWADDR[41] = recovered_180_q;
  wire recovered_180_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_180_reset || (((SR) === 1'bx) && (recovered_180_q == 1'b0))) recovered_180_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_180_q == (awaddr_tmp[43])))) recovered_180_q <= (awaddr_tmp[43]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_44_d01353f
  reg recovered_181_q = 1'b0;
  assign m_axi_output_r_AWADDR[42] = recovered_181_q;
  wire recovered_181_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_181_reset || (((SR) === 1'bx) && (recovered_181_q == 1'b0))) recovered_181_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_181_q == (awaddr_tmp[44])))) recovered_181_q <= (awaddr_tmp[44]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_44__i_2_549fdbe
  wire [3:0] recovered_182_co, recovered_182_o, recovered_182_s, recovered_182_di;
  assign recovered_182_s = m_axi_output_r_AWADDR[42:39];
  assign recovered_182_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_182_ci = ((esc_could_multi_bursts_awaddr_buf_reg_40__i_2_n_0_6bf6a9d) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_40__i_2_n_0_6bf6a9d);
  wire recovered_182_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_182_o[0] = recovered_182_s[0] ^ (recovered_182_ci || recovered_182_cy);
  assign recovered_182_co[0] = (recovered_182_s[0] & (recovered_182_ci || recovered_182_cy)) | (~recovered_182_s[0] & recovered_182_di[0]);
  assign recovered_182_o[1] = recovered_182_s[1] ^ recovered_182_co[0];
  assign recovered_182_co[1] = (recovered_182_s[1] & recovered_182_co[0]) | (~recovered_182_s[1] & recovered_182_di[1]);
  assign recovered_182_o[2] = recovered_182_s[2] ^ recovered_182_co[1];
  assign recovered_182_co[2] = (recovered_182_s[2] & recovered_182_co[1]) | (~recovered_182_s[2] & recovered_182_di[2]);
  assign recovered_182_o[3] = recovered_182_s[3] ^ recovered_182_co[2];
  assign recovered_182_co[3] = (recovered_182_s[3] & recovered_182_co[2]) | (~recovered_182_s[3] & recovered_182_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_44__i_2_n_0_2975f13 ,esc_NLW_could_multi_bursts_awaddr_buf_reg_44__i_2_CO_UNCONNECTED_13380d9 [2:0]} = recovered_182_co;
  assign data1[44:41] = recovered_182_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_45_36ff6d0
  reg recovered_183_q = 1'b0;
  assign m_axi_output_r_AWADDR[43] = recovered_183_q;
  wire recovered_183_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_183_reset || (((SR) === 1'bx) && (recovered_183_q == 1'b0))) recovered_183_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_183_q == (awaddr_tmp[45])))) recovered_183_q <= (awaddr_tmp[45]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_46_166fcbc
  reg recovered_184_q = 1'b0;
  assign m_axi_output_r_AWADDR[44] = recovered_184_q;
  wire recovered_184_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_184_reset || (((SR) === 1'bx) && (recovered_184_q == 1'b0))) recovered_184_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_184_q == (awaddr_tmp[46])))) recovered_184_q <= (awaddr_tmp[46]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_47_16226a7
  reg recovered_185_q = 1'b0;
  assign m_axi_output_r_AWADDR[45] = recovered_185_q;
  wire recovered_185_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_185_reset || (((SR) === 1'bx) && (recovered_185_q == 1'b0))) recovered_185_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_185_q == (awaddr_tmp[47])))) recovered_185_q <= (awaddr_tmp[47]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_48_9cca4d1
  reg recovered_186_q = 1'b0;
  assign m_axi_output_r_AWADDR[46] = recovered_186_q;
  wire recovered_186_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_186_reset || (((SR) === 1'bx) && (recovered_186_q == 1'b0))) recovered_186_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_186_q == (awaddr_tmp[48])))) recovered_186_q <= (awaddr_tmp[48]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_48__i_2_9a5b086
  wire [3:0] recovered_187_co, recovered_187_o, recovered_187_s, recovered_187_di;
  assign recovered_187_s = m_axi_output_r_AWADDR[46:43];
  assign recovered_187_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_187_ci = ((esc_could_multi_bursts_awaddr_buf_reg_44__i_2_n_0_2975f13) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_44__i_2_n_0_2975f13);
  wire recovered_187_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_187_o[0] = recovered_187_s[0] ^ (recovered_187_ci || recovered_187_cy);
  assign recovered_187_co[0] = (recovered_187_s[0] & (recovered_187_ci || recovered_187_cy)) | (~recovered_187_s[0] & recovered_187_di[0]);
  assign recovered_187_o[1] = recovered_187_s[1] ^ recovered_187_co[0];
  assign recovered_187_co[1] = (recovered_187_s[1] & recovered_187_co[0]) | (~recovered_187_s[1] & recovered_187_di[1]);
  assign recovered_187_o[2] = recovered_187_s[2] ^ recovered_187_co[1];
  assign recovered_187_co[2] = (recovered_187_s[2] & recovered_187_co[1]) | (~recovered_187_s[2] & recovered_187_di[2]);
  assign recovered_187_o[3] = recovered_187_s[3] ^ recovered_187_co[2];
  assign recovered_187_co[3] = (recovered_187_s[3] & recovered_187_co[2]) | (~recovered_187_s[3] & recovered_187_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_48__i_2_n_0_ed7cb93 ,esc_NLW_could_multi_bursts_awaddr_buf_reg_48__i_2_CO_UNCONNECTED_716918e [2:0]} = recovered_187_co;
  assign data1[48:45] = recovered_187_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_49_dc76912
  reg recovered_188_q = 1'b0;
  assign m_axi_output_r_AWADDR[47] = recovered_188_q;
  wire recovered_188_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_188_reset || (((SR) === 1'bx) && (recovered_188_q == 1'b0))) recovered_188_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_188_q == (awaddr_tmp[49])))) recovered_188_q <= (awaddr_tmp[49]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_4_91e40ae
  reg recovered_189_q = 1'b0;
  assign m_axi_output_r_AWADDR[2] = recovered_189_q;
  wire recovered_189_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_189_reset || (((SR) === 1'bx) && (recovered_189_q == 1'b0))) recovered_189_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_189_q == (awaddr_tmp[4])))) recovered_189_q <= (awaddr_tmp[4]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_4__i_2_a982b71
  wire [3:0] recovered_190_co, recovered_190_o, recovered_190_s, recovered_190_di;
  assign recovered_190_s = {esc_could_multi_bursts_awaddr_buf_4__i_3_n_0_a1e332e ,esc_could_multi_bursts_awaddr_buf_4__i_4_n_0_cf5f918 ,esc_could_multi_bursts_awaddr_buf_4__i_5_n_0_638540b ,esc_const0_a0cf646 };
  assign recovered_190_di = {m_axi_output_r_AWADDR[2:0],esc_const0_a0cf646 };
  wire recovered_190_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_190_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_190_o[0] = recovered_190_s[0] ^ (recovered_190_ci || recovered_190_cy);
  assign recovered_190_co[0] = (recovered_190_s[0] & (recovered_190_ci || recovered_190_cy)) | (~recovered_190_s[0] & recovered_190_di[0]);
  assign recovered_190_o[1] = recovered_190_s[1] ^ recovered_190_co[0];
  assign recovered_190_co[1] = (recovered_190_s[1] & recovered_190_co[0]) | (~recovered_190_s[1] & recovered_190_di[1]);
  assign recovered_190_o[2] = recovered_190_s[2] ^ recovered_190_co[1];
  assign recovered_190_co[2] = (recovered_190_s[2] & recovered_190_co[1]) | (~recovered_190_s[2] & recovered_190_di[2]);
  assign recovered_190_o[3] = recovered_190_s[3] ^ recovered_190_co[2];
  assign recovered_190_co[3] = (recovered_190_s[3] & recovered_190_co[2]) | (~recovered_190_s[3] & recovered_190_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_4__i_2_n_0_72e231b ,esc_NLW_could_multi_bursts_awaddr_buf_reg_4__i_2_CO_UNCONNECTED_66bd01c [2:0]} = recovered_190_co;
  assign {data1[4:2],esc_NLW_could_multi_bursts_awaddr_buf_reg_4__i_2_O_UNCONNECTED_219d49a [0]} = recovered_190_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_50_4c62351
  reg recovered_191_q = 1'b0;
  assign m_axi_output_r_AWADDR[48] = recovered_191_q;
  wire recovered_191_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_191_reset || (((SR) === 1'bx) && (recovered_191_q == 1'b0))) recovered_191_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_191_q == (awaddr_tmp[50])))) recovered_191_q <= (awaddr_tmp[50]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_51_77f291f
  reg recovered_192_q = 1'b0;
  assign m_axi_output_r_AWADDR[49] = recovered_192_q;
  wire recovered_192_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_192_reset || (((SR) === 1'bx) && (recovered_192_q == 1'b0))) recovered_192_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_192_q == (awaddr_tmp[51])))) recovered_192_q <= (awaddr_tmp[51]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_52_0721420
  reg recovered_193_q = 1'b0;
  assign m_axi_output_r_AWADDR[50] = recovered_193_q;
  wire recovered_193_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_193_reset || (((SR) === 1'bx) && (recovered_193_q == 1'b0))) recovered_193_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_193_q == (awaddr_tmp[52])))) recovered_193_q <= (awaddr_tmp[52]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_52__i_2_4c31c71
  wire [3:0] recovered_194_co, recovered_194_o, recovered_194_s, recovered_194_di;
  assign recovered_194_s = m_axi_output_r_AWADDR[50:47];
  assign recovered_194_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_194_ci = ((esc_could_multi_bursts_awaddr_buf_reg_48__i_2_n_0_ed7cb93) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_48__i_2_n_0_ed7cb93);
  wire recovered_194_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_194_o[0] = recovered_194_s[0] ^ (recovered_194_ci || recovered_194_cy);
  assign recovered_194_co[0] = (recovered_194_s[0] & (recovered_194_ci || recovered_194_cy)) | (~recovered_194_s[0] & recovered_194_di[0]);
  assign recovered_194_o[1] = recovered_194_s[1] ^ recovered_194_co[0];
  assign recovered_194_co[1] = (recovered_194_s[1] & recovered_194_co[0]) | (~recovered_194_s[1] & recovered_194_di[1]);
  assign recovered_194_o[2] = recovered_194_s[2] ^ recovered_194_co[1];
  assign recovered_194_co[2] = (recovered_194_s[2] & recovered_194_co[1]) | (~recovered_194_s[2] & recovered_194_di[2]);
  assign recovered_194_o[3] = recovered_194_s[3] ^ recovered_194_co[2];
  assign recovered_194_co[3] = (recovered_194_s[3] & recovered_194_co[2]) | (~recovered_194_s[3] & recovered_194_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_52__i_2_n_0_0e57cff ,esc_NLW_could_multi_bursts_awaddr_buf_reg_52__i_2_CO_UNCONNECTED_cc7715f [2:0]} = recovered_194_co;
  assign data1[52:49] = recovered_194_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_53_9b2db69
  reg recovered_195_q = 1'b0;
  assign m_axi_output_r_AWADDR[51] = recovered_195_q;
  wire recovered_195_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_195_reset || (((SR) === 1'bx) && (recovered_195_q == 1'b0))) recovered_195_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_195_q == (awaddr_tmp[53])))) recovered_195_q <= (awaddr_tmp[53]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_54_f4cfc96
  reg recovered_196_q = 1'b0;
  assign m_axi_output_r_AWADDR[52] = recovered_196_q;
  wire recovered_196_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_196_reset || (((SR) === 1'bx) && (recovered_196_q == 1'b0))) recovered_196_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_196_q == (awaddr_tmp[54])))) recovered_196_q <= (awaddr_tmp[54]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_55_221a169
  reg recovered_197_q = 1'b0;
  assign m_axi_output_r_AWADDR[53] = recovered_197_q;
  wire recovered_197_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_197_reset || (((SR) === 1'bx) && (recovered_197_q == 1'b0))) recovered_197_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_197_q == (awaddr_tmp[55])))) recovered_197_q <= (awaddr_tmp[55]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_56_55fd207
  reg recovered_198_q = 1'b0;
  assign m_axi_output_r_AWADDR[54] = recovered_198_q;
  wire recovered_198_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_198_reset || (((SR) === 1'bx) && (recovered_198_q == 1'b0))) recovered_198_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_198_q == (awaddr_tmp[56])))) recovered_198_q <= (awaddr_tmp[56]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_56__i_2_20aed27
  wire [3:0] recovered_199_co, recovered_199_o, recovered_199_s, recovered_199_di;
  assign recovered_199_s = m_axi_output_r_AWADDR[54:51];
  assign recovered_199_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_199_ci = ((esc_could_multi_bursts_awaddr_buf_reg_52__i_2_n_0_0e57cff) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_52__i_2_n_0_0e57cff);
  wire recovered_199_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_199_o[0] = recovered_199_s[0] ^ (recovered_199_ci || recovered_199_cy);
  assign recovered_199_co[0] = (recovered_199_s[0] & (recovered_199_ci || recovered_199_cy)) | (~recovered_199_s[0] & recovered_199_di[0]);
  assign recovered_199_o[1] = recovered_199_s[1] ^ recovered_199_co[0];
  assign recovered_199_co[1] = (recovered_199_s[1] & recovered_199_co[0]) | (~recovered_199_s[1] & recovered_199_di[1]);
  assign recovered_199_o[2] = recovered_199_s[2] ^ recovered_199_co[1];
  assign recovered_199_co[2] = (recovered_199_s[2] & recovered_199_co[1]) | (~recovered_199_s[2] & recovered_199_di[2]);
  assign recovered_199_o[3] = recovered_199_s[3] ^ recovered_199_co[2];
  assign recovered_199_co[3] = (recovered_199_s[3] & recovered_199_co[2]) | (~recovered_199_s[3] & recovered_199_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_56__i_2_n_0_41e1c5e ,esc_NLW_could_multi_bursts_awaddr_buf_reg_56__i_2_CO_UNCONNECTED_1287321 [2:0]} = recovered_199_co;
  assign data1[56:53] = recovered_199_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_57_91dbb95
  reg recovered_200_q = 1'b0;
  assign m_axi_output_r_AWADDR[55] = recovered_200_q;
  wire recovered_200_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_200_reset || (((SR) === 1'bx) && (recovered_200_q == 1'b0))) recovered_200_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_200_q == (awaddr_tmp[57])))) recovered_200_q <= (awaddr_tmp[57]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_58_db0b505
  reg recovered_201_q = 1'b0;
  assign m_axi_output_r_AWADDR[56] = recovered_201_q;
  wire recovered_201_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_201_reset || (((SR) === 1'bx) && (recovered_201_q == 1'b0))) recovered_201_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_201_q == (awaddr_tmp[58])))) recovered_201_q <= (awaddr_tmp[58]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_59_9e0a457
  reg recovered_202_q = 1'b0;
  assign m_axi_output_r_AWADDR[57] = recovered_202_q;
  wire recovered_202_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_202_reset || (((SR) === 1'bx) && (recovered_202_q == 1'b0))) recovered_202_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_202_q == (awaddr_tmp[59])))) recovered_202_q <= (awaddr_tmp[59]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_5_afc86ad
  reg recovered_203_q = 1'b0;
  assign m_axi_output_r_AWADDR[3] = recovered_203_q;
  wire recovered_203_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_203_reset || (((SR) === 1'bx) && (recovered_203_q == 1'b0))) recovered_203_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_203_q == (awaddr_tmp[5])))) recovered_203_q <= (awaddr_tmp[5]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_60_58cacd1
  reg recovered_204_q = 1'b0;
  assign m_axi_output_r_AWADDR[58] = recovered_204_q;
  wire recovered_204_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_204_reset || (((SR) === 1'bx) && (recovered_204_q == 1'b0))) recovered_204_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_204_q == (awaddr_tmp[60])))) recovered_204_q <= (awaddr_tmp[60]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_60__i_2_49d893a
  wire [3:0] recovered_205_co, recovered_205_o, recovered_205_s, recovered_205_di;
  assign recovered_205_s = m_axi_output_r_AWADDR[58:55];
  assign recovered_205_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_205_ci = ((esc_could_multi_bursts_awaddr_buf_reg_56__i_2_n_0_41e1c5e) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_56__i_2_n_0_41e1c5e);
  wire recovered_205_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_205_o[0] = recovered_205_s[0] ^ (recovered_205_ci || recovered_205_cy);
  assign recovered_205_co[0] = (recovered_205_s[0] & (recovered_205_ci || recovered_205_cy)) | (~recovered_205_s[0] & recovered_205_di[0]);
  assign recovered_205_o[1] = recovered_205_s[1] ^ recovered_205_co[0];
  assign recovered_205_co[1] = (recovered_205_s[1] & recovered_205_co[0]) | (~recovered_205_s[1] & recovered_205_di[1]);
  assign recovered_205_o[2] = recovered_205_s[2] ^ recovered_205_co[1];
  assign recovered_205_co[2] = (recovered_205_s[2] & recovered_205_co[1]) | (~recovered_205_s[2] & recovered_205_di[2]);
  assign recovered_205_o[3] = recovered_205_s[3] ^ recovered_205_co[2];
  assign recovered_205_co[3] = (recovered_205_s[3] & recovered_205_co[2]) | (~recovered_205_s[3] & recovered_205_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_60__i_2_n_0_49c4f87 ,esc_NLW_could_multi_bursts_awaddr_buf_reg_60__i_2_CO_UNCONNECTED_39c6f65 [2:0]} = recovered_205_co;
  assign data1[60:57] = recovered_205_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_61_fbdd374
  reg recovered_206_q = 1'b0;
  assign m_axi_output_r_AWADDR[59] = recovered_206_q;
  wire recovered_206_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_206_reset || (((SR) === 1'bx) && (recovered_206_q == 1'b0))) recovered_206_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_206_q == (awaddr_tmp[61])))) recovered_206_q <= (awaddr_tmp[61]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_62_14aacb3
  reg recovered_207_q = 1'b0;
  assign m_axi_output_r_AWADDR[60] = recovered_207_q;
  wire recovered_207_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_207_reset || (((SR) === 1'bx) && (recovered_207_q == 1'b0))) recovered_207_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_207_q == (awaddr_tmp[62])))) recovered_207_q <= (awaddr_tmp[62]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_63_277687c
  reg recovered_208_q = 1'b0;
  assign m_axi_output_r_AWADDR[61] = recovered_208_q;
  wire recovered_208_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_208_reset || (((SR) === 1'bx) && (recovered_208_q == 1'b0))) recovered_208_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_208_q == (awaddr_tmp[63])))) recovered_208_q <= (awaddr_tmp[63]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_63__i_5_a43742e
  wire [3:0] recovered_209_co, recovered_209_o, recovered_209_s, recovered_209_di;
  assign recovered_209_s = {esc_const0_a0cf646 ,m_axi_output_r_AWADDR[61:59]};
  assign recovered_209_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_209_ci = ((esc_could_multi_bursts_awaddr_buf_reg_60__i_2_n_0_49c4f87) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_60__i_2_n_0_49c4f87);
  wire recovered_209_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_209_o[0] = recovered_209_s[0] ^ (recovered_209_ci || recovered_209_cy);
  assign recovered_209_co[0] = (recovered_209_s[0] & (recovered_209_ci || recovered_209_cy)) | (~recovered_209_s[0] & recovered_209_di[0]);
  assign recovered_209_o[1] = recovered_209_s[1] ^ recovered_209_co[0];
  assign recovered_209_co[1] = (recovered_209_s[1] & recovered_209_co[0]) | (~recovered_209_s[1] & recovered_209_di[1]);
  assign recovered_209_o[2] = recovered_209_s[2] ^ recovered_209_co[1];
  assign recovered_209_co[2] = (recovered_209_s[2] & recovered_209_co[1]) | (~recovered_209_s[2] & recovered_209_di[2]);
  assign recovered_209_o[3] = recovered_209_s[3] ^ recovered_209_co[2];
  assign recovered_209_co[3] = (recovered_209_s[3] & recovered_209_co[2]) | (~recovered_209_s[3] & recovered_209_di[3]);
  assign data1[63:61] = recovered_209_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_6_524bc3f
  reg recovered_210_q = 1'b0;
  assign m_axi_output_r_AWADDR[4] = recovered_210_q;
  wire recovered_210_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_210_reset || (((SR) === 1'bx) && (recovered_210_q == 1'b0))) recovered_210_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_210_q == (awaddr_tmp[6])))) recovered_210_q <= (awaddr_tmp[6]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_7_e9ec7a7
  reg recovered_211_q = 1'b0;
  assign m_axi_output_r_AWADDR[5] = recovered_211_q;
  wire recovered_211_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_211_reset || (((SR) === 1'bx) && (recovered_211_q == 1'b0))) recovered_211_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_211_q == (awaddr_tmp[7])))) recovered_211_q <= (awaddr_tmp[7]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_8_de82117
  reg recovered_212_q = 1'b0;
  assign m_axi_output_r_AWADDR[6] = recovered_212_q;
  wire recovered_212_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_212_reset || (((SR) === 1'bx) && (recovered_212_q == 1'b0))) recovered_212_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_212_q == (awaddr_tmp[8])))) recovered_212_q <= (awaddr_tmp[8]);
  end

  // Reconstructed CARRY4: esc_could_multi_bursts_awaddr_buf_reg_8__i_2_f636836
  wire [3:0] recovered_213_co, recovered_213_o, recovered_213_s, recovered_213_di;
  assign recovered_213_s = {m_axi_output_r_AWADDR[6:5],esc_could_multi_bursts_awaddr_buf_8__i_3_n_0_12d65fb ,esc_could_multi_bursts_awaddr_buf_8__i_4_n_0_266e921 };
  assign recovered_213_di = m_axi_output_r_AWADDR[6:3];
  wire recovered_213_ci = ((esc_could_multi_bursts_awaddr_buf_reg_4__i_2_n_0_72e231b) !== 1'bz) && (esc_could_multi_bursts_awaddr_buf_reg_4__i_2_n_0_72e231b);
  wire recovered_213_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_213_o[0] = recovered_213_s[0] ^ (recovered_213_ci || recovered_213_cy);
  assign recovered_213_co[0] = (recovered_213_s[0] & (recovered_213_ci || recovered_213_cy)) | (~recovered_213_s[0] & recovered_213_di[0]);
  assign recovered_213_o[1] = recovered_213_s[1] ^ recovered_213_co[0];
  assign recovered_213_co[1] = (recovered_213_s[1] & recovered_213_co[0]) | (~recovered_213_s[1] & recovered_213_di[1]);
  assign recovered_213_o[2] = recovered_213_s[2] ^ recovered_213_co[1];
  assign recovered_213_co[2] = (recovered_213_s[2] & recovered_213_co[1]) | (~recovered_213_s[2] & recovered_213_di[2]);
  assign recovered_213_o[3] = recovered_213_s[3] ^ recovered_213_co[2];
  assign recovered_213_co[3] = (recovered_213_s[3] & recovered_213_co[2]) | (~recovered_213_s[3] & recovered_213_di[3]);
  assign {esc_could_multi_bursts_awaddr_buf_reg_8__i_2_n_0_7bbebf8 ,esc_NLW_could_multi_bursts_awaddr_buf_reg_8__i_2_CO_UNCONNECTED_6074f2b [2:0]} = recovered_213_co;
  assign data1[8:5] = recovered_213_o;

  // Reconstructed FDRE: esc_could_multi_bursts_awaddr_buf_reg_9_0a83a80
  reg recovered_214_q = 1'b0;
  assign m_axi_output_r_AWADDR[7] = recovered_214_q;
  wire recovered_214_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_214_reset || (((SR) === 1'bx) && (recovered_214_q == 1'b0))) recovered_214_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_214_q == (awaddr_tmp[9])))) recovered_214_q <= (awaddr_tmp[9]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awlen_buf_reg_0_1416f06
  reg recovered_215_q = 1'b0;
  assign esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [0] = recovered_215_q;
  wire recovered_215_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_215_reset || (((SR) === 1'bx) && (recovered_215_q == 1'b0))) recovered_215_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_215_q == (awlen_tmp[0])))) recovered_215_q <= (awlen_tmp[0]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awlen_buf_reg_1_0e75041
  reg recovered_216_q = 1'b0;
  assign esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [1] = recovered_216_q;
  wire recovered_216_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_216_reset || (((SR) === 1'bx) && (recovered_216_q == 1'b0))) recovered_216_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_216_q == (awlen_tmp[1])))) recovered_216_q <= (awlen_tmp[1]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awlen_buf_reg_2_2fd3174
  reg recovered_217_q = 1'b0;
  assign esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [2] = recovered_217_q;
  wire recovered_217_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_217_reset || (((SR) === 1'bx) && (recovered_217_q == 1'b0))) recovered_217_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_217_q == (awlen_tmp[2])))) recovered_217_q <= (awlen_tmp[2]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_awlen_buf_reg_3_d6e2e7c
  reg recovered_218_q = 1'b0;
  assign esc_could_multi_bursts_awlen_buf_reg_3__0_887186f [3] = recovered_218_q;
  wire recovered_218_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_218_reset || (((SR) === 1'bx) && (recovered_218_q == 1'b0))) recovered_218_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_218_q == (awlen_tmp[3])))) recovered_218_q <= (awlen_tmp[3]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_last_sect_buf_reg_5fd9311
  reg recovered_219_q = 1'b0;
  assign esc_could_multi_bursts_last_sect_buf_reg_n_0_659f5fa = recovered_219_q;
  wire recovered_219_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_219_reset || (((SR) === 1'bx) && (recovered_219_q == 1'b0))) recovered_219_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_219_q == (esc_bus_equal_gen_fifo_burst_n_66_97f8224)))) recovered_219_q <= (esc_bus_equal_gen_fifo_burst_n_66_97f8224);
  end

  // Reconstructed LUT1: esc_could_multi_bursts_loop_cnt_0__i_1__0_cbc669d
  assign p_0_in[0] = ~(esc_could_multi_bursts_loop_cnt_reg_275e801 [0]);

  // Reconstructed LUT2: esc_could_multi_bursts_loop_cnt_1__i_1__0_8c17ee3
  assign p_0_in[1] = ((esc_could_multi_bursts_loop_cnt_reg_275e801 [1]) ? (~(esc_could_multi_bursts_loop_cnt_reg_275e801 [0])) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [0]));

  // Reconstructed LUT3: esc_could_multi_bursts_loop_cnt_2__i_1__0_909a4ad
  assign p_0_in[2] = ((esc_could_multi_bursts_loop_cnt_reg_275e801 [0]) ? (((esc_could_multi_bursts_loop_cnt_reg_275e801 [1]) ? (~(esc_could_multi_bursts_loop_cnt_reg_275e801 [2])) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [2]))) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [2]));

  // Reconstructed LUT4: esc_could_multi_bursts_loop_cnt_3__i_1__0_32c0ced
  assign p_0_in[3] = ((esc_could_multi_bursts_loop_cnt_reg_275e801 [2]) ? (((esc_could_multi_bursts_loop_cnt_reg_275e801 [1]) ? (((esc_could_multi_bursts_loop_cnt_reg_275e801 [0]) ? (~(esc_could_multi_bursts_loop_cnt_reg_275e801 [3])) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [3]))) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [3]))) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [3]));

  // Reconstructed LUT5: esc_could_multi_bursts_loop_cnt_4__i_1__0_6249707
  assign p_0_in[4] = ((esc_could_multi_bursts_loop_cnt_reg_275e801 [3]) ? (((esc_could_multi_bursts_loop_cnt_reg_275e801 [0]) ? (((esc_could_multi_bursts_loop_cnt_reg_275e801 [1]) ? (((esc_could_multi_bursts_loop_cnt_reg_275e801 [2]) ? (~(esc_could_multi_bursts_loop_cnt_reg_275e801 [4])) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [4]))) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [4]))) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [4]))) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [4]));

  // Reconstructed LUT6: esc_could_multi_bursts_loop_cnt_5__i_2__0_aa4382d
  assign p_0_in[5] = ((esc_could_multi_bursts_loop_cnt_reg_275e801 [4]) ? (((esc_could_multi_bursts_loop_cnt_reg_275e801 [2]) ? (((esc_could_multi_bursts_loop_cnt_reg_275e801 [1]) ? (((esc_could_multi_bursts_loop_cnt_reg_275e801 [0]) ? (((esc_could_multi_bursts_loop_cnt_reg_275e801 [3]) ? (~(esc_could_multi_bursts_loop_cnt_reg_275e801 [5])) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [5]))) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [5]))) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [5]))) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [5]))) : (esc_could_multi_bursts_loop_cnt_reg_275e801 [5]));

  // Reconstructed FDRE: esc_could_multi_bursts_loop_cnt_reg_0_46d9d4d
  reg recovered_226_q = 1'b0;
  assign esc_could_multi_bursts_loop_cnt_reg_275e801 [0] = recovered_226_q;
  wire recovered_226_reset = ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d)) && ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_226_reset || (((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) === 1'bx) && (recovered_226_q == 1'b0))) recovered_226_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_226_q == (p_0_in[0])))) recovered_226_q <= (p_0_in[0]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_loop_cnt_reg_1_5206dd5
  reg recovered_227_q = 1'b0;
  assign esc_could_multi_bursts_loop_cnt_reg_275e801 [1] = recovered_227_q;
  wire recovered_227_reset = ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d)) && ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_227_reset || (((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) === 1'bx) && (recovered_227_q == 1'b0))) recovered_227_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_227_q == (p_0_in[1])))) recovered_227_q <= (p_0_in[1]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_loop_cnt_reg_2_93127d6
  reg recovered_228_q = 1'b0;
  assign esc_could_multi_bursts_loop_cnt_reg_275e801 [2] = recovered_228_q;
  wire recovered_228_reset = ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d)) && ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_228_reset || (((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) === 1'bx) && (recovered_228_q == 1'b0))) recovered_228_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_228_q == (p_0_in[2])))) recovered_228_q <= (p_0_in[2]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_loop_cnt_reg_3_d799ceb
  reg recovered_229_q = 1'b0;
  assign esc_could_multi_bursts_loop_cnt_reg_275e801 [3] = recovered_229_q;
  wire recovered_229_reset = ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d)) && ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_229_reset || (((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) === 1'bx) && (recovered_229_q == 1'b0))) recovered_229_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_229_q == (p_0_in[3])))) recovered_229_q <= (p_0_in[3]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_loop_cnt_reg_4_d1659db
  reg recovered_230_q = 1'b0;
  assign esc_could_multi_bursts_loop_cnt_reg_275e801 [4] = recovered_230_q;
  wire recovered_230_reset = ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d)) && ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_230_reset || (((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) === 1'bx) && (recovered_230_q == 1'b0))) recovered_230_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_230_q == (p_0_in[4])))) recovered_230_q <= (p_0_in[4]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc
  reg recovered_231_q = 1'b0;
  assign esc_could_multi_bursts_loop_cnt_reg_275e801 [5] = recovered_231_q;
  wire recovered_231_reset = ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d)) && ((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_231_reset || (((esc_bus_equal_gen_fifo_burst_n_2_6ea3f3d) === 1'bx) && (recovered_231_q == 1'b0))) recovered_231_q <= 1'b0;
    else if ((esc_could_multi_bursts_next_loop_c288065) || ((esc_could_multi_bursts_next_loop_c288065) === 1'bz) || (((esc_could_multi_bursts_next_loop_c288065) === 1'bx) && (recovered_231_q == (p_0_in[5])))) recovered_231_q <= (p_0_in[5]);
  end

  // Reconstructed FDRE: esc_could_multi_bursts_sect_handling_reg_a60c95a
  reg recovered_232_q = 1'b0;
  assign esc_could_multi_bursts_sect_handling_reg_n_0_737ec10 = recovered_232_q;
  wire recovered_232_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_232_reset || (((SR) === 1'bx) && (recovered_232_q == 1'b0))) recovered_232_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_232_q == (fifo_resp_n_6)))) recovered_232_q <= (fifo_resp_n_6);
  end

  // Reconstructed LUT2: esc_end_addr_buf_13__i_2_2fa4d2b
  assign esc_end_addr_buf_13__i_2_n_0_aa6d7cc = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__13_f3dfe34)) : (esc_start_addr_reg_n_0__13_f3dfe34));

  // Reconstructed LUT2: esc_end_addr_buf_13__i_3_33c081a
  assign esc_end_addr_buf_13__i_3_n_0_79d8b5e = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__12_0ffbef5)) : (esc_start_addr_reg_n_0__12_0ffbef5));

  // Reconstructed LUT2: esc_end_addr_buf_13__i_4_d3d5b4c
  assign esc_end_addr_buf_13__i_4_n_0_5117aa6 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__11_93897a8)) : (esc_start_addr_reg_n_0__11_93897a8));

  // Reconstructed LUT2: esc_end_addr_buf_13__i_5_5881fc4
  assign esc_end_addr_buf_13__i_5_n_0_83a716d = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__10_7dfdb33)) : (esc_start_addr_reg_n_0__10_7dfdb33));

  // Reconstructed LUT2: esc_end_addr_buf_17__i_2_f1be2e3
  assign esc_end_addr_buf_17__i_2_n_0_35ae088 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__17_a7c7f14)) : (esc_start_addr_reg_n_0__17_a7c7f14));

  // Reconstructed LUT2: esc_end_addr_buf_17__i_3_9c081b9
  assign esc_end_addr_buf_17__i_3_n_0_8f8554a = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__16_c2276cc)) : (esc_start_addr_reg_n_0__16_c2276cc));

  // Reconstructed LUT2: esc_end_addr_buf_17__i_4_65c3ee8
  assign esc_end_addr_buf_17__i_4_n_0_f4e92de = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__15_3a25f9c)) : (esc_start_addr_reg_n_0__15_3a25f9c));

  // Reconstructed LUT2: esc_end_addr_buf_17__i_5_c6221f1
  assign esc_end_addr_buf_17__i_5_n_0_3646b5a = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__14_726da08)) : (esc_start_addr_reg_n_0__14_726da08));

  // Reconstructed LUT2: esc_end_addr_buf_21__i_2_99c8413
  assign esc_end_addr_buf_21__i_2_n_0_8c345c2 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__21_9efa866)) : (esc_start_addr_reg_n_0__21_9efa866));

  // Reconstructed LUT2: esc_end_addr_buf_21__i_3_2ddc66c
  assign esc_end_addr_buf_21__i_3_n_0_14647fd = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__20_a055fe3)) : (esc_start_addr_reg_n_0__20_a055fe3));

  // Reconstructed LUT2: esc_end_addr_buf_21__i_4_b227c78
  assign esc_end_addr_buf_21__i_4_n_0_fc38406 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__19_3510eae)) : (esc_start_addr_reg_n_0__19_3510eae));

  // Reconstructed LUT2: esc_end_addr_buf_21__i_5_a43b841
  assign esc_end_addr_buf_21__i_5_n_0_5cf9081 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__18_7d4f45f)) : (esc_start_addr_reg_n_0__18_7d4f45f));

  // Reconstructed LUT2: esc_end_addr_buf_25__i_2_089206b
  assign esc_end_addr_buf_25__i_2_n_0_b8fef88 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__25_b477c1e)) : (esc_start_addr_reg_n_0__25_b477c1e));

  // Reconstructed LUT2: esc_end_addr_buf_25__i_3_d0c31d0
  assign esc_end_addr_buf_25__i_3_n_0_c486315 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__24_1d34d3b)) : (esc_start_addr_reg_n_0__24_1d34d3b));

  // Reconstructed LUT2: esc_end_addr_buf_25__i_4_6ef08c9
  assign esc_end_addr_buf_25__i_4_n_0_3133667 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__23_907ba78)) : (esc_start_addr_reg_n_0__23_907ba78));

  // Reconstructed LUT2: esc_end_addr_buf_25__i_5_3b1414f
  assign esc_end_addr_buf_25__i_5_n_0_76e97aa = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__22_ba17a60)) : (esc_start_addr_reg_n_0__22_ba17a60));

  // Reconstructed LUT2: esc_end_addr_buf_29__i_2_b545c15
  assign esc_end_addr_buf_29__i_2_n_0_a234efd = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__29_aa2b4b7)) : (esc_start_addr_reg_n_0__29_aa2b4b7));

  // Reconstructed LUT2: esc_end_addr_buf_29__i_3_88bf3a5
  assign esc_end_addr_buf_29__i_3_n_0_0c408fa = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__28_0abd4bb)) : (esc_start_addr_reg_n_0__28_0abd4bb));

  // Reconstructed LUT2: esc_end_addr_buf_29__i_4_b07b528
  assign esc_end_addr_buf_29__i_4_n_0_eb1deb1 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__27_4bb8d27)) : (esc_start_addr_reg_n_0__27_4bb8d27));

  // Reconstructed LUT2: esc_end_addr_buf_29__i_5_ee593a8
  assign esc_end_addr_buf_29__i_5_n_0_673bcfd = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__26_5efe7d3)) : (esc_start_addr_reg_n_0__26_5efe7d3));

  // Reconstructed LUT2: esc_end_addr_buf_2__i_1_fde8ce9
  assign end_addr[2] = ((esc_align_len_reg_n_0__4_9fa0be1) ? (~(esc_start_addr_reg_n_0__2_825dc7f)) : (esc_start_addr_reg_n_0__2_825dc7f));

  // Reconstructed LUT2: esc_end_addr_buf_33__i_2_4dd983b
  assign esc_end_addr_buf_33__i_2_n_0_ba38cf6 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__31_6881f62)) : (esc_start_addr_reg_n_0__31_6881f62));

  // Reconstructed LUT2: esc_end_addr_buf_33__i_3_a0e8b94
  assign esc_end_addr_buf_33__i_3_n_0_1b00089 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__30_fa7e7f5)) : (esc_start_addr_reg_n_0__30_fa7e7f5));

  // Reconstructed LUT2: esc_end_addr_buf_5__i_2_bb057a5
  assign esc_end_addr_buf_5__i_2_n_0_c358dc5 = ((esc_align_len_reg_n_0__5_511b982) ? (~(esc_start_addr_reg_n_0__5_51bdd86)) : (esc_start_addr_reg_n_0__5_51bdd86));

  // Reconstructed LUT2: esc_end_addr_buf_5__i_3_3303a28
  assign esc_end_addr_buf_5__i_3_n_0_05b3eae = ((esc_align_len_reg_n_0__4_9fa0be1) ? (~(esc_start_addr_reg_n_0__4_35bfd51)) : (esc_start_addr_reg_n_0__4_35bfd51));

  // Reconstructed LUT2: esc_end_addr_buf_5__i_4_b004115
  assign esc_end_addr_buf_5__i_4_n_0_c7750ab = ((esc_align_len_reg_n_0__4_9fa0be1) ? (~(esc_start_addr_reg_n_0__3_d6f6925)) : (esc_start_addr_reg_n_0__3_d6f6925));

  // Reconstructed LUT2: esc_end_addr_buf_5__i_5_d8311ef
  assign esc_end_addr_buf_5__i_5_n_0_54f3e3c = ((esc_align_len_reg_n_0__4_9fa0be1) ? (~(esc_start_addr_reg_n_0__2_825dc7f)) : (esc_start_addr_reg_n_0__2_825dc7f));

  // Reconstructed LUT2: esc_end_addr_buf_9__i_2_30606dd
  assign esc_end_addr_buf_9__i_2_n_0_db68aa3 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__9_b0ff003)) : (esc_start_addr_reg_n_0__9_b0ff003));

  // Reconstructed LUT2: esc_end_addr_buf_9__i_3_0f99a42
  assign esc_end_addr_buf_9__i_3_n_0_34ed475 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__8_22baed7)) : (esc_start_addr_reg_n_0__8_22baed7));

  // Reconstructed LUT2: esc_end_addr_buf_9__i_4_aa5a5d4
  assign esc_end_addr_buf_9__i_4_n_0_5bc5846 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__7_2aaf228)) : (esc_start_addr_reg_n_0__7_2aaf228));

  // Reconstructed LUT2: esc_end_addr_buf_9__i_5_3c9df81
  assign esc_end_addr_buf_9__i_5_n_0_fbd85c8 = ((esc_align_len_reg_n_0__31_e5660d3) ? (~(esc_start_addr_reg_n_0__6_85a28ac)) : (esc_start_addr_reg_n_0__6_85a28ac));

  // Reconstructed FDRE: esc_end_addr_buf_reg_10_9317ded
  reg recovered_264_q = 1'b0;
  assign esc_end_addr_buf_reg_n_0__10_c0d12d1 = recovered_264_q;
  wire recovered_264_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_264_reset || (((SR) === 1'bx) && (recovered_264_q == 1'b0))) recovered_264_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_264_q == (end_addr[10])))) recovered_264_q <= (end_addr[10]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_11_fca3e06
  reg recovered_265_q = 1'b0;
  assign esc_end_addr_buf_reg_n_0__11_d1748fe = recovered_265_q;
  wire recovered_265_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_265_reset || (((SR) === 1'bx) && (recovered_265_q == 1'b0))) recovered_265_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_265_q == (end_addr[11])))) recovered_265_q <= (end_addr[11]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_12_346c43c
  reg recovered_266_q = 1'b0;
  assign p_0_in0_in[0] = recovered_266_q;
  wire recovered_266_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_266_reset || (((SR) === 1'bx) && (recovered_266_q == 1'b0))) recovered_266_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_266_q == (end_addr[12])))) recovered_266_q <= (end_addr[12]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_13_2452c73
  reg recovered_267_q = 1'b0;
  assign p_0_in0_in[1] = recovered_267_q;
  wire recovered_267_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_267_reset || (((SR) === 1'bx) && (recovered_267_q == 1'b0))) recovered_267_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_267_q == (end_addr[13])))) recovered_267_q <= (end_addr[13]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_13__i_1_8506f88
  wire [3:0] recovered_268_co, recovered_268_o, recovered_268_s, recovered_268_di;
  assign recovered_268_s = {esc_end_addr_buf_13__i_2_n_0_aa6d7cc ,esc_end_addr_buf_13__i_3_n_0_79d8b5e ,esc_end_addr_buf_13__i_4_n_0_5117aa6 ,esc_end_addr_buf_13__i_5_n_0_83a716d };
  assign recovered_268_di = {esc_start_addr_reg_n_0__13_f3dfe34 ,esc_start_addr_reg_n_0__12_0ffbef5 ,esc_start_addr_reg_n_0__11_93897a8 ,esc_start_addr_reg_n_0__10_7dfdb33 };
  wire recovered_268_ci = ((esc_end_addr_buf_reg_9__i_1_n_0_c524ea0) !== 1'bz) && (esc_end_addr_buf_reg_9__i_1_n_0_c524ea0);
  wire recovered_268_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_268_o[0] = recovered_268_s[0] ^ (recovered_268_ci || recovered_268_cy);
  assign recovered_268_co[0] = (recovered_268_s[0] & (recovered_268_ci || recovered_268_cy)) | (~recovered_268_s[0] & recovered_268_di[0]);
  assign recovered_268_o[1] = recovered_268_s[1] ^ recovered_268_co[0];
  assign recovered_268_co[1] = (recovered_268_s[1] & recovered_268_co[0]) | (~recovered_268_s[1] & recovered_268_di[1]);
  assign recovered_268_o[2] = recovered_268_s[2] ^ recovered_268_co[1];
  assign recovered_268_co[2] = (recovered_268_s[2] & recovered_268_co[1]) | (~recovered_268_s[2] & recovered_268_di[2]);
  assign recovered_268_o[3] = recovered_268_s[3] ^ recovered_268_co[2];
  assign recovered_268_co[3] = (recovered_268_s[3] & recovered_268_co[2]) | (~recovered_268_s[3] & recovered_268_di[3]);
  assign {esc_end_addr_buf_reg_13__i_1_n_0_3c8fe49 ,esc_NLW_end_addr_buf_reg_13__i_1_CO_UNCONNECTED_6c20db1 [2:0]} = recovered_268_co;
  assign end_addr[13:10] = recovered_268_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_14_b9a6caa
  reg recovered_269_q = 1'b0;
  assign p_0_in0_in[2] = recovered_269_q;
  wire recovered_269_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_269_reset || (((SR) === 1'bx) && (recovered_269_q == 1'b0))) recovered_269_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_269_q == (end_addr[14])))) recovered_269_q <= (end_addr[14]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_15_24c4d49
  reg recovered_270_q = 1'b0;
  assign p_0_in0_in[3] = recovered_270_q;
  wire recovered_270_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_270_reset || (((SR) === 1'bx) && (recovered_270_q == 1'b0))) recovered_270_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_270_q == (end_addr[15])))) recovered_270_q <= (end_addr[15]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_16_d420b85
  reg recovered_271_q = 1'b0;
  assign p_0_in0_in[4] = recovered_271_q;
  wire recovered_271_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_271_reset || (((SR) === 1'bx) && (recovered_271_q == 1'b0))) recovered_271_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_271_q == (end_addr[16])))) recovered_271_q <= (end_addr[16]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_17_32614e1
  reg recovered_272_q = 1'b0;
  assign p_0_in0_in[5] = recovered_272_q;
  wire recovered_272_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_272_reset || (((SR) === 1'bx) && (recovered_272_q == 1'b0))) recovered_272_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_272_q == (end_addr[17])))) recovered_272_q <= (end_addr[17]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_17__i_1_6d8f75d
  wire [3:0] recovered_273_co, recovered_273_o, recovered_273_s, recovered_273_di;
  assign recovered_273_s = {esc_end_addr_buf_17__i_2_n_0_35ae088 ,esc_end_addr_buf_17__i_3_n_0_8f8554a ,esc_end_addr_buf_17__i_4_n_0_f4e92de ,esc_end_addr_buf_17__i_5_n_0_3646b5a };
  assign recovered_273_di = {esc_start_addr_reg_n_0__17_a7c7f14 ,esc_start_addr_reg_n_0__16_c2276cc ,esc_start_addr_reg_n_0__15_3a25f9c ,esc_start_addr_reg_n_0__14_726da08 };
  wire recovered_273_ci = ((esc_end_addr_buf_reg_13__i_1_n_0_3c8fe49) !== 1'bz) && (esc_end_addr_buf_reg_13__i_1_n_0_3c8fe49);
  wire recovered_273_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_273_o[0] = recovered_273_s[0] ^ (recovered_273_ci || recovered_273_cy);
  assign recovered_273_co[0] = (recovered_273_s[0] & (recovered_273_ci || recovered_273_cy)) | (~recovered_273_s[0] & recovered_273_di[0]);
  assign recovered_273_o[1] = recovered_273_s[1] ^ recovered_273_co[0];
  assign recovered_273_co[1] = (recovered_273_s[1] & recovered_273_co[0]) | (~recovered_273_s[1] & recovered_273_di[1]);
  assign recovered_273_o[2] = recovered_273_s[2] ^ recovered_273_co[1];
  assign recovered_273_co[2] = (recovered_273_s[2] & recovered_273_co[1]) | (~recovered_273_s[2] & recovered_273_di[2]);
  assign recovered_273_o[3] = recovered_273_s[3] ^ recovered_273_co[2];
  assign recovered_273_co[3] = (recovered_273_s[3] & recovered_273_co[2]) | (~recovered_273_s[3] & recovered_273_di[3]);
  assign {esc_end_addr_buf_reg_17__i_1_n_0_11987eb ,esc_NLW_end_addr_buf_reg_17__i_1_CO_UNCONNECTED_7ee3189 [2:0]} = recovered_273_co;
  assign end_addr[17:14] = recovered_273_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_18_6fdc90f
  reg recovered_274_q = 1'b0;
  assign p_0_in0_in[6] = recovered_274_q;
  wire recovered_274_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_274_reset || (((SR) === 1'bx) && (recovered_274_q == 1'b0))) recovered_274_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_274_q == (end_addr[18])))) recovered_274_q <= (end_addr[18]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_19_e7d476d
  reg recovered_275_q = 1'b0;
  assign p_0_in0_in[7] = recovered_275_q;
  wire recovered_275_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_275_reset || (((SR) === 1'bx) && (recovered_275_q == 1'b0))) recovered_275_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_275_q == (end_addr[19])))) recovered_275_q <= (end_addr[19]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_20_57f7636
  reg recovered_276_q = 1'b0;
  assign p_0_in0_in[8] = recovered_276_q;
  wire recovered_276_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_276_reset || (((SR) === 1'bx) && (recovered_276_q == 1'b0))) recovered_276_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_276_q == (end_addr[20])))) recovered_276_q <= (end_addr[20]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_21_c54d87e
  reg recovered_277_q = 1'b0;
  assign p_0_in0_in[9] = recovered_277_q;
  wire recovered_277_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_277_reset || (((SR) === 1'bx) && (recovered_277_q == 1'b0))) recovered_277_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_277_q == (end_addr[21])))) recovered_277_q <= (end_addr[21]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_21__i_1_aeb9263
  wire [3:0] recovered_278_co, recovered_278_o, recovered_278_s, recovered_278_di;
  assign recovered_278_s = {esc_end_addr_buf_21__i_2_n_0_8c345c2 ,esc_end_addr_buf_21__i_3_n_0_14647fd ,esc_end_addr_buf_21__i_4_n_0_fc38406 ,esc_end_addr_buf_21__i_5_n_0_5cf9081 };
  assign recovered_278_di = {esc_start_addr_reg_n_0__21_9efa866 ,esc_start_addr_reg_n_0__20_a055fe3 ,esc_start_addr_reg_n_0__19_3510eae ,esc_start_addr_reg_n_0__18_7d4f45f };
  wire recovered_278_ci = ((esc_end_addr_buf_reg_17__i_1_n_0_11987eb) !== 1'bz) && (esc_end_addr_buf_reg_17__i_1_n_0_11987eb);
  wire recovered_278_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_278_o[0] = recovered_278_s[0] ^ (recovered_278_ci || recovered_278_cy);
  assign recovered_278_co[0] = (recovered_278_s[0] & (recovered_278_ci || recovered_278_cy)) | (~recovered_278_s[0] & recovered_278_di[0]);
  assign recovered_278_o[1] = recovered_278_s[1] ^ recovered_278_co[0];
  assign recovered_278_co[1] = (recovered_278_s[1] & recovered_278_co[0]) | (~recovered_278_s[1] & recovered_278_di[1]);
  assign recovered_278_o[2] = recovered_278_s[2] ^ recovered_278_co[1];
  assign recovered_278_co[2] = (recovered_278_s[2] & recovered_278_co[1]) | (~recovered_278_s[2] & recovered_278_di[2]);
  assign recovered_278_o[3] = recovered_278_s[3] ^ recovered_278_co[2];
  assign recovered_278_co[3] = (recovered_278_s[3] & recovered_278_co[2]) | (~recovered_278_s[3] & recovered_278_di[3]);
  assign {esc_end_addr_buf_reg_21__i_1_n_0_e5cb45d ,esc_NLW_end_addr_buf_reg_21__i_1_CO_UNCONNECTED_43d0ce0 [2:0]} = recovered_278_co;
  assign end_addr[21:18] = recovered_278_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_22_d964cef
  reg recovered_279_q = 1'b0;
  assign p_0_in0_in[10] = recovered_279_q;
  wire recovered_279_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_279_reset || (((SR) === 1'bx) && (recovered_279_q == 1'b0))) recovered_279_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_279_q == (end_addr[22])))) recovered_279_q <= (end_addr[22]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_23_f86e698
  reg recovered_280_q = 1'b0;
  assign p_0_in0_in[11] = recovered_280_q;
  wire recovered_280_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_280_reset || (((SR) === 1'bx) && (recovered_280_q == 1'b0))) recovered_280_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_280_q == (end_addr[23])))) recovered_280_q <= (end_addr[23]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_24_88a8193
  reg recovered_281_q = 1'b0;
  assign p_0_in0_in[12] = recovered_281_q;
  wire recovered_281_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_281_reset || (((SR) === 1'bx) && (recovered_281_q == 1'b0))) recovered_281_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_281_q == (end_addr[24])))) recovered_281_q <= (end_addr[24]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_25_e2bda06
  reg recovered_282_q = 1'b0;
  assign p_0_in0_in[13] = recovered_282_q;
  wire recovered_282_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_282_reset || (((SR) === 1'bx) && (recovered_282_q == 1'b0))) recovered_282_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_282_q == (end_addr[25])))) recovered_282_q <= (end_addr[25]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_25__i_1_12f9b1b
  wire [3:0] recovered_283_co, recovered_283_o, recovered_283_s, recovered_283_di;
  assign recovered_283_s = {esc_end_addr_buf_25__i_2_n_0_b8fef88 ,esc_end_addr_buf_25__i_3_n_0_c486315 ,esc_end_addr_buf_25__i_4_n_0_3133667 ,esc_end_addr_buf_25__i_5_n_0_76e97aa };
  assign recovered_283_di = {esc_start_addr_reg_n_0__25_b477c1e ,esc_start_addr_reg_n_0__24_1d34d3b ,esc_start_addr_reg_n_0__23_907ba78 ,esc_start_addr_reg_n_0__22_ba17a60 };
  wire recovered_283_ci = ((esc_end_addr_buf_reg_21__i_1_n_0_e5cb45d) !== 1'bz) && (esc_end_addr_buf_reg_21__i_1_n_0_e5cb45d);
  wire recovered_283_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_283_o[0] = recovered_283_s[0] ^ (recovered_283_ci || recovered_283_cy);
  assign recovered_283_co[0] = (recovered_283_s[0] & (recovered_283_ci || recovered_283_cy)) | (~recovered_283_s[0] & recovered_283_di[0]);
  assign recovered_283_o[1] = recovered_283_s[1] ^ recovered_283_co[0];
  assign recovered_283_co[1] = (recovered_283_s[1] & recovered_283_co[0]) | (~recovered_283_s[1] & recovered_283_di[1]);
  assign recovered_283_o[2] = recovered_283_s[2] ^ recovered_283_co[1];
  assign recovered_283_co[2] = (recovered_283_s[2] & recovered_283_co[1]) | (~recovered_283_s[2] & recovered_283_di[2]);
  assign recovered_283_o[3] = recovered_283_s[3] ^ recovered_283_co[2];
  assign recovered_283_co[3] = (recovered_283_s[3] & recovered_283_co[2]) | (~recovered_283_s[3] & recovered_283_di[3]);
  assign {esc_end_addr_buf_reg_25__i_1_n_0_86db6f3 ,esc_NLW_end_addr_buf_reg_25__i_1_CO_UNCONNECTED_fd986b6 [2:0]} = recovered_283_co;
  assign end_addr[25:22] = recovered_283_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_26_6fafbf6
  reg recovered_284_q = 1'b0;
  assign p_0_in0_in[14] = recovered_284_q;
  wire recovered_284_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_284_reset || (((SR) === 1'bx) && (recovered_284_q == 1'b0))) recovered_284_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_284_q == (end_addr[26])))) recovered_284_q <= (end_addr[26]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_27_d00f5a8
  reg recovered_285_q = 1'b0;
  assign p_0_in0_in[15] = recovered_285_q;
  wire recovered_285_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_285_reset || (((SR) === 1'bx) && (recovered_285_q == 1'b0))) recovered_285_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_285_q == (end_addr[27])))) recovered_285_q <= (end_addr[27]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_28_085dd41
  reg recovered_286_q = 1'b0;
  assign p_0_in0_in[16] = recovered_286_q;
  wire recovered_286_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_286_reset || (((SR) === 1'bx) && (recovered_286_q == 1'b0))) recovered_286_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_286_q == (end_addr[28])))) recovered_286_q <= (end_addr[28]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_29_750221c
  reg recovered_287_q = 1'b0;
  assign p_0_in0_in[17] = recovered_287_q;
  wire recovered_287_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_287_reset || (((SR) === 1'bx) && (recovered_287_q == 1'b0))) recovered_287_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_287_q == (end_addr[29])))) recovered_287_q <= (end_addr[29]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_29__i_1_0f96b4d
  wire [3:0] recovered_288_co, recovered_288_o, recovered_288_s, recovered_288_di;
  assign recovered_288_s = {esc_end_addr_buf_29__i_2_n_0_a234efd ,esc_end_addr_buf_29__i_3_n_0_0c408fa ,esc_end_addr_buf_29__i_4_n_0_eb1deb1 ,esc_end_addr_buf_29__i_5_n_0_673bcfd };
  assign recovered_288_di = {esc_start_addr_reg_n_0__29_aa2b4b7 ,esc_start_addr_reg_n_0__28_0abd4bb ,esc_start_addr_reg_n_0__27_4bb8d27 ,esc_start_addr_reg_n_0__26_5efe7d3 };
  wire recovered_288_ci = ((esc_end_addr_buf_reg_25__i_1_n_0_86db6f3) !== 1'bz) && (esc_end_addr_buf_reg_25__i_1_n_0_86db6f3);
  wire recovered_288_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_288_o[0] = recovered_288_s[0] ^ (recovered_288_ci || recovered_288_cy);
  assign recovered_288_co[0] = (recovered_288_s[0] & (recovered_288_ci || recovered_288_cy)) | (~recovered_288_s[0] & recovered_288_di[0]);
  assign recovered_288_o[1] = recovered_288_s[1] ^ recovered_288_co[0];
  assign recovered_288_co[1] = (recovered_288_s[1] & recovered_288_co[0]) | (~recovered_288_s[1] & recovered_288_di[1]);
  assign recovered_288_o[2] = recovered_288_s[2] ^ recovered_288_co[1];
  assign recovered_288_co[2] = (recovered_288_s[2] & recovered_288_co[1]) | (~recovered_288_s[2] & recovered_288_di[2]);
  assign recovered_288_o[3] = recovered_288_s[3] ^ recovered_288_co[2];
  assign recovered_288_co[3] = (recovered_288_s[3] & recovered_288_co[2]) | (~recovered_288_s[3] & recovered_288_di[3]);
  assign {esc_end_addr_buf_reg_29__i_1_n_0_cf4fd44 ,esc_NLW_end_addr_buf_reg_29__i_1_CO_UNCONNECTED_63efa90 [2:0]} = recovered_288_co;
  assign end_addr[29:26] = recovered_288_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_2_46c1f26
  reg recovered_289_q = 1'b0;
  assign esc_end_addr_buf_reg_n_0__2_e2f5013 = recovered_289_q;
  wire recovered_289_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_289_reset || (((SR) === 1'bx) && (recovered_289_q == 1'b0))) recovered_289_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_289_q == (end_addr[2])))) recovered_289_q <= (end_addr[2]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_30_15e1071
  reg recovered_290_q = 1'b0;
  assign p_0_in0_in[18] = recovered_290_q;
  wire recovered_290_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_290_reset || (((SR) === 1'bx) && (recovered_290_q == 1'b0))) recovered_290_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_290_q == (end_addr[30])))) recovered_290_q <= (end_addr[30]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_31_e3a7b91
  reg recovered_291_q = 1'b0;
  assign p_0_in0_in[19] = recovered_291_q;
  wire recovered_291_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_291_reset || (((SR) === 1'bx) && (recovered_291_q == 1'b0))) recovered_291_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_291_q == (end_addr[31])))) recovered_291_q <= (end_addr[31]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_32_c0bdf44
  reg recovered_292_q = 1'b0;
  assign p_0_in0_in[20] = recovered_292_q;
  wire recovered_292_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_292_reset || (((SR) === 1'bx) && (recovered_292_q == 1'b0))) recovered_292_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_292_q == (end_addr[32])))) recovered_292_q <= (end_addr[32]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_33_517dc1a
  reg recovered_293_q = 1'b0;
  assign p_0_in0_in[21] = recovered_293_q;
  wire recovered_293_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_293_reset || (((SR) === 1'bx) && (recovered_293_q == 1'b0))) recovered_293_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_293_q == (end_addr[33])))) recovered_293_q <= (end_addr[33]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_33__i_1_070e45f
  wire [3:0] recovered_294_co, recovered_294_o, recovered_294_s, recovered_294_di;
  assign recovered_294_s = {esc_start_addr_reg_n_0__33_e2508d5 ,esc_start_addr_reg_n_0__32_d304ae3 ,esc_end_addr_buf_33__i_2_n_0_ba38cf6 ,esc_end_addr_buf_33__i_3_n_0_1b00089 };
  assign recovered_294_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_start_addr_reg_n_0__31_6881f62 ,esc_start_addr_reg_n_0__30_fa7e7f5 };
  wire recovered_294_ci = ((esc_end_addr_buf_reg_29__i_1_n_0_cf4fd44) !== 1'bz) && (esc_end_addr_buf_reg_29__i_1_n_0_cf4fd44);
  wire recovered_294_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_294_o[0] = recovered_294_s[0] ^ (recovered_294_ci || recovered_294_cy);
  assign recovered_294_co[0] = (recovered_294_s[0] & (recovered_294_ci || recovered_294_cy)) | (~recovered_294_s[0] & recovered_294_di[0]);
  assign recovered_294_o[1] = recovered_294_s[1] ^ recovered_294_co[0];
  assign recovered_294_co[1] = (recovered_294_s[1] & recovered_294_co[0]) | (~recovered_294_s[1] & recovered_294_di[1]);
  assign recovered_294_o[2] = recovered_294_s[2] ^ recovered_294_co[1];
  assign recovered_294_co[2] = (recovered_294_s[2] & recovered_294_co[1]) | (~recovered_294_s[2] & recovered_294_di[2]);
  assign recovered_294_o[3] = recovered_294_s[3] ^ recovered_294_co[2];
  assign recovered_294_co[3] = (recovered_294_s[3] & recovered_294_co[2]) | (~recovered_294_s[3] & recovered_294_di[3]);
  assign {esc_end_addr_buf_reg_33__i_1_n_0_0ed11e6 ,esc_NLW_end_addr_buf_reg_33__i_1_CO_UNCONNECTED_5fc7d63 [2:0]} = recovered_294_co;
  assign end_addr[33:30] = recovered_294_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_34_df4ac83
  reg recovered_295_q = 1'b0;
  assign p_0_in0_in[22] = recovered_295_q;
  wire recovered_295_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_295_reset || (((SR) === 1'bx) && (recovered_295_q == 1'b0))) recovered_295_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_295_q == (end_addr[34])))) recovered_295_q <= (end_addr[34]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_35_7660c13
  reg recovered_296_q = 1'b0;
  assign p_0_in0_in[23] = recovered_296_q;
  wire recovered_296_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_296_reset || (((SR) === 1'bx) && (recovered_296_q == 1'b0))) recovered_296_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_296_q == (end_addr[35])))) recovered_296_q <= (end_addr[35]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_36_0fc7caa
  reg recovered_297_q = 1'b0;
  assign p_0_in0_in[24] = recovered_297_q;
  wire recovered_297_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_297_reset || (((SR) === 1'bx) && (recovered_297_q == 1'b0))) recovered_297_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_297_q == (end_addr[36])))) recovered_297_q <= (end_addr[36]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_37_1a76900
  reg recovered_298_q = 1'b0;
  assign p_0_in0_in[25] = recovered_298_q;
  wire recovered_298_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_298_reset || (((SR) === 1'bx) && (recovered_298_q == 1'b0))) recovered_298_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_298_q == (end_addr[37])))) recovered_298_q <= (end_addr[37]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_37__i_1_ea08710
  wire [3:0] recovered_299_co, recovered_299_o, recovered_299_s, recovered_299_di;
  assign recovered_299_s = {esc_start_addr_reg_n_0__37_49e2d9d ,esc_start_addr_reg_n_0__36_1b35e42 ,esc_start_addr_reg_n_0__35_e55187f ,esc_start_addr_reg_n_0__34_7048a69 };
  assign recovered_299_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_299_ci = ((esc_end_addr_buf_reg_33__i_1_n_0_0ed11e6) !== 1'bz) && (esc_end_addr_buf_reg_33__i_1_n_0_0ed11e6);
  wire recovered_299_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_299_o[0] = recovered_299_s[0] ^ (recovered_299_ci || recovered_299_cy);
  assign recovered_299_co[0] = (recovered_299_s[0] & (recovered_299_ci || recovered_299_cy)) | (~recovered_299_s[0] & recovered_299_di[0]);
  assign recovered_299_o[1] = recovered_299_s[1] ^ recovered_299_co[0];
  assign recovered_299_co[1] = (recovered_299_s[1] & recovered_299_co[0]) | (~recovered_299_s[1] & recovered_299_di[1]);
  assign recovered_299_o[2] = recovered_299_s[2] ^ recovered_299_co[1];
  assign recovered_299_co[2] = (recovered_299_s[2] & recovered_299_co[1]) | (~recovered_299_s[2] & recovered_299_di[2]);
  assign recovered_299_o[3] = recovered_299_s[3] ^ recovered_299_co[2];
  assign recovered_299_co[3] = (recovered_299_s[3] & recovered_299_co[2]) | (~recovered_299_s[3] & recovered_299_di[3]);
  assign {esc_end_addr_buf_reg_37__i_1_n_0_f5b0379 ,esc_NLW_end_addr_buf_reg_37__i_1_CO_UNCONNECTED_5af208f [2:0]} = recovered_299_co;
  assign end_addr[37:34] = recovered_299_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_38_fca575f
  reg recovered_300_q = 1'b0;
  assign p_0_in0_in[26] = recovered_300_q;
  wire recovered_300_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_300_reset || (((SR) === 1'bx) && (recovered_300_q == 1'b0))) recovered_300_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_300_q == (end_addr[38])))) recovered_300_q <= (end_addr[38]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_39_4846737
  reg recovered_301_q = 1'b0;
  assign p_0_in0_in[27] = recovered_301_q;
  wire recovered_301_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_301_reset || (((SR) === 1'bx) && (recovered_301_q == 1'b0))) recovered_301_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_301_q == (end_addr[39])))) recovered_301_q <= (end_addr[39]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_3_56c8c96
  reg recovered_302_q = 1'b0;
  assign esc_end_addr_buf_reg_n_0__3_01f6baa = recovered_302_q;
  wire recovered_302_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_302_reset || (((SR) === 1'bx) && (recovered_302_q == 1'b0))) recovered_302_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_302_q == (end_addr[3])))) recovered_302_q <= (end_addr[3]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_40_1d77406
  reg recovered_303_q = 1'b0;
  assign p_0_in0_in[28] = recovered_303_q;
  wire recovered_303_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_303_reset || (((SR) === 1'bx) && (recovered_303_q == 1'b0))) recovered_303_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_303_q == (end_addr[40])))) recovered_303_q <= (end_addr[40]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_41_e6f0c4e
  reg recovered_304_q = 1'b0;
  assign p_0_in0_in[29] = recovered_304_q;
  wire recovered_304_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_304_reset || (((SR) === 1'bx) && (recovered_304_q == 1'b0))) recovered_304_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_304_q == (end_addr[41])))) recovered_304_q <= (end_addr[41]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_41__i_1_ebe5b01
  wire [3:0] recovered_305_co, recovered_305_o, recovered_305_s, recovered_305_di;
  assign recovered_305_s = {esc_start_addr_reg_n_0__41_aca3f17 ,esc_start_addr_reg_n_0__40_44358a2 ,esc_start_addr_reg_n_0__39_9f399ca ,esc_start_addr_reg_n_0__38_abcede3 };
  assign recovered_305_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_305_ci = ((esc_end_addr_buf_reg_37__i_1_n_0_f5b0379) !== 1'bz) && (esc_end_addr_buf_reg_37__i_1_n_0_f5b0379);
  wire recovered_305_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_305_o[0] = recovered_305_s[0] ^ (recovered_305_ci || recovered_305_cy);
  assign recovered_305_co[0] = (recovered_305_s[0] & (recovered_305_ci || recovered_305_cy)) | (~recovered_305_s[0] & recovered_305_di[0]);
  assign recovered_305_o[1] = recovered_305_s[1] ^ recovered_305_co[0];
  assign recovered_305_co[1] = (recovered_305_s[1] & recovered_305_co[0]) | (~recovered_305_s[1] & recovered_305_di[1]);
  assign recovered_305_o[2] = recovered_305_s[2] ^ recovered_305_co[1];
  assign recovered_305_co[2] = (recovered_305_s[2] & recovered_305_co[1]) | (~recovered_305_s[2] & recovered_305_di[2]);
  assign recovered_305_o[3] = recovered_305_s[3] ^ recovered_305_co[2];
  assign recovered_305_co[3] = (recovered_305_s[3] & recovered_305_co[2]) | (~recovered_305_s[3] & recovered_305_di[3]);
  assign {esc_end_addr_buf_reg_41__i_1_n_0_6d8bcd2 ,esc_NLW_end_addr_buf_reg_41__i_1_CO_UNCONNECTED_f8d7e91 [2:0]} = recovered_305_co;
  assign end_addr[41:38] = recovered_305_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_42_49103dd
  reg recovered_306_q = 1'b0;
  assign p_0_in0_in[30] = recovered_306_q;
  wire recovered_306_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_306_reset || (((SR) === 1'bx) && (recovered_306_q == 1'b0))) recovered_306_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_306_q == (end_addr[42])))) recovered_306_q <= (end_addr[42]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_43_f90befa
  reg recovered_307_q = 1'b0;
  assign p_0_in0_in[31] = recovered_307_q;
  wire recovered_307_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_307_reset || (((SR) === 1'bx) && (recovered_307_q == 1'b0))) recovered_307_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_307_q == (end_addr[43])))) recovered_307_q <= (end_addr[43]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_44_d8cb39b
  reg recovered_308_q = 1'b0;
  assign p_0_in0_in[32] = recovered_308_q;
  wire recovered_308_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_308_reset || (((SR) === 1'bx) && (recovered_308_q == 1'b0))) recovered_308_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_308_q == (end_addr[44])))) recovered_308_q <= (end_addr[44]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_45_19ef799
  reg recovered_309_q = 1'b0;
  assign p_0_in0_in[33] = recovered_309_q;
  wire recovered_309_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_309_reset || (((SR) === 1'bx) && (recovered_309_q == 1'b0))) recovered_309_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_309_q == (end_addr[45])))) recovered_309_q <= (end_addr[45]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_45__i_1_9e3f472
  wire [3:0] recovered_310_co, recovered_310_o, recovered_310_s, recovered_310_di;
  assign recovered_310_s = {esc_start_addr_reg_n_0__45_c02f4ba ,esc_start_addr_reg_n_0__44_91d3e92 ,esc_start_addr_reg_n_0__43_eeeef11 ,esc_start_addr_reg_n_0__42_a3d52cc };
  assign recovered_310_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_310_ci = ((esc_end_addr_buf_reg_41__i_1_n_0_6d8bcd2) !== 1'bz) && (esc_end_addr_buf_reg_41__i_1_n_0_6d8bcd2);
  wire recovered_310_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_310_o[0] = recovered_310_s[0] ^ (recovered_310_ci || recovered_310_cy);
  assign recovered_310_co[0] = (recovered_310_s[0] & (recovered_310_ci || recovered_310_cy)) | (~recovered_310_s[0] & recovered_310_di[0]);
  assign recovered_310_o[1] = recovered_310_s[1] ^ recovered_310_co[0];
  assign recovered_310_co[1] = (recovered_310_s[1] & recovered_310_co[0]) | (~recovered_310_s[1] & recovered_310_di[1]);
  assign recovered_310_o[2] = recovered_310_s[2] ^ recovered_310_co[1];
  assign recovered_310_co[2] = (recovered_310_s[2] & recovered_310_co[1]) | (~recovered_310_s[2] & recovered_310_di[2]);
  assign recovered_310_o[3] = recovered_310_s[3] ^ recovered_310_co[2];
  assign recovered_310_co[3] = (recovered_310_s[3] & recovered_310_co[2]) | (~recovered_310_s[3] & recovered_310_di[3]);
  assign {esc_end_addr_buf_reg_45__i_1_n_0_8ea948c ,esc_NLW_end_addr_buf_reg_45__i_1_CO_UNCONNECTED_3779586 [2:0]} = recovered_310_co;
  assign end_addr[45:42] = recovered_310_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_46_872b8a4
  reg recovered_311_q = 1'b0;
  assign p_0_in0_in[34] = recovered_311_q;
  wire recovered_311_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_311_reset || (((SR) === 1'bx) && (recovered_311_q == 1'b0))) recovered_311_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_311_q == (end_addr[46])))) recovered_311_q <= (end_addr[46]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_47_6621289
  reg recovered_312_q = 1'b0;
  assign p_0_in0_in[35] = recovered_312_q;
  wire recovered_312_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_312_reset || (((SR) === 1'bx) && (recovered_312_q == 1'b0))) recovered_312_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_312_q == (end_addr[47])))) recovered_312_q <= (end_addr[47]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_48_0880b86
  reg recovered_313_q = 1'b0;
  assign p_0_in0_in[36] = recovered_313_q;
  wire recovered_313_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_313_reset || (((SR) === 1'bx) && (recovered_313_q == 1'b0))) recovered_313_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_313_q == (end_addr[48])))) recovered_313_q <= (end_addr[48]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_49_6ee69c2
  reg recovered_314_q = 1'b0;
  assign p_0_in0_in[37] = recovered_314_q;
  wire recovered_314_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_314_reset || (((SR) === 1'bx) && (recovered_314_q == 1'b0))) recovered_314_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_314_q == (end_addr[49])))) recovered_314_q <= (end_addr[49]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_49__i_1_80f8636
  wire [3:0] recovered_315_co, recovered_315_o, recovered_315_s, recovered_315_di;
  assign recovered_315_s = {esc_start_addr_reg_n_0__49_f51d0fb ,esc_start_addr_reg_n_0__48_bba970f ,esc_start_addr_reg_n_0__47_38b6f54 ,esc_start_addr_reg_n_0__46_ffff99b };
  assign recovered_315_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_315_ci = ((esc_end_addr_buf_reg_45__i_1_n_0_8ea948c) !== 1'bz) && (esc_end_addr_buf_reg_45__i_1_n_0_8ea948c);
  wire recovered_315_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_315_o[0] = recovered_315_s[0] ^ (recovered_315_ci || recovered_315_cy);
  assign recovered_315_co[0] = (recovered_315_s[0] & (recovered_315_ci || recovered_315_cy)) | (~recovered_315_s[0] & recovered_315_di[0]);
  assign recovered_315_o[1] = recovered_315_s[1] ^ recovered_315_co[0];
  assign recovered_315_co[1] = (recovered_315_s[1] & recovered_315_co[0]) | (~recovered_315_s[1] & recovered_315_di[1]);
  assign recovered_315_o[2] = recovered_315_s[2] ^ recovered_315_co[1];
  assign recovered_315_co[2] = (recovered_315_s[2] & recovered_315_co[1]) | (~recovered_315_s[2] & recovered_315_di[2]);
  assign recovered_315_o[3] = recovered_315_s[3] ^ recovered_315_co[2];
  assign recovered_315_co[3] = (recovered_315_s[3] & recovered_315_co[2]) | (~recovered_315_s[3] & recovered_315_di[3]);
  assign {esc_end_addr_buf_reg_49__i_1_n_0_04a4c49 ,esc_NLW_end_addr_buf_reg_49__i_1_CO_UNCONNECTED_9c2b774 [2:0]} = recovered_315_co;
  assign end_addr[49:46] = recovered_315_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_4_a8ad670
  reg recovered_316_q = 1'b0;
  assign esc_end_addr_buf_reg_n_0__4_96f56e3 = recovered_316_q;
  wire recovered_316_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_316_reset || (((SR) === 1'bx) && (recovered_316_q == 1'b0))) recovered_316_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_316_q == (end_addr[4])))) recovered_316_q <= (end_addr[4]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_50_30130c8
  reg recovered_317_q = 1'b0;
  assign p_0_in0_in[38] = recovered_317_q;
  wire recovered_317_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_317_reset || (((SR) === 1'bx) && (recovered_317_q == 1'b0))) recovered_317_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_317_q == (end_addr[50])))) recovered_317_q <= (end_addr[50]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_51_c3287c6
  reg recovered_318_q = 1'b0;
  assign p_0_in0_in[39] = recovered_318_q;
  wire recovered_318_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_318_reset || (((SR) === 1'bx) && (recovered_318_q == 1'b0))) recovered_318_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_318_q == (end_addr[51])))) recovered_318_q <= (end_addr[51]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_52_a21a87e
  reg recovered_319_q = 1'b0;
  assign p_0_in0_in[40] = recovered_319_q;
  wire recovered_319_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_319_reset || (((SR) === 1'bx) && (recovered_319_q == 1'b0))) recovered_319_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_319_q == (end_addr[52])))) recovered_319_q <= (end_addr[52]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_53_6f38623
  reg recovered_320_q = 1'b0;
  assign p_0_in0_in[41] = recovered_320_q;
  wire recovered_320_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_320_reset || (((SR) === 1'bx) && (recovered_320_q == 1'b0))) recovered_320_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_320_q == (end_addr[53])))) recovered_320_q <= (end_addr[53]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_53__i_1_f5ce7f2
  wire [3:0] recovered_321_co, recovered_321_o, recovered_321_s, recovered_321_di;
  assign recovered_321_s = {esc_start_addr_reg_n_0__53_391e956 ,esc_start_addr_reg_n_0__52_4ddab7f ,esc_start_addr_reg_n_0__51_71ee3d6 ,esc_start_addr_reg_n_0__50_4a0d627 };
  assign recovered_321_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_321_ci = ((esc_end_addr_buf_reg_49__i_1_n_0_04a4c49) !== 1'bz) && (esc_end_addr_buf_reg_49__i_1_n_0_04a4c49);
  wire recovered_321_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_321_o[0] = recovered_321_s[0] ^ (recovered_321_ci || recovered_321_cy);
  assign recovered_321_co[0] = (recovered_321_s[0] & (recovered_321_ci || recovered_321_cy)) | (~recovered_321_s[0] & recovered_321_di[0]);
  assign recovered_321_o[1] = recovered_321_s[1] ^ recovered_321_co[0];
  assign recovered_321_co[1] = (recovered_321_s[1] & recovered_321_co[0]) | (~recovered_321_s[1] & recovered_321_di[1]);
  assign recovered_321_o[2] = recovered_321_s[2] ^ recovered_321_co[1];
  assign recovered_321_co[2] = (recovered_321_s[2] & recovered_321_co[1]) | (~recovered_321_s[2] & recovered_321_di[2]);
  assign recovered_321_o[3] = recovered_321_s[3] ^ recovered_321_co[2];
  assign recovered_321_co[3] = (recovered_321_s[3] & recovered_321_co[2]) | (~recovered_321_s[3] & recovered_321_di[3]);
  assign {esc_end_addr_buf_reg_53__i_1_n_0_9807381 ,esc_NLW_end_addr_buf_reg_53__i_1_CO_UNCONNECTED_0c406db [2:0]} = recovered_321_co;
  assign end_addr[53:50] = recovered_321_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_54_ef970bc
  reg recovered_322_q = 1'b0;
  assign p_0_in0_in[42] = recovered_322_q;
  wire recovered_322_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_322_reset || (((SR) === 1'bx) && (recovered_322_q == 1'b0))) recovered_322_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_322_q == (end_addr[54])))) recovered_322_q <= (end_addr[54]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_55_a6e3965
  reg recovered_323_q = 1'b0;
  assign p_0_in0_in[43] = recovered_323_q;
  wire recovered_323_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_323_reset || (((SR) === 1'bx) && (recovered_323_q == 1'b0))) recovered_323_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_323_q == (end_addr[55])))) recovered_323_q <= (end_addr[55]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_56_cfbf4c7
  reg recovered_324_q = 1'b0;
  assign p_0_in0_in[44] = recovered_324_q;
  wire recovered_324_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_324_reset || (((SR) === 1'bx) && (recovered_324_q == 1'b0))) recovered_324_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_324_q == (end_addr[56])))) recovered_324_q <= (end_addr[56]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_57_062a725
  reg recovered_325_q = 1'b0;
  assign p_0_in0_in[45] = recovered_325_q;
  wire recovered_325_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_325_reset || (((SR) === 1'bx) && (recovered_325_q == 1'b0))) recovered_325_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_325_q == (end_addr[57])))) recovered_325_q <= (end_addr[57]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_57__i_1_d406f81
  wire [3:0] recovered_326_co, recovered_326_o, recovered_326_s, recovered_326_di;
  assign recovered_326_s = {esc_start_addr_reg_n_0__57_897c5a0 ,esc_start_addr_reg_n_0__56_ed05e9e ,esc_start_addr_reg_n_0__55_f2a438b ,esc_start_addr_reg_n_0__54_6ca5236 };
  assign recovered_326_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_326_ci = ((esc_end_addr_buf_reg_53__i_1_n_0_9807381) !== 1'bz) && (esc_end_addr_buf_reg_53__i_1_n_0_9807381);
  wire recovered_326_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_326_o[0] = recovered_326_s[0] ^ (recovered_326_ci || recovered_326_cy);
  assign recovered_326_co[0] = (recovered_326_s[0] & (recovered_326_ci || recovered_326_cy)) | (~recovered_326_s[0] & recovered_326_di[0]);
  assign recovered_326_o[1] = recovered_326_s[1] ^ recovered_326_co[0];
  assign recovered_326_co[1] = (recovered_326_s[1] & recovered_326_co[0]) | (~recovered_326_s[1] & recovered_326_di[1]);
  assign recovered_326_o[2] = recovered_326_s[2] ^ recovered_326_co[1];
  assign recovered_326_co[2] = (recovered_326_s[2] & recovered_326_co[1]) | (~recovered_326_s[2] & recovered_326_di[2]);
  assign recovered_326_o[3] = recovered_326_s[3] ^ recovered_326_co[2];
  assign recovered_326_co[3] = (recovered_326_s[3] & recovered_326_co[2]) | (~recovered_326_s[3] & recovered_326_di[3]);
  assign {esc_end_addr_buf_reg_57__i_1_n_0_c02405a ,esc_NLW_end_addr_buf_reg_57__i_1_CO_UNCONNECTED_12bb8d1 [2:0]} = recovered_326_co;
  assign end_addr[57:54] = recovered_326_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_58_8be7f80
  reg recovered_327_q = 1'b0;
  assign p_0_in0_in[46] = recovered_327_q;
  wire recovered_327_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_327_reset || (((SR) === 1'bx) && (recovered_327_q == 1'b0))) recovered_327_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_327_q == (end_addr[58])))) recovered_327_q <= (end_addr[58]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_59_eb3b8cc
  reg recovered_328_q = 1'b0;
  assign p_0_in0_in[47] = recovered_328_q;
  wire recovered_328_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_328_reset || (((SR) === 1'bx) && (recovered_328_q == 1'b0))) recovered_328_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_328_q == (end_addr[59])))) recovered_328_q <= (end_addr[59]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_5_ef058d2
  reg recovered_329_q = 1'b0;
  assign esc_end_addr_buf_reg_n_0__5_8aa7b13 = recovered_329_q;
  wire recovered_329_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_329_reset || (((SR) === 1'bx) && (recovered_329_q == 1'b0))) recovered_329_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_329_q == (end_addr[5])))) recovered_329_q <= (end_addr[5]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_5__i_1_d975cc9
  wire [3:0] recovered_330_co, recovered_330_o, recovered_330_s, recovered_330_di;
  assign recovered_330_s = {esc_end_addr_buf_5__i_2_n_0_c358dc5 ,esc_end_addr_buf_5__i_3_n_0_05b3eae ,esc_end_addr_buf_5__i_4_n_0_c7750ab ,esc_end_addr_buf_5__i_5_n_0_54f3e3c };
  assign recovered_330_di = {esc_start_addr_reg_n_0__5_51bdd86 ,esc_start_addr_reg_n_0__4_35bfd51 ,esc_start_addr_reg_n_0__3_d6f6925 ,esc_start_addr_reg_n_0__2_825dc7f };
  wire recovered_330_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_330_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_330_o[0] = recovered_330_s[0] ^ (recovered_330_ci || recovered_330_cy);
  assign recovered_330_co[0] = (recovered_330_s[0] & (recovered_330_ci || recovered_330_cy)) | (~recovered_330_s[0] & recovered_330_di[0]);
  assign recovered_330_o[1] = recovered_330_s[1] ^ recovered_330_co[0];
  assign recovered_330_co[1] = (recovered_330_s[1] & recovered_330_co[0]) | (~recovered_330_s[1] & recovered_330_di[1]);
  assign recovered_330_o[2] = recovered_330_s[2] ^ recovered_330_co[1];
  assign recovered_330_co[2] = (recovered_330_s[2] & recovered_330_co[1]) | (~recovered_330_s[2] & recovered_330_di[2]);
  assign recovered_330_o[3] = recovered_330_s[3] ^ recovered_330_co[2];
  assign recovered_330_co[3] = (recovered_330_s[3] & recovered_330_co[2]) | (~recovered_330_s[3] & recovered_330_di[3]);
  assign {esc_end_addr_buf_reg_5__i_1_n_0_871a7e6 ,esc_NLW_end_addr_buf_reg_5__i_1_CO_UNCONNECTED_6ee8ade [2:0]} = recovered_330_co;
  assign {end_addr[5:3],esc_NLW_end_addr_buf_reg_5__i_1_O_UNCONNECTED_35eced8 [0]} = recovered_330_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_60_50b0ee1
  reg recovered_331_q = 1'b0;
  assign p_0_in0_in[48] = recovered_331_q;
  wire recovered_331_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_331_reset || (((SR) === 1'bx) && (recovered_331_q == 1'b0))) recovered_331_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_331_q == (end_addr[60])))) recovered_331_q <= (end_addr[60]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_61_3d33772
  reg recovered_332_q = 1'b0;
  assign p_0_in0_in[49] = recovered_332_q;
  wire recovered_332_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_332_reset || (((SR) === 1'bx) && (recovered_332_q == 1'b0))) recovered_332_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_332_q == (end_addr[61])))) recovered_332_q <= (end_addr[61]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_61__i_1_a332a5c
  wire [3:0] recovered_333_co, recovered_333_o, recovered_333_s, recovered_333_di;
  assign recovered_333_s = {esc_start_addr_reg_n_0__61_d0861cf ,esc_start_addr_reg_n_0__60_9bfecb1 ,esc_start_addr_reg_n_0__59_91cd7d0 ,esc_start_addr_reg_n_0__58_94d4f4b };
  assign recovered_333_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_333_ci = ((esc_end_addr_buf_reg_57__i_1_n_0_c02405a) !== 1'bz) && (esc_end_addr_buf_reg_57__i_1_n_0_c02405a);
  wire recovered_333_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_333_o[0] = recovered_333_s[0] ^ (recovered_333_ci || recovered_333_cy);
  assign recovered_333_co[0] = (recovered_333_s[0] & (recovered_333_ci || recovered_333_cy)) | (~recovered_333_s[0] & recovered_333_di[0]);
  assign recovered_333_o[1] = recovered_333_s[1] ^ recovered_333_co[0];
  assign recovered_333_co[1] = (recovered_333_s[1] & recovered_333_co[0]) | (~recovered_333_s[1] & recovered_333_di[1]);
  assign recovered_333_o[2] = recovered_333_s[2] ^ recovered_333_co[1];
  assign recovered_333_co[2] = (recovered_333_s[2] & recovered_333_co[1]) | (~recovered_333_s[2] & recovered_333_di[2]);
  assign recovered_333_o[3] = recovered_333_s[3] ^ recovered_333_co[2];
  assign recovered_333_co[3] = (recovered_333_s[3] & recovered_333_co[2]) | (~recovered_333_s[3] & recovered_333_di[3]);
  assign {esc_end_addr_buf_reg_61__i_1_n_0_7fe6a00 ,esc_NLW_end_addr_buf_reg_61__i_1_CO_UNCONNECTED_c48edce [2:0]} = recovered_333_co;
  assign end_addr[61:58] = recovered_333_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_62_0a5f22e
  reg recovered_334_q = 1'b0;
  assign p_0_in0_in[50] = recovered_334_q;
  wire recovered_334_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_334_reset || (((SR) === 1'bx) && (recovered_334_q == 1'b0))) recovered_334_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_334_q == (end_addr[62])))) recovered_334_q <= (end_addr[62]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_63_77f2f6e
  reg recovered_335_q = 1'b0;
  assign p_0_in0_in[51] = recovered_335_q;
  wire recovered_335_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_335_reset || (((SR) === 1'bx) && (recovered_335_q == 1'b0))) recovered_335_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_335_q == (end_addr[63])))) recovered_335_q <= (end_addr[63]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_63__i_1__0_713c278
  wire [3:0] recovered_336_co, recovered_336_o, recovered_336_s, recovered_336_di;
  assign recovered_336_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_start_addr_reg_n_0__63_6c9d71f ,esc_start_addr_reg_n_0__62_067c30f };
  assign recovered_336_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_336_ci = ((esc_end_addr_buf_reg_61__i_1_n_0_7fe6a00) !== 1'bz) && (esc_end_addr_buf_reg_61__i_1_n_0_7fe6a00);
  wire recovered_336_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_336_o[0] = recovered_336_s[0] ^ (recovered_336_ci || recovered_336_cy);
  assign recovered_336_co[0] = (recovered_336_s[0] & (recovered_336_ci || recovered_336_cy)) | (~recovered_336_s[0] & recovered_336_di[0]);
  assign recovered_336_o[1] = recovered_336_s[1] ^ recovered_336_co[0];
  assign recovered_336_co[1] = (recovered_336_s[1] & recovered_336_co[0]) | (~recovered_336_s[1] & recovered_336_di[1]);
  assign recovered_336_o[2] = recovered_336_s[2] ^ recovered_336_co[1];
  assign recovered_336_co[2] = (recovered_336_s[2] & recovered_336_co[1]) | (~recovered_336_s[2] & recovered_336_di[2]);
  assign recovered_336_o[3] = recovered_336_s[3] ^ recovered_336_co[2];
  assign recovered_336_co[3] = (recovered_336_s[3] & recovered_336_co[2]) | (~recovered_336_s[3] & recovered_336_di[3]);
  assign end_addr[63:62] = recovered_336_o;

  // Reconstructed FDRE: esc_end_addr_buf_reg_6_a9b81ef
  reg recovered_337_q = 1'b0;
  assign esc_end_addr_buf_reg_n_0__6_728119e = recovered_337_q;
  wire recovered_337_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_337_reset || (((SR) === 1'bx) && (recovered_337_q == 1'b0))) recovered_337_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_337_q == (end_addr[6])))) recovered_337_q <= (end_addr[6]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_7_c7de00b
  reg recovered_338_q = 1'b0;
  assign esc_end_addr_buf_reg_n_0__7_a09c043 = recovered_338_q;
  wire recovered_338_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_338_reset || (((SR) === 1'bx) && (recovered_338_q == 1'b0))) recovered_338_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_338_q == (end_addr[7])))) recovered_338_q <= (end_addr[7]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_8_f5cb114
  reg recovered_339_q = 1'b0;
  assign esc_end_addr_buf_reg_n_0__8_b6d3b5f = recovered_339_q;
  wire recovered_339_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_339_reset || (((SR) === 1'bx) && (recovered_339_q == 1'b0))) recovered_339_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_339_q == (end_addr[8])))) recovered_339_q <= (end_addr[8]);
  end

  // Reconstructed FDRE: esc_end_addr_buf_reg_9_3c7c3a2
  reg recovered_340_q = 1'b0;
  assign esc_end_addr_buf_reg_n_0__9_a87511a = recovered_340_q;
  wire recovered_340_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_340_reset || (((SR) === 1'bx) && (recovered_340_q == 1'b0))) recovered_340_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_340_q == (end_addr[9])))) recovered_340_q <= (end_addr[9]);
  end

  // Reconstructed CARRY4: esc_end_addr_buf_reg_9__i_1_a8d6c02
  wire [3:0] recovered_341_co, recovered_341_o, recovered_341_s, recovered_341_di;
  assign recovered_341_s = {esc_end_addr_buf_9__i_2_n_0_db68aa3 ,esc_end_addr_buf_9__i_3_n_0_34ed475 ,esc_end_addr_buf_9__i_4_n_0_5bc5846 ,esc_end_addr_buf_9__i_5_n_0_fbd85c8 };
  assign recovered_341_di = {esc_start_addr_reg_n_0__9_b0ff003 ,esc_start_addr_reg_n_0__8_22baed7 ,esc_start_addr_reg_n_0__7_2aaf228 ,esc_start_addr_reg_n_0__6_85a28ac };
  wire recovered_341_ci = ((esc_end_addr_buf_reg_5__i_1_n_0_871a7e6) !== 1'bz) && (esc_end_addr_buf_reg_5__i_1_n_0_871a7e6);
  wire recovered_341_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_341_o[0] = recovered_341_s[0] ^ (recovered_341_ci || recovered_341_cy);
  assign recovered_341_co[0] = (recovered_341_s[0] & (recovered_341_ci || recovered_341_cy)) | (~recovered_341_s[0] & recovered_341_di[0]);
  assign recovered_341_o[1] = recovered_341_s[1] ^ recovered_341_co[0];
  assign recovered_341_co[1] = (recovered_341_s[1] & recovered_341_co[0]) | (~recovered_341_s[1] & recovered_341_di[1]);
  assign recovered_341_o[2] = recovered_341_s[2] ^ recovered_341_co[1];
  assign recovered_341_co[2] = (recovered_341_s[2] & recovered_341_co[1]) | (~recovered_341_s[2] & recovered_341_di[2]);
  assign recovered_341_o[3] = recovered_341_s[3] ^ recovered_341_co[2];
  assign recovered_341_co[3] = (recovered_341_s[3] & recovered_341_co[2]) | (~recovered_341_s[3] & recovered_341_di[3]);
  assign {esc_end_addr_buf_reg_9__i_1_n_0_c524ea0 ,esc_NLW_end_addr_buf_reg_9__i_1_CO_UNCONNECTED_df4a3a2 [2:0]} = recovered_341_co;
  assign end_addr[9:6] = recovered_341_o;

  system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_fifo__parameterized1 fifo_resp
       (.SR(SR),
        .ap_clk(ap_clk),
        .ap_rst_n(ap_rst_n),
        .esc_could_multi_bursts_loop_cnt_reg_5_1c8fddc (esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938 ),
        .esc_could_multi_bursts_loop_cnt_reg_5__0_ac90938 (AWVALID_Dummy),
        .esc_could_multi_bursts_next_loop_c288065 (esc_could_multi_bursts_next_loop_c288065 ),
        .esc_could_multi_bursts_sect_handling_reg_a60c95a (fifo_resp_n_6),
        .esc_could_multi_bursts_sect_handling_reg_0_f501666 (esc_could_multi_bursts_sect_handling_reg_n_0_737ec10 ),
        .esc_could_multi_bursts_sect_handling_reg_1_bec7600 (esc_bus_equal_gen_fifo_burst_n_60_ce9cee6 ),
        .esc_could_multi_bursts_sect_handling_reg_2_ba13788 (wreq_handling_reg_n_0),
        .fifo_burst_ready(fifo_burst_ready),
        .fifo_resp_ready(fifo_resp_ready),
        .in(invalid_len_event_reg2),
        .invalid_len_event_reg2_reg(fifo_resp_n_2),
        .m_axi_output_r_BVALID(m_axi_output_r_BVALID),
        .next_resp(next_resp),
        .next_resp0(next_resp0),
        .next_resp_reg(full_n_reg),
        .push(push_0),
        .push_0(push),
        .esc_q_reg_1__0_d7f3451 (esc_could_multi_bursts_last_sect_buf_reg_n_0_659f5fa ));
  system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_fifo__parameterized2 fifo_resp_to_user
       (.D({D[11],D[0]}),
        .Q({Q[18:17],Q[0]}),
        .SR(SR),
        .ap_clk(ap_clk),
        .ap_done(ap_done),
        .ap_rst_n(ap_rst_n),
        .ap_start(ap_start),
        .empty_n_reg_0(empty_n_reg),
        .full_n_reg_0(full_n_reg),
        .push(push));
  system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_fifo__parameterized0 fifo_wreq
       (.E(align_len0),
        .Q(p_0_in0_in[51:48]),
        .S({fifo_wreq_n_2,fifo_wreq_n_3}),
        .SR(SR),
        .ap_clk(ap_clk),
        .ap_rst_n(ap_rst_n),
        .empty_n_reg_0(fifo_wreq_n_4),
        .empty_n_reg_1(fifo_wreq_n_69),
        .fifo_wreq_valid(fifo_wreq_valid),
        .last_sect_buf(last_sect_buf),
        .last_sect_carry__3({esc_sect_cnt_reg_n_0__51_b4f8fa6 ,esc_sect_cnt_reg_n_0__50_aee544d ,esc_sect_cnt_reg_n_0__49_ac3ce58 ,esc_sect_cnt_reg_n_0__48_c5dc410 }),
        .esc_pout_reg_1__0_e33da39 (rs2f_wreq_valid),
        .esc_q_reg_0__0_4378569 (last_sect),
        .esc_q_reg_0__1_c6877f4 (wreq_handling_reg_n_0),
        .esc_q_reg_61__0_805b7b0 (rs2f_wreq_data),
        .esc_q_reg_67__0_7bacafd ({fifo_wreq_data,fifo_wreq_n_6,fifo_wreq_n_7,fifo_wreq_n_8,fifo_wreq_n_9,fifo_wreq_n_10,fifo_wreq_n_11,fifo_wreq_n_12,fifo_wreq_n_13,fifo_wreq_n_14,fifo_wreq_n_15,fifo_wreq_n_16,fifo_wreq_n_17,fifo_wreq_n_18,fifo_wreq_n_19,fifo_wreq_n_20,fifo_wreq_n_21,fifo_wreq_n_22,fifo_wreq_n_23,fifo_wreq_n_24,fifo_wreq_n_25,fifo_wreq_n_26,fifo_wreq_n_27,fifo_wreq_n_28,fifo_wreq_n_29,fifo_wreq_n_30,fifo_wreq_n_31,fifo_wreq_n_32,fifo_wreq_n_33,fifo_wreq_n_34,fifo_wreq_n_35,fifo_wreq_n_36,fifo_wreq_n_37,fifo_wreq_n_38,fifo_wreq_n_39,fifo_wreq_n_40,fifo_wreq_n_41,fifo_wreq_n_42,fifo_wreq_n_43,fifo_wreq_n_44,fifo_wreq_n_45,fifo_wreq_n_46,fifo_wreq_n_47,fifo_wreq_n_48,fifo_wreq_n_49,fifo_wreq_n_50,fifo_wreq_n_51,fifo_wreq_n_52,fifo_wreq_n_53,fifo_wreq_n_54,fifo_wreq_n_55,fifo_wreq_n_56,fifo_wreq_n_57,fifo_wreq_n_58,fifo_wreq_n_59,fifo_wreq_n_60,fifo_wreq_n_61,fifo_wreq_n_62,fifo_wreq_n_63,fifo_wreq_n_64,fifo_wreq_n_65,fifo_wreq_n_66,fifo_wreq_n_67}),
        .esc_q_reg_67__1_0bf6791 (zero_len_event0),
        .rs2f_wreq_ack(rs2f_wreq_ack));

  // Reconstructed FDRE: fifo_wreq_valid_buf_reg
  reg recovered_345_q = 1'b0;
  assign fifo_wreq_valid_buf_reg_n_0 = recovered_345_q;
  wire recovered_345_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_345_reset || (((SR) === 1'bx) && (recovered_345_q == 1'b0))) recovered_345_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_345_q == (fifo_wreq_valid)))) recovered_345_q <= (fifo_wreq_valid);
  end

  // Reconstructed CARRY4: first_sect_carry
  wire [3:0] recovered_346_co, recovered_346_o, recovered_346_s, recovered_346_di;
  assign recovered_346_s = {first_sect_carry_i_1__0_n_0,first_sect_carry_i_2__0_n_0,first_sect_carry_i_3__0_n_0,first_sect_carry_i_4__0_n_0};
  assign recovered_346_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_346_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_346_cy = ((esc_const1_c064970) !== 1'bz) && (esc_const1_c064970);
  assign recovered_346_o[0] = recovered_346_s[0] ^ (recovered_346_ci || recovered_346_cy);
  assign recovered_346_co[0] = (recovered_346_s[0] & (recovered_346_ci || recovered_346_cy)) | (~recovered_346_s[0] & recovered_346_di[0]);
  assign recovered_346_o[1] = recovered_346_s[1] ^ recovered_346_co[0];
  assign recovered_346_co[1] = (recovered_346_s[1] & recovered_346_co[0]) | (~recovered_346_s[1] & recovered_346_di[1]);
  assign recovered_346_o[2] = recovered_346_s[2] ^ recovered_346_co[1];
  assign recovered_346_co[2] = (recovered_346_s[2] & recovered_346_co[1]) | (~recovered_346_s[2] & recovered_346_di[2]);
  assign recovered_346_o[3] = recovered_346_s[3] ^ recovered_346_co[2];
  assign recovered_346_co[3] = (recovered_346_s[3] & recovered_346_co[2]) | (~recovered_346_s[3] & recovered_346_di[3]);
  assign {first_sect_carry_n_0,NLW_first_sect_carry_CO_UNCONNECTED[2:0]} = recovered_346_co;

  // Reconstructed CARRY4: first_sect_carry__0
  wire [3:0] recovered_347_co, recovered_347_o, recovered_347_s, recovered_347_di;
  assign recovered_347_s = {first_sect_carry__0_i_1__0_n_0,first_sect_carry__0_i_2__0_n_0,first_sect_carry__0_i_3__0_n_0,first_sect_carry__0_i_4__0_n_0};
  assign recovered_347_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_347_ci = ((first_sect_carry_n_0) !== 1'bz) && (first_sect_carry_n_0);
  wire recovered_347_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_347_o[0] = recovered_347_s[0] ^ (recovered_347_ci || recovered_347_cy);
  assign recovered_347_co[0] = (recovered_347_s[0] & (recovered_347_ci || recovered_347_cy)) | (~recovered_347_s[0] & recovered_347_di[0]);
  assign recovered_347_o[1] = recovered_347_s[1] ^ recovered_347_co[0];
  assign recovered_347_co[1] = (recovered_347_s[1] & recovered_347_co[0]) | (~recovered_347_s[1] & recovered_347_di[1]);
  assign recovered_347_o[2] = recovered_347_s[2] ^ recovered_347_co[1];
  assign recovered_347_co[2] = (recovered_347_s[2] & recovered_347_co[1]) | (~recovered_347_s[2] & recovered_347_di[2]);
  assign recovered_347_o[3] = recovered_347_s[3] ^ recovered_347_co[2];
  assign recovered_347_co[3] = (recovered_347_s[3] & recovered_347_co[2]) | (~recovered_347_s[3] & recovered_347_di[3]);
  assign {first_sect_carry__0_n_0,NLW_first_sect_carry__0_CO_UNCONNECTED[2:0]} = recovered_347_co;

  // Reconstructed LUT6: first_sect_carry__0_i_1__0
  assign first_sect_carry__0_i_1__0_n_0 = ((p_0_in_0[22]) ? (((esc_sect_cnt_reg_n_0__22_fc0a11f) ? (((p_0_in_0[21]) ? (((esc_sect_cnt_reg_n_0__21_2affd71) ? (((esc_sect_cnt_reg_n_0__23_b356fba) ? (p_0_in_0[23]) : (~(p_0_in_0[23])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__21_2affd71) ? (1'b0) : (((esc_sect_cnt_reg_n_0__23_b356fba) ? (p_0_in_0[23]) : (~(p_0_in_0[23])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__22_fc0a11f) ? (1'b0) : (((p_0_in_0[21]) ? (((esc_sect_cnt_reg_n_0__21_2affd71) ? (((esc_sect_cnt_reg_n_0__23_b356fba) ? (p_0_in_0[23]) : (~(p_0_in_0[23])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__21_2affd71) ? (1'b0) : (((esc_sect_cnt_reg_n_0__23_b356fba) ? (p_0_in_0[23]) : (~(p_0_in_0[23])))))))))));

  // Reconstructed LUT6: first_sect_carry__0_i_2__0
  assign first_sect_carry__0_i_2__0_n_0 = ((p_0_in_0[19]) ? (((esc_sect_cnt_reg_n_0__19_d3501e6) ? (((p_0_in_0[18]) ? (((esc_sect_cnt_reg_n_0__18_2b2ad13) ? (((esc_sect_cnt_reg_n_0__20_44e2780) ? (p_0_in_0[20]) : (~(p_0_in_0[20])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__18_2b2ad13) ? (1'b0) : (((esc_sect_cnt_reg_n_0__20_44e2780) ? (p_0_in_0[20]) : (~(p_0_in_0[20])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__19_d3501e6) ? (1'b0) : (((p_0_in_0[18]) ? (((esc_sect_cnt_reg_n_0__18_2b2ad13) ? (((esc_sect_cnt_reg_n_0__20_44e2780) ? (p_0_in_0[20]) : (~(p_0_in_0[20])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__18_2b2ad13) ? (1'b0) : (((esc_sect_cnt_reg_n_0__20_44e2780) ? (p_0_in_0[20]) : (~(p_0_in_0[20])))))))))));

  // Reconstructed LUT6: first_sect_carry__0_i_3__0
  assign first_sect_carry__0_i_3__0_n_0 = ((p_0_in_0[16]) ? (((esc_sect_cnt_reg_n_0__16_e0e6bd3) ? (((p_0_in_0[15]) ? (((esc_sect_cnt_reg_n_0__15_baa501c) ? (((esc_sect_cnt_reg_n_0__17_60004ee) ? (p_0_in_0[17]) : (~(p_0_in_0[17])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__15_baa501c) ? (1'b0) : (((esc_sect_cnt_reg_n_0__17_60004ee) ? (p_0_in_0[17]) : (~(p_0_in_0[17])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__16_e0e6bd3) ? (1'b0) : (((p_0_in_0[15]) ? (((esc_sect_cnt_reg_n_0__15_baa501c) ? (((esc_sect_cnt_reg_n_0__17_60004ee) ? (p_0_in_0[17]) : (~(p_0_in_0[17])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__15_baa501c) ? (1'b0) : (((esc_sect_cnt_reg_n_0__17_60004ee) ? (p_0_in_0[17]) : (~(p_0_in_0[17])))))))))));

  // Reconstructed LUT6: first_sect_carry__0_i_4__0
  assign first_sect_carry__0_i_4__0_n_0 = ((p_0_in_0[13]) ? (((esc_sect_cnt_reg_n_0__13_f728c1e) ? (((p_0_in_0[12]) ? (((esc_sect_cnt_reg_n_0__12_b408e9b) ? (((esc_sect_cnt_reg_n_0__14_3816884) ? (p_0_in_0[14]) : (~(p_0_in_0[14])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__12_b408e9b) ? (1'b0) : (((esc_sect_cnt_reg_n_0__14_3816884) ? (p_0_in_0[14]) : (~(p_0_in_0[14])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__13_f728c1e) ? (1'b0) : (((p_0_in_0[12]) ? (((esc_sect_cnt_reg_n_0__12_b408e9b) ? (((esc_sect_cnt_reg_n_0__14_3816884) ? (p_0_in_0[14]) : (~(p_0_in_0[14])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__12_b408e9b) ? (1'b0) : (((esc_sect_cnt_reg_n_0__14_3816884) ? (p_0_in_0[14]) : (~(p_0_in_0[14])))))))))));

  // Reconstructed CARRY4: first_sect_carry__1
  wire [3:0] recovered_352_co, recovered_352_o, recovered_352_s, recovered_352_di;
  assign recovered_352_s = {first_sect_carry__1_i_1__0_n_0,first_sect_carry__1_i_2__0_n_0,first_sect_carry__1_i_3__0_n_0,first_sect_carry__1_i_4__0_n_0};
  assign recovered_352_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_352_ci = ((first_sect_carry__0_n_0) !== 1'bz) && (first_sect_carry__0_n_0);
  wire recovered_352_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_352_o[0] = recovered_352_s[0] ^ (recovered_352_ci || recovered_352_cy);
  assign recovered_352_co[0] = (recovered_352_s[0] & (recovered_352_ci || recovered_352_cy)) | (~recovered_352_s[0] & recovered_352_di[0]);
  assign recovered_352_o[1] = recovered_352_s[1] ^ recovered_352_co[0];
  assign recovered_352_co[1] = (recovered_352_s[1] & recovered_352_co[0]) | (~recovered_352_s[1] & recovered_352_di[1]);
  assign recovered_352_o[2] = recovered_352_s[2] ^ recovered_352_co[1];
  assign recovered_352_co[2] = (recovered_352_s[2] & recovered_352_co[1]) | (~recovered_352_s[2] & recovered_352_di[2]);
  assign recovered_352_o[3] = recovered_352_s[3] ^ recovered_352_co[2];
  assign recovered_352_co[3] = (recovered_352_s[3] & recovered_352_co[2]) | (~recovered_352_s[3] & recovered_352_di[3]);
  assign {first_sect_carry__1_n_0,NLW_first_sect_carry__1_CO_UNCONNECTED[2:0]} = recovered_352_co;

  // Reconstructed LUT6: first_sect_carry__1_i_1__0
  assign first_sect_carry__1_i_1__0_n_0 = ((p_0_in_0[34]) ? (((esc_sect_cnt_reg_n_0__34_3d99c4c) ? (((p_0_in_0[33]) ? (((esc_sect_cnt_reg_n_0__33_8cbf4a8) ? (((esc_sect_cnt_reg_n_0__35_5818df7) ? (p_0_in_0[35]) : (~(p_0_in_0[35])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__33_8cbf4a8) ? (1'b0) : (((esc_sect_cnt_reg_n_0__35_5818df7) ? (p_0_in_0[35]) : (~(p_0_in_0[35])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__34_3d99c4c) ? (1'b0) : (((p_0_in_0[33]) ? (((esc_sect_cnt_reg_n_0__33_8cbf4a8) ? (((esc_sect_cnt_reg_n_0__35_5818df7) ? (p_0_in_0[35]) : (~(p_0_in_0[35])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__33_8cbf4a8) ? (1'b0) : (((esc_sect_cnt_reg_n_0__35_5818df7) ? (p_0_in_0[35]) : (~(p_0_in_0[35])))))))))));

  // Reconstructed LUT6: first_sect_carry__1_i_2__0
  assign first_sect_carry__1_i_2__0_n_0 = ((p_0_in_0[31]) ? (((esc_sect_cnt_reg_n_0__31_0c2dac2) ? (((p_0_in_0[30]) ? (((esc_sect_cnt_reg_n_0__30_38a695a) ? (((esc_sect_cnt_reg_n_0__32_e54430d) ? (p_0_in_0[32]) : (~(p_0_in_0[32])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__30_38a695a) ? (1'b0) : (((esc_sect_cnt_reg_n_0__32_e54430d) ? (p_0_in_0[32]) : (~(p_0_in_0[32])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__31_0c2dac2) ? (1'b0) : (((p_0_in_0[30]) ? (((esc_sect_cnt_reg_n_0__30_38a695a) ? (((esc_sect_cnt_reg_n_0__32_e54430d) ? (p_0_in_0[32]) : (~(p_0_in_0[32])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__30_38a695a) ? (1'b0) : (((esc_sect_cnt_reg_n_0__32_e54430d) ? (p_0_in_0[32]) : (~(p_0_in_0[32])))))))))));

  // Reconstructed LUT6: first_sect_carry__1_i_3__0
  assign first_sect_carry__1_i_3__0_n_0 = ((p_0_in_0[28]) ? (((esc_sect_cnt_reg_n_0__28_78b1845) ? (((p_0_in_0[27]) ? (((esc_sect_cnt_reg_n_0__27_131810a) ? (((esc_sect_cnt_reg_n_0__29_2ed533d) ? (p_0_in_0[29]) : (~(p_0_in_0[29])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__27_131810a) ? (1'b0) : (((esc_sect_cnt_reg_n_0__29_2ed533d) ? (p_0_in_0[29]) : (~(p_0_in_0[29])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__28_78b1845) ? (1'b0) : (((p_0_in_0[27]) ? (((esc_sect_cnt_reg_n_0__27_131810a) ? (((esc_sect_cnt_reg_n_0__29_2ed533d) ? (p_0_in_0[29]) : (~(p_0_in_0[29])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__27_131810a) ? (1'b0) : (((esc_sect_cnt_reg_n_0__29_2ed533d) ? (p_0_in_0[29]) : (~(p_0_in_0[29])))))))))));

  // Reconstructed LUT6: first_sect_carry__1_i_4__0
  assign first_sect_carry__1_i_4__0_n_0 = ((esc_sect_cnt_reg_n_0__25_b6c1707) ? (((p_0_in_0[25]) ? (((p_0_in_0[24]) ? (((esc_sect_cnt_reg_n_0__24_f384316) ? (((p_0_in_0[26]) ? (esc_sect_cnt_reg_n_0__26_b4e21e4) : (~(esc_sect_cnt_reg_n_0__26_b4e21e4)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__24_f384316) ? (1'b0) : (((p_0_in_0[26]) ? (esc_sect_cnt_reg_n_0__26_b4e21e4) : (~(esc_sect_cnt_reg_n_0__26_b4e21e4)))))))) : (1'b0))) : (((p_0_in_0[25]) ? (1'b0) : (((p_0_in_0[24]) ? (((esc_sect_cnt_reg_n_0__24_f384316) ? (((p_0_in_0[26]) ? (esc_sect_cnt_reg_n_0__26_b4e21e4) : (~(esc_sect_cnt_reg_n_0__26_b4e21e4)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__24_f384316) ? (1'b0) : (((p_0_in_0[26]) ? (esc_sect_cnt_reg_n_0__26_b4e21e4) : (~(esc_sect_cnt_reg_n_0__26_b4e21e4)))))))))));

  // Reconstructed CARRY4: first_sect_carry__2
  wire [3:0] recovered_357_co, recovered_357_o, recovered_357_s, recovered_357_di;
  assign recovered_357_s = {first_sect_carry__2_i_1__0_n_0,first_sect_carry__2_i_2__0_n_0,first_sect_carry__2_i_3__0_n_0,first_sect_carry__2_i_4__0_n_0};
  assign recovered_357_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_357_ci = ((first_sect_carry__1_n_0) !== 1'bz) && (first_sect_carry__1_n_0);
  wire recovered_357_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_357_o[0] = recovered_357_s[0] ^ (recovered_357_ci || recovered_357_cy);
  assign recovered_357_co[0] = (recovered_357_s[0] & (recovered_357_ci || recovered_357_cy)) | (~recovered_357_s[0] & recovered_357_di[0]);
  assign recovered_357_o[1] = recovered_357_s[1] ^ recovered_357_co[0];
  assign recovered_357_co[1] = (recovered_357_s[1] & recovered_357_co[0]) | (~recovered_357_s[1] & recovered_357_di[1]);
  assign recovered_357_o[2] = recovered_357_s[2] ^ recovered_357_co[1];
  assign recovered_357_co[2] = (recovered_357_s[2] & recovered_357_co[1]) | (~recovered_357_s[2] & recovered_357_di[2]);
  assign recovered_357_o[3] = recovered_357_s[3] ^ recovered_357_co[2];
  assign recovered_357_co[3] = (recovered_357_s[3] & recovered_357_co[2]) | (~recovered_357_s[3] & recovered_357_di[3]);
  assign {first_sect_carry__2_n_0,NLW_first_sect_carry__2_CO_UNCONNECTED[2:0]} = recovered_357_co;

  // Reconstructed LUT6: first_sect_carry__2_i_1__0
  assign first_sect_carry__2_i_1__0_n_0 = ((p_0_in_0[46]) ? (((esc_sect_cnt_reg_n_0__46_bc6350d) ? (((p_0_in_0[45]) ? (((esc_sect_cnt_reg_n_0__45_028cd3e) ? (((esc_sect_cnt_reg_n_0__47_be2c9ea) ? (p_0_in_0[47]) : (~(p_0_in_0[47])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__45_028cd3e) ? (1'b0) : (((esc_sect_cnt_reg_n_0__47_be2c9ea) ? (p_0_in_0[47]) : (~(p_0_in_0[47])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__46_bc6350d) ? (1'b0) : (((p_0_in_0[45]) ? (((esc_sect_cnt_reg_n_0__45_028cd3e) ? (((esc_sect_cnt_reg_n_0__47_be2c9ea) ? (p_0_in_0[47]) : (~(p_0_in_0[47])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__45_028cd3e) ? (1'b0) : (((esc_sect_cnt_reg_n_0__47_be2c9ea) ? (p_0_in_0[47]) : (~(p_0_in_0[47])))))))))));

  // Reconstructed LUT6: first_sect_carry__2_i_2__0
  assign first_sect_carry__2_i_2__0_n_0 = ((p_0_in_0[43]) ? (((esc_sect_cnt_reg_n_0__43_b2f91b4) ? (((p_0_in_0[42]) ? (((esc_sect_cnt_reg_n_0__42_dc2ac0b) ? (((esc_sect_cnt_reg_n_0__44_ae87890) ? (p_0_in_0[44]) : (~(p_0_in_0[44])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__42_dc2ac0b) ? (1'b0) : (((esc_sect_cnt_reg_n_0__44_ae87890) ? (p_0_in_0[44]) : (~(p_0_in_0[44])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__43_b2f91b4) ? (1'b0) : (((p_0_in_0[42]) ? (((esc_sect_cnt_reg_n_0__42_dc2ac0b) ? (((esc_sect_cnt_reg_n_0__44_ae87890) ? (p_0_in_0[44]) : (~(p_0_in_0[44])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__42_dc2ac0b) ? (1'b0) : (((esc_sect_cnt_reg_n_0__44_ae87890) ? (p_0_in_0[44]) : (~(p_0_in_0[44])))))))))));

  // Reconstructed LUT6: first_sect_carry__2_i_3__0
  assign first_sect_carry__2_i_3__0_n_0 = ((p_0_in_0[39]) ? (((esc_sect_cnt_reg_n_0__39_1a62409) ? (((p_0_in_0[41]) ? (((esc_sect_cnt_reg_n_0__41_827f3d3) ? (((esc_sect_cnt_reg_n_0__40_c7f7402) ? (p_0_in_0[40]) : (~(p_0_in_0[40])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__41_827f3d3) ? (1'b0) : (((esc_sect_cnt_reg_n_0__40_c7f7402) ? (p_0_in_0[40]) : (~(p_0_in_0[40])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__39_1a62409) ? (1'b0) : (((p_0_in_0[41]) ? (((esc_sect_cnt_reg_n_0__41_827f3d3) ? (((esc_sect_cnt_reg_n_0__40_c7f7402) ? (p_0_in_0[40]) : (~(p_0_in_0[40])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__41_827f3d3) ? (1'b0) : (((esc_sect_cnt_reg_n_0__40_c7f7402) ? (p_0_in_0[40]) : (~(p_0_in_0[40])))))))))));

  // Reconstructed LUT6: first_sect_carry__2_i_4__0
  assign first_sect_carry__2_i_4__0_n_0 = ((esc_sect_cnt_reg_n_0__37_b1ebede) ? (((p_0_in_0[37]) ? (((p_0_in_0[36]) ? (((esc_sect_cnt_reg_n_0__36_b6ea0ad) ? (((p_0_in_0[38]) ? (esc_sect_cnt_reg_n_0__38_d27d0e3) : (~(esc_sect_cnt_reg_n_0__38_d27d0e3)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__36_b6ea0ad) ? (1'b0) : (((p_0_in_0[38]) ? (esc_sect_cnt_reg_n_0__38_d27d0e3) : (~(esc_sect_cnt_reg_n_0__38_d27d0e3)))))))) : (1'b0))) : (((p_0_in_0[37]) ? (1'b0) : (((p_0_in_0[36]) ? (((esc_sect_cnt_reg_n_0__36_b6ea0ad) ? (((p_0_in_0[38]) ? (esc_sect_cnt_reg_n_0__38_d27d0e3) : (~(esc_sect_cnt_reg_n_0__38_d27d0e3)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__36_b6ea0ad) ? (1'b0) : (((p_0_in_0[38]) ? (esc_sect_cnt_reg_n_0__38_d27d0e3) : (~(esc_sect_cnt_reg_n_0__38_d27d0e3)))))))))));

  // Reconstructed CARRY4: first_sect_carry__3
  wire [3:0] recovered_362_co, recovered_362_o, recovered_362_s, recovered_362_di;
  assign recovered_362_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,first_sect_carry__3_i_1__0_n_0,first_sect_carry__3_i_2__0_n_0};
  assign recovered_362_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_362_ci = ((first_sect_carry__2_n_0) !== 1'bz) && (first_sect_carry__2_n_0);
  wire recovered_362_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_362_o[0] = recovered_362_s[0] ^ (recovered_362_ci || recovered_362_cy);
  assign recovered_362_co[0] = (recovered_362_s[0] & (recovered_362_ci || recovered_362_cy)) | (~recovered_362_s[0] & recovered_362_di[0]);
  assign recovered_362_o[1] = recovered_362_s[1] ^ recovered_362_co[0];
  assign recovered_362_co[1] = (recovered_362_s[1] & recovered_362_co[0]) | (~recovered_362_s[1] & recovered_362_di[1]);
  assign recovered_362_o[2] = recovered_362_s[2] ^ recovered_362_co[1];
  assign recovered_362_co[2] = (recovered_362_s[2] & recovered_362_co[1]) | (~recovered_362_s[2] & recovered_362_di[2]);
  assign recovered_362_o[3] = recovered_362_s[3] ^ recovered_362_co[2];
  assign recovered_362_co[3] = (recovered_362_s[3] & recovered_362_co[2]) | (~recovered_362_s[3] & recovered_362_di[3]);
  assign {first_sect,NLW_first_sect_carry__3_CO_UNCONNECTED[0]} = recovered_362_co;

  // Reconstructed LUT2: first_sect_carry__3_i_1__0
  assign first_sect_carry__3_i_1__0_n_0 = ((esc_sect_cnt_reg_n_0__51_b4f8fa6) ? (p_0_in_0[51]) : (~(p_0_in_0[51])));

  // Reconstructed LUT6: first_sect_carry__3_i_2__0
  assign first_sect_carry__3_i_2__0_n_0 = ((p_0_in_0[49]) ? (((esc_sect_cnt_reg_n_0__49_ac3ce58) ? (((p_0_in_0[48]) ? (((esc_sect_cnt_reg_n_0__48_c5dc410) ? (((esc_sect_cnt_reg_n_0__50_aee544d) ? (p_0_in_0[50]) : (~(p_0_in_0[50])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__48_c5dc410) ? (1'b0) : (((esc_sect_cnt_reg_n_0__50_aee544d) ? (p_0_in_0[50]) : (~(p_0_in_0[50])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__49_ac3ce58) ? (1'b0) : (((p_0_in_0[48]) ? (((esc_sect_cnt_reg_n_0__48_c5dc410) ? (((esc_sect_cnt_reg_n_0__50_aee544d) ? (p_0_in_0[50]) : (~(p_0_in_0[50])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__48_c5dc410) ? (1'b0) : (((esc_sect_cnt_reg_n_0__50_aee544d) ? (p_0_in_0[50]) : (~(p_0_in_0[50])))))))))));

  // Reconstructed LUT6: first_sect_carry_i_1__0
  assign first_sect_carry_i_1__0_n_0 = ((esc_sect_cnt_reg_n_0__10_8129e9e) ? (((p_0_in_0[10]) ? (((p_0_in_0[9]) ? (((esc_sect_cnt_reg_n_0__9_46ce72e) ? (((p_0_in_0[11]) ? (esc_sect_cnt_reg_n_0__11_2134eea) : (~(esc_sect_cnt_reg_n_0__11_2134eea)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__9_46ce72e) ? (1'b0) : (((p_0_in_0[11]) ? (esc_sect_cnt_reg_n_0__11_2134eea) : (~(esc_sect_cnt_reg_n_0__11_2134eea)))))))) : (1'b0))) : (((p_0_in_0[10]) ? (1'b0) : (((p_0_in_0[9]) ? (((esc_sect_cnt_reg_n_0__9_46ce72e) ? (((p_0_in_0[11]) ? (esc_sect_cnt_reg_n_0__11_2134eea) : (~(esc_sect_cnt_reg_n_0__11_2134eea)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__9_46ce72e) ? (1'b0) : (((p_0_in_0[11]) ? (esc_sect_cnt_reg_n_0__11_2134eea) : (~(esc_sect_cnt_reg_n_0__11_2134eea)))))))))));

  // Reconstructed LUT6: first_sect_carry_i_2__0
  assign first_sect_carry_i_2__0_n_0 = ((esc_sect_cnt_reg_n_0__7_5d37ab6) ? (((p_0_in_0[7]) ? (((p_0_in_0[6]) ? (((esc_sect_cnt_reg_n_0__6_8f7c601) ? (((p_0_in_0[8]) ? (esc_sect_cnt_reg_n_0__8_9af08b3) : (~(esc_sect_cnt_reg_n_0__8_9af08b3)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__6_8f7c601) ? (1'b0) : (((p_0_in_0[8]) ? (esc_sect_cnt_reg_n_0__8_9af08b3) : (~(esc_sect_cnt_reg_n_0__8_9af08b3)))))))) : (1'b0))) : (((p_0_in_0[7]) ? (1'b0) : (((p_0_in_0[6]) ? (((esc_sect_cnt_reg_n_0__6_8f7c601) ? (((p_0_in_0[8]) ? (esc_sect_cnt_reg_n_0__8_9af08b3) : (~(esc_sect_cnt_reg_n_0__8_9af08b3)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__6_8f7c601) ? (1'b0) : (((p_0_in_0[8]) ? (esc_sect_cnt_reg_n_0__8_9af08b3) : (~(esc_sect_cnt_reg_n_0__8_9af08b3)))))))))));

  // Reconstructed LUT6: first_sect_carry_i_3__0
  assign first_sect_carry_i_3__0_n_0 = ((esc_sect_cnt_reg_n_0__4_2216bae) ? (((p_0_in_0[4]) ? (((p_0_in_0[3]) ? (((esc_sect_cnt_reg_n_0__3_e4b1820) ? (((p_0_in_0[5]) ? (esc_sect_cnt_reg_n_0__5_5ca388c) : (~(esc_sect_cnt_reg_n_0__5_5ca388c)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__3_e4b1820) ? (1'b0) : (((p_0_in_0[5]) ? (esc_sect_cnt_reg_n_0__5_5ca388c) : (~(esc_sect_cnt_reg_n_0__5_5ca388c)))))))) : (1'b0))) : (((p_0_in_0[4]) ? (1'b0) : (((p_0_in_0[3]) ? (((esc_sect_cnt_reg_n_0__3_e4b1820) ? (((p_0_in_0[5]) ? (esc_sect_cnt_reg_n_0__5_5ca388c) : (~(esc_sect_cnt_reg_n_0__5_5ca388c)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__3_e4b1820) ? (1'b0) : (((p_0_in_0[5]) ? (esc_sect_cnt_reg_n_0__5_5ca388c) : (~(esc_sect_cnt_reg_n_0__5_5ca388c)))))))))));

  // Reconstructed LUT6: first_sect_carry_i_4__0
  assign first_sect_carry_i_4__0_n_0 = ((p_0_in_0[1]) ? (((esc_sect_cnt_reg_n_0__1_6d680f9) ? (((p_0_in_0[0]) ? (((esc_sect_cnt_reg_n_0__0_cf5038d) ? (((esc_sect_cnt_reg_n_0__2_15d4d8f) ? (p_0_in_0[2]) : (~(p_0_in_0[2])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__0_cf5038d) ? (1'b0) : (((esc_sect_cnt_reg_n_0__2_15d4d8f) ? (p_0_in_0[2]) : (~(p_0_in_0[2])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__1_6d680f9) ? (1'b0) : (((p_0_in_0[0]) ? (((esc_sect_cnt_reg_n_0__0_cf5038d) ? (((esc_sect_cnt_reg_n_0__2_15d4d8f) ? (p_0_in_0[2]) : (~(p_0_in_0[2])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__0_cf5038d) ? (1'b0) : (((esc_sect_cnt_reg_n_0__2_15d4d8f) ? (p_0_in_0[2]) : (~(p_0_in_0[2])))))))))));

  // Reconstructed FDRE: invalid_len_event_reg
  reg recovered_369_q = 1'b0;
  assign invalid_len_event = recovered_369_q;
  wire recovered_369_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_369_reset || (((SR) === 1'bx) && (recovered_369_q == 1'b0))) recovered_369_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_369_q == (fifo_wreq_n_69)))) recovered_369_q <= (fifo_wreq_n_69);
  end

  // Reconstructed FDRE: invalid_len_event_reg1_reg
  reg recovered_370_q = 1'b0;
  assign invalid_len_event_reg1 = recovered_370_q;
  wire recovered_370_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_370_reset || (((SR) === 1'bx) && (recovered_370_q == 1'b0))) recovered_370_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_370_q == (invalid_len_event)))) recovered_370_q <= (invalid_len_event);
  end

  // Reconstructed FDRE: invalid_len_event_reg2_reg
  reg recovered_371_q = 1'b0;
  assign invalid_len_event_reg2 = recovered_371_q;
  wire recovered_371_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_371_reset || (((SR) === 1'bx) && (recovered_371_q == 1'b0))) recovered_371_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_371_q == (invalid_len_event_reg1)))) recovered_371_q <= (invalid_len_event_reg1);
  end

  // Reconstructed CARRY4: last_sect_carry
  wire [3:0] recovered_372_co, recovered_372_o, recovered_372_s, recovered_372_di;
  assign recovered_372_s = {last_sect_carry_i_1__0_n_0,last_sect_carry_i_2__0_n_0,last_sect_carry_i_3__0_n_0,last_sect_carry_i_4__0_n_0};
  assign recovered_372_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_372_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_372_cy = ((esc_const1_c064970) !== 1'bz) && (esc_const1_c064970);
  assign recovered_372_o[0] = recovered_372_s[0] ^ (recovered_372_ci || recovered_372_cy);
  assign recovered_372_co[0] = (recovered_372_s[0] & (recovered_372_ci || recovered_372_cy)) | (~recovered_372_s[0] & recovered_372_di[0]);
  assign recovered_372_o[1] = recovered_372_s[1] ^ recovered_372_co[0];
  assign recovered_372_co[1] = (recovered_372_s[1] & recovered_372_co[0]) | (~recovered_372_s[1] & recovered_372_di[1]);
  assign recovered_372_o[2] = recovered_372_s[2] ^ recovered_372_co[1];
  assign recovered_372_co[2] = (recovered_372_s[2] & recovered_372_co[1]) | (~recovered_372_s[2] & recovered_372_di[2]);
  assign recovered_372_o[3] = recovered_372_s[3] ^ recovered_372_co[2];
  assign recovered_372_co[3] = (recovered_372_s[3] & recovered_372_co[2]) | (~recovered_372_s[3] & recovered_372_di[3]);
  assign {last_sect_carry_n_0,NLW_last_sect_carry_CO_UNCONNECTED[2:0]} = recovered_372_co;

  // Reconstructed CARRY4: last_sect_carry__0
  wire [3:0] recovered_373_co, recovered_373_o, recovered_373_s, recovered_373_di;
  assign recovered_373_s = {last_sect_carry__0_i_1__0_n_0,last_sect_carry__0_i_2__0_n_0,last_sect_carry__0_i_3__0_n_0,last_sect_carry__0_i_4__0_n_0};
  assign recovered_373_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_373_ci = ((last_sect_carry_n_0) !== 1'bz) && (last_sect_carry_n_0);
  wire recovered_373_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_373_o[0] = recovered_373_s[0] ^ (recovered_373_ci || recovered_373_cy);
  assign recovered_373_co[0] = (recovered_373_s[0] & (recovered_373_ci || recovered_373_cy)) | (~recovered_373_s[0] & recovered_373_di[0]);
  assign recovered_373_o[1] = recovered_373_s[1] ^ recovered_373_co[0];
  assign recovered_373_co[1] = (recovered_373_s[1] & recovered_373_co[0]) | (~recovered_373_s[1] & recovered_373_di[1]);
  assign recovered_373_o[2] = recovered_373_s[2] ^ recovered_373_co[1];
  assign recovered_373_co[2] = (recovered_373_s[2] & recovered_373_co[1]) | (~recovered_373_s[2] & recovered_373_di[2]);
  assign recovered_373_o[3] = recovered_373_s[3] ^ recovered_373_co[2];
  assign recovered_373_co[3] = (recovered_373_s[3] & recovered_373_co[2]) | (~recovered_373_s[3] & recovered_373_di[3]);
  assign {last_sect_carry__0_n_0,NLW_last_sect_carry__0_CO_UNCONNECTED[2:0]} = recovered_373_co;

  // Reconstructed LUT6: last_sect_carry__0_i_1__0
  assign last_sect_carry__0_i_1__0_n_0 = ((p_0_in0_in[22]) ? (((esc_sect_cnt_reg_n_0__22_fc0a11f) ? (((p_0_in0_in[21]) ? (((esc_sect_cnt_reg_n_0__21_2affd71) ? (((esc_sect_cnt_reg_n_0__23_b356fba) ? (p_0_in0_in[23]) : (~(p_0_in0_in[23])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__21_2affd71) ? (1'b0) : (((esc_sect_cnt_reg_n_0__23_b356fba) ? (p_0_in0_in[23]) : (~(p_0_in0_in[23])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__22_fc0a11f) ? (1'b0) : (((p_0_in0_in[21]) ? (((esc_sect_cnt_reg_n_0__21_2affd71) ? (((esc_sect_cnt_reg_n_0__23_b356fba) ? (p_0_in0_in[23]) : (~(p_0_in0_in[23])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__21_2affd71) ? (1'b0) : (((esc_sect_cnt_reg_n_0__23_b356fba) ? (p_0_in0_in[23]) : (~(p_0_in0_in[23])))))))))));

  // Reconstructed LUT6: last_sect_carry__0_i_2__0
  assign last_sect_carry__0_i_2__0_n_0 = ((p_0_in0_in[19]) ? (((esc_sect_cnt_reg_n_0__19_d3501e6) ? (((p_0_in0_in[18]) ? (((esc_sect_cnt_reg_n_0__18_2b2ad13) ? (((esc_sect_cnt_reg_n_0__20_44e2780) ? (p_0_in0_in[20]) : (~(p_0_in0_in[20])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__18_2b2ad13) ? (1'b0) : (((esc_sect_cnt_reg_n_0__20_44e2780) ? (p_0_in0_in[20]) : (~(p_0_in0_in[20])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__19_d3501e6) ? (1'b0) : (((p_0_in0_in[18]) ? (((esc_sect_cnt_reg_n_0__18_2b2ad13) ? (((esc_sect_cnt_reg_n_0__20_44e2780) ? (p_0_in0_in[20]) : (~(p_0_in0_in[20])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__18_2b2ad13) ? (1'b0) : (((esc_sect_cnt_reg_n_0__20_44e2780) ? (p_0_in0_in[20]) : (~(p_0_in0_in[20])))))))))));

  // Reconstructed LUT6: last_sect_carry__0_i_3__0
  assign last_sect_carry__0_i_3__0_n_0 = ((p_0_in0_in[16]) ? (((esc_sect_cnt_reg_n_0__16_e0e6bd3) ? (((p_0_in0_in[15]) ? (((esc_sect_cnt_reg_n_0__15_baa501c) ? (((esc_sect_cnt_reg_n_0__17_60004ee) ? (p_0_in0_in[17]) : (~(p_0_in0_in[17])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__15_baa501c) ? (1'b0) : (((esc_sect_cnt_reg_n_0__17_60004ee) ? (p_0_in0_in[17]) : (~(p_0_in0_in[17])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__16_e0e6bd3) ? (1'b0) : (((p_0_in0_in[15]) ? (((esc_sect_cnt_reg_n_0__15_baa501c) ? (((esc_sect_cnt_reg_n_0__17_60004ee) ? (p_0_in0_in[17]) : (~(p_0_in0_in[17])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__15_baa501c) ? (1'b0) : (((esc_sect_cnt_reg_n_0__17_60004ee) ? (p_0_in0_in[17]) : (~(p_0_in0_in[17])))))))))));

  // Reconstructed LUT6: last_sect_carry__0_i_4__0
  assign last_sect_carry__0_i_4__0_n_0 = ((p_0_in0_in[13]) ? (((esc_sect_cnt_reg_n_0__13_f728c1e) ? (((p_0_in0_in[12]) ? (((esc_sect_cnt_reg_n_0__12_b408e9b) ? (((esc_sect_cnt_reg_n_0__14_3816884) ? (p_0_in0_in[14]) : (~(p_0_in0_in[14])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__12_b408e9b) ? (1'b0) : (((esc_sect_cnt_reg_n_0__14_3816884) ? (p_0_in0_in[14]) : (~(p_0_in0_in[14])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__13_f728c1e) ? (1'b0) : (((p_0_in0_in[12]) ? (((esc_sect_cnt_reg_n_0__12_b408e9b) ? (((esc_sect_cnt_reg_n_0__14_3816884) ? (p_0_in0_in[14]) : (~(p_0_in0_in[14])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__12_b408e9b) ? (1'b0) : (((esc_sect_cnt_reg_n_0__14_3816884) ? (p_0_in0_in[14]) : (~(p_0_in0_in[14])))))))))));

  // Reconstructed CARRY4: last_sect_carry__1
  wire [3:0] recovered_378_co, recovered_378_o, recovered_378_s, recovered_378_di;
  assign recovered_378_s = {last_sect_carry__1_i_1__0_n_0,last_sect_carry__1_i_2__0_n_0,last_sect_carry__1_i_3__0_n_0,last_sect_carry__1_i_4__0_n_0};
  assign recovered_378_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_378_ci = ((last_sect_carry__0_n_0) !== 1'bz) && (last_sect_carry__0_n_0);
  wire recovered_378_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_378_o[0] = recovered_378_s[0] ^ (recovered_378_ci || recovered_378_cy);
  assign recovered_378_co[0] = (recovered_378_s[0] & (recovered_378_ci || recovered_378_cy)) | (~recovered_378_s[0] & recovered_378_di[0]);
  assign recovered_378_o[1] = recovered_378_s[1] ^ recovered_378_co[0];
  assign recovered_378_co[1] = (recovered_378_s[1] & recovered_378_co[0]) | (~recovered_378_s[1] & recovered_378_di[1]);
  assign recovered_378_o[2] = recovered_378_s[2] ^ recovered_378_co[1];
  assign recovered_378_co[2] = (recovered_378_s[2] & recovered_378_co[1]) | (~recovered_378_s[2] & recovered_378_di[2]);
  assign recovered_378_o[3] = recovered_378_s[3] ^ recovered_378_co[2];
  assign recovered_378_co[3] = (recovered_378_s[3] & recovered_378_co[2]) | (~recovered_378_s[3] & recovered_378_di[3]);
  assign {last_sect_carry__1_n_0,NLW_last_sect_carry__1_CO_UNCONNECTED[2:0]} = recovered_378_co;

  // Reconstructed LUT6: last_sect_carry__1_i_1__0
  assign last_sect_carry__1_i_1__0_n_0 = ((p_0_in0_in[34]) ? (((esc_sect_cnt_reg_n_0__34_3d99c4c) ? (((p_0_in0_in[33]) ? (((esc_sect_cnt_reg_n_0__33_8cbf4a8) ? (((esc_sect_cnt_reg_n_0__35_5818df7) ? (p_0_in0_in[35]) : (~(p_0_in0_in[35])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__33_8cbf4a8) ? (1'b0) : (((esc_sect_cnt_reg_n_0__35_5818df7) ? (p_0_in0_in[35]) : (~(p_0_in0_in[35])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__34_3d99c4c) ? (1'b0) : (((p_0_in0_in[33]) ? (((esc_sect_cnt_reg_n_0__33_8cbf4a8) ? (((esc_sect_cnt_reg_n_0__35_5818df7) ? (p_0_in0_in[35]) : (~(p_0_in0_in[35])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__33_8cbf4a8) ? (1'b0) : (((esc_sect_cnt_reg_n_0__35_5818df7) ? (p_0_in0_in[35]) : (~(p_0_in0_in[35])))))))))));

  // Reconstructed LUT6: last_sect_carry__1_i_2__0
  assign last_sect_carry__1_i_2__0_n_0 = ((p_0_in0_in[31]) ? (((esc_sect_cnt_reg_n_0__31_0c2dac2) ? (((p_0_in0_in[30]) ? (((esc_sect_cnt_reg_n_0__30_38a695a) ? (((esc_sect_cnt_reg_n_0__32_e54430d) ? (p_0_in0_in[32]) : (~(p_0_in0_in[32])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__30_38a695a) ? (1'b0) : (((esc_sect_cnt_reg_n_0__32_e54430d) ? (p_0_in0_in[32]) : (~(p_0_in0_in[32])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__31_0c2dac2) ? (1'b0) : (((p_0_in0_in[30]) ? (((esc_sect_cnt_reg_n_0__30_38a695a) ? (((esc_sect_cnt_reg_n_0__32_e54430d) ? (p_0_in0_in[32]) : (~(p_0_in0_in[32])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__30_38a695a) ? (1'b0) : (((esc_sect_cnt_reg_n_0__32_e54430d) ? (p_0_in0_in[32]) : (~(p_0_in0_in[32])))))))))));

  // Reconstructed LUT6: last_sect_carry__1_i_3__0
  assign last_sect_carry__1_i_3__0_n_0 = ((p_0_in0_in[28]) ? (((esc_sect_cnt_reg_n_0__28_78b1845) ? (((p_0_in0_in[27]) ? (((esc_sect_cnt_reg_n_0__27_131810a) ? (((esc_sect_cnt_reg_n_0__29_2ed533d) ? (p_0_in0_in[29]) : (~(p_0_in0_in[29])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__27_131810a) ? (1'b0) : (((esc_sect_cnt_reg_n_0__29_2ed533d) ? (p_0_in0_in[29]) : (~(p_0_in0_in[29])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__28_78b1845) ? (1'b0) : (((p_0_in0_in[27]) ? (((esc_sect_cnt_reg_n_0__27_131810a) ? (((esc_sect_cnt_reg_n_0__29_2ed533d) ? (p_0_in0_in[29]) : (~(p_0_in0_in[29])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__27_131810a) ? (1'b0) : (((esc_sect_cnt_reg_n_0__29_2ed533d) ? (p_0_in0_in[29]) : (~(p_0_in0_in[29])))))))))));

  // Reconstructed LUT6: last_sect_carry__1_i_4__0
  assign last_sect_carry__1_i_4__0_n_0 = ((esc_sect_cnt_reg_n_0__26_b4e21e4) ? (((p_0_in0_in[26]) ? (((p_0_in0_in[24]) ? (((esc_sect_cnt_reg_n_0__24_f384316) ? (((p_0_in0_in[25]) ? (esc_sect_cnt_reg_n_0__25_b6c1707) : (~(esc_sect_cnt_reg_n_0__25_b6c1707)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__24_f384316) ? (1'b0) : (((p_0_in0_in[25]) ? (esc_sect_cnt_reg_n_0__25_b6c1707) : (~(esc_sect_cnt_reg_n_0__25_b6c1707)))))))) : (1'b0))) : (((p_0_in0_in[26]) ? (1'b0) : (((p_0_in0_in[24]) ? (((esc_sect_cnt_reg_n_0__24_f384316) ? (((p_0_in0_in[25]) ? (esc_sect_cnt_reg_n_0__25_b6c1707) : (~(esc_sect_cnt_reg_n_0__25_b6c1707)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__24_f384316) ? (1'b0) : (((p_0_in0_in[25]) ? (esc_sect_cnt_reg_n_0__25_b6c1707) : (~(esc_sect_cnt_reg_n_0__25_b6c1707)))))))))));

  // Reconstructed CARRY4: last_sect_carry__2
  wire [3:0] recovered_383_co, recovered_383_o, recovered_383_s, recovered_383_di;
  assign recovered_383_s = {last_sect_carry__2_i_1__0_n_0,last_sect_carry__2_i_2__0_n_0,last_sect_carry__2_i_3__0_n_0,last_sect_carry__2_i_4__0_n_0};
  assign recovered_383_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_383_ci = ((last_sect_carry__1_n_0) !== 1'bz) && (last_sect_carry__1_n_0);
  wire recovered_383_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_383_o[0] = recovered_383_s[0] ^ (recovered_383_ci || recovered_383_cy);
  assign recovered_383_co[0] = (recovered_383_s[0] & (recovered_383_ci || recovered_383_cy)) | (~recovered_383_s[0] & recovered_383_di[0]);
  assign recovered_383_o[1] = recovered_383_s[1] ^ recovered_383_co[0];
  assign recovered_383_co[1] = (recovered_383_s[1] & recovered_383_co[0]) | (~recovered_383_s[1] & recovered_383_di[1]);
  assign recovered_383_o[2] = recovered_383_s[2] ^ recovered_383_co[1];
  assign recovered_383_co[2] = (recovered_383_s[2] & recovered_383_co[1]) | (~recovered_383_s[2] & recovered_383_di[2]);
  assign recovered_383_o[3] = recovered_383_s[3] ^ recovered_383_co[2];
  assign recovered_383_co[3] = (recovered_383_s[3] & recovered_383_co[2]) | (~recovered_383_s[3] & recovered_383_di[3]);
  assign {last_sect_carry__2_n_0,NLW_last_sect_carry__2_CO_UNCONNECTED[2:0]} = recovered_383_co;

  // Reconstructed LUT6: last_sect_carry__2_i_1__0
  assign last_sect_carry__2_i_1__0_n_0 = ((p_0_in0_in[46]) ? (((esc_sect_cnt_reg_n_0__46_bc6350d) ? (((p_0_in0_in[45]) ? (((esc_sect_cnt_reg_n_0__45_028cd3e) ? (((esc_sect_cnt_reg_n_0__47_be2c9ea) ? (p_0_in0_in[47]) : (~(p_0_in0_in[47])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__45_028cd3e) ? (1'b0) : (((esc_sect_cnt_reg_n_0__47_be2c9ea) ? (p_0_in0_in[47]) : (~(p_0_in0_in[47])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__46_bc6350d) ? (1'b0) : (((p_0_in0_in[45]) ? (((esc_sect_cnt_reg_n_0__45_028cd3e) ? (((esc_sect_cnt_reg_n_0__47_be2c9ea) ? (p_0_in0_in[47]) : (~(p_0_in0_in[47])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__45_028cd3e) ? (1'b0) : (((esc_sect_cnt_reg_n_0__47_be2c9ea) ? (p_0_in0_in[47]) : (~(p_0_in0_in[47])))))))))));

  // Reconstructed LUT6: last_sect_carry__2_i_2__0
  assign last_sect_carry__2_i_2__0_n_0 = ((p_0_in0_in[42]) ? (((esc_sect_cnt_reg_n_0__42_dc2ac0b) ? (((p_0_in0_in[43]) ? (((esc_sect_cnt_reg_n_0__43_b2f91b4) ? (((esc_sect_cnt_reg_n_0__44_ae87890) ? (p_0_in0_in[44]) : (~(p_0_in0_in[44])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__43_b2f91b4) ? (1'b0) : (((esc_sect_cnt_reg_n_0__44_ae87890) ? (p_0_in0_in[44]) : (~(p_0_in0_in[44])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__42_dc2ac0b) ? (1'b0) : (((p_0_in0_in[43]) ? (((esc_sect_cnt_reg_n_0__43_b2f91b4) ? (((esc_sect_cnt_reg_n_0__44_ae87890) ? (p_0_in0_in[44]) : (~(p_0_in0_in[44])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__43_b2f91b4) ? (1'b0) : (((esc_sect_cnt_reg_n_0__44_ae87890) ? (p_0_in0_in[44]) : (~(p_0_in0_in[44])))))))))));

  // Reconstructed LUT6: last_sect_carry__2_i_3__0
  assign last_sect_carry__2_i_3__0_n_0 = ((p_0_in0_in[39]) ? (((esc_sect_cnt_reg_n_0__39_1a62409) ? (((p_0_in0_in[41]) ? (((esc_sect_cnt_reg_n_0__41_827f3d3) ? (((esc_sect_cnt_reg_n_0__40_c7f7402) ? (p_0_in0_in[40]) : (~(p_0_in0_in[40])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__41_827f3d3) ? (1'b0) : (((esc_sect_cnt_reg_n_0__40_c7f7402) ? (p_0_in0_in[40]) : (~(p_0_in0_in[40])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__39_1a62409) ? (1'b0) : (((p_0_in0_in[41]) ? (((esc_sect_cnt_reg_n_0__41_827f3d3) ? (((esc_sect_cnt_reg_n_0__40_c7f7402) ? (p_0_in0_in[40]) : (~(p_0_in0_in[40])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__41_827f3d3) ? (1'b0) : (((esc_sect_cnt_reg_n_0__40_c7f7402) ? (p_0_in0_in[40]) : (~(p_0_in0_in[40])))))))))));

  // Reconstructed LUT6: last_sect_carry__2_i_4__0
  assign last_sect_carry__2_i_4__0_n_0 = ((esc_sect_cnt_reg_n_0__38_d27d0e3) ? (((p_0_in0_in[38]) ? (((p_0_in0_in[37]) ? (((esc_sect_cnt_reg_n_0__37_b1ebede) ? (((p_0_in0_in[36]) ? (esc_sect_cnt_reg_n_0__36_b6ea0ad) : (~(esc_sect_cnt_reg_n_0__36_b6ea0ad)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__37_b1ebede) ? (1'b0) : (((p_0_in0_in[36]) ? (esc_sect_cnt_reg_n_0__36_b6ea0ad) : (~(esc_sect_cnt_reg_n_0__36_b6ea0ad)))))))) : (1'b0))) : (((p_0_in0_in[38]) ? (1'b0) : (((p_0_in0_in[37]) ? (((esc_sect_cnt_reg_n_0__37_b1ebede) ? (((p_0_in0_in[36]) ? (esc_sect_cnt_reg_n_0__36_b6ea0ad) : (~(esc_sect_cnt_reg_n_0__36_b6ea0ad)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__37_b1ebede) ? (1'b0) : (((p_0_in0_in[36]) ? (esc_sect_cnt_reg_n_0__36_b6ea0ad) : (~(esc_sect_cnt_reg_n_0__36_b6ea0ad)))))))))));

  // Reconstructed CARRY4: last_sect_carry__3
  wire [3:0] recovered_388_co, recovered_388_o, recovered_388_s, recovered_388_di;
  assign recovered_388_s = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,fifo_wreq_n_2,fifo_wreq_n_3};
  assign recovered_388_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_388_ci = ((last_sect_carry__2_n_0) !== 1'bz) && (last_sect_carry__2_n_0);
  wire recovered_388_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_388_o[0] = recovered_388_s[0] ^ (recovered_388_ci || recovered_388_cy);
  assign recovered_388_co[0] = (recovered_388_s[0] & (recovered_388_ci || recovered_388_cy)) | (~recovered_388_s[0] & recovered_388_di[0]);
  assign recovered_388_o[1] = recovered_388_s[1] ^ recovered_388_co[0];
  assign recovered_388_co[1] = (recovered_388_s[1] & recovered_388_co[0]) | (~recovered_388_s[1] & recovered_388_di[1]);
  assign recovered_388_o[2] = recovered_388_s[2] ^ recovered_388_co[1];
  assign recovered_388_co[2] = (recovered_388_s[2] & recovered_388_co[1]) | (~recovered_388_s[2] & recovered_388_di[2]);
  assign recovered_388_o[3] = recovered_388_s[3] ^ recovered_388_co[2];
  assign recovered_388_co[3] = (recovered_388_s[3] & recovered_388_co[2]) | (~recovered_388_s[3] & recovered_388_di[3]);
  assign {last_sect,NLW_last_sect_carry__3_CO_UNCONNECTED[0]} = recovered_388_co;

  // Reconstructed LUT6: last_sect_carry_i_1__0
  assign last_sect_carry_i_1__0_n_0 = ((esc_sect_cnt_reg_n_0__11_2134eea) ? (((p_0_in0_in[11]) ? (((p_0_in0_in[9]) ? (((esc_sect_cnt_reg_n_0__9_46ce72e) ? (((p_0_in0_in[10]) ? (esc_sect_cnt_reg_n_0__10_8129e9e) : (~(esc_sect_cnt_reg_n_0__10_8129e9e)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__9_46ce72e) ? (1'b0) : (((p_0_in0_in[10]) ? (esc_sect_cnt_reg_n_0__10_8129e9e) : (~(esc_sect_cnt_reg_n_0__10_8129e9e)))))))) : (1'b0))) : (((p_0_in0_in[11]) ? (1'b0) : (((p_0_in0_in[9]) ? (((esc_sect_cnt_reg_n_0__9_46ce72e) ? (((p_0_in0_in[10]) ? (esc_sect_cnt_reg_n_0__10_8129e9e) : (~(esc_sect_cnt_reg_n_0__10_8129e9e)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__9_46ce72e) ? (1'b0) : (((p_0_in0_in[10]) ? (esc_sect_cnt_reg_n_0__10_8129e9e) : (~(esc_sect_cnt_reg_n_0__10_8129e9e)))))))))));

  // Reconstructed LUT6: last_sect_carry_i_2__0
  assign last_sect_carry_i_2__0_n_0 = ((esc_sect_cnt_reg_n_0__8_9af08b3) ? (((p_0_in0_in[8]) ? (((p_0_in0_in[7]) ? (((esc_sect_cnt_reg_n_0__7_5d37ab6) ? (((p_0_in0_in[6]) ? (esc_sect_cnt_reg_n_0__6_8f7c601) : (~(esc_sect_cnt_reg_n_0__6_8f7c601)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__7_5d37ab6) ? (1'b0) : (((p_0_in0_in[6]) ? (esc_sect_cnt_reg_n_0__6_8f7c601) : (~(esc_sect_cnt_reg_n_0__6_8f7c601)))))))) : (1'b0))) : (((p_0_in0_in[8]) ? (1'b0) : (((p_0_in0_in[7]) ? (((esc_sect_cnt_reg_n_0__7_5d37ab6) ? (((p_0_in0_in[6]) ? (esc_sect_cnt_reg_n_0__6_8f7c601) : (~(esc_sect_cnt_reg_n_0__6_8f7c601)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__7_5d37ab6) ? (1'b0) : (((p_0_in0_in[6]) ? (esc_sect_cnt_reg_n_0__6_8f7c601) : (~(esc_sect_cnt_reg_n_0__6_8f7c601)))))))))));

  // Reconstructed LUT6: last_sect_carry_i_3__0
  assign last_sect_carry_i_3__0_n_0 = ((esc_sect_cnt_reg_n_0__5_5ca388c) ? (((p_0_in0_in[5]) ? (((p_0_in0_in[3]) ? (((esc_sect_cnt_reg_n_0__3_e4b1820) ? (((p_0_in0_in[4]) ? (esc_sect_cnt_reg_n_0__4_2216bae) : (~(esc_sect_cnt_reg_n_0__4_2216bae)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__3_e4b1820) ? (1'b0) : (((p_0_in0_in[4]) ? (esc_sect_cnt_reg_n_0__4_2216bae) : (~(esc_sect_cnt_reg_n_0__4_2216bae)))))))) : (1'b0))) : (((p_0_in0_in[5]) ? (1'b0) : (((p_0_in0_in[3]) ? (((esc_sect_cnt_reg_n_0__3_e4b1820) ? (((p_0_in0_in[4]) ? (esc_sect_cnt_reg_n_0__4_2216bae) : (~(esc_sect_cnt_reg_n_0__4_2216bae)))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__3_e4b1820) ? (1'b0) : (((p_0_in0_in[4]) ? (esc_sect_cnt_reg_n_0__4_2216bae) : (~(esc_sect_cnt_reg_n_0__4_2216bae)))))))))));

  // Reconstructed LUT6: last_sect_carry_i_4__0
  assign last_sect_carry_i_4__0_n_0 = ((p_0_in0_in[0]) ? (((esc_sect_cnt_reg_n_0__0_cf5038d) ? (((p_0_in0_in[1]) ? (((esc_sect_cnt_reg_n_0__1_6d680f9) ? (((esc_sect_cnt_reg_n_0__2_15d4d8f) ? (p_0_in0_in[2]) : (~(p_0_in0_in[2])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__1_6d680f9) ? (1'b0) : (((esc_sect_cnt_reg_n_0__2_15d4d8f) ? (p_0_in0_in[2]) : (~(p_0_in0_in[2])))))))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__0_cf5038d) ? (1'b0) : (((p_0_in0_in[1]) ? (((esc_sect_cnt_reg_n_0__1_6d680f9) ? (((esc_sect_cnt_reg_n_0__2_15d4d8f) ? (p_0_in0_in[2]) : (~(p_0_in0_in[2])))) : (1'b0))) : (((esc_sect_cnt_reg_n_0__1_6d680f9) ? (1'b0) : (((esc_sect_cnt_reg_n_0__2_15d4d8f) ? (p_0_in0_in[2]) : (~(p_0_in0_in[2])))))))))));

  // Reconstructed LUT2: m_axi_output_r_AWVALID_INST_0
  assign m_axi_output_r_AWVALID = ((m_axi_output_r_AWVALID_0) ? (1'b0) : (AWVALID_Dummy));

  // Reconstructed FDRE: next_resp_reg
  reg recovered_394_q = 1'b0;
  assign next_resp = recovered_394_q;
  wire recovered_394_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_394_reset || (((SR) === 1'bx) && (recovered_394_q == 1'b0))) recovered_394_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_394_q == (next_resp0)))) recovered_394_q <= (next_resp0);
  end

  // Reconstructed CARRY4: p_0_out_carry
  wire [3:0] recovered_395_co, recovered_395_o, recovered_395_s, recovered_395_di;
  assign recovered_395_s = {buff_wdata_n_18,buff_wdata_n_19,buff_wdata_n_20,buff_wdata_n_21};
  assign recovered_395_di = {mOutPtr_reg[3:1],buff_wdata_n_25};
  wire recovered_395_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_395_cy = ((mOutPtr_reg[0]) !== 1'bz) && (mOutPtr_reg[0]);
  assign recovered_395_o[0] = recovered_395_s[0] ^ (recovered_395_ci || recovered_395_cy);
  assign recovered_395_co[0] = (recovered_395_s[0] & (recovered_395_ci || recovered_395_cy)) | (~recovered_395_s[0] & recovered_395_di[0]);
  assign recovered_395_o[1] = recovered_395_s[1] ^ recovered_395_co[0];
  assign recovered_395_co[1] = (recovered_395_s[1] & recovered_395_co[0]) | (~recovered_395_s[1] & recovered_395_di[1]);
  assign recovered_395_o[2] = recovered_395_s[2] ^ recovered_395_co[1];
  assign recovered_395_co[2] = (recovered_395_s[2] & recovered_395_co[1]) | (~recovered_395_s[2] & recovered_395_di[2]);
  assign recovered_395_o[3] = recovered_395_s[3] ^ recovered_395_co[2];
  assign recovered_395_co[3] = (recovered_395_s[3] & recovered_395_co[2]) | (~recovered_395_s[3] & recovered_395_di[3]);
  assign {p_0_out_carry_n_0,NLW_p_0_out_carry_CO_UNCONNECTED[2:0]} = recovered_395_co;
  assign {p_0_out_carry_n_4,p_0_out_carry_n_5,p_0_out_carry_n_6,p_0_out_carry_n_7} = recovered_395_o;

  // Reconstructed CARRY4: p_0_out_carry__0
  wire [3:0] recovered_396_co, recovered_396_o, recovered_396_s, recovered_396_di;
  assign recovered_396_s = {esc_const0_a0cf646 ,buff_wdata_n_9,buff_wdata_n_10,buff_wdata_n_11};
  assign recovered_396_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,mOutPtr_reg[5:4]};
  wire recovered_396_ci = ((p_0_out_carry_n_0) !== 1'bz) && (p_0_out_carry_n_0);
  wire recovered_396_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_396_o[0] = recovered_396_s[0] ^ (recovered_396_ci || recovered_396_cy);
  assign recovered_396_co[0] = (recovered_396_s[0] & (recovered_396_ci || recovered_396_cy)) | (~recovered_396_s[0] & recovered_396_di[0]);
  assign recovered_396_o[1] = recovered_396_s[1] ^ recovered_396_co[0];
  assign recovered_396_co[1] = (recovered_396_s[1] & recovered_396_co[0]) | (~recovered_396_s[1] & recovered_396_di[1]);
  assign recovered_396_o[2] = recovered_396_s[2] ^ recovered_396_co[1];
  assign recovered_396_co[2] = (recovered_396_s[2] & recovered_396_co[1]) | (~recovered_396_s[2] & recovered_396_di[2]);
  assign recovered_396_o[3] = recovered_396_s[3] ^ recovered_396_co[2];
  assign recovered_396_co[3] = (recovered_396_s[3] & recovered_396_co[2]) | (~recovered_396_s[3] & recovered_396_di[3]);
  assign {p_0_out_carry__0_n_5,p_0_out_carry__0_n_6,p_0_out_carry__0_n_7} = recovered_396_o;

  system_blue_locator_packed_0_0_blue_locator_packed_output_r_m_axi_reg_slice rs_wreq
       (.D(D[1]),
        .E(E),
        .Q({Q[18],Q[8:1]}),
        .SR(SR),
        .esc_ap_CS_fsm_63__i_4_0_636870a (esc_ap_CS_fsm_63__i_4_789726b ),
        .esc_ap_CS_fsm_reg_63_8ee7371 (esc_ap_CS_fsm_reg_63_8ee7371 ),
        .esc_ap_CS_fsm_reg_63__0_9fe4f39 (esc_ap_CS_fsm_reg_63__0_9fe4f39 ),
        .esc_ap_CS_fsm_reg_63__1_dfe60b8 (esc_ap_CS_fsm_reg_63__1_dfe60b8 ),
        .ap_clk(ap_clk),
        .esc_data_p1_reg_61__0_8907fe4 (rs2f_wreq_data),
        .esc_data_p2_reg_61__0_36955cb (esc_data_p2_reg_61_4692f8e ),
        .output_r_AWREADY(output_r_AWREADY),
        .rs2f_wreq_ack(rs2f_wreq_ack),
        .esc_state_reg_0__0_c93a5dd (rs2f_wreq_valid));

  // Reconstructed LUT2: esc_sect_addr_buf_10__i_1__0_01c76ee
  assign sect_addr[10] = ((esc_start_addr_buf_reg_n_0__10_1323f7f) ? (first_sect) : (1'b0));

  // Reconstructed LUT2: esc_sect_addr_buf_11__i_2__0_536f2ac
  assign sect_addr[11] = ((esc_start_addr_buf_reg_n_0__11_3e2416d) ? (first_sect) : (1'b0));

  // Reconstructed LUT3: esc_sect_addr_buf_12__i_1__0_1082737
  assign sect_addr[12] = ((esc_sect_cnt_reg_n_0__0_cf5038d) ? (((first_sect) ? (p_0_in_0[0]) : (1'b1))) : (((first_sect) ? (p_0_in_0[0]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_13__i_1__0_5a0d781
  assign sect_addr[13] = ((esc_sect_cnt_reg_n_0__1_6d680f9) ? (((first_sect) ? (p_0_in_0[1]) : (1'b1))) : (((first_sect) ? (p_0_in_0[1]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_14__i_1__0_d89e65c
  assign sect_addr[14] = ((esc_sect_cnt_reg_n_0__2_15d4d8f) ? (((first_sect) ? (p_0_in_0[2]) : (1'b1))) : (((first_sect) ? (p_0_in_0[2]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_15__i_1__0_f107233
  assign sect_addr[15] = ((esc_sect_cnt_reg_n_0__3_e4b1820) ? (((first_sect) ? (p_0_in_0[3]) : (1'b1))) : (((first_sect) ? (p_0_in_0[3]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_16__i_1__0_8d8767f
  assign sect_addr[16] = ((esc_sect_cnt_reg_n_0__4_2216bae) ? (((first_sect) ? (p_0_in_0[4]) : (1'b1))) : (((first_sect) ? (p_0_in_0[4]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_17__i_1__0_37ddf2b
  assign sect_addr[17] = ((esc_sect_cnt_reg_n_0__5_5ca388c) ? (((first_sect) ? (p_0_in_0[5]) : (1'b1))) : (((first_sect) ? (p_0_in_0[5]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_18__i_1__0_f5ff4db
  assign sect_addr[18] = ((esc_sect_cnt_reg_n_0__6_8f7c601) ? (((first_sect) ? (p_0_in_0[6]) : (1'b1))) : (((first_sect) ? (p_0_in_0[6]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_19__i_1__0_0c8c07a
  assign sect_addr[19] = ((esc_sect_cnt_reg_n_0__7_5d37ab6) ? (((first_sect) ? (p_0_in_0[7]) : (1'b1))) : (((first_sect) ? (p_0_in_0[7]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_20__i_1__0_3cb6fc4
  assign sect_addr[20] = ((esc_sect_cnt_reg_n_0__8_9af08b3) ? (((first_sect) ? (p_0_in_0[8]) : (1'b1))) : (((first_sect) ? (p_0_in_0[8]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_21__i_1__0_33dcc2f
  assign sect_addr[21] = ((esc_sect_cnt_reg_n_0__9_46ce72e) ? (((first_sect) ? (p_0_in_0[9]) : (1'b1))) : (((first_sect) ? (p_0_in_0[9]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_22__i_1__0_055769d
  assign sect_addr[22] = ((esc_sect_cnt_reg_n_0__10_8129e9e) ? (((first_sect) ? (p_0_in_0[10]) : (1'b1))) : (((first_sect) ? (p_0_in_0[10]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_23__i_1__0_dd2fc8a
  assign sect_addr[23] = ((esc_sect_cnt_reg_n_0__11_2134eea) ? (((first_sect) ? (p_0_in_0[11]) : (1'b1))) : (((first_sect) ? (p_0_in_0[11]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_24__i_1__0_50410c5
  assign sect_addr[24] = ((esc_sect_cnt_reg_n_0__12_b408e9b) ? (((first_sect) ? (p_0_in_0[12]) : (1'b1))) : (((first_sect) ? (p_0_in_0[12]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_25__i_1__0_27377e3
  assign sect_addr[25] = ((esc_sect_cnt_reg_n_0__13_f728c1e) ? (((first_sect) ? (p_0_in_0[13]) : (1'b1))) : (((first_sect) ? (p_0_in_0[13]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_26__i_1__0_d6a1555
  assign sect_addr[26] = ((esc_sect_cnt_reg_n_0__14_3816884) ? (((first_sect) ? (p_0_in_0[14]) : (1'b1))) : (((first_sect) ? (p_0_in_0[14]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_27__i_1__0_7bfd5c2
  assign sect_addr[27] = ((esc_sect_cnt_reg_n_0__15_baa501c) ? (((first_sect) ? (p_0_in_0[15]) : (1'b1))) : (((first_sect) ? (p_0_in_0[15]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_28__i_1__0_c214727
  assign sect_addr[28] = ((esc_sect_cnt_reg_n_0__16_e0e6bd3) ? (((first_sect) ? (p_0_in_0[16]) : (1'b1))) : (((first_sect) ? (p_0_in_0[16]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_29__i_1__0_a0c013c
  assign sect_addr[29] = ((esc_sect_cnt_reg_n_0__17_60004ee) ? (((first_sect) ? (p_0_in_0[17]) : (1'b1))) : (((first_sect) ? (p_0_in_0[17]) : (1'b0))));

  // Reconstructed LUT2: esc_sect_addr_buf_2__i_1__0_ae32752
  assign sect_addr[2] = ((esc_start_addr_buf_reg_n_0__2_9c5ad66) ? (first_sect) : (1'b0));

  // Reconstructed LUT3: esc_sect_addr_buf_30__i_1__0_d4e5c06
  assign sect_addr[30] = ((esc_sect_cnt_reg_n_0__18_2b2ad13) ? (((first_sect) ? (p_0_in_0[18]) : (1'b1))) : (((first_sect) ? (p_0_in_0[18]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_31__i_1__0_e0229a8
  assign sect_addr[31] = ((esc_sect_cnt_reg_n_0__19_d3501e6) ? (((first_sect) ? (p_0_in_0[19]) : (1'b1))) : (((first_sect) ? (p_0_in_0[19]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_32__i_1__0_3de23f0
  assign sect_addr[32] = ((esc_sect_cnt_reg_n_0__20_44e2780) ? (((first_sect) ? (p_0_in_0[20]) : (1'b1))) : (((first_sect) ? (p_0_in_0[20]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_33__i_1__0_58d8760
  assign sect_addr[33] = ((esc_sect_cnt_reg_n_0__21_2affd71) ? (((first_sect) ? (p_0_in_0[21]) : (1'b1))) : (((first_sect) ? (p_0_in_0[21]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_34__i_1__0_1b29239
  assign sect_addr[34] = ((esc_sect_cnt_reg_n_0__22_fc0a11f) ? (((first_sect) ? (p_0_in_0[22]) : (1'b1))) : (((first_sect) ? (p_0_in_0[22]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_35__i_1__0_3a22ef0
  assign sect_addr[35] = ((esc_sect_cnt_reg_n_0__23_b356fba) ? (((first_sect) ? (p_0_in_0[23]) : (1'b1))) : (((first_sect) ? (p_0_in_0[23]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_36__i_1__0_522c7a3
  assign sect_addr[36] = ((esc_sect_cnt_reg_n_0__24_f384316) ? (((first_sect) ? (p_0_in_0[24]) : (1'b1))) : (((first_sect) ? (p_0_in_0[24]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_37__i_1__0_2b5b090
  assign sect_addr[37] = ((esc_sect_cnt_reg_n_0__25_b6c1707) ? (((first_sect) ? (p_0_in_0[25]) : (1'b1))) : (((first_sect) ? (p_0_in_0[25]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_38__i_1__0_4d6f538
  assign sect_addr[38] = ((esc_sect_cnt_reg_n_0__26_b4e21e4) ? (((first_sect) ? (p_0_in_0[26]) : (1'b1))) : (((first_sect) ? (p_0_in_0[26]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_39__i_1__0_6ce1032
  assign sect_addr[39] = ((esc_sect_cnt_reg_n_0__27_131810a) ? (((first_sect) ? (p_0_in_0[27]) : (1'b1))) : (((first_sect) ? (p_0_in_0[27]) : (1'b0))));

  // Reconstructed LUT2: esc_sect_addr_buf_3__i_1__0_1d3c235
  assign sect_addr[3] = ((esc_start_addr_buf_reg_n_0__3_6d1c7eb) ? (first_sect) : (1'b0));

  // Reconstructed LUT3: esc_sect_addr_buf_40__i_1__0_735edad
  assign sect_addr[40] = ((esc_sect_cnt_reg_n_0__28_78b1845) ? (((first_sect) ? (p_0_in_0[28]) : (1'b1))) : (((first_sect) ? (p_0_in_0[28]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_41__i_1__0_832a656
  assign sect_addr[41] = ((esc_sect_cnt_reg_n_0__29_2ed533d) ? (((first_sect) ? (p_0_in_0[29]) : (1'b1))) : (((first_sect) ? (p_0_in_0[29]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_42__i_1__0_28f4efe
  assign sect_addr[42] = ((esc_sect_cnt_reg_n_0__30_38a695a) ? (((first_sect) ? (p_0_in_0[30]) : (1'b1))) : (((first_sect) ? (p_0_in_0[30]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_43__i_1__0_c7b066a
  assign sect_addr[43] = ((esc_sect_cnt_reg_n_0__31_0c2dac2) ? (((first_sect) ? (p_0_in_0[31]) : (1'b1))) : (((first_sect) ? (p_0_in_0[31]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_44__i_1__0_10de59c
  assign sect_addr[44] = ((esc_sect_cnt_reg_n_0__32_e54430d) ? (((first_sect) ? (p_0_in_0[32]) : (1'b1))) : (((first_sect) ? (p_0_in_0[32]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_45__i_1__0_13f1b66
  assign sect_addr[45] = ((esc_sect_cnt_reg_n_0__33_8cbf4a8) ? (((first_sect) ? (p_0_in_0[33]) : (1'b1))) : (((first_sect) ? (p_0_in_0[33]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_46__i_1__0_bd8a24a
  assign sect_addr[46] = ((esc_sect_cnt_reg_n_0__34_3d99c4c) ? (((first_sect) ? (p_0_in_0[34]) : (1'b1))) : (((first_sect) ? (p_0_in_0[34]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_47__i_1__0_47d63f4
  assign sect_addr[47] = ((esc_sect_cnt_reg_n_0__35_5818df7) ? (((first_sect) ? (p_0_in_0[35]) : (1'b1))) : (((first_sect) ? (p_0_in_0[35]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_48__i_1__0_4b8b505
  assign sect_addr[48] = ((esc_sect_cnt_reg_n_0__36_b6ea0ad) ? (((first_sect) ? (p_0_in_0[36]) : (1'b1))) : (((first_sect) ? (p_0_in_0[36]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_49__i_1__0_ba9f91c
  assign sect_addr[49] = ((esc_sect_cnt_reg_n_0__37_b1ebede) ? (((first_sect) ? (p_0_in_0[37]) : (1'b1))) : (((first_sect) ? (p_0_in_0[37]) : (1'b0))));

  // Reconstructed LUT2: esc_sect_addr_buf_4__i_1__0_cbe0390
  assign sect_addr[4] = ((esc_start_addr_buf_reg_n_0__4_55d009f) ? (first_sect) : (1'b0));

  // Reconstructed LUT3: esc_sect_addr_buf_50__i_1__0_4f46aa9
  assign sect_addr[50] = ((esc_sect_cnt_reg_n_0__38_d27d0e3) ? (((first_sect) ? (p_0_in_0[38]) : (1'b1))) : (((first_sect) ? (p_0_in_0[38]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_51__i_1__0_68f402f
  assign sect_addr[51] = ((esc_sect_cnt_reg_n_0__39_1a62409) ? (((first_sect) ? (p_0_in_0[39]) : (1'b1))) : (((first_sect) ? (p_0_in_0[39]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_52__i_1__0_925be07
  assign sect_addr[52] = ((esc_sect_cnt_reg_n_0__40_c7f7402) ? (((first_sect) ? (p_0_in_0[40]) : (1'b1))) : (((first_sect) ? (p_0_in_0[40]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_53__i_1__0_106c65a
  assign sect_addr[53] = ((esc_sect_cnt_reg_n_0__41_827f3d3) ? (((first_sect) ? (p_0_in_0[41]) : (1'b1))) : (((first_sect) ? (p_0_in_0[41]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_54__i_1__0_06624c9
  assign sect_addr[54] = ((esc_sect_cnt_reg_n_0__42_dc2ac0b) ? (((first_sect) ? (p_0_in_0[42]) : (1'b1))) : (((first_sect) ? (p_0_in_0[42]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_55__i_1__0_5c71ad9
  assign sect_addr[55] = ((esc_sect_cnt_reg_n_0__43_b2f91b4) ? (((first_sect) ? (p_0_in_0[43]) : (1'b1))) : (((first_sect) ? (p_0_in_0[43]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_56__i_1__0_2f863ce
  assign sect_addr[56] = ((esc_sect_cnt_reg_n_0__44_ae87890) ? (((first_sect) ? (p_0_in_0[44]) : (1'b1))) : (((first_sect) ? (p_0_in_0[44]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_57__i_1__0_993b7d6
  assign sect_addr[57] = ((esc_sect_cnt_reg_n_0__45_028cd3e) ? (((first_sect) ? (p_0_in_0[45]) : (1'b1))) : (((first_sect) ? (p_0_in_0[45]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_58__i_1__0_be8afdb
  assign sect_addr[58] = ((esc_sect_cnt_reg_n_0__46_bc6350d) ? (((first_sect) ? (p_0_in_0[46]) : (1'b1))) : (((first_sect) ? (p_0_in_0[46]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_59__i_1__0_0b5afec
  assign sect_addr[59] = ((esc_sect_cnt_reg_n_0__47_be2c9ea) ? (((first_sect) ? (p_0_in_0[47]) : (1'b1))) : (((first_sect) ? (p_0_in_0[47]) : (1'b0))));

  // Reconstructed LUT2: esc_sect_addr_buf_5__i_1__0_5aeb225
  assign sect_addr[5] = ((esc_start_addr_buf_reg_n_0__5_f6b4823) ? (first_sect) : (1'b0));

  // Reconstructed LUT3: esc_sect_addr_buf_60__i_1__0_f38844e
  assign sect_addr[60] = ((esc_sect_cnt_reg_n_0__48_c5dc410) ? (((first_sect) ? (p_0_in_0[48]) : (1'b1))) : (((first_sect) ? (p_0_in_0[48]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_61__i_1__0_e37cb04
  assign sect_addr[61] = ((esc_sect_cnt_reg_n_0__49_ac3ce58) ? (((first_sect) ? (p_0_in_0[49]) : (1'b1))) : (((first_sect) ? (p_0_in_0[49]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_62__i_1__0_5188ee8
  assign sect_addr[62] = ((esc_sect_cnt_reg_n_0__50_aee544d) ? (((first_sect) ? (p_0_in_0[50]) : (1'b1))) : (((first_sect) ? (p_0_in_0[50]) : (1'b0))));

  // Reconstructed LUT3: esc_sect_addr_buf_63__i_1__0_bb7c996
  assign sect_addr[63] = ((esc_sect_cnt_reg_n_0__51_b4f8fa6) ? (((first_sect) ? (p_0_in_0[51]) : (1'b1))) : (((first_sect) ? (p_0_in_0[51]) : (1'b0))));

  // Reconstructed LUT2: esc_sect_addr_buf_6__i_1__0_604a854
  assign sect_addr[6] = ((esc_start_addr_buf_reg_n_0__6_5592b8e) ? (first_sect) : (1'b0));

  // Reconstructed LUT2: esc_sect_addr_buf_7__i_1__0_10b0ba9
  assign sect_addr[7] = ((esc_start_addr_buf_reg_n_0__7_8e93ddd) ? (first_sect) : (1'b0));

  // Reconstructed LUT2: esc_sect_addr_buf_8__i_1__0_3c5aecd
  assign sect_addr[8] = ((esc_start_addr_buf_reg_n_0__8_3056d1d) ? (first_sect) : (1'b0));

  // Reconstructed LUT2: esc_sect_addr_buf_9__i_1__0_30ea29f
  assign sect_addr[9] = ((esc_start_addr_buf_reg_n_0__9_d78d0ac) ? (first_sect) : (1'b0));

  // Reconstructed FDRE: esc_sect_addr_buf_reg_10_73dead4
  reg recovered_460_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__10_870b69d = recovered_460_q;
  wire recovered_460_reset = ((esc_bus_equal_gen_fifo_burst_n_4_d747600)) && ((esc_bus_equal_gen_fifo_burst_n_4_d747600) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_460_reset || (((esc_bus_equal_gen_fifo_burst_n_4_d747600) === 1'bx) && (recovered_460_q == 1'b0))) recovered_460_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_460_q == (sect_addr[10])))) recovered_460_q <= (sect_addr[10]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_11_d06c36b
  reg recovered_461_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__11_3acc932 = recovered_461_q;
  wire recovered_461_reset = ((esc_bus_equal_gen_fifo_burst_n_4_d747600)) && ((esc_bus_equal_gen_fifo_burst_n_4_d747600) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_461_reset || (((esc_bus_equal_gen_fifo_burst_n_4_d747600) === 1'bx) && (recovered_461_q == 1'b0))) recovered_461_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_461_q == (sect_addr[11])))) recovered_461_q <= (sect_addr[11]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_12_0aa322a
  reg recovered_462_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__12_3345b33 = recovered_462_q;
  wire recovered_462_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_462_reset || (((SR) === 1'bx) && (recovered_462_q == 1'b0))) recovered_462_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_462_q == (sect_addr[12])))) recovered_462_q <= (sect_addr[12]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_13_f7366b7
  reg recovered_463_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__13_c419bb0 = recovered_463_q;
  wire recovered_463_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_463_reset || (((SR) === 1'bx) && (recovered_463_q == 1'b0))) recovered_463_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_463_q == (sect_addr[13])))) recovered_463_q <= (sect_addr[13]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_14_7964795
  reg recovered_464_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__14_be30b67 = recovered_464_q;
  wire recovered_464_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_464_reset || (((SR) === 1'bx) && (recovered_464_q == 1'b0))) recovered_464_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_464_q == (sect_addr[14])))) recovered_464_q <= (sect_addr[14]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_15_97daeda
  reg recovered_465_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__15_83b1580 = recovered_465_q;
  wire recovered_465_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_465_reset || (((SR) === 1'bx) && (recovered_465_q == 1'b0))) recovered_465_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_465_q == (sect_addr[15])))) recovered_465_q <= (sect_addr[15]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_16_441b3dd
  reg recovered_466_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__16_8d80ab0 = recovered_466_q;
  wire recovered_466_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_466_reset || (((SR) === 1'bx) && (recovered_466_q == 1'b0))) recovered_466_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_466_q == (sect_addr[16])))) recovered_466_q <= (sect_addr[16]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_17_e91001f
  reg recovered_467_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__17_b463da9 = recovered_467_q;
  wire recovered_467_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_467_reset || (((SR) === 1'bx) && (recovered_467_q == 1'b0))) recovered_467_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_467_q == (sect_addr[17])))) recovered_467_q <= (sect_addr[17]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_18_e94fe24
  reg recovered_468_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__18_8f1b7e0 = recovered_468_q;
  wire recovered_468_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_468_reset || (((SR) === 1'bx) && (recovered_468_q == 1'b0))) recovered_468_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_468_q == (sect_addr[18])))) recovered_468_q <= (sect_addr[18]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_19_3a66096
  reg recovered_469_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__19_205beba = recovered_469_q;
  wire recovered_469_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_469_reset || (((SR) === 1'bx) && (recovered_469_q == 1'b0))) recovered_469_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_469_q == (sect_addr[19])))) recovered_469_q <= (sect_addr[19]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_20_1eff0db
  reg recovered_470_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__20_64eade7 = recovered_470_q;
  wire recovered_470_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_470_reset || (((SR) === 1'bx) && (recovered_470_q == 1'b0))) recovered_470_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_470_q == (sect_addr[20])))) recovered_470_q <= (sect_addr[20]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_21_f290569
  reg recovered_471_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__21_15c29c5 = recovered_471_q;
  wire recovered_471_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_471_reset || (((SR) === 1'bx) && (recovered_471_q == 1'b0))) recovered_471_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_471_q == (sect_addr[21])))) recovered_471_q <= (sect_addr[21]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_22_458f857
  reg recovered_472_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__22_b0a0c3d = recovered_472_q;
  wire recovered_472_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_472_reset || (((SR) === 1'bx) && (recovered_472_q == 1'b0))) recovered_472_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_472_q == (sect_addr[22])))) recovered_472_q <= (sect_addr[22]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_23_8ca37d6
  reg recovered_473_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__23_31ab99b = recovered_473_q;
  wire recovered_473_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_473_reset || (((SR) === 1'bx) && (recovered_473_q == 1'b0))) recovered_473_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_473_q == (sect_addr[23])))) recovered_473_q <= (sect_addr[23]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_24_ab84229
  reg recovered_474_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__24_9a91ab6 = recovered_474_q;
  wire recovered_474_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_474_reset || (((SR) === 1'bx) && (recovered_474_q == 1'b0))) recovered_474_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_474_q == (sect_addr[24])))) recovered_474_q <= (sect_addr[24]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_25_e035e57
  reg recovered_475_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__25_fd4334d = recovered_475_q;
  wire recovered_475_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_475_reset || (((SR) === 1'bx) && (recovered_475_q == 1'b0))) recovered_475_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_475_q == (sect_addr[25])))) recovered_475_q <= (sect_addr[25]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_26_04ff9f3
  reg recovered_476_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__26_4b2b197 = recovered_476_q;
  wire recovered_476_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_476_reset || (((SR) === 1'bx) && (recovered_476_q == 1'b0))) recovered_476_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_476_q == (sect_addr[26])))) recovered_476_q <= (sect_addr[26]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_27_4ad0de1
  reg recovered_477_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__27_dc5c286 = recovered_477_q;
  wire recovered_477_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_477_reset || (((SR) === 1'bx) && (recovered_477_q == 1'b0))) recovered_477_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_477_q == (sect_addr[27])))) recovered_477_q <= (sect_addr[27]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_28_36eb442
  reg recovered_478_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__28_ab688cc = recovered_478_q;
  wire recovered_478_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_478_reset || (((SR) === 1'bx) && (recovered_478_q == 1'b0))) recovered_478_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_478_q == (sect_addr[28])))) recovered_478_q <= (sect_addr[28]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_29_cdccfd5
  reg recovered_479_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__29_5fda2c0 = recovered_479_q;
  wire recovered_479_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_479_reset || (((SR) === 1'bx) && (recovered_479_q == 1'b0))) recovered_479_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_479_q == (sect_addr[29])))) recovered_479_q <= (sect_addr[29]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_2_e1863e6
  reg recovered_480_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__2_c2c1041 = recovered_480_q;
  wire recovered_480_reset = ((esc_bus_equal_gen_fifo_burst_n_4_d747600)) && ((esc_bus_equal_gen_fifo_burst_n_4_d747600) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_480_reset || (((esc_bus_equal_gen_fifo_burst_n_4_d747600) === 1'bx) && (recovered_480_q == 1'b0))) recovered_480_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_480_q == (sect_addr[2])))) recovered_480_q <= (sect_addr[2]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_30_0e1fd13
  reg recovered_481_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__30_160e1b6 = recovered_481_q;
  wire recovered_481_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_481_reset || (((SR) === 1'bx) && (recovered_481_q == 1'b0))) recovered_481_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_481_q == (sect_addr[30])))) recovered_481_q <= (sect_addr[30]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_31_641f3f2
  reg recovered_482_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__31_f1a8fbc = recovered_482_q;
  wire recovered_482_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_482_reset || (((SR) === 1'bx) && (recovered_482_q == 1'b0))) recovered_482_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_482_q == (sect_addr[31])))) recovered_482_q <= (sect_addr[31]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_32_6cda6b1
  reg recovered_483_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__32_c7aeb52 = recovered_483_q;
  wire recovered_483_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_483_reset || (((SR) === 1'bx) && (recovered_483_q == 1'b0))) recovered_483_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_483_q == (sect_addr[32])))) recovered_483_q <= (sect_addr[32]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_33_e7ab905
  reg recovered_484_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__33_3443c27 = recovered_484_q;
  wire recovered_484_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_484_reset || (((SR) === 1'bx) && (recovered_484_q == 1'b0))) recovered_484_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_484_q == (sect_addr[33])))) recovered_484_q <= (sect_addr[33]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_34_6f52206
  reg recovered_485_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__34_c59005e = recovered_485_q;
  wire recovered_485_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_485_reset || (((SR) === 1'bx) && (recovered_485_q == 1'b0))) recovered_485_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_485_q == (sect_addr[34])))) recovered_485_q <= (sect_addr[34]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_35_da0622c
  reg recovered_486_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__35_4d0f93d = recovered_486_q;
  wire recovered_486_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_486_reset || (((SR) === 1'bx) && (recovered_486_q == 1'b0))) recovered_486_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_486_q == (sect_addr[35])))) recovered_486_q <= (sect_addr[35]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_36_c82fdb9
  reg recovered_487_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__36_d80e692 = recovered_487_q;
  wire recovered_487_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_487_reset || (((SR) === 1'bx) && (recovered_487_q == 1'b0))) recovered_487_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_487_q == (sect_addr[36])))) recovered_487_q <= (sect_addr[36]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_37_ea1154e
  reg recovered_488_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__37_18b7f7b = recovered_488_q;
  wire recovered_488_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_488_reset || (((SR) === 1'bx) && (recovered_488_q == 1'b0))) recovered_488_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_488_q == (sect_addr[37])))) recovered_488_q <= (sect_addr[37]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_38_85de64b
  reg recovered_489_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__38_a55959a = recovered_489_q;
  wire recovered_489_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_489_reset || (((SR) === 1'bx) && (recovered_489_q == 1'b0))) recovered_489_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_489_q == (sect_addr[38])))) recovered_489_q <= (sect_addr[38]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_39_2c6f637
  reg recovered_490_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__39_bee2ecd = recovered_490_q;
  wire recovered_490_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_490_reset || (((SR) === 1'bx) && (recovered_490_q == 1'b0))) recovered_490_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_490_q == (sect_addr[39])))) recovered_490_q <= (sect_addr[39]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_3_560859b
  reg recovered_491_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__3_fe3572f = recovered_491_q;
  wire recovered_491_reset = ((esc_bus_equal_gen_fifo_burst_n_4_d747600)) && ((esc_bus_equal_gen_fifo_burst_n_4_d747600) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_491_reset || (((esc_bus_equal_gen_fifo_burst_n_4_d747600) === 1'bx) && (recovered_491_q == 1'b0))) recovered_491_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_491_q == (sect_addr[3])))) recovered_491_q <= (sect_addr[3]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_40_09bb75c
  reg recovered_492_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__40_1eb7798 = recovered_492_q;
  wire recovered_492_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_492_reset || (((SR) === 1'bx) && (recovered_492_q == 1'b0))) recovered_492_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_492_q == (sect_addr[40])))) recovered_492_q <= (sect_addr[40]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_41_1dbce93
  reg recovered_493_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__41_2d6e174 = recovered_493_q;
  wire recovered_493_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_493_reset || (((SR) === 1'bx) && (recovered_493_q == 1'b0))) recovered_493_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_493_q == (sect_addr[41])))) recovered_493_q <= (sect_addr[41]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_42_723fdb3
  reg recovered_494_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__42_6a4a4fb = recovered_494_q;
  wire recovered_494_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_494_reset || (((SR) === 1'bx) && (recovered_494_q == 1'b0))) recovered_494_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_494_q == (sect_addr[42])))) recovered_494_q <= (sect_addr[42]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_43_f8ef4ac
  reg recovered_495_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__43_99fa7a2 = recovered_495_q;
  wire recovered_495_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_495_reset || (((SR) === 1'bx) && (recovered_495_q == 1'b0))) recovered_495_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_495_q == (sect_addr[43])))) recovered_495_q <= (sect_addr[43]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_44_f6339da
  reg recovered_496_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__44_46a4975 = recovered_496_q;
  wire recovered_496_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_496_reset || (((SR) === 1'bx) && (recovered_496_q == 1'b0))) recovered_496_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_496_q == (sect_addr[44])))) recovered_496_q <= (sect_addr[44]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_45_0769bb6
  reg recovered_497_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__45_97ae151 = recovered_497_q;
  wire recovered_497_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_497_reset || (((SR) === 1'bx) && (recovered_497_q == 1'b0))) recovered_497_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_497_q == (sect_addr[45])))) recovered_497_q <= (sect_addr[45]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_46_92ddef2
  reg recovered_498_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__46_c8d2917 = recovered_498_q;
  wire recovered_498_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_498_reset || (((SR) === 1'bx) && (recovered_498_q == 1'b0))) recovered_498_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_498_q == (sect_addr[46])))) recovered_498_q <= (sect_addr[46]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_47_bc9baa5
  reg recovered_499_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__47_205d244 = recovered_499_q;
  wire recovered_499_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_499_reset || (((SR) === 1'bx) && (recovered_499_q == 1'b0))) recovered_499_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_499_q == (sect_addr[47])))) recovered_499_q <= (sect_addr[47]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_48_db523ff
  reg recovered_500_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__48_870c0bb = recovered_500_q;
  wire recovered_500_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_500_reset || (((SR) === 1'bx) && (recovered_500_q == 1'b0))) recovered_500_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_500_q == (sect_addr[48])))) recovered_500_q <= (sect_addr[48]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_49_4a3ce00
  reg recovered_501_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__49_ee79105 = recovered_501_q;
  wire recovered_501_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_501_reset || (((SR) === 1'bx) && (recovered_501_q == 1'b0))) recovered_501_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_501_q == (sect_addr[49])))) recovered_501_q <= (sect_addr[49]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_4_0c5e230
  reg recovered_502_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__4_363722f = recovered_502_q;
  wire recovered_502_reset = ((esc_bus_equal_gen_fifo_burst_n_4_d747600)) && ((esc_bus_equal_gen_fifo_burst_n_4_d747600) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_502_reset || (((esc_bus_equal_gen_fifo_burst_n_4_d747600) === 1'bx) && (recovered_502_q == 1'b0))) recovered_502_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_502_q == (sect_addr[4])))) recovered_502_q <= (sect_addr[4]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_50_c964bc4
  reg recovered_503_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__50_4c8d65a = recovered_503_q;
  wire recovered_503_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_503_reset || (((SR) === 1'bx) && (recovered_503_q == 1'b0))) recovered_503_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_503_q == (sect_addr[50])))) recovered_503_q <= (sect_addr[50]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_51_dc02bbe
  reg recovered_504_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__51_d4fe5b5 = recovered_504_q;
  wire recovered_504_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_504_reset || (((SR) === 1'bx) && (recovered_504_q == 1'b0))) recovered_504_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_504_q == (sect_addr[51])))) recovered_504_q <= (sect_addr[51]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_52_5ff7fcd
  reg recovered_505_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__52_9d48c85 = recovered_505_q;
  wire recovered_505_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_505_reset || (((SR) === 1'bx) && (recovered_505_q == 1'b0))) recovered_505_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_505_q == (sect_addr[52])))) recovered_505_q <= (sect_addr[52]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_53_2d80f5a
  reg recovered_506_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__53_7d93328 = recovered_506_q;
  wire recovered_506_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_506_reset || (((SR) === 1'bx) && (recovered_506_q == 1'b0))) recovered_506_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_506_q == (sect_addr[53])))) recovered_506_q <= (sect_addr[53]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_54_72414c6
  reg recovered_507_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__54_7071cc2 = recovered_507_q;
  wire recovered_507_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_507_reset || (((SR) === 1'bx) && (recovered_507_q == 1'b0))) recovered_507_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_507_q == (sect_addr[54])))) recovered_507_q <= (sect_addr[54]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_55_9c6dc63
  reg recovered_508_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__55_fa58e13 = recovered_508_q;
  wire recovered_508_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_508_reset || (((SR) === 1'bx) && (recovered_508_q == 1'b0))) recovered_508_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_508_q == (sect_addr[55])))) recovered_508_q <= (sect_addr[55]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_56_a106822
  reg recovered_509_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__56_697e16f = recovered_509_q;
  wire recovered_509_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_509_reset || (((SR) === 1'bx) && (recovered_509_q == 1'b0))) recovered_509_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_509_q == (sect_addr[56])))) recovered_509_q <= (sect_addr[56]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_57_2e89d86
  reg recovered_510_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__57_288be70 = recovered_510_q;
  wire recovered_510_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_510_reset || (((SR) === 1'bx) && (recovered_510_q == 1'b0))) recovered_510_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_510_q == (sect_addr[57])))) recovered_510_q <= (sect_addr[57]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_58_2510675
  reg recovered_511_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__58_a7911e8 = recovered_511_q;
  wire recovered_511_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_511_reset || (((SR) === 1'bx) && (recovered_511_q == 1'b0))) recovered_511_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_511_q == (sect_addr[58])))) recovered_511_q <= (sect_addr[58]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_59_83300fd
  reg recovered_512_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__59_73bc156 = recovered_512_q;
  wire recovered_512_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_512_reset || (((SR) === 1'bx) && (recovered_512_q == 1'b0))) recovered_512_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_512_q == (sect_addr[59])))) recovered_512_q <= (sect_addr[59]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_5_5d3a79d
  reg recovered_513_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__5_e2303ea = recovered_513_q;
  wire recovered_513_reset = ((esc_bus_equal_gen_fifo_burst_n_4_d747600)) && ((esc_bus_equal_gen_fifo_burst_n_4_d747600) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_513_reset || (((esc_bus_equal_gen_fifo_burst_n_4_d747600) === 1'bx) && (recovered_513_q == 1'b0))) recovered_513_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_513_q == (sect_addr[5])))) recovered_513_q <= (sect_addr[5]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_60_97b02cd
  reg recovered_514_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__60_537e0e3 = recovered_514_q;
  wire recovered_514_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_514_reset || (((SR) === 1'bx) && (recovered_514_q == 1'b0))) recovered_514_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_514_q == (sect_addr[60])))) recovered_514_q <= (sect_addr[60]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_61_a0cf94b
  reg recovered_515_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__61_0fe6dc2 = recovered_515_q;
  wire recovered_515_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_515_reset || (((SR) === 1'bx) && (recovered_515_q == 1'b0))) recovered_515_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_515_q == (sect_addr[61])))) recovered_515_q <= (sect_addr[61]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_62_ad7e09d
  reg recovered_516_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__62_7a67c6d = recovered_516_q;
  wire recovered_516_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_516_reset || (((SR) === 1'bx) && (recovered_516_q == 1'b0))) recovered_516_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_516_q == (sect_addr[62])))) recovered_516_q <= (sect_addr[62]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_63_6d31bb3
  reg recovered_517_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__63_ebd5f7d = recovered_517_q;
  wire recovered_517_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_517_reset || (((SR) === 1'bx) && (recovered_517_q == 1'b0))) recovered_517_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_517_q == (sect_addr[63])))) recovered_517_q <= (sect_addr[63]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_6_82ef320
  reg recovered_518_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__6_a42bc93 = recovered_518_q;
  wire recovered_518_reset = ((esc_bus_equal_gen_fifo_burst_n_4_d747600)) && ((esc_bus_equal_gen_fifo_burst_n_4_d747600) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_518_reset || (((esc_bus_equal_gen_fifo_burst_n_4_d747600) === 1'bx) && (recovered_518_q == 1'b0))) recovered_518_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_518_q == (sect_addr[6])))) recovered_518_q <= (sect_addr[6]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_7_bb8edad
  reg recovered_519_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__7_f3397b7 = recovered_519_q;
  wire recovered_519_reset = ((esc_bus_equal_gen_fifo_burst_n_4_d747600)) && ((esc_bus_equal_gen_fifo_burst_n_4_d747600) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_519_reset || (((esc_bus_equal_gen_fifo_burst_n_4_d747600) === 1'bx) && (recovered_519_q == 1'b0))) recovered_519_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_519_q == (sect_addr[7])))) recovered_519_q <= (sect_addr[7]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_8_9fc3810
  reg recovered_520_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__8_2d0930b = recovered_520_q;
  wire recovered_520_reset = ((esc_bus_equal_gen_fifo_burst_n_4_d747600)) && ((esc_bus_equal_gen_fifo_burst_n_4_d747600) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_520_reset || (((esc_bus_equal_gen_fifo_burst_n_4_d747600) === 1'bx) && (recovered_520_q == 1'b0))) recovered_520_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_520_q == (sect_addr[8])))) recovered_520_q <= (sect_addr[8]);
  end

  // Reconstructed FDRE: esc_sect_addr_buf_reg_9_89036dc
  reg recovered_521_q = 1'b0;
  assign esc_sect_addr_buf_reg_n_0__9_dd7820d = recovered_521_q;
  wire recovered_521_reset = ((esc_bus_equal_gen_fifo_burst_n_4_d747600)) && ((esc_bus_equal_gen_fifo_burst_n_4_d747600) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_521_reset || (((esc_bus_equal_gen_fifo_burst_n_4_d747600) === 1'bx) && (recovered_521_q == 1'b0))) recovered_521_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_521_q == (sect_addr[9])))) recovered_521_q <= (sect_addr[9]);
  end

  // Reconstructed CARRY4: sect_cnt0_carry
  wire [3:0] recovered_522_co, recovered_522_o, recovered_522_s, recovered_522_di;
  assign recovered_522_s = {esc_sect_cnt_reg_n_0__4_2216bae ,esc_sect_cnt_reg_n_0__3_e4b1820 ,esc_sect_cnt_reg_n_0__2_15d4d8f ,esc_sect_cnt_reg_n_0__1_6d680f9 };
  assign recovered_522_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_522_ci = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  wire recovered_522_cy = ((esc_sect_cnt_reg_n_0__0_cf5038d) !== 1'bz) && (esc_sect_cnt_reg_n_0__0_cf5038d);
  assign recovered_522_o[0] = recovered_522_s[0] ^ (recovered_522_ci || recovered_522_cy);
  assign recovered_522_co[0] = (recovered_522_s[0] & (recovered_522_ci || recovered_522_cy)) | (~recovered_522_s[0] & recovered_522_di[0]);
  assign recovered_522_o[1] = recovered_522_s[1] ^ recovered_522_co[0];
  assign recovered_522_co[1] = (recovered_522_s[1] & recovered_522_co[0]) | (~recovered_522_s[1] & recovered_522_di[1]);
  assign recovered_522_o[2] = recovered_522_s[2] ^ recovered_522_co[1];
  assign recovered_522_co[2] = (recovered_522_s[2] & recovered_522_co[1]) | (~recovered_522_s[2] & recovered_522_di[2]);
  assign recovered_522_o[3] = recovered_522_s[3] ^ recovered_522_co[2];
  assign recovered_522_co[3] = (recovered_522_s[3] & recovered_522_co[2]) | (~recovered_522_s[3] & recovered_522_di[3]);
  assign {sect_cnt0_carry_n_0,NLW_sect_cnt0_carry_CO_UNCONNECTED[2:0]} = recovered_522_co;
  assign sect_cnt0[4:1] = recovered_522_o;

  // Reconstructed CARRY4: sect_cnt0_carry__0
  wire [3:0] recovered_523_co, recovered_523_o, recovered_523_s, recovered_523_di;
  assign recovered_523_s = {esc_sect_cnt_reg_n_0__8_9af08b3 ,esc_sect_cnt_reg_n_0__7_5d37ab6 ,esc_sect_cnt_reg_n_0__6_8f7c601 ,esc_sect_cnt_reg_n_0__5_5ca388c };
  assign recovered_523_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_523_ci = ((sect_cnt0_carry_n_0) !== 1'bz) && (sect_cnt0_carry_n_0);
  wire recovered_523_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_523_o[0] = recovered_523_s[0] ^ (recovered_523_ci || recovered_523_cy);
  assign recovered_523_co[0] = (recovered_523_s[0] & (recovered_523_ci || recovered_523_cy)) | (~recovered_523_s[0] & recovered_523_di[0]);
  assign recovered_523_o[1] = recovered_523_s[1] ^ recovered_523_co[0];
  assign recovered_523_co[1] = (recovered_523_s[1] & recovered_523_co[0]) | (~recovered_523_s[1] & recovered_523_di[1]);
  assign recovered_523_o[2] = recovered_523_s[2] ^ recovered_523_co[1];
  assign recovered_523_co[2] = (recovered_523_s[2] & recovered_523_co[1]) | (~recovered_523_s[2] & recovered_523_di[2]);
  assign recovered_523_o[3] = recovered_523_s[3] ^ recovered_523_co[2];
  assign recovered_523_co[3] = (recovered_523_s[3] & recovered_523_co[2]) | (~recovered_523_s[3] & recovered_523_di[3]);
  assign {sect_cnt0_carry__0_n_0,NLW_sect_cnt0_carry__0_CO_UNCONNECTED[2:0]} = recovered_523_co;
  assign sect_cnt0[8:5] = recovered_523_o;

  // Reconstructed CARRY4: sect_cnt0_carry__1
  wire [3:0] recovered_524_co, recovered_524_o, recovered_524_s, recovered_524_di;
  assign recovered_524_s = {esc_sect_cnt_reg_n_0__12_b408e9b ,esc_sect_cnt_reg_n_0__11_2134eea ,esc_sect_cnt_reg_n_0__10_8129e9e ,esc_sect_cnt_reg_n_0__9_46ce72e };
  assign recovered_524_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_524_ci = ((sect_cnt0_carry__0_n_0) !== 1'bz) && (sect_cnt0_carry__0_n_0);
  wire recovered_524_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_524_o[0] = recovered_524_s[0] ^ (recovered_524_ci || recovered_524_cy);
  assign recovered_524_co[0] = (recovered_524_s[0] & (recovered_524_ci || recovered_524_cy)) | (~recovered_524_s[0] & recovered_524_di[0]);
  assign recovered_524_o[1] = recovered_524_s[1] ^ recovered_524_co[0];
  assign recovered_524_co[1] = (recovered_524_s[1] & recovered_524_co[0]) | (~recovered_524_s[1] & recovered_524_di[1]);
  assign recovered_524_o[2] = recovered_524_s[2] ^ recovered_524_co[1];
  assign recovered_524_co[2] = (recovered_524_s[2] & recovered_524_co[1]) | (~recovered_524_s[2] & recovered_524_di[2]);
  assign recovered_524_o[3] = recovered_524_s[3] ^ recovered_524_co[2];
  assign recovered_524_co[3] = (recovered_524_s[3] & recovered_524_co[2]) | (~recovered_524_s[3] & recovered_524_di[3]);
  assign {sect_cnt0_carry__1_n_0,NLW_sect_cnt0_carry__1_CO_UNCONNECTED[2:0]} = recovered_524_co;
  assign sect_cnt0[12:9] = recovered_524_o;

  // Reconstructed CARRY4: sect_cnt0_carry__10
  wire [3:0] recovered_525_co, recovered_525_o, recovered_525_s, recovered_525_di;
  assign recovered_525_s = {esc_sect_cnt_reg_n_0__48_c5dc410 ,esc_sect_cnt_reg_n_0__47_be2c9ea ,esc_sect_cnt_reg_n_0__46_bc6350d ,esc_sect_cnt_reg_n_0__45_028cd3e };
  assign recovered_525_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_525_ci = ((sect_cnt0_carry__9_n_0) !== 1'bz) && (sect_cnt0_carry__9_n_0);
  wire recovered_525_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_525_o[0] = recovered_525_s[0] ^ (recovered_525_ci || recovered_525_cy);
  assign recovered_525_co[0] = (recovered_525_s[0] & (recovered_525_ci || recovered_525_cy)) | (~recovered_525_s[0] & recovered_525_di[0]);
  assign recovered_525_o[1] = recovered_525_s[1] ^ recovered_525_co[0];
  assign recovered_525_co[1] = (recovered_525_s[1] & recovered_525_co[0]) | (~recovered_525_s[1] & recovered_525_di[1]);
  assign recovered_525_o[2] = recovered_525_s[2] ^ recovered_525_co[1];
  assign recovered_525_co[2] = (recovered_525_s[2] & recovered_525_co[1]) | (~recovered_525_s[2] & recovered_525_di[2]);
  assign recovered_525_o[3] = recovered_525_s[3] ^ recovered_525_co[2];
  assign recovered_525_co[3] = (recovered_525_s[3] & recovered_525_co[2]) | (~recovered_525_s[3] & recovered_525_di[3]);
  assign {sect_cnt0_carry__10_n_0,NLW_sect_cnt0_carry__10_CO_UNCONNECTED[2:0]} = recovered_525_co;
  assign sect_cnt0[48:45] = recovered_525_o;

  // Reconstructed CARRY4: sect_cnt0_carry__11
  wire [3:0] recovered_526_co, recovered_526_o, recovered_526_s, recovered_526_di;
  assign recovered_526_s = {esc_const0_a0cf646 ,esc_sect_cnt_reg_n_0__51_b4f8fa6 ,esc_sect_cnt_reg_n_0__50_aee544d ,esc_sect_cnt_reg_n_0__49_ac3ce58 };
  assign recovered_526_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_526_ci = ((sect_cnt0_carry__10_n_0) !== 1'bz) && (sect_cnt0_carry__10_n_0);
  wire recovered_526_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_526_o[0] = recovered_526_s[0] ^ (recovered_526_ci || recovered_526_cy);
  assign recovered_526_co[0] = (recovered_526_s[0] & (recovered_526_ci || recovered_526_cy)) | (~recovered_526_s[0] & recovered_526_di[0]);
  assign recovered_526_o[1] = recovered_526_s[1] ^ recovered_526_co[0];
  assign recovered_526_co[1] = (recovered_526_s[1] & recovered_526_co[0]) | (~recovered_526_s[1] & recovered_526_di[1]);
  assign recovered_526_o[2] = recovered_526_s[2] ^ recovered_526_co[1];
  assign recovered_526_co[2] = (recovered_526_s[2] & recovered_526_co[1]) | (~recovered_526_s[2] & recovered_526_di[2]);
  assign recovered_526_o[3] = recovered_526_s[3] ^ recovered_526_co[2];
  assign recovered_526_co[3] = (recovered_526_s[3] & recovered_526_co[2]) | (~recovered_526_s[3] & recovered_526_di[3]);
  assign sect_cnt0[51:49] = recovered_526_o;

  // Reconstructed CARRY4: sect_cnt0_carry__2
  wire [3:0] recovered_527_co, recovered_527_o, recovered_527_s, recovered_527_di;
  assign recovered_527_s = {esc_sect_cnt_reg_n_0__16_e0e6bd3 ,esc_sect_cnt_reg_n_0__15_baa501c ,esc_sect_cnt_reg_n_0__14_3816884 ,esc_sect_cnt_reg_n_0__13_f728c1e };
  assign recovered_527_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_527_ci = ((sect_cnt0_carry__1_n_0) !== 1'bz) && (sect_cnt0_carry__1_n_0);
  wire recovered_527_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_527_o[0] = recovered_527_s[0] ^ (recovered_527_ci || recovered_527_cy);
  assign recovered_527_co[0] = (recovered_527_s[0] & (recovered_527_ci || recovered_527_cy)) | (~recovered_527_s[0] & recovered_527_di[0]);
  assign recovered_527_o[1] = recovered_527_s[1] ^ recovered_527_co[0];
  assign recovered_527_co[1] = (recovered_527_s[1] & recovered_527_co[0]) | (~recovered_527_s[1] & recovered_527_di[1]);
  assign recovered_527_o[2] = recovered_527_s[2] ^ recovered_527_co[1];
  assign recovered_527_co[2] = (recovered_527_s[2] & recovered_527_co[1]) | (~recovered_527_s[2] & recovered_527_di[2]);
  assign recovered_527_o[3] = recovered_527_s[3] ^ recovered_527_co[2];
  assign recovered_527_co[3] = (recovered_527_s[3] & recovered_527_co[2]) | (~recovered_527_s[3] & recovered_527_di[3]);
  assign {sect_cnt0_carry__2_n_0,NLW_sect_cnt0_carry__2_CO_UNCONNECTED[2:0]} = recovered_527_co;
  assign sect_cnt0[16:13] = recovered_527_o;

  // Reconstructed CARRY4: sect_cnt0_carry__3
  wire [3:0] recovered_528_co, recovered_528_o, recovered_528_s, recovered_528_di;
  assign recovered_528_s = {esc_sect_cnt_reg_n_0__20_44e2780 ,esc_sect_cnt_reg_n_0__19_d3501e6 ,esc_sect_cnt_reg_n_0__18_2b2ad13 ,esc_sect_cnt_reg_n_0__17_60004ee };
  assign recovered_528_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_528_ci = ((sect_cnt0_carry__2_n_0) !== 1'bz) && (sect_cnt0_carry__2_n_0);
  wire recovered_528_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_528_o[0] = recovered_528_s[0] ^ (recovered_528_ci || recovered_528_cy);
  assign recovered_528_co[0] = (recovered_528_s[0] & (recovered_528_ci || recovered_528_cy)) | (~recovered_528_s[0] & recovered_528_di[0]);
  assign recovered_528_o[1] = recovered_528_s[1] ^ recovered_528_co[0];
  assign recovered_528_co[1] = (recovered_528_s[1] & recovered_528_co[0]) | (~recovered_528_s[1] & recovered_528_di[1]);
  assign recovered_528_o[2] = recovered_528_s[2] ^ recovered_528_co[1];
  assign recovered_528_co[2] = (recovered_528_s[2] & recovered_528_co[1]) | (~recovered_528_s[2] & recovered_528_di[2]);
  assign recovered_528_o[3] = recovered_528_s[3] ^ recovered_528_co[2];
  assign recovered_528_co[3] = (recovered_528_s[3] & recovered_528_co[2]) | (~recovered_528_s[3] & recovered_528_di[3]);
  assign {sect_cnt0_carry__3_n_0,NLW_sect_cnt0_carry__3_CO_UNCONNECTED[2:0]} = recovered_528_co;
  assign sect_cnt0[20:17] = recovered_528_o;

  // Reconstructed CARRY4: sect_cnt0_carry__4
  wire [3:0] recovered_529_co, recovered_529_o, recovered_529_s, recovered_529_di;
  assign recovered_529_s = {esc_sect_cnt_reg_n_0__24_f384316 ,esc_sect_cnt_reg_n_0__23_b356fba ,esc_sect_cnt_reg_n_0__22_fc0a11f ,esc_sect_cnt_reg_n_0__21_2affd71 };
  assign recovered_529_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_529_ci = ((sect_cnt0_carry__3_n_0) !== 1'bz) && (sect_cnt0_carry__3_n_0);
  wire recovered_529_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_529_o[0] = recovered_529_s[0] ^ (recovered_529_ci || recovered_529_cy);
  assign recovered_529_co[0] = (recovered_529_s[0] & (recovered_529_ci || recovered_529_cy)) | (~recovered_529_s[0] & recovered_529_di[0]);
  assign recovered_529_o[1] = recovered_529_s[1] ^ recovered_529_co[0];
  assign recovered_529_co[1] = (recovered_529_s[1] & recovered_529_co[0]) | (~recovered_529_s[1] & recovered_529_di[1]);
  assign recovered_529_o[2] = recovered_529_s[2] ^ recovered_529_co[1];
  assign recovered_529_co[2] = (recovered_529_s[2] & recovered_529_co[1]) | (~recovered_529_s[2] & recovered_529_di[2]);
  assign recovered_529_o[3] = recovered_529_s[3] ^ recovered_529_co[2];
  assign recovered_529_co[3] = (recovered_529_s[3] & recovered_529_co[2]) | (~recovered_529_s[3] & recovered_529_di[3]);
  assign {sect_cnt0_carry__4_n_0,NLW_sect_cnt0_carry__4_CO_UNCONNECTED[2:0]} = recovered_529_co;
  assign sect_cnt0[24:21] = recovered_529_o;

  // Reconstructed CARRY4: sect_cnt0_carry__5
  wire [3:0] recovered_530_co, recovered_530_o, recovered_530_s, recovered_530_di;
  assign recovered_530_s = {esc_sect_cnt_reg_n_0__28_78b1845 ,esc_sect_cnt_reg_n_0__27_131810a ,esc_sect_cnt_reg_n_0__26_b4e21e4 ,esc_sect_cnt_reg_n_0__25_b6c1707 };
  assign recovered_530_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_530_ci = ((sect_cnt0_carry__4_n_0) !== 1'bz) && (sect_cnt0_carry__4_n_0);
  wire recovered_530_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_530_o[0] = recovered_530_s[0] ^ (recovered_530_ci || recovered_530_cy);
  assign recovered_530_co[0] = (recovered_530_s[0] & (recovered_530_ci || recovered_530_cy)) | (~recovered_530_s[0] & recovered_530_di[0]);
  assign recovered_530_o[1] = recovered_530_s[1] ^ recovered_530_co[0];
  assign recovered_530_co[1] = (recovered_530_s[1] & recovered_530_co[0]) | (~recovered_530_s[1] & recovered_530_di[1]);
  assign recovered_530_o[2] = recovered_530_s[2] ^ recovered_530_co[1];
  assign recovered_530_co[2] = (recovered_530_s[2] & recovered_530_co[1]) | (~recovered_530_s[2] & recovered_530_di[2]);
  assign recovered_530_o[3] = recovered_530_s[3] ^ recovered_530_co[2];
  assign recovered_530_co[3] = (recovered_530_s[3] & recovered_530_co[2]) | (~recovered_530_s[3] & recovered_530_di[3]);
  assign {sect_cnt0_carry__5_n_0,NLW_sect_cnt0_carry__5_CO_UNCONNECTED[2:0]} = recovered_530_co;
  assign sect_cnt0[28:25] = recovered_530_o;

  // Reconstructed CARRY4: sect_cnt0_carry__6
  wire [3:0] recovered_531_co, recovered_531_o, recovered_531_s, recovered_531_di;
  assign recovered_531_s = {esc_sect_cnt_reg_n_0__32_e54430d ,esc_sect_cnt_reg_n_0__31_0c2dac2 ,esc_sect_cnt_reg_n_0__30_38a695a ,esc_sect_cnt_reg_n_0__29_2ed533d };
  assign recovered_531_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_531_ci = ((sect_cnt0_carry__5_n_0) !== 1'bz) && (sect_cnt0_carry__5_n_0);
  wire recovered_531_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_531_o[0] = recovered_531_s[0] ^ (recovered_531_ci || recovered_531_cy);
  assign recovered_531_co[0] = (recovered_531_s[0] & (recovered_531_ci || recovered_531_cy)) | (~recovered_531_s[0] & recovered_531_di[0]);
  assign recovered_531_o[1] = recovered_531_s[1] ^ recovered_531_co[0];
  assign recovered_531_co[1] = (recovered_531_s[1] & recovered_531_co[0]) | (~recovered_531_s[1] & recovered_531_di[1]);
  assign recovered_531_o[2] = recovered_531_s[2] ^ recovered_531_co[1];
  assign recovered_531_co[2] = (recovered_531_s[2] & recovered_531_co[1]) | (~recovered_531_s[2] & recovered_531_di[2]);
  assign recovered_531_o[3] = recovered_531_s[3] ^ recovered_531_co[2];
  assign recovered_531_co[3] = (recovered_531_s[3] & recovered_531_co[2]) | (~recovered_531_s[3] & recovered_531_di[3]);
  assign {sect_cnt0_carry__6_n_0,NLW_sect_cnt0_carry__6_CO_UNCONNECTED[2:0]} = recovered_531_co;
  assign sect_cnt0[32:29] = recovered_531_o;

  // Reconstructed CARRY4: sect_cnt0_carry__7
  wire [3:0] recovered_532_co, recovered_532_o, recovered_532_s, recovered_532_di;
  assign recovered_532_s = {esc_sect_cnt_reg_n_0__36_b6ea0ad ,esc_sect_cnt_reg_n_0__35_5818df7 ,esc_sect_cnt_reg_n_0__34_3d99c4c ,esc_sect_cnt_reg_n_0__33_8cbf4a8 };
  assign recovered_532_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_532_ci = ((sect_cnt0_carry__6_n_0) !== 1'bz) && (sect_cnt0_carry__6_n_0);
  wire recovered_532_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_532_o[0] = recovered_532_s[0] ^ (recovered_532_ci || recovered_532_cy);
  assign recovered_532_co[0] = (recovered_532_s[0] & (recovered_532_ci || recovered_532_cy)) | (~recovered_532_s[0] & recovered_532_di[0]);
  assign recovered_532_o[1] = recovered_532_s[1] ^ recovered_532_co[0];
  assign recovered_532_co[1] = (recovered_532_s[1] & recovered_532_co[0]) | (~recovered_532_s[1] & recovered_532_di[1]);
  assign recovered_532_o[2] = recovered_532_s[2] ^ recovered_532_co[1];
  assign recovered_532_co[2] = (recovered_532_s[2] & recovered_532_co[1]) | (~recovered_532_s[2] & recovered_532_di[2]);
  assign recovered_532_o[3] = recovered_532_s[3] ^ recovered_532_co[2];
  assign recovered_532_co[3] = (recovered_532_s[3] & recovered_532_co[2]) | (~recovered_532_s[3] & recovered_532_di[3]);
  assign {sect_cnt0_carry__7_n_0,NLW_sect_cnt0_carry__7_CO_UNCONNECTED[2:0]} = recovered_532_co;
  assign sect_cnt0[36:33] = recovered_532_o;

  // Reconstructed CARRY4: sect_cnt0_carry__8
  wire [3:0] recovered_533_co, recovered_533_o, recovered_533_s, recovered_533_di;
  assign recovered_533_s = {esc_sect_cnt_reg_n_0__40_c7f7402 ,esc_sect_cnt_reg_n_0__39_1a62409 ,esc_sect_cnt_reg_n_0__38_d27d0e3 ,esc_sect_cnt_reg_n_0__37_b1ebede };
  assign recovered_533_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_533_ci = ((sect_cnt0_carry__7_n_0) !== 1'bz) && (sect_cnt0_carry__7_n_0);
  wire recovered_533_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_533_o[0] = recovered_533_s[0] ^ (recovered_533_ci || recovered_533_cy);
  assign recovered_533_co[0] = (recovered_533_s[0] & (recovered_533_ci || recovered_533_cy)) | (~recovered_533_s[0] & recovered_533_di[0]);
  assign recovered_533_o[1] = recovered_533_s[1] ^ recovered_533_co[0];
  assign recovered_533_co[1] = (recovered_533_s[1] & recovered_533_co[0]) | (~recovered_533_s[1] & recovered_533_di[1]);
  assign recovered_533_o[2] = recovered_533_s[2] ^ recovered_533_co[1];
  assign recovered_533_co[2] = (recovered_533_s[2] & recovered_533_co[1]) | (~recovered_533_s[2] & recovered_533_di[2]);
  assign recovered_533_o[3] = recovered_533_s[3] ^ recovered_533_co[2];
  assign recovered_533_co[3] = (recovered_533_s[3] & recovered_533_co[2]) | (~recovered_533_s[3] & recovered_533_di[3]);
  assign {sect_cnt0_carry__8_n_0,NLW_sect_cnt0_carry__8_CO_UNCONNECTED[2:0]} = recovered_533_co;
  assign sect_cnt0[40:37] = recovered_533_o;

  // Reconstructed CARRY4: sect_cnt0_carry__9
  wire [3:0] recovered_534_co, recovered_534_o, recovered_534_s, recovered_534_di;
  assign recovered_534_s = {esc_sect_cnt_reg_n_0__44_ae87890 ,esc_sect_cnt_reg_n_0__43_b2f91b4 ,esc_sect_cnt_reg_n_0__42_dc2ac0b ,esc_sect_cnt_reg_n_0__41_827f3d3 };
  assign recovered_534_di = {esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 ,esc_const0_a0cf646 };
  wire recovered_534_ci = ((sect_cnt0_carry__8_n_0) !== 1'bz) && (sect_cnt0_carry__8_n_0);
  wire recovered_534_cy = ((esc_const0_a0cf646) !== 1'bz) && (esc_const0_a0cf646);
  assign recovered_534_o[0] = recovered_534_s[0] ^ (recovered_534_ci || recovered_534_cy);
  assign recovered_534_co[0] = (recovered_534_s[0] & (recovered_534_ci || recovered_534_cy)) | (~recovered_534_s[0] & recovered_534_di[0]);
  assign recovered_534_o[1] = recovered_534_s[1] ^ recovered_534_co[0];
  assign recovered_534_co[1] = (recovered_534_s[1] & recovered_534_co[0]) | (~recovered_534_s[1] & recovered_534_di[1]);
  assign recovered_534_o[2] = recovered_534_s[2] ^ recovered_534_co[1];
  assign recovered_534_co[2] = (recovered_534_s[2] & recovered_534_co[1]) | (~recovered_534_s[2] & recovered_534_di[2]);
  assign recovered_534_o[3] = recovered_534_s[3] ^ recovered_534_co[2];
  assign recovered_534_co[3] = (recovered_534_s[3] & recovered_534_co[2]) | (~recovered_534_s[3] & recovered_534_di[3]);
  assign {sect_cnt0_carry__9_n_0,NLW_sect_cnt0_carry__9_CO_UNCONNECTED[2:0]} = recovered_534_co;
  assign sect_cnt0[44:41] = recovered_534_o;

  // Reconstructed FDRE: esc_sect_cnt_reg_0_053187c
  reg recovered_535_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__0_cf5038d = recovered_535_q;
  wire recovered_535_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_535_reset || (((SR) === 1'bx) && (recovered_535_q == 1'b0))) recovered_535_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_535_q == (esc_bus_equal_gen_fifo_burst_n_59_97d1831)))) recovered_535_q <= (esc_bus_equal_gen_fifo_burst_n_59_97d1831);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_10_c8c815a
  reg recovered_536_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__10_8129e9e = recovered_536_q;
  wire recovered_536_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_536_reset || (((SR) === 1'bx) && (recovered_536_q == 1'b0))) recovered_536_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_536_q == (esc_bus_equal_gen_fifo_burst_n_49_f86f51b)))) recovered_536_q <= (esc_bus_equal_gen_fifo_burst_n_49_f86f51b);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_11_5319fd0
  reg recovered_537_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__11_2134eea = recovered_537_q;
  wire recovered_537_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_537_reset || (((SR) === 1'bx) && (recovered_537_q == 1'b0))) recovered_537_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_537_q == (esc_bus_equal_gen_fifo_burst_n_48_e40cb2f)))) recovered_537_q <= (esc_bus_equal_gen_fifo_burst_n_48_e40cb2f);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_12_0baa875
  reg recovered_538_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__12_b408e9b = recovered_538_q;
  wire recovered_538_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_538_reset || (((SR) === 1'bx) && (recovered_538_q == 1'b0))) recovered_538_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_538_q == (esc_bus_equal_gen_fifo_burst_n_47_3855ff4)))) recovered_538_q <= (esc_bus_equal_gen_fifo_burst_n_47_3855ff4);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_13_bc6af82
  reg recovered_539_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__13_f728c1e = recovered_539_q;
  wire recovered_539_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_539_reset || (((SR) === 1'bx) && (recovered_539_q == 1'b0))) recovered_539_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_539_q == (esc_bus_equal_gen_fifo_burst_n_46_d2c1907)))) recovered_539_q <= (esc_bus_equal_gen_fifo_burst_n_46_d2c1907);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_14_edfdd8d
  reg recovered_540_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__14_3816884 = recovered_540_q;
  wire recovered_540_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_540_reset || (((SR) === 1'bx) && (recovered_540_q == 1'b0))) recovered_540_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_540_q == (esc_bus_equal_gen_fifo_burst_n_45_b80267f)))) recovered_540_q <= (esc_bus_equal_gen_fifo_burst_n_45_b80267f);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_15_d34056b
  reg recovered_541_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__15_baa501c = recovered_541_q;
  wire recovered_541_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_541_reset || (((SR) === 1'bx) && (recovered_541_q == 1'b0))) recovered_541_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_541_q == (esc_bus_equal_gen_fifo_burst_n_44_1c0cfaa)))) recovered_541_q <= (esc_bus_equal_gen_fifo_burst_n_44_1c0cfaa);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_16_d2369ba
  reg recovered_542_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__16_e0e6bd3 = recovered_542_q;
  wire recovered_542_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_542_reset || (((SR) === 1'bx) && (recovered_542_q == 1'b0))) recovered_542_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_542_q == (esc_bus_equal_gen_fifo_burst_n_43_14e72d2)))) recovered_542_q <= (esc_bus_equal_gen_fifo_burst_n_43_14e72d2);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_17_9ed00cd
  reg recovered_543_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__17_60004ee = recovered_543_q;
  wire recovered_543_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_543_reset || (((SR) === 1'bx) && (recovered_543_q == 1'b0))) recovered_543_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_543_q == (esc_bus_equal_gen_fifo_burst_n_42_dd23c0f)))) recovered_543_q <= (esc_bus_equal_gen_fifo_burst_n_42_dd23c0f);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_18_c460fdb
  reg recovered_544_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__18_2b2ad13 = recovered_544_q;
  wire recovered_544_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_544_reset || (((SR) === 1'bx) && (recovered_544_q == 1'b0))) recovered_544_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_544_q == (esc_bus_equal_gen_fifo_burst_n_41_b94ba92)))) recovered_544_q <= (esc_bus_equal_gen_fifo_burst_n_41_b94ba92);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_19_48a7baa
  reg recovered_545_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__19_d3501e6 = recovered_545_q;
  wire recovered_545_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_545_reset || (((SR) === 1'bx) && (recovered_545_q == 1'b0))) recovered_545_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_545_q == (esc_bus_equal_gen_fifo_burst_n_40_8b7cec1)))) recovered_545_q <= (esc_bus_equal_gen_fifo_burst_n_40_8b7cec1);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_1_ab182c7
  reg recovered_546_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__1_6d680f9 = recovered_546_q;
  wire recovered_546_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_546_reset || (((SR) === 1'bx) && (recovered_546_q == 1'b0))) recovered_546_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_546_q == (esc_bus_equal_gen_fifo_burst_n_58_0a624b0)))) recovered_546_q <= (esc_bus_equal_gen_fifo_burst_n_58_0a624b0);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_20_ccd5cc0
  reg recovered_547_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__20_44e2780 = recovered_547_q;
  wire recovered_547_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_547_reset || (((SR) === 1'bx) && (recovered_547_q == 1'b0))) recovered_547_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_547_q == (esc_bus_equal_gen_fifo_burst_n_39_aa82d48)))) recovered_547_q <= (esc_bus_equal_gen_fifo_burst_n_39_aa82d48);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_21_863da31
  reg recovered_548_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__21_2affd71 = recovered_548_q;
  wire recovered_548_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_548_reset || (((SR) === 1'bx) && (recovered_548_q == 1'b0))) recovered_548_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_548_q == (esc_bus_equal_gen_fifo_burst_n_38_b60cdf7)))) recovered_548_q <= (esc_bus_equal_gen_fifo_burst_n_38_b60cdf7);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_22_bcd1275
  reg recovered_549_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__22_fc0a11f = recovered_549_q;
  wire recovered_549_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_549_reset || (((SR) === 1'bx) && (recovered_549_q == 1'b0))) recovered_549_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_549_q == (esc_bus_equal_gen_fifo_burst_n_37_820fc59)))) recovered_549_q <= (esc_bus_equal_gen_fifo_burst_n_37_820fc59);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_23_74b00be
  reg recovered_550_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__23_b356fba = recovered_550_q;
  wire recovered_550_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_550_reset || (((SR) === 1'bx) && (recovered_550_q == 1'b0))) recovered_550_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_550_q == (esc_bus_equal_gen_fifo_burst_n_36_445bf3c)))) recovered_550_q <= (esc_bus_equal_gen_fifo_burst_n_36_445bf3c);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_24_dd6a7e3
  reg recovered_551_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__24_f384316 = recovered_551_q;
  wire recovered_551_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_551_reset || (((SR) === 1'bx) && (recovered_551_q == 1'b0))) recovered_551_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_551_q == (esc_bus_equal_gen_fifo_burst_n_35_6521daf)))) recovered_551_q <= (esc_bus_equal_gen_fifo_burst_n_35_6521daf);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_25_812dff9
  reg recovered_552_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__25_b6c1707 = recovered_552_q;
  wire recovered_552_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_552_reset || (((SR) === 1'bx) && (recovered_552_q == 1'b0))) recovered_552_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_552_q == (esc_bus_equal_gen_fifo_burst_n_34_cc12236)))) recovered_552_q <= (esc_bus_equal_gen_fifo_burst_n_34_cc12236);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_26_adb7338
  reg recovered_553_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__26_b4e21e4 = recovered_553_q;
  wire recovered_553_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_553_reset || (((SR) === 1'bx) && (recovered_553_q == 1'b0))) recovered_553_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_553_q == (esc_bus_equal_gen_fifo_burst_n_33_772e8d0)))) recovered_553_q <= (esc_bus_equal_gen_fifo_burst_n_33_772e8d0);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_27_5cfb419
  reg recovered_554_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__27_131810a = recovered_554_q;
  wire recovered_554_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_554_reset || (((SR) === 1'bx) && (recovered_554_q == 1'b0))) recovered_554_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_554_q == (esc_bus_equal_gen_fifo_burst_n_32_c31df3c)))) recovered_554_q <= (esc_bus_equal_gen_fifo_burst_n_32_c31df3c);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_28_99870a5
  reg recovered_555_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__28_78b1845 = recovered_555_q;
  wire recovered_555_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_555_reset || (((SR) === 1'bx) && (recovered_555_q == 1'b0))) recovered_555_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_555_q == (esc_bus_equal_gen_fifo_burst_n_31_721a394)))) recovered_555_q <= (esc_bus_equal_gen_fifo_burst_n_31_721a394);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_29_63825e0
  reg recovered_556_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__29_2ed533d = recovered_556_q;
  wire recovered_556_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_556_reset || (((SR) === 1'bx) && (recovered_556_q == 1'b0))) recovered_556_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_556_q == (esc_bus_equal_gen_fifo_burst_n_30_b84bdbf)))) recovered_556_q <= (esc_bus_equal_gen_fifo_burst_n_30_b84bdbf);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_2_a106a55
  reg recovered_557_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__2_15d4d8f = recovered_557_q;
  wire recovered_557_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_557_reset || (((SR) === 1'bx) && (recovered_557_q == 1'b0))) recovered_557_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_557_q == (esc_bus_equal_gen_fifo_burst_n_57_9a24566)))) recovered_557_q <= (esc_bus_equal_gen_fifo_burst_n_57_9a24566);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_30_7bc4f29
  reg recovered_558_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__30_38a695a = recovered_558_q;
  wire recovered_558_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_558_reset || (((SR) === 1'bx) && (recovered_558_q == 1'b0))) recovered_558_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_558_q == (esc_bus_equal_gen_fifo_burst_n_29_d494d59)))) recovered_558_q <= (esc_bus_equal_gen_fifo_burst_n_29_d494d59);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_31_8ca2a5b
  reg recovered_559_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__31_0c2dac2 = recovered_559_q;
  wire recovered_559_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_559_reset || (((SR) === 1'bx) && (recovered_559_q == 1'b0))) recovered_559_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_559_q == (esc_bus_equal_gen_fifo_burst_n_28_e7e2550)))) recovered_559_q <= (esc_bus_equal_gen_fifo_burst_n_28_e7e2550);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_32_6ff17b7
  reg recovered_560_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__32_e54430d = recovered_560_q;
  wire recovered_560_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_560_reset || (((SR) === 1'bx) && (recovered_560_q == 1'b0))) recovered_560_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_560_q == (esc_bus_equal_gen_fifo_burst_n_27_cb0a1f0)))) recovered_560_q <= (esc_bus_equal_gen_fifo_burst_n_27_cb0a1f0);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_33_ddf622c
  reg recovered_561_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__33_8cbf4a8 = recovered_561_q;
  wire recovered_561_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_561_reset || (((SR) === 1'bx) && (recovered_561_q == 1'b0))) recovered_561_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_561_q == (esc_bus_equal_gen_fifo_burst_n_26_4e81909)))) recovered_561_q <= (esc_bus_equal_gen_fifo_burst_n_26_4e81909);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_34_ceb52e6
  reg recovered_562_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__34_3d99c4c = recovered_562_q;
  wire recovered_562_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_562_reset || (((SR) === 1'bx) && (recovered_562_q == 1'b0))) recovered_562_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_562_q == (esc_bus_equal_gen_fifo_burst_n_25_a348518)))) recovered_562_q <= (esc_bus_equal_gen_fifo_burst_n_25_a348518);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_35_b253ed9
  reg recovered_563_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__35_5818df7 = recovered_563_q;
  wire recovered_563_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_563_reset || (((SR) === 1'bx) && (recovered_563_q == 1'b0))) recovered_563_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_563_q == (esc_bus_equal_gen_fifo_burst_n_24_4d7c0c3)))) recovered_563_q <= (esc_bus_equal_gen_fifo_burst_n_24_4d7c0c3);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_36_7e968ea
  reg recovered_564_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__36_b6ea0ad = recovered_564_q;
  wire recovered_564_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_564_reset || (((SR) === 1'bx) && (recovered_564_q == 1'b0))) recovered_564_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_564_q == (esc_bus_equal_gen_fifo_burst_n_23_6ad7282)))) recovered_564_q <= (esc_bus_equal_gen_fifo_burst_n_23_6ad7282);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_37_ea1b6ee
  reg recovered_565_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__37_b1ebede = recovered_565_q;
  wire recovered_565_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_565_reset || (((SR) === 1'bx) && (recovered_565_q == 1'b0))) recovered_565_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_565_q == (esc_bus_equal_gen_fifo_burst_n_22_9956bb3)))) recovered_565_q <= (esc_bus_equal_gen_fifo_burst_n_22_9956bb3);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_38_1dcb93b
  reg recovered_566_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__38_d27d0e3 = recovered_566_q;
  wire recovered_566_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_566_reset || (((SR) === 1'bx) && (recovered_566_q == 1'b0))) recovered_566_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_566_q == (esc_bus_equal_gen_fifo_burst_n_21_3f82d63)))) recovered_566_q <= (esc_bus_equal_gen_fifo_burst_n_21_3f82d63);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_39_3ca0431
  reg recovered_567_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__39_1a62409 = recovered_567_q;
  wire recovered_567_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_567_reset || (((SR) === 1'bx) && (recovered_567_q == 1'b0))) recovered_567_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_567_q == (esc_bus_equal_gen_fifo_burst_n_20_8b50e36)))) recovered_567_q <= (esc_bus_equal_gen_fifo_burst_n_20_8b50e36);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_3_0f24406
  reg recovered_568_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__3_e4b1820 = recovered_568_q;
  wire recovered_568_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_568_reset || (((SR) === 1'bx) && (recovered_568_q == 1'b0))) recovered_568_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_568_q == (esc_bus_equal_gen_fifo_burst_n_56_02927c8)))) recovered_568_q <= (esc_bus_equal_gen_fifo_burst_n_56_02927c8);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_40_ca346ec
  reg recovered_569_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__40_c7f7402 = recovered_569_q;
  wire recovered_569_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_569_reset || (((SR) === 1'bx) && (recovered_569_q == 1'b0))) recovered_569_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_569_q == (esc_bus_equal_gen_fifo_burst_n_19_f40abca)))) recovered_569_q <= (esc_bus_equal_gen_fifo_burst_n_19_f40abca);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_41_7a9a009
  reg recovered_570_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__41_827f3d3 = recovered_570_q;
  wire recovered_570_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_570_reset || (((SR) === 1'bx) && (recovered_570_q == 1'b0))) recovered_570_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_570_q == (esc_bus_equal_gen_fifo_burst_n_18_6956e12)))) recovered_570_q <= (esc_bus_equal_gen_fifo_burst_n_18_6956e12);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_42_c8aee88
  reg recovered_571_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__42_dc2ac0b = recovered_571_q;
  wire recovered_571_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_571_reset || (((SR) === 1'bx) && (recovered_571_q == 1'b0))) recovered_571_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_571_q == (esc_bus_equal_gen_fifo_burst_n_17_5894e72)))) recovered_571_q <= (esc_bus_equal_gen_fifo_burst_n_17_5894e72);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_43_8308f20
  reg recovered_572_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__43_b2f91b4 = recovered_572_q;
  wire recovered_572_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_572_reset || (((SR) === 1'bx) && (recovered_572_q == 1'b0))) recovered_572_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_572_q == (esc_bus_equal_gen_fifo_burst_n_16_c3236d4)))) recovered_572_q <= (esc_bus_equal_gen_fifo_burst_n_16_c3236d4);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_44_ba4cb95
  reg recovered_573_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__44_ae87890 = recovered_573_q;
  wire recovered_573_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_573_reset || (((SR) === 1'bx) && (recovered_573_q == 1'b0))) recovered_573_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_573_q == (esc_bus_equal_gen_fifo_burst_n_15_d6b39e8)))) recovered_573_q <= (esc_bus_equal_gen_fifo_burst_n_15_d6b39e8);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_45_2cb7461
  reg recovered_574_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__45_028cd3e = recovered_574_q;
  wire recovered_574_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_574_reset || (((SR) === 1'bx) && (recovered_574_q == 1'b0))) recovered_574_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_574_q == (esc_bus_equal_gen_fifo_burst_n_14_c065c5d)))) recovered_574_q <= (esc_bus_equal_gen_fifo_burst_n_14_c065c5d);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_46_f51ad28
  reg recovered_575_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__46_bc6350d = recovered_575_q;
  wire recovered_575_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_575_reset || (((SR) === 1'bx) && (recovered_575_q == 1'b0))) recovered_575_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_575_q == (esc_bus_equal_gen_fifo_burst_n_13_c26be9e)))) recovered_575_q <= (esc_bus_equal_gen_fifo_burst_n_13_c26be9e);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_47_8889ef3
  reg recovered_576_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__47_be2c9ea = recovered_576_q;
  wire recovered_576_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_576_reset || (((SR) === 1'bx) && (recovered_576_q == 1'b0))) recovered_576_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_576_q == (esc_bus_equal_gen_fifo_burst_n_12_34a69c8)))) recovered_576_q <= (esc_bus_equal_gen_fifo_burst_n_12_34a69c8);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_48_f47f97d
  reg recovered_577_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__48_c5dc410 = recovered_577_q;
  wire recovered_577_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_577_reset || (((SR) === 1'bx) && (recovered_577_q == 1'b0))) recovered_577_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_577_q == (esc_bus_equal_gen_fifo_burst_n_11_5909e96)))) recovered_577_q <= (esc_bus_equal_gen_fifo_burst_n_11_5909e96);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_49_d0e6931
  reg recovered_578_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__49_ac3ce58 = recovered_578_q;
  wire recovered_578_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_578_reset || (((SR) === 1'bx) && (recovered_578_q == 1'b0))) recovered_578_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_578_q == (esc_bus_equal_gen_fifo_burst_n_10_7c8bbbb)))) recovered_578_q <= (esc_bus_equal_gen_fifo_burst_n_10_7c8bbbb);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_4_077ccaa
  reg recovered_579_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__4_2216bae = recovered_579_q;
  wire recovered_579_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_579_reset || (((SR) === 1'bx) && (recovered_579_q == 1'b0))) recovered_579_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_579_q == (esc_bus_equal_gen_fifo_burst_n_55_415c1c4)))) recovered_579_q <= (esc_bus_equal_gen_fifo_burst_n_55_415c1c4);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_50_2757c0a
  reg recovered_580_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__50_aee544d = recovered_580_q;
  wire recovered_580_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_580_reset || (((SR) === 1'bx) && (recovered_580_q == 1'b0))) recovered_580_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_580_q == (esc_bus_equal_gen_fifo_burst_n_9_8007697)))) recovered_580_q <= (esc_bus_equal_gen_fifo_burst_n_9_8007697);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_51_7c99099
  reg recovered_581_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__51_b4f8fa6 = recovered_581_q;
  wire recovered_581_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_581_reset || (((SR) === 1'bx) && (recovered_581_q == 1'b0))) recovered_581_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_581_q == (esc_bus_equal_gen_fifo_burst_n_8_17dc7bd)))) recovered_581_q <= (esc_bus_equal_gen_fifo_burst_n_8_17dc7bd);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_5_fa6eb25
  reg recovered_582_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__5_5ca388c = recovered_582_q;
  wire recovered_582_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_582_reset || (((SR) === 1'bx) && (recovered_582_q == 1'b0))) recovered_582_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_582_q == (esc_bus_equal_gen_fifo_burst_n_54_207fdd9)))) recovered_582_q <= (esc_bus_equal_gen_fifo_burst_n_54_207fdd9);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_6_5147bd4
  reg recovered_583_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__6_8f7c601 = recovered_583_q;
  wire recovered_583_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_583_reset || (((SR) === 1'bx) && (recovered_583_q == 1'b0))) recovered_583_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_583_q == (esc_bus_equal_gen_fifo_burst_n_53_ef2bee6)))) recovered_583_q <= (esc_bus_equal_gen_fifo_burst_n_53_ef2bee6);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_7_e7b8b85
  reg recovered_584_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__7_5d37ab6 = recovered_584_q;
  wire recovered_584_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_584_reset || (((SR) === 1'bx) && (recovered_584_q == 1'b0))) recovered_584_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_584_q == (esc_bus_equal_gen_fifo_burst_n_52_cc1c008)))) recovered_584_q <= (esc_bus_equal_gen_fifo_burst_n_52_cc1c008);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_8_ef71996
  reg recovered_585_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__8_9af08b3 = recovered_585_q;
  wire recovered_585_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_585_reset || (((SR) === 1'bx) && (recovered_585_q == 1'b0))) recovered_585_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_585_q == (esc_bus_equal_gen_fifo_burst_n_51_8547d41)))) recovered_585_q <= (esc_bus_equal_gen_fifo_burst_n_51_8547d41);
  end

  // Reconstructed FDRE: esc_sect_cnt_reg_9_46a40e7
  reg recovered_586_q = 1'b0;
  assign esc_sect_cnt_reg_n_0__9_46ce72e = recovered_586_q;
  wire recovered_586_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_586_reset || (((SR) === 1'bx) && (recovered_586_q == 1'b0))) recovered_586_q <= 1'b0;
    else if ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) || ((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bz) || (((esc_bus_equal_gen_fifo_burst_n_6_0b78b36) === 1'bx) && (recovered_586_q == (esc_bus_equal_gen_fifo_burst_n_50_a32939e)))) recovered_586_q <= (esc_bus_equal_gen_fifo_burst_n_50_a32939e);
  end

  // Reconstructed LUT5: esc_sect_len_buf_0__i_1__0_0f0333c
  assign esc_sect_len_buf_0__i_1__0_n_0_c1a0e8b = ((first_sect) ? (((last_sect) ? (beat_len_buf[2]) : (~(esc_start_addr_buf_reg_n_0__2_9c5ad66)))) : (((last_sect) ? (esc_end_addr_buf_reg_n_0__2_e2f5013) : (1'b1))));

  // Reconstructed LUT5: esc_sect_len_buf_1__i_1__0_2b87492
  assign esc_sect_len_buf_1__i_1__0_n_0_2a82972 = ((first_sect) ? (((last_sect) ? (beat_len_buf[2]) : (~(esc_start_addr_buf_reg_n_0__3_6d1c7eb)))) : (((last_sect) ? (esc_end_addr_buf_reg_n_0__3_01f6baa) : (1'b1))));

  // Reconstructed LUT5: esc_sect_len_buf_2__i_1__0_40f94e6
  assign esc_sect_len_buf_2__i_1__0_n_0_fbde65b = ((first_sect) ? (((last_sect) ? (beat_len_buf[2]) : (~(esc_start_addr_buf_reg_n_0__4_55d009f)))) : (((last_sect) ? (esc_end_addr_buf_reg_n_0__4_96f56e3) : (1'b1))));

  // Reconstructed LUT5: esc_sect_len_buf_3__i_1__0_0078c3e
  assign esc_sect_len_buf_3__i_1__0_n_0_2d844a1 = ((first_sect) ? (((last_sect) ? (beat_len_buf[3]) : (~(esc_start_addr_buf_reg_n_0__5_f6b4823)))) : (((last_sect) ? (esc_end_addr_buf_reg_n_0__5_8aa7b13) : (1'b1))));

  // Reconstructed LUT5: esc_sect_len_buf_4__i_1__0_5b3138c
  assign esc_sect_len_buf_4__i_1__0_n_0_261435d = ((first_sect) ? (((last_sect) ? (beat_len_buf[9]) : (~(esc_start_addr_buf_reg_n_0__6_5592b8e)))) : (((last_sect) ? (esc_end_addr_buf_reg_n_0__6_728119e) : (1'b1))));

  // Reconstructed LUT5: esc_sect_len_buf_5__i_1__0_8b64a9b
  assign esc_sect_len_buf_5__i_1__0_n_0_5bfe42b = ((first_sect) ? (((last_sect) ? (beat_len_buf[9]) : (~(esc_start_addr_buf_reg_n_0__7_8e93ddd)))) : (((last_sect) ? (esc_end_addr_buf_reg_n_0__7_a09c043) : (1'b1))));

  // Reconstructed LUT5: esc_sect_len_buf_6__i_1__0_333db01
  assign esc_sect_len_buf_6__i_1__0_n_0_8a4705a = ((first_sect) ? (((last_sect) ? (beat_len_buf[9]) : (~(esc_start_addr_buf_reg_n_0__8_3056d1d)))) : (((last_sect) ? (esc_end_addr_buf_reg_n_0__8_b6d3b5f) : (1'b1))));

  // Reconstructed LUT5: esc_sect_len_buf_7__i_1__0_67c6680
  assign esc_sect_len_buf_7__i_1__0_n_0_dcebc07 = ((first_sect) ? (((last_sect) ? (beat_len_buf[9]) : (~(esc_start_addr_buf_reg_n_0__9_d78d0ac)))) : (((last_sect) ? (esc_end_addr_buf_reg_n_0__9_a87511a) : (1'b1))));

  // Reconstructed LUT5: esc_sect_len_buf_8__i_1__0_4e35bba
  assign esc_sect_len_buf_8__i_1__0_n_0_7eddd71 = ((first_sect) ? (((last_sect) ? (beat_len_buf[9]) : (~(esc_start_addr_buf_reg_n_0__10_1323f7f)))) : (((last_sect) ? (esc_end_addr_buf_reg_n_0__10_c0d12d1) : (1'b1))));

  // Reconstructed LUT5: esc_sect_len_buf_9__i_2__0_2caebba
  assign esc_sect_len_buf_9__i_2__0_n_0_f63edb6 = ((first_sect) ? (((last_sect) ? (beat_len_buf[9]) : (~(esc_start_addr_buf_reg_n_0__11_3e2416d)))) : (((last_sect) ? (esc_end_addr_buf_reg_n_0__11_d1748fe) : (1'b1))));

  // Reconstructed FDRE: esc_sect_len_buf_reg_0_0a42ef3
  reg recovered_597_q = 1'b0;
  assign esc_sect_len_buf_reg_n_0__0_2f5bb85 = recovered_597_q;
  wire recovered_597_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_597_reset || (((SR) === 1'bx) && (recovered_597_q == 1'b0))) recovered_597_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_597_q == (esc_sect_len_buf_0__i_1__0_n_0_c1a0e8b)))) recovered_597_q <= (esc_sect_len_buf_0__i_1__0_n_0_c1a0e8b);
  end

  // Reconstructed FDRE: esc_sect_len_buf_reg_1_115df4c
  reg recovered_598_q = 1'b0;
  assign esc_sect_len_buf_reg_n_0__1_fa0e016 = recovered_598_q;
  wire recovered_598_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_598_reset || (((SR) === 1'bx) && (recovered_598_q == 1'b0))) recovered_598_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_598_q == (esc_sect_len_buf_1__i_1__0_n_0_2a82972)))) recovered_598_q <= (esc_sect_len_buf_1__i_1__0_n_0_2a82972);
  end

  // Reconstructed FDRE: esc_sect_len_buf_reg_2_24dcbd4
  reg recovered_599_q = 1'b0;
  assign esc_sect_len_buf_reg_n_0__2_64bffbf = recovered_599_q;
  wire recovered_599_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_599_reset || (((SR) === 1'bx) && (recovered_599_q == 1'b0))) recovered_599_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_599_q == (esc_sect_len_buf_2__i_1__0_n_0_fbde65b)))) recovered_599_q <= (esc_sect_len_buf_2__i_1__0_n_0_fbde65b);
  end

  // Reconstructed FDRE: esc_sect_len_buf_reg_3_9899048
  reg recovered_600_q = 1'b0;
  assign esc_sect_len_buf_reg_n_0__3_4003b8b = recovered_600_q;
  wire recovered_600_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_600_reset || (((SR) === 1'bx) && (recovered_600_q == 1'b0))) recovered_600_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_600_q == (esc_sect_len_buf_3__i_1__0_n_0_2d844a1)))) recovered_600_q <= (esc_sect_len_buf_3__i_1__0_n_0_2d844a1);
  end

  // Reconstructed FDRE: esc_sect_len_buf_reg_4_518d854
  reg recovered_601_q = 1'b0;
  assign esc_sect_len_buf_reg_n_0__4_7dfbe71 = recovered_601_q;
  wire recovered_601_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_601_reset || (((SR) === 1'bx) && (recovered_601_q == 1'b0))) recovered_601_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_601_q == (esc_sect_len_buf_4__i_1__0_n_0_261435d)))) recovered_601_q <= (esc_sect_len_buf_4__i_1__0_n_0_261435d);
  end

  // Reconstructed FDRE: esc_sect_len_buf_reg_5_3f5b412
  reg recovered_602_q = 1'b0;
  assign esc_sect_len_buf_reg_n_0__5_f880a64 = recovered_602_q;
  wire recovered_602_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_602_reset || (((SR) === 1'bx) && (recovered_602_q == 1'b0))) recovered_602_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_602_q == (esc_sect_len_buf_5__i_1__0_n_0_5bfe42b)))) recovered_602_q <= (esc_sect_len_buf_5__i_1__0_n_0_5bfe42b);
  end

  // Reconstructed FDRE: esc_sect_len_buf_reg_6_e7f2ec8
  reg recovered_603_q = 1'b0;
  assign esc_sect_len_buf_reg_n_0__6_00ec5ef = recovered_603_q;
  wire recovered_603_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_603_reset || (((SR) === 1'bx) && (recovered_603_q == 1'b0))) recovered_603_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_603_q == (esc_sect_len_buf_6__i_1__0_n_0_8a4705a)))) recovered_603_q <= (esc_sect_len_buf_6__i_1__0_n_0_8a4705a);
  end

  // Reconstructed FDRE: esc_sect_len_buf_reg_7_99d7f4c
  reg recovered_604_q = 1'b0;
  assign esc_sect_len_buf_reg_n_0__7_8a87bd5 = recovered_604_q;
  wire recovered_604_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_604_reset || (((SR) === 1'bx) && (recovered_604_q == 1'b0))) recovered_604_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_604_q == (esc_sect_len_buf_7__i_1__0_n_0_dcebc07)))) recovered_604_q <= (esc_sect_len_buf_7__i_1__0_n_0_dcebc07);
  end

  // Reconstructed FDRE: esc_sect_len_buf_reg_8_292d77b
  reg recovered_605_q = 1'b0;
  assign esc_sect_len_buf_reg_n_0__8_c195217 = recovered_605_q;
  wire recovered_605_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_605_reset || (((SR) === 1'bx) && (recovered_605_q == 1'b0))) recovered_605_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_605_q == (esc_sect_len_buf_8__i_1__0_n_0_7eddd71)))) recovered_605_q <= (esc_sect_len_buf_8__i_1__0_n_0_7eddd71);
  end

  // Reconstructed FDRE: esc_sect_len_buf_reg_9_0565b4f
  reg recovered_606_q = 1'b0;
  assign esc_sect_len_buf_reg_n_0__9_679de8d = recovered_606_q;
  wire recovered_606_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_606_reset || (((SR) === 1'bx) && (recovered_606_q == 1'b0))) recovered_606_q <= 1'b0;
    else if ((last_sect_buf) || ((last_sect_buf) === 1'bz) || (((last_sect_buf) === 1'bx) && (recovered_606_q == (esc_sect_len_buf_9__i_2__0_n_0_f63edb6)))) recovered_606_q <= (esc_sect_len_buf_9__i_2__0_n_0_f63edb6);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_10_66a4d86
  reg recovered_607_q = 1'b0;
  assign esc_start_addr_buf_reg_n_0__10_1323f7f = recovered_607_q;
  wire recovered_607_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_607_reset || (((SR) === 1'bx) && (recovered_607_q == 1'b0))) recovered_607_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_607_q == (esc_start_addr_reg_n_0__10_7dfdb33)))) recovered_607_q <= (esc_start_addr_reg_n_0__10_7dfdb33);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_11_20e1e6d
  reg recovered_608_q = 1'b0;
  assign esc_start_addr_buf_reg_n_0__11_3e2416d = recovered_608_q;
  wire recovered_608_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_608_reset || (((SR) === 1'bx) && (recovered_608_q == 1'b0))) recovered_608_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_608_q == (esc_start_addr_reg_n_0__11_93897a8)))) recovered_608_q <= (esc_start_addr_reg_n_0__11_93897a8);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_12_6229d2a
  reg recovered_609_q = 1'b0;
  assign p_0_in_0[0] = recovered_609_q;
  wire recovered_609_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_609_reset || (((SR) === 1'bx) && (recovered_609_q == 1'b0))) recovered_609_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_609_q == (esc_start_addr_reg_n_0__12_0ffbef5)))) recovered_609_q <= (esc_start_addr_reg_n_0__12_0ffbef5);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_13_ba18ba2
  reg recovered_610_q = 1'b0;
  assign p_0_in_0[1] = recovered_610_q;
  wire recovered_610_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_610_reset || (((SR) === 1'bx) && (recovered_610_q == 1'b0))) recovered_610_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_610_q == (esc_start_addr_reg_n_0__13_f3dfe34)))) recovered_610_q <= (esc_start_addr_reg_n_0__13_f3dfe34);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_14_be8f1f7
  reg recovered_611_q = 1'b0;
  assign p_0_in_0[2] = recovered_611_q;
  wire recovered_611_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_611_reset || (((SR) === 1'bx) && (recovered_611_q == 1'b0))) recovered_611_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_611_q == (esc_start_addr_reg_n_0__14_726da08)))) recovered_611_q <= (esc_start_addr_reg_n_0__14_726da08);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_15_e56a104
  reg recovered_612_q = 1'b0;
  assign p_0_in_0[3] = recovered_612_q;
  wire recovered_612_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_612_reset || (((SR) === 1'bx) && (recovered_612_q == 1'b0))) recovered_612_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_612_q == (esc_start_addr_reg_n_0__15_3a25f9c)))) recovered_612_q <= (esc_start_addr_reg_n_0__15_3a25f9c);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_16_00bb98c
  reg recovered_613_q = 1'b0;
  assign p_0_in_0[4] = recovered_613_q;
  wire recovered_613_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_613_reset || (((SR) === 1'bx) && (recovered_613_q == 1'b0))) recovered_613_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_613_q == (esc_start_addr_reg_n_0__16_c2276cc)))) recovered_613_q <= (esc_start_addr_reg_n_0__16_c2276cc);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_17_cf7b073
  reg recovered_614_q = 1'b0;
  assign p_0_in_0[5] = recovered_614_q;
  wire recovered_614_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_614_reset || (((SR) === 1'bx) && (recovered_614_q == 1'b0))) recovered_614_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_614_q == (esc_start_addr_reg_n_0__17_a7c7f14)))) recovered_614_q <= (esc_start_addr_reg_n_0__17_a7c7f14);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_18_df01459
  reg recovered_615_q = 1'b0;
  assign p_0_in_0[6] = recovered_615_q;
  wire recovered_615_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_615_reset || (((SR) === 1'bx) && (recovered_615_q == 1'b0))) recovered_615_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_615_q == (esc_start_addr_reg_n_0__18_7d4f45f)))) recovered_615_q <= (esc_start_addr_reg_n_0__18_7d4f45f);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_19_d9f8ebb
  reg recovered_616_q = 1'b0;
  assign p_0_in_0[7] = recovered_616_q;
  wire recovered_616_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_616_reset || (((SR) === 1'bx) && (recovered_616_q == 1'b0))) recovered_616_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_616_q == (esc_start_addr_reg_n_0__19_3510eae)))) recovered_616_q <= (esc_start_addr_reg_n_0__19_3510eae);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_20_31048b2
  reg recovered_617_q = 1'b0;
  assign p_0_in_0[8] = recovered_617_q;
  wire recovered_617_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_617_reset || (((SR) === 1'bx) && (recovered_617_q == 1'b0))) recovered_617_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_617_q == (esc_start_addr_reg_n_0__20_a055fe3)))) recovered_617_q <= (esc_start_addr_reg_n_0__20_a055fe3);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_21_5a9c49b
  reg recovered_618_q = 1'b0;
  assign p_0_in_0[9] = recovered_618_q;
  wire recovered_618_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_618_reset || (((SR) === 1'bx) && (recovered_618_q == 1'b0))) recovered_618_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_618_q == (esc_start_addr_reg_n_0__21_9efa866)))) recovered_618_q <= (esc_start_addr_reg_n_0__21_9efa866);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_22_f052376
  reg recovered_619_q = 1'b0;
  assign p_0_in_0[10] = recovered_619_q;
  wire recovered_619_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_619_reset || (((SR) === 1'bx) && (recovered_619_q == 1'b0))) recovered_619_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_619_q == (esc_start_addr_reg_n_0__22_ba17a60)))) recovered_619_q <= (esc_start_addr_reg_n_0__22_ba17a60);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_23_93bf5b1
  reg recovered_620_q = 1'b0;
  assign p_0_in_0[11] = recovered_620_q;
  wire recovered_620_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_620_reset || (((SR) === 1'bx) && (recovered_620_q == 1'b0))) recovered_620_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_620_q == (esc_start_addr_reg_n_0__23_907ba78)))) recovered_620_q <= (esc_start_addr_reg_n_0__23_907ba78);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_24_620268b
  reg recovered_621_q = 1'b0;
  assign p_0_in_0[12] = recovered_621_q;
  wire recovered_621_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_621_reset || (((SR) === 1'bx) && (recovered_621_q == 1'b0))) recovered_621_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_621_q == (esc_start_addr_reg_n_0__24_1d34d3b)))) recovered_621_q <= (esc_start_addr_reg_n_0__24_1d34d3b);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_25_59345ad
  reg recovered_622_q = 1'b0;
  assign p_0_in_0[13] = recovered_622_q;
  wire recovered_622_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_622_reset || (((SR) === 1'bx) && (recovered_622_q == 1'b0))) recovered_622_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_622_q == (esc_start_addr_reg_n_0__25_b477c1e)))) recovered_622_q <= (esc_start_addr_reg_n_0__25_b477c1e);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_26_17de4d0
  reg recovered_623_q = 1'b0;
  assign p_0_in_0[14] = recovered_623_q;
  wire recovered_623_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_623_reset || (((SR) === 1'bx) && (recovered_623_q == 1'b0))) recovered_623_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_623_q == (esc_start_addr_reg_n_0__26_5efe7d3)))) recovered_623_q <= (esc_start_addr_reg_n_0__26_5efe7d3);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_27_865893d
  reg recovered_624_q = 1'b0;
  assign p_0_in_0[15] = recovered_624_q;
  wire recovered_624_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_624_reset || (((SR) === 1'bx) && (recovered_624_q == 1'b0))) recovered_624_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_624_q == (esc_start_addr_reg_n_0__27_4bb8d27)))) recovered_624_q <= (esc_start_addr_reg_n_0__27_4bb8d27);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_28_01e15c3
  reg recovered_625_q = 1'b0;
  assign p_0_in_0[16] = recovered_625_q;
  wire recovered_625_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_625_reset || (((SR) === 1'bx) && (recovered_625_q == 1'b0))) recovered_625_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_625_q == (esc_start_addr_reg_n_0__28_0abd4bb)))) recovered_625_q <= (esc_start_addr_reg_n_0__28_0abd4bb);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_29_e305842
  reg recovered_626_q = 1'b0;
  assign p_0_in_0[17] = recovered_626_q;
  wire recovered_626_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_626_reset || (((SR) === 1'bx) && (recovered_626_q == 1'b0))) recovered_626_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_626_q == (esc_start_addr_reg_n_0__29_aa2b4b7)))) recovered_626_q <= (esc_start_addr_reg_n_0__29_aa2b4b7);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_2_082c694
  reg recovered_627_q = 1'b0;
  assign esc_start_addr_buf_reg_n_0__2_9c5ad66 = recovered_627_q;
  wire recovered_627_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_627_reset || (((SR) === 1'bx) && (recovered_627_q == 1'b0))) recovered_627_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_627_q == (esc_start_addr_reg_n_0__2_825dc7f)))) recovered_627_q <= (esc_start_addr_reg_n_0__2_825dc7f);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_30_8caa994
  reg recovered_628_q = 1'b0;
  assign p_0_in_0[18] = recovered_628_q;
  wire recovered_628_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_628_reset || (((SR) === 1'bx) && (recovered_628_q == 1'b0))) recovered_628_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_628_q == (esc_start_addr_reg_n_0__30_fa7e7f5)))) recovered_628_q <= (esc_start_addr_reg_n_0__30_fa7e7f5);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_31_1a131c7
  reg recovered_629_q = 1'b0;
  assign p_0_in_0[19] = recovered_629_q;
  wire recovered_629_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_629_reset || (((SR) === 1'bx) && (recovered_629_q == 1'b0))) recovered_629_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_629_q == (esc_start_addr_reg_n_0__31_6881f62)))) recovered_629_q <= (esc_start_addr_reg_n_0__31_6881f62);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_32_2795737
  reg recovered_630_q = 1'b0;
  assign p_0_in_0[20] = recovered_630_q;
  wire recovered_630_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_630_reset || (((SR) === 1'bx) && (recovered_630_q == 1'b0))) recovered_630_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_630_q == (esc_start_addr_reg_n_0__32_d304ae3)))) recovered_630_q <= (esc_start_addr_reg_n_0__32_d304ae3);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_33_4b8ccf9
  reg recovered_631_q = 1'b0;
  assign p_0_in_0[21] = recovered_631_q;
  wire recovered_631_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_631_reset || (((SR) === 1'bx) && (recovered_631_q == 1'b0))) recovered_631_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_631_q == (esc_start_addr_reg_n_0__33_e2508d5)))) recovered_631_q <= (esc_start_addr_reg_n_0__33_e2508d5);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_34_7150e17
  reg recovered_632_q = 1'b0;
  assign p_0_in_0[22] = recovered_632_q;
  wire recovered_632_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_632_reset || (((SR) === 1'bx) && (recovered_632_q == 1'b0))) recovered_632_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_632_q == (esc_start_addr_reg_n_0__34_7048a69)))) recovered_632_q <= (esc_start_addr_reg_n_0__34_7048a69);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_35_d0a2706
  reg recovered_633_q = 1'b0;
  assign p_0_in_0[23] = recovered_633_q;
  wire recovered_633_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_633_reset || (((SR) === 1'bx) && (recovered_633_q == 1'b0))) recovered_633_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_633_q == (esc_start_addr_reg_n_0__35_e55187f)))) recovered_633_q <= (esc_start_addr_reg_n_0__35_e55187f);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_36_b4c8e63
  reg recovered_634_q = 1'b0;
  assign p_0_in_0[24] = recovered_634_q;
  wire recovered_634_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_634_reset || (((SR) === 1'bx) && (recovered_634_q == 1'b0))) recovered_634_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_634_q == (esc_start_addr_reg_n_0__36_1b35e42)))) recovered_634_q <= (esc_start_addr_reg_n_0__36_1b35e42);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_37_705a104
  reg recovered_635_q = 1'b0;
  assign p_0_in_0[25] = recovered_635_q;
  wire recovered_635_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_635_reset || (((SR) === 1'bx) && (recovered_635_q == 1'b0))) recovered_635_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_635_q == (esc_start_addr_reg_n_0__37_49e2d9d)))) recovered_635_q <= (esc_start_addr_reg_n_0__37_49e2d9d);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_38_d0a6ff0
  reg recovered_636_q = 1'b0;
  assign p_0_in_0[26] = recovered_636_q;
  wire recovered_636_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_636_reset || (((SR) === 1'bx) && (recovered_636_q == 1'b0))) recovered_636_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_636_q == (esc_start_addr_reg_n_0__38_abcede3)))) recovered_636_q <= (esc_start_addr_reg_n_0__38_abcede3);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_39_13cec87
  reg recovered_637_q = 1'b0;
  assign p_0_in_0[27] = recovered_637_q;
  wire recovered_637_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_637_reset || (((SR) === 1'bx) && (recovered_637_q == 1'b0))) recovered_637_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_637_q == (esc_start_addr_reg_n_0__39_9f399ca)))) recovered_637_q <= (esc_start_addr_reg_n_0__39_9f399ca);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_3_5722577
  reg recovered_638_q = 1'b0;
  assign esc_start_addr_buf_reg_n_0__3_6d1c7eb = recovered_638_q;
  wire recovered_638_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_638_reset || (((SR) === 1'bx) && (recovered_638_q == 1'b0))) recovered_638_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_638_q == (esc_start_addr_reg_n_0__3_d6f6925)))) recovered_638_q <= (esc_start_addr_reg_n_0__3_d6f6925);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_40_cfa6396
  reg recovered_639_q = 1'b0;
  assign p_0_in_0[28] = recovered_639_q;
  wire recovered_639_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_639_reset || (((SR) === 1'bx) && (recovered_639_q == 1'b0))) recovered_639_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_639_q == (esc_start_addr_reg_n_0__40_44358a2)))) recovered_639_q <= (esc_start_addr_reg_n_0__40_44358a2);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_41_f35c554
  reg recovered_640_q = 1'b0;
  assign p_0_in_0[29] = recovered_640_q;
  wire recovered_640_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_640_reset || (((SR) === 1'bx) && (recovered_640_q == 1'b0))) recovered_640_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_640_q == (esc_start_addr_reg_n_0__41_aca3f17)))) recovered_640_q <= (esc_start_addr_reg_n_0__41_aca3f17);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_42_493b54a
  reg recovered_641_q = 1'b0;
  assign p_0_in_0[30] = recovered_641_q;
  wire recovered_641_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_641_reset || (((SR) === 1'bx) && (recovered_641_q == 1'b0))) recovered_641_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_641_q == (esc_start_addr_reg_n_0__42_a3d52cc)))) recovered_641_q <= (esc_start_addr_reg_n_0__42_a3d52cc);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_43_57a9067
  reg recovered_642_q = 1'b0;
  assign p_0_in_0[31] = recovered_642_q;
  wire recovered_642_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_642_reset || (((SR) === 1'bx) && (recovered_642_q == 1'b0))) recovered_642_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_642_q == (esc_start_addr_reg_n_0__43_eeeef11)))) recovered_642_q <= (esc_start_addr_reg_n_0__43_eeeef11);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_44_47cb090
  reg recovered_643_q = 1'b0;
  assign p_0_in_0[32] = recovered_643_q;
  wire recovered_643_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_643_reset || (((SR) === 1'bx) && (recovered_643_q == 1'b0))) recovered_643_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_643_q == (esc_start_addr_reg_n_0__44_91d3e92)))) recovered_643_q <= (esc_start_addr_reg_n_0__44_91d3e92);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_45_4b1289d
  reg recovered_644_q = 1'b0;
  assign p_0_in_0[33] = recovered_644_q;
  wire recovered_644_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_644_reset || (((SR) === 1'bx) && (recovered_644_q == 1'b0))) recovered_644_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_644_q == (esc_start_addr_reg_n_0__45_c02f4ba)))) recovered_644_q <= (esc_start_addr_reg_n_0__45_c02f4ba);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_46_13eebf6
  reg recovered_645_q = 1'b0;
  assign p_0_in_0[34] = recovered_645_q;
  wire recovered_645_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_645_reset || (((SR) === 1'bx) && (recovered_645_q == 1'b0))) recovered_645_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_645_q == (esc_start_addr_reg_n_0__46_ffff99b)))) recovered_645_q <= (esc_start_addr_reg_n_0__46_ffff99b);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_47_c9196c2
  reg recovered_646_q = 1'b0;
  assign p_0_in_0[35] = recovered_646_q;
  wire recovered_646_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_646_reset || (((SR) === 1'bx) && (recovered_646_q == 1'b0))) recovered_646_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_646_q == (esc_start_addr_reg_n_0__47_38b6f54)))) recovered_646_q <= (esc_start_addr_reg_n_0__47_38b6f54);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_48_94fa1b3
  reg recovered_647_q = 1'b0;
  assign p_0_in_0[36] = recovered_647_q;
  wire recovered_647_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_647_reset || (((SR) === 1'bx) && (recovered_647_q == 1'b0))) recovered_647_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_647_q == (esc_start_addr_reg_n_0__48_bba970f)))) recovered_647_q <= (esc_start_addr_reg_n_0__48_bba970f);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_49_a47682e
  reg recovered_648_q = 1'b0;
  assign p_0_in_0[37] = recovered_648_q;
  wire recovered_648_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_648_reset || (((SR) === 1'bx) && (recovered_648_q == 1'b0))) recovered_648_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_648_q == (esc_start_addr_reg_n_0__49_f51d0fb)))) recovered_648_q <= (esc_start_addr_reg_n_0__49_f51d0fb);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_4_7c636d8
  reg recovered_649_q = 1'b0;
  assign esc_start_addr_buf_reg_n_0__4_55d009f = recovered_649_q;
  wire recovered_649_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_649_reset || (((SR) === 1'bx) && (recovered_649_q == 1'b0))) recovered_649_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_649_q == (esc_start_addr_reg_n_0__4_35bfd51)))) recovered_649_q <= (esc_start_addr_reg_n_0__4_35bfd51);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_50_8d36c46
  reg recovered_650_q = 1'b0;
  assign p_0_in_0[38] = recovered_650_q;
  wire recovered_650_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_650_reset || (((SR) === 1'bx) && (recovered_650_q == 1'b0))) recovered_650_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_650_q == (esc_start_addr_reg_n_0__50_4a0d627)))) recovered_650_q <= (esc_start_addr_reg_n_0__50_4a0d627);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_51_bee20e7
  reg recovered_651_q = 1'b0;
  assign p_0_in_0[39] = recovered_651_q;
  wire recovered_651_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_651_reset || (((SR) === 1'bx) && (recovered_651_q == 1'b0))) recovered_651_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_651_q == (esc_start_addr_reg_n_0__51_71ee3d6)))) recovered_651_q <= (esc_start_addr_reg_n_0__51_71ee3d6);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_52_077739a
  reg recovered_652_q = 1'b0;
  assign p_0_in_0[40] = recovered_652_q;
  wire recovered_652_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_652_reset || (((SR) === 1'bx) && (recovered_652_q == 1'b0))) recovered_652_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_652_q == (esc_start_addr_reg_n_0__52_4ddab7f)))) recovered_652_q <= (esc_start_addr_reg_n_0__52_4ddab7f);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_53_c601f9d
  reg recovered_653_q = 1'b0;
  assign p_0_in_0[41] = recovered_653_q;
  wire recovered_653_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_653_reset || (((SR) === 1'bx) && (recovered_653_q == 1'b0))) recovered_653_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_653_q == (esc_start_addr_reg_n_0__53_391e956)))) recovered_653_q <= (esc_start_addr_reg_n_0__53_391e956);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_54_53a449f
  reg recovered_654_q = 1'b0;
  assign p_0_in_0[42] = recovered_654_q;
  wire recovered_654_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_654_reset || (((SR) === 1'bx) && (recovered_654_q == 1'b0))) recovered_654_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_654_q == (esc_start_addr_reg_n_0__54_6ca5236)))) recovered_654_q <= (esc_start_addr_reg_n_0__54_6ca5236);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_55_a994938
  reg recovered_655_q = 1'b0;
  assign p_0_in_0[43] = recovered_655_q;
  wire recovered_655_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_655_reset || (((SR) === 1'bx) && (recovered_655_q == 1'b0))) recovered_655_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_655_q == (esc_start_addr_reg_n_0__55_f2a438b)))) recovered_655_q <= (esc_start_addr_reg_n_0__55_f2a438b);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_56_df07d66
  reg recovered_656_q = 1'b0;
  assign p_0_in_0[44] = recovered_656_q;
  wire recovered_656_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_656_reset || (((SR) === 1'bx) && (recovered_656_q == 1'b0))) recovered_656_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_656_q == (esc_start_addr_reg_n_0__56_ed05e9e)))) recovered_656_q <= (esc_start_addr_reg_n_0__56_ed05e9e);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_57_78f0f98
  reg recovered_657_q = 1'b0;
  assign p_0_in_0[45] = recovered_657_q;
  wire recovered_657_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_657_reset || (((SR) === 1'bx) && (recovered_657_q == 1'b0))) recovered_657_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_657_q == (esc_start_addr_reg_n_0__57_897c5a0)))) recovered_657_q <= (esc_start_addr_reg_n_0__57_897c5a0);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_58_bd41cf9
  reg recovered_658_q = 1'b0;
  assign p_0_in_0[46] = recovered_658_q;
  wire recovered_658_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_658_reset || (((SR) === 1'bx) && (recovered_658_q == 1'b0))) recovered_658_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_658_q == (esc_start_addr_reg_n_0__58_94d4f4b)))) recovered_658_q <= (esc_start_addr_reg_n_0__58_94d4f4b);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_59_7d04614
  reg recovered_659_q = 1'b0;
  assign p_0_in_0[47] = recovered_659_q;
  wire recovered_659_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_659_reset || (((SR) === 1'bx) && (recovered_659_q == 1'b0))) recovered_659_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_659_q == (esc_start_addr_reg_n_0__59_91cd7d0)))) recovered_659_q <= (esc_start_addr_reg_n_0__59_91cd7d0);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_5_a4b45bd
  reg recovered_660_q = 1'b0;
  assign esc_start_addr_buf_reg_n_0__5_f6b4823 = recovered_660_q;
  wire recovered_660_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_660_reset || (((SR) === 1'bx) && (recovered_660_q == 1'b0))) recovered_660_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_660_q == (esc_start_addr_reg_n_0__5_51bdd86)))) recovered_660_q <= (esc_start_addr_reg_n_0__5_51bdd86);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_60_02ad52b
  reg recovered_661_q = 1'b0;
  assign p_0_in_0[48] = recovered_661_q;
  wire recovered_661_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_661_reset || (((SR) === 1'bx) && (recovered_661_q == 1'b0))) recovered_661_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_661_q == (esc_start_addr_reg_n_0__60_9bfecb1)))) recovered_661_q <= (esc_start_addr_reg_n_0__60_9bfecb1);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_61_27b2194
  reg recovered_662_q = 1'b0;
  assign p_0_in_0[49] = recovered_662_q;
  wire recovered_662_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_662_reset || (((SR) === 1'bx) && (recovered_662_q == 1'b0))) recovered_662_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_662_q == (esc_start_addr_reg_n_0__61_d0861cf)))) recovered_662_q <= (esc_start_addr_reg_n_0__61_d0861cf);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_62_ccefb96
  reg recovered_663_q = 1'b0;
  assign p_0_in_0[50] = recovered_663_q;
  wire recovered_663_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_663_reset || (((SR) === 1'bx) && (recovered_663_q == 1'b0))) recovered_663_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_663_q == (esc_start_addr_reg_n_0__62_067c30f)))) recovered_663_q <= (esc_start_addr_reg_n_0__62_067c30f);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_63_b2f2416
  reg recovered_664_q = 1'b0;
  assign p_0_in_0[51] = recovered_664_q;
  wire recovered_664_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_664_reset || (((SR) === 1'bx) && (recovered_664_q == 1'b0))) recovered_664_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_664_q == (esc_start_addr_reg_n_0__63_6c9d71f)))) recovered_664_q <= (esc_start_addr_reg_n_0__63_6c9d71f);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_6_820214d
  reg recovered_665_q = 1'b0;
  assign esc_start_addr_buf_reg_n_0__6_5592b8e = recovered_665_q;
  wire recovered_665_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_665_reset || (((SR) === 1'bx) && (recovered_665_q == 1'b0))) recovered_665_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_665_q == (esc_start_addr_reg_n_0__6_85a28ac)))) recovered_665_q <= (esc_start_addr_reg_n_0__6_85a28ac);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_7_68ccdf6
  reg recovered_666_q = 1'b0;
  assign esc_start_addr_buf_reg_n_0__7_8e93ddd = recovered_666_q;
  wire recovered_666_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_666_reset || (((SR) === 1'bx) && (recovered_666_q == 1'b0))) recovered_666_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_666_q == (esc_start_addr_reg_n_0__7_2aaf228)))) recovered_666_q <= (esc_start_addr_reg_n_0__7_2aaf228);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_8_6aa22b1
  reg recovered_667_q = 1'b0;
  assign esc_start_addr_buf_reg_n_0__8_3056d1d = recovered_667_q;
  wire recovered_667_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_667_reset || (((SR) === 1'bx) && (recovered_667_q == 1'b0))) recovered_667_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_667_q == (esc_start_addr_reg_n_0__8_22baed7)))) recovered_667_q <= (esc_start_addr_reg_n_0__8_22baed7);
  end

  // Reconstructed FDRE: esc_start_addr_buf_reg_9_5b81e66
  reg recovered_668_q = 1'b0;
  assign esc_start_addr_buf_reg_n_0__9_d78d0ac = recovered_668_q;
  wire recovered_668_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_668_reset || (((SR) === 1'bx) && (recovered_668_q == 1'b0))) recovered_668_q <= 1'b0;
    else if ((next_wreq) || ((next_wreq) === 1'bz) || (((next_wreq) === 1'bx) && (recovered_668_q == (esc_start_addr_reg_n_0__9_b0ff003)))) recovered_668_q <= (esc_start_addr_reg_n_0__9_b0ff003);
  end

  // Reconstructed FDRE: esc_start_addr_reg_10_457d9e3
  reg recovered_669_q = 1'b0;
  assign esc_start_addr_reg_n_0__10_7dfdb33 = recovered_669_q;
  wire recovered_669_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_669_reset || (((SR) === 1'bx) && (recovered_669_q == 1'b0))) recovered_669_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_669_q == (fifo_wreq_n_59)))) recovered_669_q <= (fifo_wreq_n_59);
  end

  // Reconstructed FDRE: esc_start_addr_reg_11_ad3183e
  reg recovered_670_q = 1'b0;
  assign esc_start_addr_reg_n_0__11_93897a8 = recovered_670_q;
  wire recovered_670_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_670_reset || (((SR) === 1'bx) && (recovered_670_q == 1'b0))) recovered_670_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_670_q == (fifo_wreq_n_58)))) recovered_670_q <= (fifo_wreq_n_58);
  end

  // Reconstructed FDRE: esc_start_addr_reg_12_9fbd8b9
  reg recovered_671_q = 1'b0;
  assign esc_start_addr_reg_n_0__12_0ffbef5 = recovered_671_q;
  wire recovered_671_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_671_reset || (((SR) === 1'bx) && (recovered_671_q == 1'b0))) recovered_671_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_671_q == (fifo_wreq_n_57)))) recovered_671_q <= (fifo_wreq_n_57);
  end

  // Reconstructed FDRE: esc_start_addr_reg_13_65dd198
  reg recovered_672_q = 1'b0;
  assign esc_start_addr_reg_n_0__13_f3dfe34 = recovered_672_q;
  wire recovered_672_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_672_reset || (((SR) === 1'bx) && (recovered_672_q == 1'b0))) recovered_672_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_672_q == (fifo_wreq_n_56)))) recovered_672_q <= (fifo_wreq_n_56);
  end

  // Reconstructed FDRE: esc_start_addr_reg_14_4a83774
  reg recovered_673_q = 1'b0;
  assign esc_start_addr_reg_n_0__14_726da08 = recovered_673_q;
  wire recovered_673_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_673_reset || (((SR) === 1'bx) && (recovered_673_q == 1'b0))) recovered_673_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_673_q == (fifo_wreq_n_55)))) recovered_673_q <= (fifo_wreq_n_55);
  end

  // Reconstructed FDRE: esc_start_addr_reg_15_cb568f8
  reg recovered_674_q = 1'b0;
  assign esc_start_addr_reg_n_0__15_3a25f9c = recovered_674_q;
  wire recovered_674_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_674_reset || (((SR) === 1'bx) && (recovered_674_q == 1'b0))) recovered_674_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_674_q == (fifo_wreq_n_54)))) recovered_674_q <= (fifo_wreq_n_54);
  end

  // Reconstructed FDRE: esc_start_addr_reg_16_7a3d8ca
  reg recovered_675_q = 1'b0;
  assign esc_start_addr_reg_n_0__16_c2276cc = recovered_675_q;
  wire recovered_675_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_675_reset || (((SR) === 1'bx) && (recovered_675_q == 1'b0))) recovered_675_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_675_q == (fifo_wreq_n_53)))) recovered_675_q <= (fifo_wreq_n_53);
  end

  // Reconstructed FDRE: esc_start_addr_reg_17_837eb3b
  reg recovered_676_q = 1'b0;
  assign esc_start_addr_reg_n_0__17_a7c7f14 = recovered_676_q;
  wire recovered_676_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_676_reset || (((SR) === 1'bx) && (recovered_676_q == 1'b0))) recovered_676_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_676_q == (fifo_wreq_n_52)))) recovered_676_q <= (fifo_wreq_n_52);
  end

  // Reconstructed FDRE: esc_start_addr_reg_18_89f2731
  reg recovered_677_q = 1'b0;
  assign esc_start_addr_reg_n_0__18_7d4f45f = recovered_677_q;
  wire recovered_677_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_677_reset || (((SR) === 1'bx) && (recovered_677_q == 1'b0))) recovered_677_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_677_q == (fifo_wreq_n_51)))) recovered_677_q <= (fifo_wreq_n_51);
  end

  // Reconstructed FDRE: esc_start_addr_reg_19_d530e37
  reg recovered_678_q = 1'b0;
  assign esc_start_addr_reg_n_0__19_3510eae = recovered_678_q;
  wire recovered_678_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_678_reset || (((SR) === 1'bx) && (recovered_678_q == 1'b0))) recovered_678_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_678_q == (fifo_wreq_n_50)))) recovered_678_q <= (fifo_wreq_n_50);
  end

  // Reconstructed FDRE: esc_start_addr_reg_20_bdd4066
  reg recovered_679_q = 1'b0;
  assign esc_start_addr_reg_n_0__20_a055fe3 = recovered_679_q;
  wire recovered_679_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_679_reset || (((SR) === 1'bx) && (recovered_679_q == 1'b0))) recovered_679_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_679_q == (fifo_wreq_n_49)))) recovered_679_q <= (fifo_wreq_n_49);
  end

  // Reconstructed FDRE: esc_start_addr_reg_21_1b0d8c6
  reg recovered_680_q = 1'b0;
  assign esc_start_addr_reg_n_0__21_9efa866 = recovered_680_q;
  wire recovered_680_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_680_reset || (((SR) === 1'bx) && (recovered_680_q == 1'b0))) recovered_680_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_680_q == (fifo_wreq_n_48)))) recovered_680_q <= (fifo_wreq_n_48);
  end

  // Reconstructed FDRE: esc_start_addr_reg_22_e91e359
  reg recovered_681_q = 1'b0;
  assign esc_start_addr_reg_n_0__22_ba17a60 = recovered_681_q;
  wire recovered_681_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_681_reset || (((SR) === 1'bx) && (recovered_681_q == 1'b0))) recovered_681_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_681_q == (fifo_wreq_n_47)))) recovered_681_q <= (fifo_wreq_n_47);
  end

  // Reconstructed FDRE: esc_start_addr_reg_23_bb22d8f
  reg recovered_682_q = 1'b0;
  assign esc_start_addr_reg_n_0__23_907ba78 = recovered_682_q;
  wire recovered_682_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_682_reset || (((SR) === 1'bx) && (recovered_682_q == 1'b0))) recovered_682_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_682_q == (fifo_wreq_n_46)))) recovered_682_q <= (fifo_wreq_n_46);
  end

  // Reconstructed FDRE: esc_start_addr_reg_24_5d0ca29
  reg recovered_683_q = 1'b0;
  assign esc_start_addr_reg_n_0__24_1d34d3b = recovered_683_q;
  wire recovered_683_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_683_reset || (((SR) === 1'bx) && (recovered_683_q == 1'b0))) recovered_683_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_683_q == (fifo_wreq_n_45)))) recovered_683_q <= (fifo_wreq_n_45);
  end

  // Reconstructed FDRE: esc_start_addr_reg_25_45a9d76
  reg recovered_684_q = 1'b0;
  assign esc_start_addr_reg_n_0__25_b477c1e = recovered_684_q;
  wire recovered_684_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_684_reset || (((SR) === 1'bx) && (recovered_684_q == 1'b0))) recovered_684_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_684_q == (fifo_wreq_n_44)))) recovered_684_q <= (fifo_wreq_n_44);
  end

  // Reconstructed FDRE: esc_start_addr_reg_26_aca634c
  reg recovered_685_q = 1'b0;
  assign esc_start_addr_reg_n_0__26_5efe7d3 = recovered_685_q;
  wire recovered_685_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_685_reset || (((SR) === 1'bx) && (recovered_685_q == 1'b0))) recovered_685_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_685_q == (fifo_wreq_n_43)))) recovered_685_q <= (fifo_wreq_n_43);
  end

  // Reconstructed FDRE: esc_start_addr_reg_27_46f0195
  reg recovered_686_q = 1'b0;
  assign esc_start_addr_reg_n_0__27_4bb8d27 = recovered_686_q;
  wire recovered_686_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_686_reset || (((SR) === 1'bx) && (recovered_686_q == 1'b0))) recovered_686_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_686_q == (fifo_wreq_n_42)))) recovered_686_q <= (fifo_wreq_n_42);
  end

  // Reconstructed FDRE: esc_start_addr_reg_28_3ca87ca
  reg recovered_687_q = 1'b0;
  assign esc_start_addr_reg_n_0__28_0abd4bb = recovered_687_q;
  wire recovered_687_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_687_reset || (((SR) === 1'bx) && (recovered_687_q == 1'b0))) recovered_687_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_687_q == (fifo_wreq_n_41)))) recovered_687_q <= (fifo_wreq_n_41);
  end

  // Reconstructed FDRE: esc_start_addr_reg_29_edf9cba
  reg recovered_688_q = 1'b0;
  assign esc_start_addr_reg_n_0__29_aa2b4b7 = recovered_688_q;
  wire recovered_688_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_688_reset || (((SR) === 1'bx) && (recovered_688_q == 1'b0))) recovered_688_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_688_q == (fifo_wreq_n_40)))) recovered_688_q <= (fifo_wreq_n_40);
  end

  // Reconstructed FDRE: esc_start_addr_reg_2_b8ec6b1
  reg recovered_689_q = 1'b0;
  assign esc_start_addr_reg_n_0__2_825dc7f = recovered_689_q;
  wire recovered_689_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_689_reset || (((SR) === 1'bx) && (recovered_689_q == 1'b0))) recovered_689_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_689_q == (fifo_wreq_n_67)))) recovered_689_q <= (fifo_wreq_n_67);
  end

  // Reconstructed FDRE: esc_start_addr_reg_30_d4afc87
  reg recovered_690_q = 1'b0;
  assign esc_start_addr_reg_n_0__30_fa7e7f5 = recovered_690_q;
  wire recovered_690_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_690_reset || (((SR) === 1'bx) && (recovered_690_q == 1'b0))) recovered_690_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_690_q == (fifo_wreq_n_39)))) recovered_690_q <= (fifo_wreq_n_39);
  end

  // Reconstructed FDRE: esc_start_addr_reg_31_520d09f
  reg recovered_691_q = 1'b0;
  assign esc_start_addr_reg_n_0__31_6881f62 = recovered_691_q;
  wire recovered_691_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_691_reset || (((SR) === 1'bx) && (recovered_691_q == 1'b0))) recovered_691_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_691_q == (fifo_wreq_n_38)))) recovered_691_q <= (fifo_wreq_n_38);
  end

  // Reconstructed FDRE: esc_start_addr_reg_32_2a538fa
  reg recovered_692_q = 1'b0;
  assign esc_start_addr_reg_n_0__32_d304ae3 = recovered_692_q;
  wire recovered_692_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_692_reset || (((SR) === 1'bx) && (recovered_692_q == 1'b0))) recovered_692_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_692_q == (fifo_wreq_n_37)))) recovered_692_q <= (fifo_wreq_n_37);
  end

  // Reconstructed FDRE: esc_start_addr_reg_33_ad0b578
  reg recovered_693_q = 1'b0;
  assign esc_start_addr_reg_n_0__33_e2508d5 = recovered_693_q;
  wire recovered_693_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_693_reset || (((SR) === 1'bx) && (recovered_693_q == 1'b0))) recovered_693_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_693_q == (fifo_wreq_n_36)))) recovered_693_q <= (fifo_wreq_n_36);
  end

  // Reconstructed FDRE: esc_start_addr_reg_34_803f937
  reg recovered_694_q = 1'b0;
  assign esc_start_addr_reg_n_0__34_7048a69 = recovered_694_q;
  wire recovered_694_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_694_reset || (((SR) === 1'bx) && (recovered_694_q == 1'b0))) recovered_694_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_694_q == (fifo_wreq_n_35)))) recovered_694_q <= (fifo_wreq_n_35);
  end

  // Reconstructed FDRE: esc_start_addr_reg_35_1b6cecf
  reg recovered_695_q = 1'b0;
  assign esc_start_addr_reg_n_0__35_e55187f = recovered_695_q;
  wire recovered_695_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_695_reset || (((SR) === 1'bx) && (recovered_695_q == 1'b0))) recovered_695_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_695_q == (fifo_wreq_n_34)))) recovered_695_q <= (fifo_wreq_n_34);
  end

  // Reconstructed FDRE: esc_start_addr_reg_36_a7fd7a3
  reg recovered_696_q = 1'b0;
  assign esc_start_addr_reg_n_0__36_1b35e42 = recovered_696_q;
  wire recovered_696_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_696_reset || (((SR) === 1'bx) && (recovered_696_q == 1'b0))) recovered_696_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_696_q == (fifo_wreq_n_33)))) recovered_696_q <= (fifo_wreq_n_33);
  end

  // Reconstructed FDRE: esc_start_addr_reg_37_7e36b0c
  reg recovered_697_q = 1'b0;
  assign esc_start_addr_reg_n_0__37_49e2d9d = recovered_697_q;
  wire recovered_697_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_697_reset || (((SR) === 1'bx) && (recovered_697_q == 1'b0))) recovered_697_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_697_q == (fifo_wreq_n_32)))) recovered_697_q <= (fifo_wreq_n_32);
  end

  // Reconstructed FDRE: esc_start_addr_reg_38_e2c4951
  reg recovered_698_q = 1'b0;
  assign esc_start_addr_reg_n_0__38_abcede3 = recovered_698_q;
  wire recovered_698_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_698_reset || (((SR) === 1'bx) && (recovered_698_q == 1'b0))) recovered_698_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_698_q == (fifo_wreq_n_31)))) recovered_698_q <= (fifo_wreq_n_31);
  end

  // Reconstructed FDRE: esc_start_addr_reg_39_6e55e45
  reg recovered_699_q = 1'b0;
  assign esc_start_addr_reg_n_0__39_9f399ca = recovered_699_q;
  wire recovered_699_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_699_reset || (((SR) === 1'bx) && (recovered_699_q == 1'b0))) recovered_699_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_699_q == (fifo_wreq_n_30)))) recovered_699_q <= (fifo_wreq_n_30);
  end

  // Reconstructed FDRE: esc_start_addr_reg_3_60a6e45
  reg recovered_700_q = 1'b0;
  assign esc_start_addr_reg_n_0__3_d6f6925 = recovered_700_q;
  wire recovered_700_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_700_reset || (((SR) === 1'bx) && (recovered_700_q == 1'b0))) recovered_700_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_700_q == (fifo_wreq_n_66)))) recovered_700_q <= (fifo_wreq_n_66);
  end

  // Reconstructed FDRE: esc_start_addr_reg_40_f8bea88
  reg recovered_701_q = 1'b0;
  assign esc_start_addr_reg_n_0__40_44358a2 = recovered_701_q;
  wire recovered_701_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_701_reset || (((SR) === 1'bx) && (recovered_701_q == 1'b0))) recovered_701_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_701_q == (fifo_wreq_n_29)))) recovered_701_q <= (fifo_wreq_n_29);
  end

  // Reconstructed FDRE: esc_start_addr_reg_41_bda34c1
  reg recovered_702_q = 1'b0;
  assign esc_start_addr_reg_n_0__41_aca3f17 = recovered_702_q;
  wire recovered_702_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_702_reset || (((SR) === 1'bx) && (recovered_702_q == 1'b0))) recovered_702_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_702_q == (fifo_wreq_n_28)))) recovered_702_q <= (fifo_wreq_n_28);
  end

  // Reconstructed FDRE: esc_start_addr_reg_42_4f06092
  reg recovered_703_q = 1'b0;
  assign esc_start_addr_reg_n_0__42_a3d52cc = recovered_703_q;
  wire recovered_703_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_703_reset || (((SR) === 1'bx) && (recovered_703_q == 1'b0))) recovered_703_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_703_q == (fifo_wreq_n_27)))) recovered_703_q <= (fifo_wreq_n_27);
  end

  // Reconstructed FDRE: esc_start_addr_reg_43_dfeefb1
  reg recovered_704_q = 1'b0;
  assign esc_start_addr_reg_n_0__43_eeeef11 = recovered_704_q;
  wire recovered_704_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_704_reset || (((SR) === 1'bx) && (recovered_704_q == 1'b0))) recovered_704_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_704_q == (fifo_wreq_n_26)))) recovered_704_q <= (fifo_wreq_n_26);
  end

  // Reconstructed FDRE: esc_start_addr_reg_44_28f9044
  reg recovered_705_q = 1'b0;
  assign esc_start_addr_reg_n_0__44_91d3e92 = recovered_705_q;
  wire recovered_705_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_705_reset || (((SR) === 1'bx) && (recovered_705_q == 1'b0))) recovered_705_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_705_q == (fifo_wreq_n_25)))) recovered_705_q <= (fifo_wreq_n_25);
  end

  // Reconstructed FDRE: esc_start_addr_reg_45_bedc5f6
  reg recovered_706_q = 1'b0;
  assign esc_start_addr_reg_n_0__45_c02f4ba = recovered_706_q;
  wire recovered_706_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_706_reset || (((SR) === 1'bx) && (recovered_706_q == 1'b0))) recovered_706_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_706_q == (fifo_wreq_n_24)))) recovered_706_q <= (fifo_wreq_n_24);
  end

  // Reconstructed FDRE: esc_start_addr_reg_46_5dce63c
  reg recovered_707_q = 1'b0;
  assign esc_start_addr_reg_n_0__46_ffff99b = recovered_707_q;
  wire recovered_707_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_707_reset || (((SR) === 1'bx) && (recovered_707_q == 1'b0))) recovered_707_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_707_q == (fifo_wreq_n_23)))) recovered_707_q <= (fifo_wreq_n_23);
  end

  // Reconstructed FDRE: esc_start_addr_reg_47_21e3309
  reg recovered_708_q = 1'b0;
  assign esc_start_addr_reg_n_0__47_38b6f54 = recovered_708_q;
  wire recovered_708_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_708_reset || (((SR) === 1'bx) && (recovered_708_q == 1'b0))) recovered_708_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_708_q == (fifo_wreq_n_22)))) recovered_708_q <= (fifo_wreq_n_22);
  end

  // Reconstructed FDRE: esc_start_addr_reg_48_d3944c4
  reg recovered_709_q = 1'b0;
  assign esc_start_addr_reg_n_0__48_bba970f = recovered_709_q;
  wire recovered_709_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_709_reset || (((SR) === 1'bx) && (recovered_709_q == 1'b0))) recovered_709_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_709_q == (fifo_wreq_n_21)))) recovered_709_q <= (fifo_wreq_n_21);
  end

  // Reconstructed FDRE: esc_start_addr_reg_49_bdae311
  reg recovered_710_q = 1'b0;
  assign esc_start_addr_reg_n_0__49_f51d0fb = recovered_710_q;
  wire recovered_710_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_710_reset || (((SR) === 1'bx) && (recovered_710_q == 1'b0))) recovered_710_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_710_q == (fifo_wreq_n_20)))) recovered_710_q <= (fifo_wreq_n_20);
  end

  // Reconstructed FDRE: esc_start_addr_reg_4_8894f84
  reg recovered_711_q = 1'b0;
  assign esc_start_addr_reg_n_0__4_35bfd51 = recovered_711_q;
  wire recovered_711_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_711_reset || (((SR) === 1'bx) && (recovered_711_q == 1'b0))) recovered_711_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_711_q == (fifo_wreq_n_65)))) recovered_711_q <= (fifo_wreq_n_65);
  end

  // Reconstructed FDRE: esc_start_addr_reg_50_4431db9
  reg recovered_712_q = 1'b0;
  assign esc_start_addr_reg_n_0__50_4a0d627 = recovered_712_q;
  wire recovered_712_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_712_reset || (((SR) === 1'bx) && (recovered_712_q == 1'b0))) recovered_712_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_712_q == (fifo_wreq_n_19)))) recovered_712_q <= (fifo_wreq_n_19);
  end

  // Reconstructed FDRE: esc_start_addr_reg_51_a9c422a
  reg recovered_713_q = 1'b0;
  assign esc_start_addr_reg_n_0__51_71ee3d6 = recovered_713_q;
  wire recovered_713_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_713_reset || (((SR) === 1'bx) && (recovered_713_q == 1'b0))) recovered_713_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_713_q == (fifo_wreq_n_18)))) recovered_713_q <= (fifo_wreq_n_18);
  end

  // Reconstructed FDRE: esc_start_addr_reg_52_f328699
  reg recovered_714_q = 1'b0;
  assign esc_start_addr_reg_n_0__52_4ddab7f = recovered_714_q;
  wire recovered_714_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_714_reset || (((SR) === 1'bx) && (recovered_714_q == 1'b0))) recovered_714_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_714_q == (fifo_wreq_n_17)))) recovered_714_q <= (fifo_wreq_n_17);
  end

  // Reconstructed FDRE: esc_start_addr_reg_53_50d44c0
  reg recovered_715_q = 1'b0;
  assign esc_start_addr_reg_n_0__53_391e956 = recovered_715_q;
  wire recovered_715_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_715_reset || (((SR) === 1'bx) && (recovered_715_q == 1'b0))) recovered_715_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_715_q == (fifo_wreq_n_16)))) recovered_715_q <= (fifo_wreq_n_16);
  end

  // Reconstructed FDRE: esc_start_addr_reg_54_df6a146
  reg recovered_716_q = 1'b0;
  assign esc_start_addr_reg_n_0__54_6ca5236 = recovered_716_q;
  wire recovered_716_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_716_reset || (((SR) === 1'bx) && (recovered_716_q == 1'b0))) recovered_716_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_716_q == (fifo_wreq_n_15)))) recovered_716_q <= (fifo_wreq_n_15);
  end

  // Reconstructed FDRE: esc_start_addr_reg_55_1e49255
  reg recovered_717_q = 1'b0;
  assign esc_start_addr_reg_n_0__55_f2a438b = recovered_717_q;
  wire recovered_717_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_717_reset || (((SR) === 1'bx) && (recovered_717_q == 1'b0))) recovered_717_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_717_q == (fifo_wreq_n_14)))) recovered_717_q <= (fifo_wreq_n_14);
  end

  // Reconstructed FDRE: esc_start_addr_reg_56_5110125
  reg recovered_718_q = 1'b0;
  assign esc_start_addr_reg_n_0__56_ed05e9e = recovered_718_q;
  wire recovered_718_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_718_reset || (((SR) === 1'bx) && (recovered_718_q == 1'b0))) recovered_718_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_718_q == (fifo_wreq_n_13)))) recovered_718_q <= (fifo_wreq_n_13);
  end

  // Reconstructed FDRE: esc_start_addr_reg_57_04fec84
  reg recovered_719_q = 1'b0;
  assign esc_start_addr_reg_n_0__57_897c5a0 = recovered_719_q;
  wire recovered_719_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_719_reset || (((SR) === 1'bx) && (recovered_719_q == 1'b0))) recovered_719_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_719_q == (fifo_wreq_n_12)))) recovered_719_q <= (fifo_wreq_n_12);
  end

  // Reconstructed FDRE: esc_start_addr_reg_58_214ec4c
  reg recovered_720_q = 1'b0;
  assign esc_start_addr_reg_n_0__58_94d4f4b = recovered_720_q;
  wire recovered_720_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_720_reset || (((SR) === 1'bx) && (recovered_720_q == 1'b0))) recovered_720_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_720_q == (fifo_wreq_n_11)))) recovered_720_q <= (fifo_wreq_n_11);
  end

  // Reconstructed FDRE: esc_start_addr_reg_59_10571fe
  reg recovered_721_q = 1'b0;
  assign esc_start_addr_reg_n_0__59_91cd7d0 = recovered_721_q;
  wire recovered_721_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_721_reset || (((SR) === 1'bx) && (recovered_721_q == 1'b0))) recovered_721_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_721_q == (fifo_wreq_n_10)))) recovered_721_q <= (fifo_wreq_n_10);
  end

  // Reconstructed FDRE: esc_start_addr_reg_5_1ec2f85
  reg recovered_722_q = 1'b0;
  assign esc_start_addr_reg_n_0__5_51bdd86 = recovered_722_q;
  wire recovered_722_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_722_reset || (((SR) === 1'bx) && (recovered_722_q == 1'b0))) recovered_722_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_722_q == (fifo_wreq_n_64)))) recovered_722_q <= (fifo_wreq_n_64);
  end

  // Reconstructed FDRE: esc_start_addr_reg_60_1a8e42b
  reg recovered_723_q = 1'b0;
  assign esc_start_addr_reg_n_0__60_9bfecb1 = recovered_723_q;
  wire recovered_723_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_723_reset || (((SR) === 1'bx) && (recovered_723_q == 1'b0))) recovered_723_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_723_q == (fifo_wreq_n_9)))) recovered_723_q <= (fifo_wreq_n_9);
  end

  // Reconstructed FDRE: esc_start_addr_reg_61_5af9187
  reg recovered_724_q = 1'b0;
  assign esc_start_addr_reg_n_0__61_d0861cf = recovered_724_q;
  wire recovered_724_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_724_reset || (((SR) === 1'bx) && (recovered_724_q == 1'b0))) recovered_724_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_724_q == (fifo_wreq_n_8)))) recovered_724_q <= (fifo_wreq_n_8);
  end

  // Reconstructed FDRE: esc_start_addr_reg_62_d2f5ef6
  reg recovered_725_q = 1'b0;
  assign esc_start_addr_reg_n_0__62_067c30f = recovered_725_q;
  wire recovered_725_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_725_reset || (((SR) === 1'bx) && (recovered_725_q == 1'b0))) recovered_725_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_725_q == (fifo_wreq_n_7)))) recovered_725_q <= (fifo_wreq_n_7);
  end

  // Reconstructed FDRE: esc_start_addr_reg_63_67d8193
  reg recovered_726_q = 1'b0;
  assign esc_start_addr_reg_n_0__63_6c9d71f = recovered_726_q;
  wire recovered_726_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_726_reset || (((SR) === 1'bx) && (recovered_726_q == 1'b0))) recovered_726_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_726_q == (fifo_wreq_n_6)))) recovered_726_q <= (fifo_wreq_n_6);
  end

  // Reconstructed FDRE: esc_start_addr_reg_6_97564e7
  reg recovered_727_q = 1'b0;
  assign esc_start_addr_reg_n_0__6_85a28ac = recovered_727_q;
  wire recovered_727_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_727_reset || (((SR) === 1'bx) && (recovered_727_q == 1'b0))) recovered_727_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_727_q == (fifo_wreq_n_63)))) recovered_727_q <= (fifo_wreq_n_63);
  end

  // Reconstructed FDRE: esc_start_addr_reg_7_b648603
  reg recovered_728_q = 1'b0;
  assign esc_start_addr_reg_n_0__7_2aaf228 = recovered_728_q;
  wire recovered_728_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_728_reset || (((SR) === 1'bx) && (recovered_728_q == 1'b0))) recovered_728_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_728_q == (fifo_wreq_n_62)))) recovered_728_q <= (fifo_wreq_n_62);
  end

  // Reconstructed FDRE: esc_start_addr_reg_8_5e94b56
  reg recovered_729_q = 1'b0;
  assign esc_start_addr_reg_n_0__8_22baed7 = recovered_729_q;
  wire recovered_729_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_729_reset || (((SR) === 1'bx) && (recovered_729_q == 1'b0))) recovered_729_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_729_q == (fifo_wreq_n_61)))) recovered_729_q <= (fifo_wreq_n_61);
  end

  // Reconstructed FDRE: esc_start_addr_reg_9_151ab48
  reg recovered_730_q = 1'b0;
  assign esc_start_addr_reg_n_0__9_b0ff003 = recovered_730_q;
  wire recovered_730_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_730_reset || (((SR) === 1'bx) && (recovered_730_q == 1'b0))) recovered_730_q <= 1'b0;
    else if ((align_len0) || ((align_len0) === 1'bz) || (((align_len0) === 1'bx) && (recovered_730_q == (fifo_wreq_n_60)))) recovered_730_q <= (fifo_wreq_n_60);
  end

  // Reconstructed FDRE: wreq_handling_reg
  reg recovered_731_q = 1'b0;
  assign wreq_handling_reg_n_0 = recovered_731_q;
  wire recovered_731_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge ap_clk) begin
    if (recovered_731_reset || (((SR) === 1'bx) && (recovered_731_q == 1'b0))) recovered_731_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_731_q == (esc_bus_equal_gen_fifo_burst_n_65_9824fa3)))) recovered_731_q <= (esc_bus_equal_gen_fifo_burst_n_65_9824fa3);
  end

endmodule

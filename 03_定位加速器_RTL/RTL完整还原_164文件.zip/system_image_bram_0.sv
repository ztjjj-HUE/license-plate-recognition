// The supplied netlist omits system_image_bram_0_blk_mem_gen_v8_4_4.
// Restore that original IP before full-system elaboration; it has not been fabricated here.
// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_image_bram_0
   (clka,
    rsta,
    ena,
    wea,
    addra,
    dina,
    douta,
    rsta_busy,
    lopt);
    input clka;
   input rsta;
   input ena;
   input [3:0]wea;
   input [31:0]addra;
   input [31:0]dina;
   output [31:0]douta;
  output rsta_busy;
  input lopt;

  wire [31:0]addra;
  wire clka;
  wire [31:0]dina;
  wire [31:0]douta;
  wire ena;
  wire lopt;
  wire [3:0]wea;
  wire [31:0]NLW_U0_addra_UNCONNECTED;

  system_image_bram_0_blk_mem_gen_v8_4_4 U0
       (.addra({addra[16:2],NLW_U0_addra_UNCONNECTED[1:0]}),
        .clka(clka),
        .dina(dina),
        .douta(douta),
        .ena(ena),
        .lopt(lopt),
        .wea(wea));
endmodule

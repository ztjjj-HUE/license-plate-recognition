// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_image_bram_ctrl_0_SRL_FIFO
   (s_axi_wlast_0,
    E,
    bid_gets_fifo_load,
    D,
    bvalid_cnt_inc,
    esc_Addr_Counters_3__FDRE_I_0_2034557 ,
    s_axi_aclk,
    s_axi_awid,
    s_axi_wlast,
    axi_wdata_full_reg,
    axi_wr_burst,
    esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_6e46e73 ,
    Data_Exists_DFF_0,
    Arb2AW_Active,
    bid_gets_fifo_load_d1_reg,
    aw_active_re,
    bid_gets_fifo_load_d1,
    Data_Exists_DFF_1,
    s_axi_bready,
    esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_0_bd3fb69 ,
    s_axi_wvalid,
    AW2Arb_BVALID_Cnt);
  output s_axi_wlast_0;
  output [0:0]E;
  output bid_gets_fifo_load;
  output [13:0]D;
  output bvalid_cnt_inc;
  input esc_Addr_Counters_3__FDRE_I_0_2034557 ;
  input s_axi_aclk;
  input [13:0]s_axi_awid;
  input s_axi_wlast;
  input axi_wdata_full_reg;
  input axi_wr_burst;
  input esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_6e46e73 ;
  input Data_Exists_DFF_0;
  input Arb2AW_Active;
  input bid_gets_fifo_load_d1_reg;
  input aw_active_re;
  input bid_gets_fifo_load_d1;
  input Data_Exists_DFF_1;
  input s_axi_bready;
  input esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_0_bd3fb69 ;
  input s_axi_wvalid;
  input [2:0]AW2Arb_BVALID_Cnt;

  wire [2:0]AW2Arb_BVALID_Cnt;
  wire esc_Addr_Counters_0__FDRE_I_n_0_8ce873c ;
  wire esc_Addr_Counters_1__FDRE_I_n_0_a789949 ;
  wire esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c ;
  wire esc_Addr_Counters_3__FDRE_I_0_2034557 ;
  wire esc_Addr_Counters_3__FDRE_I_n_0_cc564db ;
  wire esc_Addr_Counters_3__XORCY_I_i_1_n_0_dbd09ec ;
  wire Arb2AW_Active;
  wire CI;
  wire [13:0]D;
  wire D_0;
  wire Data_Exists_DFF_0;
  wire Data_Exists_DFF_1;
  wire Data_Exists_DFF_i_2_n_0;
  wire Data_Exists_DFF_i_3_n_0;
  wire [0:0]E;
  wire esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_6e46e73 ;
  wire esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_0_bd3fb69 ;
  wire S;
  wire S0_out;
  wire S1_out;
  wire VCC_1;
  wire aw_active_re;
  wire esc_axi_bid_int_13__i_3_n_0_ce5ff36 ;
  wire axi_wdata_full_reg;
  wire axi_wr_burst;
  wire bid_fifo_not_empty;
  wire [13:0]bid_fifo_rd;
  wire bid_gets_fifo_load;
  wire bid_gets_fifo_load_d1;
  wire bid_gets_fifo_load_d1_i_2_n_0;
  wire bid_gets_fifo_load_d1_reg;
  wire bvalid_cnt_inc;
  wire lopt;
  wire s_axi_aclk;
  wire [13:0]s_axi_awid;
  wire s_axi_bready;
  wire s_axi_wlast;
  wire s_axi_wlast_0;
  wire s_axi_wvalid;
  wire sum_A_0;
  wire sum_A_1;
  wire sum_A_2;
  wire sum_A_3;

  // Reconstructed FDRE: esc_Addr_Counters_0__FDRE_I_0e9886e
  reg recovered_1_q = 1'b0;
  assign esc_Addr_Counters_0__FDRE_I_n_0_8ce873c = recovered_1_q;
  wire recovered_1_reset = ((esc_Addr_Counters_3__FDRE_I_0_2034557)) && ((esc_Addr_Counters_3__FDRE_I_0_2034557) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_1_reset || (((esc_Addr_Counters_3__FDRE_I_0_2034557) === 1'bx) && (recovered_1_q == 1'b0))) recovered_1_q <= 1'b0;
    else if ((bid_fifo_not_empty) || ((bid_fifo_not_empty) === 1'bz) || (((bid_fifo_not_empty) === 1'bx) && (recovered_1_q == (sum_A_3)))) recovered_1_q <= (sum_A_3);
  end

  // Reconstructed CARRY4: esc_Addr_Counters_0__MUXCY_L_I_CARRY4_3363a6c
  wire [3:0] recovered_2_co, recovered_2_o, recovered_2_s, recovered_2_di;
  assign recovered_2_s = {esc_Addr_Counters_3__XORCY_I_i_1_n_0_dbd09ec ,S0_out,S1_out,S};
  assign recovered_2_di = {esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c ,esc_Addr_Counters_1__FDRE_I_n_0_a789949 ,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c };
  wire recovered_2_ci = ((lopt) !== 1'bz) && (lopt);
  wire recovered_2_cy = ((CI) !== 1'bz) && (CI);
  assign recovered_2_o[0] = recovered_2_s[0] ^ (recovered_2_ci || recovered_2_cy);
  assign recovered_2_co[0] = (recovered_2_s[0] & (recovered_2_ci || recovered_2_cy)) | (~recovered_2_s[0] & recovered_2_di[0]);
  assign recovered_2_o[1] = recovered_2_s[1] ^ recovered_2_co[0];
  assign recovered_2_co[1] = (recovered_2_s[1] & recovered_2_co[0]) | (~recovered_2_s[1] & recovered_2_di[1]);
  assign recovered_2_o[2] = recovered_2_s[2] ^ recovered_2_co[1];
  assign recovered_2_co[2] = (recovered_2_s[2] & recovered_2_co[1]) | (~recovered_2_s[2] & recovered_2_di[2]);
  assign recovered_2_o[3] = recovered_2_s[3] ^ recovered_2_co[2];
  assign recovered_2_co[3] = (recovered_2_s[3] & recovered_2_co[2]) | (~recovered_2_s[3] & recovered_2_di[3]);
  assign {sum_A_0,sum_A_1,sum_A_2,sum_A_3} = recovered_2_o;

  // Reconstructed GND: esc_Addr_Counters_0__MUXCY_L_I_CARRY4_GND_5cf3a4f
  assign lopt = 1'b0;

  // Reconstructed LUT6: esc_Addr_Counters_0__MUXCY_L_I_i_1_702d216
  assign S = ((esc_Addr_Counters_0__FDRE_I_n_0_8ce873c) ? (~(esc_axi_bid_int_13__i_3_n_0_ce5ff36)) : (((esc_axi_bid_int_13__i_3_n_0_ce5ff36) ? (((aw_active_re) ? (1'b1) : (((esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c) ? (1'b1) : (((esc_Addr_Counters_3__FDRE_I_n_0_cc564db) ? (1'b1) : (esc_Addr_Counters_1__FDRE_I_n_0_a789949))))))) : (1'b0))));

  // Reconstructed LUT6: esc_Addr_Counters_0__MUXCY_L_I_i_2_32565dd
  assign CI = ((esc_Addr_Counters_0__FDRE_I_n_0_8ce873c) ? (((esc_Addr_Counters_1__FDRE_I_n_0_a789949) ? (((esc_Addr_Counters_3__FDRE_I_n_0_cc564db) ? (((esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c) ? (((esc_axi_bid_int_13__i_3_n_0_ce5ff36) ? (aw_active_re) : (1'b0))) : (aw_active_re))) : (aw_active_re))) : (aw_active_re))) : (aw_active_re));

  // Reconstructed FDRE: esc_Addr_Counters_1__FDRE_I_c112dca
  reg recovered_6_q = 1'b0;
  assign esc_Addr_Counters_1__FDRE_I_n_0_a789949 = recovered_6_q;
  wire recovered_6_reset = ((esc_Addr_Counters_3__FDRE_I_0_2034557)) && ((esc_Addr_Counters_3__FDRE_I_0_2034557) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_6_reset || (((esc_Addr_Counters_3__FDRE_I_0_2034557) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((bid_fifo_not_empty) || ((bid_fifo_not_empty) === 1'bz) || (((bid_fifo_not_empty) === 1'bx) && (recovered_6_q == (sum_A_2)))) recovered_6_q <= (sum_A_2);
  end

  // Reconstructed LUT6: esc_Addr_Counters_1__MUXCY_L_I_i_1_1680eb0
  assign S1_out = ((esc_Addr_Counters_1__FDRE_I_n_0_a789949) ? (~(esc_axi_bid_int_13__i_3_n_0_ce5ff36)) : (((esc_axi_bid_int_13__i_3_n_0_ce5ff36) ? (((aw_active_re) ? (1'b1) : (((esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c) ? (1'b1) : (((esc_Addr_Counters_0__FDRE_I_n_0_8ce873c) ? (1'b1) : (esc_Addr_Counters_3__FDRE_I_n_0_cc564db))))))) : (1'b0))));

  // Reconstructed FDRE: esc_Addr_Counters_2__FDRE_I_7223a7a
  reg recovered_8_q = 1'b0;
  assign esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c = recovered_8_q;
  wire recovered_8_reset = ((esc_Addr_Counters_3__FDRE_I_0_2034557)) && ((esc_Addr_Counters_3__FDRE_I_0_2034557) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_8_reset || (((esc_Addr_Counters_3__FDRE_I_0_2034557) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((bid_fifo_not_empty) || ((bid_fifo_not_empty) === 1'bz) || (((bid_fifo_not_empty) === 1'bx) && (recovered_8_q == (sum_A_1)))) recovered_8_q <= (sum_A_1);
  end

  // Reconstructed LUT6: esc_Addr_Counters_2__MUXCY_L_I_i_1_faf3d78
  assign S0_out = ((esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c) ? (~(esc_axi_bid_int_13__i_3_n_0_ce5ff36)) : (((esc_axi_bid_int_13__i_3_n_0_ce5ff36) ? (((aw_active_re) ? (1'b1) : (((esc_Addr_Counters_0__FDRE_I_n_0_8ce873c) ? (1'b1) : (((esc_Addr_Counters_3__FDRE_I_n_0_cc564db) ? (1'b1) : (esc_Addr_Counters_1__FDRE_I_n_0_a789949))))))) : (1'b0))));

  // Reconstructed FDRE: esc_Addr_Counters_3__FDRE_I_b8b7b1e
  reg recovered_10_q = 1'b0;
  assign esc_Addr_Counters_3__FDRE_I_n_0_cc564db = recovered_10_q;
  wire recovered_10_reset = ((esc_Addr_Counters_3__FDRE_I_0_2034557)) && ((esc_Addr_Counters_3__FDRE_I_0_2034557) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_10_reset || (((esc_Addr_Counters_3__FDRE_I_0_2034557) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((bid_fifo_not_empty) || ((bid_fifo_not_empty) === 1'bz) || (((bid_fifo_not_empty) === 1'bx) && (recovered_10_q == (sum_A_0)))) recovered_10_q <= (sum_A_0);
  end

  // Reconstructed LUT6: esc_Addr_Counters_3__XORCY_I_i_1_0b9b194
  assign esc_Addr_Counters_3__XORCY_I_i_1_n_0_dbd09ec = ((esc_Addr_Counters_3__FDRE_I_n_0_cc564db) ? (~(esc_axi_bid_int_13__i_3_n_0_ce5ff36)) : (((esc_axi_bid_int_13__i_3_n_0_ce5ff36) ? (((aw_active_re) ? (1'b1) : (((esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c) ? (1'b1) : (((esc_Addr_Counters_0__FDRE_I_n_0_8ce873c) ? (1'b1) : (esc_Addr_Counters_1__FDRE_I_n_0_a789949))))))) : (1'b0))));

  // Reconstructed FDRE: Data_Exists_DFF
  reg recovered_12_q = 1'b0;
  assign bid_fifo_not_empty = recovered_12_q;
  wire recovered_12_reset = ((esc_Addr_Counters_3__FDRE_I_0_2034557)) && ((esc_Addr_Counters_3__FDRE_I_0_2034557) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_12_reset || (((esc_Addr_Counters_3__FDRE_I_0_2034557) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((VCC_1) || ((VCC_1) === 1'bz) || (((VCC_1) === 1'bx) && (recovered_12_q == (D_0)))) recovered_12_q <= (D_0);
  end

  // Reconstructed LUT5: Data_Exists_DFF_i_1
  assign D_0 = ((bid_fifo_not_empty) ? (((Data_Exists_DFF_i_3_n_0) ? (1'b1) : (((Data_Exists_DFF_i_2_n_0) ? (((Data_Exists_DFF_0) ? (1'b0) : (Arb2AW_Active))) : (1'b1))))) : (((Data_Exists_DFF_i_3_n_0) ? (1'b0) : (((Data_Exists_DFF_0) ? (1'b0) : (Arb2AW_Active))))));

  // Reconstructed LUT5: Data_Exists_DFF_i_2
  assign Data_Exists_DFF_i_2_n_0 = ((bid_gets_fifo_load_d1_i_2_n_0) ? (((bid_gets_fifo_load_d1) ? (1'b1) : (((Data_Exists_DFF_1) ? (s_axi_bready) : (1'b0))))) : (((bvalid_cnt_inc) ? (1'b1) : (bid_gets_fifo_load_d1))));

  // Reconstructed LUT4: Data_Exists_DFF_i_3
  assign Data_Exists_DFF_i_3_n_0 = ((esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c) ? (1'b1) : (((esc_Addr_Counters_0__FDRE_I_n_0_8ce873c) ? (1'b1) : (((esc_Addr_Counters_3__FDRE_I_n_0_cc564db) ? (1'b1) : (esc_Addr_Counters_1__FDRE_I_n_0_a789949))))));

  // Reconstructed SRL16E: esc_FIFO_RAM_0__SRL16E_I_1aa5106
  reg [15:0] recovered_16_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_16_shift <= {recovered_16_shift[14:0],s_axi_awid[13]};
  assign bid_fifo_rd[13] = recovered_16_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_10__SRL16E_I_f0ba2be
  reg [15:0] recovered_17_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_17_shift <= {recovered_17_shift[14:0],s_axi_awid[3]};
  assign bid_fifo_rd[3] = recovered_17_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_11__SRL16E_I_957b977
  reg [15:0] recovered_18_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_18_shift <= {recovered_18_shift[14:0],s_axi_awid[2]};
  assign bid_fifo_rd[2] = recovered_18_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_12__SRL16E_I_111c473
  reg [15:0] recovered_19_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_19_shift <= {recovered_19_shift[14:0],s_axi_awid[1]};
  assign bid_fifo_rd[1] = recovered_19_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_13__SRL16E_I_c196ff3
  reg [15:0] recovered_20_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_20_shift <= {recovered_20_shift[14:0],s_axi_awid[0]};
  assign bid_fifo_rd[0] = recovered_20_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_2__SRL16E_I_f7525ea
  reg [15:0] recovered_21_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_21_shift <= {recovered_21_shift[14:0],s_axi_awid[11]};
  assign bid_fifo_rd[11] = recovered_21_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_3__SRL16E_I_87039db
  reg [15:0] recovered_22_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_22_shift <= {recovered_22_shift[14:0],s_axi_awid[10]};
  assign bid_fifo_rd[10] = recovered_22_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_4__SRL16E_I_385fcbd
  reg [15:0] recovered_23_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_23_shift <= {recovered_23_shift[14:0],s_axi_awid[9]};
  assign bid_fifo_rd[9] = recovered_23_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_5__SRL16E_I_6d24284
  reg [15:0] recovered_24_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_24_shift <= {recovered_24_shift[14:0],s_axi_awid[8]};
  assign bid_fifo_rd[8] = recovered_24_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_6__SRL16E_I_21eb62f
  reg [15:0] recovered_25_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_25_shift <= {recovered_25_shift[14:0],s_axi_awid[7]};
  assign bid_fifo_rd[7] = recovered_25_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_7__SRL16E_I_9736a7e
  reg [15:0] recovered_26_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_26_shift <= {recovered_26_shift[14:0],s_axi_awid[6]};
  assign bid_fifo_rd[6] = recovered_26_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_8__SRL16E_I_a8b1e46
  reg [15:0] recovered_27_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_27_shift <= {recovered_27_shift[14:0],s_axi_awid[5]};
  assign bid_fifo_rd[5] = recovered_27_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed SRL16E: esc_FIFO_RAM_9__SRL16E_I_c4ae922
  reg [15:0] recovered_28_shift = 16'h0000;
  always @(posedge s_axi_aclk)
    if ((CI) == 1'b1 || (CI) === 1'bz) recovered_28_shift <= {recovered_28_shift[14:0],s_axi_awid[4]};
  assign bid_fifo_rd[4] = recovered_28_shift[{esc_Addr_Counters_3__FDRE_I_n_0_cc564db,esc_Addr_Counters_2__FDRE_I_n_0_88d7e7c,esc_Addr_Counters_1__FDRE_I_n_0_a789949,esc_Addr_Counters_0__FDRE_I_n_0_8ce873c}];

  // Reconstructed LUT4: esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_2_903fd34
  assign s_axi_wlast_0 = ((esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_6e46e73) ? (((axi_wr_burst) ? (((axi_wdata_full_reg) ? (1'b1) : (~(s_axi_wlast)))) : (((axi_wdata_full_reg) ? (1'b0) : (~(s_axi_wlast)))))) : (1'b1));

  // Reconstructed LUT6: esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_i_1_81710c5
  assign bvalid_cnt_inc = ((s_axi_wvalid) ? (((Arb2AW_Active) ? (((s_axi_wlast_0) ? (((esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_0_bd3fb69) ? (s_axi_wlast) : (1'b0))) : (1'b1))) : (((esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_0_bd3fb69) ? (s_axi_wlast) : (1'b0))))) : (((axi_wdata_full_reg) ? (((Arb2AW_Active) ? (~(s_axi_wlast_0)) : (1'b0))) : (1'b0))));

  // Reconstructed VCC: VCC
  assign VCC_1 = 1'b1;

  // Reconstructed LUT3: esc_axi_bid_int_0__i_1_c4fc023
  assign D[0] = ((bid_fifo_rd[0]) ? (((bid_gets_fifo_load) ? (s_axi_awid[0]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[0]) : (1'b0))));

  // Reconstructed LUT3: esc_axi_bid_int_10__i_1_1efbef8
  assign D[10] = ((bid_fifo_rd[10]) ? (((bid_gets_fifo_load) ? (s_axi_awid[10]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[10]) : (1'b0))));

  // Reconstructed LUT3: esc_axi_bid_int_11__i_1_f5bbabd
  assign D[11] = ((bid_fifo_rd[11]) ? (((bid_gets_fifo_load) ? (s_axi_awid[11]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[11]) : (1'b0))));

  // Reconstructed LUT2: esc_axi_bid_int_13__i_1_c16bb06
  assign E = ((bid_gets_fifo_load) ? (1'b1) : (esc_axi_bid_int_13__i_3_n_0_ce5ff36));

  // Reconstructed LUT3: esc_axi_bid_int_13__i_2_06bd62b
  assign D[13] = ((bid_fifo_rd[13]) ? (((bid_gets_fifo_load) ? (s_axi_awid[13]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[13]) : (1'b0))));

  // Reconstructed LUT6: esc_axi_bid_int_13__i_3_ca4594b
  assign esc_axi_bid_int_13__i_3_n_0_ce5ff36 = ((s_axi_bready) ? (((Data_Exists_DFF_1) ? (((bid_gets_fifo_load_d1) ? (bid_fifo_not_empty) : (((bvalid_cnt_inc) ? (bid_fifo_not_empty) : (((bid_gets_fifo_load_d1_i_2_n_0) ? (bid_fifo_not_empty) : (1'b0))))))) : (((bid_gets_fifo_load_d1) ? (bid_fifo_not_empty) : (((bvalid_cnt_inc) ? (((bid_gets_fifo_load_d1_i_2_n_0) ? (1'b0) : (bid_fifo_not_empty))) : (1'b0))))))) : (((bid_gets_fifo_load_d1) ? (bid_fifo_not_empty) : (((bvalid_cnt_inc) ? (((bid_gets_fifo_load_d1_i_2_n_0) ? (1'b0) : (bid_fifo_not_empty))) : (1'b0))))));

  // Reconstructed LUT3: esc_axi_bid_int_1__i_1_0da6d43
  assign D[1] = ((bid_fifo_rd[1]) ? (((bid_gets_fifo_load) ? (s_axi_awid[1]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[1]) : (1'b0))));

  // Reconstructed LUT3: esc_axi_bid_int_2__i_1_9930c7d
  assign D[2] = ((bid_fifo_rd[2]) ? (((bid_gets_fifo_load) ? (s_axi_awid[2]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[2]) : (1'b0))));

  // Reconstructed LUT3: esc_axi_bid_int_3__i_1_059ea9c
  assign D[3] = ((bid_fifo_rd[3]) ? (((bid_gets_fifo_load) ? (s_axi_awid[3]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[3]) : (1'b0))));

  // Reconstructed LUT3: esc_axi_bid_int_4__i_1_6036194
  assign D[4] = ((bid_fifo_rd[4]) ? (((bid_gets_fifo_load) ? (s_axi_awid[4]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[4]) : (1'b0))));

  // Reconstructed LUT3: esc_axi_bid_int_5__i_1_9d0ad5a
  assign D[5] = ((bid_fifo_rd[5]) ? (((bid_gets_fifo_load) ? (s_axi_awid[5]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[5]) : (1'b0))));

  // Reconstructed LUT3: esc_axi_bid_int_6__i_1_4b1f0e7
  assign D[6] = ((bid_fifo_rd[6]) ? (((bid_gets_fifo_load) ? (s_axi_awid[6]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[6]) : (1'b0))));

  // Reconstructed LUT3: esc_axi_bid_int_7__i_1_b50c55b
  assign D[7] = ((bid_fifo_rd[7]) ? (((bid_gets_fifo_load) ? (s_axi_awid[7]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[7]) : (1'b0))));

  // Reconstructed LUT3: esc_axi_bid_int_8__i_1_7c995cb
  assign D[8] = ((bid_fifo_rd[8]) ? (((bid_gets_fifo_load) ? (s_axi_awid[8]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[8]) : (1'b0))));

  // Reconstructed LUT3: esc_axi_bid_int_9__i_1_e725ce5
  assign D[9] = ((bid_fifo_rd[9]) ? (((bid_gets_fifo_load) ? (s_axi_awid[9]) : (1'b1))) : (((bid_gets_fifo_load) ? (s_axi_awid[9]) : (1'b0))));

  // Reconstructed LUT6: bid_gets_fifo_load_d1_i_1
  assign bid_gets_fifo_load = ((bid_gets_fifo_load_d1_i_2_n_0) ? (((bid_fifo_not_empty) ? (1'b0) : (((bvalid_cnt_inc) ? (((bid_gets_fifo_load_d1_reg) ? (((Arb2AW_Active) ? (~(Data_Exists_DFF_0)) : (1'b0))) : (1'b0))) : (1'b0))))) : (((bvalid_cnt_inc) ? (((Arb2AW_Active) ? (~(Data_Exists_DFF_0)) : (1'b0))) : (1'b0))));

  // Reconstructed LUT3: bid_gets_fifo_load_d1_i_2
  assign bid_gets_fifo_load_d1_i_2_n_0 = ((AW2Arb_BVALID_Cnt[0]) ? (1'b1) : (((AW2Arb_BVALID_Cnt[2]) ? (1'b1) : (AW2Arb_BVALID_Cnt[1]))));

endmodule

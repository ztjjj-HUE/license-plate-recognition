// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_image_bram_ctrl_0_axi_bram_ctrl_top
   (axi_bvalid_int_reg,
    esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 ,
    esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_04f15cd ,
    Q,
    s_axi_aresetn_0,
    s_axi_awready,
    s_axi_arready,
    s_axi_bid,
    bram_wrdata_a,
    s_axi_rid,
    s_axi_rdata,
    bram_we_a,
    bram_en_a,
    s_axi_wready,
    s_axi_aresetn,
    s_axi_wlast,
    s_axi_wvalid,
    s_axi_bready,
    s_axi_rready,
    s_axi_arburst,
    s_axi_awvalid,
    s_axi_arvalid,
    s_axi_aclk,
    s_axi_awid,
    s_axi_wstrb,
    s_axi_wdata,
    s_axi_arid,
    bram_rddata_a,
    s_axi_araddr,
    s_axi_awaddr,
    s_axi_arlen,
    s_axi_awlen,
    s_axi_awburst);
  output axi_bvalid_int_reg;
  output esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 ;
  output esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_04f15cd ;
  output [14:0]Q;
  output s_axi_aresetn_0;
  output s_axi_awready;
  output s_axi_arready;
  output [13:0]s_axi_bid;
  output [31:0]bram_wrdata_a;
  output [13:0]s_axi_rid;
  output [31:0]s_axi_rdata;
  output [3:0]bram_we_a;
  output bram_en_a;
  output s_axi_wready;
  input s_axi_aresetn;
  input s_axi_wlast;
  input s_axi_wvalid;
  input s_axi_bready;
  input s_axi_rready;
  input [1:0]s_axi_arburst;
  input s_axi_awvalid;
  input s_axi_arvalid;
  input s_axi_aclk;
  input [13:0]s_axi_awid;
  input [3:0]s_axi_wstrb;
  input [31:0]s_axi_wdata;
  input [13:0]s_axi_arid;
  input [31:0]bram_rddata_a;
  input [14:0]s_axi_araddr;
  input [14:0]s_axi_awaddr;
  input [7:0]s_axi_arlen;
  input [3:0]s_axi_awlen;
  input [1:0]s_axi_awburst;

  wire esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_04f15cd ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 ;
  wire [14:0]Q;
  wire axi_bvalid_int_reg;
  wire bram_en_a;
  wire [31:0]bram_rddata_a;
  wire [3:0]bram_we_a;
  wire [31:0]bram_wrdata_a;
  wire s_axi_aclk;
  wire [14:0]s_axi_araddr;
  wire [1:0]s_axi_arburst;
  wire s_axi_aresetn;
  wire [13:0]s_axi_arid;
  wire [7:0]s_axi_arlen;
  wire s_axi_arready;
  wire s_axi_arvalid;
  wire [14:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [13:0]s_axi_awid;
  wire [3:0]s_axi_awlen;
  wire s_axi_awready;
  wire s_axi_awvalid;
  wire [13:0]s_axi_bid;
  wire s_axi_bready;
  wire [31:0]s_axi_rdata;
  wire [13:0]s_axi_rid;
  wire s_axi_rready;
  wire [31:0]s_axi_wdata;
  wire s_axi_wlast;
  wire s_axi_wready;
  wire [3:0]s_axi_wstrb;
  wire s_axi_wvalid;
  wire [13:0]esc_NLW_GEN_AXI4_I_FULL_AXI_s_axi_awid_UNCONNECTED_aabdf7b ;
  wire [13:0]esc_NLW_GEN_AXI4_I_FULL_AXI_s_axi_bid_UNCONNECTED_2312fb5 ;

  system_image_bram_ctrl_0_full_axi esc_GEN_AXI4_I_FULL_AXI_dae5b5d 
       (.BRAM_Addr_A(Q),
        .esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_04f15cd (esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_04f15cd ),
        .esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 (esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 ),
        .axi_bvalid_int_reg(axi_bvalid_int_reg),
        .bram_en_a(bram_en_a),
        .bram_rddata_a(bram_rddata_a),
        .bram_we_a(bram_we_a),
        .bram_wrdata_a(bram_wrdata_a),
        .s_axi_aclk(s_axi_aclk),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_aresetn(s_axi_aresetn),
        .s_axi_arid(s_axi_arid[12:0]),
        .s_axi_arlen(s_axi_arlen[3:0]),
        .s_axi_arready(s_axi_arready),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awid({s_axi_awid[13],esc_NLW_GEN_AXI4_I_FULL_AXI_s_axi_awid_UNCONNECTED_aabdf7b [12],s_axi_awid[11:0]}),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awready(s_axi_awready),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_bid({s_axi_bid[13],esc_NLW_GEN_AXI4_I_FULL_AXI_s_axi_bid_UNCONNECTED_2312fb5 [12],s_axi_bid[11:0]}),
        .s_axi_bready(s_axi_bready),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rid(s_axi_rid[12:0]),
        .s_axi_rready(s_axi_rready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wready(s_axi_wready),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wvalid(s_axi_wvalid));
endmodule

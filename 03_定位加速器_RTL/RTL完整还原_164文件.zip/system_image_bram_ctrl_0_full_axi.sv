// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_image_bram_ctrl_0_full_axi
   (axi_bvalid_int_reg,
    esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 ,
    esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_04f15cd ,
    BRAM_Addr_A,
    SR,
    s_axi_awready,
    s_axi_arready,
    s_axi_bid,
    bram_wrdata_a,
    s_axi_rid,
    s_axi_rdata,
    bram_we_a,
    bram_en_a,
    s_axi_wready,
    s_axi_aresetn,
    s_axi_wlast,
    s_axi_wvalid,
    s_axi_bready,
    s_axi_rready,
    s_axi_arburst,
    s_axi_awvalid,
    s_axi_arvalid,
    s_axi_aclk,
    s_axi_awid,
    s_axi_wstrb,
    s_axi_wdata,
    s_axi_arid,
    bram_rddata_a,
    s_axi_araddr,
    s_axi_awaddr,
    s_axi_arlen,
    s_axi_awlen,
    s_axi_awburst);
  output axi_bvalid_int_reg;
  output esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 ;
  output esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_04f15cd ;
  output [14:0]BRAM_Addr_A;
  output [0:0]SR;
  output s_axi_awready;
  output s_axi_arready;
  output [13:0]s_axi_bid;
  output [31:0]bram_wrdata_a;
  output [13:0]s_axi_rid;
  output [31:0]s_axi_rdata;
  output [3:0]bram_we_a;
  output bram_en_a;
  output s_axi_wready;
  input s_axi_aresetn;
  input s_axi_wlast;
  input s_axi_wvalid;
  input s_axi_bready;
  input s_axi_rready;
  input [1:0]s_axi_arburst;
  input s_axi_awvalid;
  input s_axi_arvalid;
  input s_axi_aclk;
  input [13:0]s_axi_awid;
  input [3:0]s_axi_wstrb;
  input [31:0]s_axi_wdata;
  input [13:0]s_axi_arid;
  input [31:0]bram_rddata_a;
  input [14:0]s_axi_araddr;
  input [14:0]s_axi_awaddr;
  input [7:0]s_axi_arlen;
  input [3:0]s_axi_awlen;
  input [1:0]s_axi_awburst;

  wire esc_ADDR_SNG_PORT_bram_addr_int_10__i_2_n_0_0d989d4 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_11__i_3_n_0_60298c2 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_4__i_2_n_0_103e1b2 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_5__i_2_n_0_6ebf108 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_7__i_2_n_0_86ef77e ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_8__i_2_n_0_4ffbefd ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_9__i_2_n_0_92ca2a3 ;
  wire AW2Arb_Active_Clr;
  wire Arb2AR_Active;
  wire Arb2AW_Active;
  wire [14:0]BRAM_Addr_A;
  wire BRAM_En_B_i;
  wire [3:0]BRAM_WE_A_i;
  wire esc_GEN_ARB_I_SNG_PORT_n_10_93f7c28 ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_04f15cd ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 ;
  wire I_RD_CHNL_n_37;
  wire I_RD_CHNL_n_38;
  wire I_RD_CHNL_n_39;
  wire I_RD_CHNL_n_40;
  wire I_RD_CHNL_n_41;
  wire I_RD_CHNL_n_42;
  wire I_RD_CHNL_n_43;
  wire I_RD_CHNL_n_44;
  wire I_RD_CHNL_n_45;
  wire I_RD_CHNL_n_46;
  wire I_RD_CHNL_n_47;
  wire I_RD_CHNL_n_48;
  wire I_RD_CHNL_n_49;
  wire I_RD_CHNL_n_50;
  wire I_RD_CHNL_n_51;
  wire I_RD_CHNL_n_53;
  wire I_RD_CHNL_n_54;
  wire I_WR_CHNL_n_36;
  wire I_WR_CHNL_n_37;
  wire I_WR_CHNL_n_39;
  wire I_WR_CHNL_n_40;
  wire I_WR_CHNL_n_41;
  wire I_WR_CHNL_n_56;
  wire [0:0]esc_SR_7cb4374 ;
  wire ar_active_d1;
  wire ar_active_re;
  wire aw_active_d1;
  wire aw_active_re;
  wire axi_bvalid_int_reg;
  wire bram_en_a;
  wire [31:0]bram_rddata_a;
  wire [3:0]bram_we_a;
  wire [31:0]bram_wrdata_a;
  wire curr_fixed_burst_reg;
  wire [13:0]p_1_in;
  wire s_axi_aclk;
  wire [14:0]s_axi_araddr;
  wire [1:0]s_axi_arburst;
  wire s_axi_aresetn;
  wire [13:0]s_axi_arid;
  wire [7:0]s_axi_arlen;
  wire s_axi_arready;
  wire s_axi_arvalid;
  wire [14:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [13:0]s_axi_awid;
  wire [3:0]s_axi_awlen;
  wire s_axi_awready;
  wire s_axi_awvalid;
  wire [13:0]s_axi_bid;
  wire s_axi_bready;
  wire [31:0]s_axi_rdata;
  wire [13:0]s_axi_rid;
  wire s_axi_rready;
  wire [31:0]s_axi_wdata;
  wire s_axi_wlast;
  wire s_axi_wready;
  wire [3:0]s_axi_wstrb;
  wire s_axi_wvalid;
  wire sng_bram_addr_ld_en;
  wire [13:0]NLW_I_WR_CHNL_s_axi_awid_UNCONNECTED;
  wire [13:0]NLW_I_WR_CHNL_s_axi_bid_UNCONNECTED;

  // Reconstructed LUT5: esc_ADDR_SNG_PORT_bram_addr_int_10__i_2_39d5f7c
  assign esc_ADDR_SNG_PORT_bram_addr_int_10__i_2_n_0_0d989d4 = ((BRAM_Addr_A[6]) ? (((BRAM_Addr_A[5]) ? (((I_WR_CHNL_n_40) ? (1'b0) : (((BRAM_Addr_A[4]) ? (BRAM_Addr_A[7]) : (1'b0))))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_11__i_3_8f3003f
  assign esc_ADDR_SNG_PORT_bram_addr_int_11__i_3_n_0_60298c2 = ((BRAM_Addr_A[7]) ? (((BRAM_Addr_A[4]) ? (((I_WR_CHNL_n_40) ? (1'b0) : (((BRAM_Addr_A[5]) ? (((BRAM_Addr_A[6]) ? (BRAM_Addr_A[8]) : (1'b0))) : (1'b0))))) : (1'b0))) : (1'b0));

  // Reconstructed LUT2: esc_ADDR_SNG_PORT_bram_addr_int_4__i_2_11db7d5
  assign esc_ADDR_SNG_PORT_bram_addr_int_4__i_2_n_0_103e1b2 = ((BRAM_Addr_A[0]) ? (BRAM_Addr_A[1]) : (1'b0));

  // Reconstructed LUT3: esc_ADDR_SNG_PORT_bram_addr_int_5__i_2_7fc1104
  assign esc_ADDR_SNG_PORT_bram_addr_int_5__i_2_n_0_6ebf108 = ((BRAM_Addr_A[1]) ? (((BRAM_Addr_A[0]) ? (~(BRAM_Addr_A[2])) : (1'b1))) : (1'b1));

  // Reconstructed LUT5: esc_ADDR_SNG_PORT_bram_addr_int_7__i_2_0596b6d
  assign esc_ADDR_SNG_PORT_bram_addr_int_7__i_2_n_0_86ef77e = ((BRAM_Addr_A[4]) ? (((BRAM_Addr_A[1]) ? (((BRAM_Addr_A[0]) ? (((BRAM_Addr_A[2]) ? (~(BRAM_Addr_A[3])) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_8__i_2_58708b8
  assign esc_ADDR_SNG_PORT_bram_addr_int_8__i_2_n_0_4ffbefd = ((BRAM_Addr_A[5]) ? (((BRAM_Addr_A[3]) ? (((BRAM_Addr_A[2]) ? (((BRAM_Addr_A[0]) ? (((BRAM_Addr_A[1]) ? (~(BRAM_Addr_A[4])) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT4: esc_ADDR_SNG_PORT_bram_addr_int_9__i_2_f396b2c
  assign esc_ADDR_SNG_PORT_bram_addr_int_9__i_2_n_0_92ca2a3 = ((BRAM_Addr_A[4]) ? (((I_WR_CHNL_n_40) ? (1'b0) : (((BRAM_Addr_A[5]) ? (BRAM_Addr_A[6]) : (1'b0))))) : (1'b0));

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_10_3f275c0
  reg recovered_8_q = 1'b0;
  assign BRAM_Addr_A[8] = recovered_8_q;
  wire recovered_8_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_8_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((I_RD_CHNL_n_53) || ((I_RD_CHNL_n_53) === 1'bz) || (((I_RD_CHNL_n_53) === 1'bx) && (recovered_8_q == (I_RD_CHNL_n_43)))) recovered_8_q <= (I_RD_CHNL_n_43);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615
  reg recovered_9_q = 1'b0;
  assign BRAM_Addr_A[9] = recovered_9_q;
  wire recovered_9_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_9_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((I_RD_CHNL_n_53) || ((I_RD_CHNL_n_53) === 1'bz) || (((I_RD_CHNL_n_53) === 1'bx) && (recovered_9_q == (I_RD_CHNL_n_42)))) recovered_9_q <= (I_RD_CHNL_n_42);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_12_7f7fab3
  reg recovered_10_q = 1'b0;
  assign BRAM_Addr_A[10] = recovered_10_q;
  wire recovered_10_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_10_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((sng_bram_addr_ld_en) || ((sng_bram_addr_ld_en) === 1'bz) || (((sng_bram_addr_ld_en) === 1'bx) && (recovered_10_q == (I_RD_CHNL_n_41)))) recovered_10_q <= (I_RD_CHNL_n_41);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_13_008a3b6
  reg recovered_11_q = 1'b0;
  assign BRAM_Addr_A[11] = recovered_11_q;
  wire recovered_11_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_11_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((sng_bram_addr_ld_en) || ((sng_bram_addr_ld_en) === 1'bz) || (((sng_bram_addr_ld_en) === 1'bx) && (recovered_11_q == (I_RD_CHNL_n_40)))) recovered_11_q <= (I_RD_CHNL_n_40);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_14_5ee1a79
  reg recovered_12_q = 1'b0;
  assign BRAM_Addr_A[12] = recovered_12_q;
  wire recovered_12_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_12_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((sng_bram_addr_ld_en) || ((sng_bram_addr_ld_en) === 1'bz) || (((sng_bram_addr_ld_en) === 1'bx) && (recovered_12_q == (I_RD_CHNL_n_39)))) recovered_12_q <= (I_RD_CHNL_n_39);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_15_1468b7f
  reg recovered_13_q = 1'b0;
  assign BRAM_Addr_A[13] = recovered_13_q;
  wire recovered_13_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_13_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((sng_bram_addr_ld_en) || ((sng_bram_addr_ld_en) === 1'bz) || (((sng_bram_addr_ld_en) === 1'bx) && (recovered_13_q == (I_RD_CHNL_n_38)))) recovered_13_q <= (I_RD_CHNL_n_38);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8
  reg recovered_14_q = 1'b0;
  assign BRAM_Addr_A[14] = recovered_14_q;
  wire recovered_14_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_14_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((sng_bram_addr_ld_en) || ((sng_bram_addr_ld_en) === 1'bz) || (((sng_bram_addr_ld_en) === 1'bx) && (recovered_14_q == (I_RD_CHNL_n_37)))) recovered_14_q <= (I_RD_CHNL_n_37);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8
  reg recovered_15_q = 1'b0;
  assign BRAM_Addr_A[0] = recovered_15_q;
  wire recovered_15_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_15_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((I_RD_CHNL_n_53) || ((I_RD_CHNL_n_53) === 1'bz) || (((I_RD_CHNL_n_53) === 1'bx) && (recovered_15_q == (I_RD_CHNL_n_51)))) recovered_15_q <= (I_RD_CHNL_n_51);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4
  reg recovered_16_q = 1'b0;
  assign BRAM_Addr_A[1] = recovered_16_q;
  wire recovered_16_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_16_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((I_RD_CHNL_n_53) || ((I_RD_CHNL_n_53) === 1'bz) || (((I_RD_CHNL_n_53) === 1'bx) && (recovered_16_q == (I_RD_CHNL_n_50)))) recovered_16_q <= (I_RD_CHNL_n_50);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_4_f52f690
  reg recovered_17_q = 1'b0;
  assign BRAM_Addr_A[2] = recovered_17_q;
  wire recovered_17_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_17_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((I_RD_CHNL_n_53) || ((I_RD_CHNL_n_53) === 1'bz) || (((I_RD_CHNL_n_53) === 1'bx) && (recovered_17_q == (I_RD_CHNL_n_49)))) recovered_17_q <= (I_RD_CHNL_n_49);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_5_38af973
  reg recovered_18_q = 1'b0;
  assign BRAM_Addr_A[3] = recovered_18_q;
  wire recovered_18_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_18_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((I_RD_CHNL_n_53) || ((I_RD_CHNL_n_53) === 1'bz) || (((I_RD_CHNL_n_53) === 1'bx) && (recovered_18_q == (I_RD_CHNL_n_48)))) recovered_18_q <= (I_RD_CHNL_n_48);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d
  reg recovered_19_q = 1'b0;
  assign BRAM_Addr_A[4] = recovered_19_q;
  wire recovered_19_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_19_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((I_RD_CHNL_n_53) || ((I_RD_CHNL_n_53) === 1'bz) || (((I_RD_CHNL_n_53) === 1'bx) && (recovered_19_q == (I_RD_CHNL_n_47)))) recovered_19_q <= (I_RD_CHNL_n_47);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_7_6e268c9
  reg recovered_20_q = 1'b0;
  assign BRAM_Addr_A[5] = recovered_20_q;
  wire recovered_20_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_20_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((I_RD_CHNL_n_53) || ((I_RD_CHNL_n_53) === 1'bz) || (((I_RD_CHNL_n_53) === 1'bx) && (recovered_20_q == (I_RD_CHNL_n_46)))) recovered_20_q <= (I_RD_CHNL_n_46);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d
  reg recovered_21_q = 1'b0;
  assign BRAM_Addr_A[6] = recovered_21_q;
  wire recovered_21_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_21_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((I_RD_CHNL_n_53) || ((I_RD_CHNL_n_53) === 1'bz) || (((I_RD_CHNL_n_53) === 1'bx) && (recovered_21_q == (I_RD_CHNL_n_45)))) recovered_21_q <= (I_RD_CHNL_n_45);
  end

  // Reconstructed FDRE: esc_ADDR_SNG_PORT_bram_addr_int_reg_9_d2d8198
  reg recovered_22_q = 1'b0;
  assign BRAM_Addr_A[7] = recovered_22_q;
  wire recovered_22_reset = ((I_WR_CHNL_n_36)) && ((I_WR_CHNL_n_36) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_22_reset || (((I_WR_CHNL_n_36) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((I_RD_CHNL_n_53) || ((I_RD_CHNL_n_53) === 1'bz) || (((I_RD_CHNL_n_53) === 1'bx) && (recovered_22_q == (I_RD_CHNL_n_44)))) recovered_22_q <= (I_RD_CHNL_n_44);
  end

  system_image_bram_ctrl_0_sng_port_arb esc_GEN_ARB_I_SNG_PORT_2310046 
       (.AW2Arb_Active_Clr(AW2Arb_Active_Clr),
        .Arb2AR_Active(Arb2AR_Active),
        .Arb2AW_Active(Arb2AW_Active),
        .esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5 (I_RD_CHNL_n_54),
        .esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34 (I_WR_CHNL_n_56),
        .esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_3975a1b (esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_04f15cd ),
        .Q(BRAM_WE_A_i),
        .ar_active_d1(ar_active_d1),
        .ar_active_re(ar_active_re),
        .ar_active_reg_0(esc_GEN_ARB_I_SNG_PORT_n_10_93f7c28 ),
        .ar_active_reg_1(esc_SR_7cb4374 ),
        .aw_active_d1(aw_active_d1),
        .aw_active_re(aw_active_re),
        .bram_we_a(bram_we_a),
        .s_axi_aclk(s_axi_aclk),
        .s_axi_aresetn(s_axi_aresetn),
        .s_axi_arready(s_axi_arready),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_awready(s_axi_awready),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_rready(s_axi_rready));
  system_image_bram_ctrl_0_rd_chnl I_RD_CHNL
       (.esc_ADDR_SNG_PORT_bram_addr_int_reg_10_3f275c0 (esc_ADDR_SNG_PORT_bram_addr_int_10__i_2_n_0_0d989d4 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 (esc_ADDR_SNG_PORT_bram_addr_int_11__i_3_n_0_60298c2 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_11__0_4716190 (I_WR_CHNL_n_37),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 (p_1_in),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b (I_WR_CHNL_n_39),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8 (I_WR_CHNL_n_41),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_4_f52f690 (esc_ADDR_SNG_PORT_bram_addr_int_4__i_2_n_0_103e1b2 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_5_38af973 (esc_ADDR_SNG_PORT_bram_addr_int_5__i_2_n_0_6ebf108 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d (I_WR_CHNL_n_40),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_7_6e268c9 (esc_ADDR_SNG_PORT_bram_addr_int_7__i_2_n_0_86ef77e ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d (esc_ADDR_SNG_PORT_bram_addr_int_8__i_2_n_0_4ffbefd ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_9_d2d8198 (esc_ADDR_SNG_PORT_bram_addr_int_9__i_2_n_0_92ca2a3 ),
        .Arb2AR_Active(Arb2AR_Active),
        .BRAM_En_B_i(BRAM_En_B_i),
        .D({I_RD_CHNL_n_37,I_RD_CHNL_n_38,I_RD_CHNL_n_39,I_RD_CHNL_n_40,I_RD_CHNL_n_41,I_RD_CHNL_n_42,I_RD_CHNL_n_43,I_RD_CHNL_n_44,I_RD_CHNL_n_45,I_RD_CHNL_n_46,I_RD_CHNL_n_47,I_RD_CHNL_n_48,I_RD_CHNL_n_49,I_RD_CHNL_n_50,I_RD_CHNL_n_51}),
        .E(I_RD_CHNL_n_53),
        .esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_0_afd5e32 (esc_GEN_ARB_I_SNG_PORT_n_10_93f7c28 ),
        .esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_0_3cf0d99 (esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_04f15cd ),
        .esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5 (esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 ),
        .Q(BRAM_Addr_A[9:0]),
        .ar_active_d1(ar_active_d1),
        .ar_active_re(ar_active_re),
        .bram_rddata_a(bram_rddata_a),
        .curr_fixed_burst_reg(curr_fixed_burst_reg),
        .s_axi_aclk(s_axi_aclk),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_aresetn(s_axi_aresetn),
        .s_axi_aresetn_0(esc_SR_7cb4374 ),
        .s_axi_arid(s_axi_arid[12:0]),
        .s_axi_arlen(s_axi_arlen[3:0]),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rid(s_axi_rid[12:0]),
        .s_axi_rready(s_axi_rready),
        .s_axi_rready_0(I_RD_CHNL_n_54),
        .sng_bram_addr_ld_en(sng_bram_addr_ld_en));
  system_image_bram_ctrl_0_wr_chnl I_WR_CHNL
       (.esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4 (I_WR_CHNL_n_40),
        .AW2Arb_Active_Clr(AW2Arb_Active_Clr),
        .Arb2AW_Active(Arb2AW_Active),
        .BRAM_En_B_i(BRAM_En_B_i),
        .D(p_1_in),
        .esc_GEN_WR_NO_ECC_bram_we_int_reg_3__0_c89e4f5 (BRAM_WE_A_i),
        .Q(BRAM_Addr_A[3:0]),
        .SR(I_WR_CHNL_n_36),
        .aw_active_d1(aw_active_d1),
        .aw_active_re(aw_active_re),
        .axi_bvalid_int_reg_0(axi_bvalid_int_reg),
        .bram_en_a(bram_en_a),
        .bram_wrdata_a(bram_wrdata_a),
        .curr_fixed_burst_reg(curr_fixed_burst_reg),
        .curr_wrap_burst_reg_reg_0(I_WR_CHNL_n_39),
        .s_axi_aclk(s_axi_aclk),
        .s_axi_aresetn(s_axi_aresetn),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awaddr_2_sp_1(I_WR_CHNL_n_41),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awid({s_axi_awid[13],NLW_I_WR_CHNL_s_axi_awid_UNCONNECTED[12],s_axi_awid[11:0]}),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awvalid_0(I_WR_CHNL_n_56),
        .s_axi_bid({s_axi_bid[13],NLW_I_WR_CHNL_s_axi_bid_UNCONNECTED[12],s_axi_bid[11:0]}),
        .s_axi_bready(s_axi_bready),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wready(s_axi_wready),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wvalid_0(I_WR_CHNL_n_37),
        .esc_save_init_bram_addr_ld_reg_3_8d0fcb1 (esc_SR_7cb4374 ));
endmodule

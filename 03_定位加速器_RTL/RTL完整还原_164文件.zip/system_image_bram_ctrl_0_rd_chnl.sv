// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_image_bram_ctrl_0_rd_chnl
   (s_axi_aresetn_0,
    s_axi_rdata,
    ar_active_d1,
    esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5 ,
    esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_0_3cf0d99 ,
    BRAM_En_B_i,
    D,
    sng_bram_addr_ld_en,
    E,
    s_axi_rready_0,
    s_axi_rid,
    s_axi_aclk,
    ar_active_re,
    esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_0_afd5e32 ,
    Arb2AR_Active,
    s_axi_rready,
    s_axi_aresetn,
    s_axi_arburst,
    s_axi_araddr,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8 ,
    Q,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_4_f52f690 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_5_38af973 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_7_6e268c9 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_9_d2d8198 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_10_3f275c0 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 ,
    curr_fixed_burst_reg,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_11__0_4716190 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b ,
    s_axi_arlen,
    s_axi_arid,
    bram_rddata_a);
  output s_axi_aresetn_0;
  output [31:0]s_axi_rdata;
  output ar_active_d1;
  output esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5 ;
  output esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_0_3cf0d99 ;
  output BRAM_En_B_i;
  output [14:0]D;
  output sng_bram_addr_ld_en;
  output [0:0]E;
  output s_axi_rready_0;
  output [13:0]s_axi_rid;
  input s_axi_aclk;
  input ar_active_re;
  input esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_0_afd5e32 ;
  input Arb2AR_Active;
  input s_axi_rready;
  input s_axi_aresetn;
  input [1:0]s_axi_arburst;
  input [14:0]s_axi_araddr;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8 ;
  input [9:0]Q;
  input [13:0]esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_4_f52f690 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_5_38af973 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_7_6e268c9 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_9_d2d8198 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_10_3f275c0 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 ;
  input curr_fixed_burst_reg;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_11__0_4716190 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b ;
  input [7:0]s_axi_arlen;
  input [13:0]s_axi_arid;
  input [31:0]bram_rddata_a;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_10_3f275c0 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_11__0_4716190 ;
  wire [13:0]esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_4_f52f690 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_5_38af973 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_7_6e268c9 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_9_d2d8198 ;
  wire Arb2AR_Active;
  wire BRAM_En_B_i;
  wire [14:0]D;
  wire [0:0]E;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_n_0_6794c86 ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_3_n_0_b541be8 ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_1_n_0_60377e1 ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_2_n_0_6a1ab57 ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_3_n_0_0302857 ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_4_n_0_453065b ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_1_n_0_c941b6d ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_2_n_0_11a31ae ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_3_n_0_5826479 ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_4_n_0_3e89f72 ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071 ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_3_n_0_a3b07ab ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_4_n_0_425e44b ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_5_n_0_b79abcb ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_0__i_1_n_0_3b4a66a ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_0__i_2_n_0_f3245e5 ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_1__i_1_n_0_9323c0d ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_1__i_2_n_0_ef4ab2f ;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_2__i_1_n_0_6ae07b9 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_0_afd5e32 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_BRST_MAX_WO_NARROW_brst_cnt_max_i_1_n_0_74a0570 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_0__axi_rdata_int_0__i__cbdea2c ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_10__axi_rdata_int_10___c316c0b ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_11__axi_rdata_int_11___f6abc8e ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_12__axi_rdata_int_12___051976d ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_13__axi_rdata_int_13___ef17877 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_14__axi_rdata_int_14___eda1062 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_15__axi_rdata_int_15___39d8b13 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_16__axi_rdata_int_16___4863ba6 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_17__axi_rdata_int_17___78d5042 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_18__axi_rdata_int_18___f3c438e ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_19__axi_rdata_int_19___88a8a10 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_20__axi_rdata_int_20___f907f75 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_21__axi_rdata_int_21___5cd571d ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_22__axi_rdata_int_22___3b7f7b9 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_23__axi_rdata_int_23___fbe8b2f ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_24__axi_rdata_int_24___ecd05a9 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_25__axi_rdata_int_25___4d6c85b ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_26__axi_rdata_int_26___a76bb3b ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_27__axi_rdata_int_27___0157642 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_28__axi_rdata_int_28___b0a5d7c ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_29__axi_rdata_int_29___0994f33 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_2__axi_rdata_int_2__i__85ffbc0 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_30__axi_rdata_int_30___9fb2710 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___71431ba ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___c338934 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_3__axi_rdata_int_3__i__b65330b ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_4__axi_rdata_int_4__i__14a34c8 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_5__axi_rdata_int_5__i__22798a9 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_6__axi_rdata_int_6__i__e1ca4ca ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_7__axi_rdata_int_7__i__9d6410c ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_8__axi_rdata_int_8__i__091d9f9 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_9__axi_rdata_int_9__i__1c78a6f ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_i_1_n_0_1481d78 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_i_1_n_0_b1b8c5c ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_0__i_1_n_0_ad2691b ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_10__i_1_n_0_d1df9c2 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_11__i_1_n_0_ef48a26 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_12__i_1_n_0_e0b0fcf ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_1__i_1_n_0_b944abf ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_2__i_1_n_0_acf57a4 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_3__i_1_n_0_5254c78 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_4__i_1_n_0_7b97654 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_5__i_1_n_0_e9f4baa ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_6__i_1_n_0_d67c492 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_7__i_1_n_0_be8b498 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_8__i_1_n_0_35e4171 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_9__i_1_n_0_416ffbd ;
  wire esc_GEN_NO_RD_CMD_OPT_I_WRAP_BRST_n_17_bb20d7a ;
  wire esc_GEN_NO_RD_CMD_OPT_I_WRAP_BRST_n_18_a16cbe7 ;
  wire esc_GEN_NO_RD_CMD_OPT_act_rd_burst_i_1_n_0_960cf06 ;
  wire esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_1_n_0_47fbcad ;
  wire esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_3_n_0_1715bf3 ;
  wire esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_4_n_0_c02b5a0 ;
  wire esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_5_n_0_aff0cda ;
  wire esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_6_n_0_df59b12 ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_1_n_0_fc66297 ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_2_n_0_e1c9416 ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_3_n_0_a8407fb ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_0_3cf0d99 ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rvalid_clr_ok_i_1_n_0_5022dbe ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rvalid_clr_ok_i_2_n_0_0445914 ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_i_1_n_0_a4fc85a ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5 ;
  wire esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_n_0_a10bed0 ;
  wire esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_1_n_0_1455849 ;
  wire esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_2_n_0_b0bf0d4 ;
  wire esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_5_n_0_4614b2d ;
  wire esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_6_n_0_fdc76b2 ;
  wire esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_7_n_0_5171dc6 ;
  wire esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_8_n_0_e739311 ;
  wire esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_9_n_0_216be6b ;
  wire esc_GEN_NO_RD_CMD_OPT_bram_en_int_reg_i_4_n_0_306144d ;
  wire esc_GEN_NO_RD_CMD_OPT_brst_cnt_6__i_2_n_0_326a996 ;
  wire esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989 ;
  wire esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_3_n_0_74a3160 ;
  wire esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_4_n_0_f716194 ;
  wire [7:0]esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d ;
  wire esc_GEN_NO_RD_CMD_OPT_brst_one_i_1_n_0_3f345ef ;
  wire esc_GEN_NO_RD_CMD_OPT_brst_one_i_2_n_0_6f3810c ;
  wire esc_GEN_NO_RD_CMD_OPT_brst_zero_i_1_n_0_726de18 ;
  wire esc_GEN_NO_RD_CMD_OPT_brst_zero_i_2_n_0_1adf7a4 ;
  wire esc_GEN_NO_RD_CMD_OPT_curr_wrap_burst_reg_i_1_n_0_652f3c5 ;
  wire esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_n_0_a9b7297 ;
  wire esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_3_n_0_fd44a63 ;
  wire esc_GEN_NO_RD_CMD_OPT_end_brst_rd_clr_i_1_n_0_f643e1a ;
  wire esc_GEN_NO_RD_CMD_OPT_end_brst_rd_i_1_n_0_24dfd54 ;
  wire esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_n_0_5a64921 ;
  wire esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_3_n_0_2c1b1c9 ;
  wire esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_4_n_0_e0d5aa6 ;
  wire esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_5_n_0_a8376f4 ;
  wire esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_6_n_0_51f0397 ;
  wire esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_1_n_0_14bd384 ;
  wire esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_2_n_0_897ef2d ;
  wire esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_3_n_0_7b48e3d ;
  wire esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_4_n_0_c9064de ;
  wire esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_6_n_0_d0dc7d9 ;
  wire esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_1_n_0_7903c77 ;
  wire esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_2_n_0_176cec6 ;
  wire esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_3_n_0_add223d ;
  wire [9:0]Q;
  wire act_rd_burst;
  wire act_rd_burst_set;
  wire act_rd_burst_two;
  wire ar_active_d1;
  wire ar_active_re;
  wire axi_rd_burst;
  wire axi_rd_burst0;
  wire axi_rd_burst_two;
  wire axi_rdata_en;
  wire [13:0]axi_rid_temp;
  wire axi_rvalid_clr_ok;
  wire axi_rvalid_set;
  wire axi_rvalid_set_cmb;
  wire [31:0]bram_rddata_a;
  wire brst_cnt_max;
  wire brst_cnt_max_d1;
  wire brst_one;
  wire brst_zero;
  wire curr_fixed_burst;
  wire curr_fixed_burst_reg;
  wire curr_fixed_burst_reg_0;
  wire curr_wrap_burst_reg;
  wire disable_b2b_brst;
  wire disable_b2b_brst_cmb;
  wire end_brst_rd;
  wire end_brst_rd_clr;
  wire end_brst_rd_clr_cmb;
  wire last_bram_addr;
  wire last_bram_addr0;
  wire p_0_in;
  wire [7:0]p_0_in__0;
  wire pend_rd_op;
  wire [3:0]rd_data_sm_cs;
  wire [3:0]rd_data_sm_ns;
  wire [31:0]rd_skid_buf;
  wire rd_skid_buf_ld;
  wire rd_skid_buf_ld_cmb;
  wire rd_skid_buf_ld_reg;
  wire rddata_mux_sel;
  wire [2:0]rlast_sm_cs;
  wire s_axi_aclk;
  wire [14:0]s_axi_araddr;
  wire [1:0]s_axi_arburst;
  wire s_axi_aresetn;
  wire s_axi_aresetn_0;
  wire [13:0]s_axi_arid;
  wire [7:0]s_axi_arlen;
  wire [31:0]s_axi_rdata;
  wire [13:0]s_axi_rid;
  wire s_axi_rready;
  wire s_axi_rready_0;
  wire sng_bram_addr_ld_en;

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_1_2966bf3
  assign rd_data_sm_ns[0] = ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_3_n_0_b541be8) ? (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[3]) ? (1'b0) : (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_n_0_6794c86))) : (((rd_data_sm_cs[3]) ? (((rd_data_sm_cs[1]) ? (1'b0) : (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_n_0_6794c86))) : (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_n_0_6794c86))))) : (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_3_n_0_0302857) ? (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[3]) ? (1'b0) : (((rd_data_sm_cs[1]) ? (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_n_0_6794c86) : (1'b1))))) : (((rd_data_sm_cs[3]) ? (((rd_data_sm_cs[1]) ? (1'b0) : (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_n_0_6794c86))) : (((rd_data_sm_cs[1]) ? (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_n_0_6794c86) : (1'b1))))))) : (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[3]) ? (1'b0) : (((rd_data_sm_cs[1]) ? (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_n_0_6794c86) : (1'b1))))) : (((rd_data_sm_cs[3]) ? (((rd_data_sm_cs[1]) ? (1'b0) : (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_n_0_6794c86))) : (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_n_0_6794c86))))))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_4f5cd51
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_2_n_0_6794c86 = ((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[0]) ? (((ar_active_re) ? (((rd_data_sm_cs[1]) ? (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)) : (1'b0))) : (((pend_rd_op) ? (((rd_data_sm_cs[1]) ? (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)) : (1'b0))) : (1'b0))))) : (1'b1))) : (((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[1]) ? (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)) : (1'b0))) : (1'b1))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_3_9be3157
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_0__i_3_n_0_b541be8 = ((act_rd_burst) ? (((rd_data_sm_cs[2]) ? (((ar_active_re) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (~(s_axi_rready)) : (1'b1))))) : (1'b0))) : (((act_rd_burst_two) ? (((rd_data_sm_cs[2]) ? (((ar_active_re) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (~(s_axi_rready)) : (1'b1))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_1_419064e
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_1_n_0_60377e1 = ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_4_n_0_453065b) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_4_n_0_425e44b) ? (((rd_data_sm_cs[2]) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_2_n_0_6a1ab57) ? (~(rd_data_sm_cs[3])) : (1'b0))) : (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_3_n_0_0302857) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_2_n_0_6a1ab57) ? (~(rd_data_sm_cs[3])) : (1'b0))) : (~(rd_data_sm_cs[3])))))) : (((rd_data_sm_cs[2]) ? (~(rd_data_sm_cs[3])) : (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_3_n_0_0302857) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_2_n_0_6a1ab57) ? (~(rd_data_sm_cs[3])) : (1'b0))) : (~(rd_data_sm_cs[3])))))))) : (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_2_n_0_6a1ab57) ? (~(rd_data_sm_cs[3])) : (1'b0))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_2_fbf0a2c
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_2_n_0_6a1ab57 = ((end_brst_rd) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[1]) ? (~(rd_data_sm_cs[0])) : (1'b0))) : (1'b0))) : (((rd_data_sm_cs[1]) ? (~(rd_data_sm_cs[0])) : (1'b0))))) : (((brst_zero) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[1]) ? (~(rd_data_sm_cs[0])) : (1'b0))) : (1'b0))) : (((rd_data_sm_cs[1]) ? (~(rd_data_sm_cs[0])) : (1'b0))))) : (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (((rd_data_sm_cs[2]) ? (~(rd_data_sm_cs[0])) : (1'b0))) : (((rd_data_sm_cs[2]) ? (~(rd_data_sm_cs[0])) : (((rd_data_sm_cs[1]) ? (~(rd_data_sm_cs[0])) : (1'b0))))))))));

  // Reconstructed LUT2: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_3_f627464
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_3_n_0_0302857 = ((axi_rd_burst) ? (1'b0) : (~(esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356)));

  // Reconstructed LUT2: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_4_ea582b3
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_4_n_0_453065b = ((rd_data_sm_cs[1]) ? (1'b0) : (rd_data_sm_cs[0]));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_1_38f2177
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_1_n_0_c941b6d = ((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[0]) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_3_n_0_5826479) ? (~(rd_data_sm_cs[3])) : (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_2_n_0_11a31ae) ? (~(rd_data_sm_cs[3])) : (1'b0))))) : (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_2_n_0_11a31ae) ? (~(rd_data_sm_cs[3])) : (1'b0))))) : (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_4_n_0_3e89f72) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_2_n_0_11a31ae) ? (~(rd_data_sm_cs[3])) : (1'b0))) : (((rd_data_sm_cs[0]) ? (~(rd_data_sm_cs[3])) : (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_2_n_0_11a31ae) ? (~(rd_data_sm_cs[3])) : (1'b0))))))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_2_1160d7c
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_2_n_0_11a31ae = ((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[2]) ? (1'b0) : (((rd_data_sm_cs[1]) ? (esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) : (1'b0))))) : (((rd_data_sm_cs[2]) ? (((end_brst_rd) ? (1'b1) : (((brst_zero) ? (1'b1) : (rd_data_sm_cs[1]))))) : (((rd_data_sm_cs[1]) ? (esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) : (1'b0))))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_3_79c43e7
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_3_n_0_5826479 = ((ar_active_re) ? (((s_axi_rready) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (((act_rd_burst_two) ? (1'b0) : (((act_rd_burst) ? (1'b0) : (~(rd_data_sm_cs[1])))))) : (~(rd_data_sm_cs[1])))) : (~(rd_data_sm_cs[1])))) : (~(rd_data_sm_cs[1])));

  // Reconstructed LUT3: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_4_c00aa5e
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_4_n_0_3e89f72 = ((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (~(rd_data_sm_cs[1])) : (((axi_rd_burst) ? (~(rd_data_sm_cs[1])) : (1'b0))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_6cf4791
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071 = ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_3_n_0_a3b07ab) ? (((rd_data_sm_cs[3]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (1'b0) : (((rd_data_sm_cs[2]) ? (1'b0) : (((rd_data_sm_cs[0]) ? (1'b0) : (~(rd_data_sm_cs[1])))))))) : (1'b1))) : (((rd_data_sm_cs[3]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (1'b0) : (((rd_data_sm_cs[2]) ? (1'b0) : (((rd_data_sm_cs[0]) ? (1'b0) : (~(rd_data_sm_cs[1])))))))) : (1'b0))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_2_a50cc5c
  assign rd_data_sm_ns[3] = ((rd_data_sm_cs[1]) ? (((rd_data_sm_cs[3]) ? (1'b0) : (((rd_data_sm_cs[2]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (rd_data_sm_cs[0]) : (1'b0))) : (1'b0))))) : (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_4_n_0_425e44b) ? (((rd_data_sm_cs[3]) ? (1'b0) : (((rd_data_sm_cs[2]) ? (rd_data_sm_cs[0]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_3_4dd9496
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_3_n_0_a3b07ab = ((rd_data_sm_cs[1]) ? (((ar_active_re) ? (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[0]) ? (1'b1) : (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)))) : (((rd_data_sm_cs[0]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (1'b1) : (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_5_n_0_b79abcb))) : (1'b1))))) : (((rd_data_sm_cs[2]) ? (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)) : (((rd_data_sm_cs[0]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (1'b1) : (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_5_n_0_b79abcb))) : (1'b1))))))) : (((ar_active_re) ? (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[0]) ? (1'b1) : (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)))) : (1'b1))) : (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[0]) ? (1'b1) : (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)))) : (rd_data_sm_cs[0]))))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_4_c1e0648
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_4_n_0_425e44b = ((act_rd_burst) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (((s_axi_rready) ? (((Arb2AR_Active) ? (~(ar_active_d1)) : (1'b0))) : (1'b0))) : (1'b0))) : (((act_rd_burst_two) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (((s_axi_rready) ? (((Arb2AR_Active) ? (~(ar_active_d1)) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT2: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_5_f9ca5ea
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_5_n_0_b79abcb = ((brst_zero) ? (1'b1) : (end_brst_rd));

  // Reconstructed FDRE: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_0_57eab98
  reg recovered_17_q = 1'b0;
  assign rd_data_sm_cs[0] = recovered_17_q;
  wire recovered_17_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_17_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) || ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) === 1'bz) || (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) === 1'bx) && (recovered_17_q == (rd_data_sm_ns[0])))) recovered_17_q <= (rd_data_sm_ns[0]);
  end

  // Reconstructed FDRE: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c
  reg recovered_18_q = 1'b0;
  assign rd_data_sm_cs[1] = recovered_18_q;
  wire recovered_18_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_18_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) || ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) === 1'bz) || (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) === 1'bx) && (recovered_18_q == (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_1_n_0_60377e1)))) recovered_18_q <= (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_1_n_0_60377e1);
  end

  // Reconstructed FDRE: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_2_c659583
  reg recovered_19_q = 1'b0;
  assign rd_data_sm_cs[2] = recovered_19_q;
  wire recovered_19_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_19_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) || ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) === 1'bz) || (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) === 1'bx) && (recovered_19_q == (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_1_n_0_c941b6d)))) recovered_19_q <= (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_2__i_1_n_0_c941b6d);
  end

  // Reconstructed FDRE: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_3_2f781b6
  reg recovered_20_q = 1'b0;
  assign rd_data_sm_cs[3] = recovered_20_q;
  wire recovered_20_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_20_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) || ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) === 1'bz) || (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_1_n_0_3b84071) === 1'bx) && (recovered_20_q == (rd_data_sm_ns[3])))) recovered_20_q <= (rd_data_sm_ns[3]);
  end

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_0__i_1_7de1a81
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_0__i_1_n_0_3b4a66a = ((last_bram_addr) ? (((rlast_sm_cs[2]) ? (rlast_sm_cs[0]) : (((rlast_sm_cs[0]) ? (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) : (((rlast_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (1'b0) : (~(esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_0__i_2_n_0_f3245e5)))) : (~(esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_0__i_2_n_0_f3245e5)))))))) : (((rlast_sm_cs[2]) ? (rlast_sm_cs[0]) : (((rlast_sm_cs[0]) ? (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) : (((rlast_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (1'b0) : (~(esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_0__i_2_n_0_f3245e5)))) : (1'b0))))))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_0__i_2_cea4ea8
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_0__i_2_n_0_f3245e5 = ((axi_rd_burst) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (1'b0) : (((act_rd_burst_two) ? (1'b0) : (((s_axi_rready) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (1'b0) : (~(rlast_sm_cs[1])))) : (~(rlast_sm_cs[1])))))))) : (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (1'b0) : (~(rlast_sm_cs[1])))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_1__i_1_1cc3e25
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_1__i_1_n_0_9323c0d = ((last_bram_addr) ? (((rlast_sm_cs[2]) ? (rlast_sm_cs[1]) : (((rlast_sm_cs[0]) ? (((rlast_sm_cs[1]) ? (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) : (1'b0))) : (((rlast_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (1'b1) : (~(esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_1__i_2_n_0_ef4ab2f)))) : (~(esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_1__i_2_n_0_ef4ab2f)))))))) : (((rlast_sm_cs[2]) ? (rlast_sm_cs[1]) : (((rlast_sm_cs[0]) ? (((rlast_sm_cs[1]) ? (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) : (1'b0))) : (((rlast_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (1'b1) : (~(esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_1__i_2_n_0_ef4ab2f)))) : (1'b0))))))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_1__i_2_1c979cc
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_1__i_2_n_0_ef4ab2f = ((axi_rd_burst) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (((s_axi_rready) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (1'b0) : (~(rlast_sm_cs[1])))) : (~(rlast_sm_cs[1])))) : (((act_rd_burst_two) ? (((s_axi_rready) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (1'b0) : (~(rlast_sm_cs[1])))) : (~(rlast_sm_cs[1])))) : (1'b0))))) : (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (((s_axi_rready) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (1'b0) : (~(rlast_sm_cs[1])))) : (~(rlast_sm_cs[1])))) : (~(rlast_sm_cs[1])))));

  // Reconstructed LUT6: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_2__i_1_bccb55d
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_2__i_1_n_0_6ae07b9 = ((last_bram_addr) ? (((rlast_sm_cs[2]) ? (((rlast_sm_cs[0]) ? (1'b1) : (((rlast_sm_cs[1]) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09))))) : (((rlast_sm_cs[0]) ? (((rlast_sm_cs[1]) ? (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)) : (1'b0))) : (((rlast_sm_cs[1]) ? (1'b0) : (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_3_n_0_0302857))))))) : (((rlast_sm_cs[2]) ? (((rlast_sm_cs[0]) ? (1'b1) : (((rlast_sm_cs[1]) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09))))) : (((rlast_sm_cs[0]) ? (((rlast_sm_cs[1]) ? (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)) : (1'b0))) : (1'b0))))));

  // Reconstructed FDRE: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_reg_0_c79a8e7
  reg recovered_26_q = 1'b0;
  assign rlast_sm_cs[0] = recovered_26_q;
  wire recovered_26_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_26_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_26_q == (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_0__i_1_n_0_3b4a66a)))) recovered_26_q <= (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_0__i_1_n_0_3b4a66a);
  end

  // Reconstructed FDRE: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_reg_1_a925468
  reg recovered_27_q = 1'b0;
  assign rlast_sm_cs[1] = recovered_27_q;
  wire recovered_27_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_27_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_27_q == (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_1__i_1_n_0_9323c0d)))) recovered_27_q <= (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_1__i_1_n_0_9323c0d);
  end

  // Reconstructed FDRE: esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_reg_2_bc8de2a
  reg recovered_28_q = 1'b0;
  assign rlast_sm_cs[2] = recovered_28_q;
  wire recovered_28_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_28_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_28_q == (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_2__i_1_n_0_6ae07b9)))) recovered_28_q <= (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rlast_sm_cs_2__i_1_n_0_6ae07b9);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_3975a1b
  reg recovered_29_q = 1'b0;
  assign ar_active_d1 = recovered_29_q;
  wire recovered_29_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_29_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_29_q == (esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_0_afd5e32)))) recovered_29_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_0_afd5e32);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_GEN_BRST_MAX_WO_NARROW_brst_cnt_max_i_1_917980b
  assign esc_GEN_NO_RD_CMD_OPT_GEN_BRST_MAX_WO_NARROW_brst_cnt_max_i_1_n_0_74a0570 = ((Arb2AR_Active) ? (((ar_active_d1) ? (((s_axi_aresetn) ? (((brst_cnt_max) ? (1'b1) : (((brst_zero) ? (~(pend_rd_op)) : (1'b0))))) : (1'b0))) : (1'b0))) : (((s_axi_aresetn) ? (brst_cnt_max) : (1'b0))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_BRST_MAX_WO_NARROW_brst_cnt_max_reg_af4af51
  reg recovered_31_q = 1'b0;
  assign brst_cnt_max = recovered_31_q;
  wire recovered_31_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_31_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_31_q == (esc_GEN_NO_RD_CMD_OPT_GEN_BRST_MAX_WO_NARROW_brst_cnt_max_i_1_n_0_74a0570)))) recovered_31_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_BRST_MAX_WO_NARROW_brst_cnt_max_i_1_n_0_74a0570);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_0__axi_rdata_int_0__i__fd6a4e2
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_0__axi_rdata_int_0__i__cbdea2c = ((rddata_mux_sel) ? (rd_skid_buf[0]) : (bram_rddata_a[0]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_0__axi_rdata_int_reg_0_d2f64f5
  reg recovered_33_q = 1'b0;
  assign s_axi_rdata[0] = recovered_33_q;
  wire recovered_33_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_33_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_33_q == 1'b0))) recovered_33_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_33_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_0__axi_rdata_int_0__i__cbdea2c)))) recovered_33_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_0__axi_rdata_int_0__i__cbdea2c);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_10__axi_rdata_int_10___effa77e
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_10__axi_rdata_int_10___c316c0b = ((rddata_mux_sel) ? (rd_skid_buf[10]) : (bram_rddata_a[10]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_10__axi_rdata_int_reg__1e66135
  reg recovered_35_q = 1'b0;
  assign s_axi_rdata[10] = recovered_35_q;
  wire recovered_35_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_35_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_35_q == 1'b0))) recovered_35_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_35_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_10__axi_rdata_int_10___c316c0b)))) recovered_35_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_10__axi_rdata_int_10___c316c0b);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_11__axi_rdata_int_11___310eb4e
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_11__axi_rdata_int_11___f6abc8e = ((rddata_mux_sel) ? (rd_skid_buf[11]) : (bram_rddata_a[11]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_11__axi_rdata_int_reg__2c453f3
  reg recovered_37_q = 1'b0;
  assign s_axi_rdata[11] = recovered_37_q;
  wire recovered_37_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_37_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_37_q == 1'b0))) recovered_37_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_37_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_11__axi_rdata_int_11___f6abc8e)))) recovered_37_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_11__axi_rdata_int_11___f6abc8e);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_12__axi_rdata_int_12___e41a027
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_12__axi_rdata_int_12___051976d = ((rddata_mux_sel) ? (rd_skid_buf[12]) : (bram_rddata_a[12]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_12__axi_rdata_int_reg__992c339
  reg recovered_39_q = 1'b0;
  assign s_axi_rdata[12] = recovered_39_q;
  wire recovered_39_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_39_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_39_q == 1'b0))) recovered_39_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_39_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_12__axi_rdata_int_12___051976d)))) recovered_39_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_12__axi_rdata_int_12___051976d);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_13__axi_rdata_int_13___59c0b26
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_13__axi_rdata_int_13___ef17877 = ((rddata_mux_sel) ? (rd_skid_buf[13]) : (bram_rddata_a[13]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_13__axi_rdata_int_reg__e4efe44
  reg recovered_41_q = 1'b0;
  assign s_axi_rdata[13] = recovered_41_q;
  wire recovered_41_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_41_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_41_q == 1'b0))) recovered_41_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_41_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_13__axi_rdata_int_13___ef17877)))) recovered_41_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_13__axi_rdata_int_13___ef17877);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_14__axi_rdata_int_14___ae777fa
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_14__axi_rdata_int_14___eda1062 = ((rddata_mux_sel) ? (rd_skid_buf[14]) : (bram_rddata_a[14]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_14__axi_rdata_int_reg__95b41dd
  reg recovered_43_q = 1'b0;
  assign s_axi_rdata[14] = recovered_43_q;
  wire recovered_43_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_43_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_43_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_14__axi_rdata_int_14___eda1062)))) recovered_43_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_14__axi_rdata_int_14___eda1062);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_15__axi_rdata_int_15___70e32ae
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_15__axi_rdata_int_15___39d8b13 = ((rddata_mux_sel) ? (rd_skid_buf[15]) : (bram_rddata_a[15]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_15__axi_rdata_int_reg__9d9040c
  reg recovered_45_q = 1'b0;
  assign s_axi_rdata[15] = recovered_45_q;
  wire recovered_45_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_45_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_45_q == 1'b0))) recovered_45_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_45_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_15__axi_rdata_int_15___39d8b13)))) recovered_45_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_15__axi_rdata_int_15___39d8b13);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_16__axi_rdata_int_16___0f54373
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_16__axi_rdata_int_16___4863ba6 = ((rddata_mux_sel) ? (rd_skid_buf[16]) : (bram_rddata_a[16]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_16__axi_rdata_int_reg__e82a1e8
  reg recovered_47_q = 1'b0;
  assign s_axi_rdata[16] = recovered_47_q;
  wire recovered_47_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_47_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_47_q == 1'b0))) recovered_47_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_47_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_16__axi_rdata_int_16___4863ba6)))) recovered_47_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_16__axi_rdata_int_16___4863ba6);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_17__axi_rdata_int_17___cb6b6b9
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_17__axi_rdata_int_17___78d5042 = ((rddata_mux_sel) ? (rd_skid_buf[17]) : (bram_rddata_a[17]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_17__axi_rdata_int_reg__180986b
  reg recovered_49_q = 1'b0;
  assign s_axi_rdata[17] = recovered_49_q;
  wire recovered_49_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_49_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_49_q == 1'b0))) recovered_49_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_49_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_17__axi_rdata_int_17___78d5042)))) recovered_49_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_17__axi_rdata_int_17___78d5042);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_18__axi_rdata_int_18___9373c83
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_18__axi_rdata_int_18___f3c438e = ((rddata_mux_sel) ? (rd_skid_buf[18]) : (bram_rddata_a[18]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_18__axi_rdata_int_reg__eaf5381
  reg recovered_51_q = 1'b0;
  assign s_axi_rdata[18] = recovered_51_q;
  wire recovered_51_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_51_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_51_q == 1'b0))) recovered_51_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_51_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_18__axi_rdata_int_18___f3c438e)))) recovered_51_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_18__axi_rdata_int_18___f3c438e);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_19__axi_rdata_int_19___288d36b
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_19__axi_rdata_int_19___88a8a10 = ((rddata_mux_sel) ? (rd_skid_buf[19]) : (bram_rddata_a[19]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_19__axi_rdata_int_reg__cb6d552
  reg recovered_53_q = 1'b0;
  assign s_axi_rdata[19] = recovered_53_q;
  wire recovered_53_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_53_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_53_q == 1'b0))) recovered_53_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_53_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_19__axi_rdata_int_19___88a8a10)))) recovered_53_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_19__axi_rdata_int_19___88a8a10);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_1__axi_rdata_int_1__i__57787f2
  assign p_0_in = ((rddata_mux_sel) ? (rd_skid_buf[1]) : (bram_rddata_a[1]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_1__axi_rdata_int_reg_1_9161e4e
  reg recovered_55_q = 1'b0;
  assign s_axi_rdata[1] = recovered_55_q;
  wire recovered_55_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_55_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_55_q == 1'b0))) recovered_55_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_55_q == (p_0_in)))) recovered_55_q <= (p_0_in);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_20__axi_rdata_int_20___d1c5473
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_20__axi_rdata_int_20___f907f75 = ((rddata_mux_sel) ? (rd_skid_buf[20]) : (bram_rddata_a[20]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_20__axi_rdata_int_reg__6b052f6
  reg recovered_57_q = 1'b0;
  assign s_axi_rdata[20] = recovered_57_q;
  wire recovered_57_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_57_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_57_q == 1'b0))) recovered_57_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_57_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_20__axi_rdata_int_20___f907f75)))) recovered_57_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_20__axi_rdata_int_20___f907f75);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_21__axi_rdata_int_21___4ad97e3
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_21__axi_rdata_int_21___5cd571d = ((rddata_mux_sel) ? (rd_skid_buf[21]) : (bram_rddata_a[21]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_21__axi_rdata_int_reg__d139ed8
  reg recovered_59_q = 1'b0;
  assign s_axi_rdata[21] = recovered_59_q;
  wire recovered_59_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_59_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_59_q == 1'b0))) recovered_59_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_59_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_21__axi_rdata_int_21___5cd571d)))) recovered_59_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_21__axi_rdata_int_21___5cd571d);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_22__axi_rdata_int_22___dc0daf2
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_22__axi_rdata_int_22___3b7f7b9 = ((rddata_mux_sel) ? (rd_skid_buf[22]) : (bram_rddata_a[22]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_22__axi_rdata_int_reg__7e4adcb
  reg recovered_61_q = 1'b0;
  assign s_axi_rdata[22] = recovered_61_q;
  wire recovered_61_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_61_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_61_q == 1'b0))) recovered_61_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_61_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_22__axi_rdata_int_22___3b7f7b9)))) recovered_61_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_22__axi_rdata_int_22___3b7f7b9);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_23__axi_rdata_int_23___c924dd1
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_23__axi_rdata_int_23___fbe8b2f = ((rddata_mux_sel) ? (rd_skid_buf[23]) : (bram_rddata_a[23]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_23__axi_rdata_int_reg__58d963f
  reg recovered_63_q = 1'b0;
  assign s_axi_rdata[23] = recovered_63_q;
  wire recovered_63_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_63_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_63_q == 1'b0))) recovered_63_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_63_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_23__axi_rdata_int_23___fbe8b2f)))) recovered_63_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_23__axi_rdata_int_23___fbe8b2f);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_24__axi_rdata_int_24___777d5ea
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_24__axi_rdata_int_24___ecd05a9 = ((rddata_mux_sel) ? (rd_skid_buf[24]) : (bram_rddata_a[24]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_24__axi_rdata_int_reg__d716c5a
  reg recovered_65_q = 1'b0;
  assign s_axi_rdata[24] = recovered_65_q;
  wire recovered_65_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_65_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_65_q == 1'b0))) recovered_65_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_65_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_24__axi_rdata_int_24___ecd05a9)))) recovered_65_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_24__axi_rdata_int_24___ecd05a9);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_25__axi_rdata_int_25___488c3f8
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_25__axi_rdata_int_25___4d6c85b = ((rddata_mux_sel) ? (rd_skid_buf[25]) : (bram_rddata_a[25]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_25__axi_rdata_int_reg__baeb6ad
  reg recovered_67_q = 1'b0;
  assign s_axi_rdata[25] = recovered_67_q;
  wire recovered_67_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_67_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_67_q == 1'b0))) recovered_67_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_67_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_25__axi_rdata_int_25___4d6c85b)))) recovered_67_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_25__axi_rdata_int_25___4d6c85b);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_26__axi_rdata_int_26___0544d01
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_26__axi_rdata_int_26___a76bb3b = ((rddata_mux_sel) ? (rd_skid_buf[26]) : (bram_rddata_a[26]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_26__axi_rdata_int_reg__4f33221
  reg recovered_69_q = 1'b0;
  assign s_axi_rdata[26] = recovered_69_q;
  wire recovered_69_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_69_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_69_q == 1'b0))) recovered_69_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_69_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_26__axi_rdata_int_26___a76bb3b)))) recovered_69_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_26__axi_rdata_int_26___a76bb3b);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_27__axi_rdata_int_27___f2699a2
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_27__axi_rdata_int_27___0157642 = ((rddata_mux_sel) ? (rd_skid_buf[27]) : (bram_rddata_a[27]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_27__axi_rdata_int_reg__9436376
  reg recovered_71_q = 1'b0;
  assign s_axi_rdata[27] = recovered_71_q;
  wire recovered_71_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_71_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_71_q == 1'b0))) recovered_71_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_71_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_27__axi_rdata_int_27___0157642)))) recovered_71_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_27__axi_rdata_int_27___0157642);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_28__axi_rdata_int_28___baf9e8a
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_28__axi_rdata_int_28___b0a5d7c = ((rddata_mux_sel) ? (rd_skid_buf[28]) : (bram_rddata_a[28]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_28__axi_rdata_int_reg__d471104
  reg recovered_73_q = 1'b0;
  assign s_axi_rdata[28] = recovered_73_q;
  wire recovered_73_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_73_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_73_q == 1'b0))) recovered_73_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_73_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_28__axi_rdata_int_28___b0a5d7c)))) recovered_73_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_28__axi_rdata_int_28___b0a5d7c);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_29__axi_rdata_int_29___5ab7e7f
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_29__axi_rdata_int_29___0994f33 = ((rddata_mux_sel) ? (rd_skid_buf[29]) : (bram_rddata_a[29]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_29__axi_rdata_int_reg__897901a
  reg recovered_75_q = 1'b0;
  assign s_axi_rdata[29] = recovered_75_q;
  wire recovered_75_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_75_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_75_q == 1'b0))) recovered_75_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_75_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_29__axi_rdata_int_29___0994f33)))) recovered_75_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_29__axi_rdata_int_29___0994f33);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_2__axi_rdata_int_2__i__c60493d
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_2__axi_rdata_int_2__i__85ffbc0 = ((rddata_mux_sel) ? (rd_skid_buf[2]) : (bram_rddata_a[2]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_2__axi_rdata_int_reg_2_51e3780
  reg recovered_77_q = 1'b0;
  assign s_axi_rdata[2] = recovered_77_q;
  wire recovered_77_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_77_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_77_q == 1'b0))) recovered_77_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_77_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_2__axi_rdata_int_2__i__85ffbc0)))) recovered_77_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_2__axi_rdata_int_2__i__85ffbc0);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_30__axi_rdata_int_30___1e05246
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_30__axi_rdata_int_30___9fb2710 = ((rddata_mux_sel) ? (rd_skid_buf[30]) : (bram_rddata_a[30]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_30__axi_rdata_int_reg__e2ee4b1
  reg recovered_79_q = 1'b0;
  assign s_axi_rdata[30] = recovered_79_q;
  wire recovered_79_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_79_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_79_q == 1'b0))) recovered_79_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_79_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_30__axi_rdata_int_30___9fb2710)))) recovered_79_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_30__axi_rdata_int_30___9fb2710);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___2f043d1
  assign axi_rdata_en = ((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[1]) ? (((rd_data_sm_cs[2]) ? (1'b0) : (((rd_data_sm_cs[3]) ? (1'b0) : (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)))))) : (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[3]) ? (1'b0) : (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___c338934) : (1'b1))))) : (1'b0))))) : (((rd_data_sm_cs[1]) ? (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[3]) ? (1'b0) : (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)))) : (~(rd_data_sm_cs[3])))) : (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[3]) ? (1'b0) : (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)))) : (1'b0))))));

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___8a64346
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___71431ba = ((rddata_mux_sel) ? (rd_skid_buf[31]) : (bram_rddata_a[31]));

  // Reconstructed LUT2: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___06cacd9
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___c338934 = ((act_rd_burst) ? (1'b0) : (~(act_rd_burst_two)));

  // Reconstructed LUT2: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___e2f9827
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09 = ((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (~(s_axi_rready)) : (1'b1));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_reg__384ca80
  reg recovered_84_q = 1'b0;
  assign s_axi_rdata[31] = recovered_84_q;
  wire recovered_84_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_84_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_84_q == 1'b0))) recovered_84_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_84_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___71431ba)))) recovered_84_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___71431ba);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_3__axi_rdata_int_3__i__f33110f
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_3__axi_rdata_int_3__i__b65330b = ((rddata_mux_sel) ? (rd_skid_buf[3]) : (bram_rddata_a[3]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_3__axi_rdata_int_reg_3_a27deb1
  reg recovered_86_q = 1'b0;
  assign s_axi_rdata[3] = recovered_86_q;
  wire recovered_86_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_86_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_86_q == 1'b0))) recovered_86_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_86_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_3__axi_rdata_int_3__i__b65330b)))) recovered_86_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_3__axi_rdata_int_3__i__b65330b);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_4__axi_rdata_int_4__i__3f112f7
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_4__axi_rdata_int_4__i__14a34c8 = ((rddata_mux_sel) ? (rd_skid_buf[4]) : (bram_rddata_a[4]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_4__axi_rdata_int_reg_4_76e8ff1
  reg recovered_88_q = 1'b0;
  assign s_axi_rdata[4] = recovered_88_q;
  wire recovered_88_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_88_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_88_q == 1'b0))) recovered_88_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_88_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_4__axi_rdata_int_4__i__14a34c8)))) recovered_88_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_4__axi_rdata_int_4__i__14a34c8);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_5__axi_rdata_int_5__i__78752a7
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_5__axi_rdata_int_5__i__22798a9 = ((rddata_mux_sel) ? (rd_skid_buf[5]) : (bram_rddata_a[5]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_5__axi_rdata_int_reg_5_c4210e3
  reg recovered_90_q = 1'b0;
  assign s_axi_rdata[5] = recovered_90_q;
  wire recovered_90_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_90_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_90_q == 1'b0))) recovered_90_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_90_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_5__axi_rdata_int_5__i__22798a9)))) recovered_90_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_5__axi_rdata_int_5__i__22798a9);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_6__axi_rdata_int_6__i__b11a162
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_6__axi_rdata_int_6__i__e1ca4ca = ((rddata_mux_sel) ? (rd_skid_buf[6]) : (bram_rddata_a[6]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_6__axi_rdata_int_reg_6_b7900e7
  reg recovered_92_q = 1'b0;
  assign s_axi_rdata[6] = recovered_92_q;
  wire recovered_92_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_92_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_92_q == 1'b0))) recovered_92_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_92_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_6__axi_rdata_int_6__i__e1ca4ca)))) recovered_92_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_6__axi_rdata_int_6__i__e1ca4ca);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_7__axi_rdata_int_7__i__da82a82
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_7__axi_rdata_int_7__i__9d6410c = ((rddata_mux_sel) ? (rd_skid_buf[7]) : (bram_rddata_a[7]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_7__axi_rdata_int_reg_7_080b0bd
  reg recovered_94_q = 1'b0;
  assign s_axi_rdata[7] = recovered_94_q;
  wire recovered_94_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_94_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_94_q == 1'b0))) recovered_94_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_94_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_7__axi_rdata_int_7__i__9d6410c)))) recovered_94_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_7__axi_rdata_int_7__i__9d6410c);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_8__axi_rdata_int_8__i__9e0e2c9
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_8__axi_rdata_int_8__i__091d9f9 = ((rddata_mux_sel) ? (rd_skid_buf[8]) : (bram_rddata_a[8]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_8__axi_rdata_int_reg_8_632dbaa
  reg recovered_96_q = 1'b0;
  assign s_axi_rdata[8] = recovered_96_q;
  wire recovered_96_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_96_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_96_q == 1'b0))) recovered_96_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_96_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_8__axi_rdata_int_8__i__091d9f9)))) recovered_96_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_8__axi_rdata_int_8__i__091d9f9);
  end

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_9__axi_rdata_int_9__i__a4b3ed8
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_9__axi_rdata_int_9__i__1c78a6f = ((rddata_mux_sel) ? (rd_skid_buf[9]) : (bram_rddata_a[9]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_9__axi_rdata_int_reg_9_b28566a
  reg recovered_98_q = 1'b0;
  assign s_axi_rdata[9] = recovered_98_q;
  wire recovered_98_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_98_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_98_q == 1'b0))) recovered_98_q <= 1'b0;
    else if ((axi_rdata_en) || ((axi_rdata_en) === 1'bz) || (((axi_rdata_en) === 1'bx) && (recovered_98_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_9__axi_rdata_int_9__i__1c78a6f)))) recovered_98_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_9__axi_rdata_int_9__i__1c78a6f);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_31__i_1_7da6244
  assign rd_skid_buf_ld = ((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (rd_skid_buf_ld_reg) : (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[0]) ? (rd_skid_buf_ld_reg) : (((rd_data_sm_cs[1]) ? (rd_skid_buf_ld_reg) : (((rd_data_sm_cs[3]) ? (rd_skid_buf_ld_reg) : (1'b1))))))) : (rd_skid_buf_ld_reg))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_0_2210a6b
  reg recovered_100_q = 1'b0;
  assign rd_skid_buf[0] = recovered_100_q;
  wire recovered_100_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_100_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_100_q == 1'b0))) recovered_100_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_100_q == (bram_rddata_a[0])))) recovered_100_q <= (bram_rddata_a[0]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_10_320b5ca
  reg recovered_101_q = 1'b0;
  assign rd_skid_buf[10] = recovered_101_q;
  wire recovered_101_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_101_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_101_q == 1'b0))) recovered_101_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_101_q == (bram_rddata_a[10])))) recovered_101_q <= (bram_rddata_a[10]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_11_38e2ba5
  reg recovered_102_q = 1'b0;
  assign rd_skid_buf[11] = recovered_102_q;
  wire recovered_102_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_102_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_102_q == 1'b0))) recovered_102_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_102_q == (bram_rddata_a[11])))) recovered_102_q <= (bram_rddata_a[11]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_12_f70f756
  reg recovered_103_q = 1'b0;
  assign rd_skid_buf[12] = recovered_103_q;
  wire recovered_103_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_103_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_103_q == 1'b0))) recovered_103_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_103_q == (bram_rddata_a[12])))) recovered_103_q <= (bram_rddata_a[12]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_13_6ae3bdd
  reg recovered_104_q = 1'b0;
  assign rd_skid_buf[13] = recovered_104_q;
  wire recovered_104_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_104_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_104_q == 1'b0))) recovered_104_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_104_q == (bram_rddata_a[13])))) recovered_104_q <= (bram_rddata_a[13]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_14_d674a80
  reg recovered_105_q = 1'b0;
  assign rd_skid_buf[14] = recovered_105_q;
  wire recovered_105_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_105_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_105_q == 1'b0))) recovered_105_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_105_q == (bram_rddata_a[14])))) recovered_105_q <= (bram_rddata_a[14]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_15_5db60d1
  reg recovered_106_q = 1'b0;
  assign rd_skid_buf[15] = recovered_106_q;
  wire recovered_106_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_106_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_106_q == 1'b0))) recovered_106_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_106_q == (bram_rddata_a[15])))) recovered_106_q <= (bram_rddata_a[15]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_16_7182daf
  reg recovered_107_q = 1'b0;
  assign rd_skid_buf[16] = recovered_107_q;
  wire recovered_107_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_107_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_107_q == 1'b0))) recovered_107_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_107_q == (bram_rddata_a[16])))) recovered_107_q <= (bram_rddata_a[16]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_17_8f5278f
  reg recovered_108_q = 1'b0;
  assign rd_skid_buf[17] = recovered_108_q;
  wire recovered_108_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_108_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_108_q == 1'b0))) recovered_108_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_108_q == (bram_rddata_a[17])))) recovered_108_q <= (bram_rddata_a[17]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_18_c59c65e
  reg recovered_109_q = 1'b0;
  assign rd_skid_buf[18] = recovered_109_q;
  wire recovered_109_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_109_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_109_q == 1'b0))) recovered_109_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_109_q == (bram_rddata_a[18])))) recovered_109_q <= (bram_rddata_a[18]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_19_ae68c43
  reg recovered_110_q = 1'b0;
  assign rd_skid_buf[19] = recovered_110_q;
  wire recovered_110_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_110_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_110_q == 1'b0))) recovered_110_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_110_q == (bram_rddata_a[19])))) recovered_110_q <= (bram_rddata_a[19]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_1_91a4c8e
  reg recovered_111_q = 1'b0;
  assign rd_skid_buf[1] = recovered_111_q;
  wire recovered_111_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_111_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_111_q == 1'b0))) recovered_111_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_111_q == (bram_rddata_a[1])))) recovered_111_q <= (bram_rddata_a[1]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_20_42c4034
  reg recovered_112_q = 1'b0;
  assign rd_skid_buf[20] = recovered_112_q;
  wire recovered_112_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_112_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_112_q == 1'b0))) recovered_112_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_112_q == (bram_rddata_a[20])))) recovered_112_q <= (bram_rddata_a[20]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_21_67a60b2
  reg recovered_113_q = 1'b0;
  assign rd_skid_buf[21] = recovered_113_q;
  wire recovered_113_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_113_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_113_q == 1'b0))) recovered_113_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_113_q == (bram_rddata_a[21])))) recovered_113_q <= (bram_rddata_a[21]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_22_db71b18
  reg recovered_114_q = 1'b0;
  assign rd_skid_buf[22] = recovered_114_q;
  wire recovered_114_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_114_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_114_q == 1'b0))) recovered_114_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_114_q == (bram_rddata_a[22])))) recovered_114_q <= (bram_rddata_a[22]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_23_f4820a8
  reg recovered_115_q = 1'b0;
  assign rd_skid_buf[23] = recovered_115_q;
  wire recovered_115_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_115_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_115_q == 1'b0))) recovered_115_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_115_q == (bram_rddata_a[23])))) recovered_115_q <= (bram_rddata_a[23]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_24_00e41df
  reg recovered_116_q = 1'b0;
  assign rd_skid_buf[24] = recovered_116_q;
  wire recovered_116_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_116_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_116_q == 1'b0))) recovered_116_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_116_q == (bram_rddata_a[24])))) recovered_116_q <= (bram_rddata_a[24]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_25_7f46a78
  reg recovered_117_q = 1'b0;
  assign rd_skid_buf[25] = recovered_117_q;
  wire recovered_117_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_117_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_117_q == 1'b0))) recovered_117_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_117_q == (bram_rddata_a[25])))) recovered_117_q <= (bram_rddata_a[25]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_26_b8e0ae7
  reg recovered_118_q = 1'b0;
  assign rd_skid_buf[26] = recovered_118_q;
  wire recovered_118_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_118_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_118_q == 1'b0))) recovered_118_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_118_q == (bram_rddata_a[26])))) recovered_118_q <= (bram_rddata_a[26]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_27_35642d7
  reg recovered_119_q = 1'b0;
  assign rd_skid_buf[27] = recovered_119_q;
  wire recovered_119_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_119_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_119_q == 1'b0))) recovered_119_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_119_q == (bram_rddata_a[27])))) recovered_119_q <= (bram_rddata_a[27]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_28_f333a63
  reg recovered_120_q = 1'b0;
  assign rd_skid_buf[28] = recovered_120_q;
  wire recovered_120_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_120_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_120_q == 1'b0))) recovered_120_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_120_q == (bram_rddata_a[28])))) recovered_120_q <= (bram_rddata_a[28]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_29_1a975a9
  reg recovered_121_q = 1'b0;
  assign rd_skid_buf[29] = recovered_121_q;
  wire recovered_121_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_121_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_121_q == 1'b0))) recovered_121_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_121_q == (bram_rddata_a[29])))) recovered_121_q <= (bram_rddata_a[29]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_2_44482a9
  reg recovered_122_q = 1'b0;
  assign rd_skid_buf[2] = recovered_122_q;
  wire recovered_122_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_122_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_122_q == 1'b0))) recovered_122_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_122_q == (bram_rddata_a[2])))) recovered_122_q <= (bram_rddata_a[2]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_30_374dca5
  reg recovered_123_q = 1'b0;
  assign rd_skid_buf[30] = recovered_123_q;
  wire recovered_123_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_123_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_123_q == 1'b0))) recovered_123_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_123_q == (bram_rddata_a[30])))) recovered_123_q <= (bram_rddata_a[30]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_31_d7384f1
  reg recovered_124_q = 1'b0;
  assign rd_skid_buf[31] = recovered_124_q;
  wire recovered_124_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_124_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_124_q == 1'b0))) recovered_124_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_124_q == (bram_rddata_a[31])))) recovered_124_q <= (bram_rddata_a[31]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_3_75d2398
  reg recovered_125_q = 1'b0;
  assign rd_skid_buf[3] = recovered_125_q;
  wire recovered_125_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_125_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_125_q == 1'b0))) recovered_125_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_125_q == (bram_rddata_a[3])))) recovered_125_q <= (bram_rddata_a[3]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_4_1cacc57
  reg recovered_126_q = 1'b0;
  assign rd_skid_buf[4] = recovered_126_q;
  wire recovered_126_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_126_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_126_q == 1'b0))) recovered_126_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_126_q == (bram_rddata_a[4])))) recovered_126_q <= (bram_rddata_a[4]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_5_6d63f00
  reg recovered_127_q = 1'b0;
  assign rd_skid_buf[5] = recovered_127_q;
  wire recovered_127_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_127_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_127_q == 1'b0))) recovered_127_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_127_q == (bram_rddata_a[5])))) recovered_127_q <= (bram_rddata_a[5]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_6_f26dc4e
  reg recovered_128_q = 1'b0;
  assign rd_skid_buf[6] = recovered_128_q;
  wire recovered_128_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_128_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_128_q == 1'b0))) recovered_128_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_128_q == (bram_rddata_a[6])))) recovered_128_q <= (bram_rddata_a[6]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_7_f811c9a
  reg recovered_129_q = 1'b0;
  assign rd_skid_buf[7] = recovered_129_q;
  wire recovered_129_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_129_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_129_q == 1'b0))) recovered_129_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_129_q == (bram_rddata_a[7])))) recovered_129_q <= (bram_rddata_a[7]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_8_c0dab92
  reg recovered_130_q = 1'b0;
  assign rd_skid_buf[8] = recovered_130_q;
  wire recovered_130_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_130_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_130_q == 1'b0))) recovered_130_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_130_q == (bram_rddata_a[8])))) recovered_130_q <= (bram_rddata_a[8]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_rd_skid_buf_reg_9_3c2cdda
  reg recovered_131_q = 1'b0;
  assign rd_skid_buf[9] = recovered_131_q;
  wire recovered_131_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_131_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_131_q == 1'b0))) recovered_131_q <= 1'b0;
    else if ((rd_skid_buf_ld) || ((rd_skid_buf_ld) === 1'bz) || (((rd_skid_buf_ld) === 1'bx) && (recovered_131_q == (bram_rddata_a[9])))) recovered_131_q <= (bram_rddata_a[9]);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_i_1_42c79d3
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_i_1_n_0_1481d78 = ((Arb2AR_Active) ? (((ar_active_d1) ? (((brst_zero) ? (1'b0) : (((s_axi_aresetn) ? (axi_rd_burst) : (1'b0))))) : (((s_axi_aresetn) ? (axi_rd_burst0) : (1'b0))))) : (((brst_zero) ? (1'b0) : (((s_axi_aresetn) ? (axi_rd_burst) : (1'b0))))));

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_i_2_b9be7b2
  assign axi_rd_burst0 = ((s_axi_arlen[1]) ? (1'b1) : (((s_axi_arlen[2]) ? (1'b1) : (s_axi_arlen[3]))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_reg_7dc8ad0
  reg recovered_134_q = 1'b0;
  assign axi_rd_burst = recovered_134_q;
  wire recovered_134_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_134_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_134_q == 1'b0))) recovered_134_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_134_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_i_1_n_0_1481d78)))) recovered_134_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_i_1_n_0_1481d78);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_i_1_e049b6a
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_i_1_n_0_b1b8c5c = ((Arb2AR_Active) ? (((ar_active_d1) ? (((brst_zero) ? (1'b0) : (((s_axi_aresetn) ? (esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) : (1'b0))))) : (((s_axi_aresetn) ? (axi_rd_burst_two) : (1'b0))))) : (((brst_zero) ? (1'b0) : (((s_axi_aresetn) ? (esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_i_2_d7d60f2
  assign axi_rd_burst_two = ((s_axi_arlen[3]) ? (1'b0) : (((s_axi_arlen[2]) ? (1'b0) : (((s_axi_arlen[1]) ? (1'b0) : (s_axi_arlen[0]))))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_ade80d4
  reg recovered_137_q = 1'b0;
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356 = recovered_137_q;
  wire recovered_137_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_137_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_137_q == 1'b0))) recovered_137_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_137_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_i_1_n_0_b1b8c5c)))) recovered_137_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_i_1_n_0_b1b8c5c);
  end

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_0__i_1_39102de
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_0__i_1_n_0_ad2691b = ((axi_rid_temp[0]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[0]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[0]) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_10__i_1_320851f
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_10__i_1_n_0_d1df9c2 = ((axi_rid_temp[10]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[10]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[10]) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_11__i_1_029edce
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_11__i_1_n_0_ef48a26 = ((axi_rid_temp[11]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[11]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[11]) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_12__i_1_993050f
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_12__i_1_n_0_e0b0fcf = ((axi_rid_temp[12]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[12]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[12]) : (1'b0))))));

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_38bc219
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5 = ((s_axi_aresetn) ? (((s_axi_rready) ? (esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_0_3cf0d99) : (1'b0))) : (1'b1));

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_6ca9ca7
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06 = ((Arb2AR_Active) ? (((ar_active_d1) ? (axi_rvalid_set) : (1'b1))) : (axi_rvalid_set));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_1__i_1_9292d5b
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_1__i_1_n_0_b944abf = ((axi_rid_temp[1]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[1]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[1]) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_2__i_1_f417611
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_2__i_1_n_0_acf57a4 = ((axi_rid_temp[2]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[2]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[2]) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_3__i_1_0a68ac0
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_3__i_1_n_0_5254c78 = ((axi_rid_temp[3]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[3]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[3]) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_4__i_1_5558e57
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_4__i_1_n_0_7b97654 = ((axi_rid_temp[4]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[4]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[4]) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_5__i_1_d9dd665
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_5__i_1_n_0_e9f4baa = ((axi_rid_temp[5]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[5]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[5]) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_6__i_1_c35fe6b
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_6__i_1_n_0_d67c492 = ((axi_rid_temp[6]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[6]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[6]) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_7__i_1_b930027
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_7__i_1_n_0_be8b498 = ((axi_rid_temp[7]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[7]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[7]) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_8__i_1_51dbb63
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_8__i_1_n_0_35e4171 = ((axi_rid_temp[8]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[8]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[8]) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_9__i_1_8db9b32
  assign esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_9__i_1_n_0_416ffbd = ((axi_rid_temp[9]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arid[9]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arid[9]) : (1'b0))))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_0_0085d36
  reg recovered_153_q = 1'b0;
  assign s_axi_rid[0] = recovered_153_q;
  wire recovered_153_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_153_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_153_q == 1'b0))) recovered_153_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_153_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_0__i_1_n_0_ad2691b)))) recovered_153_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_0__i_1_n_0_ad2691b);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_10_f7ca8c9
  reg recovered_154_q = 1'b0;
  assign s_axi_rid[10] = recovered_154_q;
  wire recovered_154_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_154_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_154_q == 1'b0))) recovered_154_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_154_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_10__i_1_n_0_d1df9c2)))) recovered_154_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_10__i_1_n_0_d1df9c2);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_11_6fb09bc
  reg recovered_155_q = 1'b0;
  assign s_axi_rid[11] = recovered_155_q;
  wire recovered_155_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_155_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_155_q == 1'b0))) recovered_155_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_155_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_11__i_1_n_0_ef48a26)))) recovered_155_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_11__i_1_n_0_ef48a26);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_12_73b3b2a
  reg recovered_156_q = 1'b0;
  assign s_axi_rid[12] = recovered_156_q;
  wire recovered_156_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_156_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_156_q == 1'b0))) recovered_156_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_156_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_12__i_1_n_0_e0b0fcf)))) recovered_156_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_12__i_1_n_0_e0b0fcf);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_1_b0cda58
  reg recovered_157_q = 1'b0;
  assign s_axi_rid[1] = recovered_157_q;
  wire recovered_157_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_157_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_157_q == 1'b0))) recovered_157_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_157_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_1__i_1_n_0_b944abf)))) recovered_157_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_1__i_1_n_0_b944abf);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_2_f2c2118
  reg recovered_158_q = 1'b0;
  assign s_axi_rid[2] = recovered_158_q;
  wire recovered_158_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_158_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_158_q == 1'b0))) recovered_158_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_158_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_2__i_1_n_0_acf57a4)))) recovered_158_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_2__i_1_n_0_acf57a4);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_3_8121c87
  reg recovered_159_q = 1'b0;
  assign s_axi_rid[3] = recovered_159_q;
  wire recovered_159_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_159_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_159_q == 1'b0))) recovered_159_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_159_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_3__i_1_n_0_5254c78)))) recovered_159_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_3__i_1_n_0_5254c78);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_4_f1ba657
  reg recovered_160_q = 1'b0;
  assign s_axi_rid[4] = recovered_160_q;
  wire recovered_160_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_160_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_160_q == 1'b0))) recovered_160_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_160_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_4__i_1_n_0_7b97654)))) recovered_160_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_4__i_1_n_0_7b97654);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_5_f988b3b
  reg recovered_161_q = 1'b0;
  assign s_axi_rid[5] = recovered_161_q;
  wire recovered_161_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_161_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_161_q == 1'b0))) recovered_161_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_161_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_5__i_1_n_0_e9f4baa)))) recovered_161_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_5__i_1_n_0_e9f4baa);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_6_e270109
  reg recovered_162_q = 1'b0;
  assign s_axi_rid[6] = recovered_162_q;
  wire recovered_162_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_162_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_162_q == 1'b0))) recovered_162_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_162_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_6__i_1_n_0_d67c492)))) recovered_162_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_6__i_1_n_0_d67c492);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_7_c8e5229
  reg recovered_163_q = 1'b0;
  assign s_axi_rid[7] = recovered_163_q;
  wire recovered_163_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_163_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_163_q == 1'b0))) recovered_163_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_163_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_7__i_1_n_0_be8b498)))) recovered_163_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_7__i_1_n_0_be8b498);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_8_5961f01
  reg recovered_164_q = 1'b0;
  assign s_axi_rid[8] = recovered_164_q;
  wire recovered_164_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_164_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_164_q == 1'b0))) recovered_164_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_164_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_8__i_1_n_0_35e4171)))) recovered_164_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_8__i_1_n_0_35e4171);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_reg_9_394f30d
  reg recovered_165_q = 1'b0;
  assign s_axi_rid[9] = recovered_165_q;
  wire recovered_165_reset = ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5)) && ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_165_reset || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_1_n_0_ec16da5) === 1'bx) && (recovered_165_q == 1'b0))) recovered_165_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) || ((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_13__i_2_n_0_b0d3e06) === 1'bx) && (recovered_165_q == (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_9__i_1_n_0_416ffbd)))) recovered_165_q <= (esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_int_9__i_1_n_0_416ffbd);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_0_67ba649
  reg recovered_166_q = 1'b0;
  assign axi_rid_temp[0] = recovered_166_q;
  wire recovered_166_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_166_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_166_q == 1'b0))) recovered_166_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_166_q == (s_axi_arid[0])))) recovered_166_q <= (s_axi_arid[0]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_10_a610d85
  reg recovered_167_q = 1'b0;
  assign axi_rid_temp[10] = recovered_167_q;
  wire recovered_167_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_167_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_167_q == 1'b0))) recovered_167_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_167_q == (s_axi_arid[10])))) recovered_167_q <= (s_axi_arid[10]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_11_54e3ae2
  reg recovered_168_q = 1'b0;
  assign axi_rid_temp[11] = recovered_168_q;
  wire recovered_168_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_168_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_168_q == 1'b0))) recovered_168_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_168_q == (s_axi_arid[11])))) recovered_168_q <= (s_axi_arid[11]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_12_1163ecc
  reg recovered_169_q = 1'b0;
  assign axi_rid_temp[12] = recovered_169_q;
  wire recovered_169_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_169_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_169_q == 1'b0))) recovered_169_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_169_q == (s_axi_arid[12])))) recovered_169_q <= (s_axi_arid[12]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_1_78812fb
  reg recovered_170_q = 1'b0;
  assign axi_rid_temp[1] = recovered_170_q;
  wire recovered_170_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_170_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_170_q == 1'b0))) recovered_170_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_170_q == (s_axi_arid[1])))) recovered_170_q <= (s_axi_arid[1]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_2_4fd8151
  reg recovered_171_q = 1'b0;
  assign axi_rid_temp[2] = recovered_171_q;
  wire recovered_171_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_171_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_171_q == 1'b0))) recovered_171_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_171_q == (s_axi_arid[2])))) recovered_171_q <= (s_axi_arid[2]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_3_ff973b8
  reg recovered_172_q = 1'b0;
  assign axi_rid_temp[3] = recovered_172_q;
  wire recovered_172_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_172_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_172_q == 1'b0))) recovered_172_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_172_q == (s_axi_arid[3])))) recovered_172_q <= (s_axi_arid[3]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_4_5c4d084
  reg recovered_173_q = 1'b0;
  assign axi_rid_temp[4] = recovered_173_q;
  wire recovered_173_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_173_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_173_q == 1'b0))) recovered_173_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_173_q == (s_axi_arid[4])))) recovered_173_q <= (s_axi_arid[4]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_5_43cba72
  reg recovered_174_q = 1'b0;
  assign axi_rid_temp[5] = recovered_174_q;
  wire recovered_174_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_174_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_174_q == 1'b0))) recovered_174_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_174_q == (s_axi_arid[5])))) recovered_174_q <= (s_axi_arid[5]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_6_cca80eb
  reg recovered_175_q = 1'b0;
  assign axi_rid_temp[6] = recovered_175_q;
  wire recovered_175_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_175_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_175_q == 1'b0))) recovered_175_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_175_q == (s_axi_arid[6])))) recovered_175_q <= (s_axi_arid[6]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_7_aa7f061
  reg recovered_176_q = 1'b0;
  assign axi_rid_temp[7] = recovered_176_q;
  wire recovered_176_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_176_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_176_q == 1'b0))) recovered_176_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_176_q == (s_axi_arid[7])))) recovered_176_q <= (s_axi_arid[7]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_8_a7dda14
  reg recovered_177_q = 1'b0;
  assign axi_rid_temp[8] = recovered_177_q;
  wire recovered_177_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_177_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_177_q == 1'b0))) recovered_177_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_177_q == (s_axi_arid[8])))) recovered_177_q <= (s_axi_arid[8]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_GEN_RID_SNG_axi_rid_temp_reg_9_175579a
  reg recovered_178_q = 1'b0;
  assign axi_rid_temp[9] = recovered_178_q;
  wire recovered_178_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_178_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_178_q == 1'b0))) recovered_178_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_178_q == (s_axi_arid[9])))) recovered_178_q <= (s_axi_arid[9]);
  end

  system_image_bram_ctrl_0_wrap_brst_0 esc_GEN_NO_RD_CMD_OPT_I_WRAP_BRST_3221013 
       (.esc_ADDR_SNG_PORT_bram_addr_int_16__i_8_0_f3c52ef (esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_10_3f275c0 (esc_ADDR_SNG_PORT_bram_addr_int_reg_10_3f275c0 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 (Q),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_11__0_4716190 (esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_11__1_abec655 (esc_ADDR_SNG_PORT_bram_addr_int_reg_11__0_4716190 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 (esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b (esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_16__1_a03d898 (ar_active_d1),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8 (esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_4_f52f690 (esc_ADDR_SNG_PORT_bram_addr_int_reg_4_f52f690 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_5_38af973 (esc_ADDR_SNG_PORT_bram_addr_int_reg_5_38af973 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d (esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_7_6e268c9 (esc_ADDR_SNG_PORT_bram_addr_int_reg_7_6e268c9 ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d (esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d ),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_9_d2d8198 (esc_ADDR_SNG_PORT_bram_addr_int_reg_9_d2d8198 ),
        .Arb2AR_Active(Arb2AR_Active),
        .D(D),
        .E(E),
        .esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c (esc_GEN_NO_RD_CMD_OPT_I_WRAP_BRST_n_17_bb20d7a ),
        .esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 (esc_GEN_NO_RD_CMD_OPT_I_WRAP_BRST_n_18_a16cbe7 ),
        .esc_GEN_NO_RD_CMD_OPT_bram_en_int_reg_f4d1ea4 (esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5 ),
        .Q(rd_data_sm_cs),
        .SR(s_axi_aresetn_0),
        .ar_active_re(ar_active_re),
        .ar_active_reg(sng_bram_addr_ld_en),
        .axi_rd_burst(axi_rd_burst),
        .brst_zero(brst_zero),
        .curr_fixed_burst_reg(curr_fixed_burst_reg),
        .curr_fixed_burst_reg_0(curr_fixed_burst_reg_0),
        .curr_wrap_burst_reg(curr_wrap_burst_reg),
        .end_brst_rd(end_brst_rd),
        .s_axi_aclk(s_axi_aclk),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_aresetn(s_axi_aresetn),
        .s_axi_arlen(s_axi_arlen[3:0]),
        .s_axi_rready(s_axi_rready));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_act_rd_burst_i_1_7bf61ef
  assign esc_GEN_NO_RD_CMD_OPT_act_rd_burst_i_1_n_0_960cf06 = ((esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_4_n_0_c02b5a0) ? (1'b0) : (((axi_rd_burst_two) ? (((ar_active_re) ? (((act_rd_burst_set) ? (1'b0) : (act_rd_burst))) : (((axi_rd_burst) ? (((act_rd_burst_set) ? (1'b1) : (act_rd_burst))) : (((act_rd_burst_set) ? (1'b0) : (act_rd_burst))))))) : (((ar_active_re) ? (((act_rd_burst_set) ? (1'b1) : (act_rd_burst))) : (((axi_rd_burst) ? (((act_rd_burst_set) ? (1'b1) : (act_rd_burst))) : (((act_rd_burst_set) ? (1'b0) : (act_rd_burst))))))))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_act_rd_burst_reg_66b54dd
  reg recovered_181_q = 1'b0;
  assign act_rd_burst = recovered_181_q;
  wire recovered_181_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_181_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_181_q == 1'b0))) recovered_181_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_181_q == (esc_GEN_NO_RD_CMD_OPT_act_rd_burst_i_1_n_0_960cf06)))) recovered_181_q <= (esc_GEN_NO_RD_CMD_OPT_act_rd_burst_i_1_n_0_960cf06);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_1_22a8c44
  assign esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_1_n_0_47fbcad = ((esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_4_n_0_c02b5a0) ? (1'b0) : (((esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_3_n_0_1715bf3) ? (((ar_active_re) ? (((act_rd_burst_set) ? (1'b1) : (act_rd_burst_two))) : (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (((act_rd_burst_set) ? (1'b1) : (act_rd_burst_two))) : (((act_rd_burst_set) ? (1'b0) : (act_rd_burst_two))))))) : (((ar_active_re) ? (((act_rd_burst_set) ? (1'b0) : (act_rd_burst_two))) : (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (((act_rd_burst_set) ? (1'b1) : (act_rd_burst_two))) : (((act_rd_burst_set) ? (1'b0) : (act_rd_burst_two))))))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_2_751a91d
  assign act_rd_burst_set = ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_3_n_0_0302857) ? (((rd_data_sm_cs[0]) ? (1'b0) : (((esc_GEN_NO_RD_CMD_OPT_brst_zero_i_2_n_0_1adf7a4) ? (1'b0) : (((ar_active_re) ? (((esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_5_n_0_aff0cda) ? (~(rd_data_sm_cs[3])) : (1'b0))) : (1'b0))))))) : (((rd_data_sm_cs[0]) ? (((esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_5_n_0_aff0cda) ? (~(rd_data_sm_cs[3])) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_brst_zero_i_2_n_0_1adf7a4) ? (1'b0) : (((ar_active_re) ? (((esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_5_n_0_aff0cda) ? (~(rd_data_sm_cs[3])) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_3_5ef6805
  assign esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_3_n_0_1715bf3 = ((s_axi_arlen[0]) ? (((s_axi_arlen[1]) ? (1'b0) : (((s_axi_arlen[3]) ? (1'b0) : (~(s_axi_arlen[2])))))) : (1'b0));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_4_07534dd
  assign esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_4_n_0_c02b5a0 = ((s_axi_aresetn) ? (((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_6_n_0_df59b12) ? (1'b0) : (((rd_data_sm_cs[3]) ? (1'b0) : (rd_data_sm_cs[2]))))) : (1'b0))) : (((rd_data_sm_cs[1]) ? (1'b0) : (((esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_6_n_0_df59b12) ? (1'b0) : (((rd_data_sm_cs[3]) ? (~(rd_data_sm_cs[2])) : (1'b0))))))))) : (1'b1));

  // Reconstructed LUT2: esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_5_dc60de2
  assign esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_5_n_0_aff0cda = ((rd_data_sm_cs[2]) ? (1'b0) : (~(rd_data_sm_cs[1])));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_6_a607345
  assign esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_6_n_0_df59b12 = ((s_axi_rready) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (((act_rd_burst_two) ? (1'b0) : (~(act_rd_burst)))) : (1'b1))) : (1'b1));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_reg_e3909d7
  reg recovered_188_q = 1'b0;
  assign act_rd_burst_two = recovered_188_q;
  wire recovered_188_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_188_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_188_q == 1'b0))) recovered_188_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_188_q == (esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_1_n_0_47fbcad)))) recovered_188_q <= (esc_GEN_NO_RD_CMD_OPT_act_rd_burst_two_i_1_n_0_47fbcad);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_1_24c0f0a
  assign esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_1_n_0_fc66297 = ((s_axi_aresetn) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_0_3cf0d99) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_3_n_0_a8407fb) ? (1'b1) : (~(s_axi_rready)))) : (((esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_3_n_0_a8407fb) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_2_n_0_e1c9416) ? (rlast_sm_cs[2]) : (1'b0))))))) : (1'b0));

  // Reconstructed LUT2: esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_2_ef2cf95
  assign esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_2_n_0_e1c9416 = ((rlast_sm_cs[1]) ? (1'b0) : (~(rlast_sm_cs[0])));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_3_aa7d57e
  assign esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_3_n_0_a8407fb = ((s_axi_rready) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (((rlast_sm_cs[0]) ? (~(rlast_sm_cs[2])) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_04f15cd
  reg recovered_192_q = 1'b0;
  assign esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_0_3cf0d99 = recovered_192_q;
  wire recovered_192_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_192_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_192_q == 1'b0))) recovered_192_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_192_q == (esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_1_n_0_fc66297)))) recovered_192_q <= (esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_i_1_n_0_fc66297);
  end

  // Reconstructed LUT5: esc_GEN_NO_RD_CMD_OPT_axi_rvalid_clr_ok_i_1_1d11258
  assign esc_GEN_NO_RD_CMD_OPT_axi_rvalid_clr_ok_i_1_n_0_5022dbe = ((axi_rvalid_clr_ok) ? (1'b1) : (((last_bram_addr) ? (((disable_b2b_brst) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_n_0_a9b7297) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_axi_rvalid_clr_ok_i_2_n_0_0445914))))) : (esc_GEN_NO_RD_CMD_OPT_axi_rvalid_clr_ok_i_2_n_0_0445914))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_axi_rvalid_clr_ok_i_2_e57cd54
  assign esc_GEN_NO_RD_CMD_OPT_axi_rvalid_clr_ok_i_2_n_0_0445914 = ((rd_data_sm_cs[3]) ? (((Arb2AR_Active) ? (~(ar_active_d1)) : (1'b0))) : (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[1]) ? (((Arb2AR_Active) ? (~(ar_active_d1)) : (1'b0))) : (((rd_data_sm_cs[0]) ? (1'b1) : (((Arb2AR_Active) ? (~(ar_active_d1)) : (1'b0))))))) : (((Arb2AR_Active) ? (~(ar_active_d1)) : (1'b0))))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_axi_rvalid_clr_ok_reg_24a399e
  reg recovered_195_q = 1'b0;
  assign axi_rvalid_clr_ok = recovered_195_q;
  wire recovered_195_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_195_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_195_q == 1'b0))) recovered_195_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_195_q == (esc_GEN_NO_RD_CMD_OPT_axi_rvalid_clr_ok_i_1_n_0_5022dbe)))) recovered_195_q <= (esc_GEN_NO_RD_CMD_OPT_axi_rvalid_clr_ok_i_1_n_0_5022dbe);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_i_1_23bfb6d
  assign esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_i_1_n_0_a4fc85a = ((s_axi_aresetn) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (((axi_rvalid_clr_ok) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_0_3cf0d99) ? (~(s_axi_rready)) : (1'b1))) : (1'b1))) : (((axi_rvalid_set) ? (((axi_rvalid_clr_ok) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_0_3cf0d99) ? (~(s_axi_rready)) : (1'b1))) : (1'b1))) : (1'b0))))) : (1'b0));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159
  reg recovered_197_q = 1'b0;
  assign esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5 = recovered_197_q;
  wire recovered_197_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_197_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_197_q == 1'b0))) recovered_197_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_197_q == (esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_i_1_n_0_a4fc85a)))) recovered_197_q <= (esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_i_1_n_0_a4fc85a);
  end

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_axi_rvalid_set_i_1_fc80957
  assign axi_rvalid_set_cmb = ((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[1]) ? (1'b0) : (((rd_data_sm_cs[3]) ? (1'b0) : (~(rd_data_sm_cs[2])))))) : (1'b0));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_axi_rvalid_set_reg_256b815
  reg recovered_199_q = 1'b0;
  assign axi_rvalid_set = recovered_199_q;
  wire recovered_199_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_199_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_199_q == 1'b0))) recovered_199_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_199_q == (axi_rvalid_set_cmb)))) recovered_199_q <= (axi_rvalid_set_cmb);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_1_76549c8
  assign esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_1_n_0_1455849 = ((BRAM_En_B_i) ? (((esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_5_n_0_4614b2d) ? (1'b1) : (((rd_data_sm_cs[3]) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_bram_en_int_reg_i_4_n_0_306144d) ? (((esc_GEN_NO_RD_CMD_OPT_I_WRAP_BRST_n_18_a16cbe7) ? (1'b0) : (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_2_n_0_b0bf0d4))) : (1'b1))))))) : (((esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_5_n_0_4614b2d) ? (1'b0) : (((rd_data_sm_cs[3]) ? (1'b0) : (((esc_GEN_NO_RD_CMD_OPT_bram_en_int_reg_i_4_n_0_306144d) ? (((esc_GEN_NO_RD_CMD_OPT_I_WRAP_BRST_n_18_a16cbe7) ? (1'b0) : (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_2_n_0_b0bf0d4))) : (1'b1))))))));

  // Reconstructed LUT5: esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_38ab5b3
  assign esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_n_0_a10bed0 = ((pend_rd_op) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (((s_axi_rready) ? (1'b0) : (((Arb2AR_Active) ? (ar_active_d1) : (1'b1))))) : (((Arb2AR_Active) ? (ar_active_d1) : (1'b1))))) : (((Arb2AR_Active) ? (ar_active_d1) : (1'b1))));

  // Reconstructed LUT2: esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_2_99f7e5f
  assign esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_2_n_0_b0bf0d4 = ((rd_data_sm_cs[0]) ? (1'b0) : (rd_data_sm_cs[2]));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_5_967cfe3
  assign esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_5_n_0_4614b2d = ((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_9_n_0_216be6b) ? (1'b0) : (((rd_data_sm_cs[2]) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_8_n_0_e739311))))) : (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_4_n_0_425e44b) ? (1'b0) : (((esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_9_n_0_216be6b) ? (1'b0) : (((rd_data_sm_cs[2]) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_8_n_0_e739311))))))))) : (((esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_9_n_0_216be6b) ? (1'b0) : (((rd_data_sm_cs[2]) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_8_n_0_e739311))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_6_01071fc
  assign esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_6_n_0_fdc76b2 = ((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[0]) ? (((Arb2AR_Active) ? (ar_active_d1) : (1'b1))) : (1'b1))) : (((rd_data_sm_cs[0]) ? (1'b0) : (((Arb2AR_Active) ? (ar_active_d1) : (1'b1))))))) : (((axi_rd_burst) ? (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[0]) ? (((Arb2AR_Active) ? (ar_active_d1) : (1'b1))) : (1'b1))) : (((rd_data_sm_cs[0]) ? (1'b0) : (((Arb2AR_Active) ? (ar_active_d1) : (1'b1))))))) : (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[0]) ? (((Arb2AR_Active) ? (ar_active_d1) : (1'b1))) : (1'b1))) : (((rd_data_sm_cs[0]) ? (1'b1) : (((Arb2AR_Active) ? (ar_active_d1) : (1'b1))))))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_7_1848c30
  assign esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_7_n_0_5171dc6 = ((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (((rd_data_sm_cs[0]) ? (((brst_zero) ? (((rd_data_sm_cs[2]) ? (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_n_0_a10bed0) : (1'b1))) : (((end_brst_rd) ? (((rd_data_sm_cs[2]) ? (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_n_0_a10bed0) : (1'b1))) : (((rd_data_sm_cs[2]) ? (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_n_0_a10bed0) : (1'b0))))))) : (((rd_data_sm_cs[2]) ? (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_n_0_a10bed0) : (1'b1))))) : (((rd_data_sm_cs[0]) ? (((brst_zero) ? (((rd_data_sm_cs[2]) ? (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_n_0_a10bed0) : (1'b1))) : (((end_brst_rd) ? (((rd_data_sm_cs[2]) ? (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_n_0_a10bed0) : (1'b1))) : (((rd_data_sm_cs[2]) ? (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_n_0_a10bed0) : (1'b0))))))) : (((rd_data_sm_cs[2]) ? (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_n_0_a10bed0) : (1'b0))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_8_2e14b00
  assign esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_8_n_0_e739311 = ((ar_active_re) ? (((rd_data_sm_cs[0]) ? (((brst_one) ? (((rd_data_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (~(esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_5_n_0_b79abcb)) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))) : (((rd_data_sm_cs[0]) ? (((brst_one) ? (((rd_data_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (~(esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_5_n_0_b79abcb)) : (1'b0))) : (1'b0))) : (1'b0))) : (~(rd_data_sm_cs[1])))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_9_b46d70d
  assign esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_9_n_0_216be6b = ((rd_data_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_10_n_0_a10bed0) ? (1'b0) : (((rd_data_sm_cs[2]) ? (rd_data_sm_cs[0]) : (1'b0))))) : (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_5_n_0_b79abcb) ? (((rd_data_sm_cs[2]) ? (~(rd_data_sm_cs[0])) : (1'b0))) : (1'b0))) : (((rd_data_sm_cs[2]) ? (~(rd_data_sm_cs[0])) : (1'b0))))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_bram_en_int_reg_f4d1ea4
  reg recovered_208_q = 1'b0;
  assign BRAM_En_B_i = recovered_208_q;
  wire recovered_208_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_208_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_208_q == 1'b0))) recovered_208_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_208_q == (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_1_n_0_1455849)))) recovered_208_q <= (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_1_n_0_1455849);
  end

  // Reconstructed MUXF7: esc_GEN_NO_RD_CMD_OPT_bram_en_int_reg_i_4_fc6eacb
  assign esc_GEN_NO_RD_CMD_OPT_bram_en_int_reg_i_4_n_0_306144d = (rd_data_sm_cs[1]) ? (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_7_n_0_5171dc6) : (esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_6_n_0_fdc76b2);

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_brst_cnt_0__i_1_e970214
  assign p_0_in__0[0] = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [0]) ? (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arlen[0]) : (1'b0))))) : (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arlen[0]) : (1'b1))))));

  // Reconstructed LUT5: esc_GEN_NO_RD_CMD_OPT_brst_cnt_1__i_1_ee988d5
  assign p_0_in__0[1] = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [0]) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [1]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arlen[1]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arlen[1]) : (1'b0))))))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [1]) ? (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arlen[1]) : (1'b0))))) : (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arlen[1]) : (1'b1))))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_brst_cnt_2__i_1_8c68fcf
  assign p_0_in__0[2] = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [2]) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [0]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arlen[2]) : (1'b1))))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [1]) ? (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arlen[2]) : (1'b1))))) : (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arlen[2]) : (1'b0))))))))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [0]) ? (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arlen[2]) : (1'b0))))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [1]) ? (((ar_active_d1) ? (1'b0) : (((Arb2AR_Active) ? (s_axi_arlen[2]) : (1'b0))))) : (((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (s_axi_arlen[2]) : (1'b1))))))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_brst_cnt_3__i_1_8496c9a
  assign p_0_in__0[3] = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [3]) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [1]) ? (((ar_active_re) ? (s_axi_arlen[3]) : (1'b1))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [0]) ? (((ar_active_re) ? (s_axi_arlen[3]) : (1'b1))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [2]) ? (((ar_active_re) ? (s_axi_arlen[3]) : (1'b1))) : (((ar_active_re) ? (s_axi_arlen[3]) : (1'b0))))))))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [1]) ? (((ar_active_re) ? (s_axi_arlen[3]) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [0]) ? (((ar_active_re) ? (s_axi_arlen[3]) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [2]) ? (((ar_active_re) ? (s_axi_arlen[3]) : (1'b0))) : (((ar_active_re) ? (s_axi_arlen[3]) : (1'b1))))))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_brst_cnt_4__i_1_65d6cdc
  assign p_0_in__0[4] = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [4]) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_6__i_2_n_0_326a996) ? (((ar_active_d1) ? (1'b1) : (~(Arb2AR_Active)))) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_6__i_2_n_0_326a996) ? (1'b0) : (((ar_active_d1) ? (1'b1) : (~(Arb2AR_Active)))))));

  // Reconstructed LUT5: esc_GEN_NO_RD_CMD_OPT_brst_cnt_5__i_1_2bdae3e
  assign p_0_in__0[5] = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [4]) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [5]) ? (((ar_active_d1) ? (1'b1) : (~(Arb2AR_Active)))) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_6__i_2_n_0_326a996) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [5]) ? (((ar_active_d1) ? (1'b1) : (~(Arb2AR_Active)))) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [5]) ? (1'b0) : (((ar_active_d1) ? (1'b1) : (~(Arb2AR_Active)))))))));

  // Reconstructed LUT5: esc_GEN_NO_RD_CMD_OPT_brst_cnt_6__i_1_fca81f8
  assign p_0_in__0[6] = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [5]) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [6]) ? (~(ar_active_re)) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [4]) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [6]) ? (~(ar_active_re)) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_6__i_2_n_0_326a996) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [6]) ? (~(ar_active_re)) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [6]) ? (1'b0) : (~(ar_active_re)))))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_brst_cnt_6__i_2_daa0fc0
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_6__i_2_n_0_326a996 = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [2]) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [0]) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [1]) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [3]))))));

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_987440f
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989 = ((esc_GEN_NO_RD_CMD_OPT_I_WRAP_BRST_n_17_bb20d7a) ? (1'b1) : (((Arb2AR_Active) ? (~(ar_active_d1)) : (1'b0))));

  // Reconstructed LUT5: esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_2_cc0d7c6
  assign p_0_in__0[7] = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_4_n_0_f716194) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [7]) ? (((ar_active_d1) ? (1'b1) : (~(Arb2AR_Active)))) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_3_n_0_74a3160) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [7]) ? (((ar_active_d1) ? (1'b1) : (~(Arb2AR_Active)))) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [7]) ? (1'b0) : (((ar_active_d1) ? (1'b1) : (~(Arb2AR_Active)))))))));

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_3_c57252e
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_3_n_0_74a3160 = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [1]) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [0]) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [2]))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_4_5d61b2f
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_4_n_0_f716194 = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [4]) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [5]) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [3]) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [6]))))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_brst_cnt_max_d1_reg_0b23e9a
  reg recovered_222_q = 1'b0;
  assign brst_cnt_max_d1 = recovered_222_q;
  wire recovered_222_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_222_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_222_q == 1'b0))) recovered_222_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_222_q == (brst_cnt_max)))) recovered_222_q <= (brst_cnt_max);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_0_bfe24d9
  reg recovered_223_q = 1'b0;
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [0] = recovered_223_q;
  wire recovered_223_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_223_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_223_q == 1'b0))) recovered_223_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) || ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bx) && (recovered_223_q == (p_0_in__0[0])))) recovered_223_q <= (p_0_in__0[0]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_1_c9d62dc
  reg recovered_224_q = 1'b0;
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [1] = recovered_224_q;
  wire recovered_224_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_224_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_224_q == 1'b0))) recovered_224_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) || ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bx) && (recovered_224_q == (p_0_in__0[1])))) recovered_224_q <= (p_0_in__0[1]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_2_bfc9efe
  reg recovered_225_q = 1'b0;
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [2] = recovered_225_q;
  wire recovered_225_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_225_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_225_q == 1'b0))) recovered_225_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) || ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bx) && (recovered_225_q == (p_0_in__0[2])))) recovered_225_q <= (p_0_in__0[2]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_3_e0875da
  reg recovered_226_q = 1'b0;
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [3] = recovered_226_q;
  wire recovered_226_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_226_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_226_q == 1'b0))) recovered_226_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) || ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bx) && (recovered_226_q == (p_0_in__0[3])))) recovered_226_q <= (p_0_in__0[3]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_4_1de0fcd
  reg recovered_227_q = 1'b0;
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [4] = recovered_227_q;
  wire recovered_227_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_227_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_227_q == 1'b0))) recovered_227_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) || ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bx) && (recovered_227_q == (p_0_in__0[4])))) recovered_227_q <= (p_0_in__0[4]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_5_2654ebe
  reg recovered_228_q = 1'b0;
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [5] = recovered_228_q;
  wire recovered_228_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_228_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_228_q == 1'b0))) recovered_228_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) || ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bx) && (recovered_228_q == (p_0_in__0[5])))) recovered_228_q <= (p_0_in__0[5]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_6_44f624d
  reg recovered_229_q = 1'b0;
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [6] = recovered_229_q;
  wire recovered_229_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_229_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_229_q == 1'b0))) recovered_229_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) || ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bx) && (recovered_229_q == (p_0_in__0[6])))) recovered_229_q <= (p_0_in__0[6]);
  end

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_7_09d2b0f
  reg recovered_230_q = 1'b0;
  assign esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [7] = recovered_230_q;
  wire recovered_230_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_230_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_230_q == 1'b0))) recovered_230_q <= 1'b0;
    else if ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) || ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bz) || (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_1_n_0_3291989) === 1'bx) && (recovered_230_q == (p_0_in__0[7])))) recovered_230_q <= (p_0_in__0[7]);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_brst_one_i_1_421a59b
  assign esc_GEN_NO_RD_CMD_OPT_brst_one_i_1_n_0_3f345ef = ((esc_GEN_NO_RD_CMD_OPT_brst_one_i_2_n_0_6f3810c) ? (((axi_rd_burst_two) ? (((s_axi_aresetn) ? (~(esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_n_0_5a64921)) : (1'b0))) : (((ar_active_re) ? (1'b0) : (((s_axi_aresetn) ? (~(esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_n_0_5a64921)) : (1'b0))))))) : (((axi_rd_burst_two) ? (((ar_active_re) ? (((s_axi_aresetn) ? (~(esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_n_0_5a64921)) : (1'b0))) : (((brst_one) ? (((s_axi_aresetn) ? (~(esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_n_0_5a64921)) : (1'b0))) : (1'b0))))) : (((ar_active_re) ? (1'b0) : (((brst_one) ? (((s_axi_aresetn) ? (~(esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_n_0_5a64921)) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_brst_one_i_2_7ec35de
  assign esc_GEN_NO_RD_CMD_OPT_brst_one_i_2_n_0_6f3810c = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [0]) ? (1'b0) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [1]) ? (((esc_GEN_NO_RD_CMD_OPT_I_WRAP_BRST_n_17_bb20d7a) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_4_n_0_f716194) ? (1'b0) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [2]) ? (1'b0) : (~(esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [7])))))) : (1'b0))) : (1'b0))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_brst_one_reg_4ad6131
  reg recovered_233_q = 1'b0;
  assign brst_one = recovered_233_q;
  wire recovered_233_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_233_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_233_q == 1'b0))) recovered_233_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_233_q == (esc_GEN_NO_RD_CMD_OPT_brst_one_i_1_n_0_3f345ef)))) recovered_233_q <= (esc_GEN_NO_RD_CMD_OPT_brst_one_i_1_n_0_3f345ef);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_brst_zero_i_1_ca89d8f
  assign esc_GEN_NO_RD_CMD_OPT_brst_zero_i_1_n_0_726de18 = ((s_axi_aresetn) ? (((brst_zero) ? (((Arb2AR_Active) ? (((ar_active_d1) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_brst_zero_i_2_n_0_1adf7a4))) : (1'b1))) : (((esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_n_0_5a64921) ? (((Arb2AR_Active) ? (((ar_active_d1) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_brst_zero_i_2_n_0_1adf7a4))) : (1'b1))) : (1'b0))))) : (1'b0));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_brst_zero_i_2_7303e70
  assign esc_GEN_NO_RD_CMD_OPT_brst_zero_i_2_n_0_1adf7a4 = ((s_axi_arlen[3]) ? (1'b0) : (((s_axi_arlen[2]) ? (1'b0) : (((s_axi_arlen[1]) ? (1'b0) : (~(s_axi_arlen[0])))))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_brst_zero_reg_f59d4dc
  reg recovered_236_q = 1'b0;
  assign brst_zero = recovered_236_q;
  wire recovered_236_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_236_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_236_q == 1'b0))) recovered_236_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_236_q == (esc_GEN_NO_RD_CMD_OPT_brst_zero_i_1_n_0_726de18)))) recovered_236_q <= (esc_GEN_NO_RD_CMD_OPT_brst_zero_i_1_n_0_726de18);
  end

  // Reconstructed LUT2: esc_GEN_NO_RD_CMD_OPT_curr_fixed_burst_reg_i_1_d5800b5
  assign curr_fixed_burst = ((s_axi_arburst[1]) ? (1'b0) : (~(s_axi_arburst[0])));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_curr_fixed_burst_reg_reg_91e5ed4
  reg recovered_238_q = 1'b0;
  assign curr_fixed_burst_reg_0 = recovered_238_q;
  wire recovered_238_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_238_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_238_q == 1'b0))) recovered_238_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_238_q == (curr_fixed_burst)))) recovered_238_q <= (curr_fixed_burst);
  end

  // Reconstructed LUT2: esc_GEN_NO_RD_CMD_OPT_curr_wrap_burst_reg_i_1_a6f8691
  assign esc_GEN_NO_RD_CMD_OPT_curr_wrap_burst_reg_i_1_n_0_652f3c5 = ((s_axi_arburst[0]) ? (1'b0) : (s_axi_arburst[1]));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_curr_wrap_burst_reg_reg_b070fb7
  reg recovered_240_q = 1'b0;
  assign curr_wrap_burst_reg = recovered_240_q;
  wire recovered_240_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_240_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_240_q == 1'b0))) recovered_240_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_240_q == (esc_GEN_NO_RD_CMD_OPT_curr_wrap_burst_reg_i_1_n_0_652f3c5)))) recovered_240_q <= (esc_GEN_NO_RD_CMD_OPT_curr_wrap_burst_reg_i_1_n_0_652f3c5);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_1_eb6ef8d
  assign disable_b2b_brst_cmb = ((rd_data_sm_cs[1]) ? (((rd_data_sm_cs[0]) ? (esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_n_0_a9b7297) : (((disable_b2b_brst) ? (((rd_data_sm_cs[3]) ? (esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_n_0_a9b7297) : (1'b1))) : (esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_n_0_a9b7297))))) : (((rd_data_sm_cs[2]) ? (((disable_b2b_brst) ? (((rd_data_sm_cs[3]) ? (esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_n_0_a9b7297) : (1'b1))) : (esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_n_0_a9b7297))) : (((rd_data_sm_cs[0]) ? (esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_n_0_a9b7297) : (((disable_b2b_brst) ? (((rd_data_sm_cs[3]) ? (esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_n_0_a9b7297) : (1'b1))) : (esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_n_0_a9b7297))))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_a9b85bf
  assign esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_2_n_0_a9b7297 = ((esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_3_n_0_fd44a63) ? (1'b0) : (((brst_one) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (1'b1) : (((rd_data_sm_cs[1]) ? (disable_b2b_brst) : (1'b1))))) : (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_3__i_5_n_0_b79abcb) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (1'b1) : (((rd_data_sm_cs[1]) ? (disable_b2b_brst) : (1'b1))))) : (((rd_data_sm_cs[1]) ? (disable_b2b_brst) : (1'b1))))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_3_7516683
  assign esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_i_3_n_0_fd44a63 = ((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[2]) ? (1'b1) : (((rd_data_sm_cs[3]) ? (1'b1) : (((axi_rd_burst) ? (((rd_data_sm_cs[1]) ? (1'b0) : (~(esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356)))) : (1'b0))))))) : (1'b1));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_disable_b2b_brst_reg_09d9920
  reg recovered_244_q = 1'b0;
  assign disable_b2b_brst = recovered_244_q;
  wire recovered_244_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_244_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_244_q == 1'b0))) recovered_244_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_244_q == (disable_b2b_brst_cmb)))) recovered_244_q <= (disable_b2b_brst_cmb);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_end_brst_rd_clr_i_1_659d40c
  assign esc_GEN_NO_RD_CMD_OPT_end_brst_rd_clr_i_1_n_0_f643e1a = ((end_brst_rd_clr) ? (((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[2]) ? (1'b1) : (((rd_data_sm_cs[3]) ? (1'b1) : (rd_data_sm_cs[1]))))) : (((rd_data_sm_cs[2]) ? (1'b1) : (((rd_data_sm_cs[3]) ? (1'b1) : (((rd_data_sm_cs[1]) ? (1'b1) : (~(ar_active_re)))))))))) : (((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[3]) ? (1'b0) : (~(rd_data_sm_cs[1])))) : (1'b0))) : (1'b0))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_end_brst_rd_clr_reg_4af7586
  reg recovered_246_q = 1'b0;
  assign end_brst_rd_clr = recovered_246_q;
  wire recovered_246_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_246_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_246_q == 1'b0))) recovered_246_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_246_q == (esc_GEN_NO_RD_CMD_OPT_end_brst_rd_clr_i_1_n_0_f643e1a)))) recovered_246_q <= (esc_GEN_NO_RD_CMD_OPT_end_brst_rd_clr_i_1_n_0_f643e1a);
  end

  // Reconstructed LUT5: esc_GEN_NO_RD_CMD_OPT_end_brst_rd_i_1_4ee2fb0
  assign esc_GEN_NO_RD_CMD_OPT_end_brst_rd_i_1_n_0_24dfd54 = ((s_axi_aresetn) ? (((end_brst_rd) ? (~(end_brst_rd_clr)) : (((brst_cnt_max) ? (~(brst_cnt_max_d1)) : (1'b0))))) : (1'b0));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_end_brst_rd_reg_a76b3c6
  reg recovered_248_q = 1'b0;
  assign end_brst_rd = recovered_248_q;
  wire recovered_248_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_248_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_248_q == 1'b0))) recovered_248_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_248_q == (esc_GEN_NO_RD_CMD_OPT_end_brst_rd_i_1_n_0_24dfd54)))) recovered_248_q <= (esc_GEN_NO_RD_CMD_OPT_end_brst_rd_i_1_n_0_24dfd54);
  end

  // Reconstructed LUT5: esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_1_185d8db
  assign last_bram_addr0 = ((esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_6_n_0_51f0397) ? (((esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_5_n_0_a8376f4) ? (((esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_4_n_0_e0d5aa6) ? (((esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_3_n_0_2c1b1c9) ? (esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_n_0_5a64921) : (1'b1))) : (1'b1))) : (((esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_3_n_0_2c1b1c9) ? (esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_n_0_5a64921) : (1'b1))))) : (esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_n_0_5a64921));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_4733a20
  assign esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_2_n_0_5a64921 = ((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [1]) ? (1'b0) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [0]) ? (((esc_GEN_NO_RD_CMD_OPT_I_WRAP_BRST_n_17_bb20d7a) ? (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_7__i_4_n_0_f716194) ? (1'b0) : (((esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [2]) ? (1'b0) : (~(esc_GEN_NO_RD_CMD_OPT_brst_cnt_reg_fe8153d [7])))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_3_68f9b23
  assign esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_3_n_0_2c1b1c9 = ((ar_active_d1) ? (1'b1) : (((Arb2AR_Active) ? (((rd_data_sm_cs[2]) ? (1'b1) : (((rd_data_sm_cs[3]) ? (1'b1) : (~(esc_GEN_NO_RD_CMD_OPT_brst_zero_i_2_n_0_1adf7a4)))))) : (1'b1))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_4_b45daf9
  assign esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_4_n_0_e0d5aa6 = ((ar_active_d1) ? (((axi_rd_burst) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (1'b1) : (((s_axi_rready) ? (~(esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5)) : (1'b1))))))) : (((Arb2AR_Active) ? (((s_axi_rready) ? (~(esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5)) : (1'b1))) : (((axi_rd_burst) ? (1'b1) : (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (1'b1) : (((s_axi_rready) ? (~(esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5)) : (1'b1))))))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_5_bed9119
  assign esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_5_n_0_a8376f4 = ((esc_GEN_NO_RD_CMD_OPT_brst_zero_i_2_n_0_1adf7a4) ? (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[3]) ? (1'b0) : (((pend_rd_op) ? (1'b1) : (ar_active_re))))) : (((rd_data_sm_cs[3]) ? (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_3_n_0_0302857) : (1'b0))))) : (((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[3]) ? (1'b0) : (((pend_rd_op) ? (~(ar_active_re)) : (1'b0))))) : (((rd_data_sm_cs[3]) ? (esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_3_n_0_0302857) : (1'b0))))));

  // Reconstructed LUT3: esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_6_b2c316b
  assign esc_GEN_NO_RD_CMD_OPT_last_bram_addr_i_6_n_0_51f0397 = ((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[0]) ? (rd_data_sm_cs[1]) : (1'b0))) : (((rd_data_sm_cs[0]) ? (1'b0) : (~(rd_data_sm_cs[1])))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_last_bram_addr_reg_9b9069e
  reg recovered_255_q = 1'b0;
  assign last_bram_addr = recovered_255_q;
  wire recovered_255_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_255_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_255_q == 1'b0))) recovered_255_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_255_q == (last_bram_addr0)))) recovered_255_q <= (last_bram_addr0);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_1_21c30b7
  assign esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_1_n_0_14bd384 = ((esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_4_n_0_c9064de) ? (((ar_active_re) ? (~(esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_2_n_0_897ef2d)) : (1'b0))) : (((esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_3_n_0_7b48e3d) ? (pend_rd_op) : (((ar_active_re) ? (~(esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_2_n_0_897ef2d)) : (((pend_rd_op) ? (~(esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_0_3cf0d99)) : (1'b0))))))));

  // Reconstructed LUT5: esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_2_ddd5875
  assign esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_2_n_0_897ef2d = ((rd_data_sm_cs[1]) ? (1'b1) : (((rd_data_sm_cs[3]) ? (1'b1) : (((rd_data_sm_cs[2]) ? (1'b0) : (((axi_rd_burst) ? (1'b1) : (esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356))))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_3_974e918
  assign esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_3_n_0_7b48e3d = ((rd_data_sm_cs[2]) ? (((rd_data_sm_cs[0]) ? (1'b1) : (((rd_data_sm_cs[1]) ? (1'b1) : (rd_data_sm_cs[3]))))) : (1'b1));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_4_de50ea1
  assign esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_4_n_0_c9064de = ((rd_data_sm_cs[0]) ? (((esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_6_n_0_d0dc7d9) ? (1'b1) : (((rd_data_sm_cs[1]) ? (((end_brst_rd_clr_cmb) ? (((pend_rd_op) ? (~(esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09)) : (1'b0))) : (1'b0))) : (1'b0))))) : (1'b0));

  // Reconstructed LUT2: esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_5_8a55208
  assign end_brst_rd_clr_cmb = ((rd_data_sm_cs[3]) ? (1'b0) : (rd_data_sm_cs[2]));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_6_a3b79cc
  assign esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_6_n_0_d0dc7d9 = ((ar_active_re) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_1__i_3_n_0_0302857) ? (((rd_data_sm_cs[2]) ? (1'b0) : (((rd_data_sm_cs[1]) ? (1'b0) : (~(rd_data_sm_cs[3])))))) : (((pend_rd_op) ? (((rd_data_sm_cs[2]) ? (1'b0) : (((rd_data_sm_cs[1]) ? (1'b0) : (~(rd_data_sm_cs[3])))))) : (1'b0))))) : (((pend_rd_op) ? (((rd_data_sm_cs[2]) ? (1'b0) : (((rd_data_sm_cs[1]) ? (1'b0) : (~(rd_data_sm_cs[3])))))) : (1'b0))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_pend_rd_op_reg_0eaba01
  reg recovered_262_q = 1'b0;
  assign pend_rd_op = recovered_262_q;
  wire recovered_262_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_262_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_262_q == 1'b0))) recovered_262_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_262_q == (esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_1_n_0_14bd384)))) recovered_262_q <= (esc_GEN_NO_RD_CMD_OPT_pend_rd_op_i_1_n_0_14bd384);
  end

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_rd_skid_buf_ld_reg_i_1_cdc2e49
  assign rd_skid_buf_ld_cmb = ((rd_data_sm_cs[2]) ? (1'b0) : (((rd_data_sm_cs[3]) ? (1'b0) : (((rd_data_sm_cs[1]) ? (((rd_data_sm_cs[0]) ? (((s_axi_rready) ? (esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) : (1'b0))) : (1'b1))) : (rd_data_sm_cs[0]))))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_rd_skid_buf_ld_reg_reg_9544f02
  reg recovered_264_q = 1'b0;
  assign rd_skid_buf_ld_reg = recovered_264_q;
  wire recovered_264_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_264_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_264_q == 1'b0))) recovered_264_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_264_q == (rd_skid_buf_ld_cmb)))) recovered_264_q <= (rd_skid_buf_ld_cmb);
  end

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_1_2c93f85
  assign esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_1_n_0_7903c77 = ((rddata_mux_sel) ? (((esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_3_n_0_add223d) ? (1'b1) : (((rd_data_sm_cs[3]) ? (1'b1) : (~(esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_2_n_0_176cec6)))))) : (((esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_3_n_0_add223d) ? (1'b0) : (((rd_data_sm_cs[3]) ? (1'b0) : (~(esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_2_n_0_176cec6)))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_2_e817db8
  assign esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_2_n_0_176cec6 = ((esc_GEN_NO_RD_CMD_OPT_GEN_RDATA_NO_ECC_GEN_RDATA_NO_RL_NO_ECC_GEN_RDATA_31__axi_rdata_int_31___7819f09) ? (((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[2]) ? (1'b0) : (~(rd_data_sm_cs[1])))) : (1'b1))) : (((act_rd_burst_two) ? (((rd_data_sm_cs[0]) ? (1'b1) : (~(rd_data_sm_cs[2])))) : (((act_rd_burst) ? (((rd_data_sm_cs[0]) ? (1'b1) : (~(rd_data_sm_cs[2])))) : (~(rd_data_sm_cs[2])))))));

  // Reconstructed LUT6: esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_3_6e675fb
  assign esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_3_n_0_add223d = ((s_axi_rready) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_0_97a82a5) ? (((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[1]) ? (rd_data_sm_cs[2]) : (1'b0))) : (((rd_data_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (1'b0) : (~(rd_data_sm_cs[2])))) : (~(rd_data_sm_cs[2])))))) : (((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[1]) ? (rd_data_sm_cs[2]) : (1'b0))) : (((rd_data_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (rd_data_sm_cs[2]) : (1'b1))) : (1'b1))))))) : (((rd_data_sm_cs[0]) ? (((rd_data_sm_cs[1]) ? (rd_data_sm_cs[2]) : (1'b0))) : (((rd_data_sm_cs[1]) ? (((esc_GEN_NO_RD_CMD_OPT_GEN_RD_BURST_NORL_axi_rd_burst_two_reg_n_0_3dc4356) ? (rd_data_sm_cs[2]) : (1'b1))) : (1'b1))))));

  // Reconstructed FDRE: esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_reg_5259bfa
  reg recovered_268_q = 1'b0;
  assign rddata_mux_sel = recovered_268_q;
  wire recovered_268_reset = ((s_axi_aresetn_0)) && ((s_axi_aresetn_0) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_268_reset || (((s_axi_aresetn_0) === 1'bx) && (recovered_268_q == 1'b0))) recovered_268_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_268_q == (esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_1_n_0_7903c77)))) recovered_268_q <= (esc_GEN_NO_RD_CMD_OPT_rddata_mux_sel_i_1_n_0_7903c77);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT2: axi_awready_int_i_3
  assign s_axi_rready_0 = ((esc_GEN_NO_RD_CMD_OPT_axi_rlast_int_reg_0_3cf0d99) ? (s_axi_rready) : (1'b0));

endmodule

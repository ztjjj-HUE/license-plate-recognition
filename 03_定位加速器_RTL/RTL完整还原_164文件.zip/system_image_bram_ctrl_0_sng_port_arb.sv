// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_image_bram_ctrl_0_sng_port_arb
   (s_axi_awready,
    s_axi_arready,
    Arb2AW_Active,
    Arb2AR_Active,
    aw_active_re,
    ar_active_re,
    bram_we_a,
    ar_active_reg_0,
    ar_active_reg_1,
    s_axi_aclk,
    aw_active_d1,
    ar_active_d1,
    esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5 ,
    s_axi_awvalid,
    s_axi_arvalid,
    esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34 ,
    esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_3975a1b ,
    s_axi_rready,
    AW2Arb_Active_Clr,
    Q,
    s_axi_aresetn);
  output s_axi_awready;
  output s_axi_arready;
  output Arb2AW_Active;
  output Arb2AR_Active;
  output aw_active_re;
  output ar_active_re;
  output [3:0]bram_we_a;
  output ar_active_reg_0;
  input ar_active_reg_1;
  input s_axi_aclk;
  input aw_active_d1;
  input ar_active_d1;
  input esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5 ;
  input s_axi_awvalid;
  input s_axi_arvalid;
  input esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34 ;
  input esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_3975a1b ;
  input s_axi_rready;
  input AW2Arb_Active_Clr;
  input [3:0]Q;
  input s_axi_aresetn;

  wire esc_const1_c064970 ;
  wire AW2Arb_Active_Clr;
  wire Arb2AR_Active;
  wire Arb2AW_Active;
  wire esc_FSM_sequential_arb_sm_cs_0__i_1_n_0_9ae40b4 ;
  wire esc_FSM_sequential_arb_sm_cs_0__i_2_n_0_178210a ;
  wire esc_FSM_sequential_arb_sm_cs_1__i_1_n_0_fbb5671 ;
  wire esc_FSM_sequential_arb_sm_cs_1__i_2_n_0_a0d4e05 ;
  wire esc_FSM_sequential_arb_sm_cs_1__i_3_n_0_f684e18 ;
  wire esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5 ;
  wire esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34 ;
  wire esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_3975a1b ;
  wire [3:0]Q;
  wire ar_active_d1;
  wire ar_active_i_1_n_0;
  wire ar_active_re;
  wire ar_active_reg_0;
  wire ar_active_reg_1;
  wire [1:0]arb_sm_cs;
  wire [1:1]arb_sm_ns;
  wire aw_active_d1;
  wire aw_active_i_1_n_0;
  wire aw_active_re;
  wire axi_arready_cmb;
  wire axi_arready_int_i_2_n_0;
  wire axi_awready_cmb;
  wire [3:0]bram_we_a;
  wire last_arb_won;
  wire last_arb_won_i_1_n_0;
  wire last_arb_won_i_3_n_0;
  wire s_axi_aclk;
  wire s_axi_aresetn;
  wire s_axi_arready;
  wire s_axi_arvalid;
  wire s_axi_awready;
  wire s_axi_awvalid;
  wire s_axi_rready;

  // Reconstructed LUT6: esc_FSM_sequential_arb_sm_cs_0__i_1_16ce0d2
  assign esc_FSM_sequential_arb_sm_cs_0__i_1_n_0_9ae40b4 = ((esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5) ? (((AW2Arb_Active_Clr) ? (((esc_FSM_sequential_arb_sm_cs_0__i_2_n_0_178210a) ? (((arb_sm_cs[0]) ? (arb_sm_cs[1]) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))) : (((arb_sm_cs[0]) ? (arb_sm_cs[1]) : (((arb_sm_cs[1]) ? (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34) : (1'b0))))))) : (((esc_FSM_sequential_arb_sm_cs_0__i_2_n_0_178210a) ? (((arb_sm_cs[0]) ? (1'b1) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))) : (((arb_sm_cs[0]) ? (1'b1) : (((arb_sm_cs[1]) ? (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34) : (1'b0))))))))) : (((AW2Arb_Active_Clr) ? (((esc_FSM_sequential_arb_sm_cs_0__i_2_n_0_178210a) ? (((arb_sm_cs[0]) ? (arb_sm_cs[1]) : (((arb_sm_cs[1]) ? (1'b0) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))))) : (((arb_sm_cs[0]) ? (arb_sm_cs[1]) : (1'b0))))) : (((esc_FSM_sequential_arb_sm_cs_0__i_2_n_0_178210a) ? (((arb_sm_cs[0]) ? (1'b1) : (((arb_sm_cs[1]) ? (1'b0) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))))) : (arb_sm_cs[0]))))));

  // Reconstructed LUT3: esc_FSM_sequential_arb_sm_cs_0__i_2_7e4cd09
  assign esc_FSM_sequential_arb_sm_cs_0__i_2_n_0_178210a = ((s_axi_arvalid) ? (((last_arb_won) ? (s_axi_awvalid) : (1'b0))) : (1'b1));

  // Reconstructed LUT6: esc_FSM_sequential_arb_sm_cs_1__i_1_68a3d6a
  assign esc_FSM_sequential_arb_sm_cs_1__i_1_n_0_fbb5671 = ((arb_sm_cs[1]) ? (((esc_FSM_sequential_arb_sm_cs_1__i_2_n_0_a0d4e05) ? (((s_axi_arvalid) ? (((s_axi_awvalid) ? (1'b0) : (~(arb_sm_cs[0])))) : (1'b0))) : (1'b1))) : (((esc_FSM_sequential_arb_sm_cs_1__i_2_n_0_a0d4e05) ? (((s_axi_arvalid) ? (((s_axi_awvalid) ? (((arb_sm_cs[0]) ? (1'b1) : (~(last_arb_won)))) : (1'b1))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_FSM_sequential_arb_sm_cs_1__i_2_a3ce32e
  assign esc_FSM_sequential_arb_sm_cs_1__i_2_n_0_a0d4e05 = ((esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5) ? (((arb_sm_cs[0]) ? (((arb_sm_cs[1]) ? (esc_FSM_sequential_arb_sm_cs_1__i_3_n_0_f684e18) : (((AW2Arb_Active_Clr) ? (1'b1) : (esc_FSM_sequential_arb_sm_cs_1__i_3_n_0_f684e18))))) : (((arb_sm_cs[1]) ? (1'b1) : (((esc_FSM_sequential_arb_sm_cs_1__i_3_n_0_f684e18) ? (1'b1) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))))))) : (((arb_sm_cs[0]) ? (((arb_sm_cs[1]) ? (esc_FSM_sequential_arb_sm_cs_1__i_3_n_0_f684e18) : (((AW2Arb_Active_Clr) ? (1'b1) : (esc_FSM_sequential_arb_sm_cs_1__i_3_n_0_f684e18))))) : (((arb_sm_cs[1]) ? (esc_FSM_sequential_arb_sm_cs_1__i_3_n_0_f684e18) : (((esc_FSM_sequential_arb_sm_cs_1__i_3_n_0_f684e18) ? (1'b1) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))))))));

  // Reconstructed LUT5: esc_FSM_sequential_arb_sm_cs_1__i_3_51c9d9e
  assign esc_FSM_sequential_arb_sm_cs_1__i_3_n_0_f684e18 = ((s_axi_awvalid) ? (((last_arb_won) ? (1'b0) : (((s_axi_arvalid) ? (((arb_sm_cs[0]) ? (1'b0) : (~(arb_sm_cs[1])))) : (1'b0))))) : (((s_axi_arvalid) ? (((arb_sm_cs[0]) ? (1'b0) : (~(arb_sm_cs[1])))) : (1'b0))));

  // Reconstructed FDRE: esc_FSM_sequential_arb_sm_cs_reg_0_ba57830
  reg recovered_6_q = 1'b0;
  assign arb_sm_cs[0] = recovered_6_q;
  wire recovered_6_reset = ((ar_active_reg_1)) && ((ar_active_reg_1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_6_reset || (((ar_active_reg_1) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (esc_FSM_sequential_arb_sm_cs_0__i_1_n_0_9ae40b4)))) recovered_6_q <= (esc_FSM_sequential_arb_sm_cs_0__i_1_n_0_9ae40b4);
  end

  // Reconstructed FDRE: esc_FSM_sequential_arb_sm_cs_reg_1_81c327b
  reg recovered_7_q = 1'b0;
  assign arb_sm_cs[1] = recovered_7_q;
  wire recovered_7_reset = ((ar_active_reg_1)) && ((ar_active_reg_1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_7_reset || (((ar_active_reg_1) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (esc_FSM_sequential_arb_sm_cs_1__i_1_n_0_fbb5671)))) recovered_7_q <= (esc_FSM_sequential_arb_sm_cs_1__i_1_n_0_fbb5671);
  end

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_i_1_cf0a9f9
  assign ar_active_reg_0 = ((esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_3975a1b) ? (((s_axi_rready) ? (1'b0) : (((s_axi_aresetn) ? (Arb2AR_Active) : (1'b0))))) : (((s_axi_aresetn) ? (Arb2AR_Active) : (1'b0))));

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: ar_active_i_1
  assign ar_active_i_1_n_0 = ((Arb2AR_Active) ? (((axi_arready_int_i_2_n_0) ? (arb_sm_ns) : (((esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5) ? (((arb_sm_cs[0]) ? (1'b1) : (((arb_sm_cs[1]) ? (arb_sm_ns) : (1'b1))))) : (1'b1))))) : (((axi_arready_int_i_2_n_0) ? (arb_sm_ns) : (((esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5) ? (((arb_sm_cs[0]) ? (1'b0) : (((arb_sm_cs[1]) ? (arb_sm_ns) : (1'b0))))) : (1'b0))))));

  // Reconstructed FDRE: ar_active_reg
  reg recovered_11_q = 1'b0;
  assign Arb2AR_Active = recovered_11_q;
  wire recovered_11_reset = ((ar_active_reg_1)) && ((ar_active_reg_1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_11_reset || (((ar_active_reg_1) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_11_q == (ar_active_i_1_n_0)))) recovered_11_q <= (ar_active_i_1_n_0);
  end

  // Reconstructed LUT6: aw_active_i_1
  assign aw_active_i_1_n_0 = ((Arb2AW_Active) ? (((axi_awready_cmb) ? (((arb_sm_cs[0]) ? (1'b0) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))) : (((AW2Arb_Active_Clr) ? (((arb_sm_cs[0]) ? (arb_sm_cs[1]) : (1'b1))) : (1'b1))))) : (((axi_awready_cmb) ? (((arb_sm_cs[0]) ? (1'b0) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))) : (1'b0))));

  // Reconstructed FDRE: aw_active_reg
  reg recovered_13_q = 1'b0;
  assign Arb2AW_Active = recovered_13_q;
  wire recovered_13_reset = ((ar_active_reg_1)) && ((ar_active_reg_1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_13_reset || (((ar_active_reg_1) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_13_q == (aw_active_i_1_n_0)))) recovered_13_q <= (aw_active_i_1_n_0);
  end

  // Reconstructed LUT6: axi_arready_int_i_1
  assign axi_arready_cmb = ((axi_arready_int_i_2_n_0) ? (1'b1) : (((s_axi_arvalid) ? (((s_axi_awvalid) ? (1'b0) : (((arb_sm_cs[1]) ? (((arb_sm_cs[0]) ? (1'b0) : (esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5))) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: axi_arready_int_i_2
  assign axi_arready_int_i_2_n_0 = ((arb_sm_cs[1]) ? (1'b0) : (((arb_sm_cs[0]) ? (((s_axi_arvalid) ? (AW2Arb_Active_Clr) : (1'b0))) : (((s_axi_arvalid) ? (((last_arb_won) ? (~(s_axi_awvalid)) : (1'b1))) : (1'b0))))));

  // Reconstructed FDRE: axi_arready_int_reg
  reg recovered_16_q = 1'b0;
  assign s_axi_arready = recovered_16_q;
  wire recovered_16_reset = ((ar_active_reg_1)) && ((ar_active_reg_1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_16_reset || (((ar_active_reg_1) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_16_q == (axi_arready_cmb)))) recovered_16_q <= (axi_arready_cmb);
  end

  // Reconstructed LUT6: axi_awready_int_i_1
  assign axi_awready_cmb = ((last_arb_won) ? (((esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5) ? (((arb_sm_cs[0]) ? (1'b0) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))) : (((arb_sm_cs[0]) ? (1'b0) : (((arb_sm_cs[1]) ? (1'b0) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))))))) : (((s_axi_arvalid) ? (((esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5) ? (((arb_sm_cs[0]) ? (1'b0) : (((arb_sm_cs[1]) ? (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34) : (1'b0))))) : (1'b0))) : (((esc_FSM_sequential_arb_sm_cs_reg_0__0_a9ef9c5) ? (((arb_sm_cs[0]) ? (1'b0) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))) : (((arb_sm_cs[0]) ? (1'b0) : (((arb_sm_cs[1]) ? (1'b0) : (esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34))))))))));

  // Reconstructed FDRE: axi_awready_int_reg
  reg recovered_18_q = 1'b0;
  assign s_axi_awready = recovered_18_q;
  wire recovered_18_reset = ((ar_active_reg_1)) && ((ar_active_reg_1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_18_reset || (((ar_active_reg_1) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_18_q == (axi_awready_cmb)))) recovered_18_q <= (axi_awready_cmb);
  end

  // Reconstructed LUT2: esc_bram_we_a_0__INST_0_818eb64
  assign bram_we_a[0] = ((Q[0]) ? (Arb2AW_Active) : (1'b0));

  // Reconstructed LUT2: esc_bram_we_a_1__INST_0_6204ff1
  assign bram_we_a[1] = ((Q[1]) ? (Arb2AW_Active) : (1'b0));

  // Reconstructed LUT2: esc_bram_we_a_2__INST_0_9b23ead
  assign bram_we_a[2] = ((Q[2]) ? (Arb2AW_Active) : (1'b0));

  // Reconstructed LUT2: esc_bram_we_a_3__INST_0_f5a0256
  assign bram_we_a[3] = ((Q[3]) ? (Arb2AW_Active) : (1'b0));

  // Reconstructed LUT4: last_arb_won_i_1
  assign last_arb_won_i_1_n_0 = ((last_arb_won) ? (((last_arb_won_i_3_n_0) ? (arb_sm_ns) : (((axi_arready_cmb) ? (arb_sm_ns) : (1'b1))))) : (((last_arb_won_i_3_n_0) ? (arb_sm_ns) : (((axi_arready_cmb) ? (arb_sm_ns) : (1'b0))))));

  // Reconstructed LUT5: last_arb_won_i_2
  assign arb_sm_ns = ((s_axi_arvalid) ? (((s_axi_awvalid) ? (((arb_sm_cs[1]) ? (1'b0) : (((arb_sm_cs[0]) ? (1'b1) : (~(last_arb_won)))))) : (((arb_sm_cs[1]) ? (~(arb_sm_cs[0])) : (1'b1))))) : (1'b0));

  // Reconstructed LUT5: last_arb_won_i_3
  assign last_arb_won_i_3_n_0 = ((esc_FSM_sequential_arb_sm_cs_reg_0__1_6dbcc34) ? (((arb_sm_cs[1]) ? (((arb_sm_cs[0]) ? (1'b0) : (((s_axi_rready) ? (esc_GEN_NO_RD_CMD_OPT_GEN_AR_SNG_ar_active_d1_reg_3975a1b) : (1'b0))))) : (~(arb_sm_cs[0])))) : (1'b0));

  // Reconstructed FDRE: last_arb_won_reg
  reg recovered_26_q = 1'b0;
  assign last_arb_won = recovered_26_q;
  wire recovered_26_reset = ((ar_active_reg_1)) && ((ar_active_reg_1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_26_reset || (((ar_active_reg_1) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_26_q == (last_arb_won_i_1_n_0)))) recovered_26_q <= (last_arb_won_i_1_n_0);
  end

  // Reconstructed LUT2: esc_save_init_bram_addr_ld_16__i_1_182bfa4
  assign aw_active_re = ((aw_active_d1) ? (1'b0) : (Arb2AW_Active));

  // Reconstructed LUT2: esc_save_init_bram_addr_ld_16__i_1__0_321b301
  assign ar_active_re = ((ar_active_d1) ? (1'b0) : (Arb2AR_Active));

endmodule

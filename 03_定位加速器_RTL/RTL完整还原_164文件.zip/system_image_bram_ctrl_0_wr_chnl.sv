// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_image_bram_ctrl_0_wr_chnl
   (aw_active_d1,
    bram_wrdata_a,
    s_axi_wready,
    axi_bvalid_int_reg_0,
    curr_fixed_burst_reg,
    SR,
    s_axi_wvalid_0,
    AW2Arb_Active_Clr,
    curr_wrap_burst_reg_reg_0,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4 ,
    .s_axi_awaddr_2_sp_1(s_axi_awaddr_2_sn_1),
    D,
    s_axi_awvalid_0,
    bram_en_a,
    s_axi_bid,
    esc_GEN_WR_NO_ECC_bram_we_int_reg_3__0_c89e4f5 ,
    esc_save_init_bram_addr_ld_reg_3_8d0fcb1 ,
    s_axi_aclk,
    s_axi_awid,
    Arb2AW_Active,
    s_axi_wdata,
    aw_active_re,
    s_axi_aresetn,
    s_axi_wlast,
    s_axi_wvalid,
    s_axi_bready,
    s_axi_awaddr,
    Q,
    s_axi_awvalid,
    s_axi_awlen,
    BRAM_En_B_i,
    s_axi_awburst,
    s_axi_wstrb);
  output aw_active_d1;
  output [31:0]bram_wrdata_a;
  output s_axi_wready;
  output axi_bvalid_int_reg_0;
  output curr_fixed_burst_reg;
  output [0:0]SR;
  output s_axi_wvalid_0;
  output AW2Arb_Active_Clr;
  output curr_wrap_burst_reg_reg_0;
  output esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4 ;
  output [13:0]D;
  output s_axi_awvalid_0;
  output bram_en_a;
  output [13:0]s_axi_bid;
  output [3:0]esc_GEN_WR_NO_ECC_bram_we_int_reg_3__0_c89e4f5 ;
  input esc_save_init_bram_addr_ld_reg_3_8d0fcb1 ;
  input s_axi_aclk;
  input [13:0]s_axi_awid;
  input Arb2AW_Active;
  input [31:0]s_axi_wdata;
  input aw_active_re;
  input s_axi_aresetn;
  input s_axi_wlast;
  input s_axi_wvalid;
  input s_axi_bready;
  input [14:0]s_axi_awaddr;
  input [3:0]Q;
  input s_axi_awvalid;
  input [3:0]s_axi_awlen;
  input BRAM_En_B_i;
  input [1:0]s_axi_awburst;
  input [3:0]s_axi_wstrb;
  output s_axi_awaddr_2_sn_1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4 ;
  wire AW2Arb_Active_Clr;
  wire [2:0]AW2Arb_BVALID_Cnt;
  wire Arb2AW_Active;
  wire BID_FIFO_n_0;
  wire BID_FIFO_n_1;
  wire BID_FIFO_n_10;
  wire BID_FIFO_n_11;
  wire BID_FIFO_n_12;
  wire BID_FIFO_n_13;
  wire BID_FIFO_n_14;
  wire BID_FIFO_n_15;
  wire BID_FIFO_n_16;
  wire BID_FIFO_n_3;
  wire BID_FIFO_n_5;
  wire BID_FIFO_n_6;
  wire BID_FIFO_n_7;
  wire BID_FIFO_n_8;
  wire BID_FIFO_n_9;
  wire BRAM_En_A_i;
  wire BRAM_En_B_i;
  wire [13:0]D;
  wire esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_0__i_1_n_0_e97d593 ;
  wire esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_1__i_1_n_0_8cf37a7 ;
  wire esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_1__i_2_n_0_90cad25 ;
  wire esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_1_n_0_6224675 ;
  wire esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201 ;
  wire esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c ;
  wire esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb ;
  wire esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51 ;
  wire [3:0]esc_GEN_WR_NO_ECC_bram_we_int_reg_3__0_c89e4f5 ;
  wire I_WRAP_BRST_n_18;
  wire I_WRAP_BRST_n_19;
  wire [3:0]Q;
  wire [0:0]SR;
  wire aw_active_d1;
  wire aw_active_re;
  wire axi_bvalid_int_i_1_n_0;
  wire axi_bvalid_int_i_2_n_0;
  wire axi_bvalid_int_reg_0;
  wire axi_wdata_full_cmb;
  wire axi_wdata_full_reg;
  wire axi_wr_burst;
  wire axi_wr_burst_i_1_n_0;
  wire axi_wr_burst_i_2_n_0;
  wire axi_wready_int_mod_i_1_n_0;
  wire bid_gets_fifo_load;
  wire bid_gets_fifo_load_d1;
  wire bram_en_a;
  wire bram_en_cmb;
  wire [31:0]bram_wrdata_a;
  wire esc_bvalid_cnt_0__i_1_n_0_a8f27e6 ;
  wire esc_bvalid_cnt_1__i_1_n_0_828609c ;
  wire esc_bvalid_cnt_2__i_1_n_0_d2c7e4b ;
  wire bvalid_cnt_inc;
  wire clr_bram_we;
  wire curr_fixed_burst_reg;
  wire curr_wrap_burst_reg;
  wire curr_wrap_burst_reg_reg_0;
  wire s_axi_aclk;
  wire s_axi_aresetn;
  wire [14:0]s_axi_awaddr;
  wire s_axi_awaddr_2_sn_1;
  wire [1:0]s_axi_awburst;
  wire [13:0]s_axi_awid;
  wire [3:0]s_axi_awlen;
  wire s_axi_awvalid;
  wire s_axi_awvalid_0;
  wire [13:0]s_axi_bid;
  wire s_axi_bready;
  wire [31:0]s_axi_wdata;
  wire s_axi_wlast;
  wire s_axi_wready;
  wire [3:0]s_axi_wstrb;
  wire s_axi_wvalid;
  wire s_axi_wvalid_0;
  wire esc_save_init_bram_addr_ld_reg_3_8d0fcb1 ;
  wire wrdata_reg_ld;
  wire [13:0]NLW_BID_FIFO_D_UNCONNECTED;
  wire [13:0]NLW_BID_FIFO_s_axi_awid_UNCONNECTED;

  // Reconstructed LUT2: esc_ADDR_SNG_PORT_bram_addr_int_16__i_4_1ab550d
  assign s_axi_wvalid_0 = ((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb) ? (s_axi_wvalid) : (1'b0));

  system_image_bram_ctrl_0_SRL_FIFO BID_FIFO
       (.AW2Arb_BVALID_Cnt(AW2Arb_BVALID_Cnt),
        .esc_Addr_Counters_3__FDRE_I_0_2034557 (esc_save_init_bram_addr_ld_reg_3_8d0fcb1 ),
        .Arb2AW_Active(Arb2AW_Active),
        .D({BID_FIFO_n_3,NLW_BID_FIFO_D_UNCONNECTED[12],BID_FIFO_n_5,BID_FIFO_n_6,BID_FIFO_n_7,BID_FIFO_n_8,BID_FIFO_n_9,BID_FIFO_n_10,BID_FIFO_n_11,BID_FIFO_n_12,BID_FIFO_n_13,BID_FIFO_n_14,BID_FIFO_n_15,BID_FIFO_n_16}),
        .Data_Exists_DFF_0(aw_active_d1),
        .Data_Exists_DFF_1(axi_bvalid_int_reg_0),
        .E(BID_FIFO_n_1),
        .esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_6e46e73 (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c ),
        .esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_0_bd3fb69 (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb ),
        .aw_active_re(aw_active_re),
        .axi_wdata_full_reg(axi_wdata_full_reg),
        .axi_wr_burst(axi_wr_burst),
        .bid_gets_fifo_load(bid_gets_fifo_load),
        .bid_gets_fifo_load_d1(bid_gets_fifo_load_d1),
        .bid_gets_fifo_load_d1_reg(axi_bvalid_int_i_2_n_0),
        .bvalid_cnt_inc(bvalid_cnt_inc),
        .s_axi_aclk(s_axi_aclk),
        .s_axi_awid({s_axi_awid[13],NLW_BID_FIFO_s_axi_awid_UNCONNECTED[12],s_axi_awid[11:0]}),
        .s_axi_bready(s_axi_bready),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wlast_0(BID_FIFO_n_0),
        .s_axi_wvalid(s_axi_wvalid));

  // Reconstructed LUT6: esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_0__i_1_0958153
  assign esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_0__i_1_n_0_e97d593 = ((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c) ? (((AW2Arb_Active_Clr) ? (1'b1) : (((s_axi_wlast) ? (((s_axi_wvalid) ? (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb) ? (1'b0) : (~(esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201)))) : (~(esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201)))) : (~(esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201)))))) : (AW2Arb_Active_Clr));

  // Reconstructed LUT6: esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_1__i_1_6f90ae1
  assign esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_1__i_1_n_0_8cf37a7 = ((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb) ? (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_1__i_2_n_0_90cad25) ? (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c) ? (((axi_wr_burst) ? (((axi_wdata_full_reg) ? (1'b1) : (~(s_axi_wlast)))) : (((axi_wdata_full_reg) ? (1'b0) : (~(s_axi_wlast)))))) : (1'b0))) : (1'b1))) : (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_1__i_2_n_0_90cad25) ? (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c) ? (((axi_wr_burst) ? (((axi_wdata_full_reg) ? (1'b1) : (~(s_axi_wlast)))) : (((axi_wdata_full_reg) ? (1'b0) : (~(s_axi_wlast)))))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_1__i_2_89903f3
  assign esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_1__i_2_n_0_90cad25 = ((AW2Arb_Active_Clr) ? (1'b1) : (((s_axi_wlast) ? (((s_axi_wvalid) ? (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb) ? (1'b1) : (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201))) : (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201))) : (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201))));

  // Reconstructed LUT6: esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_1_0d068df
  assign esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_1_n_0_6224675 = ((AW2Arb_Active_Clr) ? (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb) ? (1'b1) : (~(BID_FIFO_n_0)))) : (((s_axi_wlast) ? (((s_axi_wvalid) ? (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb) ? (1'b1) : (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201) ? (~(BID_FIFO_n_0)) : (1'b0))))) : (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb) ? (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201) : (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201) ? (~(BID_FIFO_n_0)) : (1'b0))))))) : (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb) ? (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201) : (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201) ? (~(BID_FIFO_n_0)) : (1'b0))))))));

  // Reconstructed LUT4: esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_8439f28
  assign esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201 = ((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c) ? (((Arb2AW_Active) ? (((axi_wdata_full_reg) ? (1'b1) : (s_axi_wvalid))) : (1'b0))) : (1'b0));

  // Reconstructed FDSE: esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_0_a0ecbe4
  reg recovered_8_q = 1'b1;
  assign esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c = recovered_8_q;
  wire recovered_8_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_8_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_8_q == 1'b1))) recovered_8_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_8_q == (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_0__i_1_n_0_e97d593)))) recovered_8_q <= (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_0__i_1_n_0_e97d593);
  end

  // Reconstructed FDRE: esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_1_7536d71
  reg recovered_9_q = 1'b0;
  assign esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb = recovered_9_q;
  wire recovered_9_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_9_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_1__i_1_n_0_8cf37a7)))) recovered_9_q <= (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_1__i_1_n_0_8cf37a7);
  end

  // Reconstructed FDRE: esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_2_892132a
  reg recovered_10_q = 1'b0;
  assign AW2Arb_Active_Clr = recovered_10_q;
  wire recovered_10_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_10_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_10_q == (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_1_n_0_6224675)))) recovered_10_q <= (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_1_n_0_6224675);
  end

  // Reconstructed LUT6: esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_axi_wdata_full_reg_i_1_7429cfa
  assign axi_wdata_full_cmb = ((s_axi_wvalid) ? (((AW2Arb_Active_Clr) ? (1'b1) : (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb) ? (((axi_wdata_full_reg) ? (1'b1) : (((Arb2AW_Active) ? (1'b0) : (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c))))) : (((Arb2AW_Active) ? (1'b0) : (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c))))))) : (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb) ? (axi_wdata_full_reg) : (((axi_wdata_full_reg) ? (((Arb2AW_Active) ? (1'b0) : (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c))) : (1'b0))))));

  // Reconstructed FDRE: esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_axi_wdata_full_reg_reg_07756cf
  reg recovered_12_q = 1'b0;
  assign axi_wdata_full_reg = recovered_12_q;
  wire recovered_12_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_12_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_12_q == (axi_wdata_full_cmb)))) recovered_12_q <= (axi_wdata_full_cmb);
  end

  // Reconstructed LUT5: esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_bram_en_int_i_1_42bc27d
  assign bram_en_cmb = ((s_axi_wvalid) ? (((Arb2AW_Active) ? (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c) ? (1'b1) : (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb))) : (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb))) : (((axi_wdata_full_reg) ? (((Arb2AW_Active) ? (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c) : (1'b0))) : (1'b0))));

  // Reconstructed FDRE: esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_bram_en_int_reg_7340f99
  reg recovered_14_q = 1'b0;
  assign BRAM_En_A_i = recovered_14_q;
  wire recovered_14_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_14_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_14_q == (bram_en_cmb)))) recovered_14_q <= (bram_en_cmb);
  end

  // Reconstructed FDRE: esc_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_clr_bram_we_reg_6e46e73
  reg recovered_15_q = 1'b0;
  assign clr_bram_we = recovered_15_q;
  wire recovered_15_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_15_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_15_q == (bvalid_cnt_inc)))) recovered_15_q <= (bvalid_cnt_inc);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_0__bram_wrdata_int_reg_0_620015f
  reg recovered_16_q = 1'b0;
  assign bram_wrdata_a[0] = recovered_16_q;
  wire recovered_16_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_16_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_16_q == (s_axi_wdata[0])))) recovered_16_q <= (s_axi_wdata[0]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_10__bram_wrdata_int_reg_10_72a01a5
  reg recovered_17_q = 1'b0;
  assign bram_wrdata_a[10] = recovered_17_q;
  wire recovered_17_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_17_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_17_q == (s_axi_wdata[10])))) recovered_17_q <= (s_axi_wdata[10]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_11__bram_wrdata_int_reg_11_72074ea
  reg recovered_18_q = 1'b0;
  assign bram_wrdata_a[11] = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_18_q == (s_axi_wdata[11])))) recovered_18_q <= (s_axi_wdata[11]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_12__bram_wrdata_int_reg_12_1ad45f7
  reg recovered_19_q = 1'b0;
  assign bram_wrdata_a[12] = recovered_19_q;
  wire recovered_19_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_19_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_19_q == (s_axi_wdata[12])))) recovered_19_q <= (s_axi_wdata[12]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_13__bram_wrdata_int_reg_13_6677e80
  reg recovered_20_q = 1'b0;
  assign bram_wrdata_a[13] = recovered_20_q;
  wire recovered_20_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_20_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_20_q == (s_axi_wdata[13])))) recovered_20_q <= (s_axi_wdata[13]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_14__bram_wrdata_int_reg_14_b19603d
  reg recovered_21_q = 1'b0;
  assign bram_wrdata_a[14] = recovered_21_q;
  wire recovered_21_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_21_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_21_q == (s_axi_wdata[14])))) recovered_21_q <= (s_axi_wdata[14]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_15__bram_wrdata_int_reg_15_5b06385
  reg recovered_22_q = 1'b0;
  assign bram_wrdata_a[15] = recovered_22_q;
  wire recovered_22_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_22_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_22_q == (s_axi_wdata[15])))) recovered_22_q <= (s_axi_wdata[15]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_16__bram_wrdata_int_reg_16_1f98b6f
  reg recovered_23_q = 1'b0;
  assign bram_wrdata_a[16] = recovered_23_q;
  wire recovered_23_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_23_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_23_q == (s_axi_wdata[16])))) recovered_23_q <= (s_axi_wdata[16]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_17__bram_wrdata_int_reg_17_dd87972
  reg recovered_24_q = 1'b0;
  assign bram_wrdata_a[17] = recovered_24_q;
  wire recovered_24_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_24_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_24_q == (s_axi_wdata[17])))) recovered_24_q <= (s_axi_wdata[17]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_18__bram_wrdata_int_reg_18_8d41f10
  reg recovered_25_q = 1'b0;
  assign bram_wrdata_a[18] = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_25_q == (s_axi_wdata[18])))) recovered_25_q <= (s_axi_wdata[18]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_19__bram_wrdata_int_reg_19_1a0894c
  reg recovered_26_q = 1'b0;
  assign bram_wrdata_a[19] = recovered_26_q;
  wire recovered_26_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_26_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_26_q == (s_axi_wdata[19])))) recovered_26_q <= (s_axi_wdata[19]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_1__bram_wrdata_int_reg_1_2a22425
  reg recovered_27_q = 1'b0;
  assign bram_wrdata_a[1] = recovered_27_q;
  wire recovered_27_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_27_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_27_q == (s_axi_wdata[1])))) recovered_27_q <= (s_axi_wdata[1]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_20__bram_wrdata_int_reg_20_e9b6737
  reg recovered_28_q = 1'b0;
  assign bram_wrdata_a[20] = recovered_28_q;
  wire recovered_28_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_28_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_28_q == (s_axi_wdata[20])))) recovered_28_q <= (s_axi_wdata[20]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_21__bram_wrdata_int_reg_21_9623936
  reg recovered_29_q = 1'b0;
  assign bram_wrdata_a[21] = recovered_29_q;
  wire recovered_29_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_29_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_29_q == (s_axi_wdata[21])))) recovered_29_q <= (s_axi_wdata[21]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_22__bram_wrdata_int_reg_22_1a16fd9
  reg recovered_30_q = 1'b0;
  assign bram_wrdata_a[22] = recovered_30_q;
  wire recovered_30_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_30_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_30_q == (s_axi_wdata[22])))) recovered_30_q <= (s_axi_wdata[22]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_23__bram_wrdata_int_reg_23_74603ef
  reg recovered_31_q = 1'b0;
  assign bram_wrdata_a[23] = recovered_31_q;
  wire recovered_31_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_31_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_31_q == (s_axi_wdata[23])))) recovered_31_q <= (s_axi_wdata[23]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_24__bram_wrdata_int_reg_24_953dc14
  reg recovered_32_q = 1'b0;
  assign bram_wrdata_a[24] = recovered_32_q;
  wire recovered_32_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_32_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_32_q == 1'b0))) recovered_32_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_32_q == (s_axi_wdata[24])))) recovered_32_q <= (s_axi_wdata[24]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_25__bram_wrdata_int_reg_25_91c4b5c
  reg recovered_33_q = 1'b0;
  assign bram_wrdata_a[25] = recovered_33_q;
  wire recovered_33_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_33_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_33_q == 1'b0))) recovered_33_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_33_q == (s_axi_wdata[25])))) recovered_33_q <= (s_axi_wdata[25]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_26__bram_wrdata_int_reg_26_5f2c840
  reg recovered_34_q = 1'b0;
  assign bram_wrdata_a[26] = recovered_34_q;
  wire recovered_34_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_34_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_34_q == 1'b0))) recovered_34_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_34_q == (s_axi_wdata[26])))) recovered_34_q <= (s_axi_wdata[26]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_27__bram_wrdata_int_reg_27_6e84f2b
  reg recovered_35_q = 1'b0;
  assign bram_wrdata_a[27] = recovered_35_q;
  wire recovered_35_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_35_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_35_q == 1'b0))) recovered_35_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_35_q == (s_axi_wdata[27])))) recovered_35_q <= (s_axi_wdata[27]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_28__bram_wrdata_int_reg_28_8b9bbbe
  reg recovered_36_q = 1'b0;
  assign bram_wrdata_a[28] = recovered_36_q;
  wire recovered_36_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_36_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_36_q == 1'b0))) recovered_36_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_36_q == (s_axi_wdata[28])))) recovered_36_q <= (s_axi_wdata[28]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_29__bram_wrdata_int_reg_29_4f6d885
  reg recovered_37_q = 1'b0;
  assign bram_wrdata_a[29] = recovered_37_q;
  wire recovered_37_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_37_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_37_q == 1'b0))) recovered_37_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_37_q == (s_axi_wdata[29])))) recovered_37_q <= (s_axi_wdata[29]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_2__bram_wrdata_int_reg_2_76b271a
  reg recovered_38_q = 1'b0;
  assign bram_wrdata_a[2] = recovered_38_q;
  wire recovered_38_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_38_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_38_q == 1'b0))) recovered_38_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_38_q == (s_axi_wdata[2])))) recovered_38_q <= (s_axi_wdata[2]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_30__bram_wrdata_int_reg_30_2d6186d
  reg recovered_39_q = 1'b0;
  assign bram_wrdata_a[30] = recovered_39_q;
  wire recovered_39_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_39_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_39_q == 1'b0))) recovered_39_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_39_q == (s_axi_wdata[30])))) recovered_39_q <= (s_axi_wdata[30]);
  end

  // Reconstructed LUT5: esc_GEN_WRDATA_31__bram_wrdata_int_31__i_1_12b1841
  assign wrdata_reg_ld = ((AW2Arb_Active_Clr) ? (s_axi_wvalid) : (((axi_wdata_full_reg) ? (((s_axi_wvalid) ? (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb) : (1'b0))) : (((s_axi_wvalid) ? (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c) ? (1'b1) : (esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__1_f8a58cb))) : (1'b0))))));

  // Reconstructed FDRE: esc_GEN_WRDATA_31__bram_wrdata_int_reg_31_9601b19
  reg recovered_41_q = 1'b0;
  assign bram_wrdata_a[31] = recovered_41_q;
  wire recovered_41_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_41_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_41_q == 1'b0))) recovered_41_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_41_q == (s_axi_wdata[31])))) recovered_41_q <= (s_axi_wdata[31]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_3__bram_wrdata_int_reg_3_900525b
  reg recovered_42_q = 1'b0;
  assign bram_wrdata_a[3] = recovered_42_q;
  wire recovered_42_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_42_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_42_q == 1'b0))) recovered_42_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_42_q == (s_axi_wdata[3])))) recovered_42_q <= (s_axi_wdata[3]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_4__bram_wrdata_int_reg_4_c1884ea
  reg recovered_43_q = 1'b0;
  assign bram_wrdata_a[4] = recovered_43_q;
  wire recovered_43_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_43_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_43_q == (s_axi_wdata[4])))) recovered_43_q <= (s_axi_wdata[4]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_5__bram_wrdata_int_reg_5_fde5a82
  reg recovered_44_q = 1'b0;
  assign bram_wrdata_a[5] = recovered_44_q;
  wire recovered_44_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_44_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_44_q == (s_axi_wdata[5])))) recovered_44_q <= (s_axi_wdata[5]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_6__bram_wrdata_int_reg_6_7297297
  reg recovered_45_q = 1'b0;
  assign bram_wrdata_a[6] = recovered_45_q;
  wire recovered_45_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_45_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_45_q == 1'b0))) recovered_45_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_45_q == (s_axi_wdata[6])))) recovered_45_q <= (s_axi_wdata[6]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_7__bram_wrdata_int_reg_7_4f52d7a
  reg recovered_46_q = 1'b0;
  assign bram_wrdata_a[7] = recovered_46_q;
  wire recovered_46_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_46_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_46_q == 1'b0))) recovered_46_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_46_q == (s_axi_wdata[7])))) recovered_46_q <= (s_axi_wdata[7]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_8__bram_wrdata_int_reg_8_b7c6a4a
  reg recovered_47_q = 1'b0;
  assign bram_wrdata_a[8] = recovered_47_q;
  wire recovered_47_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_47_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_47_q == 1'b0))) recovered_47_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_47_q == (s_axi_wdata[8])))) recovered_47_q <= (s_axi_wdata[8]);
  end

  // Reconstructed FDRE: esc_GEN_WRDATA_9__bram_wrdata_int_reg_9_ee4c505
  reg recovered_48_q = 1'b0;
  assign bram_wrdata_a[9] = recovered_48_q;
  wire recovered_48_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_48_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_48_q == 1'b0))) recovered_48_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_48_q == (s_axi_wdata[9])))) recovered_48_q <= (s_axi_wdata[9]);
  end

  // Reconstructed LUT3: esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_68cf913
  assign esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51 = ((s_axi_aresetn) ? (((clr_bram_we) ? (~(wrdata_reg_ld)) : (1'b0))) : (1'b1));

  // Reconstructed FDRE: esc_GEN_WR_NO_ECC_bram_we_int_reg_0_14d01ad
  reg recovered_50_q = 1'b0;
  assign esc_GEN_WR_NO_ECC_bram_we_int_reg_3__0_c89e4f5 [0] = recovered_50_q;
  wire recovered_50_reset = ((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51)) && ((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_50_reset || (((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51) === 1'bx) && (recovered_50_q == 1'b0))) recovered_50_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_50_q == (s_axi_wstrb[0])))) recovered_50_q <= (s_axi_wstrb[0]);
  end

  // Reconstructed FDRE: esc_GEN_WR_NO_ECC_bram_we_int_reg_1_6fbde12
  reg recovered_51_q = 1'b0;
  assign esc_GEN_WR_NO_ECC_bram_we_int_reg_3__0_c89e4f5 [1] = recovered_51_q;
  wire recovered_51_reset = ((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51)) && ((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_51_reset || (((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51) === 1'bx) && (recovered_51_q == 1'b0))) recovered_51_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_51_q == (s_axi_wstrb[1])))) recovered_51_q <= (s_axi_wstrb[1]);
  end

  // Reconstructed FDRE: esc_GEN_WR_NO_ECC_bram_we_int_reg_2_5499c80
  reg recovered_52_q = 1'b0;
  assign esc_GEN_WR_NO_ECC_bram_we_int_reg_3__0_c89e4f5 [2] = recovered_52_q;
  wire recovered_52_reset = ((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51)) && ((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_52_reset || (((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51) === 1'bx) && (recovered_52_q == 1'b0))) recovered_52_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_52_q == (s_axi_wstrb[2])))) recovered_52_q <= (s_axi_wstrb[2]);
  end

  // Reconstructed FDRE: esc_GEN_WR_NO_ECC_bram_we_int_reg_3_25ca690
  reg recovered_53_q = 1'b0;
  assign esc_GEN_WR_NO_ECC_bram_we_int_reg_3__0_c89e4f5 [3] = recovered_53_q;
  wire recovered_53_reset = ((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51)) && ((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_53_reset || (((esc_GEN_WR_NO_ECC_bram_we_int_3__i_1_n_0_9899c51) === 1'bx) && (recovered_53_q == 1'b0))) recovered_53_q <= 1'b0;
    else if ((wrdata_reg_ld) || ((wrdata_reg_ld) === 1'bz) || (((wrdata_reg_ld) === 1'bx) && (recovered_53_q == (s_axi_wstrb[3])))) recovered_53_q <= (s_axi_wstrb[3]);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  system_image_bram_ctrl_0_wrap_brst I_WRAP_BRST
       (.esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 (s_axi_wvalid_0),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b (AW2Arb_Active_Clr),
        .esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4 (esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4 ),
        .Arb2AW_Active(Arb2AW_Active),
        .D(D),
        .Q(Q),
        .SR(SR),
        .aw_active_re(aw_active_re),
        .curr_fixed_burst_reg(curr_fixed_burst_reg),
        .curr_fixed_burst_reg_reg(I_WRAP_BRST_n_19),
        .curr_fixed_burst_reg_reg_0(aw_active_d1),
        .curr_wrap_burst_reg(curr_wrap_burst_reg),
        .curr_wrap_burst_reg_reg(curr_wrap_burst_reg_reg_0),
        .curr_wrap_burst_reg_reg_0(I_WRAP_BRST_n_18),
        .s_axi_aclk(s_axi_aclk),
        .s_axi_aresetn(s_axi_aresetn),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awaddr_2_sp_1(s_axi_awaddr_2_sn_1),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awvalid(s_axi_awvalid),
        .esc_save_init_bram_addr_ld_reg_3__0_d2dbc06 (esc_save_init_bram_addr_ld_reg_3_8d0fcb1 ));

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed FDRE: aw_active_d1_reg
  reg recovered_57_q = 1'b0;
  assign aw_active_d1 = recovered_57_q;
  wire recovered_57_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_57_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_57_q == 1'b0))) recovered_57_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_57_q == (Arb2AW_Active)))) recovered_57_q <= (Arb2AW_Active);
  end

  // Reconstructed LUT4: axi_awready_int_i_2
  assign s_axi_awvalid_0 = ((AW2Arb_BVALID_Cnt[1]) ? (((AW2Arb_BVALID_Cnt[2]) ? (((AW2Arb_BVALID_Cnt[0]) ? (1'b0) : (s_axi_awvalid))) : (s_axi_awvalid))) : (s_axi_awvalid));

  // Reconstructed FDRE: esc_axi_bid_int_reg_0_c0d4855
  reg recovered_59_q = 1'b0;
  assign s_axi_bid[0] = recovered_59_q;
  wire recovered_59_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_59_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_59_q == 1'b0))) recovered_59_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_59_q == (BID_FIFO_n_16)))) recovered_59_q <= (BID_FIFO_n_16);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_10_02a194f
  reg recovered_60_q = 1'b0;
  assign s_axi_bid[10] = recovered_60_q;
  wire recovered_60_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_60_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_60_q == 1'b0))) recovered_60_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_60_q == (BID_FIFO_n_6)))) recovered_60_q <= (BID_FIFO_n_6);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_11_2bb8c9d
  reg recovered_61_q = 1'b0;
  assign s_axi_bid[11] = recovered_61_q;
  wire recovered_61_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_61_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_61_q == 1'b0))) recovered_61_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_61_q == (BID_FIFO_n_5)))) recovered_61_q <= (BID_FIFO_n_5);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_13_87ec3f0
  reg recovered_62_q = 1'b0;
  assign s_axi_bid[13] = recovered_62_q;
  wire recovered_62_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_62_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_62_q == 1'b0))) recovered_62_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_62_q == (BID_FIFO_n_3)))) recovered_62_q <= (BID_FIFO_n_3);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_1_14a2a27
  reg recovered_63_q = 1'b0;
  assign s_axi_bid[1] = recovered_63_q;
  wire recovered_63_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_63_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_63_q == 1'b0))) recovered_63_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_63_q == (BID_FIFO_n_15)))) recovered_63_q <= (BID_FIFO_n_15);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_2_9340450
  reg recovered_64_q = 1'b0;
  assign s_axi_bid[2] = recovered_64_q;
  wire recovered_64_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_64_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_64_q == 1'b0))) recovered_64_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_64_q == (BID_FIFO_n_14)))) recovered_64_q <= (BID_FIFO_n_14);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_3_1c7cf33
  reg recovered_65_q = 1'b0;
  assign s_axi_bid[3] = recovered_65_q;
  wire recovered_65_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_65_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_65_q == 1'b0))) recovered_65_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_65_q == (BID_FIFO_n_13)))) recovered_65_q <= (BID_FIFO_n_13);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_4_39bd47e
  reg recovered_66_q = 1'b0;
  assign s_axi_bid[4] = recovered_66_q;
  wire recovered_66_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_66_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_66_q == 1'b0))) recovered_66_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_66_q == (BID_FIFO_n_12)))) recovered_66_q <= (BID_FIFO_n_12);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_5_a539526
  reg recovered_67_q = 1'b0;
  assign s_axi_bid[5] = recovered_67_q;
  wire recovered_67_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_67_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_67_q == 1'b0))) recovered_67_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_67_q == (BID_FIFO_n_11)))) recovered_67_q <= (BID_FIFO_n_11);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_6_34bd6ae
  reg recovered_68_q = 1'b0;
  assign s_axi_bid[6] = recovered_68_q;
  wire recovered_68_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_68_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_68_q == 1'b0))) recovered_68_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_68_q == (BID_FIFO_n_10)))) recovered_68_q <= (BID_FIFO_n_10);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_7_19c0b9c
  reg recovered_69_q = 1'b0;
  assign s_axi_bid[7] = recovered_69_q;
  wire recovered_69_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_69_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_69_q == 1'b0))) recovered_69_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_69_q == (BID_FIFO_n_9)))) recovered_69_q <= (BID_FIFO_n_9);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_8_6c42f00
  reg recovered_70_q = 1'b0;
  assign s_axi_bid[8] = recovered_70_q;
  wire recovered_70_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_70_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_70_q == 1'b0))) recovered_70_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_70_q == (BID_FIFO_n_8)))) recovered_70_q <= (BID_FIFO_n_8);
  end

  // Reconstructed FDRE: esc_axi_bid_int_reg_9_cfb08a4
  reg recovered_71_q = 1'b0;
  assign s_axi_bid[9] = recovered_71_q;
  wire recovered_71_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_71_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_71_q == 1'b0))) recovered_71_q <= 1'b0;
    else if ((BID_FIFO_n_1) || ((BID_FIFO_n_1) === 1'bz) || (((BID_FIFO_n_1) === 1'bx) && (recovered_71_q == (BID_FIFO_n_7)))) recovered_71_q <= (BID_FIFO_n_7);
  end

  // Reconstructed LUT6: axi_bvalid_int_i_1
  assign axi_bvalid_int_i_1_n_0 = ((bvalid_cnt_inc) ? (s_axi_aresetn) : (((axi_bvalid_int_i_2_n_0) ? (1'b0) : (((AW2Arb_BVALID_Cnt[1]) ? (s_axi_aresetn) : (((AW2Arb_BVALID_Cnt[2]) ? (s_axi_aresetn) : (((AW2Arb_BVALID_Cnt[0]) ? (s_axi_aresetn) : (1'b0))))))))));

  // Reconstructed LUT5: axi_bvalid_int_i_2
  assign axi_bvalid_int_i_2_n_0 = ((axi_bvalid_int_reg_0) ? (((s_axi_bready) ? (((AW2Arb_BVALID_Cnt[1]) ? (1'b0) : (((AW2Arb_BVALID_Cnt[0]) ? (~(AW2Arb_BVALID_Cnt[2])) : (1'b0))))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: axi_bvalid_int_reg
  reg recovered_74_q = 1'b0;
  assign axi_bvalid_int_reg_0 = recovered_74_q;
  wire recovered_74_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_74_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_74_q == 1'b0))) recovered_74_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_74_q == (axi_bvalid_int_i_1_n_0)))) recovered_74_q <= (axi_bvalid_int_i_1_n_0);
  end

  // Reconstructed LUT4: axi_wr_burst_i_1
  assign axi_wr_burst_i_1_n_0 = ((axi_wr_burst) ? (((axi_wr_burst_i_2_n_0) ? (~(s_axi_wlast)) : (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201) ? (~(s_axi_wlast)) : (1'b1))))) : (((axi_wr_burst_i_2_n_0) ? (~(s_axi_wlast)) : (((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_2__i_3_n_0_6559201) ? (~(s_axi_wlast)) : (1'b0))))));

  // Reconstructed LUT4: axi_wr_burst_i_2
  assign axi_wr_burst_i_2_n_0 = ((esc_FSM_onehot_GEN_WDATA_SM_NO_ECC_SNG_REG_WREADY_wr_data_sng_sm_cs_reg_n_0__0_c69330c) ? (((s_axi_wvalid) ? (((axi_wdata_full_reg) ? (AW2Arb_Active_Clr) : (1'b1))) : (1'b0))) : (((s_axi_wvalid) ? (AW2Arb_Active_Clr) : (1'b0))));

  // Reconstructed FDRE: axi_wr_burst_reg
  reg recovered_77_q = 1'b0;
  assign axi_wr_burst = recovered_77_q;
  wire recovered_77_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_77_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_77_q == 1'b0))) recovered_77_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_77_q == (axi_wr_burst_i_1_n_0)))) recovered_77_q <= (axi_wr_burst_i_1_n_0);
  end

  // Reconstructed LUT2: axi_wready_int_mod_i_1
  assign axi_wready_int_mod_i_1_n_0 = ((axi_wdata_full_cmb) ? (1'b0) : (s_axi_aresetn));

  // Reconstructed FDRE: axi_wready_int_mod_reg
  reg recovered_79_q = 1'b0;
  assign s_axi_wready = recovered_79_q;
  wire recovered_79_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_79_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_79_q == 1'b0))) recovered_79_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_79_q == (axi_wready_int_mod_i_1_n_0)))) recovered_79_q <= (axi_wready_int_mod_i_1_n_0);
  end

  // Reconstructed FDRE: bid_gets_fifo_load_d1_reg
  reg recovered_80_q = 1'b0;
  assign bid_gets_fifo_load_d1 = recovered_80_q;
  wire recovered_80_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_80_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_80_q == 1'b0))) recovered_80_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_80_q == (bid_gets_fifo_load)))) recovered_80_q <= (bid_gets_fifo_load);
  end

  // Reconstructed LUT2: bram_en_a_INST_0
  assign bram_en_a = ((BRAM_En_B_i) ? (1'b1) : (BRAM_En_A_i));

  // Reconstructed LUT6: esc_bvalid_cnt_0__i_1_7037be9
  assign esc_bvalid_cnt_0__i_1_n_0_a8f27e6 = ((AW2Arb_BVALID_Cnt[0]) ? (((bvalid_cnt_inc) ? (((axi_bvalid_int_reg_0) ? (s_axi_bready) : (1'b0))) : (((axi_bvalid_int_reg_0) ? (~(s_axi_bready)) : (1'b1))))) : (((bvalid_cnt_inc) ? (((axi_bvalid_int_reg_0) ? (((s_axi_bready) ? (((AW2Arb_BVALID_Cnt[1]) ? (1'b0) : (~(AW2Arb_BVALID_Cnt[2])))) : (1'b1))) : (1'b1))) : (((axi_bvalid_int_reg_0) ? (((s_axi_bready) ? (((AW2Arb_BVALID_Cnt[1]) ? (1'b1) : (AW2Arb_BVALID_Cnt[2]))) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT6: esc_bvalid_cnt_1__i_1_87a3ea9
  assign esc_bvalid_cnt_1__i_1_n_0_828609c = ((AW2Arb_BVALID_Cnt[0]) ? (((AW2Arb_BVALID_Cnt[1]) ? (((s_axi_bready) ? (((axi_bvalid_int_reg_0) ? (1'b1) : (~(bvalid_cnt_inc)))) : (~(bvalid_cnt_inc)))) : (((s_axi_bready) ? (((axi_bvalid_int_reg_0) ? (1'b0) : (bvalid_cnt_inc))) : (bvalid_cnt_inc))))) : (((AW2Arb_BVALID_Cnt[2]) ? (((AW2Arb_BVALID_Cnt[1]) ? (((s_axi_bready) ? (((axi_bvalid_int_reg_0) ? (bvalid_cnt_inc) : (1'b1))) : (1'b1))) : (((s_axi_bready) ? (((axi_bvalid_int_reg_0) ? (~(bvalid_cnt_inc)) : (1'b0))) : (1'b0))))) : (((AW2Arb_BVALID_Cnt[1]) ? (((s_axi_bready) ? (((axi_bvalid_int_reg_0) ? (bvalid_cnt_inc) : (1'b1))) : (1'b1))) : (1'b0))))));

  // Reconstructed LUT6: esc_bvalid_cnt_2__i_1_7439120
  assign esc_bvalid_cnt_2__i_1_n_0_d2c7e4b = ((AW2Arb_BVALID_Cnt[0]) ? (((AW2Arb_BVALID_Cnt[2]) ? (((AW2Arb_BVALID_Cnt[1]) ? (((s_axi_bready) ? (((axi_bvalid_int_reg_0) ? (1'b1) : (~(bvalid_cnt_inc)))) : (~(bvalid_cnt_inc)))) : (1'b1))) : (((AW2Arb_BVALID_Cnt[1]) ? (((s_axi_bready) ? (((axi_bvalid_int_reg_0) ? (1'b0) : (bvalid_cnt_inc))) : (bvalid_cnt_inc))) : (1'b0))))) : (((AW2Arb_BVALID_Cnt[2]) ? (((AW2Arb_BVALID_Cnt[1]) ? (1'b1) : (((s_axi_bready) ? (((axi_bvalid_int_reg_0) ? (bvalid_cnt_inc) : (1'b1))) : (1'b1))))) : (1'b0))));

  // Reconstructed FDRE: esc_bvalid_cnt_reg_0_6b7dc99
  reg recovered_85_q = 1'b0;
  assign AW2Arb_BVALID_Cnt[0] = recovered_85_q;
  wire recovered_85_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_85_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_85_q == 1'b0))) recovered_85_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_85_q == (esc_bvalid_cnt_0__i_1_n_0_a8f27e6)))) recovered_85_q <= (esc_bvalid_cnt_0__i_1_n_0_a8f27e6);
  end

  // Reconstructed FDRE: esc_bvalid_cnt_reg_1_3fae55a
  reg recovered_86_q = 1'b0;
  assign AW2Arb_BVALID_Cnt[1] = recovered_86_q;
  wire recovered_86_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_86_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_86_q == 1'b0))) recovered_86_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_86_q == (esc_bvalid_cnt_1__i_1_n_0_828609c)))) recovered_86_q <= (esc_bvalid_cnt_1__i_1_n_0_828609c);
  end

  // Reconstructed FDRE: esc_bvalid_cnt_reg_2_4ed16d9
  reg recovered_87_q = 1'b0;
  assign AW2Arb_BVALID_Cnt[2] = recovered_87_q;
  wire recovered_87_reset = ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1)) && ((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_87_reset || (((esc_save_init_bram_addr_ld_reg_3_8d0fcb1) === 1'bx) && (recovered_87_q == 1'b0))) recovered_87_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_87_q == (esc_bvalid_cnt_2__i_1_n_0_d2c7e4b)))) recovered_87_q <= (esc_bvalid_cnt_2__i_1_n_0_d2c7e4b);
  end

  // Reconstructed FDRE: curr_fixed_burst_reg_reg
  reg recovered_88_q = 1'b0;
  assign curr_fixed_burst_reg = recovered_88_q;
  wire recovered_88_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_88_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_88_q == 1'b0))) recovered_88_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_88_q == (I_WRAP_BRST_n_19)))) recovered_88_q <= (I_WRAP_BRST_n_19);
  end

  // Reconstructed FDRE: curr_wrap_burst_reg_reg
  reg recovered_89_q = 1'b0;
  assign curr_wrap_burst_reg = recovered_89_q;
  wire recovered_89_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_89_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_89_q == 1'b0))) recovered_89_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_89_q == (I_WRAP_BRST_n_18)))) recovered_89_q <= (I_WRAP_BRST_n_18);
  end

endmodule

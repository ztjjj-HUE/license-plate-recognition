// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_image_bram_ctrl_0_wrap_brst
   (SR,
    curr_wrap_burst_reg_reg,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4 ,
    .s_axi_awaddr_2_sp_1(s_axi_awaddr_2_sn_1),
    D,
    curr_wrap_burst_reg_reg_0,
    curr_fixed_burst_reg_reg,
    curr_fixed_burst_reg,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b ,
    aw_active_re,
    s_axi_aresetn,
    curr_wrap_burst_reg,
    s_axi_awaddr,
    curr_fixed_burst_reg_reg_0,
    Arb2AW_Active,
    Q,
    s_axi_awlen,
    s_axi_awvalid,
    s_axi_awburst,
    esc_save_init_bram_addr_ld_reg_3__0_d2dbc06 ,
    s_axi_aclk);
  output [0:0]SR;
  output curr_wrap_burst_reg_reg;
  output esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4 ;
  output [13:0]D;
  output curr_wrap_burst_reg_reg_0;
  output curr_fixed_burst_reg_reg;
  input curr_fixed_burst_reg;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b ;
  input aw_active_re;
  input s_axi_aresetn;
  input curr_wrap_burst_reg;
  input [14:0]s_axi_awaddr;
  input curr_fixed_burst_reg_reg_0;
  input Arb2AW_Active;
  input [3:0]Q;
  input [3:0]s_axi_awlen;
  input s_axi_awvalid;
  input [1:0]s_axi_awburst;
  input esc_save_init_bram_addr_ld_reg_3__0_d2dbc06 ;
  input s_axi_aclk;
  output s_axi_awaddr_2_sn_1;

  wire esc_ADDR_SNG_PORT_bram_addr_int_16__i_10_n_0_a42244a ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_16__i_11_n_0_64b108e ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_16__i_5_n_0_8b5c0e9 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4 ;
  wire Arb2AW_Active;
  wire [13:0]D;
  wire [3:0]Q;
  wire [0:0]SR;
  wire aw_active_re;
  wire curr_fixed_burst_reg;
  wire curr_fixed_burst_reg_reg;
  wire curr_fixed_burst_reg_reg_0;
  wire curr_wrap_burst_reg;
  wire curr_wrap_burst_reg_reg;
  wire curr_wrap_burst_reg_reg_0;
  wire [14:1]data0;
  wire s_axi_aclk;
  wire s_axi_aresetn;
  wire [14:0]s_axi_awaddr;
  wire s_axi_awaddr_2_sn_1;
  wire [1:0]s_axi_awburst;
  wire [3:0]s_axi_awlen;
  wire s_axi_awvalid;
  wire esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c ;
  wire esc_save_init_bram_addr_ld_reg_3__0_d2dbc06 ;
  wire [2:0]wrap_burst_total;
  wire esc_wrap_burst_total_0__i_1_n_0_2ea6d16 ;
  wire esc_wrap_burst_total_1__i_1_n_0_ef4004a ;
  wire esc_wrap_burst_total_2__i_1_n_0_351f795 ;

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_16__i_1_ffbdfaf
  assign SR = ((s_axi_aresetn) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_5_n_0_8b5c0e9) ? (((aw_active_re) ? (1'b0) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8) ? (curr_fixed_burst_reg) : (1'b1))) : (1'b0))))) : (((aw_active_re) ? (1'b0) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b) ? (~(esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8)) : (1'b0))))))) : (1'b1));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_16__i_10_0b5d09a
  assign esc_ADDR_SNG_PORT_bram_addr_int_16__i_10_n_0_a42244a = ((wrap_burst_total[2]) ? (1'b0) : (((Q[0]) ? (((wrap_burst_total[0]) ? (((wrap_burst_total[1]) ? (((Q[2]) ? (Q[1]) : (1'b0))) : (1'b1))) : (((wrap_burst_total[1]) ? (Q[1]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT3: esc_ADDR_SNG_PORT_bram_addr_int_16__i_11_444a619
  assign esc_ADDR_SNG_PORT_bram_addr_int_16__i_11_n_0_64b108e = ((wrap_burst_total[0]) ? (1'b0) : (((wrap_burst_total[2]) ? (~(wrap_burst_total[1])) : (1'b0))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_16__i_5_48587dd
  assign esc_ADDR_SNG_PORT_bram_addr_int_16__i_5_n_0_8b5c0e9 = ((esc_ADDR_SNG_PORT_bram_addr_int_16__i_10_n_0_a42244a) ? (~(curr_wrap_burst_reg)) : (((wrap_burst_total[1]) ? (1'b1) : (((wrap_burst_total[2]) ? (((wrap_burst_total[0]) ? (1'b1) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4) ? (1'b1) : (~(curr_wrap_burst_reg)))))) : (1'b1))))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_16__i_6_086d5a4
  assign curr_wrap_burst_reg_reg = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_10_n_0_a42244a) ? (((curr_wrap_burst_reg) ? (1'b0) : (~(aw_active_re)))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_11_n_0_64b108e) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4) ? (~(aw_active_re)) : (((curr_wrap_burst_reg) ? (1'b0) : (~(aw_active_re)))))) : (~(aw_active_re)))))) : (~(aw_active_re)));

  // Reconstructed LUT2: esc_ADDR_SNG_PORT_bram_addr_int_2__i_2_04227c2
  assign s_axi_awaddr_2_sn_1 = ((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[0]) : (1'b0));

  // Reconstructed LUT4: esc_ADDR_SNG_PORT_bram_addr_int_6__i_2_ae74d36
  assign esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4 = ((Q[3]) ? (((Q[2]) ? (((Q[0]) ? (~(Q[1])) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT6: curr_fixed_burst_reg_i_1
  assign curr_fixed_burst_reg_reg = ((SR) ? (1'b0) : (((s_axi_awburst[0]) ? (((Arb2AW_Active) ? (((curr_fixed_burst_reg_reg_0) ? (curr_fixed_burst_reg) : (1'b0))) : (curr_fixed_burst_reg))) : (((s_axi_awburst[1]) ? (((Arb2AW_Active) ? (((curr_fixed_burst_reg_reg_0) ? (curr_fixed_burst_reg) : (1'b0))) : (curr_fixed_burst_reg))) : (((Arb2AW_Active) ? (((curr_fixed_burst_reg_reg_0) ? (curr_fixed_burst_reg) : (1'b1))) : (curr_fixed_burst_reg))))))));

  // Reconstructed LUT6: curr_wrap_burst_reg_i_1
  assign curr_wrap_burst_reg_reg_0 = ((SR) ? (1'b0) : (((s_axi_awburst[1]) ? (((s_axi_awburst[0]) ? (((Arb2AW_Active) ? (((curr_fixed_burst_reg_reg_0) ? (curr_wrap_burst_reg) : (1'b0))) : (curr_wrap_burst_reg))) : (((Arb2AW_Active) ? (((curr_fixed_burst_reg_reg_0) ? (curr_wrap_burst_reg) : (1'b1))) : (curr_wrap_burst_reg))))) : (((Arb2AW_Active) ? (((curr_fixed_burst_reg_reg_0) ? (curr_wrap_burst_reg) : (1'b0))) : (curr_wrap_burst_reg))))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_10__i_1_a57fda0
  assign D[7] = ((data0[8]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[8]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[8]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_11__i_1_49020f2
  assign D[8] = ((data0[9]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[9]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[9]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_12__i_1_30fa956
  assign D[9] = ((data0[10]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[10]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[10]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_13__i_1_17a0bbb
  assign D[10] = ((data0[11]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[11]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[11]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_14__i_1_defe6a9
  assign D[11] = ((data0[12]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[12]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[12]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_15__i_1_61755ca
  assign D[12] = ((data0[13]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[13]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[13]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_16__i_2_dfb9d3f
  assign D[13] = ((data0[14]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[14]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[14]) : (1'b0))));

  // Reconstructed LUT6: esc_save_init_bram_addr_ld_16__i_3_93fa14b
  assign esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c = ((curr_wrap_burst_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_3_f9c94d4) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_10_n_0_a42244a) ? (((Arb2AW_Active) ? (~(curr_fixed_burst_reg_reg_0)) : (1'b0))) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_11_n_0_64b108e) ? (((Arb2AW_Active) ? (~(curr_fixed_burst_reg_reg_0)) : (1'b0))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_10_n_0_a42244a) ? (((Arb2AW_Active) ? (~(curr_fixed_burst_reg_reg_0)) : (1'b0))) : (1'b1))))))) : (1'b1));

  // Reconstructed LUT6: esc_save_init_bram_addr_ld_3__i_1_c75452f
  assign D[0] = ((wrap_burst_total[1]) ? (((wrap_burst_total[2]) ? (((data0[1]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[1]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[1]) : (1'b0))))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[1]) : (1'b0))))) : (((wrap_burst_total[2]) ? (((wrap_burst_total[0]) ? (((data0[1]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[1]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[1]) : (1'b0))))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[1]) : (1'b0))))) : (((data0[1]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[1]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[1]) : (1'b0))))))));

  // Reconstructed LUT6: esc_save_init_bram_addr_ld_4__i_1_fd7857b
  assign D[1] = ((wrap_burst_total[2]) ? (((wrap_burst_total[1]) ? (((data0[2]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[2]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[2]) : (1'b0))))) : (((wrap_burst_total[0]) ? (((data0[2]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[2]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[2]) : (1'b0))))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[2]) : (1'b0))))))) : (((wrap_burst_total[1]) ? (((wrap_burst_total[0]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[2]) : (1'b0))) : (((data0[2]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[2]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[2]) : (1'b0))))))) : (((data0[2]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[2]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[2]) : (1'b0))))))));

  // Reconstructed LUT6: esc_save_init_bram_addr_ld_5__i_1_e3b055a
  assign D[2] = ((wrap_burst_total[1]) ? (((data0[3]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[3]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[3]) : (1'b0))))) : (((wrap_burst_total[2]) ? (((wrap_burst_total[0]) ? (((data0[3]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[3]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[3]) : (1'b0))))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[3]) : (1'b0))))) : (((data0[3]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[3]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[3]) : (1'b0))))))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_6__i_1_862b632
  assign D[3] = ((data0[4]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[4]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[4]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_7__i_1_2cba49b
  assign D[4] = ((data0[5]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[5]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[5]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_8__i_1_bbcbd3d
  assign D[5] = ((data0[6]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[6]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[6]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_9__i_1_42aceaf
  assign D[6] = ((data0[7]) ? (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[7]) : (1'b1))) : (((esc_save_init_bram_addr_ld_16__i_3_n_0_f2d395c) ? (s_axi_awaddr[7]) : (1'b0))));

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_10_f053177
  reg recovered_25_q = 1'b0;
  assign data0[8] = recovered_25_q;
  wire recovered_25_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_25_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_25_q == (D[7])))) recovered_25_q <= (D[7]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_11_debbd83
  reg recovered_26_q = 1'b0;
  assign data0[9] = recovered_26_q;
  wire recovered_26_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_26_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_26_q == (D[8])))) recovered_26_q <= (D[8]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_12_ef18ece
  reg recovered_27_q = 1'b0;
  assign data0[10] = recovered_27_q;
  wire recovered_27_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_27_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_27_q == (D[9])))) recovered_27_q <= (D[9]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_13_6821a83
  reg recovered_28_q = 1'b0;
  assign data0[11] = recovered_28_q;
  wire recovered_28_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_28_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_28_q == (D[10])))) recovered_28_q <= (D[10]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_14_054801c
  reg recovered_29_q = 1'b0;
  assign data0[12] = recovered_29_q;
  wire recovered_29_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_29_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_29_q == (D[11])))) recovered_29_q <= (D[11]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_15_51d6f5b
  reg recovered_30_q = 1'b0;
  assign data0[13] = recovered_30_q;
  wire recovered_30_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_30_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_30_q == (D[12])))) recovered_30_q <= (D[12]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_16_4b25231
  reg recovered_31_q = 1'b0;
  assign data0[14] = recovered_31_q;
  wire recovered_31_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_31_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_31_q == (D[13])))) recovered_31_q <= (D[13]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_3_8d0fcb1
  reg recovered_32_q = 1'b0;
  assign data0[1] = recovered_32_q;
  wire recovered_32_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_32_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_32_q == 1'b0))) recovered_32_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_32_q == (D[0])))) recovered_32_q <= (D[0]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_4_fc2fdd8
  reg recovered_33_q = 1'b0;
  assign data0[2] = recovered_33_q;
  wire recovered_33_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_33_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_33_q == 1'b0))) recovered_33_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_33_q == (D[1])))) recovered_33_q <= (D[1]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_5_1a3a97b
  reg recovered_34_q = 1'b0;
  assign data0[3] = recovered_34_q;
  wire recovered_34_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_34_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_34_q == 1'b0))) recovered_34_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_34_q == (D[2])))) recovered_34_q <= (D[2]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_6_b4b4c98
  reg recovered_35_q = 1'b0;
  assign data0[4] = recovered_35_q;
  wire recovered_35_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_35_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_35_q == 1'b0))) recovered_35_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_35_q == (D[3])))) recovered_35_q <= (D[3]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_7_64ba03a
  reg recovered_36_q = 1'b0;
  assign data0[5] = recovered_36_q;
  wire recovered_36_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_36_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_36_q == 1'b0))) recovered_36_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_36_q == (D[4])))) recovered_36_q <= (D[4]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_8_d252b48
  reg recovered_37_q = 1'b0;
  assign data0[6] = recovered_37_q;
  wire recovered_37_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_37_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_37_q == 1'b0))) recovered_37_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_37_q == (D[5])))) recovered_37_q <= (D[5]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_9_b5165f1
  reg recovered_38_q = 1'b0;
  assign data0[7] = recovered_38_q;
  wire recovered_38_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_38_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_38_q == 1'b0))) recovered_38_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_38_q == (D[6])))) recovered_38_q <= (D[6]);
  end

  // Reconstructed LUT5: esc_wrap_burst_total_0__i_1_1781fe3
  assign esc_wrap_burst_total_0__i_1_n_0_2ea6d16 = ((s_axi_awlen[0]) ? (((s_axi_awlen[3]) ? (1'b0) : (((s_axi_awvalid) ? (((s_axi_awlen[2]) ? (s_axi_awlen[1]) : (~(s_axi_awlen[1])))) : (1'b0))))) : (1'b0));

  // Reconstructed LUT4: esc_wrap_burst_total_1__i_1_018fd52
  assign esc_wrap_burst_total_1__i_1_n_0_ef4004a = ((s_axi_awlen[3]) ? (1'b0) : (((s_axi_awlen[0]) ? (((s_axi_awvalid) ? (s_axi_awlen[1]) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_wrap_burst_total_2__i_1_10d2382
  assign esc_wrap_burst_total_2__i_1_n_0_351f795 = ((s_axi_awlen[2]) ? (((s_axi_awvalid) ? (((s_axi_awlen[3]) ? (((s_axi_awlen[0]) ? (s_axi_awlen[1]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_wrap_burst_total_reg_0_693cc30
  reg recovered_42_q = 1'b0;
  assign wrap_burst_total[0] = recovered_42_q;
  wire recovered_42_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_42_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_42_q == 1'b0))) recovered_42_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_42_q == (esc_wrap_burst_total_0__i_1_n_0_2ea6d16)))) recovered_42_q <= (esc_wrap_burst_total_0__i_1_n_0_2ea6d16);
  end

  // Reconstructed FDRE: esc_wrap_burst_total_reg_1_58ff126
  reg recovered_43_q = 1'b0;
  assign wrap_burst_total[1] = recovered_43_q;
  wire recovered_43_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_43_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_43_q == (esc_wrap_burst_total_1__i_1_n_0_ef4004a)))) recovered_43_q <= (esc_wrap_burst_total_1__i_1_n_0_ef4004a);
  end

  // Reconstructed FDRE: esc_wrap_burst_total_reg_2_ab654c1
  reg recovered_44_q = 1'b0;
  assign wrap_burst_total[2] = recovered_44_q;
  wire recovered_44_reset = ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06)) && ((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_44_reset || (((esc_save_init_bram_addr_ld_reg_3__0_d2dbc06) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((aw_active_re) || ((aw_active_re) === 1'bz) || (((aw_active_re) === 1'bx) && (recovered_44_q == (esc_wrap_burst_total_2__i_1_n_0_351f795)))) recovered_44_q <= (esc_wrap_burst_total_2__i_1_n_0_351f795);
  end

endmodule

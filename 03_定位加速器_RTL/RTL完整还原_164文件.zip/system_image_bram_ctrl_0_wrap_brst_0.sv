// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_image_bram_ctrl_0_wrap_brst_0
   (D,
    ar_active_reg,
    E,
    esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c ,
    esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 ,
    SR,
    esc_ADDR_SNG_PORT_bram_addr_int_16__i_8_0_f3c52ef ,
    axi_rd_burst,
    Q,
    s_axi_araddr,
    Arb2AR_Active,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_4_f52f690 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_5_38af973 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_7_6e268c9 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_9_d2d8198 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_10_3f275c0 ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_11__0_4716190 ,
    curr_fixed_burst_reg,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_11__1_abec655 ,
    curr_fixed_burst_reg_0,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b ,
    esc_ADDR_SNG_PORT_bram_addr_int_reg_16__1_a03d898 ,
    curr_wrap_burst_reg,
    esc_GEN_NO_RD_CMD_OPT_bram_en_int_reg_f4d1ea4 ,
    s_axi_rready,
    brst_zero,
    end_brst_rd,
    s_axi_aresetn,
    s_axi_arlen,
    ar_active_re,
    s_axi_aclk);
  output [14:0]D;
  output ar_active_reg;
  output [0:0]E;
  output esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c ;
  output esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 ;
  output [0:0]SR;
  input esc_ADDR_SNG_PORT_bram_addr_int_16__i_8_0_f3c52ef ;
  input axi_rd_burst;
  input [3:0]Q;
  input [14:0]s_axi_araddr;
  input Arb2AR_Active;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8 ;
  input [9:0]esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 ;
  input [13:0]esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_4_f52f690 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_5_38af973 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_7_6e268c9 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_9_d2d8198 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_10_3f275c0 ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_11__0_4716190 ;
  input curr_fixed_burst_reg;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_11__1_abec655 ;
  input curr_fixed_burst_reg_0;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b ;
  input esc_ADDR_SNG_PORT_bram_addr_int_reg_16__1_a03d898 ;
  input curr_wrap_burst_reg;
  input esc_GEN_NO_RD_CMD_OPT_bram_en_int_reg_f4d1ea4 ;
  input s_axi_rready;
  input brst_zero;
  input end_brst_rd;
  input s_axi_aresetn;
  input [3:0]s_axi_arlen;
  input ar_active_re;
  input s_axi_aclk;

  wire esc_ADDR_SNG_PORT_bram_addr_int_16__i_12_n_0_e823aaf ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_16__i_13_n_0_c33ff43 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_16__i_14_n_0_7bc7b42 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_16__i_15_n_0_75bcefb ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_16__i_8_0_f3c52ef ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_10_3f275c0 ;
  wire [9:0]esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_11__0_4716190 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_11__1_abec655 ;
  wire [13:0]esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_16__1_a03d898 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_4_f52f690 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_5_38af973 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_7_6e268c9 ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d ;
  wire esc_ADDR_SNG_PORT_bram_addr_int_reg_9_d2d8198 ;
  wire Arb2AR_Active;
  wire [14:0]D;
  wire [0:0]E;
  wire esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c ;
  wire esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 ;
  wire esc_GEN_NO_RD_CMD_OPT_bram_en_int_reg_f4d1ea4 ;
  wire [3:0]Q;
  wire [14:1]RdChnl_BRAM_Addr_Ld;
  wire [0:0]SR;
  wire ar_active_re;
  wire ar_active_reg;
  wire axi_rd_burst;
  wire brst_zero;
  wire curr_fixed_burst_reg;
  wire curr_fixed_burst_reg_0;
  wire curr_wrap_burst_reg;
  wire end_brst_rd;
  wire s_axi_aclk;
  wire [14:0]s_axi_araddr;
  wire s_axi_aresetn;
  wire [3:0]s_axi_arlen;
  wire s_axi_rready;
  wire esc_save_init_bram_addr_ld_3__i_2_n_0_bf290d8 ;
  wire esc_save_init_bram_addr_ld_4__i_2_n_0_6cd05a1 ;
  wire esc_save_init_bram_addr_ld_5__i_2_n_0_fcf630a ;
  wire esc_save_init_bram_addr_ld_reg_n_0__10_478a3b9 ;
  wire esc_save_init_bram_addr_ld_reg_n_0__11_1fd82d7 ;
  wire esc_save_init_bram_addr_ld_reg_n_0__12_9dc6cc5 ;
  wire esc_save_init_bram_addr_ld_reg_n_0__13_30c9db9 ;
  wire esc_save_init_bram_addr_ld_reg_n_0__14_3d0160e ;
  wire esc_save_init_bram_addr_ld_reg_n_0__15_2b944df ;
  wire esc_save_init_bram_addr_ld_reg_n_0__16_c258704 ;
  wire esc_save_init_bram_addr_ld_reg_n_0__3_86f22ef ;
  wire esc_save_init_bram_addr_ld_reg_n_0__4_431a28f ;
  wire esc_save_init_bram_addr_ld_reg_n_0__5_0deaa4e ;
  wire esc_save_init_bram_addr_ld_reg_n_0__6_2ec8c53 ;
  wire esc_save_init_bram_addr_ld_reg_n_0__7_f1f022b ;
  wire esc_save_init_bram_addr_ld_reg_n_0__8_8f3b4ea ;
  wire esc_save_init_bram_addr_ld_reg_n_0__9_40065bf ;
  wire esc_wrap_burst_total_0__i_1__0_n_0_6e58155 ;
  wire esc_wrap_burst_total_1__i_1__0_n_0_1aec749 ;
  wire esc_wrap_burst_total_2__i_1__0_n_0_e596465 ;
  wire esc_wrap_burst_total_reg_n_0__0_0f50db8 ;
  wire esc_wrap_burst_total_reg_n_0__1_11a3b99 ;
  wire esc_wrap_burst_total_reg_n_0__2_751422e ;

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_10__i_1_a36109f
  assign D[8] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_10_3f275c0) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [8]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [7]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[8]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[8]) : (1'b0))))) : (1'b0))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [7]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[8]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[8]) : (1'b0))))) : (1'b1))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [8]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [7]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[8]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[8]) : (1'b0))))) : (1'b1))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [7]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[8]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[8]) : (1'b0))))) : (1'b0))))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_11__i_1_77290b0
  assign E = ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (((curr_fixed_burst_reg_0) ? (((Arb2AR_Active) ? (ar_active_reg) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11__1_abec655) ? (((curr_fixed_burst_reg) ? (ar_active_reg) : (1'b1))) : (ar_active_reg))))) : (((Arb2AR_Active) ? (1'b1) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11__1_abec655) ? (((curr_fixed_burst_reg) ? (ar_active_reg) : (1'b1))) : (ar_active_reg))))))) : (((Arb2AR_Active) ? (ar_active_reg) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11__1_abec655) ? (((curr_fixed_burst_reg) ? (ar_active_reg) : (1'b1))) : (ar_active_reg))))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_11__i_2_5763a3a
  assign D[9] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_11__0_4716190) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [9]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [8]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[9]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[9]) : (1'b0))))) : (1'b0))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [8]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[9]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[9]) : (1'b0))))) : (1'b1))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [9]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [8]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[9]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[9]) : (1'b0))))) : (1'b1))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [8]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[9]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[9]) : (1'b0))))) : (1'b0))))));

  // Reconstructed LUT5: esc_ADDR_SNG_PORT_bram_addr_int_12__i_1_2f1f2c7
  assign D[10] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [9]) ? (((Arb2AR_Active) ? (((esc_save_init_bram_addr_ld_reg_n_0__12_9dc6cc5) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[10]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[10]) : (1'b0))))) : (1'b1))) : (((Arb2AR_Active) ? (((esc_save_init_bram_addr_ld_reg_n_0__12_9dc6cc5) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[10]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[10]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT5: esc_ADDR_SNG_PORT_bram_addr_int_13__i_1_00b4693
  assign D[11] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [10]) ? (((Arb2AR_Active) ? (((esc_save_init_bram_addr_ld_reg_n_0__13_30c9db9) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[11]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[11]) : (1'b0))))) : (1'b1))) : (((Arb2AR_Active) ? (((esc_save_init_bram_addr_ld_reg_n_0__13_30c9db9) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[11]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[11]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT5: esc_ADDR_SNG_PORT_bram_addr_int_14__i_1_0f41410
  assign D[12] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [11]) ? (((Arb2AR_Active) ? (((esc_save_init_bram_addr_ld_reg_n_0__14_3d0160e) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[12]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[12]) : (1'b0))))) : (1'b1))) : (((Arb2AR_Active) ? (((esc_save_init_bram_addr_ld_reg_n_0__14_3d0160e) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[12]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[12]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT5: esc_ADDR_SNG_PORT_bram_addr_int_15__i_1_bb8b637
  assign D[13] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [12]) ? (((Arb2AR_Active) ? (((esc_save_init_bram_addr_ld_reg_n_0__15_2b944df) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[13]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[13]) : (1'b0))))) : (1'b1))) : (((Arb2AR_Active) ? (((esc_save_init_bram_addr_ld_reg_n_0__15_2b944df) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[13]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[13]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_16__i_12_db9a844
  assign esc_ADDR_SNG_PORT_bram_addr_int_16__i_12_n_0_e823aaf = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [2]) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [1]) ? (((esc_wrap_burst_total_reg_n_0__1_11a3b99) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [0]) ? (~(esc_wrap_burst_total_reg_n_0__2_751422e)) : (1'b0))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [0]) ? (((esc_wrap_burst_total_reg_n_0__0_0f50db8) ? (~(esc_wrap_burst_total_reg_n_0__2_751422e)) : (1'b0))) : (1'b0))))) : (((esc_wrap_burst_total_reg_n_0__1_11a3b99) ? (1'b0) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [0]) ? (((esc_wrap_burst_total_reg_n_0__0_0f50db8) ? (~(esc_wrap_burst_total_reg_n_0__2_751422e)) : (1'b0))) : (1'b0))))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [1]) ? (((esc_wrap_burst_total_reg_n_0__1_11a3b99) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [0]) ? (((esc_wrap_burst_total_reg_n_0__0_0f50db8) ? (1'b0) : (~(esc_wrap_burst_total_reg_n_0__2_751422e)))) : (1'b0))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [0]) ? (((esc_wrap_burst_total_reg_n_0__0_0f50db8) ? (~(esc_wrap_burst_total_reg_n_0__2_751422e)) : (1'b0))) : (1'b0))))) : (((esc_wrap_burst_total_reg_n_0__1_11a3b99) ? (1'b0) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [0]) ? (((esc_wrap_burst_total_reg_n_0__0_0f50db8) ? (~(esc_wrap_burst_total_reg_n_0__2_751422e)) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT4: esc_ADDR_SNG_PORT_bram_addr_int_16__i_13_31e405f
  assign esc_ADDR_SNG_PORT_bram_addr_int_16__i_13_n_0_c33ff43 = ((Q[0]) ? (((Q[1]) ? (1'b0) : (((axi_rd_burst) ? (1'b1) : (esc_ADDR_SNG_PORT_bram_addr_int_16__i_8_0_f3c52ef))))) : (1'b1));

  // Reconstructed LUT3: esc_ADDR_SNG_PORT_bram_addr_int_16__i_14_61d639b
  assign esc_ADDR_SNG_PORT_bram_addr_int_16__i_14_n_0_7bc7b42 = ((Q[0]) ? (((Q[2]) ? (1'b1) : (Q[3]))) : (Q[3]));

  // Reconstructed LUT4: esc_ADDR_SNG_PORT_bram_addr_int_16__i_15_77eb7ef
  assign esc_ADDR_SNG_PORT_bram_addr_int_16__i_15_n_0_75bcefb = ((esc_ADDR_SNG_PORT_bram_addr_int_16__i_8_0_f3c52ef) ? (Q[0]) : (((Q[1]) ? (((Q[2]) ? (Q[0]) : (1'b1))) : (Q[0]))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_16__i_2_da6dcf2
  assign ar_active_reg = ((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (((curr_wrap_burst_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (1'b1) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16__1_a03d898) ? (~(esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b)) : (((Arb2AR_Active) ? (1'b1) : (~(esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b)))))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16__1_a03d898) ? (~(esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b)) : (((Arb2AR_Active) ? (1'b1) : (~(esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b)))))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16__1_a03d898) ? (~(esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b)) : (((Arb2AR_Active) ? (1'b1) : (~(esc_ADDR_SNG_PORT_bram_addr_int_reg_16__0_eed9a0b)))))));

  // Reconstructed LUT5: esc_ADDR_SNG_PORT_bram_addr_int_16__i_3_6e59a8e
  assign D[14] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [13]) ? (((Arb2AR_Active) ? (((esc_save_init_bram_addr_ld_reg_n_0__16_c258704) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[14]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[14]) : (1'b0))))) : (1'b1))) : (((Arb2AR_Active) ? (((esc_save_init_bram_addr_ld_reg_n_0__16_c258704) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[14]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[14]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT5: esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_9d2b233
  assign esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693 = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d) ? (esc_ADDR_SNG_PORT_bram_addr_int_16__i_12_n_0_e823aaf) : (((esc_wrap_burst_total_reg_n_0__0_0f50db8) ? (esc_ADDR_SNG_PORT_bram_addr_int_16__i_12_n_0_e823aaf) : (((esc_wrap_burst_total_reg_n_0__2_751422e) ? (((esc_wrap_burst_total_reg_n_0__1_11a3b99) ? (esc_ADDR_SNG_PORT_bram_addr_int_16__i_12_n_0_e823aaf) : (1'b1))) : (esc_ADDR_SNG_PORT_bram_addr_int_16__i_12_n_0_e823aaf))))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_16__i_8_1d80e5d
  assign esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c = ((esc_ADDR_SNG_PORT_bram_addr_int_16__i_15_n_0_75bcefb) ? (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_14_n_0_7bc7b42) ? (1'b0) : (esc_ADDR_SNG_PORT_bram_addr_int_16__i_13_n_0_c33ff43))) : (((Q[1]) ? (~(esc_ADDR_SNG_PORT_bram_addr_int_16__i_14_n_0_7bc7b42)) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_14_n_0_7bc7b42) ? (1'b0) : (esc_ADDR_SNG_PORT_bram_addr_int_16__i_13_n_0_c33ff43))))))) : (((esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159) ? (1'b0) : (((Q[2]) ? (((Q[1]) ? (1'b0) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_14_n_0_7bc7b42) ? (1'b0) : (esc_ADDR_SNG_PORT_bram_addr_int_16__i_13_n_0_c33ff43))))) : (1'b0))))));

  // Reconstructed LUT5: esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_41364be
  assign esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e = ((esc_ADDR_SNG_PORT_bram_addr_int_16__i_12_n_0_e823aaf) ? (((curr_wrap_burst_reg) ? (~(esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c)) : (1'b1))) : (((esc_save_init_bram_addr_ld_5__i_2_n_0_fcf630a) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d) ? (1'b1) : (((curr_wrap_burst_reg) ? (~(esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c)) : (1'b1))))) : (1'b1))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_2__i_1_3fc951e
  assign D[0] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [0]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8) ? (((Arb2AR_Active) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[0]) : (1'b0))) : (1'b1))) : (((Arb2AR_Active) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[0]) : (1'b0))) : (1'b0))))) : (1'b0))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_2_020cde8) ? (((Arb2AR_Active) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[0]) : (1'b0))) : (1'b1))) : (((Arb2AR_Active) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[0]) : (1'b0))) : (1'b0))))) : (1'b1))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_3__i_1_376490d
  assign D[1] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [0]) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [1]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [0]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[1]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[1]) : (1'b0))))) : (1'b0))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [0]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[1]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[1]) : (1'b0))))) : (1'b1))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [1]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [0]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[1]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[1]) : (1'b0))))) : (1'b1))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [0]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[1]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[1]) : (1'b0))))) : (1'b0))))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_4__i_1_732a924
  assign D[2] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_4_f52f690) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [2]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [1]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[2]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[2]) : (1'b0))))) : (1'b0))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [1]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[2]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[2]) : (1'b0))))) : (1'b1))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [2]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [1]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[2]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[2]) : (1'b0))))) : (1'b1))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [1]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[2]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[2]) : (1'b0))))) : (1'b0))))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_5__i_1_a0bc139
  assign D[3] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_5_38af973) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [3]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [2]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[3]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[3]) : (1'b0))))) : (1'b1))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [2]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[3]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[3]) : (1'b0))))) : (1'b0))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [3]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [2]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[3]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[3]) : (1'b0))))) : (1'b0))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [2]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[3]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[3]) : (1'b0))))) : (1'b1))))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_6__i_1_d7bcb1c
  assign D[4] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_6_b61751d) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [4]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [3]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[4]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[4]) : (1'b0))))) : (1'b1))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [3]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[4]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[4]) : (1'b0))))) : (1'b0))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [4]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [3]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[4]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[4]) : (1'b0))))) : (1'b0))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [3]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[4]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[4]) : (1'b0))))) : (1'b1))))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_7__i_1_c763958
  assign D[5] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_7_6e268c9) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [5]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [4]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[5]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[5]) : (1'b0))))) : (1'b1))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [4]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[5]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[5]) : (1'b0))))) : (1'b0))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [5]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [4]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[5]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[5]) : (1'b0))))) : (1'b0))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [4]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[5]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[5]) : (1'b0))))) : (1'b1))))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_8__i_1_acd68db
  assign D[6] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [6]) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [5]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[6]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[6]) : (1'b0))))) : (1'b1))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [5]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[6]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[6]) : (1'b0))))) : (1'b0))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_8_d36c75d) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [5]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[6]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[6]) : (1'b0))))) : (1'b0))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [5]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[6]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[6]) : (1'b0))))) : (1'b1))))));

  // Reconstructed LUT6: esc_ADDR_SNG_PORT_bram_addr_int_9__i_1_f1df7c3
  assign D[7] = ((esc_ADDR_SNG_PORT_bram_addr_int_reg_9_d2d8198) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [7]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [6]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[7]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[7]) : (1'b0))))) : (1'b0))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [6]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[7]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[7]) : (1'b0))))) : (1'b1))))) : (((esc_ADDR_SNG_PORT_bram_addr_int_reg_11_7e78615 [7]) ? (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [6]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[7]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[7]) : (1'b0))))) : (1'b1))) : (((ar_active_reg) ? (((esc_ADDR_SNG_PORT_bram_addr_int_reg_16_9108ce8 [6]) ? (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[7]) : (1'b1))) : (((Arb2AR_Active) ? (RdChnl_BRAM_Addr_Ld[7]) : (1'b0))))) : (1'b0))))));

  // Reconstructed LUT4: esc_GEN_NO_RD_CMD_OPT_bram_en_int_i_3_6c28667
  assign esc_GEN_NO_RD_CMD_OPT_axi_rvalid_int_reg_7921159 = ((end_brst_rd) ? (1'b1) : (((brst_zero) ? (1'b1) : (((s_axi_rready) ? (~(esc_GEN_NO_RD_CMD_OPT_bram_en_int_reg_f4d1ea4)) : (1'b1))))));

  // Reconstructed LUT1: bram_rst_a_INST_0
  assign SR = ~(s_axi_aresetn);

  // Reconstructed LUT5: esc_save_init_bram_addr_ld_10__i_1__0_d8353d2
  assign RdChnl_BRAM_Addr_Ld[8] = ((esc_save_init_bram_addr_ld_reg_n_0__10_478a3b9) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b1) : (s_axi_araddr[8]))) : (s_axi_araddr[8]))) : (s_axi_araddr[8]))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b0) : (s_axi_araddr[8]))) : (s_axi_araddr[8]))) : (s_axi_araddr[8]))));

  // Reconstructed LUT5: esc_save_init_bram_addr_ld_11__i_1__0_31653f5
  assign RdChnl_BRAM_Addr_Ld[9] = ((esc_save_init_bram_addr_ld_reg_n_0__11_1fd82d7) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b1) : (s_axi_araddr[9]))) : (s_axi_araddr[9]))) : (s_axi_araddr[9]))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b0) : (s_axi_araddr[9]))) : (s_axi_araddr[9]))) : (s_axi_araddr[9]))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_12__i_1__0_860ed43
  assign RdChnl_BRAM_Addr_Ld[10] = ((esc_save_init_bram_addr_ld_reg_n_0__12_9dc6cc5) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[10]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[10]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_13__i_1__0_0e31305
  assign RdChnl_BRAM_Addr_Ld[11] = ((esc_save_init_bram_addr_ld_reg_n_0__13_30c9db9) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[11]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[11]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_14__i_1__0_c9b0f65
  assign RdChnl_BRAM_Addr_Ld[12] = ((esc_save_init_bram_addr_ld_reg_n_0__14_3d0160e) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[12]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[12]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_15__i_1__0_7be87c4
  assign RdChnl_BRAM_Addr_Ld[13] = ((esc_save_init_bram_addr_ld_reg_n_0__15_2b944df) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[13]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[13]) : (1'b0))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_16__i_2__0_66ef915
  assign RdChnl_BRAM_Addr_Ld[14] = ((esc_save_init_bram_addr_ld_reg_n_0__16_c258704) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[14]) : (1'b1))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_9_n_0_1d9b60e) ? (s_axi_araddr[14]) : (1'b0))));

  // Reconstructed LUT5: esc_save_init_bram_addr_ld_3__i_1__0_b70abca
  assign RdChnl_BRAM_Addr_Ld[1] = ((esc_save_init_bram_addr_ld_3__i_2_n_0_bf290d8) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b1) : (s_axi_araddr[1]))) : (s_axi_araddr[1]))) : (s_axi_araddr[1]))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b0) : (s_axi_araddr[1]))) : (s_axi_araddr[1]))) : (s_axi_araddr[1]))));

  // Reconstructed LUT4: esc_save_init_bram_addr_ld_3__i_2_8210989
  assign esc_save_init_bram_addr_ld_3__i_2_n_0_bf290d8 = ((esc_wrap_burst_total_reg_n_0__1_11a3b99) ? (((esc_wrap_burst_total_reg_n_0__2_751422e) ? (esc_save_init_bram_addr_ld_reg_n_0__3_86f22ef) : (1'b0))) : (((esc_wrap_burst_total_reg_n_0__2_751422e) ? (((esc_wrap_burst_total_reg_n_0__0_0f50db8) ? (esc_save_init_bram_addr_ld_reg_n_0__3_86f22ef) : (1'b0))) : (esc_save_init_bram_addr_ld_reg_n_0__3_86f22ef))));

  // Reconstructed LUT5: esc_save_init_bram_addr_ld_4__i_1__0_23c000b
  assign RdChnl_BRAM_Addr_Ld[2] = ((esc_save_init_bram_addr_ld_4__i_2_n_0_6cd05a1) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b1) : (s_axi_araddr[2]))) : (s_axi_araddr[2]))) : (s_axi_araddr[2]))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b0) : (s_axi_araddr[2]))) : (s_axi_araddr[2]))) : (s_axi_araddr[2]))));

  // Reconstructed LUT4: esc_save_init_bram_addr_ld_4__i_2_71ca2ad
  assign esc_save_init_bram_addr_ld_4__i_2_n_0_6cd05a1 = ((esc_wrap_burst_total_reg_n_0__2_751422e) ? (((esc_wrap_burst_total_reg_n_0__1_11a3b99) ? (esc_save_init_bram_addr_ld_reg_n_0__4_431a28f) : (((esc_wrap_burst_total_reg_n_0__0_0f50db8) ? (esc_save_init_bram_addr_ld_reg_n_0__4_431a28f) : (1'b0))))) : (((esc_wrap_burst_total_reg_n_0__1_11a3b99) ? (((esc_wrap_burst_total_reg_n_0__0_0f50db8) ? (1'b0) : (esc_save_init_bram_addr_ld_reg_n_0__4_431a28f))) : (esc_save_init_bram_addr_ld_reg_n_0__4_431a28f))));

  // Reconstructed LUT6: esc_save_init_bram_addr_ld_5__i_1__0_b12adc6
  assign RdChnl_BRAM_Addr_Ld[3] = ((esc_save_init_bram_addr_ld_5__i_2_n_0_fcf630a) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b0) : (s_axi_araddr[3]))) : (s_axi_araddr[3]))) : (s_axi_araddr[3]))) : (((esc_save_init_bram_addr_ld_reg_n_0__5_0deaa4e) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b1) : (s_axi_araddr[3]))) : (s_axi_araddr[3]))) : (s_axi_araddr[3]))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b0) : (s_axi_araddr[3]))) : (s_axi_araddr[3]))) : (s_axi_araddr[3]))))));

  // Reconstructed LUT3: esc_save_init_bram_addr_ld_5__i_2_5298696
  assign esc_save_init_bram_addr_ld_5__i_2_n_0_fcf630a = ((esc_wrap_burst_total_reg_n_0__0_0f50db8) ? (1'b0) : (((esc_wrap_burst_total_reg_n_0__2_751422e) ? (~(esc_wrap_burst_total_reg_n_0__1_11a3b99)) : (1'b0))));

  // Reconstructed LUT5: esc_save_init_bram_addr_ld_6__i_1__0_d9ec6d0
  assign RdChnl_BRAM_Addr_Ld[4] = ((esc_save_init_bram_addr_ld_reg_n_0__6_2ec8c53) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b1) : (s_axi_araddr[4]))) : (s_axi_araddr[4]))) : (s_axi_araddr[4]))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b0) : (s_axi_araddr[4]))) : (s_axi_araddr[4]))) : (s_axi_araddr[4]))));

  // Reconstructed LUT5: esc_save_init_bram_addr_ld_7__i_1__0_3fe966f
  assign RdChnl_BRAM_Addr_Ld[5] = ((esc_save_init_bram_addr_ld_reg_n_0__7_f1f022b) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b1) : (s_axi_araddr[5]))) : (s_axi_araddr[5]))) : (s_axi_araddr[5]))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b0) : (s_axi_araddr[5]))) : (s_axi_araddr[5]))) : (s_axi_araddr[5]))));

  // Reconstructed LUT5: esc_save_init_bram_addr_ld_8__i_1__0_08a49b3
  assign RdChnl_BRAM_Addr_Ld[6] = ((esc_save_init_bram_addr_ld_reg_n_0__8_8f3b4ea) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b1) : (s_axi_araddr[6]))) : (s_axi_araddr[6]))) : (s_axi_araddr[6]))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b0) : (s_axi_araddr[6]))) : (s_axi_araddr[6]))) : (s_axi_araddr[6]))));

  // Reconstructed LUT5: esc_save_init_bram_addr_ld_9__i_1__0_febb4b3
  assign RdChnl_BRAM_Addr_Ld[7] = ((esc_save_init_bram_addr_ld_reg_n_0__9_40065bf) ? (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b1) : (s_axi_araddr[7]))) : (s_axi_araddr[7]))) : (s_axi_araddr[7]))) : (((esc_ADDR_SNG_PORT_bram_addr_int_16__i_7_n_0_0755693) ? (((curr_wrap_burst_reg) ? (((esc_FSM_sequential_GEN_NO_RD_CMD_OPT_rd_data_sm_cs_reg_1_ee8570c) ? (1'b0) : (s_axi_araddr[7]))) : (s_axi_araddr[7]))) : (s_axi_araddr[7]))));

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_10_f053177
  reg recovered_44_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__10_478a3b9 = recovered_44_q;
  wire recovered_44_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_44_reset || (((SR) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_44_q == (RdChnl_BRAM_Addr_Ld[8])))) recovered_44_q <= (RdChnl_BRAM_Addr_Ld[8]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_11_debbd83
  reg recovered_45_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__11_1fd82d7 = recovered_45_q;
  wire recovered_45_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_45_reset || (((SR) === 1'bx) && (recovered_45_q == 1'b0))) recovered_45_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_45_q == (RdChnl_BRAM_Addr_Ld[9])))) recovered_45_q <= (RdChnl_BRAM_Addr_Ld[9]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_12_ef18ece
  reg recovered_46_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__12_9dc6cc5 = recovered_46_q;
  wire recovered_46_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_46_reset || (((SR) === 1'bx) && (recovered_46_q == 1'b0))) recovered_46_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_46_q == (RdChnl_BRAM_Addr_Ld[10])))) recovered_46_q <= (RdChnl_BRAM_Addr_Ld[10]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_13_6821a83
  reg recovered_47_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__13_30c9db9 = recovered_47_q;
  wire recovered_47_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_47_reset || (((SR) === 1'bx) && (recovered_47_q == 1'b0))) recovered_47_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_47_q == (RdChnl_BRAM_Addr_Ld[11])))) recovered_47_q <= (RdChnl_BRAM_Addr_Ld[11]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_14_054801c
  reg recovered_48_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__14_3d0160e = recovered_48_q;
  wire recovered_48_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_48_reset || (((SR) === 1'bx) && (recovered_48_q == 1'b0))) recovered_48_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_48_q == (RdChnl_BRAM_Addr_Ld[12])))) recovered_48_q <= (RdChnl_BRAM_Addr_Ld[12]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_15_51d6f5b
  reg recovered_49_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__15_2b944df = recovered_49_q;
  wire recovered_49_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_49_reset || (((SR) === 1'bx) && (recovered_49_q == 1'b0))) recovered_49_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_49_q == (RdChnl_BRAM_Addr_Ld[13])))) recovered_49_q <= (RdChnl_BRAM_Addr_Ld[13]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_16_4b25231
  reg recovered_50_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__16_c258704 = recovered_50_q;
  wire recovered_50_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_50_reset || (((SR) === 1'bx) && (recovered_50_q == 1'b0))) recovered_50_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_50_q == (RdChnl_BRAM_Addr_Ld[14])))) recovered_50_q <= (RdChnl_BRAM_Addr_Ld[14]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_3_8d0fcb1
  reg recovered_51_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__3_86f22ef = recovered_51_q;
  wire recovered_51_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_51_reset || (((SR) === 1'bx) && (recovered_51_q == 1'b0))) recovered_51_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_51_q == (RdChnl_BRAM_Addr_Ld[1])))) recovered_51_q <= (RdChnl_BRAM_Addr_Ld[1]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_4_fc2fdd8
  reg recovered_52_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__4_431a28f = recovered_52_q;
  wire recovered_52_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_52_reset || (((SR) === 1'bx) && (recovered_52_q == 1'b0))) recovered_52_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_52_q == (RdChnl_BRAM_Addr_Ld[2])))) recovered_52_q <= (RdChnl_BRAM_Addr_Ld[2]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_5_1a3a97b
  reg recovered_53_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__5_0deaa4e = recovered_53_q;
  wire recovered_53_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_53_reset || (((SR) === 1'bx) && (recovered_53_q == 1'b0))) recovered_53_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_53_q == (RdChnl_BRAM_Addr_Ld[3])))) recovered_53_q <= (RdChnl_BRAM_Addr_Ld[3]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_6_b4b4c98
  reg recovered_54_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__6_2ec8c53 = recovered_54_q;
  wire recovered_54_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_54_reset || (((SR) === 1'bx) && (recovered_54_q == 1'b0))) recovered_54_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_54_q == (RdChnl_BRAM_Addr_Ld[4])))) recovered_54_q <= (RdChnl_BRAM_Addr_Ld[4]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_7_64ba03a
  reg recovered_55_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__7_f1f022b = recovered_55_q;
  wire recovered_55_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_55_reset || (((SR) === 1'bx) && (recovered_55_q == 1'b0))) recovered_55_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_55_q == (RdChnl_BRAM_Addr_Ld[5])))) recovered_55_q <= (RdChnl_BRAM_Addr_Ld[5]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_8_d252b48
  reg recovered_56_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__8_8f3b4ea = recovered_56_q;
  wire recovered_56_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_56_reset || (((SR) === 1'bx) && (recovered_56_q == 1'b0))) recovered_56_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_56_q == (RdChnl_BRAM_Addr_Ld[6])))) recovered_56_q <= (RdChnl_BRAM_Addr_Ld[6]);
  end

  // Reconstructed FDRE: esc_save_init_bram_addr_ld_reg_9_b5165f1
  reg recovered_57_q = 1'b0;
  assign esc_save_init_bram_addr_ld_reg_n_0__9_40065bf = recovered_57_q;
  wire recovered_57_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_57_reset || (((SR) === 1'bx) && (recovered_57_q == 1'b0))) recovered_57_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_57_q == (RdChnl_BRAM_Addr_Ld[7])))) recovered_57_q <= (RdChnl_BRAM_Addr_Ld[7]);
  end

  // Reconstructed LUT4: esc_wrap_burst_total_0__i_1__0_8bb03c0
  assign esc_wrap_burst_total_0__i_1__0_n_0_6e58155 = ((s_axi_arlen[1]) ? (((s_axi_arlen[2]) ? (((s_axi_arlen[0]) ? (~(s_axi_arlen[3])) : (1'b0))) : (1'b0))) : (((s_axi_arlen[2]) ? (1'b0) : (((s_axi_arlen[0]) ? (~(s_axi_arlen[3])) : (1'b0))))));

  // Reconstructed LUT3: esc_wrap_burst_total_1__i_1__0_63e8190
  assign esc_wrap_burst_total_1__i_1__0_n_0_1aec749 = ((s_axi_arlen[0]) ? (((s_axi_arlen[3]) ? (1'b0) : (s_axi_arlen[1]))) : (1'b0));

  // Reconstructed LUT4: esc_wrap_burst_total_2__i_1__0_b3e6639
  assign esc_wrap_burst_total_2__i_1__0_n_0_e596465 = ((s_axi_arlen[0]) ? (((s_axi_arlen[3]) ? (((s_axi_arlen[1]) ? (s_axi_arlen[2]) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_wrap_burst_total_reg_0_693cc30
  reg recovered_61_q = 1'b0;
  assign esc_wrap_burst_total_reg_n_0__0_0f50db8 = recovered_61_q;
  wire recovered_61_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_61_reset || (((SR) === 1'bx) && (recovered_61_q == 1'b0))) recovered_61_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_61_q == (esc_wrap_burst_total_0__i_1__0_n_0_6e58155)))) recovered_61_q <= (esc_wrap_burst_total_0__i_1__0_n_0_6e58155);
  end

  // Reconstructed FDRE: esc_wrap_burst_total_reg_1_58ff126
  reg recovered_62_q = 1'b0;
  assign esc_wrap_burst_total_reg_n_0__1_11a3b99 = recovered_62_q;
  wire recovered_62_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_62_reset || (((SR) === 1'bx) && (recovered_62_q == 1'b0))) recovered_62_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_62_q == (esc_wrap_burst_total_1__i_1__0_n_0_1aec749)))) recovered_62_q <= (esc_wrap_burst_total_1__i_1__0_n_0_1aec749);
  end

  // Reconstructed FDRE: esc_wrap_burst_total_reg_2_ab654c1
  reg recovered_63_q = 1'b0;
  assign esc_wrap_burst_total_reg_n_0__2_751422e = recovered_63_q;
  wire recovered_63_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge s_axi_aclk) begin
    if (recovered_63_reset || (((SR) === 1'bx) && (recovered_63_q == 1'b0))) recovered_63_q <= 1'b0;
    else if ((ar_active_re) || ((ar_active_re) === 1'bz) || (((ar_active_re) === 1'bx) && (recovered_63_q == (esc_wrap_burst_total_2__i_1__0_n_0_e596465)))) recovered_63_q <= (esc_wrap_burst_total_2__i_1__0_n_0_e596465);
  end

endmodule

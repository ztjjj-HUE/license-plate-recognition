// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_reset_0_0
   (slowest_sync_clk,
    ext_reset_in,
    aux_reset_in,
    mb_debug_sys_rst,
    dcm_locked,
    mb_reset,
    bus_struct_reset,
    peripheral_reset,
    interconnect_aresetn,
    peripheral_aresetn);
    input slowest_sync_clk;
    input ext_reset_in;
    input aux_reset_in;
    input mb_debug_sys_rst;
  input dcm_locked;
    output mb_reset;
    output [0:0]bus_struct_reset;
    output [0:0]peripheral_reset;
    output [0:0]interconnect_aresetn;
    output [0:0]peripheral_aresetn;

  wire ext_reset_in;
  wire [0:0]interconnect_aresetn;
  wire [0:0]peripheral_aresetn;
  wire slowest_sync_clk;

  system_reset_0_0_proc_sys_reset U0
       (.ext_reset_in(ext_reset_in),
        .interconnect_aresetn(interconnect_aresetn),
        .peripheral_aresetn(peripheral_aresetn),
        .slowest_sync_clk(slowest_sync_clk));
endmodule

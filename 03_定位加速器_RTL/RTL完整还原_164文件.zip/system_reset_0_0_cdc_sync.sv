// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_reset_0_0_cdc_sync
   (lpf_asr_reg,
    scndry_out,
    lpf_asr,
    p_1_in,
    p_2_in,
    asr_lpf,
    aux_reset_in,
    slowest_sync_clk);
  output lpf_asr_reg;
  output scndry_out;
  input lpf_asr;
  input p_1_in;
  input p_2_in;
  input [0:0]asr_lpf;
  input aux_reset_in;
  input slowest_sync_clk;

  wire esc_const0_a0cf646 ;
  wire VCC_1;
  wire asr_d1;
  wire [0:0]asr_lpf;
  wire lpf_asr;
  wire lpf_asr_reg;
  wire p_1_in;
  wire p_2_in;
  wire s_level_out_d1_cdc_to;
  wire s_level_out_d2;
  wire s_level_out_d3;
  wire scndry_out;
  wire slowest_sync_clk;

  // Reconstructed FDRE: esc_GENERATE_LEVEL_P_S_CDC_SINGLE_BIT_CROSS_PLEVEL_IN2SCNDRY_IN_cdc_to_27f9b30
  reg recovered_1_q = 1'b0;
  assign s_level_out_d1_cdc_to = recovered_1_q;
  wire recovered_1_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_1_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_1_q == 1'b0))) recovered_1_q <= 1'b0;
    else if ((VCC_1) || ((VCC_1) === 1'bz) || (((VCC_1) === 1'bx) && (recovered_1_q == (asr_d1)))) recovered_1_q <= (asr_d1);
  end

  // Reconstructed FDRE: esc_GENERATE_LEVEL_P_S_CDC_SINGLE_BIT_CROSS_PLEVEL_IN2SCNDRY_s_level_out_d2_b13981d
  reg recovered_2_q = 1'b0;
  assign s_level_out_d2 = recovered_2_q;
  wire recovered_2_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_2_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_2_q == 1'b0))) recovered_2_q <= 1'b0;
    else if ((VCC_1) || ((VCC_1) === 1'bz) || (((VCC_1) === 1'bx) && (recovered_2_q == (s_level_out_d1_cdc_to)))) recovered_2_q <= (s_level_out_d1_cdc_to);
  end

  // Reconstructed FDRE: esc_GENERATE_LEVEL_P_S_CDC_SINGLE_BIT_CROSS_PLEVEL_IN2SCNDRY_s_level_out_d3_45a1fba
  reg recovered_3_q = 1'b0;
  assign s_level_out_d3 = recovered_3_q;
  wire recovered_3_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_3_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_3_q == 1'b0))) recovered_3_q <= 1'b0;
    else if ((VCC_1) || ((VCC_1) === 1'bz) || (((VCC_1) === 1'bx) && (recovered_3_q == (s_level_out_d2)))) recovered_3_q <= (s_level_out_d2);
  end

  // Reconstructed FDRE: esc_GENERATE_LEVEL_P_S_CDC_SINGLE_BIT_CROSS_PLEVEL_IN2SCNDRY_s_level_out_d4_2eae253
  reg recovered_4_q = 1'b0;
  assign scndry_out = recovered_4_q;
  wire recovered_4_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_4_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((VCC_1) || ((VCC_1) === 1'bz) || (((VCC_1) === 1'bx) && (recovered_4_q == (s_level_out_d3)))) recovered_4_q <= (s_level_out_d3);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed GND: GND_1
  assign asr_d1 = 1'b0;

  // Reconstructed VCC: VCC
  assign VCC_1 = 1'b1;

  // Reconstructed LUT5: lpf_asr_i_1
  assign lpf_asr_reg = ((asr_lpf) ? (((scndry_out) ? (((p_2_in) ? (((p_1_in) ? (1'b1) : (lpf_asr))) : (lpf_asr))) : (lpf_asr))) : (((scndry_out) ? (lpf_asr) : (((p_2_in) ? (lpf_asr) : (((p_1_in) ? (lpf_asr) : (1'b0))))))));

endmodule

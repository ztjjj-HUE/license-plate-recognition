// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_reset_0_0_cdc_sync_0
   (lpf_exr_reg,
    scndry_out,
    lpf_exr,
    p_1_in4_in,
    p_2_in3_in,
    exr_lpf,
    mb_debug_sys_rst,
    ext_reset_in,
    slowest_sync_clk);
  output lpf_exr_reg;
  output scndry_out;
  input lpf_exr;
  input p_1_in4_in;
  input p_2_in3_in;
  input [0:0]exr_lpf;
  input mb_debug_sys_rst;
  input ext_reset_in;
  input slowest_sync_clk;

  wire esc_const0_a0cf646 ;
  wire VCC_1;
  wire exr_d1;
  wire [0:0]exr_lpf;
  wire ext_reset_in;
  wire lpf_exr;
  wire lpf_exr_reg;
  wire p_1_in4_in;
  wire p_2_in3_in;
  wire s_level_out_d1_cdc_to;
  wire s_level_out_d2;
  wire s_level_out_d3;
  wire scndry_out;
  wire slowest_sync_clk;

  // Reconstructed FDRE: esc_GENERATE_LEVEL_P_S_CDC_SINGLE_BIT_CROSS_PLEVEL_IN2SCNDRY_IN_cdc_to_27f9b30
  reg recovered_1_q = 1'b0;
  assign s_level_out_d1_cdc_to = recovered_1_q;
  wire recovered_1_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_1_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_1_q == 1'b0))) recovered_1_q <= 1'b0;
    else if ((VCC_1) || ((VCC_1) === 1'bz) || (((VCC_1) === 1'bx) && (recovered_1_q == (exr_d1)))) recovered_1_q <= (exr_d1);
  end

  // Reconstructed LUT1: esc_GENERATE_LEVEL_P_S_CDC_SINGLE_BIT_CROSS_PLEVEL_IN2SCNDRY_IN_cdc_to_i_1_da5788e
  assign exr_d1 = ~(ext_reset_in);

  // Reconstructed FDRE: esc_GENERATE_LEVEL_P_S_CDC_SINGLE_BIT_CROSS_PLEVEL_IN2SCNDRY_s_level_out_d2_b13981d
  reg recovered_3_q = 1'b0;
  assign s_level_out_d2 = recovered_3_q;
  wire recovered_3_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_3_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_3_q == 1'b0))) recovered_3_q <= 1'b0;
    else if ((VCC_1) || ((VCC_1) === 1'bz) || (((VCC_1) === 1'bx) && (recovered_3_q == (s_level_out_d1_cdc_to)))) recovered_3_q <= (s_level_out_d1_cdc_to);
  end

  // Reconstructed FDRE: esc_GENERATE_LEVEL_P_S_CDC_SINGLE_BIT_CROSS_PLEVEL_IN2SCNDRY_s_level_out_d3_45a1fba
  reg recovered_4_q = 1'b0;
  assign s_level_out_d3 = recovered_4_q;
  wire recovered_4_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_4_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((VCC_1) || ((VCC_1) === 1'bz) || (((VCC_1) === 1'bx) && (recovered_4_q == (s_level_out_d2)))) recovered_4_q <= (s_level_out_d2);
  end

  // Reconstructed FDRE: esc_GENERATE_LEVEL_P_S_CDC_SINGLE_BIT_CROSS_PLEVEL_IN2SCNDRY_s_level_out_d4_2eae253
  reg recovered_5_q = 1'b0;
  assign scndry_out = recovered_5_q;
  wire recovered_5_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_5_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((VCC_1) || ((VCC_1) === 1'bz) || (((VCC_1) === 1'bx) && (recovered_5_q == (s_level_out_d3)))) recovered_5_q <= (s_level_out_d3);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign VCC_1 = 1'b1;

  // Reconstructed LUT5: lpf_exr_i_1
  assign lpf_exr_reg = ((exr_lpf) ? (((scndry_out) ? (((p_2_in3_in) ? (((p_1_in4_in) ? (1'b1) : (lpf_exr))) : (lpf_exr))) : (lpf_exr))) : (((scndry_out) ? (lpf_exr) : (((p_2_in3_in) ? (lpf_exr) : (((p_1_in4_in) ? (lpf_exr) : (1'b0))))))));

endmodule

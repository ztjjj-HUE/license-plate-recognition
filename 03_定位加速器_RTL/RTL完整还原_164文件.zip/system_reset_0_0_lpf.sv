// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_reset_0_0_lpf
   (lpf_int,
    slowest_sync_clk,
    dcm_locked,
    mb_debug_sys_rst,
    ext_reset_in,
    aux_reset_in);
  output lpf_int;
  input slowest_sync_clk;
  input dcm_locked;
  input mb_debug_sys_rst;
  input ext_reset_in;
  input aux_reset_in;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire esc_ACTIVE_LOW_AUX_ACT_LO_AUX_n_0_bb97a4b ;
  wire esc_ACTIVE_LOW_EXT_ACT_LO_EXT_n_0_509f264 ;
  wire Q;
  wire VCC_2;
  wire [0:0]asr_lpf;
  wire [0:0]exr_lpf;
  wire ext_reset_in;
  wire lpf_asr;
  wire lpf_exr;
  wire lpf_int;
  wire lpf_int0__0;
  wire p_1_in;
  wire p_1_in4_in;
  wire p_2_in;
  wire p_2_in3_in;
  wire p_3_in1_in;
  wire p_3_in6_in;
  wire slowest_sync_clk;

  system_reset_0_0_cdc_sync esc_ACTIVE_LOW_AUX_ACT_LO_AUX_c80df31 
       (.asr_lpf(asr_lpf),
        .lpf_asr(lpf_asr),
        .lpf_asr_reg(esc_ACTIVE_LOW_AUX_ACT_LO_AUX_n_0_bb97a4b ),
        .p_1_in(p_1_in),
        .p_2_in(p_2_in),
        .scndry_out(p_3_in1_in),
        .slowest_sync_clk(slowest_sync_clk));
  system_reset_0_0_cdc_sync_0 esc_ACTIVE_LOW_EXT_ACT_LO_EXT_9ea307c 
       (.exr_lpf(exr_lpf),
        .ext_reset_in(ext_reset_in),
        .lpf_exr(lpf_exr),
        .lpf_exr_reg(esc_ACTIVE_LOW_EXT_ACT_LO_EXT_n_0_509f264 ),
        .p_1_in4_in(p_1_in4_in),
        .p_2_in3_in(p_2_in3_in),
        .scndry_out(p_3_in6_in),
        .slowest_sync_clk(slowest_sync_clk));

  // Reconstructed FDRE: esc_AUX_LPF_1__asr_lpf_reg_1_4c0fe30
  reg recovered_3_q = 1'b0;
  assign p_2_in = recovered_3_q;
  wire recovered_3_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_3_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_3_q == 1'b0))) recovered_3_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_3_q == (p_3_in1_in)))) recovered_3_q <= (p_3_in1_in);
  end

  // Reconstructed FDRE: esc_AUX_LPF_2__asr_lpf_reg_2_53e1d8c
  reg recovered_4_q = 1'b0;
  assign p_1_in = recovered_4_q;
  wire recovered_4_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_4_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (p_2_in)))) recovered_4_q <= (p_2_in);
  end

  // Reconstructed FDRE: esc_AUX_LPF_3__asr_lpf_reg_3_45ad964
  reg recovered_5_q = 1'b0;
  assign asr_lpf = recovered_5_q;
  wire recovered_5_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_5_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (p_1_in)))) recovered_5_q <= (p_1_in);
  end

  // Reconstructed FDRE: esc_EXT_LPF_1__exr_lpf_reg_1_7f20156
  reg recovered_6_q = 1'b0;
  assign p_2_in3_in = recovered_6_q;
  wire recovered_6_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_6_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (p_3_in6_in)))) recovered_6_q <= (p_3_in6_in);
  end

  // Reconstructed FDRE: esc_EXT_LPF_2__exr_lpf_reg_2_7d450e9
  reg recovered_7_q = 1'b0;
  assign p_1_in4_in = recovered_7_q;
  wire recovered_7_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_7_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (p_2_in3_in)))) recovered_7_q <= (p_2_in3_in);
  end

  // Reconstructed FDRE: esc_EXT_LPF_3__exr_lpf_reg_3_f4fca79
  reg recovered_8_q = 1'b0;
  assign exr_lpf = recovered_8_q;
  wire recovered_8_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_8_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_8_q == (p_1_in4_in)))) recovered_8_q <= (p_1_in4_in);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed SRL16E: POR_SRL_I
  reg [15:0] recovered_10_shift = 16'hFFFF;
  always @(posedge slowest_sync_clk)
    if ((VCC_2) == 1'b1 || (VCC_2) === 1'bz) recovered_10_shift <= {recovered_10_shift[14:0],esc_const0_a0cf646};
  assign Q = recovered_10_shift[{esc_const1_c064970,esc_const1_c064970,esc_const1_c064970,esc_const1_c064970}];

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed VCC: VCC_1
  assign VCC_2 = 1'b1;

  // Reconstructed FDRE: lpf_asr_reg
  reg recovered_13_q = 1'b0;
  assign lpf_asr = recovered_13_q;
  wire recovered_13_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_13_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_13_q == (esc_ACTIVE_LOW_AUX_ACT_LO_AUX_n_0_bb97a4b)))) recovered_13_q <= (esc_ACTIVE_LOW_AUX_ACT_LO_AUX_n_0_bb97a4b);
  end

  // Reconstructed FDRE: lpf_exr_reg
  reg recovered_14_q = 1'b0;
  assign lpf_exr = recovered_14_q;
  wire recovered_14_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_14_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_14_q == (esc_ACTIVE_LOW_EXT_ACT_LO_EXT_n_0_509f264)))) recovered_14_q <= (esc_ACTIVE_LOW_EXT_ACT_LO_EXT_n_0_509f264);
  end

  // Reconstructed LUT3: lpf_int0
  assign lpf_int0__0 = ((Q) ? (1'b1) : (((lpf_asr) ? (1'b1) : (lpf_exr))));

  // Reconstructed FDRE: lpf_int_reg
  reg recovered_16_q = 1'b0;
  assign lpf_int = recovered_16_q;
  wire recovered_16_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_16_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_16_q == (lpf_int0__0)))) recovered_16_q <= (lpf_int0__0);
  end

endmodule

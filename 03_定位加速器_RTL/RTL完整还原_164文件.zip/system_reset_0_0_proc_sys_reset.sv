// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_reset_0_0_proc_sys_reset
   (slowest_sync_clk,
    ext_reset_in,
    aux_reset_in,
    mb_debug_sys_rst,
    dcm_locked,
    mb_reset,
    bus_struct_reset,
    peripheral_reset,
    interconnect_aresetn,
    peripheral_aresetn);
  input slowest_sync_clk;
  input ext_reset_in;
  input aux_reset_in;
  input mb_debug_sys_rst;
  input dcm_locked;
  output mb_reset;
  output [0:0]bus_struct_reset;
  output [0:0]peripheral_reset;
  output [0:0]interconnect_aresetn;
  output [0:0]peripheral_aresetn;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire SEQ_n_3;
  wire SEQ_n_4;
  wire ext_reset_in;
  wire [0:0]interconnect_aresetn;
  wire lpf_int;
  wire [0:0]peripheral_aresetn;
  wire slowest_sync_clk;

  // Reconstructed FDRE: esc_ACTIVE_LOW_BSR_OUT_DFF_0__FDRE_BSR_N_e0c2456
  reg recovered_1_q = 1'b0;
  assign interconnect_aresetn = recovered_1_q;
  wire recovered_1_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_1_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_1_q == 1'b0))) recovered_1_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_1_q == (SEQ_n_3)))) recovered_1_q <= (SEQ_n_3);
  end

  // Reconstructed FDRE: esc_ACTIVE_LOW_PR_OUT_DFF_0__FDRE_PER_N_b251691
  reg recovered_2_q = 1'b0;
  assign peripheral_aresetn = recovered_2_q;
  wire recovered_2_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_2_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_2_q == 1'b0))) recovered_2_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_2_q == (SEQ_n_4)))) recovered_2_q <= (SEQ_n_4);
  end

  system_reset_0_0_lpf EXT_LPF
       (.ext_reset_in(ext_reset_in),
        .lpf_int(lpf_int),
        .slowest_sync_clk(slowest_sync_clk));

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  system_reset_0_0_sequence_psr SEQ
       (.bsr_reg_0(SEQ_n_3),
        .lpf_int(lpf_int),
        .pr_reg_0(SEQ_n_4),
        .slowest_sync_clk(slowest_sync_clk));

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

endmodule

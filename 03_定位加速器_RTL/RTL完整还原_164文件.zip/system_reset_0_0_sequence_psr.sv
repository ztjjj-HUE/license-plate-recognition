// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_reset_0_0_sequence_psr
   (MB_out,
    Bsr_out,
    Pr_out,
    bsr_reg_0,
    pr_reg_0,
    lpf_int,
    slowest_sync_clk);
  output MB_out;
  output Bsr_out;
  output Pr_out;
  output bsr_reg_0;
  output pr_reg_0;
  input lpf_int;
  input slowest_sync_clk;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire esc_Bsr_out_53b3c12 ;
  wire Core_i_1_n_0;
  wire esc_MB_out_3b5cac3 ;
  wire esc_Pr_out_7167056 ;
  wire esc_bsr_dec_reg_n_0__0_16a1e57 ;
  wire esc_bsr_dec_reg_n_0__2_af16ad9 ;
  wire bsr_i_1_n_0;
  wire bsr_reg_0;
  wire esc_core_dec_0__i_1_n_0_e58d9be ;
  wire esc_core_dec_2__i_1_n_0_f05986c ;
  wire esc_core_dec_reg_n_0__0_4f8e48f ;
  wire esc_core_dec_reg_n_0__1_130bc9b ;
  wire from_sys_i_1_n_0;
  wire lpf_int;
  wire p_0_in;
  wire [2:0]p_3_out;
  wire [2:0]p_5_out;
  wire pr_dec0__0;
  wire esc_pr_dec_reg_n_0__0_fcc0110 ;
  wire esc_pr_dec_reg_n_0__2_70704d4 ;
  wire pr_i_1_n_0;
  wire pr_reg_0;
  wire seq_clr;
  wire [5:0]seq_cnt;
  wire seq_cnt_en;
  wire slowest_sync_clk;

  // Reconstructed LUT1: esc_ACTIVE_LOW_BSR_OUT_DFF_0__FDRE_BSR_N_i_1_373a878
  assign bsr_reg_0 = ~(esc_Bsr_out_53b3c12);

  // Reconstructed LUT1: esc_ACTIVE_LOW_PR_OUT_DFF_0__FDRE_PER_N_i_1_607a02d
  assign pr_reg_0 = ~(esc_Pr_out_7167056);

  // Reconstructed LUT2: Core_i_1
  assign Core_i_1_n_0 = ((p_0_in) ? (1'b0) : (esc_MB_out_3b5cac3));

  // Reconstructed FDSE: Core_reg
  reg recovered_4_q = 1'b1;
  assign esc_MB_out_3b5cac3 = recovered_4_q;
  wire recovered_4_reset = ((lpf_int)) && ((lpf_int) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_4_reset || (((lpf_int) === 1'bx) && (recovered_4_q == 1'b1))) recovered_4_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (Core_i_1_n_0)))) recovered_4_q <= (Core_i_1_n_0);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  system_reset_0_0_upcnt_n SEQ_COUNTER
       (.Q(seq_cnt),
        .seq_clr(seq_clr),
        .seq_cnt_en(seq_cnt_en),
        .slowest_sync_clk(slowest_sync_clk));

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT4: esc_bsr_dec_0__i_1_736b6f9
  assign p_5_out[0] = ((seq_cnt[5]) ? (1'b0) : (((seq_cnt[3]) ? (((seq_cnt[4]) ? (seq_cnt_en) : (~(seq_cnt_en)))) : (1'b0))));

  // Reconstructed LUT2: esc_bsr_dec_2__i_1_3d50bfe
  assign p_5_out[2] = ((esc_bsr_dec_reg_n_0__0_16a1e57) ? (esc_core_dec_reg_n_0__1_130bc9b) : (1'b0));

  // Reconstructed FDRE: esc_bsr_dec_reg_0_c1bfbcb
  reg recovered_10_q = 1'b0;
  assign esc_bsr_dec_reg_n_0__0_16a1e57 = recovered_10_q;
  wire recovered_10_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_10_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_10_q == (p_5_out[0])))) recovered_10_q <= (p_5_out[0]);
  end

  // Reconstructed FDRE: esc_bsr_dec_reg_2_25a9b69
  reg recovered_11_q = 1'b0;
  assign esc_bsr_dec_reg_n_0__2_af16ad9 = recovered_11_q;
  wire recovered_11_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_11_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_11_q == (p_5_out[2])))) recovered_11_q <= (p_5_out[2]);
  end

  // Reconstructed LUT2: bsr_i_1
  assign bsr_i_1_n_0 = ((esc_bsr_dec_reg_n_0__2_af16ad9) ? (1'b0) : (esc_Bsr_out_53b3c12));

  // Reconstructed FDSE: bsr_reg
  reg recovered_13_q = 1'b1;
  assign esc_Bsr_out_53b3c12 = recovered_13_q;
  wire recovered_13_reset = ((lpf_int)) && ((lpf_int) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_13_reset || (((lpf_int) === 1'bx) && (recovered_13_q == 1'b1))) recovered_13_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_13_q == (bsr_i_1_n_0)))) recovered_13_q <= (bsr_i_1_n_0);
  end

  // Reconstructed LUT4: esc_core_dec_0__i_1_aa6be60
  assign esc_core_dec_0__i_1_n_0_e58d9be = ((seq_cnt[5]) ? (((seq_cnt[3]) ? (((seq_cnt[4]) ? (seq_cnt_en) : (~(seq_cnt_en)))) : (1'b0))) : (1'b0));

  // Reconstructed LUT2: esc_core_dec_2__i_1_3d0aac0
  assign esc_core_dec_2__i_1_n_0_f05986c = ((esc_core_dec_reg_n_0__0_4f8e48f) ? (esc_core_dec_reg_n_0__1_130bc9b) : (1'b0));

  // Reconstructed FDRE: esc_core_dec_reg_0_ce988a3
  reg recovered_16_q = 1'b0;
  assign esc_core_dec_reg_n_0__0_4f8e48f = recovered_16_q;
  wire recovered_16_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_16_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_16_q == (esc_core_dec_0__i_1_n_0_e58d9be)))) recovered_16_q <= (esc_core_dec_0__i_1_n_0_e58d9be);
  end

  // Reconstructed FDRE: esc_core_dec_reg_1_ba256a3
  reg recovered_17_q = 1'b0;
  assign esc_core_dec_reg_n_0__1_130bc9b = recovered_17_q;
  wire recovered_17_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_17_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_17_q == (pr_dec0__0)))) recovered_17_q <= (pr_dec0__0);
  end

  // Reconstructed FDRE: esc_core_dec_reg_2_38bf8fa
  reg recovered_18_q = 1'b0;
  assign p_0_in = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_18_q == (esc_core_dec_2__i_1_n_0_f05986c)))) recovered_18_q <= (esc_core_dec_2__i_1_n_0_f05986c);
  end

  // Reconstructed LUT2: from_sys_i_1
  assign from_sys_i_1_n_0 = ((seq_cnt_en) ? (esc_MB_out_3b5cac3) : (1'b0));

  // Reconstructed FDSE: from_sys_reg
  reg recovered_20_q = 1'b0;
  assign seq_cnt_en = recovered_20_q;
  wire recovered_20_reset = ((lpf_int)) && ((lpf_int) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_20_reset || (((lpf_int) === 1'bx) && (recovered_20_q == 1'b1))) recovered_20_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_20_q == (from_sys_i_1_n_0)))) recovered_20_q <= (from_sys_i_1_n_0);
  end

  // Reconstructed LUT4: pr_dec0
  assign pr_dec0__0 = ((seq_cnt[1]) ? (1'b0) : (((seq_cnt[2]) ? (((seq_cnt[0]) ? (1'b0) : (~(seq_cnt_en)))) : (((seq_cnt[0]) ? (seq_cnt_en) : (1'b0))))));

  // Reconstructed LUT4: esc_pr_dec_0__i_1_703ac36
  assign p_3_out[0] = ((seq_cnt[4]) ? (((seq_cnt[5]) ? (1'b0) : (((seq_cnt[3]) ? (~(seq_cnt_en)) : (1'b0))))) : (((seq_cnt[5]) ? (((seq_cnt[3]) ? (seq_cnt_en) : (1'b0))) : (1'b0))));

  // Reconstructed LUT2: esc_pr_dec_2__i_1_3b78556
  assign p_3_out[2] = ((esc_pr_dec_reg_n_0__0_fcc0110) ? (esc_core_dec_reg_n_0__1_130bc9b) : (1'b0));

  // Reconstructed FDRE: esc_pr_dec_reg_0_6136344
  reg recovered_24_q = 1'b0;
  assign esc_pr_dec_reg_n_0__0_fcc0110 = recovered_24_q;
  wire recovered_24_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_24_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_24_q == (p_3_out[0])))) recovered_24_q <= (p_3_out[0]);
  end

  // Reconstructed FDRE: esc_pr_dec_reg_2_2b9042e
  reg recovered_25_q = 1'b0;
  assign esc_pr_dec_reg_n_0__2_70704d4 = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_25_q == (p_3_out[2])))) recovered_25_q <= (p_3_out[2]);
  end

  // Reconstructed LUT2: pr_i_1
  assign pr_i_1_n_0 = ((esc_pr_dec_reg_n_0__2_70704d4) ? (1'b0) : (esc_Pr_out_7167056));

  // Reconstructed FDSE: pr_reg
  reg recovered_27_q = 1'b1;
  assign esc_Pr_out_7167056 = recovered_27_q;
  wire recovered_27_reset = ((lpf_int)) && ((lpf_int) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_27_reset || (((lpf_int) === 1'bx) && (recovered_27_q == 1'b1))) recovered_27_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_27_q == (pr_i_1_n_0)))) recovered_27_q <= (pr_i_1_n_0);
  end

  // Reconstructed FDRE: seq_clr_reg
  reg recovered_28_q = 1'b0;
  assign seq_clr = recovered_28_q;
  wire recovered_28_reset = ((lpf_int)) && ((lpf_int) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_28_reset || (((lpf_int) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_28_q == (esc_const1_c064970)))) recovered_28_q <= (esc_const1_c064970);
  end

endmodule

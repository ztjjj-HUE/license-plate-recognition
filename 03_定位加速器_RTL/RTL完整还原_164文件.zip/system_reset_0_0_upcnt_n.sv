// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_reset_0_0_upcnt_n
   (Q,
    seq_clr,
    seq_cnt_en,
    slowest_sync_clk);
  output [5:0]Q;
  input seq_clr;
  input seq_cnt_en;
  input slowest_sync_clk;

  wire [5:0]Q;
  wire clear;
  wire [5:0]q_int0;
  wire seq_clr;
  wire seq_cnt_en;
  wire slowest_sync_clk;

  // Reconstructed LUT1: esc_q_int_0__i_1_0ddcb13
  assign q_int0[0] = ~(Q[0]);

  // Reconstructed LUT2: esc_q_int_1__i_1_94cf307
  assign q_int0[1] = ((Q[1]) ? (~(Q[0])) : (Q[0]));

  // Reconstructed LUT3: esc_q_int_2__i_1_1a6361a
  assign q_int0[2] = ((Q[2]) ? (((Q[1]) ? (~(Q[0])) : (1'b1))) : (((Q[1]) ? (Q[0]) : (1'b0))));

  // Reconstructed LUT4: esc_q_int_3__i_1_a26c310
  assign q_int0[3] = ((Q[3]) ? (((Q[2]) ? (((Q[0]) ? (~(Q[1])) : (1'b1))) : (1'b1))) : (((Q[2]) ? (((Q[0]) ? (Q[1]) : (1'b0))) : (1'b0))));

  // Reconstructed LUT5: esc_q_int_4__i_1_1525d24
  assign q_int0[4] = ((Q[4]) ? (((Q[3]) ? (((Q[1]) ? (((Q[0]) ? (~(Q[2])) : (1'b1))) : (1'b1))) : (1'b1))) : (((Q[3]) ? (((Q[1]) ? (((Q[0]) ? (Q[2]) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT1: esc_q_int_5__i_1_22c6fbc
  assign clear = ~(seq_clr);

  // Reconstructed LUT6: esc_q_int_5__i_2_7752199
  assign q_int0[5] = ((Q[5]) ? (((Q[4]) ? (((Q[2]) ? (((Q[0]) ? (((Q[1]) ? (~(Q[3])) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1))) : (((Q[4]) ? (((Q[2]) ? (((Q[0]) ? (((Q[1]) ? (Q[3]) : (1'b0))) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed FDRE: esc_q_int_reg_0_1bc7c39
  reg recovered_8_q = 1'b1;
  assign Q[0] = recovered_8_q;
  wire recovered_8_reset = ((clear)) && ((clear) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_8_reset || (((clear) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((seq_cnt_en) || ((seq_cnt_en) === 1'bz) || (((seq_cnt_en) === 1'bx) && (recovered_8_q == (q_int0[0])))) recovered_8_q <= (q_int0[0]);
  end

  // Reconstructed FDRE: esc_q_int_reg_1_c8b86e7
  reg recovered_9_q = 1'b1;
  assign Q[1] = recovered_9_q;
  wire recovered_9_reset = ((clear)) && ((clear) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_9_reset || (((clear) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((seq_cnt_en) || ((seq_cnt_en) === 1'bz) || (((seq_cnt_en) === 1'bx) && (recovered_9_q == (q_int0[1])))) recovered_9_q <= (q_int0[1]);
  end

  // Reconstructed FDRE: esc_q_int_reg_2_e5da93f
  reg recovered_10_q = 1'b1;
  assign Q[2] = recovered_10_q;
  wire recovered_10_reset = ((clear)) && ((clear) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_10_reset || (((clear) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((seq_cnt_en) || ((seq_cnt_en) === 1'bz) || (((seq_cnt_en) === 1'bx) && (recovered_10_q == (q_int0[2])))) recovered_10_q <= (q_int0[2]);
  end

  // Reconstructed FDRE: esc_q_int_reg_3_b32d267
  reg recovered_11_q = 1'b1;
  assign Q[3] = recovered_11_q;
  wire recovered_11_reset = ((clear)) && ((clear) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_11_reset || (((clear) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((seq_cnt_en) || ((seq_cnt_en) === 1'bz) || (((seq_cnt_en) === 1'bx) && (recovered_11_q == (q_int0[3])))) recovered_11_q <= (q_int0[3]);
  end

  // Reconstructed FDRE: esc_q_int_reg_4_ce89a66
  reg recovered_12_q = 1'b1;
  assign Q[4] = recovered_12_q;
  wire recovered_12_reset = ((clear)) && ((clear) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_12_reset || (((clear) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((seq_cnt_en) || ((seq_cnt_en) === 1'bz) || (((seq_cnt_en) === 1'bx) && (recovered_12_q == (q_int0[4])))) recovered_12_q <= (q_int0[4]);
  end

  // Reconstructed FDRE: esc_q_int_reg_5_7cfc6e7
  reg recovered_13_q = 1'b1;
  assign Q[5] = recovered_13_q;
  wire recovered_13_reset = ((clear)) && ((clear) !== 1'bz);
  always @(posedge slowest_sync_clk) begin
    if (recovered_13_reset || (((clear) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((seq_cnt_en) || ((seq_cnt_en) === 1'bz) || (((seq_cnt_en) === 1'bx) && (recovered_13_q == (q_int0[5])))) recovered_13_q <= (q_int0[5]);
  end

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0
   (aclk,
    aresetn,
    s_axi_awid,
    s_axi_awaddr,
    s_axi_awlen,
    s_axi_awsize,
    s_axi_awburst,
    s_axi_awlock,
    s_axi_awcache,
    s_axi_awprot,
    s_axi_awqos,
    s_axi_awvalid,
    s_axi_awready,
    s_axi_wdata,
    s_axi_wstrb,
    s_axi_wlast,
    s_axi_wvalid,
    s_axi_wready,
    s_axi_bid,
    s_axi_bresp,
    s_axi_bvalid,
    s_axi_bready,
    s_axi_arid,
    s_axi_araddr,
    s_axi_arlen,
    s_axi_arsize,
    s_axi_arburst,
    s_axi_arlock,
    s_axi_arcache,
    s_axi_arprot,
    s_axi_arqos,
    s_axi_arvalid,
    s_axi_arready,
    s_axi_rid,
    s_axi_rdata,
    s_axi_rresp,
    s_axi_rlast,
    s_axi_rvalid,
    s_axi_rready,
    m_axi_awid,
    m_axi_awaddr,
    m_axi_awlen,
    m_axi_awsize,
    m_axi_awburst,
    m_axi_awlock,
    m_axi_awcache,
    m_axi_awprot,
    m_axi_awregion,
    m_axi_awqos,
    m_axi_awvalid,
    m_axi_awready,
    m_axi_wdata,
    m_axi_wstrb,
    m_axi_wlast,
    m_axi_wvalid,
    m_axi_wready,
    m_axi_bid,
    m_axi_bresp,
    m_axi_bvalid,
    m_axi_bready,
    m_axi_arid,
    m_axi_araddr,
    m_axi_arlen,
    m_axi_arsize,
    m_axi_arburst,
    m_axi_arlock,
    m_axi_arcache,
    m_axi_arprot,
    m_axi_arregion,
    m_axi_arqos,
    m_axi_arvalid,
    m_axi_arready,
    m_axi_rid,
    m_axi_rdata,
    m_axi_rresp,
    m_axi_rlast,
    m_axi_rvalid,
    m_axi_rready);
    input aclk;
    input aresetn;
   input [11:0]s_axi_awid;
   input [31:0]s_axi_awaddr;
   input [7:0]s_axi_awlen;
   input [2:0]s_axi_awsize;
   input [1:0]s_axi_awburst;
   input [0:0]s_axi_awlock;
   input [3:0]s_axi_awcache;
   input [2:0]s_axi_awprot;
   input [3:0]s_axi_awqos;
   input [0:0]s_axi_awvalid;
   output [0:0]s_axi_awready;
   input [31:0]s_axi_wdata;
   input [3:0]s_axi_wstrb;
   input [0:0]s_axi_wlast;
   input [0:0]s_axi_wvalid;
   output [0:0]s_axi_wready;
   output [11:0]s_axi_bid;
   output [1:0]s_axi_bresp;
   output [0:0]s_axi_bvalid;
   input [0:0]s_axi_bready;
   input [11:0]s_axi_arid;
   input [31:0]s_axi_araddr;
   input [7:0]s_axi_arlen;
   input [2:0]s_axi_arsize;
   input [1:0]s_axi_arburst;
   input [0:0]s_axi_arlock;
   input [3:0]s_axi_arcache;
   input [2:0]s_axi_arprot;
   input [3:0]s_axi_arqos;
   input [0:0]s_axi_arvalid;
   output [0:0]s_axi_arready;
   output [11:0]s_axi_rid;
   output [31:0]s_axi_rdata;
   output [1:0]s_axi_rresp;
   output [0:0]s_axi_rlast;
   output [0:0]s_axi_rvalid;
    input [0:0]s_axi_rready;
   output [23:0]m_axi_awid;
   output [63:0]m_axi_awaddr;
   output [15:0]m_axi_awlen;
   output [5:0]m_axi_awsize;
   output [3:0]m_axi_awburst;
   output [1:0]m_axi_awlock;
   output [7:0]m_axi_awcache;
   output [5:0]m_axi_awprot;
   output [7:0]m_axi_awregion;
   output [7:0]m_axi_awqos;
   output [1:0]m_axi_awvalid;
   input [1:0]m_axi_awready;
   output [63:0]m_axi_wdata;
   output [7:0]m_axi_wstrb;
   output [1:0]m_axi_wlast;
   output [1:0]m_axi_wvalid;
   input [1:0]m_axi_wready;
   input [23:0]m_axi_bid;
   input [3:0]m_axi_bresp;
   input [1:0]m_axi_bvalid;
   output [1:0]m_axi_bready;
   output [23:0]m_axi_arid;
   output [63:0]m_axi_araddr;
   output [15:0]m_axi_arlen;
   output [5:0]m_axi_arsize;
   output [3:0]m_axi_arburst;
   output [1:0]m_axi_arlock;
   output [7:0]m_axi_arcache;
   output [5:0]m_axi_arprot;
   output [7:0]m_axi_arregion;
   output [7:0]m_axi_arqos;
   output [1:0]m_axi_arvalid;
   input [1:0]m_axi_arready;
   input [23:0]m_axi_rid;
   input [63:0]m_axi_rdata;
   input [3:0]m_axi_rresp;
   input [1:0]m_axi_rlast;
   input [1:0]m_axi_rvalid;
    output [1:0]m_axi_rready;

  wire aclk;
  wire aresetn;
  wire [63:0]m_axi_araddr;
  wire [3:0]m_axi_arburst;
  wire [23:0]m_axi_arid;
  wire [15:0]m_axi_arlen;
  wire [1:0]m_axi_arready;
  wire [5:0]m_axi_arsize;
  wire [1:0]m_axi_arvalid;
  wire [63:0]m_axi_awaddr;
  wire [3:0]m_axi_awburst;
  wire [23:0]m_axi_awid;
  wire [15:0]m_axi_awlen;
  wire [1:0]m_axi_awready;
  wire [5:0]m_axi_awsize;
  wire [1:0]m_axi_awvalid;
  wire [23:0]m_axi_bid;
  wire [1:0]m_axi_bready;
  wire [3:0]m_axi_bresp;
  wire [1:0]m_axi_bvalid;
  wire [63:0]m_axi_rdata;
  wire [23:0]m_axi_rid;
  wire [1:0]m_axi_rlast;
  wire [1:0]m_axi_rready;
  wire [3:0]m_axi_rresp;
  wire [1:0]m_axi_rvalid;
  wire [63:0]m_axi_wdata;
  wire [1:0]m_axi_wlast;
  wire [1:0]m_axi_wready;
  wire [7:0]m_axi_wstrb;
  wire [1:0]m_axi_wvalid;
  wire [31:0]s_axi_araddr;
  wire [1:0]s_axi_arburst;
  wire [11:0]s_axi_arid;
  wire [7:0]s_axi_arlen;
  wire [0:0]s_axi_arready;
  wire [2:0]s_axi_arsize;
  wire [0:0]s_axi_arvalid;
  wire [31:0]s_axi_awaddr;
  wire [1:0]s_axi_awburst;
  wire [11:0]s_axi_awid;
  wire [7:0]s_axi_awlen;
  wire [0:0]s_axi_awready;
  wire [2:0]s_axi_awsize;
  wire [0:0]s_axi_awvalid;
  wire [11:0]s_axi_bid;
  wire [0:0]s_axi_bready;
  wire [1:0]s_axi_bresp;
  wire [0:0]s_axi_bvalid;
  wire [31:0]s_axi_rdata;
  wire [11:0]s_axi_rid;
  wire [0:0]s_axi_rlast;
  wire [0:0]s_axi_rready;
  wire [1:0]s_axi_rresp;
  wire [0:0]s_axi_rvalid;
  wire [31:0]s_axi_wdata;
  wire [0:0]s_axi_wlast;
  wire [0:0]s_axi_wready;
  wire [3:0]s_axi_wstrb;
  wire [0:0]s_axi_wvalid;
  wire [63:0]NLW_inst_m_axi_araddr_UNCONNECTED;
  wire [15:0]NLW_inst_m_axi_arlen_UNCONNECTED;
  wire [63:0]NLW_inst_m_axi_awaddr_UNCONNECTED;
  wire [15:0]NLW_inst_m_axi_awlen_UNCONNECTED;
  wire [3:0]NLW_inst_m_axi_rresp_UNCONNECTED;
  wire [1:0]NLW_inst_m_axi_wlast_UNCONNECTED;

  system_xbar_0_axi_crossbar_v2_1_23_axi_crossbar inst
       (.aclk(aclk),
        .aresetn(aresetn),
        .m_axi_araddr({m_axi_araddr[63:34],NLW_inst_m_axi_araddr_UNCONNECTED[33:8],m_axi_araddr[7:0]}),
        .m_axi_arburst(m_axi_arburst),
        .m_axi_arid(m_axi_arid),
        .m_axi_arlen({m_axi_arlen[11:8],NLW_inst_m_axi_arlen_UNCONNECTED[7:4],m_axi_arlen[3:0]}),
        .m_axi_arready(m_axi_arready),
        .m_axi_arsize(m_axi_arsize[1:0]),
        .m_axi_arvalid(m_axi_arvalid),
        .m_axi_awaddr({m_axi_awaddr[63:34],NLW_inst_m_axi_awaddr_UNCONNECTED[33:8],m_axi_awaddr[7:0]}),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awid(m_axi_awid),
        .m_axi_awlen({m_axi_awlen[11:8],NLW_inst_m_axi_awlen_UNCONNECTED[7:4],m_axi_awlen[3:0]}),
        .m_axi_awready(m_axi_awready),
        .m_axi_awsize(m_axi_awsize[1:0]),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_bid(m_axi_bid),
        .m_axi_bready(m_axi_bready),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_rdata(m_axi_rdata),
        .m_axi_rid(m_axi_rid),
        .m_axi_rlast(m_axi_rlast),
        .m_axi_rready(m_axi_rready),
        .m_axi_rresp({m_axi_rresp[3:2],NLW_inst_m_axi_rresp_UNCONNECTED[1:0]}),
        .m_axi_rvalid(m_axi_rvalid),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wlast({m_axi_wlast[1],NLW_inst_m_axi_wlast_UNCONNECTED[0]}),
        .m_axi_wready(m_axi_wready),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wvalid(m_axi_wvalid),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_arid(s_axi_arid),
        .s_axi_arlen(s_axi_arlen[3:0]),
        .s_axi_arready(s_axi_arready),
        .s_axi_arsize(s_axi_arsize[1:0]),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awid(s_axi_awid),
        .s_axi_awlen(s_axi_awlen[3:0]),
        .s_axi_awready(s_axi_awready),
        .s_axi_awsize(s_axi_awsize[1:0]),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_bid(s_axi_bid),
        .s_axi_bready(s_axi_bready),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rid(s_axi_rid),
        .s_axi_rlast(s_axi_rlast),
        .s_axi_rready(s_axi_rready),
        .s_axi_rresp(s_axi_rresp),
        .s_axi_rvalid(s_axi_rvalid),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wready(s_axi_wready),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wvalid(s_axi_wvalid));
endmodule

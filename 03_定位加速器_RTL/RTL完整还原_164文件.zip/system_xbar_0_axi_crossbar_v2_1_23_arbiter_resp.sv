// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_crossbar_v2_1_23_arbiter_resp
   (aresetn_d_reg,
    m_valid_i,
    esc_chosen_reg_0__0_db1ffe9 ,
    esc_chosen_reg_0__1_a7d9131 ,
    aresetn_d_reg_0,
    esc_gen_master_slots_0__w_issuing_cnt_reg_1_c906b05 ,
    s_axi_bvalid,
    esc_chosen_reg_2__0_f7c16fe ,
    esc_chosen_reg_1__0_620be56 ,
    esc_s_axi_bready_0_6776e19 ,
    esc_gen_multi_thread_active_cnt_reg_8_8455e33 ,
    esc_gen_multi_thread_active_cnt_reg_19_d0476bf ,
    esc_gen_multi_thread_active_cnt_reg_27_ae45a7f ,
    esc_gen_multi_thread_active_cnt_reg_35_918f06b ,
    esc_gen_multi_thread_active_cnt_reg_43_12e6e9f ,
    esc_gen_multi_thread_active_cnt_reg_51_0dd34c8 ,
    esc_gen_multi_thread_active_cnt_reg_56_c509015 ,
    esc_gen_multi_thread_accept_cnt_reg_3_3e8a8a0 ,
    esc_gen_multi_thread_accept_cnt_reg_2_8143b78 ,
    esc_s_axi_bready_0__0_3434b82 ,
    aresetn_d,
    chosen41_in,
    s_axi_bready,
    D,
    st_aa_awtarget_hot,
    aa_mi_awtarget_hot,
    w_issuing_cnt,
    esc_gen_master_slots_0__w_issuing_cnt_reg_0_55b6fcd ,
    m_axi_awready,
    chosen40_in,
    E,
    esc_gen_no_arbiter_m_target_hot_i_reg_2_e9c3b41 ,
    esc_gen_no_arbiter_m_target_hot_i_reg_2__0_c43d162 ,
    esc_gen_no_arbiter_m_target_hot_i_reg_2__1_13cbb8a ,
    esc_gen_no_arbiter_m_target_hot_i_reg_2__2_6833a62 ,
    esc_gen_no_arbiter_m_target_hot_i_reg_2__3_bd1b2c1 ,
    esc_gen_no_arbiter_m_target_hot_i_2__i_2_0_d8d5244 ,
    esc_gen_no_arbiter_m_target_hot_i_2__i_2_1_2159265 ,
    Q,
    esc_gen_no_arbiter_m_target_hot_i_2__i_8_0_813c3b8 ,
    esc_gen_multi_thread_active_cnt_reg_2_d9d8f7c ,
    CO,
    esc_gen_multi_thread_active_cnt_reg_2__0_6abe1f0 ,
    esc_gen_multi_thread_active_cnt_reg_10_aa6bc77 ,
    esc_gen_multi_thread_active_cnt_reg_10__0_041afb5 ,
    esc_gen_multi_thread_cmd_push_1_87888fa ,
    esc_gen_multi_thread_active_cnt_reg_18_fd99d72 ,
    esc_gen_multi_thread_active_cnt_reg_18__0_364a565 ,
    esc_gen_multi_thread_cmd_push_2_520dcd2 ,
    esc_gen_multi_thread_active_cnt_reg_26_ff68a00 ,
    esc_gen_multi_thread_active_cnt_reg_26__0_a520897 ,
    esc_gen_multi_thread_cmd_push_3_18de08c ,
    esc_gen_multi_thread_active_cnt_reg_34_f21a0c7 ,
    esc_gen_multi_thread_active_cnt_reg_34__0_89ffb86 ,
    esc_gen_multi_thread_cmd_push_4_14ecfd5 ,
    esc_gen_multi_thread_active_cnt_reg_42_cf2b36c ,
    esc_gen_multi_thread_active_cnt_reg_42__0_f1bf799 ,
    esc_gen_multi_thread_cmd_push_5_915e4e1 ,
    esc_gen_multi_thread_active_cnt_reg_50_5130782 ,
    esc_gen_multi_thread_active_cnt_reg_50__0_5520c48 ,
    esc_gen_multi_thread_cmd_push_6_03443fb ,
    esc_gen_multi_thread_active_cnt_reg_58_573cc6a ,
    esc_gen_multi_thread_active_cnt_reg_58__0_186cc7e ,
    esc_gen_multi_thread_cmd_push_7_5ddb345 ,
    esc_gen_multi_thread_accept_cnt_reg_1_ed65982 ,
    esc_gen_multi_thread_accept_cnt_reg_3__0_7ef0d65 ,
    esc_gen_no_arbiter_m_target_hot_i_2__i_8_1_bdc7251 ,
    SR,
    aclk);
  output aresetn_d_reg;
  output m_valid_i;
  output esc_chosen_reg_0__0_db1ffe9 ;
  output esc_chosen_reg_0__1_a7d9131 ;
  output aresetn_d_reg_0;
  output esc_gen_master_slots_0__w_issuing_cnt_reg_1_c906b05 ;
  output [0:0]s_axi_bvalid;
  output esc_chosen_reg_2__0_f7c16fe ;
  output esc_chosen_reg_1__0_620be56 ;
  output [0:0]esc_s_axi_bready_0_6776e19 ;
  output [0:0]esc_gen_multi_thread_active_cnt_reg_8_8455e33 ;
  output [0:0]esc_gen_multi_thread_active_cnt_reg_19_d0476bf ;
  output [0:0]esc_gen_multi_thread_active_cnt_reg_27_ae45a7f ;
  output [0:0]esc_gen_multi_thread_active_cnt_reg_35_918f06b ;
  output [0:0]esc_gen_multi_thread_active_cnt_reg_43_12e6e9f ;
  output [0:0]esc_gen_multi_thread_active_cnt_reg_51_0dd34c8 ;
  output [0:0]esc_gen_multi_thread_active_cnt_reg_56_c509015 ;
  output [2:0]esc_gen_multi_thread_accept_cnt_reg_3_3e8a8a0 ;
  output [0:0]esc_gen_multi_thread_accept_cnt_reg_2_8143b78 ;
  output esc_s_axi_bready_0__0_3434b82 ;
  input aresetn_d;
  input chosen41_in;
  input [0:0]s_axi_bready;
  input [0:0]D;
  input [0:0]st_aa_awtarget_hot;
  input [1:0]aa_mi_awtarget_hot;
  input [2:0]w_issuing_cnt;
  input esc_gen_master_slots_0__w_issuing_cnt_reg_0_55b6fcd ;
  input [0:0]m_axi_awready;
  input chosen40_in;
  input [0:0]E;
  input esc_gen_no_arbiter_m_target_hot_i_reg_2_e9c3b41 ;
  input esc_gen_no_arbiter_m_target_hot_i_reg_2__0_c43d162 ;
  input esc_gen_no_arbiter_m_target_hot_i_reg_2__1_13cbb8a ;
  input esc_gen_no_arbiter_m_target_hot_i_reg_2__2_6833a62 ;
  input esc_gen_no_arbiter_m_target_hot_i_reg_2__3_bd1b2c1 ;
  input esc_gen_no_arbiter_m_target_hot_i_2__i_2_0_d8d5244 ;
  input esc_gen_no_arbiter_m_target_hot_i_2__i_2_1_2159265 ;
  input [3:0]Q;
  input esc_gen_no_arbiter_m_target_hot_i_2__i_8_0_813c3b8 ;
  input esc_gen_multi_thread_active_cnt_reg_2_d9d8f7c ;
  input [0:0]CO;
  input esc_gen_multi_thread_active_cnt_reg_2__0_6abe1f0 ;
  input [0:0]esc_gen_multi_thread_active_cnt_reg_10_aa6bc77 ;
  input esc_gen_multi_thread_active_cnt_reg_10__0_041afb5 ;
  input esc_gen_multi_thread_cmd_push_1_87888fa ;
  input esc_gen_multi_thread_active_cnt_reg_18_fd99d72 ;
  input [0:0]esc_gen_multi_thread_active_cnt_reg_18__0_364a565 ;
  input esc_gen_multi_thread_cmd_push_2_520dcd2 ;
  input esc_gen_multi_thread_active_cnt_reg_26_ff68a00 ;
  input [0:0]esc_gen_multi_thread_active_cnt_reg_26__0_a520897 ;
  input esc_gen_multi_thread_cmd_push_3_18de08c ;
  input esc_gen_multi_thread_active_cnt_reg_34_f21a0c7 ;
  input [0:0]esc_gen_multi_thread_active_cnt_reg_34__0_89ffb86 ;
  input esc_gen_multi_thread_cmd_push_4_14ecfd5 ;
  input esc_gen_multi_thread_active_cnt_reg_42_cf2b36c ;
  input [0:0]esc_gen_multi_thread_active_cnt_reg_42__0_f1bf799 ;
  input esc_gen_multi_thread_cmd_push_5_915e4e1 ;
  input esc_gen_multi_thread_active_cnt_reg_50_5130782 ;
  input [0:0]esc_gen_multi_thread_active_cnt_reg_50__0_5520c48 ;
  input esc_gen_multi_thread_cmd_push_6_03443fb ;
  input [0:0]esc_gen_multi_thread_active_cnt_reg_58_573cc6a ;
  input esc_gen_multi_thread_active_cnt_reg_58__0_186cc7e ;
  input esc_gen_multi_thread_cmd_push_7_5ddb345 ;
  input esc_gen_multi_thread_accept_cnt_reg_1_ed65982 ;
  input esc_gen_multi_thread_accept_cnt_reg_3__0_7ef0d65 ;
  input esc_gen_no_arbiter_m_target_hot_i_2__i_8_1_bdc7251 ;
  input [0:0]SR;
  input aclk;

  wire esc_const1_c064970 ;
  wire [0:0]CO;
  wire [0:0]D;
  wire [0:0]E;
  wire [3:0]Q;
  wire [0:0]SR;
  wire [1:0]aa_mi_awtarget_hot;
  wire aclk;
  wire aresetn_d;
  wire aresetn_d_reg;
  wire aresetn_d_reg_0;
  wire chosen40_in;
  wire chosen41_in;
  wire esc_chosen_0__i_1__0_n_0_f3b8818 ;
  wire esc_chosen_1__i_1__0_n_0_a3b5146 ;
  wire esc_chosen_2__i_1__0_n_0_65b92d1 ;
  wire esc_chosen_reg_0__0_db1ffe9 ;
  wire esc_chosen_reg_0__1_a7d9131 ;
  wire esc_chosen_reg_1__0_620be56 ;
  wire esc_chosen_reg_2__0_f7c16fe ;
  wire esc_gen_master_slots_0__w_issuing_cnt_reg_0_55b6fcd ;
  wire esc_gen_master_slots_0__w_issuing_cnt_reg_1_c906b05 ;
  wire esc_gen_multi_thread_accept_cnt_reg_1_ed65982 ;
  wire [0:0]esc_gen_multi_thread_accept_cnt_reg_2_8143b78 ;
  wire [2:0]esc_gen_multi_thread_accept_cnt_reg_3_3e8a8a0 ;
  wire esc_gen_multi_thread_accept_cnt_reg_3__0_7ef0d65 ;
  wire esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_10_aa6bc77 ;
  wire esc_gen_multi_thread_active_cnt_reg_10__0_041afb5 ;
  wire esc_gen_multi_thread_active_cnt_reg_18_fd99d72 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_18__0_364a565 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_19_d0476bf ;
  wire esc_gen_multi_thread_active_cnt_reg_26_ff68a00 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_26__0_a520897 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_27_ae45a7f ;
  wire esc_gen_multi_thread_active_cnt_reg_2_d9d8f7c ;
  wire esc_gen_multi_thread_active_cnt_reg_2__0_6abe1f0 ;
  wire esc_gen_multi_thread_active_cnt_reg_34_f21a0c7 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_34__0_89ffb86 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_35_918f06b ;
  wire esc_gen_multi_thread_active_cnt_reg_42_cf2b36c ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_42__0_f1bf799 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_43_12e6e9f ;
  wire esc_gen_multi_thread_active_cnt_reg_50_5130782 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_50__0_5520c48 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_51_0dd34c8 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_56_c509015 ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_58_573cc6a ;
  wire esc_gen_multi_thread_active_cnt_reg_58__0_186cc7e ;
  wire [0:0]esc_gen_multi_thread_active_cnt_reg_8_8455e33 ;
  wire esc_gen_multi_thread_cmd_push_1_87888fa ;
  wire esc_gen_multi_thread_cmd_push_2_520dcd2 ;
  wire esc_gen_multi_thread_cmd_push_3_18de08c ;
  wire esc_gen_multi_thread_cmd_push_4_14ecfd5 ;
  wire esc_gen_multi_thread_cmd_push_5_915e4e1 ;
  wire esc_gen_multi_thread_cmd_push_6_03443fb ;
  wire esc_gen_multi_thread_cmd_push_7_5ddb345 ;
  wire esc_gen_no_arbiter_m_target_hot_i_2__i_16_n_0_0ad4422 ;
  wire esc_gen_no_arbiter_m_target_hot_i_2__i_17_n_0_96d9058 ;
  wire esc_gen_no_arbiter_m_target_hot_i_2__i_2_0_d8d5244 ;
  wire esc_gen_no_arbiter_m_target_hot_i_2__i_2_1_2159265 ;
  wire esc_gen_no_arbiter_m_target_hot_i_2__i_8_0_813c3b8 ;
  wire esc_gen_no_arbiter_m_target_hot_i_2__i_8_1_bdc7251 ;
  wire esc_gen_no_arbiter_m_target_hot_i_2__i_8_n_0_eb48ae0 ;
  wire esc_gen_no_arbiter_m_target_hot_i_reg_2_e9c3b41 ;
  wire esc_gen_no_arbiter_m_target_hot_i_reg_2__0_c43d162 ;
  wire esc_gen_no_arbiter_m_target_hot_i_reg_2__1_13cbb8a ;
  wire esc_gen_no_arbiter_m_target_hot_i_reg_2__2_6833a62 ;
  wire esc_gen_no_arbiter_m_target_hot_i_reg_2__3_bd1b2c1 ;
  wire esc_last_rr_hot_0__i_1__0_n_0_0e63a71 ;
  wire esc_last_rr_hot_1__i_1__0_n_0_fb27d0b ;
  wire esc_last_rr_hot_2__i_1__0_n_0_9e1aecd ;
  wire esc_last_rr_hot_2__i_6_n_0_0da4f1d ;
  wire esc_last_rr_hot_reg_n_0__0_df186df ;
  wire [0:0]m_axi_awready;
  wire m_valid_i;
  wire need_arbitration;
  wire [2:0]next_rr_hot;
  wire p_3_in;
  wire p_4_in;
  wire [0:0]s_axi_bready;
  wire [0:0]esc_s_axi_bready_0_6776e19 ;
  wire esc_s_axi_bready_0__0_3434b82 ;
  wire [0:0]s_axi_bvalid;
  wire [0:0]st_aa_awtarget_hot;
  wire [2:0]w_issuing_cnt;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT3: esc_chosen_0__i_1__0_8a74693
  assign esc_chosen_0__i_1__0_n_0_f3b8818 = ((esc_chosen_reg_0__1_a7d9131) ? (((need_arbitration) ? (next_rr_hot[0]) : (1'b1))) : (((need_arbitration) ? (next_rr_hot[0]) : (1'b0))));

  // Reconstructed LUT3: esc_chosen_1__i_1__0_f231717
  assign esc_chosen_1__i_1__0_n_0_a3b5146 = ((esc_chosen_reg_1__0_620be56) ? (((need_arbitration) ? (next_rr_hot[1]) : (1'b1))) : (((need_arbitration) ? (next_rr_hot[1]) : (1'b0))));

  // Reconstructed LUT3: esc_chosen_2__i_1__0_3c207fd
  assign esc_chosen_2__i_1__0_n_0_65b92d1 = ((esc_chosen_reg_2__0_f7c16fe) ? (((need_arbitration) ? (next_rr_hot[2]) : (1'b1))) : (((need_arbitration) ? (next_rr_hot[2]) : (1'b0))));

  // Reconstructed FDRE: esc_chosen_reg_0_cbf18f4
  reg recovered_5_q = 1'b0;
  assign esc_chosen_reg_0__1_a7d9131 = recovered_5_q;
  wire recovered_5_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((SR) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (esc_chosen_0__i_1__0_n_0_f3b8818)))) recovered_5_q <= (esc_chosen_0__i_1__0_n_0_f3b8818);
  end

  // Reconstructed FDRE: esc_chosen_reg_1_fa03fcd
  reg recovered_6_q = 1'b0;
  assign esc_chosen_reg_1__0_620be56 = recovered_6_q;
  wire recovered_6_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((SR) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (esc_chosen_1__i_1__0_n_0_a3b5146)))) recovered_6_q <= (esc_chosen_1__i_1__0_n_0_a3b5146);
  end

  // Reconstructed FDRE: esc_chosen_reg_2_a9a9265
  reg recovered_7_q = 1'b0;
  assign esc_chosen_reg_2__0_f7c16fe = recovered_7_q;
  wire recovered_7_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((SR) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (esc_chosen_2__i_1__0_n_0_65b92d1)))) recovered_7_q <= (esc_chosen_2__i_1__0_n_0_65b92d1);
  end

  // Reconstructed LUT6: esc_gen_master_slots_0__w_issuing_cnt_0__i_1_ff35b41
  assign esc_gen_master_slots_0__w_issuing_cnt_reg_1_c906b05 = ((w_issuing_cnt[0]) ? (((aa_mi_awtarget_hot[0]) ? (((m_axi_awready) ? (((esc_gen_master_slots_0__w_issuing_cnt_reg_0_55b6fcd) ? (esc_chosen_reg_0__0_db1ffe9) : (~(esc_chosen_reg_0__0_db1ffe9)))) : (esc_chosen_reg_0__0_db1ffe9))) : (esc_chosen_reg_0__0_db1ffe9))) : (((aa_mi_awtarget_hot[0]) ? (((m_axi_awready) ? (((esc_gen_master_slots_0__w_issuing_cnt_reg_0_55b6fcd) ? (((w_issuing_cnt[1]) ? (~(esc_chosen_reg_0__0_db1ffe9)) : (1'b0))) : (esc_chosen_reg_0__0_db1ffe9))) : (((w_issuing_cnt[1]) ? (~(esc_chosen_reg_0__0_db1ffe9)) : (1'b0))))) : (((w_issuing_cnt[1]) ? (~(esc_chosen_reg_0__0_db1ffe9)) : (1'b0))))));

  // Reconstructed LUT3: esc_gen_master_slots_0__w_issuing_cnt_1__i_2_b35c19f
  assign esc_chosen_reg_0__0_db1ffe9 = ((s_axi_bready) ? (((chosen41_in) ? (1'b1) : (~(esc_chosen_reg_0__1_a7d9131)))) : (1'b1));

  // Reconstructed LUT3: esc_gen_master_slots_1__w_issuing_cnt_11__i_4_8789bdd
  assign esc_s_axi_bready_0__0_3434b82 = ((E) ? (1'b1) : (((esc_chosen_reg_1__0_620be56) ? (~(s_axi_bready)) : (1'b1))));

  // Reconstructed LUT4: esc_gen_multi_thread_accept_cnt_1__i_1__0_e79ed58
  assign esc_gen_multi_thread_accept_cnt_reg_3_3e8a8a0 [0] = ((Q[1]) ? (((Q[0]) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (1'b1) : (~(esc_gen_multi_thread_accept_cnt_reg_1_ed65982)))) : (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (1'b0) : (esc_gen_multi_thread_accept_cnt_reg_1_ed65982))))) : (((Q[0]) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (1'b0) : (esc_gen_multi_thread_accept_cnt_reg_1_ed65982))) : (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (1'b1) : (~(esc_gen_multi_thread_accept_cnt_reg_1_ed65982)))))));

  // Reconstructed LUT5: esc_gen_multi_thread_accept_cnt_2__i_1__0_645e8be
  assign esc_gen_multi_thread_accept_cnt_reg_3_3e8a8a0 [1] = ((Q[1]) ? (((Q[2]) ? (((esc_gen_multi_thread_accept_cnt_reg_1_ed65982) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (1'b1) : (~(Q[0])))) : (1'b1))) : (((esc_gen_multi_thread_accept_cnt_reg_1_ed65982) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (1'b0) : (Q[0]))) : (1'b0))))) : (((Q[2]) ? (((esc_gen_multi_thread_accept_cnt_reg_1_ed65982) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (Q[0]) : (1'b1))) : (Q[0]))) : (((esc_gen_multi_thread_accept_cnt_reg_1_ed65982) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (~(Q[0])) : (1'b0))) : (~(Q[0])))))));

  // Reconstructed LUT6: esc_gen_multi_thread_accept_cnt_3__i_1__0_c1c3efa
  assign esc_gen_multi_thread_accept_cnt_reg_2_8143b78 = ((esc_gen_multi_thread_accept_cnt_reg_1_ed65982) ? (~(esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926)) : (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((Q[0]) ? (1'b1) : (((Q[1]) ? (1'b1) : (((Q[3]) ? (1'b1) : (Q[2]))))))) : (1'b0))));

  // Reconstructed LUT6: esc_gen_multi_thread_accept_cnt_3__i_2__0_4e47b7a
  assign esc_gen_multi_thread_accept_cnt_reg_3_3e8a8a0 [2] = ((Q[2]) ? (((esc_gen_multi_thread_accept_cnt_reg_1_ed65982) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (Q[3]) : (((Q[0]) ? (((Q[1]) ? (~(Q[3])) : (Q[3]))) : (Q[3]))))) : (Q[3]))) : (((esc_gen_multi_thread_accept_cnt_reg_1_ed65982) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((Q[0]) ? (Q[3]) : (((Q[1]) ? (Q[3]) : (~(Q[3])))))) : (Q[3]))) : (((Q[0]) ? (Q[3]) : (((Q[1]) ? (Q[3]) : (~(Q[3])))))))));

  // Reconstructed LUT4: esc_gen_multi_thread_active_cnt_11__i_1__0_146f451
  assign esc_gen_multi_thread_active_cnt_reg_8_8455e33 = ((esc_gen_multi_thread_cmd_push_1_87888fa) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_10__0_041afb5) ? (~(esc_gen_multi_thread_active_cnt_reg_10_aa6bc77)) : (1'b1))) : (1'b1))) : (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_10__0_041afb5) ? (esc_gen_multi_thread_active_cnt_reg_10_aa6bc77) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: esc_gen_multi_thread_active_cnt_19__i_1__0_0bb7e03
  assign esc_gen_multi_thread_active_cnt_reg_19_d0476bf = ((esc_gen_multi_thread_cmd_push_2_520dcd2) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_18__0_364a565) ? (esc_gen_multi_thread_active_cnt_reg_18_fd99d72) : (1'b1))) : (1'b1))) : (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_18__0_364a565) ? (~(esc_gen_multi_thread_active_cnt_reg_18_fd99d72)) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: esc_gen_multi_thread_active_cnt_27__i_1__0_0c9b154
  assign esc_gen_multi_thread_active_cnt_reg_27_ae45a7f = ((esc_gen_multi_thread_cmd_push_3_18de08c) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_26__0_a520897) ? (esc_gen_multi_thread_active_cnt_reg_26_ff68a00) : (1'b1))) : (1'b1))) : (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_26__0_a520897) ? (~(esc_gen_multi_thread_active_cnt_reg_26_ff68a00)) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: esc_gen_multi_thread_active_cnt_35__i_1__0_ff807a2
  assign esc_gen_multi_thread_active_cnt_reg_35_918f06b = ((esc_gen_multi_thread_cmd_push_4_14ecfd5) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_34__0_89ffb86) ? (esc_gen_multi_thread_active_cnt_reg_34_f21a0c7) : (1'b1))) : (1'b1))) : (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_34__0_89ffb86) ? (~(esc_gen_multi_thread_active_cnt_reg_34_f21a0c7)) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: esc_gen_multi_thread_active_cnt_3__i_1__0_2365dc8
  assign esc_s_axi_bready_0_6776e19 = ((esc_gen_multi_thread_active_cnt_reg_2__0_6abe1f0) ? (((CO) ? (((esc_gen_multi_thread_active_cnt_reg_2_d9d8f7c) ? (1'b1) : (~(esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926)))) : (1'b1))) : (((CO) ? (((esc_gen_multi_thread_active_cnt_reg_2_d9d8f7c) ? (1'b0) : (esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926))) : (1'b0))));

  // Reconstructed LUT4: esc_gen_multi_thread_active_cnt_43__i_1__0_5409386
  assign esc_gen_multi_thread_active_cnt_reg_43_12e6e9f = ((esc_gen_multi_thread_cmd_push_5_915e4e1) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_42__0_f1bf799) ? (esc_gen_multi_thread_active_cnt_reg_42_cf2b36c) : (1'b1))) : (1'b1))) : (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_42__0_f1bf799) ? (~(esc_gen_multi_thread_active_cnt_reg_42_cf2b36c)) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: esc_gen_multi_thread_active_cnt_51__i_1__0_3a4bfbc
  assign esc_gen_multi_thread_active_cnt_reg_51_0dd34c8 = ((esc_gen_multi_thread_cmd_push_6_03443fb) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_50__0_5520c48) ? (esc_gen_multi_thread_active_cnt_reg_50_5130782) : (1'b1))) : (1'b1))) : (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_50__0_5520c48) ? (~(esc_gen_multi_thread_active_cnt_reg_50_5130782)) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: esc_gen_multi_thread_active_cnt_59__i_1__0_b8839f1
  assign esc_gen_multi_thread_active_cnt_reg_56_c509015 = ((esc_gen_multi_thread_cmd_push_7_5ddb345) ? (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_58__0_186cc7e) ? (~(esc_gen_multi_thread_active_cnt_reg_58_573cc6a)) : (1'b1))) : (1'b1))) : (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (((esc_gen_multi_thread_active_cnt_reg_58__0_186cc7e) ? (esc_gen_multi_thread_active_cnt_reg_58_573cc6a) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_gen_multi_thread_active_cnt_59__i_3__0_36a7cd3
  assign esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926 = ((esc_gen_multi_thread_accept_cnt_reg_3__0_7ef0d65) ? (((chosen40_in) ? (s_axi_bready) : (((esc_chosen_reg_2__0_f7c16fe) ? (1'b0) : (s_axi_bready))))) : (((chosen40_in) ? (((esc_chosen_reg_0__1_a7d9131) ? (((chosen41_in) ? (1'b0) : (s_axi_bready))) : (1'b0))) : (((esc_chosen_reg_2__0_f7c16fe) ? (s_axi_bready) : (((esc_chosen_reg_0__1_a7d9131) ? (((chosen41_in) ? (1'b0) : (s_axi_bready))) : (1'b0))))))));

  // Reconstructed LUT5: esc_gen_no_arbiter_m_target_hot_i_2__i_16_5f5887c
  assign esc_gen_no_arbiter_m_target_hot_i_2__i_16_n_0_0ad4422 = ((w_issuing_cnt[2]) ? (((s_axi_bready) ? (((chosen40_in) ? (1'b1) : (((esc_chosen_reg_2__0_f7c16fe) ? (esc_gen_no_arbiter_m_target_hot_i_2__i_8_1_bdc7251) : (1'b1))))) : (1'b1))) : (esc_gen_no_arbiter_m_target_hot_i_2__i_8_1_bdc7251));

  // Reconstructed LUT6: esc_gen_no_arbiter_m_target_hot_i_2__i_17_e6238c3
  assign esc_gen_no_arbiter_m_target_hot_i_2__i_17_n_0_96d9058 = ((esc_gen_no_arbiter_m_target_hot_i_2__i_8_0_813c3b8) ? (1'b1) : (((esc_gen_multi_thread_active_cnt_59__i_3__0_n_0_4122926) ? (1'b0) : (((Q[3]) ? (((Q[2]) ? (1'b0) : (((Q[1]) ? (1'b0) : (~(Q[0])))))) : (1'b0))))));

  // Reconstructed LUT5: esc_gen_no_arbiter_m_target_hot_i_2__i_1__0_94bf66f
  assign aresetn_d_reg_0 = ((aa_mi_awtarget_hot[1]) ? (((aresetn_d) ? (((m_valid_i) ? (((st_aa_awtarget_hot) ? (1'b0) : (~(D)))) : (1'b1))) : (1'b1))) : (((aresetn_d) ? (((m_valid_i) ? (((st_aa_awtarget_hot) ? (1'b0) : (~(D)))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_gen_no_arbiter_m_target_hot_i_2__i_2_3d98d57
  assign m_valid_i = ((esc_gen_no_arbiter_m_target_hot_i_2__i_8_n_0_eb48ae0) ? (1'b0) : (((esc_gen_no_arbiter_m_target_hot_i_reg_2__3_bd1b2c1) ? (1'b0) : (((esc_gen_no_arbiter_m_target_hot_i_reg_2__2_6833a62) ? (1'b0) : (((esc_gen_no_arbiter_m_target_hot_i_reg_2__1_13cbb8a) ? (1'b0) : (((esc_gen_no_arbiter_m_target_hot_i_reg_2__0_c43d162) ? (~(esc_gen_no_arbiter_m_target_hot_i_reg_2_e9c3b41)) : (1'b0))))))))));

  // Reconstructed LUT6: esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d
  assign esc_gen_no_arbiter_m_target_hot_i_2__i_8_n_0_eb48ae0 = ((esc_gen_no_arbiter_m_target_hot_i_2__i_17_n_0_96d9058) ? (1'b1) : (((esc_gen_no_arbiter_m_target_hot_i_2__i_16_n_0_0ad4422) ? (((D) ? (((esc_gen_no_arbiter_m_target_hot_i_2__i_2_1_2159265) ? (((st_aa_awtarget_hot) ? (esc_gen_no_arbiter_m_target_hot_i_2__i_2_0_d8d5244) : (1'b1))) : (1'b0))) : (((st_aa_awtarget_hot) ? (esc_gen_no_arbiter_m_target_hot_i_2__i_2_0_d8d5244) : (1'b1))))) : (1'b0))));

  // Reconstructed LUT2: esc_gen_no_arbiter_s_ready_i_0__i_1__0_3c8942c
  assign aresetn_d_reg = ((aresetn_d) ? (m_valid_i) : (1'b0));

  // Reconstructed LUT5: esc_last_rr_hot_0__i_1__0_222f66e
  assign esc_last_rr_hot_0__i_1__0_n_0_0e63a71 = ((esc_last_rr_hot_reg_n_0__0_df186df) ? (((next_rr_hot[0]) ? (1'b1) : (((next_rr_hot[1]) ? (~(need_arbitration)) : (((next_rr_hot[2]) ? (~(need_arbitration)) : (1'b1))))))) : (((next_rr_hot[0]) ? (need_arbitration) : (1'b0))));

  // Reconstructed LUT5: esc_last_rr_hot_1__i_1__0_dbf700a
  assign esc_last_rr_hot_1__i_1__0_n_0_fb27d0b = ((p_3_in) ? (((next_rr_hot[0]) ? (((next_rr_hot[1]) ? (1'b1) : (~(need_arbitration)))) : (((next_rr_hot[1]) ? (1'b1) : (((next_rr_hot[2]) ? (~(need_arbitration)) : (1'b1))))))) : (((next_rr_hot[1]) ? (need_arbitration) : (1'b0))));

  // Reconstructed LUT5: esc_last_rr_hot_2__i_1__0_07e5336
  assign esc_last_rr_hot_2__i_1__0_n_0_9e1aecd = ((p_4_in) ? (((next_rr_hot[0]) ? (((next_rr_hot[2]) ? (1'b1) : (~(need_arbitration)))) : (((next_rr_hot[1]) ? (((next_rr_hot[2]) ? (1'b1) : (~(need_arbitration)))) : (1'b1))))) : (((next_rr_hot[2]) ? (need_arbitration) : (1'b0))));

  // Reconstructed LUT6: esc_last_rr_hot_2__i_2__0_524869b
  assign need_arbitration = ((s_axi_bready) ? (((chosen41_in) ? (((esc_last_rr_hot_2__i_6_n_0_0da4f1d) ? (((chosen40_in) ? (~(E)) : (1'b1))) : (1'b1))) : (1'b1))) : (((chosen41_in) ? (((esc_last_rr_hot_2__i_6_n_0_0da4f1d) ? (((chosen40_in) ? (~(E)) : (1'b1))) : (1'b0))) : (((esc_chosen_reg_0__1_a7d9131) ? (1'b0) : (esc_last_rr_hot_2__i_6_n_0_0da4f1d))))));

  // Reconstructed LUT6: esc_last_rr_hot_2__i_3__0_b9e3ee1
  assign next_rr_hot[2] = ((esc_last_rr_hot_reg_n_0__0_df186df) ? (((E) ? (~(chosen40_in)) : (((p_3_in) ? (~(chosen40_in)) : (1'b0))))) : (((chosen41_in) ? (((p_4_in) ? (((E) ? (~(chosen40_in)) : (((p_3_in) ? (~(chosen40_in)) : (1'b0))))) : (((p_3_in) ? (~(chosen40_in)) : (1'b0))))) : (((p_3_in) ? (~(chosen40_in)) : (1'b0))))));

  // Reconstructed LUT6: esc_last_rr_hot_2__i_4__0_50cd505
  assign next_rr_hot[1] = ((esc_last_rr_hot_reg_n_0__0_df186df) ? (~(E)) : (((p_3_in) ? (((chosen40_in) ? (((chosen41_in) ? (~(E)) : (1'b0))) : (((p_4_in) ? (((chosen41_in) ? (~(E)) : (1'b0))) : (1'b0))))) : (((p_4_in) ? (((chosen41_in) ? (~(E)) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT6: esc_last_rr_hot_2__i_5__0_33c6bbd
  assign next_rr_hot[0] = ((p_4_in) ? (~(chosen41_in)) : (((p_3_in) ? (((chosen40_in) ? (~(chosen41_in)) : (1'b0))) : (((chosen40_in) ? (((E) ? (((esc_last_rr_hot_reg_n_0__0_df186df) ? (~(chosen41_in)) : (1'b0))) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT4: esc_last_rr_hot_2__i_6_35c5551
  assign esc_last_rr_hot_2__i_6_n_0_0da4f1d = ((E) ? (((chosen40_in) ? (1'b1) : (~(esc_chosen_reg_2__0_f7c16fe)))) : (((esc_chosen_reg_1__0_620be56) ? (1'b0) : (((chosen40_in) ? (1'b1) : (~(esc_chosen_reg_2__0_f7c16fe)))))));

  // Reconstructed FDRE: esc_last_rr_hot_reg_0_b00b3ee
  reg recovered_38_q = 1'b0;
  assign esc_last_rr_hot_reg_n_0__0_df186df = recovered_38_q;
  wire recovered_38_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_38_reset || (((SR) === 1'bx) && (recovered_38_q == 1'b0))) recovered_38_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_38_q == (esc_last_rr_hot_0__i_1__0_n_0_0e63a71)))) recovered_38_q <= (esc_last_rr_hot_0__i_1__0_n_0_0e63a71);
  end

  // Reconstructed FDRE: esc_last_rr_hot_reg_1_6b93826
  reg recovered_39_q = 1'b0;
  assign p_3_in = recovered_39_q;
  wire recovered_39_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_39_reset || (((SR) === 1'bx) && (recovered_39_q == 1'b0))) recovered_39_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_39_q == (esc_last_rr_hot_1__i_1__0_n_0_fb27d0b)))) recovered_39_q <= (esc_last_rr_hot_1__i_1__0_n_0_fb27d0b);
  end

  // Reconstructed FDSE: esc_last_rr_hot_reg_2_a8c4e3e
  reg recovered_40_q = 1'b1;
  assign p_4_in = recovered_40_q;
  wire recovered_40_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_40_reset || (((SR) === 1'bx) && (recovered_40_q == 1'b1))) recovered_40_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_40_q == (esc_last_rr_hot_2__i_1__0_n_0_9e1aecd)))) recovered_40_q <= (esc_last_rr_hot_2__i_1__0_n_0_9e1aecd);
  end

  // Reconstructed LUT6: esc_s_axi_bvalid_0__INST_0_ee257ff
  assign s_axi_bvalid = ((E) ? (((chosen40_in) ? (((esc_chosen_reg_0__1_a7d9131) ? (~(chosen41_in)) : (1'b0))) : (((esc_chosen_reg_2__0_f7c16fe) ? (1'b1) : (((esc_chosen_reg_0__1_a7d9131) ? (~(chosen41_in)) : (1'b0))))))) : (((esc_chosen_reg_1__0_620be56) ? (1'b1) : (((chosen40_in) ? (((esc_chosen_reg_0__1_a7d9131) ? (~(chosen41_in)) : (1'b0))) : (((esc_chosen_reg_2__0_f7c16fe) ? (1'b1) : (((esc_chosen_reg_0__1_a7d9131) ? (~(chosen41_in)) : (1'b0))))))))));

endmodule

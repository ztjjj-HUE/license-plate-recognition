// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_crossbar_v2_1_23_splitter
   (s_ready_i_reg,
    m_ready_d,
    .s_axi_awvalid_0_sp_1(s_axi_awvalid_0_sn_1),
    ss_wr_awready,
    ss_aa_awready,
    s_axi_awvalid,
    aresetn_d,
    aclk);
  output s_ready_i_reg;
  output [1:0]m_ready_d;
  input ss_wr_awready;
  input ss_aa_awready;
  input [0:0]s_axi_awvalid;
  input aresetn_d;
  input aclk;
  output s_axi_awvalid_0_sn_1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire aclk;
  wire aresetn_d;
  wire [1:0]m_ready_d;
  wire esc_m_ready_d_0__i_1_n_0_0b931db ;
  wire esc_m_ready_d_1__i_1_n_0_aafc7eb ;
  wire [0:0]s_axi_awvalid;
  wire s_axi_awvalid_0_sn_1;
  wire s_ready_i_reg;
  wire ss_aa_awready;
  wire ss_wr_awready;

  // Reconstructed LUT2: esc_FSM_onehot_state_1__i_4_c93c46d
  assign s_axi_awvalid_0_sn_1 = ((m_ready_d[1]) ? (1'b0) : (s_axi_awvalid));

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_m_ready_d_0__i_1_bc9ee7e
  assign esc_m_ready_d_0__i_1_n_0_0b931db = ((m_ready_d[0]) ? (((m_ready_d[1]) ? (1'b0) : (((ss_wr_awready) ? (1'b0) : (aresetn_d))))) : (((ss_aa_awready) ? (((m_ready_d[1]) ? (1'b0) : (((ss_wr_awready) ? (1'b0) : (((aresetn_d) ? (s_axi_awvalid) : (1'b0))))))) : (1'b0))));

  // Reconstructed LUT6: esc_m_ready_d_1__i_1_17d9d3e
  assign esc_m_ready_d_1__i_1_n_0_aafc7eb = ((m_ready_d[0]) ? (1'b0) : (((ss_aa_awready) ? (1'b0) : (((m_ready_d[1]) ? (aresetn_d) : (((ss_wr_awready) ? (((aresetn_d) ? (s_axi_awvalid) : (1'b0))) : (1'b0))))))));

  // Reconstructed FDRE: esc_m_ready_d_reg_0_0b6f615
  reg recovered_6_q = 1'b0;
  assign m_ready_d[0] = recovered_6_q;
  wire recovered_6_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (esc_m_ready_d_0__i_1_n_0_0b931db)))) recovered_6_q <= (esc_m_ready_d_0__i_1_n_0_0b931db);
  end

  // Reconstructed FDRE: esc_m_ready_d_reg_1_9138ab7
  reg recovered_7_q = 1'b0;
  assign m_ready_d[1] = recovered_7_q;
  wire recovered_7_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (esc_m_ready_d_1__i_1_n_0_aafc7eb)))) recovered_7_q <= (esc_m_ready_d_1__i_1_n_0_aafc7eb);
  end

  // Reconstructed LUT4: esc_s_axi_awready_0__INST_0_9d5725f
  assign s_ready_i_reg = ((m_ready_d[0]) ? (((m_ready_d[1]) ? (1'b1) : (ss_wr_awready))) : (((ss_aa_awready) ? (((m_ready_d[1]) ? (1'b1) : (ss_wr_awready))) : (1'b0))));

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_crossbar_v2_1_23_splitter_3
   (esc_m_ready_d_reg_1__0_09b2d76 ,
    m_ready_d,
    p_1_in,
    aresetn_d,
    esc_m_ready_d_reg_1__1_9c52823 ,
    esc_m_ready_d_reg_1__2_5a7996c ,
    aa_mi_awtarget_hot,
    esc_m_ready_d_reg_0__0_e29ee0b ,
    aclk);
  output esc_m_ready_d_reg_1__0_09b2d76 ;
  output [1:0]m_ready_d;
  input p_1_in;
  input aresetn_d;
  input esc_m_ready_d_reg_1__1_9c52823 ;
  input esc_m_ready_d_reg_1__2_5a7996c ;
  input [2:0]aa_mi_awtarget_hot;
  input esc_m_ready_d_reg_0__0_e29ee0b ;
  input aclk;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [2:0]aa_mi_awtarget_hot;
  wire aclk;
  wire aresetn_d;
  wire [1:0]m_ready_d;
  wire esc_m_ready_d_0__i_1_n_0_0b931db ;
  wire esc_m_ready_d_1__i_1_n_0_aafc7eb ;
  wire esc_m_ready_d_reg_0__0_e29ee0b ;
  wire esc_m_ready_d_reg_1__0_09b2d76 ;
  wire esc_m_ready_d_reg_1__1_9c52823 ;
  wire esc_m_ready_d_reg_1__2_5a7996c ;
  wire p_1_in;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT2: esc_gen_master_slots_1__w_issuing_cnt_9__i_2_7e9d30e
  assign esc_m_ready_d_reg_1__0_09b2d76 = ((p_1_in) ? (1'b1) : (m_ready_d[1]));

  // Reconstructed LUT6: esc_m_ready_d_0__i_1_bc9ee7e
  assign esc_m_ready_d_0__i_1_n_0_0b931db = ((esc_m_ready_d_reg_0__0_e29ee0b) ? (1'b0) : (((aa_mi_awtarget_hot[0]) ? (((m_ready_d[0]) ? (1'b1) : (~(p_1_in)))) : (((aa_mi_awtarget_hot[1]) ? (((m_ready_d[0]) ? (1'b1) : (~(p_1_in)))) : (((aa_mi_awtarget_hot[2]) ? (((m_ready_d[0]) ? (1'b1) : (~(p_1_in)))) : (m_ready_d[0]))))))));

  // Reconstructed LUT5: esc_m_ready_d_1__i_1_17d9d3e
  assign esc_m_ready_d_1__i_1_n_0_aafc7eb = ((esc_m_ready_d_reg_1__2_5a7996c) ? (((esc_m_ready_d_reg_1__1_9c52823) ? (((aresetn_d) ? (((m_ready_d[1]) ? (1'b1) : (~(p_1_in)))) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_m_ready_d_reg_0_0b6f615
  reg recovered_6_q = 1'b0;
  assign m_ready_d[0] = recovered_6_q;
  wire recovered_6_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (esc_m_ready_d_0__i_1_n_0_0b931db)))) recovered_6_q <= (esc_m_ready_d_0__i_1_n_0_0b931db);
  end

  // Reconstructed FDRE: esc_m_ready_d_reg_1_9138ab7
  reg recovered_7_q = 1'b0;
  assign m_ready_d[1] = recovered_7_q;
  wire recovered_7_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (esc_m_ready_d_1__i_1_n_0_aafc7eb)))) recovered_7_q <= (esc_m_ready_d_1__i_1_n_0_aafc7eb);
  end

endmodule

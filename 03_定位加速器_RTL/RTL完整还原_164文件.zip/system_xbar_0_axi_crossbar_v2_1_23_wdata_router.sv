// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_crossbar_v2_1_23_wdata_router
   (ss_wr_awready,
    m_axi_wvalid,
    m_valid_i_reg,
    s_axi_wready,
    st_aa_awtarget_hot,
    aclk,
    D,
    SR,
    s_axi_awvalid,
    m_ready_d,
    esc_FSM_onehot_state_reg_1_070266a ,
    s_axi_wvalid,
    s_axi_wlast,
    esc_FSM_onehot_gen_axi_write_cs_reg_2_4d655b4 ,
    m_axi_wready,
    mi_wready_2,
    esc_storage_data1_reg_0_3e8f598 );
  output ss_wr_awready;
  output [1:0]m_axi_wvalid;
  output m_valid_i_reg;
  output [0:0]s_axi_wready;
  input [1:0]st_aa_awtarget_hot;
  input aclk;
  input [0:0]D;
  input [0:0]SR;
  input [0:0]s_axi_awvalid;
  input [0:0]m_ready_d;
  input esc_FSM_onehot_state_reg_1_070266a ;
  input [0:0]s_axi_wvalid;
  input [0:0]s_axi_wlast;
  input esc_FSM_onehot_gen_axi_write_cs_reg_2_4d655b4 ;
  input [1:0]m_axi_wready;
  input mi_wready_2;
  input esc_storage_data1_reg_0_3e8f598 ;

  wire [0:0]D;
  wire esc_FSM_onehot_gen_axi_write_cs_reg_2_4d655b4 ;
  wire esc_FSM_onehot_state_reg_1_070266a ;
  wire [0:0]SR;
  wire aclk;
  wire [1:0]m_axi_wready;
  wire [1:0]m_axi_wvalid;
  wire [0:0]m_ready_d;
  wire m_valid_i_reg;
  wire mi_wready_2;
  wire [0:0]s_axi_awvalid;
  wire [0:0]s_axi_wlast;
  wire [0:0]s_axi_wready;
  wire [0:0]s_axi_wvalid;
  wire ss_wr_awready;
  wire [1:0]st_aa_awtarget_hot;
  wire esc_storage_data1_reg_0_3e8f598 ;

  system_xbar_0_axi_data_fifo_v2_1_21_axic_reg_srl_fifo wrouter_aw_fifo
       (.D(D),
        .esc_FSM_onehot_gen_axi_write_cs_reg_2_4d655b4 (esc_FSM_onehot_gen_axi_write_cs_reg_2_4d655b4 ),
        .esc_FSM_onehot_state_reg_1__0_2261399 (esc_FSM_onehot_state_reg_1_070266a ),
        .SR(SR),
        .aclk(aclk),
        .m_axi_wready(m_axi_wready),
        .m_axi_wvalid(m_axi_wvalid),
        .m_ready_d(m_ready_d),
        .m_valid_i_reg_0(m_valid_i_reg),
        .mi_wready_2(mi_wready_2),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wready(s_axi_wready),
        .s_axi_wvalid(s_axi_wvalid),
        .s_ready_i_reg_0(ss_wr_awready),
        .st_aa_awtarget_hot(st_aa_awtarget_hot),
        .esc_storage_data1_reg_0__0_22cc170 (esc_storage_data1_reg_0_3e8f598 ));
endmodule

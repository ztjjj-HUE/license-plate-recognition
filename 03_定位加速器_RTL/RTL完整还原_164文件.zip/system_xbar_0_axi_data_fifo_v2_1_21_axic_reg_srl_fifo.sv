// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_data_fifo_v2_1_21_axic_reg_srl_fifo
   (s_ready_i_reg_0,
    m_axi_wvalid,
    m_valid_i_reg_0,
    s_axi_wready,
    st_aa_awtarget_hot,
    aclk,
    D,
    SR,
    s_axi_awvalid,
    m_ready_d,
    esc_FSM_onehot_state_reg_1__0_2261399 ,
    s_axi_wvalid,
    s_axi_wlast,
    esc_FSM_onehot_gen_axi_write_cs_reg_2_4d655b4 ,
    m_axi_wready,
    mi_wready_2,
    esc_storage_data1_reg_0__0_22cc170 );
  output s_ready_i_reg_0;
  output [1:0]m_axi_wvalid;
  output m_valid_i_reg_0;
  output [0:0]s_axi_wready;
  input [1:0]st_aa_awtarget_hot;
  input aclk;
  input [0:0]D;
  input [0:0]SR;
  input [0:0]s_axi_awvalid;
  input [0:0]m_ready_d;
  input esc_FSM_onehot_state_reg_1__0_2261399 ;
  input [0:0]s_axi_wvalid;
  input [0:0]s_axi_wlast;
  input esc_FSM_onehot_gen_axi_write_cs_reg_2_4d655b4 ;
  input [1:0]m_axi_wready;
  input mi_wready_2;
  input esc_storage_data1_reg_0__0_22cc170 ;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]D;
  wire esc_FSM_onehot_gen_axi_write_cs_reg_2_4d655b4 ;
  wire esc_FSM_onehot_state_0__i_1_n_0_78643ea ;
  wire esc_FSM_onehot_state_1__i_1_n_0_6912413 ;
  wire esc_FSM_onehot_state_1__i_2_n_0_4bafa4f ;
  wire esc_FSM_onehot_state_1__i_3_n_0_5dba949 ;
  wire esc_FSM_onehot_state_3__i_2_n_0_675d89d ;
  wire esc_FSM_onehot_state_reg_1__0_2261399 ;
  wire esc_FSM_onehot_state_reg_n_0__0_ee5cad1 ;
  wire [0:0]SR;
  wire aclk;
  wire areset_d1;
  wire [2:0]fifoaddr;
  wire esc_gen_rep_0__fifoaddr_0__i_1_n_0_f91a071 ;
  wire esc_gen_rep_0__fifoaddr_0__i_2_n_0_39cade9 ;
  wire esc_gen_rep_0__fifoaddr_1__i_1_n_0_b55aa70 ;
  wire esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46 ;
  wire esc_gen_srls_0__gen_rep_1__srl_nx1_n_1_ef61234 ;
  wire esc_gen_srls_0__gen_rep_1__srl_nx1_n_2_f364b1e ;
  wire esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716 ;
  wire load_s1;
  wire m_avalid;
  wire [1:0]m_axi_wready;
  wire [1:0]m_axi_wvalid;
  wire [0:0]m_ready_d;
  wire m_valid_i;
  wire m_valid_i_i_1__1_n_0;
  wire m_valid_i_reg_0;
  wire mi_wready_2;
  wire p_0_in8_in;
  wire p_9_in;
  wire push;
  wire [0:0]s_axi_awvalid;
  wire [0:0]s_axi_wlast;
  wire [0:0]s_axi_wready;
  wire [0:0]s_axi_wvalid;
  wire s_ready_i_i_1__2_n_0;
  wire s_ready_i_i_2_n_0;
  wire s_ready_i_reg_0;
  wire [1:0]st_aa_awtarget_hot;
  wire esc_storage_data1_0__i_1_n_0_a6b7fdb ;
  wire esc_storage_data1_reg_0__0_22cc170 ;
  wire esc_storage_data1_reg_n_0__0_0c2301c ;
  wire esc_storage_data1_reg_n_0__1_bf099e9 ;
  wire [0:0]storage_data2;

  // Reconstructed LUT6: esc_FSM_onehot_gen_axi_write_cs_2__i_2_8a05424
  assign m_valid_i_reg_0 = ((esc_storage_data1_reg_n_0__1_bf099e9) ? (((esc_storage_data1_reg_n_0__0_0c2301c) ? (1'b0) : (((esc_FSM_onehot_gen_axi_write_cs_reg_2_4d655b4) ? (((s_axi_wlast) ? (((s_axi_wvalid) ? (m_avalid) : (1'b0))) : (1'b0))) : (1'b0))))) : (1'b0));

  // Reconstructed LUT4: esc_FSM_onehot_state_0__i_1_a03811a
  assign esc_FSM_onehot_state_0__i_1_n_0_78643ea = ((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (p_0_in8_in) : (((m_ready_d) ? (1'b0) : (((s_axi_awvalid) ? (p_0_in8_in) : (1'b0))))));

  // Reconstructed LUT6: esc_FSM_onehot_state_1__i_1_c672e6d
  assign esc_FSM_onehot_state_1__i_1_n_0_6912413 = ((s_ready_i_reg_0) ? (((esc_FSM_onehot_state_reg_1__0_2261399) ? (p_9_in) : (((esc_FSM_onehot_state_1__i_3_n_0_5dba949) ? (((esc_FSM_onehot_state_1__i_2_n_0_4bafa4f) ? (1'b0) : (~(fifoaddr[2])))) : (1'b0))))) : (((esc_FSM_onehot_state_reg_1__0_2261399) ? (((esc_FSM_onehot_state_1__i_3_n_0_5dba949) ? (((esc_FSM_onehot_state_1__i_2_n_0_4bafa4f) ? (p_9_in) : (((fifoaddr[2]) ? (p_9_in) : (1'b1))))) : (p_9_in))) : (((esc_FSM_onehot_state_1__i_3_n_0_5dba949) ? (((esc_FSM_onehot_state_1__i_2_n_0_4bafa4f) ? (1'b0) : (~(fifoaddr[2])))) : (1'b0))))));

  // Reconstructed LUT2: esc_FSM_onehot_state_1__i_2_1d1cfc1
  assign esc_FSM_onehot_state_1__i_2_n_0_4bafa4f = ((fifoaddr[0]) ? (1'b1) : (fifoaddr[1]));

  // Reconstructed LUT2: esc_FSM_onehot_state_1__i_3_03b4cda
  assign esc_FSM_onehot_state_1__i_3_n_0_5dba949 = ((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (1'b0) : (esc_FSM_onehot_state_reg_n_0__0_ee5cad1));

  // Reconstructed LUT5: esc_FSM_onehot_state_3__i_1_64a1985
  assign m_valid_i = ((p_0_in8_in) ? (((m_ready_d) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (esc_FSM_onehot_state_1__i_1_n_0_6912413) : (1'b1))) : (((s_axi_awvalid) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (1'b1) : (esc_FSM_onehot_state_1__i_1_n_0_6912413))) : (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (esc_FSM_onehot_state_1__i_1_n_0_6912413) : (1'b1))))))) : (esc_FSM_onehot_state_1__i_1_n_0_6912413));

  // Reconstructed LUT4: esc_FSM_onehot_state_3__i_2_40b6139
  assign esc_FSM_onehot_state_3__i_2_n_0_675d89d = ((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (1'b0) : (((m_ready_d) ? (p_0_in8_in) : (((s_axi_awvalid) ? (1'b0) : (p_0_in8_in))))));

  // Reconstructed FDRE: esc_FSM_onehot_state_reg_0_536fb89
  reg recovered_8_q = 1'b0;
  assign esc_FSM_onehot_state_reg_n_0__0_ee5cad1 = recovered_8_q;
  wire recovered_8_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_8_reset || (((areset_d1) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_8_q == (esc_FSM_onehot_state_0__i_1_n_0_78643ea)))) recovered_8_q <= (esc_FSM_onehot_state_0__i_1_n_0_78643ea);
  end

  // Reconstructed FDRE: esc_FSM_onehot_state_reg_1_070266a
  reg recovered_9_q = 1'b0;
  assign p_0_in8_in = recovered_9_q;
  wire recovered_9_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((areset_d1) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_9_q == (esc_FSM_onehot_state_1__i_1_n_0_6912413)))) recovered_9_q <= (esc_FSM_onehot_state_1__i_1_n_0_6912413);
  end

  // Reconstructed FDSE: esc_FSM_onehot_state_reg_3_5c113c4
  reg recovered_10_q = 1'b1;
  assign p_9_in = recovered_10_q;
  wire recovered_10_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_10_reset || (((areset_d1) === 1'bx) && (recovered_10_q == 1'b1))) recovered_10_q <= 1'b1;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_10_q == (esc_FSM_onehot_state_3__i_2_n_0_675d89d)))) recovered_10_q <= (esc_FSM_onehot_state_3__i_2_n_0_675d89d);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed FDRE: areset_d1_reg
  reg recovered_13_q = 1'b0;
  assign areset_d1 = recovered_13_q;
  wire recovered_13_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_13_q == (SR)))) recovered_13_q <= (SR);
  end

  // Reconstructed LUT2: esc_gen_rep_0__fifoaddr_0__i_1_751ffbd
  assign esc_gen_rep_0__fifoaddr_0__i_1_n_0_f91a071 = ((fifoaddr[0]) ? (~(esc_gen_rep_0__fifoaddr_0__i_2_n_0_39cade9)) : (esc_gen_rep_0__fifoaddr_0__i_2_n_0_39cade9));

  // Reconstructed LUT6: esc_gen_rep_0__fifoaddr_0__i_2_57488c8
  assign esc_gen_rep_0__fifoaddr_0__i_2_n_0_39cade9 = ((p_0_in8_in) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (((m_ready_d) ? (1'b0) : (s_axi_awvalid))) : (((s_ready_i_reg_0) ? (((m_ready_d) ? (esc_FSM_onehot_state_reg_n_0__0_ee5cad1) : (((s_axi_awvalid) ? (1'b0) : (esc_FSM_onehot_state_reg_n_0__0_ee5cad1))))) : (esc_FSM_onehot_state_reg_n_0__0_ee5cad1))))) : (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (((s_ready_i_reg_0) ? (((m_ready_d) ? (1'b0) : (((s_axi_awvalid) ? (esc_FSM_onehot_state_reg_n_0__0_ee5cad1) : (1'b0))))) : (1'b0))) : (((s_ready_i_reg_0) ? (((m_ready_d) ? (esc_FSM_onehot_state_reg_n_0__0_ee5cad1) : (((s_axi_awvalid) ? (1'b0) : (esc_FSM_onehot_state_reg_n_0__0_ee5cad1))))) : (esc_FSM_onehot_state_reg_n_0__0_ee5cad1))))));

  // Reconstructed LUT5: esc_gen_rep_0__fifoaddr_1__i_1_452a188
  assign esc_gen_rep_0__fifoaddr_1__i_1_n_0_b55aa70 = ((fifoaddr[1]) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_2_f364b1e) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (~(fifoaddr[0])) : (1'b1))) : (~(fifoaddr[0])))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (1'b1) : (fifoaddr[0]))) : (1'b1))))) : (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_2_f364b1e) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (fifoaddr[0]) : (1'b0))) : (fifoaddr[0]))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (1'b0) : (~(fifoaddr[0])))) : (1'b0))))));

  // Reconstructed LUT6: esc_gen_rep_0__fifoaddr_2__i_1_7a332c8
  assign esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46 = ((fifoaddr[2]) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_2_f364b1e) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (((fifoaddr[1]) ? (~(fifoaddr[0])) : (1'b1))) : (1'b1))) : (((fifoaddr[1]) ? (~(fifoaddr[0])) : (1'b1))))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (1'b1) : (((fifoaddr[1]) ? (1'b1) : (fifoaddr[0]))))) : (1'b1))))) : (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_2_f364b1e) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (((fifoaddr[1]) ? (fifoaddr[0]) : (1'b0))) : (1'b0))) : (((fifoaddr[1]) ? (fifoaddr[0]) : (1'b0))))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (1'b0) : (((fifoaddr[1]) ? (1'b0) : (~(fifoaddr[0])))))) : (1'b0))))));

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_0_2da314e
  reg recovered_18_q = 1'b1;
  assign fifoaddr[0] = recovered_18_q;
  wire recovered_18_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((SR) === 1'bx) && (recovered_18_q == 1'b1))) recovered_18_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_18_q == (esc_gen_rep_0__fifoaddr_0__i_1_n_0_f91a071)))) recovered_18_q <= (esc_gen_rep_0__fifoaddr_0__i_1_n_0_f91a071);
  end

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_1_9ffca33
  reg recovered_19_q = 1'b1;
  assign fifoaddr[1] = recovered_19_q;
  wire recovered_19_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((SR) === 1'bx) && (recovered_19_q == 1'b1))) recovered_19_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_19_q == (esc_gen_rep_0__fifoaddr_1__i_1_n_0_b55aa70)))) recovered_19_q <= (esc_gen_rep_0__fifoaddr_1__i_1_n_0_b55aa70);
  end

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_2_19f7d82
  reg recovered_20_q = 1'b1;
  assign fifoaddr[2] = recovered_20_q;
  wire recovered_20_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((SR) === 1'bx) && (recovered_20_q == 1'b1))) recovered_20_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_20_q == (esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46)))) recovered_20_q <= (esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46);
  end

  system_xbar_0_axi_data_fifo_v2_1_21_ndeep_srl__parameterized0 esc_gen_srls_0__gen_rep_0__srl_nx1_87f4823 
       (.aclk(aclk),
        .fifoaddr(fifoaddr),
        .push(push),
        .st_aa_awtarget_hot(st_aa_awtarget_hot[1]),
        .storage_data2(storage_data2));
  system_xbar_0_axi_data_fifo_v2_1_21_ndeep_srl__parameterized0_4 esc_gen_srls_0__gen_rep_1__srl_nx1_8532c48 
       (.D(D),
        .esc_FSM_onehot_state_3__i_3_0_e1ddfbb (esc_storage_data1_reg_n_0__0_0c2301c ),
        .esc_FSM_onehot_state_reg_0_536fb89 (esc_gen_srls_0__gen_rep_1__srl_nx1_n_1_ef61234 ),
        .esc_FSM_onehot_state_reg_1_070266a (esc_gen_srls_0__gen_rep_1__srl_nx1_n_2_f364b1e ),
        .Q({p_0_in8_in,esc_FSM_onehot_state_reg_n_0__0_ee5cad1 }),
        .aclk(aclk),
        .fifoaddr(fifoaddr),
        .load_s1(load_s1),
        .m_avalid(m_avalid),
        .m_axi_wready(m_axi_wready),
        .m_ready_d(m_ready_d),
        .m_valid_i_reg(esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716 ),
        .mi_wready_2(mi_wready_2),
        .push(push),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wvalid(s_axi_wvalid),
        .s_ready_i_reg(s_ready_i_reg_0),
        .st_aa_awtarget_hot(st_aa_awtarget_hot),
        .esc_storage_data1_reg_1_261ad78 (esc_storage_data1_reg_n_0__1_bf099e9 ));

  // Reconstructed LUT4: esc_m_axi_wvalid_0__INST_0_19e36b0
  assign m_axi_wvalid[0] = ((m_avalid) ? (((s_axi_wvalid) ? (((esc_storage_data1_reg_n_0__0_0c2301c) ? (1'b0) : (~(esc_storage_data1_reg_n_0__1_bf099e9)))) : (1'b0))) : (1'b0));

  // Reconstructed LUT4: esc_m_axi_wvalid_1__INST_0_7b0f35e
  assign m_axi_wvalid[1] = ((m_avalid) ? (((s_axi_wvalid) ? (((esc_storage_data1_reg_n_0__1_bf099e9) ? (1'b0) : (esc_storage_data1_reg_n_0__0_0c2301c))) : (1'b0))) : (1'b0));

  // Reconstructed LUT5: m_valid_i_i_1__1
  assign m_valid_i_i_1__1_n_0 = ((esc_FSM_onehot_state_1__i_1_n_0_6912413) ? (1'b1) : (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (((s_axi_awvalid) ? (((m_ready_d) ? (1'b0) : (p_0_in8_in))) : (1'b0))) : (1'b0))));

  // Reconstructed FDRE: m_valid_i_reg
  reg recovered_26_q = 1'b0;
  assign m_avalid = recovered_26_q;
  wire recovered_26_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_26_reset || (((areset_d1) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_26_q == (m_valid_i_i_1__1_n_0)))) recovered_26_q <= (m_valid_i_i_1__1_n_0);
  end

  // Reconstructed LUT6: esc_s_axi_wready_0__INST_0_c198ae5
  assign s_axi_wready = ((mi_wready_2) ? (((m_axi_wready[1]) ? (((esc_storage_data1_reg_n_0__0_0c2301c) ? (((esc_storage_data1_reg_n_0__1_bf099e9) ? (1'b0) : (m_avalid))) : (((esc_storage_data1_reg_n_0__1_bf099e9) ? (m_avalid) : (((m_axi_wready[0]) ? (m_avalid) : (1'b0))))))) : (((esc_storage_data1_reg_n_0__0_0c2301c) ? (1'b0) : (((esc_storage_data1_reg_n_0__1_bf099e9) ? (m_avalid) : (((m_axi_wready[0]) ? (m_avalid) : (1'b0))))))))) : (((m_axi_wready[1]) ? (((esc_storage_data1_reg_n_0__0_0c2301c) ? (((esc_storage_data1_reg_n_0__1_bf099e9) ? (1'b0) : (m_avalid))) : (((esc_storage_data1_reg_n_0__1_bf099e9) ? (1'b0) : (((m_axi_wready[0]) ? (m_avalid) : (1'b0))))))) : (((esc_storage_data1_reg_n_0__0_0c2301c) ? (1'b0) : (((esc_storage_data1_reg_n_0__1_bf099e9) ? (1'b0) : (((m_axi_wready[0]) ? (m_avalid) : (1'b0))))))))));

  // Reconstructed LUT6: s_ready_i_i_1__2
  assign s_ready_i_i_1__2_n_0 = ((s_ready_i_reg_0) ? (((fifoaddr[0]) ? (1'b1) : (((fifoaddr[1]) ? (((fifoaddr[2]) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_2_f364b1e) ? (s_ready_i_i_2_n_0) : (1'b1))) : (1'b1))) : (1'b1))))) : (s_ready_i_i_2_n_0));

  // Reconstructed LUT3: s_ready_i_i_2
  assign s_ready_i_i_2_n_0 = ((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (areset_d1) : (1'b1))) : (areset_d1));

  // Reconstructed FDRE: s_ready_i_reg
  reg recovered_30_q = 1'b0;
  assign s_ready_i_reg_0 = recovered_30_q;
  wire recovered_30_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_30_reset || (((SR) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_30_q == (s_ready_i_i_1__2_n_0)))) recovered_30_q <= (s_ready_i_i_1__2_n_0);
  end

  // Reconstructed LUT5: esc_storage_data1_0__i_1_5a0cbe8
  assign esc_storage_data1_0__i_1_n_0_a6b7fdb = ((esc_storage_data1_reg_n_0__0_0c2301c) ? (((load_s1) ? (((esc_storage_data1_reg_0__0_22cc170) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (storage_data2) : (1'b1))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (storage_data2) : (1'b0))))) : (1'b1))) : (((load_s1) ? (((esc_storage_data1_reg_0__0_22cc170) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (storage_data2) : (1'b1))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (storage_data2) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_storage_data1_1__i_2_a6c152d
  assign load_s1 = ((p_0_in8_in) ? (((m_ready_d) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (~(esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716)) : (1'b0))) : (((s_axi_awvalid) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (p_9_in) : (1'b1))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (~(esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716)) : (1'b0))))))) : (((m_ready_d) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (~(esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716)) : (1'b0))) : (((s_axi_awvalid) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716) ? (p_9_in) : (1'b1))) : (p_9_in))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (~(esc_gen_srls_0__gen_rep_1__srl_nx1_n_3_d435716)) : (1'b0))))))));

  // Reconstructed FDRE: esc_storage_data1_reg_0_3e8f598
  reg recovered_33_q = 1'b0;
  assign esc_storage_data1_reg_n_0__0_0c2301c = recovered_33_q;
  wire recovered_33_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_33_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_33_q == 1'b0))) recovered_33_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_33_q == (esc_storage_data1_0__i_1_n_0_a6b7fdb)))) recovered_33_q <= (esc_storage_data1_0__i_1_n_0_a6b7fdb);
  end

  // Reconstructed FDRE: esc_storage_data1_reg_1_261ad78
  reg recovered_34_q = 1'b0;
  assign esc_storage_data1_reg_n_0__1_bf099e9 = recovered_34_q;
  wire recovered_34_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_34_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_34_q == 1'b0))) recovered_34_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_34_q == (esc_gen_srls_0__gen_rep_1__srl_nx1_n_1_ef61234)))) recovered_34_q <= (esc_gen_srls_0__gen_rep_1__srl_nx1_n_1_ef61234);
  end

endmodule

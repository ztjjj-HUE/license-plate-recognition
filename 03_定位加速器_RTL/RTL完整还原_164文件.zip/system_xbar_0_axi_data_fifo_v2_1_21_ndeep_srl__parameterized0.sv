// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_data_fifo_v2_1_21_ndeep_srl__parameterized0
   (storage_data2,
    push,
    st_aa_awtarget_hot,
    fifoaddr,
    aclk);
  output [0:0]storage_data2;
  input push;
  input [0:0]st_aa_awtarget_hot;
  input [2:0]fifoaddr;
  input aclk;

  wire esc_const0_a0cf646 ;
  wire aclk;
  wire [2:0]fifoaddr;
  wire push;
  wire [0:0]st_aa_awtarget_hot;
  wire [0:0]storage_data2;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed SRL16E: esc_gen_primitive_shifter_gen_srls_0__srl_inst_44ed1e3
  reg [15:0] recovered_2_shift = 16'h0000;
  always @(posedge aclk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_2_shift <= {recovered_2_shift[14:0],st_aa_awtarget_hot};
  assign storage_data2 = recovered_2_shift[{esc_const0_a0cf646,fifoaddr[2],fifoaddr[1],fifoaddr[0]}];

endmodule

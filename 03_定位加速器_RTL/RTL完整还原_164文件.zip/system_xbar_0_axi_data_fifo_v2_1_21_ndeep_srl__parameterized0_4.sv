// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_data_fifo_v2_1_21_ndeep_srl__parameterized0_4
   (push,
    esc_FSM_onehot_state_reg_0_536fb89 ,
    esc_FSM_onehot_state_reg_1_070266a ,
    m_valid_i_reg,
    D,
    fifoaddr,
    aclk,
    st_aa_awtarget_hot,
    Q,
    load_s1,
    esc_storage_data1_reg_1_261ad78 ,
    s_ready_i_reg,
    m_ready_d,
    s_axi_awvalid,
    m_avalid,
    s_axi_wvalid,
    s_axi_wlast,
    mi_wready_2,
    m_axi_wready,
    esc_FSM_onehot_state_3__i_3_0_e1ddfbb );
  output push;
  output esc_FSM_onehot_state_reg_0_536fb89 ;
  output esc_FSM_onehot_state_reg_1_070266a ;
  output m_valid_i_reg;
  input [0:0]D;
  input [2:0]fifoaddr;
  input aclk;
  input [1:0]st_aa_awtarget_hot;
  input [1:0]Q;
  input load_s1;
  input esc_storage_data1_reg_1_261ad78 ;
  input s_ready_i_reg;
  input [0:0]m_ready_d;
  input [0:0]s_axi_awvalid;
  input m_avalid;
  input [0:0]s_axi_wvalid;
  input [0:0]s_axi_wlast;
  input mi_wready_2;
  input [1:0]m_axi_wready;
  input esc_FSM_onehot_state_3__i_3_0_e1ddfbb ;

  wire esc_const0_a0cf646 ;
  wire [0:0]D;
  wire esc_FSM_onehot_state_3__i_3_0_e1ddfbb ;
  wire esc_FSM_onehot_state_3__i_4_n_0_f65af67 ;
  wire esc_FSM_onehot_state_reg_0_536fb89 ;
  wire [1:0]Q;
  wire aclk;
  wire [2:0]fifoaddr;
  wire load_s1;
  wire m_avalid;
  wire [1:0]m_axi_wready;
  wire [0:0]m_ready_d;
  wire m_valid_i_reg;
  wire mi_wready_2;
  wire push;
  wire [0:0]s_axi_awvalid;
  wire [0:0]s_axi_wlast;
  wire [0:0]s_axi_wvalid;
  wire s_ready_i_reg;
  wire [1:0]st_aa_awtarget_hot;
  wire esc_storage_data1_reg_1_261ad78 ;
  wire [1:1]storage_data2;

  assign esc_FSM_onehot_state_reg_1_070266a  = push;

  // Reconstructed LUT4: esc_FSM_onehot_state_3__i_3_b7baa48
  assign m_valid_i_reg = ((s_axi_wlast) ? (((s_axi_wvalid) ? (((m_avalid) ? (esc_FSM_onehot_state_3__i_4_n_0_f65af67) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT5: esc_FSM_onehot_state_3__i_4_54f286e
  assign esc_FSM_onehot_state_3__i_4_n_0_f65af67 = ((m_axi_wready[0]) ? (((esc_storage_data1_reg_1_261ad78) ? (((esc_FSM_onehot_state_3__i_3_0_e1ddfbb) ? (1'b1) : (~(mi_wready_2)))) : (((esc_FSM_onehot_state_3__i_3_0_e1ddfbb) ? (~(m_axi_wready[1])) : (1'b0))))) : (((esc_storage_data1_reg_1_261ad78) ? (((esc_FSM_onehot_state_3__i_3_0_e1ddfbb) ? (1'b1) : (~(mi_wready_2)))) : (((esc_FSM_onehot_state_3__i_3_0_e1ddfbb) ? (~(m_axi_wready[1])) : (1'b1))))));

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed SRL16E: esc_gen_primitive_shifter_gen_srls_0__srl_inst_44ed1e3
  reg [15:0] recovered_4_shift = 16'h0000;
  always @(posedge aclk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_4_shift <= {recovered_4_shift[14:0],D};
  assign storage_data2 = recovered_4_shift[{esc_const0_a0cf646,fifoaddr[2],fifoaddr[1],fifoaddr[0]}];

  // Reconstructed LUT6: esc_gen_primitive_shifter_gen_srls_0__srl_inst_i_2_f7e74f6
  assign push = ((Q[0]) ? (((s_axi_awvalid) ? (((m_ready_d) ? (1'b0) : (((s_ready_i_reg) ? (1'b1) : (((m_valid_i_reg) ? (Q[1]) : (1'b0))))))) : (1'b0))) : (((s_axi_awvalid) ? (((m_ready_d) ? (1'b0) : (((m_valid_i_reg) ? (Q[1]) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT6: esc_storage_data1_1__i_1_cc044f5
  assign esc_FSM_onehot_state_reg_0_536fb89 = ((esc_storage_data1_reg_1_261ad78) ? (((load_s1) ? (((Q[0]) ? (storage_data2) : (((st_aa_awtarget_hot[0]) ? (1'b0) : (~(st_aa_awtarget_hot[1])))))) : (1'b1))) : (((load_s1) ? (((Q[0]) ? (storage_data2) : (((st_aa_awtarget_hot[0]) ? (1'b0) : (~(st_aa_awtarget_hot[1])))))) : (1'b0))));

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_register_slice_v2_1_22_axi_register_slice
   (m_axi_bready,
    st_mr_rvalid,
    s_ready_i_reg,
    chosen41_in,
    esc_m_payload_i_reg_34_a1cd3d0 ,
    Q,
    .s_axi_rready_0_sp_1(s_axi_rready_0_sn_1),
    .s_axi_bready_0_sp_1(s_axi_bready_0_sn_1),
    esc_m_payload_i_reg_13_5fdb661 ,
    p_1_in,
    aclk,
    p_0_in,
    m_axi_bvalid,
    chosen,
    s_axi_bready,
    s_ready_i_reg_0,
    chosen_0,
    s_axi_rready,
    r_issuing_cnt,
    m_axi_rvalid,
    w_issuing_cnt,
    m_axi_rid,
    m_axi_rlast,
    m_axi_rresp,
    m_axi_rdata,
    D);
  output [0:0]m_axi_bready;
  output [0:0]st_mr_rvalid;
  output s_ready_i_reg;
  output chosen41_in;
  output esc_m_payload_i_reg_34_a1cd3d0 ;
  output [46:0]Q;
  output [13:0]esc_m_payload_i_reg_13_5fdb661 ;
  input p_1_in;
  input aclk;
  input p_0_in;
  input [0:0]m_axi_bvalid;
  input [0:0]chosen;
  input [0:0]s_axi_bready;
  input s_ready_i_reg_0;
  input [0:0]chosen_0;
  input [0:0]s_axi_rready;
  input [1:0]r_issuing_cnt;
  input [0:0]m_axi_rvalid;
  input [1:0]w_issuing_cnt;
  input [11:0]m_axi_rid;
  input [0:0]m_axi_rlast;
  input [1:0]m_axi_rresp;
  input [31:0]m_axi_rdata;
  input [13:0]D;
  output s_axi_rready_0_sn_1;
  output s_axi_bready_0_sn_1;

  wire [13:0]D;
  wire [46:0]Q;
  wire aclk;
  wire [0:0]chosen;
  wire chosen41_in;
  wire [0:0]chosen_0;
  wire [0:0]m_axi_bready;
  wire [0:0]m_axi_bvalid;
  wire [31:0]m_axi_rdata;
  wire [11:0]m_axi_rid;
  wire [0:0]m_axi_rlast;
  wire [0:0]m_axi_rvalid;
  wire [13:0]esc_m_payload_i_reg_13_5fdb661 ;
  wire esc_m_payload_i_reg_34_a1cd3d0 ;
  wire p_0_in;
  wire p_1_in;
  wire [1:0]r_issuing_cnt;
  wire [0:0]s_axi_bready;
  wire s_axi_bready_0_sn_1;
  wire [0:0]s_axi_rready;
  wire s_axi_rready_0_sn_1;
  wire s_ready_i_reg;
  wire s_ready_i_reg_0;
  wire [0:0]st_mr_rvalid;
  wire [1:0]w_issuing_cnt;
  wire [46:0]esc_NLW_r_r_pipe_Q_UNCONNECTED_d809013 ;

  system_xbar_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized1_8 esc_b_b_pipe_f512acc 
       (.D(D),
        .E(chosen41_in),
        .aclk(aclk),
        .chosen(chosen),
        .m_axi_bready(m_axi_bready),
        .m_axi_bvalid(m_axi_bvalid),
        .esc_m_payload_i_reg_13__0_806bc71 (esc_m_payload_i_reg_13_5fdb661 ),
        .p_0_in(p_0_in),
        .p_1_in(p_1_in),
        .s_axi_bready(s_axi_bready),
        .s_axi_bready_0_sp_1(s_axi_bready_0_sn_1),
        .s_ready_i_reg_0(s_ready_i_reg_0),
        .w_issuing_cnt(w_issuing_cnt));
  system_xbar_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized2_9 esc_r_r_pipe_b1606f9 
       (.Q({Q[46:34],esc_NLW_r_r_pipe_Q_UNCONNECTED_d809013 [33:32],Q[31:0]}),
        .aclk(aclk),
        .chosen_0(chosen_0),
        .m_axi_rdata(m_axi_rdata),
        .m_axi_rid(m_axi_rid),
        .m_axi_rlast(m_axi_rlast),
        .m_axi_rvalid(m_axi_rvalid),
        .esc_m_payload_i_reg_34__0_276b419 (esc_m_payload_i_reg_34_a1cd3d0 ),
        .m_valid_i_reg_0(st_mr_rvalid),
        .p_0_in(p_0_in),
        .p_1_in(p_1_in),
        .r_issuing_cnt(r_issuing_cnt),
        .s_axi_rready(s_axi_rready),
        .s_axi_rready_0_sp_1(s_axi_rready_0_sn_1),
        .s_ready_i_reg_0(s_ready_i_reg));
endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_register_slice_v2_1_22_axi_register_slice_1
   (m_axi_bready,
    p_1_in,
    st_mr_rvalid,
    p_0_in,
    s_ready_i_reg,
    esc_aresetn_d_reg_1_853850f ,
    E,
    D,
    esc_gen_master_slots_1__r_issuing_cnt_reg_10_4003bed ,
    s_axi_rdata,
    esc_m_payload_i_reg_46_022e045 ,
    s_axi_rresp,
    esc_gen_master_slots_1__r_issuing_cnt_reg_11_bd27538 ,
    .s_axi_rready_0_sp_1(s_axi_rready_0_sn_1),
    s_axi_bresp,
    .s_axi_bready_0_sp_1(s_axi_bready_0_sn_1),
    m_valid_i_reg_inv,
    S,
    esc_gen_multi_thread_active_id_reg_22_e111eaf ,
    esc_gen_multi_thread_active_id_reg_34_4169566 ,
    esc_gen_multi_thread_active_id_reg_46_d2665b4 ,
    esc_gen_multi_thread_active_id_reg_58_a37b6c4 ,
    esc_gen_multi_thread_active_id_reg_70_a21a41b ,
    esc_gen_multi_thread_active_id_reg_82_ab1b57f ,
    esc_gen_multi_thread_active_id_reg_94_a64542a ,
    s_axi_bid,
    esc_m_payload_i_reg_10_ffe4795 ,
    esc_m_payload_i_reg_9_9458063 ,
    esc_m_payload_i_reg_8_f05b222 ,
    esc_m_payload_i_reg_7_ba4380d ,
    esc_m_payload_i_reg_5_6200800 ,
    aclk,
    aresetn,
    Q,
    m_axi_bvalid,
    s_axi_bready,
    chosen,
    st_aa_artarget_hot,
    esc_gen_no_arbiter_s_ready_i_0__i_2_67e48b9 ,
    esc_gen_no_arbiter_s_ready_i_0__i_2_0_99bc98b ,
    esc_gen_no_arbiter_s_ready_i_0__i_2_1_44c95fe ,
    esc_s_axi_rresp_1_33d8b74 ,
    chosen_0,
    esc_s_axi_rresp_0_48ec671 ,
    m_axi_rvalid,
    s_axi_rready,
    esc_gen_master_slots_1__r_issuing_cnt_reg_8_3114f53 ,
    esc_s_axi_bid_11_c93e0e2 ,
    chosen40_in,
    esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d ,
    esc_gen_multi_thread_rid_match_00_carry_79415cb ,
    esc_gen_multi_thread_rid_match_10_carry_f513b8e ,
    esc_gen_multi_thread_rid_match_20_carry_f121ae1 ,
    esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ,
    esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ,
    esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ,
    esc_gen_multi_thread_rid_match_60_carry_fd19279 ,
    esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ,
    esc_s_axi_bid_11__0_07e1705 ,
    m_axi_rid,
    m_axi_rlast,
    m_axi_rresp,
    m_axi_rdata,
    esc_m_payload_i_reg_13_5fdb661 ,
    esc_m_payload_i_reg_0_2f8d71c );
  output [0:0]m_axi_bready;
  output p_1_in;
  output [0:0]st_mr_rvalid;
  output p_0_in;
  output s_ready_i_reg;
  output esc_aresetn_d_reg_1_853850f ;
  output [0:0]E;
  output [1:0]D;
  output esc_gen_master_slots_1__r_issuing_cnt_reg_10_4003bed ;
  output [20:0]s_axi_rdata;
  output [23:0]esc_m_payload_i_reg_46_022e045 ;
  output [1:0]s_axi_rresp;
  output [0:0]esc_gen_master_slots_1__r_issuing_cnt_reg_11_bd27538 ;
  output [1:0]s_axi_bresp;
  output m_valid_i_reg_inv;
  output [0:0]S;
  output [0:0]esc_gen_multi_thread_active_id_reg_22_e111eaf ;
  output [0:0]esc_gen_multi_thread_active_id_reg_34_4169566 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_46_d2665b4 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_58_a37b6c4 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_70_a21a41b ;
  output [0:0]esc_gen_multi_thread_active_id_reg_82_ab1b57f ;
  output [0:0]esc_gen_multi_thread_active_id_reg_94_a64542a ;
  output [6:0]s_axi_bid;
  output [4:0]esc_m_payload_i_reg_10_ffe4795 ;
  output esc_m_payload_i_reg_9_9458063 ;
  output esc_m_payload_i_reg_8_f05b222 ;
  output esc_m_payload_i_reg_7_ba4380d ;
  output esc_m_payload_i_reg_5_6200800 ;
  input aclk;
  input aresetn;
  input [3:0]Q;
  input [0:0]m_axi_bvalid;
  input [0:0]s_axi_bready;
  input [1:0]chosen;
  input [1:0]st_aa_artarget_hot;
  input esc_gen_no_arbiter_s_ready_i_0__i_2_67e48b9 ;
  input esc_gen_no_arbiter_s_ready_i_0__i_2_0_99bc98b ;
  input esc_gen_no_arbiter_s_ready_i_0__i_2_1_44c95fe ;
  input [22:0]esc_s_axi_rresp_1_33d8b74 ;
  input [1:0]chosen_0;
  input [0:0]esc_s_axi_rresp_0_48ec671 ;
  input [0:0]m_axi_rvalid;
  input [0:0]s_axi_rready;
  input esc_gen_master_slots_1__r_issuing_cnt_reg_8_3114f53 ;
  input [8:0]esc_s_axi_bid_11_c93e0e2 ;
  input chosen40_in;
  input [3:0]esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d ;
  input [2:0]esc_gen_multi_thread_rid_match_00_carry_79415cb ;
  input [2:0]esc_gen_multi_thread_rid_match_10_carry_f513b8e ;
  input [2:0]esc_gen_multi_thread_rid_match_20_carry_f121ae1 ;
  input [2:0]esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ;
  input [2:0]esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ;
  input [2:0]esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ;
  input [2:0]esc_gen_multi_thread_rid_match_60_carry_fd19279 ;
  input [2:0]esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ;
  input [6:0]esc_s_axi_bid_11__0_07e1705 ;
  input [11:0]m_axi_rid;
  input [0:0]m_axi_rlast;
  input [1:0]m_axi_rresp;
  input [31:0]m_axi_rdata;
  input [13:0]esc_m_payload_i_reg_13_5fdb661 ;
  input [0:0]esc_m_payload_i_reg_0_2f8d71c ;
  output s_axi_rready_0_sn_1;
  output s_axi_bready_0_sn_1;

  wire [1:0]D;
  wire [0:0]E;
  wire [3:0]Q;
  wire [0:0]S;
  wire aclk;
  wire aresetn;
  wire esc_aresetn_d_reg_1_853850f ;
  wire [1:0]chosen;
  wire chosen40_in;
  wire [1:0]chosen_0;
  wire esc_gen_master_slots_1__r_issuing_cnt_reg_10_4003bed ;
  wire [0:0]esc_gen_master_slots_1__r_issuing_cnt_reg_11_bd27538 ;
  wire esc_gen_master_slots_1__r_issuing_cnt_reg_8_3114f53 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_22_e111eaf ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_34_4169566 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_46_d2665b4 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_58_a37b6c4 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_70_a21a41b ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_82_ab1b57f ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_94_a64542a ;
  wire [2:0]esc_gen_multi_thread_rid_match_00_carry_79415cb ;
  wire [2:0]esc_gen_multi_thread_rid_match_10_carry_f513b8e ;
  wire [2:0]esc_gen_multi_thread_rid_match_20_carry_f121ae1 ;
  wire [2:0]esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ;
  wire [2:0]esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ;
  wire [2:0]esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ;
  wire [2:0]esc_gen_multi_thread_rid_match_60_carry_fd19279 ;
  wire [2:0]esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ;
  wire [3:0]esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d ;
  wire esc_gen_no_arbiter_s_ready_i_0__i_2_67e48b9 ;
  wire esc_gen_no_arbiter_s_ready_i_0__i_2_0_99bc98b ;
  wire esc_gen_no_arbiter_s_ready_i_0__i_2_1_44c95fe ;
  wire [0:0]m_axi_bready;
  wire [0:0]m_axi_bvalid;
  wire [31:0]m_axi_rdata;
  wire [11:0]m_axi_rid;
  wire [0:0]m_axi_rlast;
  wire [1:0]m_axi_rresp;
  wire [0:0]m_axi_rvalid;
  wire [0:0]esc_m_payload_i_reg_0_2f8d71c ;
  wire [4:0]esc_m_payload_i_reg_10_ffe4795 ;
  wire [13:0]esc_m_payload_i_reg_13_5fdb661 ;
  wire [23:0]esc_m_payload_i_reg_46_022e045 ;
  wire esc_m_payload_i_reg_5_6200800 ;
  wire esc_m_payload_i_reg_7_ba4380d ;
  wire esc_m_payload_i_reg_8_f05b222 ;
  wire esc_m_payload_i_reg_9_9458063 ;
  wire m_valid_i_reg_inv;
  wire p_0_in;
  wire p_1_in;
  wire [6:0]s_axi_bid;
  wire [8:0]esc_s_axi_bid_11_c93e0e2 ;
  wire [6:0]esc_s_axi_bid_11__0_07e1705 ;
  wire [0:0]s_axi_bready;
  wire s_axi_bready_0_sn_1;
  wire [1:0]s_axi_bresp;
  wire [20:0]s_axi_rdata;
  wire [0:0]s_axi_rready;
  wire s_axi_rready_0_sn_1;
  wire [1:0]s_axi_rresp;
  wire [0:0]esc_s_axi_rresp_0_48ec671 ;
  wire [22:0]esc_s_axi_rresp_1_33d8b74 ;
  wire s_ready_i_reg;
  wire [1:0]st_aa_artarget_hot;
  wire [0:0]st_mr_rvalid;

  system_xbar_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized1_6 esc_b_b_pipe_f512acc 
       (.S(S),
        .aclk(aclk),
        .aresetn(aresetn),
        .esc_aresetn_d_reg_1__0_d937af1 (esc_aresetn_d_reg_1_853850f ),
        .chosen(chosen),
        .chosen40_in(chosen40_in),
        .esc_gen_multi_thread_active_id_reg_22_e111eaf (esc_gen_multi_thread_active_id_reg_22_e111eaf ),
        .esc_gen_multi_thread_active_id_reg_34_4169566 (esc_gen_multi_thread_active_id_reg_34_4169566 ),
        .esc_gen_multi_thread_active_id_reg_46_d2665b4 (esc_gen_multi_thread_active_id_reg_46_d2665b4 ),
        .esc_gen_multi_thread_active_id_reg_58_a37b6c4 (esc_gen_multi_thread_active_id_reg_58_a37b6c4 ),
        .esc_gen_multi_thread_active_id_reg_70_a21a41b (esc_gen_multi_thread_active_id_reg_70_a21a41b ),
        .esc_gen_multi_thread_active_id_reg_82_ab1b57f (esc_gen_multi_thread_active_id_reg_82_ab1b57f ),
        .esc_gen_multi_thread_active_id_reg_94_a64542a (esc_gen_multi_thread_active_id_reg_94_a64542a ),
        .esc_gen_multi_thread_rid_match_00_carry_79415cb (esc_gen_multi_thread_rid_match_00_carry_79415cb ),
        .esc_gen_multi_thread_rid_match_10_carry_f513b8e (esc_gen_multi_thread_rid_match_10_carry_f513b8e ),
        .esc_gen_multi_thread_rid_match_20_carry_f121ae1 (esc_gen_multi_thread_rid_match_20_carry_f121ae1 ),
        .esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 (esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ),
        .esc_gen_multi_thread_rid_match_40_carry_9bea3c8 (esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ),
        .esc_gen_multi_thread_rid_match_50_carry_8bab2c3 (esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ),
        .esc_gen_multi_thread_rid_match_60_carry_fd19279 (esc_gen_multi_thread_rid_match_60_carry_fd19279 ),
        .esc_gen_multi_thread_rid_match_70_carry_de4f5a5 (esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ),
        .esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d (esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d ),
        .m_axi_bready(m_axi_bready),
        .m_axi_bvalid(m_axi_bvalid),
        .esc_m_payload_i_reg_10__0_f6e6b86 (esc_m_payload_i_reg_10_ffe4795 ),
        .esc_m_payload_i_reg_13__0_806bc71 (esc_m_payload_i_reg_13_5fdb661 ),
        .esc_m_payload_i_reg_5__0_5440fd2 (esc_m_payload_i_reg_5_6200800 ),
        .esc_m_payload_i_reg_7__0_d32552f (esc_m_payload_i_reg_7_ba4380d ),
        .esc_m_payload_i_reg_8__0_b998321 (esc_m_payload_i_reg_8_f05b222 ),
        .esc_m_payload_i_reg_9__0_6c07cd9 (esc_m_payload_i_reg_9_9458063 ),
        .m_valid_i_reg_inv_0(E),
        .m_valid_i_reg_inv_1(m_valid_i_reg_inv),
        .p_0_in(p_0_in),
        .p_1_in(p_1_in),
        .s_axi_bid(s_axi_bid),
        .esc_s_axi_bid_11_c93e0e2 (esc_s_axi_bid_11_c93e0e2 ),
        .esc_s_axi_bid_11__0_07e1705 (esc_s_axi_bid_11__0_07e1705 ),
        .s_axi_bready(s_axi_bready),
        .s_axi_bready_0_sp_1(s_axi_bready_0_sn_1),
        .s_axi_bresp(s_axi_bresp));
  system_xbar_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized2_7 esc_r_r_pipe_b1606f9 
       (.D(D),
        .Q(Q),
        .aclk(aclk),
        .chosen_0(chosen_0),
        .esc_gen_master_slots_1__r_issuing_cnt_reg_10_4003bed (esc_gen_master_slots_1__r_issuing_cnt_reg_10_4003bed ),
        .esc_gen_master_slots_1__r_issuing_cnt_reg_11_bd27538 (esc_gen_master_slots_1__r_issuing_cnt_reg_11_bd27538 ),
        .esc_gen_master_slots_1__r_issuing_cnt_reg_8_3114f53 (esc_gen_master_slots_1__r_issuing_cnt_reg_8_3114f53 ),
        .esc_gen_no_arbiter_s_ready_i_0__i_2_67e48b9 (esc_gen_no_arbiter_s_ready_i_0__i_2_67e48b9 ),
        .esc_gen_no_arbiter_s_ready_i_0__i_2_0_99bc98b (esc_gen_no_arbiter_s_ready_i_0__i_2_0_99bc98b ),
        .esc_gen_no_arbiter_s_ready_i_0__i_2_1_44c95fe (esc_gen_no_arbiter_s_ready_i_0__i_2_1_44c95fe ),
        .m_axi_rdata(m_axi_rdata),
        .m_axi_rid(m_axi_rid),
        .m_axi_rlast(m_axi_rlast),
        .m_axi_rresp(m_axi_rresp),
        .m_axi_rvalid(m_axi_rvalid),
        .esc_m_payload_i_reg_0__0_0129b79 (esc_m_payload_i_reg_0_2f8d71c ),
        .esc_m_payload_i_reg_46__0_de80657 (esc_m_payload_i_reg_46_022e045 ),
        .m_valid_i_reg_0(st_mr_rvalid),
        .p_0_in(p_0_in),
        .p_1_in(p_1_in),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rready(s_axi_rready),
        .s_axi_rready_0_sp_1(s_axi_rready_0_sn_1),
        .s_axi_rresp(s_axi_rresp),
        .esc_s_axi_rresp_0_48ec671 (esc_s_axi_rresp_0_48ec671 ),
        .esc_s_axi_rresp_1_33d8b74 (esc_s_axi_rresp_1_33d8b74 [20:0]),
        .s_ready_i_reg_0(s_ready_i_reg),
        .st_aa_artarget_hot(st_aa_artarget_hot));
endmodule

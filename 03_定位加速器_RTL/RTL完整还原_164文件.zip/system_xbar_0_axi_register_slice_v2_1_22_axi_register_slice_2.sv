// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_register_slice_v2_1_22_axi_register_slice_2
   (mi_bready_2,
    m_valid_i_reg,
    mi_rready_2,
    chosen40_in,
    .s_axi_rready_0_sp_1(s_axi_rready_0_sn_1),
    Q,
    esc_m_payload_i_reg_34_a1cd3d0 ,
    s_axi_bid,
    esc_m_payload_i_reg_10_ffe4795 ,
    esc_m_payload_i_reg_13_5fdb661 ,
    esc_m_payload_i_reg_6_8d56399 ,
    S,
    esc_gen_multi_thread_active_id_reg_13_8bbc4fb ,
    esc_gen_multi_thread_active_id_reg_25_7f719e6 ,
    esc_gen_multi_thread_active_id_reg_37_4f7ca46 ,
    esc_gen_multi_thread_active_id_reg_49_9efdc13 ,
    esc_gen_multi_thread_active_id_reg_61_b9e746b ,
    esc_gen_multi_thread_active_id_reg_73_994c3c5 ,
    esc_gen_multi_thread_active_id_reg_85_75c2f14 ,
    p_1_in,
    aclk,
    p_0_in,
    mi_bvalid_2,
    chosen,
    s_axi_bready,
    s_ready_i_reg,
    esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621 ,
    s_axi_rready,
    chosen_0,
    r_issuing_cnt,
    mi_rvalid_2,
    esc_gen_no_arbiter_s_ready_i_0__i_7_6a848e4 ,
    esc_s_axi_bid_8_15e08b0 ,
    .s_axi_bid_0_sp_1(s_axi_bid_0_sn_1),
    esc_gen_multi_thread_rid_match_00_carry_79415cb ,
    esc_gen_multi_thread_rid_match_10_carry_f513b8e ,
    esc_gen_multi_thread_rid_match_20_carry_f121ae1 ,
    esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ,
    esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ,
    esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ,
    esc_gen_multi_thread_rid_match_60_carry_fd19279 ,
    esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ,
    esc_skid_buffer_reg_46_665ac24 ,
    mi_rlast_2,
    D,
    E);
  output mi_bready_2;
  output [0:0]m_valid_i_reg;
  output mi_rready_2;
  output chosen40_in;
  output [12:0]Q;
  output esc_m_payload_i_reg_34_a1cd3d0 ;
  output [4:0]s_axi_bid;
  output esc_m_payload_i_reg_10_ffe4795 ;
  output [6:0]esc_m_payload_i_reg_13_5fdb661 ;
  output esc_m_payload_i_reg_6_8d56399 ;
  output [0:0]S;
  output [0:0]esc_gen_multi_thread_active_id_reg_13_8bbc4fb ;
  output [0:0]esc_gen_multi_thread_active_id_reg_25_7f719e6 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_37_4f7ca46 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_49_9efdc13 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_61_b9e746b ;
  output [0:0]esc_gen_multi_thread_active_id_reg_73_994c3c5 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_85_75c2f14 ;
  input p_1_in;
  input aclk;
  input p_0_in;
  input mi_bvalid_2;
  input [0:0]chosen;
  input [0:0]s_axi_bready;
  input s_ready_i_reg;
  input esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621 ;
  input [0:0]s_axi_rready;
  input [0:0]chosen_0;
  input [0:0]r_issuing_cnt;
  input mi_rvalid_2;
  input esc_gen_no_arbiter_s_ready_i_0__i_7_6a848e4 ;
  input [9:0]esc_s_axi_bid_8_15e08b0 ;
  input [2:0]esc_gen_multi_thread_rid_match_00_carry_79415cb ;
  input [2:0]esc_gen_multi_thread_rid_match_10_carry_f513b8e ;
  input [2:0]esc_gen_multi_thread_rid_match_20_carry_f121ae1 ;
  input [2:0]esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ;
  input [2:0]esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ;
  input [2:0]esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ;
  input [2:0]esc_gen_multi_thread_rid_match_60_carry_fd19279 ;
  input [2:0]esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ;
  input [11:0]esc_skid_buffer_reg_46_665ac24 ;
  input mi_rlast_2;
  input [11:0]D;
  input [0:0]E;
  output s_axi_rready_0_sn_1;
  input s_axi_bid_0_sn_1;

  wire [11:0]D;
  wire [0:0]E;
  wire [12:0]Q;
  wire [0:0]S;
  wire aclk;
  wire [0:0]chosen;
  wire chosen40_in;
  wire [0:0]chosen_0;
  wire esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_13_8bbc4fb ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_25_7f719e6 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_37_4f7ca46 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_49_9efdc13 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_61_b9e746b ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_73_994c3c5 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_85_75c2f14 ;
  wire [2:0]esc_gen_multi_thread_rid_match_00_carry_79415cb ;
  wire [2:0]esc_gen_multi_thread_rid_match_10_carry_f513b8e ;
  wire [2:0]esc_gen_multi_thread_rid_match_20_carry_f121ae1 ;
  wire [2:0]esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ;
  wire [2:0]esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ;
  wire [2:0]esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ;
  wire [2:0]esc_gen_multi_thread_rid_match_60_carry_fd19279 ;
  wire [2:0]esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ;
  wire esc_gen_no_arbiter_s_ready_i_0__i_7_6a848e4 ;
  wire esc_m_payload_i_reg_10_ffe4795 ;
  wire [6:0]esc_m_payload_i_reg_13_5fdb661 ;
  wire esc_m_payload_i_reg_34_a1cd3d0 ;
  wire esc_m_payload_i_reg_6_8d56399 ;
  wire [0:0]m_valid_i_reg;
  wire mi_bready_2;
  wire mi_bvalid_2;
  wire mi_rlast_2;
  wire mi_rready_2;
  wire mi_rvalid_2;
  wire p_0_in;
  wire p_1_in;
  wire [0:0]r_issuing_cnt;
  wire [4:0]s_axi_bid;
  wire [9:0]esc_s_axi_bid_8_15e08b0 ;
  wire s_axi_bid_0_sn_1;
  wire [0:0]s_axi_bready;
  wire [0:0]s_axi_rready;
  wire s_axi_rready_0_sn_1;
  wire s_ready_i_reg;
  wire [11:0]esc_skid_buffer_reg_46_665ac24 ;

  system_xbar_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized1 esc_b_b_pipe_f512acc 
       (.D(D),
        .E(chosen40_in),
        .S(S),
        .aclk(aclk),
        .chosen(chosen),
        .esc_gen_multi_thread_active_id_reg_13_8bbc4fb (esc_gen_multi_thread_active_id_reg_13_8bbc4fb ),
        .esc_gen_multi_thread_active_id_reg_25_7f719e6 (esc_gen_multi_thread_active_id_reg_25_7f719e6 ),
        .esc_gen_multi_thread_active_id_reg_37_4f7ca46 (esc_gen_multi_thread_active_id_reg_37_4f7ca46 ),
        .esc_gen_multi_thread_active_id_reg_49_9efdc13 (esc_gen_multi_thread_active_id_reg_49_9efdc13 ),
        .esc_gen_multi_thread_active_id_reg_61_b9e746b (esc_gen_multi_thread_active_id_reg_61_b9e746b ),
        .esc_gen_multi_thread_active_id_reg_73_994c3c5 (esc_gen_multi_thread_active_id_reg_73_994c3c5 ),
        .esc_gen_multi_thread_active_id_reg_85_75c2f14 (esc_gen_multi_thread_active_id_reg_85_75c2f14 ),
        .esc_gen_multi_thread_rid_match_00_carry_79415cb (esc_gen_multi_thread_rid_match_00_carry_79415cb ),
        .esc_gen_multi_thread_rid_match_10_carry_f513b8e (esc_gen_multi_thread_rid_match_10_carry_f513b8e ),
        .esc_gen_multi_thread_rid_match_20_carry_f121ae1 (esc_gen_multi_thread_rid_match_20_carry_f121ae1 ),
        .esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 (esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ),
        .esc_gen_multi_thread_rid_match_40_carry_9bea3c8 (esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ),
        .esc_gen_multi_thread_rid_match_50_carry_8bab2c3 (esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ),
        .esc_gen_multi_thread_rid_match_60_carry_fd19279 (esc_gen_multi_thread_rid_match_60_carry_fd19279 ),
        .esc_gen_multi_thread_rid_match_70_carry_de4f5a5 (esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ),
        .esc_m_payload_i_reg_10__0_f6e6b86 (esc_m_payload_i_reg_10_ffe4795 ),
        .esc_m_payload_i_reg_13__0_806bc71 (esc_m_payload_i_reg_13_5fdb661 ),
        .esc_m_payload_i_reg_6__0_a018448 (esc_m_payload_i_reg_6_8d56399 ),
        .mi_bready_2(mi_bready_2),
        .mi_bvalid_2(mi_bvalid_2),
        .p_0_in(p_0_in),
        .p_1_in(p_1_in),
        .s_axi_bid(s_axi_bid),
        .esc_s_axi_bid_8_15e08b0 (esc_s_axi_bid_8_15e08b0 ),
        .s_axi_bid_0_sp_1(s_axi_bid_0_sn_1),
        .s_axi_bready(s_axi_bready),
        .s_ready_i_reg_0(s_ready_i_reg));
  system_xbar_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized2 esc_r_r_pipe_b1606f9 
       (.E(E),
        .Q(Q),
        .aclk(aclk),
        .chosen_0(chosen_0),
        .esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621 (esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621 ),
        .esc_gen_no_arbiter_s_ready_i_0__i_7_6a848e4 (esc_gen_no_arbiter_s_ready_i_0__i_7_6a848e4 ),
        .esc_m_payload_i_reg_34__0_276b419 (esc_m_payload_i_reg_34_a1cd3d0 ),
        .m_valid_i_reg_0(m_valid_i_reg),
        .mi_rlast_2(mi_rlast_2),
        .mi_rvalid_2(mi_rvalid_2),
        .p_0_in(p_0_in),
        .p_1_in(p_1_in),
        .r_issuing_cnt(r_issuing_cnt),
        .s_axi_rready(s_axi_rready),
        .s_axi_rready_0_sp_1(s_axi_rready_0_sn_1),
        .s_ready_i_reg_0(mi_rready_2),
        .esc_skid_buffer_reg_46__0_5d60302 (esc_skid_buffer_reg_46_665ac24 ));
endmodule

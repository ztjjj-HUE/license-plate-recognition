// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized1
   (mi_bready_2,
    E,
    s_axi_bid,
    esc_m_payload_i_reg_10__0_f6e6b86 ,
    esc_m_payload_i_reg_6__0_a018448 ,
    S,
    esc_gen_multi_thread_active_id_reg_13_8bbc4fb ,
    esc_gen_multi_thread_active_id_reg_25_7f719e6 ,
    esc_gen_multi_thread_active_id_reg_37_4f7ca46 ,
    esc_gen_multi_thread_active_id_reg_49_9efdc13 ,
    esc_gen_multi_thread_active_id_reg_61_b9e746b ,
    esc_gen_multi_thread_active_id_reg_73_994c3c5 ,
    esc_gen_multi_thread_active_id_reg_85_75c2f14 ,
    esc_m_payload_i_reg_13__0_806bc71 ,
    p_1_in,
    aclk,
    p_0_in,
    mi_bvalid_2,
    chosen,
    s_axi_bready,
    s_ready_i_reg_0,
    esc_s_axi_bid_8_15e08b0 ,
    .s_axi_bid_0_sp_1(s_axi_bid_0_sn_1),
    esc_gen_multi_thread_rid_match_00_carry_79415cb ,
    esc_gen_multi_thread_rid_match_10_carry_f513b8e ,
    esc_gen_multi_thread_rid_match_20_carry_f121ae1 ,
    esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ,
    esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ,
    esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ,
    esc_gen_multi_thread_rid_match_60_carry_fd19279 ,
    esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ,
    D);
  output mi_bready_2;
  output [0:0]E;
  output [4:0]s_axi_bid;
  output esc_m_payload_i_reg_10__0_f6e6b86 ;
  output esc_m_payload_i_reg_6__0_a018448 ;
  output [0:0]S;
  output [0:0]esc_gen_multi_thread_active_id_reg_13_8bbc4fb ;
  output [0:0]esc_gen_multi_thread_active_id_reg_25_7f719e6 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_37_4f7ca46 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_49_9efdc13 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_61_b9e746b ;
  output [0:0]esc_gen_multi_thread_active_id_reg_73_994c3c5 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_85_75c2f14 ;
  output [6:0]esc_m_payload_i_reg_13__0_806bc71 ;
  input p_1_in;
  input aclk;
  input p_0_in;
  input mi_bvalid_2;
  input [0:0]chosen;
  input [0:0]s_axi_bready;
  input s_ready_i_reg_0;
  input [9:0]esc_s_axi_bid_8_15e08b0 ;
  input [2:0]esc_gen_multi_thread_rid_match_00_carry_79415cb ;
  input [2:0]esc_gen_multi_thread_rid_match_10_carry_f513b8e ;
  input [2:0]esc_gen_multi_thread_rid_match_20_carry_f121ae1 ;
  input [2:0]esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ;
  input [2:0]esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ;
  input [2:0]esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ;
  input [2:0]esc_gen_multi_thread_rid_match_60_carry_fd19279 ;
  input [2:0]esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ;
  input [11:0]D;
  input s_axi_bid_0_sn_1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [11:0]D;
  wire [0:0]E;
  wire [0:0]S;
  wire aclk;
  wire [0:0]chosen;
  wire [0:0]esc_gen_multi_thread_active_id_reg_13_8bbc4fb ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_25_7f719e6 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_37_4f7ca46 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_49_9efdc13 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_61_b9e746b ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_73_994c3c5 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_85_75c2f14 ;
  wire [2:0]esc_gen_multi_thread_rid_match_00_carry_79415cb ;
  wire [2:0]esc_gen_multi_thread_rid_match_10_carry_f513b8e ;
  wire [2:0]esc_gen_multi_thread_rid_match_20_carry_f121ae1 ;
  wire [2:0]esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ;
  wire [2:0]esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ;
  wire [2:0]esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ;
  wire [2:0]esc_gen_multi_thread_rid_match_60_carry_fd19279 ;
  wire [2:0]esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ;
  wire [6:0]esc_m_payload_i_reg_13__0_806bc71 ;
  wire m_valid_i_inv_i_1__1_n_0;
  wire mi_bready_2;
  wire mi_bvalid_2;
  wire p_0_in;
  wire p_1_in;
  wire [4:0]s_axi_bid;
  wire [9:0]esc_s_axi_bid_8_15e08b0 ;
  wire s_axi_bid_0_sn_1;
  wire [0:0]s_axi_bready;
  wire s_ready_i_i_1__5_n_0;
  wire s_ready_i_reg_0;
  wire [32:24]st_mr_bid;

  assign esc_m_payload_i_reg_10__0_f6e6b86  = s_axi_bid[4];
  assign esc_m_payload_i_reg_6__0_a018448  = s_axi_bid[3];

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_00_carry_i_4__0_171e386
  assign S = ((s_axi_bid[0]) ? (((esc_gen_multi_thread_rid_match_00_carry_79415cb [0]) ? (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_00_carry_79415cb [2]) ? (((esc_gen_multi_thread_rid_match_00_carry_79415cb [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_00_carry_79415cb [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_00_carry_79415cb [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_00_carry_79415cb [0]) ? (1'b0) : (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_00_carry_79415cb [2]) ? (((esc_gen_multi_thread_rid_match_00_carry_79415cb [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_00_carry_79415cb [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_00_carry_79415cb [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_10_carry_i_4__0_e025a84
  assign esc_gen_multi_thread_active_id_reg_13_8bbc4fb = ((s_axi_bid[0]) ? (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [0]) ? (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [2]) ? (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [0]) ? (1'b0) : (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [2]) ? (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_20_carry_i_4__0_220d2fa
  assign esc_gen_multi_thread_active_id_reg_25_7f719e6 = ((s_axi_bid[0]) ? (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [0]) ? (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [2]) ? (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [0]) ? (1'b0) : (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [2]) ? (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_30_carry_i_4__0_f19037c
  assign esc_gen_multi_thread_active_id_reg_37_4f7ca46 = ((s_axi_bid[0]) ? (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [0]) ? (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [2]) ? (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [0]) ? (1'b0) : (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [2]) ? (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_40_carry_i_4__0_9e35a47
  assign esc_gen_multi_thread_active_id_reg_49_9efdc13 = ((s_axi_bid[0]) ? (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [0]) ? (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [2]) ? (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [0]) ? (1'b0) : (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [2]) ? (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_50_carry_i_4__0_4669d91
  assign esc_gen_multi_thread_active_id_reg_61_b9e746b = ((s_axi_bid[0]) ? (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [0]) ? (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [2]) ? (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [0]) ? (1'b0) : (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [2]) ? (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_60_carry_i_4__0_4b98409
  assign esc_gen_multi_thread_active_id_reg_73_994c3c5 = ((s_axi_bid[0]) ? (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [0]) ? (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [2]) ? (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [0]) ? (1'b0) : (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [2]) ? (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_70_carry_i_4__0_7167cc2
  assign esc_gen_multi_thread_active_id_reg_85_75c2f14 = ((s_axi_bid[0]) ? (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [0]) ? (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [2]) ? (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [0]) ? (1'b0) : (((s_axi_bid[2]) ? (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [2]) ? (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [1]) ? (s_axi_bid[1]) : (~(s_axi_bid[1])))))))))));

  // Reconstructed FDRE: esc_m_payload_i_reg_10_ffe4795
  reg recovered_11_q = 1'b0;
  assign st_mr_bid[32] = recovered_11_q;
  wire recovered_11_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_11_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_11_q == (D[8])))) recovered_11_q <= (D[8]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_11_41a697a
  reg recovered_12_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [4] = recovered_12_q;
  wire recovered_12_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_12_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_12_q == (D[9])))) recovered_12_q <= (D[9]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_12_69d425e
  reg recovered_13_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [5] = recovered_13_q;
  wire recovered_13_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_13_q == (D[10])))) recovered_13_q <= (D[10]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_13_5fdb661
  reg recovered_14_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [6] = recovered_14_q;
  wire recovered_14_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_14_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_14_q == (D[11])))) recovered_14_q <= (D[11]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_2_3bf2adb
  reg recovered_15_q = 1'b0;
  assign st_mr_bid[24] = recovered_15_q;
  wire recovered_15_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_15_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_15_q == (D[0])))) recovered_15_q <= (D[0]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_3_3eab624
  reg recovered_16_q = 1'b0;
  assign st_mr_bid[25] = recovered_16_q;
  wire recovered_16_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_16_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_16_q == (D[1])))) recovered_16_q <= (D[1]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_4_60ef705
  reg recovered_17_q = 1'b0;
  assign st_mr_bid[26] = recovered_17_q;
  wire recovered_17_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_17_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_17_q == (D[2])))) recovered_17_q <= (D[2]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_5_6200800
  reg recovered_18_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [0] = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_18_q == (D[3])))) recovered_18_q <= (D[3]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_6_8d56399
  reg recovered_19_q = 1'b0;
  assign st_mr_bid[28] = recovered_19_q;
  wire recovered_19_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_19_q == (D[4])))) recovered_19_q <= (D[4]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_7_ba4380d
  reg recovered_20_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [1] = recovered_20_q;
  wire recovered_20_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_20_q == (D[5])))) recovered_20_q <= (D[5]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_8_f05b222
  reg recovered_21_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [2] = recovered_21_q;
  wire recovered_21_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_21_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_21_q == (D[6])))) recovered_21_q <= (D[6]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_9_9458063
  reg recovered_22_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [3] = recovered_22_q;
  wire recovered_22_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_22_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_22_q == (D[7])))) recovered_22_q <= (D[7]);
  end

  // Reconstructed LUT5: m_valid_i_inv_i_1__1
  assign m_valid_i_inv_i_1__1_n_0 = ((chosen) ? (((E) ? (((mi_bready_2) ? (~(mi_bvalid_2)) : (1'b0))) : (((s_axi_bready) ? (((mi_bready_2) ? (~(mi_bvalid_2)) : (1'b1))) : (((mi_bready_2) ? (~(mi_bvalid_2)) : (1'b0))))))) : (((mi_bready_2) ? (~(mi_bvalid_2)) : (1'b0))));

  // Reconstructed FDSE: m_valid_i_reg_inv
  reg recovered_24_q = 1'b1;
  assign E = recovered_24_q;
  wire recovered_24_reset = ((p_0_in)) && ((p_0_in) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_24_reset || (((p_0_in) === 1'bx) && (recovered_24_q == 1'b1))) recovered_24_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_24_q == (m_valid_i_inv_i_1__1_n_0)))) recovered_24_q <= (m_valid_i_inv_i_1__1_n_0);
  end

  // Reconstructed LUT6: esc_s_axi_bid_0__INST_0_i_1_e930319
  assign s_axi_bid[0] = ((esc_s_axi_bid_8_15e08b0 [0]) ? (((chosen) ? (((E) ? (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [5]) : (1'b1))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (st_mr_bid[24]))))) : (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [5]) : (1'b1))))) : (((chosen) ? (((E) ? (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [5]) : (1'b0))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (st_mr_bid[24]))))) : (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [5]) : (1'b0))))));

  // Reconstructed LUT6: esc_s_axi_bid_1__INST_0_i_1_ff413d0
  assign s_axi_bid[1] = ((esc_s_axi_bid_8_15e08b0 [6]) ? (((chosen) ? (((E) ? (((s_axi_bid_0_sn_1) ? (1'b1) : (esc_s_axi_bid_8_15e08b0 [1]))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (st_mr_bid[25]))))) : (((s_axi_bid_0_sn_1) ? (1'b1) : (esc_s_axi_bid_8_15e08b0 [1]))))) : (((chosen) ? (((E) ? (((s_axi_bid_0_sn_1) ? (1'b0) : (esc_s_axi_bid_8_15e08b0 [1]))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (st_mr_bid[25]))))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (esc_s_axi_bid_8_15e08b0 [1]))))));

  // Reconstructed LUT6: esc_s_axi_bid_2__INST_0_i_1_8a04984
  assign s_axi_bid[2] = ((esc_s_axi_bid_8_15e08b0 [2]) ? (((chosen) ? (((E) ? (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [7]) : (1'b1))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (st_mr_bid[26]))))) : (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [7]) : (1'b1))))) : (((chosen) ? (((E) ? (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [7]) : (1'b0))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (st_mr_bid[26]))))) : (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [7]) : (1'b0))))));

  // Reconstructed LUT6: esc_s_axi_bid_4__INST_0_i_1_674f58a
  assign s_axi_bid[3] = ((esc_s_axi_bid_8_15e08b0 [3]) ? (((chosen) ? (((E) ? (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [8]) : (1'b1))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (st_mr_bid[28]))))) : (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [8]) : (1'b1))))) : (((chosen) ? (((E) ? (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [8]) : (1'b0))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (st_mr_bid[28]))))) : (((s_axi_bid_0_sn_1) ? (esc_s_axi_bid_8_15e08b0 [8]) : (1'b0))))));

  // Reconstructed LUT6: esc_s_axi_bid_8__INST_0_i_1_38576fd
  assign s_axi_bid[4] = ((esc_s_axi_bid_8_15e08b0 [9]) ? (((chosen) ? (((E) ? (((s_axi_bid_0_sn_1) ? (1'b1) : (esc_s_axi_bid_8_15e08b0 [4]))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (st_mr_bid[32]))))) : (((s_axi_bid_0_sn_1) ? (1'b1) : (esc_s_axi_bid_8_15e08b0 [4]))))) : (((chosen) ? (((E) ? (((s_axi_bid_0_sn_1) ? (1'b0) : (esc_s_axi_bid_8_15e08b0 [4]))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (st_mr_bid[32]))))) : (((s_axi_bid_0_sn_1) ? (1'b0) : (esc_s_axi_bid_8_15e08b0 [4]))))));

  // Reconstructed LUT5: s_ready_i_i_1__5
  assign s_ready_i_i_1__5_n_0 = ((s_ready_i_reg_0) ? (((s_axi_bready) ? (((chosen) ? (((mi_bvalid_2) ? (~(E)) : (1'b1))) : (((mi_bvalid_2) ? (1'b0) : (E))))) : (((mi_bvalid_2) ? (1'b0) : (E))))) : (1'b1));

  // Reconstructed FDRE: s_ready_i_reg
  reg recovered_31_q = 1'b0;
  assign mi_bready_2 = recovered_31_q;
  wire recovered_31_reset = ((p_1_in)) && ((p_1_in) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_31_reset || (((p_1_in) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_31_q == (s_ready_i_i_1__5_n_0)))) recovered_31_q <= (s_ready_i_i_1__5_n_0);
  end

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized1_6
   (m_axi_bready,
    p_1_in,
    esc_aresetn_d_reg_1__0_d937af1 ,
    m_valid_i_reg_inv_0,
    p_0_in,
    s_axi_bresp,
    .s_axi_bready_0_sp_1(s_axi_bready_0_sn_1),
    m_valid_i_reg_inv_1,
    S,
    esc_gen_multi_thread_active_id_reg_22_e111eaf ,
    esc_gen_multi_thread_active_id_reg_34_4169566 ,
    esc_gen_multi_thread_active_id_reg_46_d2665b4 ,
    esc_gen_multi_thread_active_id_reg_58_a37b6c4 ,
    esc_gen_multi_thread_active_id_reg_70_a21a41b ,
    esc_gen_multi_thread_active_id_reg_82_ab1b57f ,
    esc_gen_multi_thread_active_id_reg_94_a64542a ,
    s_axi_bid,
    esc_m_payload_i_reg_9__0_6c07cd9 ,
    esc_m_payload_i_reg_8__0_b998321 ,
    esc_m_payload_i_reg_7__0_d32552f ,
    esc_m_payload_i_reg_5__0_5440fd2 ,
    esc_m_payload_i_reg_10__0_f6e6b86 ,
    aclk,
    aresetn,
    m_axi_bvalid,
    s_axi_bready,
    chosen,
    esc_s_axi_bid_11_c93e0e2 ,
    chosen40_in,
    esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d ,
    esc_gen_multi_thread_rid_match_00_carry_79415cb ,
    esc_gen_multi_thread_rid_match_10_carry_f513b8e ,
    esc_gen_multi_thread_rid_match_20_carry_f121ae1 ,
    esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ,
    esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ,
    esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ,
    esc_gen_multi_thread_rid_match_60_carry_fd19279 ,
    esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ,
    esc_s_axi_bid_11__0_07e1705 ,
    esc_m_payload_i_reg_13__0_806bc71 );
  output [0:0]m_axi_bready;
  output p_1_in;
  output esc_aresetn_d_reg_1__0_d937af1 ;
  output m_valid_i_reg_inv_0;
  output p_0_in;
  output [1:0]s_axi_bresp;
  output m_valid_i_reg_inv_1;
  output [0:0]S;
  output [0:0]esc_gen_multi_thread_active_id_reg_22_e111eaf ;
  output [0:0]esc_gen_multi_thread_active_id_reg_34_4169566 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_46_d2665b4 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_58_a37b6c4 ;
  output [0:0]esc_gen_multi_thread_active_id_reg_70_a21a41b ;
  output [0:0]esc_gen_multi_thread_active_id_reg_82_ab1b57f ;
  output [0:0]esc_gen_multi_thread_active_id_reg_94_a64542a ;
  output [6:0]s_axi_bid;
  output esc_m_payload_i_reg_9__0_6c07cd9 ;
  output esc_m_payload_i_reg_8__0_b998321 ;
  output esc_m_payload_i_reg_7__0_d32552f ;
  output esc_m_payload_i_reg_5__0_5440fd2 ;
  output [4:0]esc_m_payload_i_reg_10__0_f6e6b86 ;
  input aclk;
  input aresetn;
  input [0:0]m_axi_bvalid;
  input [0:0]s_axi_bready;
  input [1:0]chosen;
  input [8:0]esc_s_axi_bid_11_c93e0e2 ;
  input chosen40_in;
  input [3:0]esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d ;
  input [2:0]esc_gen_multi_thread_rid_match_00_carry_79415cb ;
  input [2:0]esc_gen_multi_thread_rid_match_10_carry_f513b8e ;
  input [2:0]esc_gen_multi_thread_rid_match_20_carry_f121ae1 ;
  input [2:0]esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ;
  input [2:0]esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ;
  input [2:0]esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ;
  input [2:0]esc_gen_multi_thread_rid_match_60_carry_fd19279 ;
  input [2:0]esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ;
  input [6:0]esc_s_axi_bid_11__0_07e1705 ;
  input [13:0]esc_m_payload_i_reg_13__0_806bc71 ;
  output s_axi_bready_0_sn_1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]S;
  wire aclk;
  wire aresetn;
  wire esc_aresetn_d_1__i_1_n_0_666dca4 ;
  wire esc_aresetn_d_reg_1__0_d937af1 ;
  wire esc_aresetn_d_reg_n_0__0_417d18e ;
  wire [1:0]chosen;
  wire chosen40_in;
  wire [0:0]esc_gen_multi_thread_active_id_reg_22_e111eaf ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_34_4169566 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_46_d2665b4 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_58_a37b6c4 ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_70_a21a41b ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_82_ab1b57f ;
  wire [0:0]esc_gen_multi_thread_active_id_reg_94_a64542a ;
  wire [2:0]esc_gen_multi_thread_rid_match_00_carry_79415cb ;
  wire [2:0]esc_gen_multi_thread_rid_match_10_carry_f513b8e ;
  wire [2:0]esc_gen_multi_thread_rid_match_20_carry_f121ae1 ;
  wire [2:0]esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 ;
  wire [2:0]esc_gen_multi_thread_rid_match_40_carry_9bea3c8 ;
  wire [2:0]esc_gen_multi_thread_rid_match_50_carry_8bab2c3 ;
  wire [2:0]esc_gen_multi_thread_rid_match_60_carry_fd19279 ;
  wire [2:0]esc_gen_multi_thread_rid_match_70_carry_de4f5a5 ;
  wire [3:0]esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d ;
  wire [0:0]m_axi_bready;
  wire [0:0]m_axi_bvalid;
  wire [4:0]esc_m_payload_i_reg_10__0_f6e6b86 ;
  wire [13:0]esc_m_payload_i_reg_13__0_806bc71 ;
  wire m_valid_i_inv_i_1__0_n_0;
  wire m_valid_i_reg_inv_0;
  wire m_valid_i_reg_inv_1;
  wire p_0_in;
  wire p_1_in;
  wire [6:0]s_axi_bid;
  wire [8:0]esc_s_axi_bid_11_c93e0e2 ;
  wire [6:0]esc_s_axi_bid_11__0_07e1705 ;
  wire [0:0]s_axi_bready;
  wire s_axi_bready_0_sn_1;
  wire [1:0]s_axi_bresp;
  wire s_ready_i_i_2__0_n_0;
  wire [23:15]st_mr_bid;
  wire [4:3]st_mr_bmesg;

  assign esc_m_payload_i_reg_5__0_5440fd2  = s_axi_bid[0];
  assign esc_m_payload_i_reg_7__0_d32552f  = s_axi_bid[1];
  assign esc_m_payload_i_reg_8__0_b998321  = s_axi_bid[2];
  assign esc_m_payload_i_reg_9__0_6c07cd9  = s_axi_bid[3];

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT2: esc_aresetn_d_1__i_1_cac2a08
  assign esc_aresetn_d_1__i_1_n_0_666dca4 = ((aresetn) ? (esc_aresetn_d_reg_n_0__0_417d18e) : (1'b0));

  // Reconstructed FDRE: esc_aresetn_d_reg_0_e1dde1e
  reg recovered_4_q = 1'b0;
  assign esc_aresetn_d_reg_n_0__0_417d18e = recovered_4_q;
  wire recovered_4_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_4_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (aresetn)))) recovered_4_q <= (aresetn);
  end

  // Reconstructed FDRE: esc_aresetn_d_reg_1_853850f
  reg recovered_5_q = 1'b0;
  assign esc_aresetn_d_reg_1__0_d937af1 = recovered_5_q;
  wire recovered_5_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (esc_aresetn_d_1__i_1_n_0_666dca4)))) recovered_5_q <= (esc_aresetn_d_1__i_1_n_0_666dca4);
  end

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_00_carry_i_1__0_22ec399
  assign S = ((s_axi_bid[4]) ? (((esc_gen_multi_thread_rid_match_00_carry_79415cb [0]) ? (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_00_carry_79415cb [2]) ? (((esc_gen_multi_thread_rid_match_00_carry_79415cb [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_00_carry_79415cb [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_00_carry_79415cb [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_00_carry_79415cb [0]) ? (1'b0) : (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_00_carry_79415cb [2]) ? (((esc_gen_multi_thread_rid_match_00_carry_79415cb [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_00_carry_79415cb [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_00_carry_79415cb [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_10_carry_i_1__0_4cad752
  assign esc_gen_multi_thread_active_id_reg_22_e111eaf = ((s_axi_bid[4]) ? (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [0]) ? (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [2]) ? (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [0]) ? (1'b0) : (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [2]) ? (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_10_carry_f513b8e [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_20_carry_i_1__0_2d71999
  assign esc_gen_multi_thread_active_id_reg_34_4169566 = ((s_axi_bid[4]) ? (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [0]) ? (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [2]) ? (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [0]) ? (1'b0) : (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [2]) ? (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_20_carry_f121ae1 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_30_carry_i_1__0_36b1753
  assign esc_gen_multi_thread_active_id_reg_46_d2665b4 = ((s_axi_bid[4]) ? (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [0]) ? (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [2]) ? (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [0]) ? (1'b0) : (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [2]) ? (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_30_carry_f8dd6e6 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_40_carry_i_1__0_5801e60
  assign esc_gen_multi_thread_active_id_reg_58_a37b6c4 = ((s_axi_bid[4]) ? (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [0]) ? (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [2]) ? (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [0]) ? (1'b0) : (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [2]) ? (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_40_carry_9bea3c8 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_50_carry_i_1__0_49292a3
  assign esc_gen_multi_thread_active_id_reg_70_a21a41b = ((s_axi_bid[4]) ? (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [0]) ? (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [2]) ? (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [0]) ? (1'b0) : (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [2]) ? (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_50_carry_8bab2c3 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_60_carry_i_1__0_39965f8
  assign esc_gen_multi_thread_active_id_reg_82_ab1b57f = ((s_axi_bid[4]) ? (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [0]) ? (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [2]) ? (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [0]) ? (1'b0) : (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [2]) ? (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_60_carry_fd19279 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))))));

  // Reconstructed LUT6: esc_gen_multi_thread_rid_match_70_carry_i_1__0_eef931c
  assign esc_gen_multi_thread_active_id_reg_94_a64542a = ((s_axi_bid[4]) ? (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [0]) ? (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [2]) ? (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [0]) ? (1'b0) : (((s_axi_bid[6]) ? (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [2]) ? (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))) : (1'b0))) : (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [2]) ? (1'b0) : (((esc_gen_multi_thread_rid_match_70_carry_de4f5a5 [1]) ? (s_axi_bid[5]) : (~(s_axi_bid[5])))))))))));

  // Reconstructed LUT6: esc_gen_no_arbiter_m_target_hot_i_2__i_15_9b5b9a2
  assign s_axi_bready_0_sn_1 = ((esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d [3]) ? (((esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d [2]) ? (1'b0) : (((esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d [1]) ? (1'b0) : (((esc_gen_no_arbiter_m_target_hot_i_2__i_8_e71a59d [0]) ? (1'b0) : (((s_axi_bready) ? (~(m_valid_i_reg_inv_1)) : (1'b1))))))))) : (1'b0));

  // Reconstructed FDRE: esc_m_payload_i_reg_0_2f8d71c
  reg recovered_15_q = 1'b0;
  assign st_mr_bmesg[3] = recovered_15_q;
  wire recovered_15_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_15_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_15_q == (esc_m_payload_i_reg_13__0_806bc71 [0])))) recovered_15_q <= (esc_m_payload_i_reg_13__0_806bc71 [0]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_10_ffe4795
  reg recovered_16_q = 1'b0;
  assign esc_m_payload_i_reg_10__0_f6e6b86 [4] = recovered_16_q;
  wire recovered_16_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_16_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_16_q == (esc_m_payload_i_reg_13__0_806bc71 [10])))) recovered_16_q <= (esc_m_payload_i_reg_13__0_806bc71 [10]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_11_41a697a
  reg recovered_17_q = 1'b0;
  assign st_mr_bid[21] = recovered_17_q;
  wire recovered_17_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_17_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_17_q == (esc_m_payload_i_reg_13__0_806bc71 [11])))) recovered_17_q <= (esc_m_payload_i_reg_13__0_806bc71 [11]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_12_69d425e
  reg recovered_18_q = 1'b0;
  assign st_mr_bid[22] = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_18_q == (esc_m_payload_i_reg_13__0_806bc71 [12])))) recovered_18_q <= (esc_m_payload_i_reg_13__0_806bc71 [12]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_13_5fdb661
  reg recovered_19_q = 1'b0;
  assign st_mr_bid[23] = recovered_19_q;
  wire recovered_19_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_19_q == (esc_m_payload_i_reg_13__0_806bc71 [13])))) recovered_19_q <= (esc_m_payload_i_reg_13__0_806bc71 [13]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_1_a76cbaf
  reg recovered_20_q = 1'b0;
  assign st_mr_bmesg[4] = recovered_20_q;
  wire recovered_20_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_20_q == (esc_m_payload_i_reg_13__0_806bc71 [1])))) recovered_20_q <= (esc_m_payload_i_reg_13__0_806bc71 [1]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_2_3bf2adb
  reg recovered_21_q = 1'b0;
  assign esc_m_payload_i_reg_10__0_f6e6b86 [0] = recovered_21_q;
  wire recovered_21_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_21_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_21_q == (esc_m_payload_i_reg_13__0_806bc71 [2])))) recovered_21_q <= (esc_m_payload_i_reg_13__0_806bc71 [2]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_3_3eab624
  reg recovered_22_q = 1'b0;
  assign esc_m_payload_i_reg_10__0_f6e6b86 [1] = recovered_22_q;
  wire recovered_22_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_22_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_22_q == (esc_m_payload_i_reg_13__0_806bc71 [3])))) recovered_22_q <= (esc_m_payload_i_reg_13__0_806bc71 [3]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_4_60ef705
  reg recovered_23_q = 1'b0;
  assign esc_m_payload_i_reg_10__0_f6e6b86 [2] = recovered_23_q;
  wire recovered_23_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_23_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_23_q == (esc_m_payload_i_reg_13__0_806bc71 [4])))) recovered_23_q <= (esc_m_payload_i_reg_13__0_806bc71 [4]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_5_6200800
  reg recovered_24_q = 1'b0;
  assign st_mr_bid[15] = recovered_24_q;
  wire recovered_24_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_24_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_24_q == (esc_m_payload_i_reg_13__0_806bc71 [5])))) recovered_24_q <= (esc_m_payload_i_reg_13__0_806bc71 [5]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_6_8d56399
  reg recovered_25_q = 1'b0;
  assign esc_m_payload_i_reg_10__0_f6e6b86 [3] = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_25_q == (esc_m_payload_i_reg_13__0_806bc71 [6])))) recovered_25_q <= (esc_m_payload_i_reg_13__0_806bc71 [6]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_7_ba4380d
  reg recovered_26_q = 1'b0;
  assign st_mr_bid[17] = recovered_26_q;
  wire recovered_26_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_26_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_26_q == (esc_m_payload_i_reg_13__0_806bc71 [7])))) recovered_26_q <= (esc_m_payload_i_reg_13__0_806bc71 [7]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_8_f05b222
  reg recovered_27_q = 1'b0;
  assign st_mr_bid[18] = recovered_27_q;
  wire recovered_27_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_27_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_27_q == (esc_m_payload_i_reg_13__0_806bc71 [8])))) recovered_27_q <= (esc_m_payload_i_reg_13__0_806bc71 [8]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_9_9458063
  reg recovered_28_q = 1'b0;
  assign st_mr_bid[19] = recovered_28_q;
  wire recovered_28_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_28_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_28_q == (esc_m_payload_i_reg_13__0_806bc71 [9])))) recovered_28_q <= (esc_m_payload_i_reg_13__0_806bc71 [9]);
  end

  // Reconstructed LUT1: m_valid_i_i_1__2
  assign p_0_in = ~(esc_aresetn_d_reg_1__0_d937af1);

  // Reconstructed LUT5: m_valid_i_inv_i_1__0
  assign m_valid_i_inv_i_1__0_n_0 = ((m_valid_i_reg_inv_0) ? (((m_axi_bready) ? (~(m_axi_bvalid)) : (1'b0))) : (((chosen[0]) ? (((s_axi_bready) ? (((m_axi_bready) ? (~(m_axi_bvalid)) : (1'b1))) : (((m_axi_bready) ? (~(m_axi_bvalid)) : (1'b0))))) : (((m_axi_bready) ? (~(m_axi_bvalid)) : (1'b0))))));

  // Reconstructed FDSE: m_valid_i_reg_inv
  reg recovered_31_q = 1'b1;
  assign m_valid_i_reg_inv_0 = recovered_31_q;
  wire recovered_31_reset = ((p_0_in)) && ((p_0_in) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_31_reset || (((p_0_in) === 1'bx) && (recovered_31_q == 1'b1))) recovered_31_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_31_q == (m_valid_i_inv_i_1__0_n_0)))) recovered_31_q <= (m_valid_i_inv_i_1__0_n_0);
  end

  // Reconstructed LUT6: esc_s_axi_bid_10__INST_0_i_1_fe19f2f
  assign s_axi_bid[5] = ((esc_s_axi_bid_11__0_07e1705 [5]) ? (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[22]) : (esc_s_axi_bid_11_c93e0e2 [7]))) : (~(m_valid_i_reg_inv_1)))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[22]) : (esc_s_axi_bid_11_c93e0e2 [7]))))) : (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[22]) : (esc_s_axi_bid_11_c93e0e2 [7]))) : (1'b0))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[22]) : (esc_s_axi_bid_11_c93e0e2 [7]))))));

  // Reconstructed LUT6: esc_s_axi_bid_11__INST_0_i_1_221c823
  assign s_axi_bid[6] = ((esc_s_axi_bid_11__0_07e1705 [6]) ? (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[23]) : (esc_s_axi_bid_11_c93e0e2 [8]))) : (~(m_valid_i_reg_inv_1)))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[23]) : (esc_s_axi_bid_11_c93e0e2 [8]))))) : (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[23]) : (esc_s_axi_bid_11_c93e0e2 [8]))) : (1'b0))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[23]) : (esc_s_axi_bid_11_c93e0e2 [8]))))));

  // Reconstructed LUT2: esc_s_axi_bid_11__INST_0_i_2_dbb999e
  assign m_valid_i_reg_inv_1 = ((chosen[0]) ? (~(m_valid_i_reg_inv_0)) : (1'b0));

  // Reconstructed LUT6: esc_s_axi_bid_3__INST_0_i_1_540a157
  assign s_axi_bid[0] = ((esc_s_axi_bid_11_c93e0e2 [2]) ? (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[15]) : (1'b1))) : (((m_valid_i_reg_inv_1) ? (1'b0) : (esc_s_axi_bid_11__0_07e1705 [0]))))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[15]) : (1'b1))))) : (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[15]) : (1'b0))) : (((m_valid_i_reg_inv_1) ? (1'b0) : (esc_s_axi_bid_11__0_07e1705 [0]))))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[15]) : (1'b0))))));

  // Reconstructed LUT6: esc_s_axi_bid_5__INST_0_i_1_c77782a
  assign s_axi_bid[1] = ((esc_s_axi_bid_11__0_07e1705 [1]) ? (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[17]) : (esc_s_axi_bid_11_c93e0e2 [3]))) : (~(m_valid_i_reg_inv_1)))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[17]) : (esc_s_axi_bid_11_c93e0e2 [3]))))) : (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[17]) : (esc_s_axi_bid_11_c93e0e2 [3]))) : (1'b0))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[17]) : (esc_s_axi_bid_11_c93e0e2 [3]))))));

  // Reconstructed LUT6: esc_s_axi_bid_6__INST_0_i_1_737c4b1
  assign s_axi_bid[2] = ((esc_s_axi_bid_11_c93e0e2 [4]) ? (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[18]) : (1'b1))) : (((m_valid_i_reg_inv_1) ? (1'b0) : (esc_s_axi_bid_11__0_07e1705 [2]))))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[18]) : (1'b1))))) : (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[18]) : (1'b0))) : (((m_valid_i_reg_inv_1) ? (1'b0) : (esc_s_axi_bid_11__0_07e1705 [2]))))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[18]) : (1'b0))))));

  // Reconstructed LUT6: esc_s_axi_bid_7__INST_0_i_1_0c3b718
  assign s_axi_bid[3] = ((esc_s_axi_bid_11_c93e0e2 [5]) ? (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[19]) : (1'b1))) : (((m_valid_i_reg_inv_1) ? (1'b0) : (esc_s_axi_bid_11__0_07e1705 [3]))))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[19]) : (1'b1))))) : (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[19]) : (1'b0))) : (((m_valid_i_reg_inv_1) ? (1'b0) : (esc_s_axi_bid_11__0_07e1705 [3]))))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[19]) : (1'b0))))));

  // Reconstructed LUT6: esc_s_axi_bid_9__INST_0_i_1_4c98d1e
  assign s_axi_bid[4] = ((esc_s_axi_bid_11_c93e0e2 [6]) ? (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[21]) : (1'b1))) : (((m_valid_i_reg_inv_1) ? (1'b0) : (esc_s_axi_bid_11__0_07e1705 [4]))))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[21]) : (1'b1))))) : (((chosen[1]) ? (((chosen40_in) ? (((m_valid_i_reg_inv_1) ? (st_mr_bid[21]) : (1'b0))) : (((m_valid_i_reg_inv_1) ? (1'b0) : (esc_s_axi_bid_11__0_07e1705 [4]))))) : (((m_valid_i_reg_inv_1) ? (st_mr_bid[21]) : (1'b0))))));

  // Reconstructed LUT6: esc_s_axi_bresp_0__INST_0_ffb0f72
  assign s_axi_bresp[0] = ((chosen40_in) ? (((m_valid_i_reg_inv_0) ? (esc_s_axi_bid_11_c93e0e2 [0]) : (((chosen[0]) ? (st_mr_bmesg[3]) : (esc_s_axi_bid_11_c93e0e2 [0]))))) : (((chosen[1]) ? (((m_valid_i_reg_inv_0) ? (1'b1) : (~(chosen[0])))) : (((m_valid_i_reg_inv_0) ? (esc_s_axi_bid_11_c93e0e2 [0]) : (((chosen[0]) ? (st_mr_bmesg[3]) : (esc_s_axi_bid_11_c93e0e2 [0]))))))));

  // Reconstructed LUT6: esc_s_axi_bresp_1__INST_0_fffb493
  assign s_axi_bresp[1] = ((chosen40_in) ? (((m_valid_i_reg_inv_0) ? (esc_s_axi_bid_11_c93e0e2 [1]) : (((chosen[0]) ? (st_mr_bmesg[4]) : (esc_s_axi_bid_11_c93e0e2 [1]))))) : (((chosen[1]) ? (((m_valid_i_reg_inv_0) ? (1'b1) : (~(chosen[0])))) : (((m_valid_i_reg_inv_0) ? (esc_s_axi_bid_11_c93e0e2 [1]) : (((chosen[0]) ? (st_mr_bmesg[4]) : (esc_s_axi_bid_11_c93e0e2 [1]))))))));

  // Reconstructed LUT1: s_ready_i_i_1__3
  assign p_1_in = ~(esc_aresetn_d_reg_n_0__0_417d18e);

  // Reconstructed LUT5: s_ready_i_i_2__0
  assign s_ready_i_i_2__0_n_0 = ((esc_aresetn_d_reg_1__0_d937af1) ? (((chosen[0]) ? (((s_axi_bready) ? (((m_valid_i_reg_inv_0) ? (~(m_axi_bvalid)) : (1'b1))) : (((m_valid_i_reg_inv_0) ? (~(m_axi_bvalid)) : (1'b0))))) : (((m_valid_i_reg_inv_0) ? (~(m_axi_bvalid)) : (1'b0))))) : (1'b1));

  // Reconstructed FDRE: s_ready_i_reg
  reg recovered_44_q = 1'b0;
  assign m_axi_bready = recovered_44_q;
  wire recovered_44_reset = ((p_1_in)) && ((p_1_in) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_44_reset || (((p_1_in) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_44_q == (s_ready_i_i_2__0_n_0)))) recovered_44_q <= (s_ready_i_i_2__0_n_0);
  end

endmodule

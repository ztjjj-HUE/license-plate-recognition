// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized1_8
   (m_axi_bready,
    E,
    .s_axi_bready_0_sp_1(s_axi_bready_0_sn_1),
    esc_m_payload_i_reg_13__0_806bc71 ,
    p_1_in,
    aclk,
    p_0_in,
    m_axi_bvalid,
    chosen,
    s_axi_bready,
    s_ready_i_reg_0,
    w_issuing_cnt,
    D);
  output [0:0]m_axi_bready;
  output [0:0]E;
  output [13:0]esc_m_payload_i_reg_13__0_806bc71 ;
  input p_1_in;
  input aclk;
  input p_0_in;
  input [0:0]m_axi_bvalid;
  input [0:0]chosen;
  input [0:0]s_axi_bready;
  input s_ready_i_reg_0;
  input [1:0]w_issuing_cnt;
  input [13:0]D;
  output s_axi_bready_0_sn_1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [13:0]D;
  wire [0:0]E;
  wire aclk;
  wire [0:0]chosen;
  wire [0:0]m_axi_bready;
  wire [0:0]m_axi_bvalid;
  wire [13:0]esc_m_payload_i_reg_13__0_806bc71 ;
  wire m_valid_i_inv_i_1_n_0;
  wire p_0_in;
  wire p_1_in;
  wire [0:0]s_axi_bready;
  wire s_axi_bready_0_sn_1;
  wire s_ready_i_i_1__4_n_0;
  wire s_ready_i_reg_0;
  wire [1:0]w_issuing_cnt;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT5: esc_gen_no_arbiter_m_target_hot_i_2__i_14_db60fca
  assign s_axi_bready_0_sn_1 = ((w_issuing_cnt[0]) ? (1'b0) : (((w_issuing_cnt[1]) ? (((chosen) ? (((E) ? (1'b1) : (~(s_axi_bready)))) : (1'b1))) : (1'b0))));

  // Reconstructed FDRE: esc_m_payload_i_reg_0_2f8d71c
  reg recovered_4_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [0] = recovered_4_q;
  wire recovered_4_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_4_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_4_q == (D[0])))) recovered_4_q <= (D[0]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_10_ffe4795
  reg recovered_5_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [10] = recovered_5_q;
  wire recovered_5_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_5_q == (D[10])))) recovered_5_q <= (D[10]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_11_41a697a
  reg recovered_6_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [11] = recovered_6_q;
  wire recovered_6_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_6_q == (D[11])))) recovered_6_q <= (D[11]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_12_69d425e
  reg recovered_7_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [12] = recovered_7_q;
  wire recovered_7_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_7_q == (D[12])))) recovered_7_q <= (D[12]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_13_5fdb661
  reg recovered_8_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [13] = recovered_8_q;
  wire recovered_8_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_8_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_8_q == (D[13])))) recovered_8_q <= (D[13]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_1_a76cbaf
  reg recovered_9_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [1] = recovered_9_q;
  wire recovered_9_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_9_q == (D[1])))) recovered_9_q <= (D[1]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_2_3bf2adb
  reg recovered_10_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [2] = recovered_10_q;
  wire recovered_10_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_10_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_10_q == (D[2])))) recovered_10_q <= (D[2]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_3_3eab624
  reg recovered_11_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [3] = recovered_11_q;
  wire recovered_11_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_11_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_11_q == (D[3])))) recovered_11_q <= (D[3]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_4_60ef705
  reg recovered_12_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [4] = recovered_12_q;
  wire recovered_12_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_12_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_12_q == (D[4])))) recovered_12_q <= (D[4]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_5_6200800
  reg recovered_13_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [5] = recovered_13_q;
  wire recovered_13_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_13_q == (D[5])))) recovered_13_q <= (D[5]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_6_8d56399
  reg recovered_14_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [6] = recovered_14_q;
  wire recovered_14_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_14_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_14_q == (D[6])))) recovered_14_q <= (D[6]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_7_ba4380d
  reg recovered_15_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [7] = recovered_15_q;
  wire recovered_15_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_15_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_15_q == (D[7])))) recovered_15_q <= (D[7]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_8_f05b222
  reg recovered_16_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [8] = recovered_16_q;
  wire recovered_16_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_16_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_16_q == (D[8])))) recovered_16_q <= (D[8]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_9_9458063
  reg recovered_17_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [9] = recovered_17_q;
  wire recovered_17_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_17_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_17_q == 1'b0))) recovered_17_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_17_q == (D[9])))) recovered_17_q <= (D[9]);
  end

  // Reconstructed LUT5: m_valid_i_inv_i_1
  assign m_valid_i_inv_i_1_n_0 = ((s_axi_bready) ? (((E) ? (((m_axi_bready) ? (~(m_axi_bvalid)) : (1'b0))) : (((chosen) ? (((m_axi_bready) ? (~(m_axi_bvalid)) : (1'b1))) : (((m_axi_bready) ? (~(m_axi_bvalid)) : (1'b0))))))) : (((m_axi_bready) ? (~(m_axi_bvalid)) : (1'b0))));

  // Reconstructed FDSE: m_valid_i_reg_inv
  reg recovered_19_q = 1'b1;
  assign E = recovered_19_q;
  wire recovered_19_reset = ((p_0_in)) && ((p_0_in) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((p_0_in) === 1'bx) && (recovered_19_q == 1'b1))) recovered_19_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_19_q == (m_valid_i_inv_i_1_n_0)))) recovered_19_q <= (m_valid_i_inv_i_1_n_0);
  end

  // Reconstructed LUT5: s_ready_i_i_1__4
  assign s_ready_i_i_1__4_n_0 = ((s_ready_i_reg_0) ? (((s_axi_bready) ? (((chosen) ? (((m_axi_bvalid) ? (~(E)) : (1'b1))) : (((m_axi_bvalid) ? (1'b0) : (E))))) : (((m_axi_bvalid) ? (1'b0) : (E))))) : (1'b1));

  // Reconstructed FDRE: s_ready_i_reg
  reg recovered_21_q = 1'b0;
  assign m_axi_bready = recovered_21_q;
  wire recovered_21_reset = ((p_1_in)) && ((p_1_in) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_21_reset || (((p_1_in) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_21_q == (s_ready_i_i_1__4_n_0)))) recovered_21_q <= (s_ready_i_i_1__4_n_0);
  end

endmodule

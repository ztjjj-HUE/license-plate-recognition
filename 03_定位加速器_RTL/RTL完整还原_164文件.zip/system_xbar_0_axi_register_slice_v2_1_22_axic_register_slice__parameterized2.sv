// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_0_axi_register_slice_v2_1_22_axic_register_slice__parameterized2
   (m_valid_i_reg_0,
    s_ready_i_reg_0,
    .s_axi_rready_0_sp_1(s_axi_rready_0_sn_1),
    Q,
    esc_m_payload_i_reg_34__0_276b419 ,
    p_0_in,
    aclk,
    p_1_in,
    esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621 ,
    s_axi_rready,
    chosen_0,
    r_issuing_cnt,
    mi_rvalid_2,
    esc_gen_no_arbiter_s_ready_i_0__i_7_6a848e4 ,
    esc_skid_buffer_reg_46__0_5d60302 ,
    mi_rlast_2,
    E);
  output m_valid_i_reg_0;
  output s_ready_i_reg_0;
  output [12:0]Q;
  output esc_m_payload_i_reg_34__0_276b419 ;
  input p_0_in;
  input aclk;
  input p_1_in;
  input esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621 ;
  input [0:0]s_axi_rready;
  input [0:0]chosen_0;
  input [0:0]r_issuing_cnt;
  input mi_rvalid_2;
  input esc_gen_no_arbiter_s_ready_i_0__i_7_6a848e4 ;
  input [11:0]esc_skid_buffer_reg_46__0_5d60302 ;
  input mi_rlast_2;
  input [0:0]E;
  output s_axi_rready_0_sn_1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]E;
  wire [12:0]Q;
  wire aclk;
  wire [0:0]chosen_0;
  wire esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621 ;
  wire esc_gen_no_arbiter_s_ready_i_0__i_7_6a848e4 ;
  wire esc_m_payload_i_reg_34__0_276b419 ;
  wire m_valid_i0;
  wire m_valid_i_reg_0;
  wire mi_rlast_2;
  wire mi_rvalid_2;
  wire p_0_in;
  wire p_1_in;
  wire [0:0]r_issuing_cnt;
  wire [0:0]s_axi_rready;
  wire s_axi_rready_0_sn_1;
  wire s_ready_i0;
  wire s_ready_i_reg_0;
  wire [46:34]skid_buffer;
  wire [11:0]esc_skid_buffer_reg_46__0_5d60302 ;
  wire esc_skid_buffer_reg_n_0__34_c7e1dec ;
  wire esc_skid_buffer_reg_n_0__35_27754b0 ;
  wire esc_skid_buffer_reg_n_0__36_49139cd ;
  wire esc_skid_buffer_reg_n_0__37_31ae3e4 ;
  wire esc_skid_buffer_reg_n_0__38_66da518 ;
  wire esc_skid_buffer_reg_n_0__39_753eaf3 ;
  wire esc_skid_buffer_reg_n_0__40_440334c ;
  wire esc_skid_buffer_reg_n_0__41_30ffac3 ;
  wire esc_skid_buffer_reg_n_0__42_3e0c00f ;
  wire esc_skid_buffer_reg_n_0__43_6940e48 ;
  wire esc_skid_buffer_reg_n_0__44_4973a46 ;
  wire esc_skid_buffer_reg_n_0__45_ae6ce43 ;
  wire esc_skid_buffer_reg_n_0__46_e862893 ;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_gen_master_slots_2__r_issuing_cnt_16__i_1_235e97f
  assign s_axi_rready_0_sn_1 = ((r_issuing_cnt) ? (((Q[0]) ? (((m_valid_i_reg_0) ? (((chosen_0) ? (((s_axi_rready) ? (esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621) : (~(esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621)))) : (~(esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621)))) : (~(esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621)))) : (~(esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621)))) : (((Q[0]) ? (((m_valid_i_reg_0) ? (((chosen_0) ? (((s_axi_rready) ? (1'b0) : (esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621))) : (esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621))) : (esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621))) : (esc_gen_master_slots_2__r_issuing_cnt_reg_16_ca8a621))));

  // Reconstructed LUT6: esc_gen_no_arbiter_s_ready_i_0__i_18_bb29235
  assign esc_m_payload_i_reg_34__0_276b419 = ((r_issuing_cnt) ? (((s_axi_rready) ? (((chosen_0) ? (((m_valid_i_reg_0) ? (((Q[0]) ? (esc_gen_no_arbiter_s_ready_i_0__i_7_6a848e4) : (1'b1))) : (1'b1))) : (1'b1))) : (1'b1))) : (esc_gen_no_arbiter_s_ready_i_0__i_7_6a848e4));

  // Reconstructed LUT3: esc_m_payload_i_34__i_1__1_bdeeed9
  assign skid_buffer[34] = ((esc_skid_buffer_reg_n_0__34_c7e1dec) ? (((s_ready_i_reg_0) ? (mi_rlast_2) : (1'b1))) : (((s_ready_i_reg_0) ? (mi_rlast_2) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_35__i_1__1_7bac765
  assign skid_buffer[35] = ((esc_skid_buffer_reg_n_0__35_27754b0) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [0]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [0]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_36__i_1__1_47c6cef
  assign skid_buffer[36] = ((esc_skid_buffer_reg_n_0__36_49139cd) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [1]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [1]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_37__i_1__1_b102040
  assign skid_buffer[37] = ((esc_skid_buffer_reg_n_0__37_31ae3e4) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [2]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [2]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_38__i_1__1_6924fbf
  assign skid_buffer[38] = ((esc_skid_buffer_reg_n_0__38_66da518) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [3]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [3]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_39__i_1__1_353b2c1
  assign skid_buffer[39] = ((esc_skid_buffer_reg_n_0__39_753eaf3) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [4]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [4]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_40__i_1__1_8610ba2
  assign skid_buffer[40] = ((esc_skid_buffer_reg_n_0__40_440334c) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [5]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [5]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_41__i_1__1_2d44ea6
  assign skid_buffer[41] = ((esc_skid_buffer_reg_n_0__41_30ffac3) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [6]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [6]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_42__i_1__1_ab00871
  assign skid_buffer[42] = ((esc_skid_buffer_reg_n_0__42_3e0c00f) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [7]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [7]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_43__i_1__1_acacb7a
  assign skid_buffer[43] = ((esc_skid_buffer_reg_n_0__43_6940e48) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [8]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [8]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_44__i_1__1_a45942e
  assign skid_buffer[44] = ((esc_skid_buffer_reg_n_0__44_4973a46) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [9]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [9]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_45__i_1__1_42b045d
  assign skid_buffer[45] = ((esc_skid_buffer_reg_n_0__45_ae6ce43) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [10]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [10]) : (1'b0))));

  // Reconstructed LUT3: esc_m_payload_i_46__i_2__1_27409c4
  assign skid_buffer[46] = ((esc_skid_buffer_reg_n_0__46_e862893) ? (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [11]) : (1'b1))) : (((s_ready_i_reg_0) ? (esc_skid_buffer_reg_46__0_5d60302 [11]) : (1'b0))));

  // Reconstructed FDRE: esc_m_payload_i_reg_34_a1cd3d0
  reg recovered_18_q = 1'b0;
  assign Q[0] = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_18_q == (skid_buffer[34])))) recovered_18_q <= (skid_buffer[34]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_35_235a12d
  reg recovered_19_q = 1'b0;
  assign Q[1] = recovered_19_q;
  wire recovered_19_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_19_q == (skid_buffer[35])))) recovered_19_q <= (skid_buffer[35]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_36_9854560
  reg recovered_20_q = 1'b0;
  assign Q[2] = recovered_20_q;
  wire recovered_20_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_20_q == (skid_buffer[36])))) recovered_20_q <= (skid_buffer[36]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_37_373e068
  reg recovered_21_q = 1'b0;
  assign Q[3] = recovered_21_q;
  wire recovered_21_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_21_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_21_q == (skid_buffer[37])))) recovered_21_q <= (skid_buffer[37]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_38_b34fad1
  reg recovered_22_q = 1'b0;
  assign Q[4] = recovered_22_q;
  wire recovered_22_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_22_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_22_q == (skid_buffer[38])))) recovered_22_q <= (skid_buffer[38]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_39_ea68878
  reg recovered_23_q = 1'b0;
  assign Q[5] = recovered_23_q;
  wire recovered_23_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_23_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_23_q == (skid_buffer[39])))) recovered_23_q <= (skid_buffer[39]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_40_fbd0b74
  reg recovered_24_q = 1'b0;
  assign Q[6] = recovered_24_q;
  wire recovered_24_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_24_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_24_q == (skid_buffer[40])))) recovered_24_q <= (skid_buffer[40]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_41_81df92e
  reg recovered_25_q = 1'b0;
  assign Q[7] = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_25_q == (skid_buffer[41])))) recovered_25_q <= (skid_buffer[41]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_42_e168c29
  reg recovered_26_q = 1'b0;
  assign Q[8] = recovered_26_q;
  wire recovered_26_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_26_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_26_q == (skid_buffer[42])))) recovered_26_q <= (skid_buffer[42]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_43_486eb83
  reg recovered_27_q = 1'b0;
  assign Q[9] = recovered_27_q;
  wire recovered_27_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_27_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_27_q == (skid_buffer[43])))) recovered_27_q <= (skid_buffer[43]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_44_7279c72
  reg recovered_28_q = 1'b0;
  assign Q[10] = recovered_28_q;
  wire recovered_28_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_28_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_28_q == (skid_buffer[44])))) recovered_28_q <= (skid_buffer[44]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_45_fff3a3b
  reg recovered_29_q = 1'b0;
  assign Q[11] = recovered_29_q;
  wire recovered_29_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_29_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_29_q == (skid_buffer[45])))) recovered_29_q <= (skid_buffer[45]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_46_022e045
  reg recovered_30_q = 1'b0;
  assign Q[12] = recovered_30_q;
  wire recovered_30_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_30_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_30_q == (skid_buffer[46])))) recovered_30_q <= (skid_buffer[46]);
  end

  // Reconstructed LUT5: m_valid_i_i_1
  assign m_valid_i0 = ((s_ready_i_reg_0) ? (((mi_rvalid_2) ? (1'b1) : (((m_valid_i_reg_0) ? (((chosen_0) ? (~(s_axi_rready)) : (1'b1))) : (1'b0))))) : (1'b1));

  // Reconstructed FDRE: m_valid_i_reg
  reg recovered_32_q = 1'b0;
  assign m_valid_i_reg_0 = recovered_32_q;
  wire recovered_32_reset = ((p_0_in)) && ((p_0_in) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_32_reset || (((p_0_in) === 1'bx) && (recovered_32_q == 1'b0))) recovered_32_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_32_q == (m_valid_i0)))) recovered_32_q <= (m_valid_i0);
  end

  // Reconstructed LUT5: s_ready_i_i_1
  assign s_ready_i0 = ((m_valid_i_reg_0) ? (((chosen_0) ? (((s_axi_rready) ? (1'b1) : (((s_ready_i_reg_0) ? (~(mi_rvalid_2)) : (1'b0))))) : (((s_ready_i_reg_0) ? (~(mi_rvalid_2)) : (1'b0))))) : (1'b1));

  // Reconstructed FDRE: s_ready_i_reg
  reg recovered_34_q = 1'b0;
  assign s_ready_i_reg_0 = recovered_34_q;
  wire recovered_34_reset = ((p_1_in)) && ((p_1_in) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_34_reset || (((p_1_in) === 1'bx) && (recovered_34_q == 1'b0))) recovered_34_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_34_q == (s_ready_i0)))) recovered_34_q <= (s_ready_i0);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_34_e521fde
  reg recovered_35_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__34_c7e1dec = recovered_35_q;
  wire recovered_35_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_35_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_35_q == 1'b0))) recovered_35_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_35_q == (mi_rlast_2)))) recovered_35_q <= (mi_rlast_2);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_35_1832a0f
  reg recovered_36_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__35_27754b0 = recovered_36_q;
  wire recovered_36_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_36_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_36_q == 1'b0))) recovered_36_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_36_q == (esc_skid_buffer_reg_46__0_5d60302 [0])))) recovered_36_q <= (esc_skid_buffer_reg_46__0_5d60302 [0]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_36_590360f
  reg recovered_37_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__36_49139cd = recovered_37_q;
  wire recovered_37_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_37_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_37_q == 1'b0))) recovered_37_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_37_q == (esc_skid_buffer_reg_46__0_5d60302 [1])))) recovered_37_q <= (esc_skid_buffer_reg_46__0_5d60302 [1]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_37_8e8d3f5
  reg recovered_38_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__37_31ae3e4 = recovered_38_q;
  wire recovered_38_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_38_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_38_q == 1'b0))) recovered_38_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_38_q == (esc_skid_buffer_reg_46__0_5d60302 [2])))) recovered_38_q <= (esc_skid_buffer_reg_46__0_5d60302 [2]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_38_2e7b154
  reg recovered_39_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__38_66da518 = recovered_39_q;
  wire recovered_39_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_39_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_39_q == 1'b0))) recovered_39_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_39_q == (esc_skid_buffer_reg_46__0_5d60302 [3])))) recovered_39_q <= (esc_skid_buffer_reg_46__0_5d60302 [3]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_39_f9c8e20
  reg recovered_40_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__39_753eaf3 = recovered_40_q;
  wire recovered_40_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_40_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_40_q == 1'b0))) recovered_40_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_40_q == (esc_skid_buffer_reg_46__0_5d60302 [4])))) recovered_40_q <= (esc_skid_buffer_reg_46__0_5d60302 [4]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_40_f34a585
  reg recovered_41_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__40_440334c = recovered_41_q;
  wire recovered_41_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_41_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_41_q == 1'b0))) recovered_41_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_41_q == (esc_skid_buffer_reg_46__0_5d60302 [5])))) recovered_41_q <= (esc_skid_buffer_reg_46__0_5d60302 [5]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_41_7ae160f
  reg recovered_42_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__41_30ffac3 = recovered_42_q;
  wire recovered_42_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_42_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_42_q == 1'b0))) recovered_42_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_42_q == (esc_skid_buffer_reg_46__0_5d60302 [6])))) recovered_42_q <= (esc_skid_buffer_reg_46__0_5d60302 [6]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_42_c1c8056
  reg recovered_43_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__42_3e0c00f = recovered_43_q;
  wire recovered_43_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_43_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_43_q == (esc_skid_buffer_reg_46__0_5d60302 [7])))) recovered_43_q <= (esc_skid_buffer_reg_46__0_5d60302 [7]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_43_dd88279
  reg recovered_44_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__43_6940e48 = recovered_44_q;
  wire recovered_44_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_44_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_44_q == (esc_skid_buffer_reg_46__0_5d60302 [8])))) recovered_44_q <= (esc_skid_buffer_reg_46__0_5d60302 [8]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_44_ba14b87
  reg recovered_45_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__44_4973a46 = recovered_45_q;
  wire recovered_45_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_45_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_45_q == 1'b0))) recovered_45_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_45_q == (esc_skid_buffer_reg_46__0_5d60302 [9])))) recovered_45_q <= (esc_skid_buffer_reg_46__0_5d60302 [9]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_45_e8f1309
  reg recovered_46_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__45_ae6ce43 = recovered_46_q;
  wire recovered_46_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_46_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_46_q == 1'b0))) recovered_46_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_46_q == (esc_skid_buffer_reg_46__0_5d60302 [10])))) recovered_46_q <= (esc_skid_buffer_reg_46__0_5d60302 [10]);
  end

  // Reconstructed FDRE: esc_skid_buffer_reg_46_665ac24
  reg recovered_47_q = 1'b0;
  assign esc_skid_buffer_reg_n_0__46_e862893 = recovered_47_q;
  wire recovered_47_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_47_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_47_q == 1'b0))) recovered_47_q <= 1'b0;
    else if ((s_ready_i_reg_0) || ((s_ready_i_reg_0) === 1'bz) || (((s_ready_i_reg_0) === 1'bx) && (recovered_47_q == (esc_skid_buffer_reg_46__0_5d60302 [11])))) recovered_47_q <= (esc_skid_buffer_reg_46__0_5d60302 [11]);
  end

endmodule

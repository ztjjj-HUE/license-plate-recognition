// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1
   (aclk,
    aresetn,
    s_axi_awid,
    s_axi_awaddr,
    s_axi_awlen,
    s_axi_awsize,
    s_axi_awburst,
    s_axi_awlock,
    s_axi_awcache,
    s_axi_awprot,
    s_axi_awqos,
    s_axi_awvalid,
    s_axi_awready,
    s_axi_wdata,
    s_axi_wstrb,
    s_axi_wlast,
    s_axi_wvalid,
    s_axi_wready,
    s_axi_bid,
    s_axi_bresp,
    s_axi_bvalid,
    s_axi_bready,
    s_axi_arid,
    s_axi_araddr,
    s_axi_arlen,
    s_axi_arsize,
    s_axi_arburst,
    s_axi_arlock,
    s_axi_arcache,
    s_axi_arprot,
    s_axi_arqos,
    s_axi_arvalid,
    s_axi_arready,
    s_axi_rid,
    s_axi_rdata,
    s_axi_rresp,
    s_axi_rlast,
    s_axi_rvalid,
    s_axi_rready,
    m_axi_awid,
    m_axi_awaddr,
    m_axi_awlen,
    m_axi_awsize,
    m_axi_awburst,
    m_axi_awlock,
    m_axi_awcache,
    m_axi_awprot,
    m_axi_awregion,
    m_axi_awqos,
    m_axi_awvalid,
    m_axi_awready,
    m_axi_wdata,
    m_axi_wstrb,
    m_axi_wlast,
    m_axi_wvalid,
    m_axi_wready,
    m_axi_bid,
    m_axi_bresp,
    m_axi_bvalid,
    m_axi_bready,
    m_axi_arid,
    m_axi_araddr,
    m_axi_arlen,
    m_axi_arsize,
    m_axi_arburst,
    m_axi_arlock,
    m_axi_arcache,
    m_axi_arprot,
    m_axi_arregion,
    m_axi_arqos,
    m_axi_arvalid,
    m_axi_arready,
    m_axi_rid,
    m_axi_rdata,
    m_axi_rresp,
    m_axi_rlast,
    m_axi_rvalid,
    m_axi_rready);
    input aclk;
    input aresetn;
   input [41:0]s_axi_awid;
   input [191:0]s_axi_awaddr;
   input [23:0]s_axi_awlen;
   input [8:0]s_axi_awsize;
   input [5:0]s_axi_awburst;
   input [2:0]s_axi_awlock;
   input [11:0]s_axi_awcache;
   input [8:0]s_axi_awprot;
   input [11:0]s_axi_awqos;
   input [2:0]s_axi_awvalid;
   output [2:0]s_axi_awready;
   input [95:0]s_axi_wdata;
   input [11:0]s_axi_wstrb;
   input [2:0]s_axi_wlast;
   input [2:0]s_axi_wvalid;
   output [2:0]s_axi_wready;
   output [41:0]s_axi_bid;
   output [5:0]s_axi_bresp;
   output [2:0]s_axi_bvalid;
   input [2:0]s_axi_bready;
   input [41:0]s_axi_arid;
   input [191:0]s_axi_araddr;
   input [23:0]s_axi_arlen;
   input [8:0]s_axi_arsize;
   input [5:0]s_axi_arburst;
   input [2:0]s_axi_arlock;
   input [11:0]s_axi_arcache;
   input [8:0]s_axi_arprot;
   input [11:0]s_axi_arqos;
   input [2:0]s_axi_arvalid;
   output [2:0]s_axi_arready;
   output [41:0]s_axi_rid;
   output [95:0]s_axi_rdata;
   output [5:0]s_axi_rresp;
   output [2:0]s_axi_rlast;
   output [2:0]s_axi_rvalid;
    input [2:0]s_axi_rready;
   output [13:0]m_axi_awid;
   output [63:0]m_axi_awaddr;
   output [7:0]m_axi_awlen;
   output [2:0]m_axi_awsize;
   output [1:0]m_axi_awburst;
   output [0:0]m_axi_awlock;
   output [3:0]m_axi_awcache;
   output [2:0]m_axi_awprot;
   output [3:0]m_axi_awregion;
   output [3:0]m_axi_awqos;
   output [0:0]m_axi_awvalid;
   input [0:0]m_axi_awready;
   output [31:0]m_axi_wdata;
   output [3:0]m_axi_wstrb;
   output [0:0]m_axi_wlast;
   output [0:0]m_axi_wvalid;
   input [0:0]m_axi_wready;
   input [13:0]m_axi_bid;
   input [1:0]m_axi_bresp;
   input [0:0]m_axi_bvalid;
   output [0:0]m_axi_bready;
   output [13:0]m_axi_arid;
   output [63:0]m_axi_araddr;
   output [7:0]m_axi_arlen;
   output [2:0]m_axi_arsize;
   output [1:0]m_axi_arburst;
   output [0:0]m_axi_arlock;
   output [3:0]m_axi_arcache;
   output [2:0]m_axi_arprot;
   output [3:0]m_axi_arregion;
   output [3:0]m_axi_arqos;
   output [0:0]m_axi_arvalid;
   input [0:0]m_axi_arready;
   input [13:0]m_axi_rid;
   input [31:0]m_axi_rdata;
   input [1:0]m_axi_rresp;
   input [0:0]m_axi_rlast;
   input [0:0]m_axi_rvalid;
    output [0:0]m_axi_rready;

  wire aclk;
  wire aresetn;
  wire [63:0]m_axi_araddr;
  wire [1:0]m_axi_arburst;
  wire [13:0]m_axi_arid;
  wire [7:0]m_axi_arlen;
  wire [0:0]m_axi_arready;
  wire [0:0]m_axi_arvalid;
  wire [63:0]m_axi_awaddr;
  wire [1:0]m_axi_awburst;
  wire [13:0]m_axi_awid;
  wire [7:0]m_axi_awlen;
  wire [0:0]m_axi_awready;
  wire [0:0]m_axi_awvalid;
  wire [13:0]m_axi_bid;
  wire [0:0]m_axi_bready;
  wire [0:0]m_axi_bvalid;
  wire [31:0]m_axi_rdata;
  wire [13:0]m_axi_rid;
  wire [0:0]m_axi_rlast;
  wire [0:0]m_axi_rready;
  wire [0:0]m_axi_rvalid;
  wire [31:0]m_axi_wdata;
  wire [0:0]m_axi_wlast;
  wire [0:0]m_axi_wready;
  wire [3:0]m_axi_wstrb;
  wire [0:0]m_axi_wvalid;
  wire [191:0]s_axi_araddr;
  wire [5:0]s_axi_arburst;
  wire [41:0]s_axi_arid;
  wire [23:0]s_axi_arlen;
  wire [2:0]s_axi_arready;
  wire [2:0]s_axi_arvalid;
  wire [191:0]s_axi_awaddr;
  wire [5:0]s_axi_awburst;
  wire [41:0]s_axi_awid;
  wire [23:0]s_axi_awlen;
  wire [2:0]s_axi_awready;
  wire [2:0]s_axi_awvalid;
  wire [41:0]s_axi_bid;
  wire [2:0]s_axi_bready;
  wire [5:0]s_axi_bresp;
  wire [2:0]s_axi_bvalid;
  wire [95:0]s_axi_rdata;
  wire [41:0]s_axi_rid;
  wire [2:0]s_axi_rlast;
  wire [2:0]s_axi_rready;
  wire [5:0]s_axi_rresp;
  wire [2:0]s_axi_rvalid;
  wire [95:0]s_axi_wdata;
  wire [2:0]s_axi_wlast;
  wire [2:0]s_axi_wready;
  wire [11:0]s_axi_wstrb;
  wire [2:0]s_axi_wvalid;
  wire [63:0]NLW_inst_m_axi_araddr_UNCONNECTED;
  wire [63:0]NLW_inst_m_axi_awaddr_UNCONNECTED;
  wire [13:0]NLW_inst_m_axi_awid_UNCONNECTED;
  wire [13:0]NLW_inst_m_axi_bid_UNCONNECTED;
  wire [191:0]NLW_inst_s_axi_araddr_UNCONNECTED;
  wire [23:0]NLW_inst_s_axi_arlen_UNCONNECTED;
  wire [191:0]NLW_inst_s_axi_awaddr_UNCONNECTED;
  wire [23:0]NLW_inst_s_axi_awlen_UNCONNECTED;
  wire [2:0]NLW_inst_s_axi_awready_UNCONNECTED;
  wire [2:0]NLW_inst_s_axi_awvalid_UNCONNECTED;
  wire [2:0]NLW_inst_s_axi_bready_UNCONNECTED;
  wire [2:0]NLW_inst_s_axi_bvalid_UNCONNECTED;
  wire [95:0]NLW_inst_s_axi_wdata_UNCONNECTED;
  wire [2:0]NLW_inst_s_axi_wlast_UNCONNECTED;
  wire [2:0]NLW_inst_s_axi_wready_UNCONNECTED;
  wire [11:0]NLW_inst_s_axi_wstrb_UNCONNECTED;
  wire [2:0]NLW_inst_s_axi_wvalid_UNCONNECTED;

  system_xbar_1_axi_crossbar_v2_1_23_axi_crossbar inst
       (.aclk(aclk),
        .aresetn(aresetn),
        .m_axi_araddr({m_axi_araddr[16:2],NLW_inst_m_axi_araddr_UNCONNECTED[1:0]}),
        .m_axi_arburst(m_axi_arburst),
        .m_axi_arid(m_axi_arid[12:0]),
        .m_axi_arlen(m_axi_arlen[3:0]),
        .m_axi_arready(m_axi_arready),
        .m_axi_arvalid(m_axi_arvalid),
        .m_axi_awaddr({m_axi_awaddr[16:2],NLW_inst_m_axi_awaddr_UNCONNECTED[1:0]}),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awid({m_axi_awid[13],NLW_inst_m_axi_awid_UNCONNECTED[12],m_axi_awid[11:0]}),
        .m_axi_awlen(m_axi_awlen[3:0]),
        .m_axi_awready(m_axi_awready),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_bid({m_axi_bid[13],NLW_inst_m_axi_bid_UNCONNECTED[12],m_axi_bid[11:0]}),
        .m_axi_bready(m_axi_bready),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_rdata(m_axi_rdata),
        .m_axi_rid(m_axi_rid[12:0]),
        .m_axi_rlast(m_axi_rlast),
        .m_axi_rready(m_axi_rready),
        .m_axi_rvalid(m_axi_rvalid),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wready(m_axi_wready),
        .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wvalid(m_axi_wvalid),
        .s_axi_araddr({s_axi_araddr[127:66],NLW_inst_s_axi_araddr_UNCONNECTED[65:32],s_axi_araddr[31:2],NLW_inst_s_axi_araddr_UNCONNECTED[1:0]}),
        .s_axi_arburst(s_axi_arburst[1:0]),
        .s_axi_arid(s_axi_arid[11:0]),
        .s_axi_arlen({s_axi_arlen[11:8],NLW_inst_s_axi_arlen_UNCONNECTED[7:4],s_axi_arlen[3:0]}),
        .s_axi_arready(s_axi_arready[1:0]),
        .s_axi_arvalid(s_axi_arvalid[1:0]),
        .s_axi_awaddr({s_axi_awaddr[191:130],NLW_inst_s_axi_awaddr_UNCONNECTED[129:32],s_axi_awaddr[31:2],NLW_inst_s_axi_awaddr_UNCONNECTED[1:0]}),
        .s_axi_awburst(s_axi_awburst[1:0]),
        .s_axi_awid(s_axi_awid[11:0]),
        .s_axi_awlen({s_axi_awlen[19:16],NLW_inst_s_axi_awlen_UNCONNECTED[15:4],s_axi_awlen[3:0]}),
        .s_axi_awready({s_axi_awready[2],NLW_inst_s_axi_awready_UNCONNECTED[1],s_axi_awready[0]}),
        .s_axi_awvalid({s_axi_awvalid[2],NLW_inst_s_axi_awvalid_UNCONNECTED[1],s_axi_awvalid[0]}),
        .s_axi_bid(s_axi_bid[11:0]),
        .s_axi_bready({s_axi_bready[2],NLW_inst_s_axi_bready_UNCONNECTED[1],s_axi_bready[0]}),
        .s_axi_bresp(s_axi_bresp[1:0]),
        .s_axi_bvalid({s_axi_bvalid[2],NLW_inst_s_axi_bvalid_UNCONNECTED[1],s_axi_bvalid[0]}),
        .s_axi_rdata(s_axi_rdata[63:0]),
        .s_axi_rid(s_axi_rid[11:0]),
        .s_axi_rlast(s_axi_rlast[1:0]),
        .s_axi_rready(s_axi_rready[1:0]),
        .s_axi_rresp(s_axi_rresp[3:0]),
        .s_axi_rvalid(s_axi_rvalid[1:0]),
        .s_axi_wdata({s_axi_wdata[95:64],NLW_inst_s_axi_wdata_UNCONNECTED[63:32],s_axi_wdata[31:0]}),
        .s_axi_wlast({s_axi_wlast[2],NLW_inst_s_axi_wlast_UNCONNECTED[1],s_axi_wlast[0]}),
        .s_axi_wready({s_axi_wready[2],NLW_inst_s_axi_wready_UNCONNECTED[1],s_axi_wready[0]}),
        .s_axi_wstrb({s_axi_wstrb[11:8],NLW_inst_s_axi_wstrb_UNCONNECTED[7:4],s_axi_wstrb[3:0]}),
        .s_axi_wvalid({s_axi_wvalid[2],NLW_inst_s_axi_wvalid_UNCONNECTED[1],s_axi_wvalid[0]}));
endmodule

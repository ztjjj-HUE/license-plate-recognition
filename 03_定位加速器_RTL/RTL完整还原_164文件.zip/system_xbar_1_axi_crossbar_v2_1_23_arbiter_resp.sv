// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_arbiter_resp
   (p_2_in,
    SR,
    esc_last_rr_hot_reg_0__0_0b10be6 ,
    chosen,
    esc_last_rr_hot_reg_1__0_399c674 ,
    aclk,
    esc_last_rr_hot_reg_0__1_3090a81 ,
    esc_chosen_reg_1__0_620be56 ,
    esc_chosen_reg_1__1_b926e5c ,
    s_axi_bready,
    aresetn_d);
  output p_2_in;
  output [0:0]SR;
  output esc_last_rr_hot_reg_0__0_0b10be6 ;
  output [1:0]chosen;
  input esc_last_rr_hot_reg_1__0_399c674 ;
  input aclk;
  input esc_last_rr_hot_reg_0__1_3090a81 ;
  input esc_chosen_reg_1__0_620be56 ;
  input esc_chosen_reg_1__1_b926e5c ;
  input [0:0]s_axi_bready;
  input aresetn_d;

  wire esc_const1_c064970 ;
  wire [0:0]SR;
  wire aclk;
  wire aresetn_d;
  wire [1:0]chosen;
  wire esc_chosen_0__i_1__0_n_0_f3b8818 ;
  wire esc_chosen_1__i_1__0_n_0_a3b5146 ;
  wire esc_chosen_reg_1__0_620be56 ;
  wire esc_chosen_reg_1__1_b926e5c ;
  wire esc_last_rr_hot_reg_0__0_0b10be6 ;
  wire esc_last_rr_hot_reg_0__1_3090a81 ;
  wire esc_last_rr_hot_reg_1__0_399c674 ;
  wire [1:0]next_rr_hot;
  wire p_2_in;
  wire [0:0]s_axi_bready;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_chosen_0__i_1__0_8a74693
  assign esc_chosen_0__i_1__0_n_0_f3b8818 = ((next_rr_hot[0]) ? (((s_axi_bready) ? (((esc_chosen_reg_1__1_b926e5c) ? (1'b1) : (((chosen[0]) ? (1'b1) : (esc_chosen_reg_1__0_620be56))))) : (((chosen[1]) ? (((esc_chosen_reg_1__1_b926e5c) ? (chosen[0]) : (((chosen[0]) ? (1'b1) : (esc_chosen_reg_1__0_620be56))))) : (((esc_chosen_reg_1__1_b926e5c) ? (1'b1) : (((chosen[0]) ? (1'b1) : (esc_chosen_reg_1__0_620be56))))))))) : (((s_axi_bready) ? (((esc_chosen_reg_1__1_b926e5c) ? (1'b0) : (((chosen[0]) ? (~(esc_chosen_reg_1__0_620be56)) : (1'b0))))) : (((chosen[1]) ? (chosen[0]) : (((esc_chosen_reg_1__1_b926e5c) ? (((chosen[0]) ? (esc_chosen_reg_1__0_620be56) : (1'b0))) : (chosen[0]))))))));

  // Reconstructed LUT4: esc_chosen_0__i_2_16c1555
  assign next_rr_hot[0] = ((esc_last_rr_hot_reg_0__0_0b10be6) ? (((esc_chosen_reg_1__1_b926e5c) ? (((p_2_in) ? (esc_chosen_reg_1__0_620be56) : (1'b0))) : (esc_chosen_reg_1__0_620be56))) : (((p_2_in) ? (esc_chosen_reg_1__0_620be56) : (1'b0))));

  // Reconstructed LUT6: esc_chosen_1__i_1__0_f231717
  assign esc_chosen_1__i_1__0_n_0_a3b5146 = ((next_rr_hot[1]) ? (((s_axi_bready) ? (((chosen[1]) ? (1'b1) : (((esc_chosen_reg_1__1_b926e5c) ? (1'b1) : (esc_chosen_reg_1__0_620be56))))) : (((chosen[1]) ? (1'b1) : (((esc_chosen_reg_1__1_b926e5c) ? (((chosen[0]) ? (~(esc_chosen_reg_1__0_620be56)) : (1'b1))) : (((chosen[0]) ? (1'b0) : (esc_chosen_reg_1__0_620be56))))))))) : (((s_axi_bready) ? (((chosen[1]) ? (((esc_chosen_reg_1__1_b926e5c) ? (1'b0) : (~(esc_chosen_reg_1__0_620be56)))) : (1'b0))) : (((chosen[1]) ? (((esc_chosen_reg_1__1_b926e5c) ? (1'b1) : (((chosen[0]) ? (1'b1) : (~(esc_chosen_reg_1__0_620be56)))))) : (1'b0))))));

  // Reconstructed LUT4: esc_chosen_1__i_2__0_81c4c08
  assign next_rr_hot[1] = ((esc_last_rr_hot_reg_0__0_0b10be6) ? (esc_chosen_reg_1__1_b926e5c) : (((esc_chosen_reg_1__0_620be56) ? (1'b0) : (((p_2_in) ? (esc_chosen_reg_1__1_b926e5c) : (1'b0))))));

  // Reconstructed FDRE: esc_chosen_reg_0_cbf18f4
  reg recovered_6_q = 1'b0;
  assign chosen[0] = recovered_6_q;
  wire recovered_6_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((SR) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (esc_chosen_0__i_1__0_n_0_f3b8818)))) recovered_6_q <= (esc_chosen_0__i_1__0_n_0_f3b8818);
  end

  // Reconstructed FDRE: esc_chosen_reg_1_fa03fcd
  reg recovered_7_q = 1'b0;
  assign chosen[1] = recovered_7_q;
  wire recovered_7_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((SR) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (esc_chosen_1__i_1__0_n_0_a3b5146)))) recovered_7_q <= (esc_chosen_1__i_1__0_n_0_a3b5146);
  end

  // Reconstructed LUT1: esc_gen_arbiter_m_mesg_i_13__i_1__0_aac8230
  assign SR = ~(aresetn_d);

  // Reconstructed FDRE: esc_last_rr_hot_reg_0_b00b3ee
  reg recovered_9_q = 1'b0;
  assign esc_last_rr_hot_reg_0__0_0b10be6 = recovered_9_q;
  wire recovered_9_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((SR) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (esc_last_rr_hot_reg_0__1_3090a81)))) recovered_9_q <= (esc_last_rr_hot_reg_0__1_3090a81);
  end

  // Reconstructed FDSE: esc_last_rr_hot_reg_1_6b93826
  reg recovered_10_q = 1'b1;
  assign p_2_in = recovered_10_q;
  wire recovered_10_reset = ((SR)) && ((SR) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_10_reset || (((SR) === 1'bx) && (recovered_10_q == 1'b1))) recovered_10_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_10_q == (esc_last_rr_hot_reg_1__0_399c674)))) recovered_10_q <= (esc_last_rr_hot_reg_1__0_399c674);
  end

endmodule

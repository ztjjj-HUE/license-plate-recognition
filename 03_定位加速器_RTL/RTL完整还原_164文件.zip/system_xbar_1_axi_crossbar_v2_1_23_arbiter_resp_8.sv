// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_arbiter_resp_8
   (chosen,
    esc_chosen_reg_1__0_620be56 ,
    esc_chosen_reg_1__1_b926e5c ,
    s_axi_rready,
    esc_last_rr_hot_reg_0__0_0b10be6 ,
    reset,
    aclk);
  output [1:0]chosen;
  input esc_chosen_reg_1__0_620be56 ;
  input esc_chosen_reg_1__1_b926e5c ;
  input [0:0]s_axi_rready;
  input esc_last_rr_hot_reg_0__0_0b10be6 ;
  input reset;
  input aclk;

  wire esc_const1_c064970 ;
  wire aclk;
  wire [1:0]chosen;
  wire esc_chosen_0__i_1_n_0_158a51b ;
  wire esc_chosen_1__i_1_n_0_c6cc455 ;
  wire esc_chosen_1__i_2_n_0_b22871d ;
  wire esc_chosen_reg_1__0_620be56 ;
  wire esc_chosen_reg_1__1_b926e5c ;
  wire esc_last_rr_hot_0__i_1_n_0_3bc735d ;
  wire esc_last_rr_hot_1__i_1_n_0_dc9b418 ;
  wire esc_last_rr_hot_reg_0__0_0b10be6 ;
  wire esc_last_rr_hot_reg_n_0__0_df186df ;
  wire p_2_in;
  wire reset;
  wire [0:0]s_axi_rready;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_chosen_0__i_1_f125885
  assign esc_chosen_0__i_1_n_0_158a51b = ((chosen[0]) ? (((esc_chosen_reg_1__1_b926e5c) ? (esc_chosen_1__i_2_n_0_b22871d) : (((p_2_in) ? (1'b1) : (((esc_chosen_reg_1__0_620be56) ? (((esc_last_rr_hot_reg_n_0__0_df186df) ? (1'b1) : (esc_chosen_1__i_2_n_0_b22871d))) : (esc_chosen_1__i_2_n_0_b22871d))))))) : (((esc_chosen_reg_1__1_b926e5c) ? (1'b0) : (((p_2_in) ? (~(esc_chosen_1__i_2_n_0_b22871d)) : (((esc_chosen_reg_1__0_620be56) ? (((esc_last_rr_hot_reg_n_0__0_df186df) ? (~(esc_chosen_1__i_2_n_0_b22871d)) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT6: esc_chosen_1__i_1_df11b03
  assign esc_chosen_1__i_1_n_0_c6cc455 = ((chosen[1]) ? (((esc_chosen_reg_1__0_620be56) ? (esc_chosen_1__i_2_n_0_b22871d) : (((esc_last_rr_hot_reg_n_0__0_df186df) ? (1'b1) : (((p_2_in) ? (((esc_chosen_reg_1__1_b926e5c) ? (1'b1) : (esc_chosen_1__i_2_n_0_b22871d))) : (esc_chosen_1__i_2_n_0_b22871d))))))) : (((esc_chosen_reg_1__0_620be56) ? (1'b0) : (((esc_last_rr_hot_reg_n_0__0_df186df) ? (~(esc_chosen_1__i_2_n_0_b22871d)) : (((p_2_in) ? (((esc_chosen_reg_1__1_b926e5c) ? (~(esc_chosen_1__i_2_n_0_b22871d)) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT5: esc_chosen_1__i_2_86843e2
  assign esc_chosen_1__i_2_n_0_b22871d = ((chosen[0]) ? (((chosen[1]) ? (((esc_chosen_reg_1__0_620be56) ? (((esc_chosen_reg_1__1_b926e5c) ? (1'b1) : (~(s_axi_rready)))) : (~(s_axi_rready)))) : (((esc_chosen_reg_1__0_620be56) ? (((esc_chosen_reg_1__1_b926e5c) ? (1'b1) : (~(s_axi_rready)))) : (((esc_chosen_reg_1__1_b926e5c) ? (1'b0) : (~(s_axi_rready)))))))) : (((chosen[1]) ? (((esc_chosen_reg_1__0_620be56) ? (esc_chosen_reg_1__1_b926e5c) : (~(s_axi_rready)))) : (((esc_chosen_reg_1__0_620be56) ? (esc_chosen_reg_1__1_b926e5c) : (1'b0))))));

  // Reconstructed FDRE: esc_chosen_reg_0_cbf18f4
  reg recovered_5_q = 1'b0;
  assign chosen[0] = recovered_5_q;
  wire recovered_5_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((reset) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (esc_chosen_0__i_1_n_0_158a51b)))) recovered_5_q <= (esc_chosen_0__i_1_n_0_158a51b);
  end

  // Reconstructed FDRE: esc_chosen_reg_1_fa03fcd
  reg recovered_6_q = 1'b0;
  assign chosen[1] = recovered_6_q;
  wire recovered_6_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((reset) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (esc_chosen_1__i_1_n_0_c6cc455)))) recovered_6_q <= (esc_chosen_1__i_1_n_0_c6cc455);
  end

  // Reconstructed LUT6: esc_last_rr_hot_0__i_1_f3a0842
  assign esc_last_rr_hot_0__i_1_n_0_3bc735d = ((s_axi_rready) ? (((esc_chosen_reg_1__1_b926e5c) ? (((esc_chosen_reg_1__0_620be56) ? (esc_last_rr_hot_reg_n_0__0_df186df) : (1'b0))) : (((esc_chosen_reg_1__0_620be56) ? (((p_2_in) ? (1'b1) : (esc_last_rr_hot_reg_n_0__0_df186df))) : (p_2_in))))) : (((esc_chosen_reg_1__1_b926e5c) ? (((esc_chosen_reg_1__0_620be56) ? (esc_last_rr_hot_reg_n_0__0_df186df) : (((esc_last_rr_hot_reg_0__0_0b10be6) ? (esc_last_rr_hot_reg_n_0__0_df186df) : (1'b0))))) : (((esc_chosen_reg_1__0_620be56) ? (((esc_last_rr_hot_reg_0__0_0b10be6) ? (esc_last_rr_hot_reg_n_0__0_df186df) : (((p_2_in) ? (1'b1) : (esc_last_rr_hot_reg_n_0__0_df186df))))) : (((esc_last_rr_hot_reg_0__0_0b10be6) ? (esc_last_rr_hot_reg_n_0__0_df186df) : (p_2_in))))))));

  // Reconstructed LUT6: esc_last_rr_hot_1__i_1_d1b3105
  assign esc_last_rr_hot_1__i_1_n_0_dc9b418 = ((s_axi_rready) ? (((esc_chosen_reg_1__1_b926e5c) ? (((esc_chosen_reg_1__0_620be56) ? (p_2_in) : (((p_2_in) ? (1'b1) : (esc_last_rr_hot_reg_n_0__0_df186df))))) : (((esc_chosen_reg_1__0_620be56) ? (1'b0) : (esc_last_rr_hot_reg_n_0__0_df186df))))) : (((esc_chosen_reg_1__1_b926e5c) ? (((esc_chosen_reg_1__0_620be56) ? (p_2_in) : (((esc_last_rr_hot_reg_0__0_0b10be6) ? (p_2_in) : (((p_2_in) ? (1'b1) : (esc_last_rr_hot_reg_n_0__0_df186df))))))) : (((esc_chosen_reg_1__0_620be56) ? (((esc_last_rr_hot_reg_0__0_0b10be6) ? (p_2_in) : (1'b0))) : (((esc_last_rr_hot_reg_0__0_0b10be6) ? (p_2_in) : (esc_last_rr_hot_reg_n_0__0_df186df))))))));

  // Reconstructed FDRE: esc_last_rr_hot_reg_0_b00b3ee
  reg recovered_9_q = 1'b0;
  assign esc_last_rr_hot_reg_n_0__0_df186df = recovered_9_q;
  wire recovered_9_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((reset) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (esc_last_rr_hot_0__i_1_n_0_3bc735d)))) recovered_9_q <= (esc_last_rr_hot_0__i_1_n_0_3bc735d);
  end

  // Reconstructed FDSE: esc_last_rr_hot_reg_1_6b93826
  reg recovered_10_q = 1'b1;
  assign p_2_in = recovered_10_q;
  wire recovered_10_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_10_reset || (((reset) === 1'bx) && (recovered_10_q == 1'b1))) recovered_10_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_10_q == (esc_last_rr_hot_1__i_1_n_0_dc9b418)))) recovered_10_q <= (esc_last_rr_hot_1__i_1_n_0_dc9b418);
  end

endmodule

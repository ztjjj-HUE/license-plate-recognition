// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_decerr_slave
   (mi_awready,
    mi_wready_1,
    mi_bvalid_1,
    mi_rvalid_1,
    mi_arready,
    mi_rlast_1,
    esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047 ,
    esc_FSM_onehot_gen_axi_write_cs_reg_1__0_51b354e ,
    esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d ,
    esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d ,
    reset,
    aclk,
    Q,
    p_1_in,
    m_ready_d,
    mi_bready_1,
    esc_gen_axi_s_axi_bvalid_i_reg_0_5c86ab2 ,
    aresetn_d,
    mi_rready_1,
    p_1_in_0,
    esc_gen_axi_read_cs_reg_0__0_b336fc8 ,
    esc_gen_axi_read_cnt_reg_7__0_73f746d ,
    esc_gen_axi_s_axi_awready_i_reg_0_a4f981b ,
    esc_gen_axi_s_axi_awready_i_reg_1_5541a1c ,
    esc_gen_axi_s_axi_rlast_i_reg_0_71a8bed ,
    m_axi_awid);
  output [0:0]mi_awready;
  output mi_wready_1;
  output mi_bvalid_1;
  output mi_rvalid_1;
  output [0:0]mi_arready;
  output mi_rlast_1;
  output esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047 ;
  output esc_FSM_onehot_gen_axi_write_cs_reg_1__0_51b354e ;
  output [13:0]esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d ;
  output [13:0]esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d ;
  input reset;
  input aclk;
  input [0:0]Q;
  input p_1_in;
  input [0:0]m_ready_d;
  input mi_bready_1;
  input esc_gen_axi_s_axi_bvalid_i_reg_0_5c86ab2 ;
  input aresetn_d;
  input mi_rready_1;
  input p_1_in_0;
  input [0:0]esc_gen_axi_read_cs_reg_0__0_b336fc8 ;
  input [21:0]esc_gen_axi_read_cnt_reg_7__0_73f746d ;
  input esc_gen_axi_s_axi_awready_i_reg_0_a4f981b ;
  input esc_gen_axi_s_axi_awready_i_reg_1_5541a1c ;
  input esc_gen_axi_s_axi_rlast_i_reg_0_71a8bed ;
  input [13:0]m_axi_awid;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire esc_FSM_onehot_gen_axi_write_cs_0__i_1_n_0_cb33c0a ;
  wire esc_FSM_onehot_gen_axi_write_cs_1__i_1_n_0_ff36043 ;
  wire esc_FSM_onehot_gen_axi_write_cs_2__i_1_n_0_22f9d92 ;
  wire esc_FSM_onehot_gen_axi_write_cs_reg_1__0_51b354e ;
  wire esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047 ;
  wire esc_FSM_onehot_gen_axi_write_cs_reg_n_0__0_6ea7869 ;
  wire [0:0]Q;
  wire aclk;
  wire aresetn_d;
  wire esc_gen_axi_read_cnt_4__i_2_n_0_97b018a ;
  wire esc_gen_axi_read_cnt_5__i_2_n_0_8aa12fd ;
  wire esc_gen_axi_read_cnt_7__i_1_n_0_e223c46 ;
  wire esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b ;
  wire esc_gen_axi_read_cnt_7__i_4_n_0_ebb0cb0 ;
  wire [7:1]esc_gen_axi_read_cnt_reg_c2245d9 ;
  wire [21:0]esc_gen_axi_read_cnt_reg_7__0_73f746d ;
  wire [0:0]esc_gen_axi_read_cnt_reg__0_49dfe50 ;
  wire esc_gen_axi_read_cs_0__i_1_n_0_11c5517 ;
  wire [0:0]esc_gen_axi_read_cs_reg_0__0_b336fc8 ;
  wire esc_gen_axi_s_axi_arready_i_i_1_n_0_020c060 ;
  wire esc_gen_axi_s_axi_arready_i_i_2_n_0_498ea98 ;
  wire esc_gen_axi_s_axi_awready_i_i_1_n_0_784fd3c ;
  wire esc_gen_axi_s_axi_awready_i_reg_0_a4f981b ;
  wire esc_gen_axi_s_axi_awready_i_reg_1_5541a1c ;
  wire esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa ;
  wire [13:0]esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d ;
  wire esc_gen_axi_s_axi_bvalid_i_i_1_n_0_19a3c41 ;
  wire esc_gen_axi_s_axi_bvalid_i_reg_0_5c86ab2 ;
  wire esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb ;
  wire [13:0]esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d ;
  wire esc_gen_axi_s_axi_rlast_i_i_1_n_0_5c500d0 ;
  wire esc_gen_axi_s_axi_rlast_i_i_3_n_0_5a9b61a ;
  wire esc_gen_axi_s_axi_rlast_i_i_5_n_0_c104863 ;
  wire esc_gen_axi_s_axi_rlast_i_reg_0_71a8bed ;
  wire esc_gen_axi_s_axi_wready_i_i_1_n_0_6456074 ;
  wire [13:0]m_axi_awid;
  wire [0:0]m_ready_d;
  wire [0:0]mi_arready;
  wire [0:0]mi_awready;
  wire mi_bready_1;
  wire mi_bvalid_1;
  wire mi_rlast_1;
  wire mi_rready_1;
  wire mi_rvalid_1;
  wire mi_wready_1;
  wire [7:0]p_0_in;
  wire p_1_in;
  wire p_1_in_0;
  wire reset;
  wire s_axi_wready_i;

  // Reconstructed LUT4: esc_FSM_onehot_gen_axi_write_cs_0__i_1_160dd4d
  assign esc_FSM_onehot_gen_axi_write_cs_0__i_1_n_0_cb33c0a = ((esc_FSM_onehot_gen_axi_write_cs_reg_n_0__0_6ea7869) ? (((s_axi_wready_i) ? (esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047) : (1'b1))) : (((s_axi_wready_i) ? (esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047) : (((mi_bready_1) ? (esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047) : (1'b0))))));

  // Reconstructed LUT5: esc_FSM_onehot_gen_axi_write_cs_1__i_1_2213f5d
  assign esc_FSM_onehot_gen_axi_write_cs_1__i_1_n_0_ff36043 = ((esc_FSM_onehot_gen_axi_write_cs_reg_1__0_51b354e) ? (((esc_FSM_onehot_gen_axi_write_cs_reg_n_0__0_6ea7869) ? (1'b1) : (((s_axi_wready_i) ? (1'b0) : (((mi_bready_1) ? (~(esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047)) : (1'b1))))))) : (((esc_FSM_onehot_gen_axi_write_cs_reg_n_0__0_6ea7869) ? (((s_axi_wready_i) ? (1'b1) : (((mi_bready_1) ? (esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT4: esc_FSM_onehot_gen_axi_write_cs_2__i_1_d082928
  assign esc_FSM_onehot_gen_axi_write_cs_2__i_1_n_0_22f9d92 = ((esc_FSM_onehot_gen_axi_write_cs_reg_1__0_51b354e) ? (((s_axi_wready_i) ? (1'b1) : (esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047))) : (((s_axi_wready_i) ? (1'b0) : (((mi_bready_1) ? (1'b0) : (esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047))))));

  // Reconstructed LUT6: esc_FSM_onehot_gen_axi_write_cs_2__i_2_8a05424
  assign s_axi_wready_i = ((mi_awready) ? (((Q) ? (((p_1_in) ? (esc_gen_axi_s_axi_bvalid_i_reg_0_5c86ab2) : (((m_ready_d) ? (esc_gen_axi_s_axi_bvalid_i_reg_0_5c86ab2) : (((esc_FSM_onehot_gen_axi_write_cs_reg_n_0__0_6ea7869) ? (1'b1) : (esc_gen_axi_s_axi_bvalid_i_reg_0_5c86ab2))))))) : (esc_gen_axi_s_axi_bvalid_i_reg_0_5c86ab2))) : (esc_gen_axi_s_axi_bvalid_i_reg_0_5c86ab2));

  // Reconstructed FDSE: esc_FSM_onehot_gen_axi_write_cs_reg_0_0e34489
  reg recovered_5_q = 1'b1;
  assign esc_FSM_onehot_gen_axi_write_cs_reg_n_0__0_6ea7869 = recovered_5_q;
  wire recovered_5_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((reset) === 1'bx) && (recovered_5_q == 1'b1))) recovered_5_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (esc_FSM_onehot_gen_axi_write_cs_0__i_1_n_0_cb33c0a)))) recovered_5_q <= (esc_FSM_onehot_gen_axi_write_cs_0__i_1_n_0_cb33c0a);
  end

  // Reconstructed FDRE: esc_FSM_onehot_gen_axi_write_cs_reg_1_dc473f5
  reg recovered_6_q = 1'b0;
  assign esc_FSM_onehot_gen_axi_write_cs_reg_1__0_51b354e = recovered_6_q;
  wire recovered_6_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((reset) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (esc_FSM_onehot_gen_axi_write_cs_1__i_1_n_0_ff36043)))) recovered_6_q <= (esc_FSM_onehot_gen_axi_write_cs_1__i_1_n_0_ff36043);
  end

  // Reconstructed FDRE: esc_FSM_onehot_gen_axi_write_cs_reg_2_4d655b4
  reg recovered_7_q = 1'b0;
  assign esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047 = recovered_7_q;
  wire recovered_7_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((reset) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_7_q == (esc_FSM_onehot_gen_axi_write_cs_2__i_1_n_0_22f9d92)))) recovered_7_q <= (esc_FSM_onehot_gen_axi_write_cs_2__i_1_n_0_22f9d92);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT3: esc_gen_axi_read_cnt_0__i_1_f940a13
  assign p_0_in[0] = ((esc_gen_axi_read_cnt_reg_7__0_73f746d [14]) ? (((mi_rvalid_1) ? (~(esc_gen_axi_read_cnt_reg__0_49dfe50)) : (1'b1))) : (((mi_rvalid_1) ? (~(esc_gen_axi_read_cnt_reg__0_49dfe50)) : (1'b0))));

  // Reconstructed LUT4: esc_gen_axi_read_cnt_1__i_1_6eebdd0
  assign p_0_in[1] = ((esc_gen_axi_read_cnt_reg_c2245d9 [1]) ? (((esc_gen_axi_read_cnt_reg__0_49dfe50) ? (((mi_rvalid_1) ? (1'b1) : (esc_gen_axi_read_cnt_reg_7__0_73f746d [15]))) : (((mi_rvalid_1) ? (1'b0) : (esc_gen_axi_read_cnt_reg_7__0_73f746d [15]))))) : (((esc_gen_axi_read_cnt_reg__0_49dfe50) ? (((mi_rvalid_1) ? (1'b0) : (esc_gen_axi_read_cnt_reg_7__0_73f746d [15]))) : (((mi_rvalid_1) ? (1'b1) : (esc_gen_axi_read_cnt_reg_7__0_73f746d [15]))))));

  // Reconstructed LUT5: esc_gen_axi_read_cnt_2__i_1_db2cbdd
  assign p_0_in[2] = ((mi_rvalid_1) ? (((esc_gen_axi_read_cnt_reg_c2245d9 [2]) ? (((esc_gen_axi_read_cnt_reg__0_49dfe50) ? (1'b1) : (esc_gen_axi_read_cnt_reg_c2245d9 [1]))) : (((esc_gen_axi_read_cnt_reg__0_49dfe50) ? (1'b0) : (~(esc_gen_axi_read_cnt_reg_c2245d9 [1])))))) : (esc_gen_axi_read_cnt_reg_7__0_73f746d [16]));

  // Reconstructed LUT6: esc_gen_axi_read_cnt_3__i_1_a1b4ece
  assign p_0_in[3] = ((mi_rvalid_1) ? (((esc_gen_axi_read_cnt_reg_c2245d9 [3]) ? (((esc_gen_axi_read_cnt_reg_c2245d9 [1]) ? (1'b1) : (((esc_gen_axi_read_cnt_reg__0_49dfe50) ? (1'b1) : (esc_gen_axi_read_cnt_reg_c2245d9 [2]))))) : (((esc_gen_axi_read_cnt_reg_c2245d9 [1]) ? (1'b0) : (((esc_gen_axi_read_cnt_reg__0_49dfe50) ? (1'b0) : (~(esc_gen_axi_read_cnt_reg_c2245d9 [2])))))))) : (esc_gen_axi_read_cnt_reg_7__0_73f746d [17]));

  // Reconstructed LUT3: esc_gen_axi_read_cnt_4__i_1_bcc428a
  assign p_0_in[4] = ((mi_rvalid_1) ? (((esc_gen_axi_read_cnt_reg_c2245d9 [4]) ? (esc_gen_axi_read_cnt_4__i_2_n_0_97b018a) : (~(esc_gen_axi_read_cnt_4__i_2_n_0_97b018a)))) : (1'b0));

  // Reconstructed LUT4: esc_gen_axi_read_cnt_4__i_2_7913297
  assign esc_gen_axi_read_cnt_4__i_2_n_0_97b018a = ((esc_gen_axi_read_cnt_reg_c2245d9 [3]) ? (1'b1) : (((esc_gen_axi_read_cnt_reg_c2245d9 [1]) ? (1'b1) : (((esc_gen_axi_read_cnt_reg__0_49dfe50) ? (1'b1) : (esc_gen_axi_read_cnt_reg_c2245d9 [2]))))));

  // Reconstructed LUT3: esc_gen_axi_read_cnt_5__i_1_d68ca26
  assign p_0_in[5] = ((mi_rvalid_1) ? (((esc_gen_axi_read_cnt_reg_c2245d9 [5]) ? (esc_gen_axi_read_cnt_5__i_2_n_0_8aa12fd) : (~(esc_gen_axi_read_cnt_5__i_2_n_0_8aa12fd)))) : (1'b0));

  // Reconstructed LUT5: esc_gen_axi_read_cnt_5__i_2_d3cb1fb
  assign esc_gen_axi_read_cnt_5__i_2_n_0_8aa12fd = ((esc_gen_axi_read_cnt_reg_c2245d9 [4]) ? (1'b1) : (((esc_gen_axi_read_cnt_reg_c2245d9 [2]) ? (1'b1) : (((esc_gen_axi_read_cnt_reg__0_49dfe50) ? (1'b1) : (((esc_gen_axi_read_cnt_reg_c2245d9 [1]) ? (1'b1) : (esc_gen_axi_read_cnt_reg_c2245d9 [3]))))))));

  // Reconstructed LUT3: esc_gen_axi_read_cnt_6__i_1_4575072
  assign p_0_in[6] = ((mi_rvalid_1) ? (((esc_gen_axi_read_cnt_reg_c2245d9 [6]) ? (esc_gen_axi_read_cnt_7__i_4_n_0_ebb0cb0) : (~(esc_gen_axi_read_cnt_7__i_4_n_0_ebb0cb0)))) : (1'b0));

  // Reconstructed LUT6: esc_gen_axi_read_cnt_7__i_1_e5bf29f
  assign esc_gen_axi_read_cnt_7__i_1_n_0_e223c46 = ((mi_arready) ? (((esc_gen_axi_read_cs_reg_0__0_b336fc8) ? (((p_1_in_0) ? (((mi_rvalid_1) ? (((mi_rready_1) ? (esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b) : (1'b0))) : (1'b0))) : (((mi_rvalid_1) ? (((mi_rready_1) ? (esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b) : (1'b0))) : (1'b1))))) : (((mi_rvalid_1) ? (((mi_rready_1) ? (esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b) : (1'b0))) : (1'b0))))) : (((mi_rvalid_1) ? (((mi_rready_1) ? (esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b) : (1'b0))) : (1'b0))));

  // Reconstructed LUT4: esc_gen_axi_read_cnt_7__i_2_b66fc70
  assign p_0_in[7] = ((mi_rvalid_1) ? (((esc_gen_axi_read_cnt_reg_c2245d9 [7]) ? (((esc_gen_axi_read_cnt_7__i_4_n_0_ebb0cb0) ? (1'b1) : (esc_gen_axi_read_cnt_reg_c2245d9 [6]))) : (((esc_gen_axi_read_cnt_7__i_4_n_0_ebb0cb0) ? (1'b0) : (~(esc_gen_axi_read_cnt_reg_c2245d9 [6])))))) : (1'b0));

  // Reconstructed LUT3: esc_gen_axi_read_cnt_7__i_3_7578a53
  assign esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b = ((esc_gen_axi_read_cnt_reg_c2245d9 [7]) ? (1'b1) : (((esc_gen_axi_read_cnt_7__i_4_n_0_ebb0cb0) ? (1'b1) : (esc_gen_axi_read_cnt_reg_c2245d9 [6]))));

  // Reconstructed LUT6: esc_gen_axi_read_cnt_7__i_4_336dd02
  assign esc_gen_axi_read_cnt_7__i_4_n_0_ebb0cb0 = ((esc_gen_axi_read_cnt_reg_c2245d9 [5]) ? (1'b1) : (((esc_gen_axi_read_cnt_reg_c2245d9 [3]) ? (1'b1) : (((esc_gen_axi_read_cnt_reg_c2245d9 [1]) ? (1'b1) : (((esc_gen_axi_read_cnt_reg__0_49dfe50) ? (1'b1) : (((esc_gen_axi_read_cnt_reg_c2245d9 [2]) ? (1'b1) : (esc_gen_axi_read_cnt_reg_c2245d9 [4]))))))))));

  // Reconstructed FDRE: esc_gen_axi_read_cnt_reg_0_7993182
  reg recovered_23_q = 1'b0;
  assign esc_gen_axi_read_cnt_reg__0_49dfe50 = recovered_23_q;
  wire recovered_23_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_23_reset || (((reset) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) || ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bz) || (((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bx) && (recovered_23_q == (p_0_in[0])))) recovered_23_q <= (p_0_in[0]);
  end

  // Reconstructed FDRE: esc_gen_axi_read_cnt_reg_1_5e333f8
  reg recovered_24_q = 1'b0;
  assign esc_gen_axi_read_cnt_reg_c2245d9 [1] = recovered_24_q;
  wire recovered_24_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_24_reset || (((reset) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) || ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bz) || (((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bx) && (recovered_24_q == (p_0_in[1])))) recovered_24_q <= (p_0_in[1]);
  end

  // Reconstructed FDRE: esc_gen_axi_read_cnt_reg_2_b3af4fa
  reg recovered_25_q = 1'b0;
  assign esc_gen_axi_read_cnt_reg_c2245d9 [2] = recovered_25_q;
  wire recovered_25_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_25_reset || (((reset) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) || ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bz) || (((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bx) && (recovered_25_q == (p_0_in[2])))) recovered_25_q <= (p_0_in[2]);
  end

  // Reconstructed FDRE: esc_gen_axi_read_cnt_reg_3_166f899
  reg recovered_26_q = 1'b0;
  assign esc_gen_axi_read_cnt_reg_c2245d9 [3] = recovered_26_q;
  wire recovered_26_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_26_reset || (((reset) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) || ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bz) || (((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bx) && (recovered_26_q == (p_0_in[3])))) recovered_26_q <= (p_0_in[3]);
  end

  // Reconstructed FDRE: esc_gen_axi_read_cnt_reg_4_63b334b
  reg recovered_27_q = 1'b0;
  assign esc_gen_axi_read_cnt_reg_c2245d9 [4] = recovered_27_q;
  wire recovered_27_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_27_reset || (((reset) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) || ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bz) || (((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bx) && (recovered_27_q == (p_0_in[4])))) recovered_27_q <= (p_0_in[4]);
  end

  // Reconstructed FDRE: esc_gen_axi_read_cnt_reg_5_4c7a6cd
  reg recovered_28_q = 1'b0;
  assign esc_gen_axi_read_cnt_reg_c2245d9 [5] = recovered_28_q;
  wire recovered_28_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_28_reset || (((reset) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) || ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bz) || (((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bx) && (recovered_28_q == (p_0_in[5])))) recovered_28_q <= (p_0_in[5]);
  end

  // Reconstructed FDRE: esc_gen_axi_read_cnt_reg_6_542e506
  reg recovered_29_q = 1'b0;
  assign esc_gen_axi_read_cnt_reg_c2245d9 [6] = recovered_29_q;
  wire recovered_29_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_29_reset || (((reset) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) || ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bz) || (((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bx) && (recovered_29_q == (p_0_in[6])))) recovered_29_q <= (p_0_in[6]);
  end

  // Reconstructed FDRE: esc_gen_axi_read_cnt_reg_7_21801b8
  reg recovered_30_q = 1'b0;
  assign esc_gen_axi_read_cnt_reg_c2245d9 [7] = recovered_30_q;
  wire recovered_30_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_30_reset || (((reset) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) || ((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bz) || (((esc_gen_axi_read_cnt_7__i_1_n_0_e223c46) === 1'bx) && (recovered_30_q == (p_0_in[7])))) recovered_30_q <= (p_0_in[7]);
  end

  // Reconstructed LUT6: esc_gen_axi_read_cs_0__i_1_8b2e5c6
  assign esc_gen_axi_read_cs_0__i_1_n_0_11c5517 = ((mi_arready) ? (((esc_gen_axi_read_cs_reg_0__0_b336fc8) ? (((p_1_in_0) ? (((mi_rvalid_1) ? (((mi_rready_1) ? (esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b) : (1'b1))) : (1'b0))) : (((mi_rvalid_1) ? (((mi_rready_1) ? (esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b) : (1'b1))) : (1'b1))))) : (((mi_rvalid_1) ? (((mi_rready_1) ? (esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b) : (1'b1))) : (1'b0))))) : (((mi_rvalid_1) ? (((mi_rready_1) ? (esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b) : (1'b1))) : (1'b0))));

  // Reconstructed FDRE: esc_gen_axi_read_cs_reg_0_45a4808
  reg recovered_32_q = 1'b0;
  assign mi_rvalid_1 = recovered_32_q;
  wire recovered_32_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_32_reset || (((reset) === 1'bx) && (recovered_32_q == 1'b0))) recovered_32_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_32_q == (esc_gen_axi_read_cs_0__i_1_n_0_11c5517)))) recovered_32_q <= (esc_gen_axi_read_cs_0__i_1_n_0_11c5517);
  end

  // Reconstructed LUT6: esc_gen_axi_s_axi_arready_i_i_1_80ffc8e
  assign esc_gen_axi_s_axi_arready_i_i_1_n_0_020c060 = ((esc_gen_axi_s_axi_arready_i_i_2_n_0_498ea98) ? (((mi_arready) ? (aresetn_d) : (((mi_rvalid_1) ? (((esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b) ? (1'b0) : (((mi_rready_1) ? (aresetn_d) : (1'b0))))) : (aresetn_d))))) : (1'b0));

  // Reconstructed LUT4: esc_gen_axi_s_axi_arready_i_i_2_dbf43f0
  assign esc_gen_axi_s_axi_arready_i_i_2_n_0_498ea98 = ((mi_rvalid_1) ? (1'b1) : (((p_1_in_0) ? (1'b1) : (((esc_gen_axi_read_cs_reg_0__0_b336fc8) ? (~(mi_arready)) : (1'b1))))));

  // Reconstructed FDRE: esc_gen_axi_s_axi_arready_i_reg_4e20423
  reg recovered_35_q = 1'b0;
  assign mi_arready = recovered_35_q;
  wire recovered_35_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_35_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_35_q == 1'b0))) recovered_35_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_35_q == (esc_gen_axi_s_axi_arready_i_i_1_n_0_020c060)))) recovered_35_q <= (esc_gen_axi_s_axi_arready_i_i_1_n_0_020c060);
  end

  // Reconstructed LUT6: esc_gen_axi_s_axi_awready_i_i_1_9a802de
  assign esc_gen_axi_s_axi_awready_i_i_1_n_0_784fd3c = ((mi_awready) ? (((esc_FSM_onehot_gen_axi_write_cs_reg_n_0__0_6ea7869) ? (((esc_gen_axi_s_axi_awready_i_reg_1_5541a1c) ? (1'b1) : (((Q) ? (((esc_gen_axi_s_axi_awready_i_reg_0_a4f981b) ? (1'b1) : (esc_FSM_onehot_gen_axi_write_cs_reg_1__0_51b354e))) : (1'b1))))) : (1'b1))) : (((esc_FSM_onehot_gen_axi_write_cs_reg_n_0__0_6ea7869) ? (1'b1) : (esc_gen_axi_s_axi_awready_i_reg_1_5541a1c))));

  // Reconstructed FDRE: esc_gen_axi_s_axi_awready_i_reg_0ff185b
  reg recovered_37_q = 1'b0;
  assign mi_awready = recovered_37_q;
  wire recovered_37_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_37_reset || (((reset) === 1'bx) && (recovered_37_q == 1'b0))) recovered_37_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_37_q == (esc_gen_axi_s_axi_awready_i_i_1_n_0_784fd3c)))) recovered_37_q <= (esc_gen_axi_s_axi_awready_i_i_1_n_0_784fd3c);
  end

  // Reconstructed LUT5: esc_gen_axi_s_axi_bid_i_13__i_1_2cdf397
  assign esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa = ((esc_FSM_onehot_gen_axi_write_cs_reg_n_0__0_6ea7869) ? (((m_ready_d) ? (1'b0) : (((p_1_in) ? (1'b0) : (((Q) ? (mi_awready) : (1'b0))))))) : (1'b0));

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_0_d577ee3
  reg recovered_39_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [0] = recovered_39_q;
  wire recovered_39_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_39_reset || (((reset) === 1'bx) && (recovered_39_q == 1'b0))) recovered_39_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_39_q == (m_axi_awid[0])))) recovered_39_q <= (m_axi_awid[0]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_10_16ebb7f
  reg recovered_40_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [10] = recovered_40_q;
  wire recovered_40_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_40_reset || (((reset) === 1'bx) && (recovered_40_q == 1'b0))) recovered_40_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_40_q == (m_axi_awid[10])))) recovered_40_q <= (m_axi_awid[10]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_11_c268784
  reg recovered_41_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [11] = recovered_41_q;
  wire recovered_41_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_41_reset || (((reset) === 1'bx) && (recovered_41_q == 1'b0))) recovered_41_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_41_q == (m_axi_awid[11])))) recovered_41_q <= (m_axi_awid[11]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_13_6ca9a2a
  reg recovered_42_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [13] = recovered_42_q;
  wire recovered_42_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_42_reset || (((reset) === 1'bx) && (recovered_42_q == 1'b0))) recovered_42_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_42_q == (m_axi_awid[13])))) recovered_42_q <= (m_axi_awid[13]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_1_e01a9ce
  reg recovered_43_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [1] = recovered_43_q;
  wire recovered_43_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_43_reset || (((reset) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_43_q == (m_axi_awid[1])))) recovered_43_q <= (m_axi_awid[1]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_2_8bd15b9
  reg recovered_44_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [2] = recovered_44_q;
  wire recovered_44_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_44_reset || (((reset) === 1'bx) && (recovered_44_q == 1'b0))) recovered_44_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_44_q == (m_axi_awid[2])))) recovered_44_q <= (m_axi_awid[2]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_3_673b02c
  reg recovered_45_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [3] = recovered_45_q;
  wire recovered_45_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_45_reset || (((reset) === 1'bx) && (recovered_45_q == 1'b0))) recovered_45_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_45_q == (m_axi_awid[3])))) recovered_45_q <= (m_axi_awid[3]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_4_43e5474
  reg recovered_46_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [4] = recovered_46_q;
  wire recovered_46_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_46_reset || (((reset) === 1'bx) && (recovered_46_q == 1'b0))) recovered_46_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_46_q == (m_axi_awid[4])))) recovered_46_q <= (m_axi_awid[4]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_5_0dea3bc
  reg recovered_47_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [5] = recovered_47_q;
  wire recovered_47_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_47_reset || (((reset) === 1'bx) && (recovered_47_q == 1'b0))) recovered_47_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_47_q == (m_axi_awid[5])))) recovered_47_q <= (m_axi_awid[5]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_6_b49873c
  reg recovered_48_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [6] = recovered_48_q;
  wire recovered_48_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_48_reset || (((reset) === 1'bx) && (recovered_48_q == 1'b0))) recovered_48_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_48_q == (m_axi_awid[6])))) recovered_48_q <= (m_axi_awid[6]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_7_3cdd142
  reg recovered_49_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [7] = recovered_49_q;
  wire recovered_49_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_49_reset || (((reset) === 1'bx) && (recovered_49_q == 1'b0))) recovered_49_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_49_q == (m_axi_awid[7])))) recovered_49_q <= (m_axi_awid[7]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_8_dac2529
  reg recovered_50_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [8] = recovered_50_q;
  wire recovered_50_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_50_reset || (((reset) === 1'bx) && (recovered_50_q == 1'b0))) recovered_50_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_50_q == (m_axi_awid[8])))) recovered_50_q <= (m_axi_awid[8]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_bid_i_reg_9_448a636
  reg recovered_51_q = 1'b0;
  assign esc_gen_axi_s_axi_bid_i_reg_13__0_97a743d [9] = recovered_51_q;
  wire recovered_51_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_51_reset || (((reset) === 1'bx) && (recovered_51_q == 1'b0))) recovered_51_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) || ((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bz) || (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) === 1'bx) && (recovered_51_q == (m_axi_awid[9])))) recovered_51_q <= (m_axi_awid[9]);
  end

  // Reconstructed LUT4: esc_gen_axi_s_axi_bvalid_i_i_1_caef052
  assign esc_gen_axi_s_axi_bvalid_i_i_1_n_0_19a3c41 = ((mi_bvalid_1) ? (((mi_bready_1) ? (((esc_FSM_onehot_gen_axi_write_cs_reg_2__0_73a4047) ? (esc_gen_axi_s_axi_bvalid_i_reg_0_5c86ab2) : (1'b1))) : (1'b1))) : (esc_gen_axi_s_axi_bvalid_i_reg_0_5c86ab2));

  // Reconstructed FDRE: esc_gen_axi_s_axi_bvalid_i_reg_1e6dfb5
  reg recovered_53_q = 1'b0;
  assign mi_bvalid_1 = recovered_53_q;
  wire recovered_53_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_53_reset || (((reset) === 1'bx) && (recovered_53_q == 1'b0))) recovered_53_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_53_q == (esc_gen_axi_s_axi_bvalid_i_i_1_n_0_19a3c41)))) recovered_53_q <= (esc_gen_axi_s_axi_bvalid_i_i_1_n_0_19a3c41);
  end

  // Reconstructed LUT4: esc_gen_axi_s_axi_rid_i_13__i_1_062c760
  assign esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb = ((mi_arready) ? (((esc_gen_axi_read_cs_reg_0__0_b336fc8) ? (((p_1_in_0) ? (1'b0) : (~(mi_rvalid_1)))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_0_b9fa4a0
  reg recovered_55_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [0] = recovered_55_q;
  wire recovered_55_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_55_reset || (((reset) === 1'bx) && (recovered_55_q == 1'b0))) recovered_55_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_55_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [0])))) recovered_55_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [0]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_10_af52858
  reg recovered_56_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [10] = recovered_56_q;
  wire recovered_56_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_56_reset || (((reset) === 1'bx) && (recovered_56_q == 1'b0))) recovered_56_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_56_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [10])))) recovered_56_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [10]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_11_d3a4a3e
  reg recovered_57_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [11] = recovered_57_q;
  wire recovered_57_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_57_reset || (((reset) === 1'bx) && (recovered_57_q == 1'b0))) recovered_57_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_57_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [11])))) recovered_57_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [11]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_12_2a6a775
  reg recovered_58_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [12] = recovered_58_q;
  wire recovered_58_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_58_reset || (((reset) === 1'bx) && (recovered_58_q == 1'b0))) recovered_58_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_58_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [12])))) recovered_58_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [12]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_1_13b2480
  reg recovered_59_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [1] = recovered_59_q;
  wire recovered_59_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_59_reset || (((reset) === 1'bx) && (recovered_59_q == 1'b0))) recovered_59_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_59_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [1])))) recovered_59_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [1]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_2_1c3f3f3
  reg recovered_60_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [2] = recovered_60_q;
  wire recovered_60_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_60_reset || (((reset) === 1'bx) && (recovered_60_q == 1'b0))) recovered_60_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_60_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [2])))) recovered_60_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [2]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_3_3ab282c
  reg recovered_61_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [3] = recovered_61_q;
  wire recovered_61_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_61_reset || (((reset) === 1'bx) && (recovered_61_q == 1'b0))) recovered_61_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_61_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [3])))) recovered_61_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [3]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_4_51a10cd
  reg recovered_62_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [4] = recovered_62_q;
  wire recovered_62_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_62_reset || (((reset) === 1'bx) && (recovered_62_q == 1'b0))) recovered_62_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_62_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [4])))) recovered_62_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [4]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_5_3b77d58
  reg recovered_63_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [5] = recovered_63_q;
  wire recovered_63_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_63_reset || (((reset) === 1'bx) && (recovered_63_q == 1'b0))) recovered_63_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_63_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [5])))) recovered_63_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [5]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_6_ff768be
  reg recovered_64_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [6] = recovered_64_q;
  wire recovered_64_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_64_reset || (((reset) === 1'bx) && (recovered_64_q == 1'b0))) recovered_64_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_64_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [6])))) recovered_64_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [6]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_7_c5e2a15
  reg recovered_65_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [7] = recovered_65_q;
  wire recovered_65_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_65_reset || (((reset) === 1'bx) && (recovered_65_q == 1'b0))) recovered_65_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_65_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [7])))) recovered_65_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [7]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_8_1184ca7
  reg recovered_66_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [8] = recovered_66_q;
  wire recovered_66_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_66_reset || (((reset) === 1'bx) && (recovered_66_q == 1'b0))) recovered_66_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_66_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [8])))) recovered_66_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [8]);
  end

  // Reconstructed FDRE: esc_gen_axi_s_axi_rid_i_reg_9_b90f4f6
  reg recovered_67_q = 1'b0;
  assign esc_gen_axi_s_axi_rid_i_reg_13__0_d7f460d [9] = recovered_67_q;
  wire recovered_67_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_67_reset || (((reset) === 1'bx) && (recovered_67_q == 1'b0))) recovered_67_q <= 1'b0;
    else if ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) || ((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bz) || (((esc_gen_axi_s_axi_rid_i_13__i_1_n_0_dc9cabb) === 1'bx) && (recovered_67_q == (esc_gen_axi_read_cnt_reg_7__0_73f746d [9])))) recovered_67_q <= (esc_gen_axi_read_cnt_reg_7__0_73f746d [9]);
  end

  // Reconstructed LUT5: esc_gen_axi_s_axi_rlast_i_i_1_75bc7d7
  assign esc_gen_axi_s_axi_rlast_i_i_1_n_0_5c500d0 = ((mi_rlast_1) ? (((esc_gen_axi_s_axi_rlast_i_i_3_n_0_5a9b61a) ? (((esc_gen_axi_s_axi_rlast_i_reg_0_71a8bed) ? (1'b1) : (((esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b) ? (mi_rvalid_1) : (1'b0))))) : (1'b1))) : (((esc_gen_axi_s_axi_rlast_i_i_3_n_0_5a9b61a) ? (((esc_gen_axi_s_axi_rlast_i_reg_0_71a8bed) ? (1'b1) : (((esc_gen_axi_read_cnt_7__i_3_n_0_4284c4b) ? (mi_rvalid_1) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT5: esc_gen_axi_s_axi_rlast_i_i_3_650e2fa
  assign esc_gen_axi_s_axi_rlast_i_i_3_n_0_5a9b61a = ((esc_gen_axi_s_axi_arready_i_i_2_n_0_498ea98) ? (((esc_gen_axi_read_cnt_reg_c2245d9 [1]) ? (1'b0) : (((esc_gen_axi_read_cnt_reg_c2245d9 [2]) ? (1'b0) : (((esc_gen_axi_read_cnt_reg_c2245d9 [3]) ? (1'b0) : (esc_gen_axi_s_axi_rlast_i_i_5_n_0_c104863))))))) : (1'b1));

  // Reconstructed LUT6: esc_gen_axi_s_axi_rlast_i_i_5_958a0e8
  assign esc_gen_axi_s_axi_rlast_i_i_5_n_0_c104863 = ((mi_rvalid_1) ? (((mi_rready_1) ? (((esc_gen_axi_read_cnt_reg_c2245d9 [5]) ? (1'b0) : (((esc_gen_axi_read_cnt_reg_c2245d9 [4]) ? (1'b0) : (((esc_gen_axi_read_cnt_reg_c2245d9 [7]) ? (1'b0) : (~(esc_gen_axi_read_cnt_reg_c2245d9 [6])))))))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_gen_axi_s_axi_rlast_i_reg_5705bbd
  reg recovered_71_q = 1'b0;
  assign mi_rlast_1 = recovered_71_q;
  wire recovered_71_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_71_reset || (((reset) === 1'bx) && (recovered_71_q == 1'b0))) recovered_71_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_71_q == (esc_gen_axi_s_axi_rlast_i_i_1_n_0_5c500d0)))) recovered_71_q <= (esc_gen_axi_s_axi_rlast_i_i_1_n_0_5c500d0);
  end

  // Reconstructed LUT3: esc_gen_axi_s_axi_wready_i_i_1_365b6ed
  assign esc_gen_axi_s_axi_wready_i_i_1_n_0_6456074 = ((mi_wready_1) ? (((esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa) ? (1'b1) : (~(esc_gen_axi_s_axi_bvalid_i_reg_0_5c86ab2)))) : (esc_gen_axi_s_axi_bid_i_13__i_1_n_0_45261fa));

  // Reconstructed FDRE: esc_gen_axi_s_axi_wready_i_reg_60f6f1e
  reg recovered_73_q = 1'b0;
  assign mi_wready_1 = recovered_73_q;
  wire recovered_73_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_73_reset || (((reset) === 1'bx) && (recovered_73_q == 1'b0))) recovered_73_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_73_q == (esc_gen_axi_s_axi_wready_i_i_1_n_0_6456074)))) recovered_73_q <= (esc_gen_axi_s_axi_wready_i_i_1_n_0_6456074);
  end

endmodule

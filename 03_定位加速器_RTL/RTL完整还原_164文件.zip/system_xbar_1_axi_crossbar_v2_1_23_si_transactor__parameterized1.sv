// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_si_transactor__parameterized1
   (esc_gen_single_thread_active_target_enc_219b1ab ,
    esc_gen_single_thread_active_target_hot_f34cb3c ,
    esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e ,
    st_aa_arvalid_qual,
    reset,
    esc_gen_single_thread_accept_cnt_reg_4__0_05ec382 ,
    aclk,
    esc_gen_single_thread_active_target_enc_reg_0__0_f6ff5de ,
    esc_gen_single_thread_active_target_hot_reg_0__0_803a5b4 ,
    esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d ,
    p_2_in,
    st_aa_artarget_hot);
  output esc_gen_single_thread_active_target_enc_219b1ab ;
  output [0:0]esc_gen_single_thread_active_target_hot_f34cb3c ;
  output esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e ;
  output [0:0]st_aa_arvalid_qual;
  input reset;
  input esc_gen_single_thread_accept_cnt_reg_4__0_05ec382 ;
  input aclk;
  input esc_gen_single_thread_active_target_enc_reg_0__0_f6ff5de ;
  input esc_gen_single_thread_active_target_hot_reg_0__0_803a5b4 ;
  input esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d ;
  input p_2_in;
  input [0:0]st_aa_artarget_hot;

  wire esc_const1_c064970 ;
  wire aclk;
  wire esc_gen_single_thread_accept_cnt_0__i_1__1_n_0_aec50b1 ;
  wire esc_gen_single_thread_accept_cnt_1__i_1__1_n_0_7617d64 ;
  wire esc_gen_single_thread_accept_cnt_2__i_1_n_0_2d631b6 ;
  wire esc_gen_single_thread_accept_cnt_3__i_1_n_0_57359e1 ;
  wire esc_gen_single_thread_accept_cnt_4__i_2_n_0_0bf45d3 ;
  wire [4:0]esc_gen_single_thread_accept_cnt_reg_824e258 ;
  wire esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d ;
  wire esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e ;
  wire esc_gen_single_thread_accept_cnt_reg_4__0_05ec382 ;
  wire esc_gen_single_thread_accept_limit00_in_035b519 ;
  wire esc_gen_single_thread_active_target_enc_219b1ab ;
  wire esc_gen_single_thread_active_target_enc_reg_0__0_f6ff5de ;
  wire [0:0]esc_gen_single_thread_active_target_hot_f34cb3c ;
  wire esc_gen_single_thread_active_target_hot_reg_0__0_803a5b4 ;
  wire p_2_in;
  wire reset;
  wire [0:0]st_aa_artarget_hot;
  wire [0:0]st_aa_arvalid_qual;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT5: esc_gen_arbiter_qual_reg_1__i_3_ca5102e
  assign st_aa_arvalid_qual = ((esc_gen_single_thread_accept_limit00_in_035b519) ? (((p_2_in) ? (((esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e) ? (1'b1) : (((esc_gen_single_thread_active_target_enc_219b1ab) ? (~(st_aa_artarget_hot)) : (st_aa_artarget_hot))))) : (1'b0))) : (((esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e) ? (1'b1) : (((esc_gen_single_thread_active_target_enc_219b1ab) ? (~(st_aa_artarget_hot)) : (st_aa_artarget_hot))))));

  // Reconstructed LUT5: esc_gen_arbiter_qual_reg_1__i_4_423d63e
  assign esc_gen_single_thread_accept_limit00_in_035b519 = ((esc_gen_single_thread_accept_cnt_reg_824e258 [0]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [3]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (1'b0) : (esc_gen_single_thread_accept_cnt_reg_824e258 [4]))))))));

  // Reconstructed LUT4: esc_gen_single_thread_accept_cnt_0__i_1__1_f75248f
  assign esc_gen_single_thread_accept_cnt_0__i_1__1_n_0_aec50b1 = ((esc_gen_single_thread_accept_cnt_reg_824e258 [0]) ? (((esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e) ? (((p_2_in) ? (1'b1) : (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)))) : (((p_2_in) ? (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) : (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)))))) : (((esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e) ? (((p_2_in) ? (1'b0) : (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d))) : (((p_2_in) ? (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)) : (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d))))));

  // Reconstructed LUT3: esc_gen_single_thread_accept_cnt_1__i_1__1_207a070
  assign esc_gen_single_thread_accept_cnt_1__i_1__1_n_0_7617d64 = ((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (~(esc_gen_single_thread_accept_cnt_reg_824e258 [0])) : (esc_gen_single_thread_accept_cnt_reg_824e258 [0]))) : (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (esc_gen_single_thread_accept_cnt_reg_824e258 [0]) : (~(esc_gen_single_thread_accept_cnt_reg_824e258 [0])))));

  // Reconstructed LUT4: esc_gen_single_thread_accept_cnt_2__i_1_1677f0c
  assign esc_gen_single_thread_accept_cnt_2__i_1_n_0_2d631b6 = ((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (~(esc_gen_single_thread_accept_cnt_reg_824e258 [0])) : (1'b1))) : (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (esc_gen_single_thread_accept_cnt_reg_824e258 [0]) : (1'b0))))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (1'b1) : (esc_gen_single_thread_accept_cnt_reg_824e258 [0]))) : (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (1'b0) : (~(esc_gen_single_thread_accept_cnt_reg_824e258 [0])))))));

  // Reconstructed LUT5: esc_gen_single_thread_accept_cnt_3__i_1_4804355
  assign esc_gen_single_thread_accept_cnt_3__i_1_n_0_57359e1 = ((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [3]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [0]) ? (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)) : (1'b1))) : (1'b1))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [0]) ? (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) : (1'b0))) : (1'b0))))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [3]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (1'b1) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [0]) ? (1'b1) : (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d))))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [0]) ? (1'b0) : (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)))))))));

  // Reconstructed LUT6: esc_gen_single_thread_accept_cnt_4__i_2_bda87bf
  assign esc_gen_single_thread_accept_cnt_4__i_2_n_0_0bf45d3 = ((esc_gen_single_thread_accept_cnt_reg_824e258 [3]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [4]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [0]) ? (~(esc_gen_single_thread_accept_cnt_reg_824e258 [1])) : (1'b1))) : (1'b1))) : (1'b1))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [0]) ? (esc_gen_single_thread_accept_cnt_reg_824e258 [1]) : (1'b0))) : (1'b0))) : (1'b0))))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [4]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (1'b1) : (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (1'b1) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [0]) ? (1'b1) : (esc_gen_single_thread_accept_cnt_reg_824e258 [1]))))))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [0]) ? (1'b0) : (~(esc_gen_single_thread_accept_cnt_reg_824e258 [1])))))))))));

  // Reconstructed LUT5: esc_gen_single_thread_accept_cnt_4__i_4_0d3eb66
  assign esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e = ((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [4]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [0]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (1'b0) : (~(esc_gen_single_thread_accept_cnt_reg_824e258 [3])))))))));

  // Reconstructed FDRE: esc_gen_single_thread_accept_cnt_reg_0_b642bb1
  reg recovered_10_q = 1'b0;
  assign esc_gen_single_thread_accept_cnt_reg_824e258 [0] = recovered_10_q;
  wire recovered_10_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_10_reset || (((reset) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_10_q == (esc_gen_single_thread_accept_cnt_0__i_1__1_n_0_aec50b1)))) recovered_10_q <= (esc_gen_single_thread_accept_cnt_0__i_1__1_n_0_aec50b1);
  end

  // Reconstructed FDRE: esc_gen_single_thread_accept_cnt_reg_1_1f56dae
  reg recovered_11_q = 1'b0;
  assign esc_gen_single_thread_accept_cnt_reg_824e258 [1] = recovered_11_q;
  wire recovered_11_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_11_reset || (((reset) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) || ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bz) || (((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bx) && (recovered_11_q == (esc_gen_single_thread_accept_cnt_1__i_1__1_n_0_7617d64)))) recovered_11_q <= (esc_gen_single_thread_accept_cnt_1__i_1__1_n_0_7617d64);
  end

  // Reconstructed FDRE: esc_gen_single_thread_accept_cnt_reg_2_8242257
  reg recovered_12_q = 1'b0;
  assign esc_gen_single_thread_accept_cnt_reg_824e258 [2] = recovered_12_q;
  wire recovered_12_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_12_reset || (((reset) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) || ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bz) || (((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bx) && (recovered_12_q == (esc_gen_single_thread_accept_cnt_2__i_1_n_0_2d631b6)))) recovered_12_q <= (esc_gen_single_thread_accept_cnt_2__i_1_n_0_2d631b6);
  end

  // Reconstructed FDRE: esc_gen_single_thread_accept_cnt_reg_3_b9a1a1b
  reg recovered_13_q = 1'b0;
  assign esc_gen_single_thread_accept_cnt_reg_824e258 [3] = recovered_13_q;
  wire recovered_13_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((reset) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) || ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bz) || (((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bx) && (recovered_13_q == (esc_gen_single_thread_accept_cnt_3__i_1_n_0_57359e1)))) recovered_13_q <= (esc_gen_single_thread_accept_cnt_3__i_1_n_0_57359e1);
  end

  // Reconstructed FDRE: esc_gen_single_thread_accept_cnt_reg_4_57ac5fc
  reg recovered_14_q = 1'b0;
  assign esc_gen_single_thread_accept_cnt_reg_824e258 [4] = recovered_14_q;
  wire recovered_14_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_14_reset || (((reset) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) || ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bz) || (((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bx) && (recovered_14_q == (esc_gen_single_thread_accept_cnt_4__i_2_n_0_0bf45d3)))) recovered_14_q <= (esc_gen_single_thread_accept_cnt_4__i_2_n_0_0bf45d3);
  end

  // Reconstructed FDRE: esc_gen_single_thread_active_target_enc_reg_0_1d4f65e
  reg recovered_15_q = 1'b0;
  assign esc_gen_single_thread_active_target_enc_219b1ab = recovered_15_q;
  wire recovered_15_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_15_reset || (((reset) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_15_q == (esc_gen_single_thread_active_target_enc_reg_0__0_f6ff5de)))) recovered_15_q <= (esc_gen_single_thread_active_target_enc_reg_0__0_f6ff5de);
  end

  // Reconstructed FDRE: esc_gen_single_thread_active_target_hot_reg_0_ad29f1b
  reg recovered_16_q = 1'b0;
  assign esc_gen_single_thread_active_target_hot_f34cb3c = recovered_16_q;
  wire recovered_16_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_16_reset || (((reset) === 1'bx) && (recovered_16_q == 1'b0))) recovered_16_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_16_q == (esc_gen_single_thread_active_target_hot_reg_0__0_803a5b4)))) recovered_16_q <= (esc_gen_single_thread_active_target_hot_reg_0__0_803a5b4);
  end

endmodule

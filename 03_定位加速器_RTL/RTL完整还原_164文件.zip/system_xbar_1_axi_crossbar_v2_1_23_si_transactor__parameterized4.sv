// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_si_transactor__parameterized4
   (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d ,
    esc_gen_single_thread_active_target_enc_219b1ab ,
    esc_gen_single_thread_active_target_hot_f34cb3c ,
    esc_gen_single_thread_s_avalid_en_5fadb6c ,
    esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e ,
    esc_gen_single_thread_accept_limit00_in_035b519 ,
    reset,
    esc_gen_single_thread_accept_cnt_reg_4__0_05ec382 ,
    aclk,
    esc_gen_single_thread_accept_cnt_reg_0__1_c02edc8 ,
    esc_gen_single_thread_active_target_enc_reg_0__0_f6ff5de ,
    esc_gen_single_thread_active_target_hot_reg_0__0_803a5b4 ,
    m_ready_d,
    ss_aa_awready,
    ss_wr_awready_2,
    st_aa_awtarget_hot,
    esc_gen_single_thread_accept_cnt_reg_2__0_73121aa );
  output [0:0]esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d ;
  output esc_gen_single_thread_active_target_enc_219b1ab ;
  output [0:0]esc_gen_single_thread_active_target_hot_f34cb3c ;
  output esc_gen_single_thread_s_avalid_en_5fadb6c ;
  output esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e ;
  output esc_gen_single_thread_accept_limit00_in_035b519 ;
  input reset;
  input esc_gen_single_thread_accept_cnt_reg_4__0_05ec382 ;
  input aclk;
  input esc_gen_single_thread_accept_cnt_reg_0__1_c02edc8 ;
  input esc_gen_single_thread_active_target_enc_reg_0__0_f6ff5de ;
  input esc_gen_single_thread_active_target_hot_reg_0__0_803a5b4 ;
  input [1:0]m_ready_d;
  input [0:0]ss_aa_awready;
  input ss_wr_awready_2;
  input [0:0]st_aa_awtarget_hot;
  input esc_gen_single_thread_accept_cnt_reg_2__0_73121aa ;

  wire esc_const1_c064970 ;
  wire aclk;
  wire esc_gen_single_thread_accept_cnt_1__i_1_n_0_f734227 ;
  wire esc_gen_single_thread_accept_cnt_2__i_1__2_n_0_e957c78 ;
  wire esc_gen_single_thread_accept_cnt_3__i_1__2_n_0_31ca90b ;
  wire esc_gen_single_thread_accept_cnt_4__i_2__2_n_0_70e43fb ;
  wire [4:1]esc_gen_single_thread_accept_cnt_reg_824e258 ;
  wire [0:0]esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d ;
  wire esc_gen_single_thread_accept_cnt_reg_0__1_c02edc8 ;
  wire esc_gen_single_thread_accept_cnt_reg_2__0_73121aa ;
  wire esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e ;
  wire esc_gen_single_thread_accept_cnt_reg_4__0_05ec382 ;
  wire esc_gen_single_thread_accept_limit00_in_035b519 ;
  wire esc_gen_single_thread_active_target_enc_219b1ab ;
  wire esc_gen_single_thread_active_target_enc_reg_0__0_f6ff5de ;
  wire [0:0]esc_gen_single_thread_active_target_hot_f34cb3c ;
  wire esc_gen_single_thread_active_target_hot_reg_0__0_803a5b4 ;
  wire esc_gen_single_thread_s_avalid_en_5fadb6c ;
  wire [1:0]m_ready_d;
  wire reset;
  wire [0:0]ss_aa_awready;
  wire ss_wr_awready_2;
  wire [0:0]st_aa_awtarget_hot;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT3: esc_gen_arbiter_last_rr_hot_2__i_8__0_09f6d66
  assign esc_gen_single_thread_s_avalid_en_5fadb6c = ((st_aa_awtarget_hot) ? (((esc_gen_single_thread_active_target_enc_219b1ab) ? (1'b1) : (esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e))) : (((esc_gen_single_thread_active_target_enc_219b1ab) ? (esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e) : (1'b1))));

  // Reconstructed LUT5: esc_gen_arbiter_qual_reg_2__i_9_35d8f29
  assign esc_gen_single_thread_accept_limit00_in_035b519 = ((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [3]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (1'b0) : (esc_gen_single_thread_accept_cnt_reg_824e258 [4]))))))));

  // Reconstructed LUT6: esc_gen_single_thread_accept_cnt_1__i_1_30641b9
  assign esc_gen_single_thread_accept_cnt_1__i_1_n_0_f734227 = ((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (((ss_wr_awready_2) ? (((ss_aa_awready) ? (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)) : (((m_ready_d[0]) ? (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)) : (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d))))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)) : (((m_ready_d[0]) ? (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)) : (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d))))) : (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d))))) : (((ss_wr_awready_2) ? (((ss_aa_awready) ? (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) : (((m_ready_d[0]) ? (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) : (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)))))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) : (((m_ready_d[0]) ? (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) : (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)))))) : (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)))))));

  // Reconstructed LUT4: esc_gen_single_thread_accept_cnt_2__i_1__2_7e5b9cc
  assign esc_gen_single_thread_accept_cnt_2__i_1__2_n_0_e957c78 = ((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (((esc_gen_single_thread_accept_cnt_reg_2__0_73121aa) ? (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)) : (1'b1))) : (((esc_gen_single_thread_accept_cnt_reg_2__0_73121aa) ? (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) : (1'b0))))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (((esc_gen_single_thread_accept_cnt_reg_2__0_73121aa) ? (1'b1) : (esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d))) : (((esc_gen_single_thread_accept_cnt_reg_2__0_73121aa) ? (1'b0) : (~(esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d)))))));

  // Reconstructed LUT5: esc_gen_single_thread_accept_cnt_3__i_1__2_9701087
  assign esc_gen_single_thread_accept_cnt_3__i_1__2_n_0_31ca90b = ((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [3]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (~(esc_gen_single_thread_accept_cnt_reg_2__0_73121aa)) : (1'b1))) : (1'b1))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (esc_gen_single_thread_accept_cnt_reg_2__0_73121aa) : (1'b0))) : (1'b0))))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [3]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (1'b1) : (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (1'b1) : (esc_gen_single_thread_accept_cnt_reg_2__0_73121aa))))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (1'b0) : (~(esc_gen_single_thread_accept_cnt_reg_2__0_73121aa)))))))));

  // Reconstructed LUT6: esc_gen_single_thread_accept_cnt_4__i_2__2_82b42a3
  assign esc_gen_single_thread_accept_cnt_4__i_2__2_n_0_70e43fb = ((esc_gen_single_thread_accept_cnt_reg_824e258 [3]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [4]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (((esc_gen_single_thread_accept_cnt_reg_2__0_73121aa) ? (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (~(esc_gen_single_thread_accept_cnt_reg_824e258 [1])) : (1'b1))) : (1'b1))) : (1'b1))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (((esc_gen_single_thread_accept_cnt_reg_2__0_73121aa) ? (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (esc_gen_single_thread_accept_cnt_reg_824e258 [1]) : (1'b0))) : (1'b0))) : (1'b0))))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [4]) ? (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (1'b1) : (((esc_gen_single_thread_accept_cnt_reg_2__0_73121aa) ? (1'b1) : (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (1'b1) : (esc_gen_single_thread_accept_cnt_reg_824e258 [1]))))))) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_2__0_73121aa) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (1'b0) : (~(esc_gen_single_thread_accept_cnt_reg_824e258 [1])))))))))));

  // Reconstructed LUT5: esc_gen_single_thread_accept_cnt_4__i_4__2_131e9da
  assign esc_gen_single_thread_accept_cnt_reg_3__0_1e8b03e = ((esc_gen_single_thread_accept_cnt_reg_824e258 [2]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [4]) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (1'b0) : (((esc_gen_single_thread_accept_cnt_reg_824e258 [1]) ? (1'b0) : (~(esc_gen_single_thread_accept_cnt_reg_824e258 [3])))))))));

  // Reconstructed FDRE: esc_gen_single_thread_accept_cnt_reg_0_b642bb1
  reg recovered_9_q = 1'b0;
  assign esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d = recovered_9_q;
  wire recovered_9_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((reset) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (esc_gen_single_thread_accept_cnt_reg_0__1_c02edc8)))) recovered_9_q <= (esc_gen_single_thread_accept_cnt_reg_0__1_c02edc8);
  end

  // Reconstructed FDRE: esc_gen_single_thread_accept_cnt_reg_1_1f56dae
  reg recovered_10_q = 1'b0;
  assign esc_gen_single_thread_accept_cnt_reg_824e258 [1] = recovered_10_q;
  wire recovered_10_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_10_reset || (((reset) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) || ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bz) || (((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bx) && (recovered_10_q == (esc_gen_single_thread_accept_cnt_1__i_1_n_0_f734227)))) recovered_10_q <= (esc_gen_single_thread_accept_cnt_1__i_1_n_0_f734227);
  end

  // Reconstructed FDRE: esc_gen_single_thread_accept_cnt_reg_2_8242257
  reg recovered_11_q = 1'b0;
  assign esc_gen_single_thread_accept_cnt_reg_824e258 [2] = recovered_11_q;
  wire recovered_11_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_11_reset || (((reset) === 1'bx) && (recovered_11_q == 1'b0))) recovered_11_q <= 1'b0;
    else if ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) || ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bz) || (((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bx) && (recovered_11_q == (esc_gen_single_thread_accept_cnt_2__i_1__2_n_0_e957c78)))) recovered_11_q <= (esc_gen_single_thread_accept_cnt_2__i_1__2_n_0_e957c78);
  end

  // Reconstructed FDRE: esc_gen_single_thread_accept_cnt_reg_3_b9a1a1b
  reg recovered_12_q = 1'b0;
  assign esc_gen_single_thread_accept_cnt_reg_824e258 [3] = recovered_12_q;
  wire recovered_12_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_12_reset || (((reset) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) || ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bz) || (((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bx) && (recovered_12_q == (esc_gen_single_thread_accept_cnt_3__i_1__2_n_0_31ca90b)))) recovered_12_q <= (esc_gen_single_thread_accept_cnt_3__i_1__2_n_0_31ca90b);
  end

  // Reconstructed FDRE: esc_gen_single_thread_accept_cnt_reg_4_57ac5fc
  reg recovered_13_q = 1'b0;
  assign esc_gen_single_thread_accept_cnt_reg_824e258 [4] = recovered_13_q;
  wire recovered_13_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((reset) === 1'bx) && (recovered_13_q == 1'b0))) recovered_13_q <= 1'b0;
    else if ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) || ((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bz) || (((esc_gen_single_thread_accept_cnt_reg_4__0_05ec382) === 1'bx) && (recovered_13_q == (esc_gen_single_thread_accept_cnt_4__i_2__2_n_0_70e43fb)))) recovered_13_q <= (esc_gen_single_thread_accept_cnt_4__i_2__2_n_0_70e43fb);
  end

  // Reconstructed FDRE: esc_gen_single_thread_active_target_enc_reg_0_1d4f65e
  reg recovered_14_q = 1'b0;
  assign esc_gen_single_thread_active_target_enc_219b1ab = recovered_14_q;
  wire recovered_14_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_14_reset || (((reset) === 1'bx) && (recovered_14_q == 1'b0))) recovered_14_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_14_q == (esc_gen_single_thread_active_target_enc_reg_0__0_f6ff5de)))) recovered_14_q <= (esc_gen_single_thread_active_target_enc_reg_0__0_f6ff5de);
  end

  // Reconstructed FDRE: esc_gen_single_thread_active_target_hot_reg_0_ad29f1b
  reg recovered_15_q = 1'b0;
  assign esc_gen_single_thread_active_target_hot_f34cb3c = recovered_15_q;
  wire recovered_15_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_15_reset || (((reset) === 1'bx) && (recovered_15_q == 1'b0))) recovered_15_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_15_q == (esc_gen_single_thread_active_target_hot_reg_0__0_803a5b4)))) recovered_15_q <= (esc_gen_single_thread_active_target_hot_reg_0__0_803a5b4);
  end

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_splitter
   (esc_m_ready_d_reg_0__0_e29ee0b ,
    m_ready_d,
    ss_aa_awready,
    ss_wr_awready_0,
    s_axi_awvalid,
    aresetn_d,
    aclk);
  output esc_m_ready_d_reg_0__0_e29ee0b ;
  output [1:0]m_ready_d;
  input [0:0]ss_aa_awready;
  input ss_wr_awready_0;
  input [0:0]s_axi_awvalid;
  input aresetn_d;
  input aclk;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire aclk;
  wire aresetn_d;
  wire [1:0]m_ready_d;
  wire esc_m_ready_d_0__i_1_n_0_0b931db ;
  wire esc_m_ready_d_1__i_1_n_0_aafc7eb ;
  wire esc_m_ready_d_reg_0__0_e29ee0b ;
  wire [0:0]s_axi_awvalid;
  wire [0:0]ss_aa_awready;
  wire ss_wr_awready_0;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT6: esc_m_ready_d_0__i_1_bc9ee7e
  assign esc_m_ready_d_0__i_1_n_0_0b931db = ((ss_wr_awready_0) ? (1'b0) : (((m_ready_d[1]) ? (1'b0) : (((ss_aa_awready) ? (((m_ready_d[0]) ? (aresetn_d) : (((aresetn_d) ? (s_axi_awvalid) : (1'b0))))) : (((m_ready_d[0]) ? (aresetn_d) : (1'b0))))))));

  // Reconstructed LUT6: esc_m_ready_d_1__i_1_17d9d3e
  assign esc_m_ready_d_1__i_1_n_0_aafc7eb = ((ss_wr_awready_0) ? (((m_ready_d[1]) ? (((ss_aa_awready) ? (1'b0) : (((m_ready_d[0]) ? (1'b0) : (aresetn_d))))) : (((ss_aa_awready) ? (1'b0) : (((m_ready_d[0]) ? (1'b0) : (((aresetn_d) ? (s_axi_awvalid) : (1'b0))))))))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (1'b0) : (((m_ready_d[0]) ? (1'b0) : (aresetn_d))))) : (1'b0))));

  // Reconstructed FDRE: esc_m_ready_d_reg_0_0b6f615
  reg recovered_5_q = 1'b0;
  assign m_ready_d[0] = recovered_5_q;
  wire recovered_5_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_5_q == (esc_m_ready_d_0__i_1_n_0_0b931db)))) recovered_5_q <= (esc_m_ready_d_0__i_1_n_0_0b931db);
  end

  // Reconstructed FDRE: esc_m_ready_d_reg_1_9138ab7
  reg recovered_6_q = 1'b0;
  assign m_ready_d[1] = recovered_6_q;
  wire recovered_6_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_6_q == (esc_m_ready_d_1__i_1_n_0_aafc7eb)))) recovered_6_q <= (esc_m_ready_d_1__i_1_n_0_aafc7eb);
  end

  // Reconstructed LUT4: esc_s_axi_awready_0__INST_0_9d5725f
  assign esc_m_ready_d_reg_0__0_e29ee0b = ((ss_wr_awready_0) ? (((ss_aa_awready) ? (1'b1) : (m_ready_d[0]))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (1'b1) : (m_ready_d[0]))) : (1'b0))));

endmodule

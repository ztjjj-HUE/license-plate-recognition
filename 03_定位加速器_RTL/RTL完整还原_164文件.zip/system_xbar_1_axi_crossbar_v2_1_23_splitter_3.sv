// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_splitter_3
   (esc_m_ready_d_reg_0__0_e29ee0b ,
    m_ready_d,
    esc_gen_single_thread_accept_cnt_reg_0_b642bb1 ,
    esc_m_ready_d_reg_0__1_35bedb2 ,
    esc_m_ready_d_reg_0__2_bcd11bd ,
    esc_m_ready_d_reg_0__3_cc745e5 ,
    st_aa_awtarget_hot,
    ss_aa_awready,
    ss_wr_awready_2,
    esc_gen_single_thread_active_target_enc_219b1ab ,
    esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d ,
    p_2_in,
    esc_gen_single_thread_accept_cnt_reg_4_57ac5fc ,
    esc_gen_single_thread_active_target_hot_f34cb3c ,
    s_axi_awvalid,
    aresetn_d,
    aclk);
  output esc_m_ready_d_reg_0__0_e29ee0b ;
  output [1:0]m_ready_d;
  output esc_gen_single_thread_accept_cnt_reg_0_b642bb1 ;
  output esc_m_ready_d_reg_0__1_35bedb2 ;
  output esc_m_ready_d_reg_0__2_bcd11bd ;
  output esc_m_ready_d_reg_0__3_cc745e5 ;
  input [0:0]st_aa_awtarget_hot;
  input [0:0]ss_aa_awready;
  input ss_wr_awready_2;
  input esc_gen_single_thread_active_target_enc_219b1ab ;
  input [0:0]esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d ;
  input p_2_in;
  input esc_gen_single_thread_accept_cnt_reg_4_57ac5fc ;
  input [0:0]esc_gen_single_thread_active_target_hot_f34cb3c ;
  input [0:0]s_axi_awvalid;
  input aresetn_d;
  input aclk;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire aclk;
  wire aresetn_d;
  wire esc_gen_single_thread_accept_cnt_reg_0_b642bb1 ;
  wire [0:0]esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d ;
  wire esc_gen_single_thread_accept_cnt_reg_4_57ac5fc ;
  wire esc_gen_single_thread_active_target_enc_219b1ab ;
  wire [0:0]esc_gen_single_thread_active_target_hot_f34cb3c ;
  wire [1:0]m_ready_d;
  wire esc_m_ready_d_0__i_1_n_0_0b931db ;
  wire esc_m_ready_d_1__i_1_n_0_aafc7eb ;
  wire esc_m_ready_d_reg_0__0_e29ee0b ;
  wire esc_m_ready_d_reg_0__1_35bedb2 ;
  wire esc_m_ready_d_reg_0__2_bcd11bd ;
  wire esc_m_ready_d_reg_0__3_cc745e5 ;
  wire p_2_in;
  wire [0:0]s_axi_awvalid;
  wire [0:0]ss_aa_awready;
  wire ss_wr_awready_2;
  wire [0:0]st_aa_awtarget_hot;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT2: esc_gen_single_thread_accept_cnt_0__i_1__0_fc309a0
  assign esc_gen_single_thread_accept_cnt_reg_0_b642bb1 = ((esc_gen_single_thread_accept_cnt_reg_0__0_3b1669d) ? (~(esc_m_ready_d_reg_0__1_35bedb2)) : (esc_m_ready_d_reg_0__1_35bedb2));

  // Reconstructed LUT6: esc_gen_single_thread_accept_cnt_4__i_1__2_24ab831
  assign esc_m_ready_d_reg_0__1_35bedb2 = ((esc_gen_single_thread_accept_cnt_reg_4_57ac5fc) ? (((p_2_in) ? (1'b0) : (((ss_wr_awready_2) ? (((ss_aa_awready) ? (1'b1) : (m_ready_d[0]))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (1'b1) : (m_ready_d[0]))) : (1'b0))))))) : (((p_2_in) ? (((ss_wr_awready_2) ? (((ss_aa_awready) ? (1'b0) : (~(m_ready_d[0])))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (1'b0) : (~(m_ready_d[0])))) : (1'b1))))) : (((ss_wr_awready_2) ? (((ss_aa_awready) ? (1'b1) : (m_ready_d[0]))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (1'b1) : (m_ready_d[0]))) : (1'b0))))))));

  // Reconstructed LUT6: esc_gen_single_thread_active_target_enc_0__i_1__2_bdce777
  assign esc_m_ready_d_reg_0__0_e29ee0b = ((esc_gen_single_thread_active_target_enc_219b1ab) ? (((ss_wr_awready_2) ? (((ss_aa_awready) ? (st_aa_awtarget_hot) : (((m_ready_d[0]) ? (st_aa_awtarget_hot) : (1'b1))))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (st_aa_awtarget_hot) : (((m_ready_d[0]) ? (st_aa_awtarget_hot) : (1'b1))))) : (1'b1))))) : (((ss_wr_awready_2) ? (((ss_aa_awready) ? (st_aa_awtarget_hot) : (((m_ready_d[0]) ? (st_aa_awtarget_hot) : (1'b0))))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (st_aa_awtarget_hot) : (((m_ready_d[0]) ? (st_aa_awtarget_hot) : (1'b0))))) : (1'b0))))));

  // Reconstructed LUT6: esc_gen_single_thread_active_target_hot_0__i_1__2_dd64382
  assign esc_m_ready_d_reg_0__2_bcd11bd = ((esc_gen_single_thread_active_target_hot_f34cb3c) ? (((ss_wr_awready_2) ? (((ss_aa_awready) ? (~(st_aa_awtarget_hot)) : (((m_ready_d[0]) ? (~(st_aa_awtarget_hot)) : (1'b1))))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (~(st_aa_awtarget_hot)) : (((m_ready_d[0]) ? (~(st_aa_awtarget_hot)) : (1'b1))))) : (1'b1))))) : (((ss_wr_awready_2) ? (((ss_aa_awready) ? (~(st_aa_awtarget_hot)) : (((m_ready_d[0]) ? (~(st_aa_awtarget_hot)) : (1'b0))))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (~(st_aa_awtarget_hot)) : (((m_ready_d[0]) ? (~(st_aa_awtarget_hot)) : (1'b0))))) : (1'b0))))));

  // Reconstructed LUT6: esc_m_ready_d_0__i_1_bc9ee7e
  assign esc_m_ready_d_0__i_1_n_0_0b931db = ((ss_wr_awready_2) ? (1'b0) : (((m_ready_d[1]) ? (1'b0) : (((ss_aa_awready) ? (((m_ready_d[0]) ? (aresetn_d) : (((aresetn_d) ? (s_axi_awvalid) : (1'b0))))) : (((m_ready_d[0]) ? (aresetn_d) : (1'b0))))))));

  // Reconstructed LUT6: esc_m_ready_d_1__i_1_17d9d3e
  assign esc_m_ready_d_1__i_1_n_0_aafc7eb = ((ss_wr_awready_2) ? (((m_ready_d[1]) ? (((ss_aa_awready) ? (1'b0) : (((m_ready_d[0]) ? (1'b0) : (aresetn_d))))) : (((ss_aa_awready) ? (1'b0) : (((m_ready_d[0]) ? (1'b0) : (((aresetn_d) ? (s_axi_awvalid) : (1'b0))))))))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (1'b0) : (((m_ready_d[0]) ? (1'b0) : (aresetn_d))))) : (1'b0))));

  // Reconstructed FDRE: esc_m_ready_d_reg_0_0b6f615
  reg recovered_9_q = 1'b0;
  assign m_ready_d[0] = recovered_9_q;
  wire recovered_9_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (esc_m_ready_d_0__i_1_n_0_0b931db)))) recovered_9_q <= (esc_m_ready_d_0__i_1_n_0_0b931db);
  end

  // Reconstructed FDRE: esc_m_ready_d_reg_1_9138ab7
  reg recovered_10_q = 1'b0;
  assign m_ready_d[1] = recovered_10_q;
  wire recovered_10_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_10_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_10_q == 1'b0))) recovered_10_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_10_q == (esc_m_ready_d_1__i_1_n_0_aafc7eb)))) recovered_10_q <= (esc_m_ready_d_1__i_1_n_0_aafc7eb);
  end

  // Reconstructed LUT4: esc_s_axi_awready_2__INST_0_cd7e578
  assign esc_m_ready_d_reg_0__3_cc745e5 = ((ss_wr_awready_2) ? (((ss_aa_awready) ? (1'b1) : (m_ready_d[0]))) : (((m_ready_d[1]) ? (((ss_aa_awready) ? (1'b1) : (m_ready_d[0]))) : (1'b0))));

endmodule

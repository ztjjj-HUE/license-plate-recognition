// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_splitter_5
   (esc_gen_arbiter_m_valid_i_reg_inv_5735384 ,
    aa_sa_awready,
    m_ready_d,
    esc_m_ready_d_reg_1__0_09b2d76 ,
    p_1_in,
    aresetn_d,
    Q,
    m_axi_awready,
    mi_awready,
    esc_m_ready_d_reg_1__1_9c52823 ,
    aclk);
  output esc_gen_arbiter_m_valid_i_reg_inv_5735384 ;
  output aa_sa_awready;
  output [1:0]m_ready_d;
  output esc_m_ready_d_reg_1__0_09b2d76 ;
  input p_1_in;
  input aresetn_d;
  input [1:0]Q;
  input [0:0]m_axi_awready;
  input [0:0]mi_awready;
  input esc_m_ready_d_reg_1__1_9c52823 ;
  input aclk;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [1:0]Q;
  wire aa_sa_awready;
  wire aclk;
  wire aresetn_d;
  wire esc_gen_arbiter_m_valid_i_reg_inv_5735384 ;
  wire [0:0]m_axi_awready;
  wire [1:0]m_ready_d;
  wire esc_m_ready_d_0__i_1_n_0_0b931db ;
  wire esc_m_ready_d_1__i_1_n_0_aafc7eb ;
  wire esc_m_ready_d_reg_1__0_09b2d76 ;
  wire esc_m_ready_d_reg_1__1_9c52823 ;
  wire [0:0]mi_awready;
  wire p_1_in;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT3: esc_gen_arbiter_grant_hot_2__i_3_59a01c8
  assign esc_gen_arbiter_m_valid_i_reg_inv_5735384 = ((aresetn_d) ? (((p_1_in) ? (1'b0) : (aa_sa_awready))) : (1'b1));

  // Reconstructed LUT6: esc_gen_arbiter_m_valid_i_inv_i_2_2917236
  assign aa_sa_awready = ((mi_awready) ? (((Q[1]) ? (1'b1) : (((m_axi_awready) ? (((Q[0]) ? (1'b1) : (((m_ready_d[0]) ? (m_ready_d[1]) : (1'b0))))) : (((Q[0]) ? (m_ready_d[1]) : (((m_ready_d[0]) ? (m_ready_d[1]) : (1'b0))))))))) : (((Q[1]) ? (((m_axi_awready) ? (((Q[0]) ? (1'b1) : (m_ready_d[1]))) : (m_ready_d[1]))) : (((m_axi_awready) ? (((Q[0]) ? (1'b1) : (((m_ready_d[0]) ? (m_ready_d[1]) : (1'b0))))) : (((Q[0]) ? (m_ready_d[1]) : (((m_ready_d[0]) ? (m_ready_d[1]) : (1'b0))))))))));

  // Reconstructed LUT2: esc_gen_axi_s_axi_awready_i_i_2_847cbda
  assign esc_m_ready_d_reg_1__0_09b2d76 = ((p_1_in) ? (1'b1) : (m_ready_d[1]));

  // Reconstructed LUT6: esc_m_ready_d_0__i_1_bc9ee7e
  assign esc_m_ready_d_0__i_1_n_0_0b931db = ((aa_sa_awready) ? (1'b0) : (((aresetn_d) ? (((p_1_in) ? (m_ready_d[0]) : (((Q[0]) ? (1'b1) : (((Q[1]) ? (1'b1) : (m_ready_d[0]))))))) : (1'b0))));

  // Reconstructed LUT5: esc_m_ready_d_1__i_1_17d9d3e
  assign esc_m_ready_d_1__i_1_n_0_aafc7eb = ((aa_sa_awready) ? (1'b0) : (((aresetn_d) ? (((p_1_in) ? (m_ready_d[1]) : (((esc_m_ready_d_reg_1__1_9c52823) ? (1'b1) : (m_ready_d[1]))))) : (1'b0))));

  // Reconstructed FDRE: esc_m_ready_d_reg_0_0b6f615
  reg recovered_8_q = 1'b0;
  assign m_ready_d[0] = recovered_8_q;
  wire recovered_8_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_8_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_8_q == (esc_m_ready_d_0__i_1_n_0_0b931db)))) recovered_8_q <= (esc_m_ready_d_0__i_1_n_0_0b931db);
  end

  // Reconstructed FDRE: esc_m_ready_d_reg_1_9138ab7
  reg recovered_9_q = 1'b0;
  assign m_ready_d[1] = recovered_9_q;
  wire recovered_9_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_9_q == 1'b0))) recovered_9_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_9_q == (esc_m_ready_d_1__i_1_n_0_aafc7eb)))) recovered_9_q <= (esc_m_ready_d_1__i_1_n_0_aafc7eb);
  end

endmodule

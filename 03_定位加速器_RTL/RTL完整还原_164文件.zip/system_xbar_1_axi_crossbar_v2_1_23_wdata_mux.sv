// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_wdata_mux
   (m_avalid,
    f_decoder_return,
    m_select_enc,
    Q,
    m_valid_i_reg,
    m_axi_wlast,
    m_axi_wstrb,
    m_axi_wdata,
    push,
    aa_wm_awgrant_enc,
    aclk,
    areset_d1,
    sa_wm_awvalid,
    m_aready,
    m_ready_d,
    esc_FSM_onehot_state_reg_1_070266a ,
    p_1_in,
    esc_FSM_onehot_state_reg_1__0_2261399 ,
    m_axi_wready,
    s_axi_wlast,
    D,
    reset,
    E,
    s_axi_wstrb,
    s_axi_wdata);
  output m_avalid;
  output [2:0]f_decoder_return;
  output [1:0]m_select_enc;
  output [1:0]Q;
  output m_valid_i_reg;
  output [0:0]m_axi_wlast;
  output [3:0]m_axi_wstrb;
  output [31:0]m_axi_wdata;
  input push;
  input [1:0]aa_wm_awgrant_enc;
  input aclk;
  input areset_d1;
  input [0:0]sa_wm_awvalid;
  input m_aready;
  input [0:0]m_ready_d;
  input [0:0]esc_FSM_onehot_state_reg_1_070266a ;
  input p_1_in;
  input esc_FSM_onehot_state_reg_1__0_2261399 ;
  input [0:0]m_axi_wready;
  input [2:0]s_axi_wlast;
  input [1:0]D;
  input reset;
  input [0:0]E;
  input [11:0]s_axi_wstrb;
  input [95:0]s_axi_wdata;

  wire [1:0]D;
  wire [0:0]E;
  wire [0:0]esc_FSM_onehot_state_reg_1_070266a ;
  wire esc_FSM_onehot_state_reg_1__0_2261399 ;
  wire [1:0]Q;
  wire [1:0]aa_wm_awgrant_enc;
  wire aclk;
  wire areset_d1;
  wire [2:0]f_decoder_return;
  wire m_aready;
  wire m_avalid;
  wire [31:0]m_axi_wdata;
  wire [0:0]m_axi_wlast;
  wire [0:0]m_axi_wready;
  wire [3:0]m_axi_wstrb;
  wire [0:0]m_ready_d;
  wire [1:0]m_select_enc;
  wire m_valid_i_reg;
  wire p_1_in;
  wire push;
  wire reset;
  wire [95:0]s_axi_wdata;
  wire [2:0]s_axi_wlast;
  wire [11:0]s_axi_wstrb;
  wire [0:0]sa_wm_awvalid;
  wire [1:0]esc_NLW_gen_wmux_wmux_aw_fifo_aa_wm_awgrant_enc_UNCONNECTED_0ed6d5e ;
  wire [2:0]esc_NLW_gen_wmux_wmux_aw_fifo_f_decoder_return_UNCONNECTED_e7bec0a ;
  wire [95:0]esc_NLW_gen_wmux_wmux_aw_fifo_s_axi_wdata_UNCONNECTED_78d12f1 ;
  wire [2:0]esc_NLW_gen_wmux_wmux_aw_fifo_s_axi_wlast_UNCONNECTED_31fe55b ;
  wire [11:0]esc_NLW_gen_wmux_wmux_aw_fifo_s_axi_wstrb_UNCONNECTED_c515415 ;

  system_xbar_1_axi_data_fifo_v2_1_21_axic_reg_srl_fifo__parameterized1 esc_gen_wmux_wmux_aw_fifo_c90851b 
       (.D(D),
        .E(E),
        .esc_FSM_onehot_state_reg_1__0_2261399 (esc_FSM_onehot_state_reg_1_070266a ),
        .esc_FSM_onehot_state_reg_1__1_f4c0b3e (esc_FSM_onehot_state_reg_1__0_2261399 ),
        .Q(Q),
        .aa_wm_awgrant_enc({aa_wm_awgrant_enc[1],esc_NLW_gen_wmux_wmux_aw_fifo_aa_wm_awgrant_enc_UNCONNECTED_0ed6d5e [0]}),
        .aclk(aclk),
        .areset_d1(areset_d1),
        .f_decoder_return({f_decoder_return[2],esc_NLW_gen_wmux_wmux_aw_fifo_f_decoder_return_UNCONNECTED_e7bec0a [1],f_decoder_return[0]}),
        .m_aready(m_aready),
        .m_avalid(m_avalid),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wready(m_axi_wready),
        .m_axi_wstrb(m_axi_wstrb),
        .m_ready_d(m_ready_d),
        .m_valid_i_reg_0(m_valid_i_reg),
        .p_1_in(p_1_in),
        .push(push),
        .reset(reset),
        .s_axi_wdata({s_axi_wdata[95:64],esc_NLW_gen_wmux_wmux_aw_fifo_s_axi_wdata_UNCONNECTED_78d12f1 [63:32],s_axi_wdata[31:0]}),
        .s_axi_wlast({s_axi_wlast[2],esc_NLW_gen_wmux_wmux_aw_fifo_s_axi_wlast_UNCONNECTED_31fe55b [1],s_axi_wlast[0]}),
        .s_axi_wstrb({s_axi_wstrb[11:8],esc_NLW_gen_wmux_wmux_aw_fifo_s_axi_wstrb_UNCONNECTED_c515415 [7:4],s_axi_wstrb[3:0]}),
        .sa_wm_awvalid(sa_wm_awvalid),
        .esc_storage_data1_reg_0__0_22cc170 (m_select_enc[0]),
        .esc_storage_data1_reg_1__0_19392bf (m_select_enc[1]));
endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_wdata_mux__parameterized0
   (esc_gen_rep_0__fifoaddr_reg_0_2da314e ,
    m_avalid,
    Q,
    s_axi_wready,
    esc_storage_data1_reg_0_3e8f598 ,
    m_select_enc,
    esc_storage_data1_reg_1_261ad78 ,
    esc_storage_data1_reg_0__0_22cc170 ,
    esc_FSM_onehot_gen_axi_write_cs_reg_1_dc473f5 ,
    wm_mr_wlast_1,
    esc_storage_data1_reg_1__0_19392bf ,
    push,
    aa_wm_awgrant_enc,
    aclk,
    reset,
    esc_gen_rep_0__fifoaddr_reg_0__0_fd46e5a ,
    areset_d1,
    m_aready,
    esc_FSM_onehot_state_reg_1_070266a ,
    m_avalid_0,
    m_select_enc_1,
    f_decoder_return,
    esc_s_axi_wready_2_bad3bf1 ,
    m_select_enc_2,
    m_select_enc_3,
    sa_wm_awvalid,
    wm_mr_wvalid_1,
    esc_gen_axi_s_axi_bvalid_i_reg_1e6dfb5 ,
    mi_wready_1,
    s_axi_wlast,
    D);
  output [0:0]esc_gen_rep_0__fifoaddr_reg_0_2da314e ;
  output m_avalid;
  output [2:0]Q;
  output [0:0]s_axi_wready;
  output esc_storage_data1_reg_0_3e8f598 ;
  output [1:0]m_select_enc;
  output esc_storage_data1_reg_1_261ad78 ;
  output esc_storage_data1_reg_0__0_22cc170 ;
  output esc_FSM_onehot_gen_axi_write_cs_reg_1_dc473f5 ;
  output wm_mr_wlast_1;
  output esc_storage_data1_reg_1__0_19392bf ;
  input push;
  input [1:0]aa_wm_awgrant_enc;
  input aclk;
  input reset;
  input esc_gen_rep_0__fifoaddr_reg_0__0_fd46e5a ;
  input areset_d1;
  input m_aready;
  input esc_FSM_onehot_state_reg_1_070266a ;
  input m_avalid_0;
  input m_select_enc_1;
  input [2:0]f_decoder_return;
  input esc_s_axi_wready_2_bad3bf1 ;
  input m_select_enc_2;
  input m_select_enc_3;
  input [0:0]sa_wm_awvalid;
  input wm_mr_wvalid_1;
  input esc_gen_axi_s_axi_bvalid_i_reg_1e6dfb5 ;
  input mi_wready_1;
  input [2:0]s_axi_wlast;
  input [1:0]D;

  wire [1:0]D;
  wire esc_FSM_onehot_gen_axi_write_cs_reg_1_dc473f5 ;
  wire esc_FSM_onehot_state_reg_1_070266a ;
  wire [2:0]Q;
  wire [1:0]aa_wm_awgrant_enc;
  wire aclk;
  wire areset_d1;
  wire [2:0]f_decoder_return;
  wire esc_gen_axi_s_axi_bvalid_i_reg_1e6dfb5 ;
  wire [0:0]esc_gen_rep_0__fifoaddr_reg_0_2da314e ;
  wire esc_gen_rep_0__fifoaddr_reg_0__0_fd46e5a ;
  wire m_aready;
  wire m_avalid;
  wire m_avalid_0;
  wire [1:0]m_select_enc;
  wire m_select_enc_1;
  wire m_select_enc_3;
  wire mi_wready_1;
  wire push;
  wire reset;
  wire [2:0]s_axi_wlast;
  wire [0:0]s_axi_wready;
  wire esc_s_axi_wready_2_bad3bf1 ;
  wire [0:0]sa_wm_awvalid;
  wire esc_storage_data1_reg_0_3e8f598 ;
  wire esc_storage_data1_reg_0__0_22cc170 ;
  wire esc_storage_data1_reg_1__0_19392bf ;
  wire wm_mr_wlast_1;
  wire wm_mr_wvalid_1;
  wire [1:0]esc_NLW_gen_wmux_wmux_aw_fifo_aa_wm_awgrant_enc_UNCONNECTED_0ed6d5e ;
  wire [2:0]esc_NLW_gen_wmux_wmux_aw_fifo_f_decoder_return_UNCONNECTED_e7bec0a ;
  wire [2:0]esc_NLW_gen_wmux_wmux_aw_fifo_s_axi_wlast_UNCONNECTED_31fe55b ;

  system_xbar_1_axi_data_fifo_v2_1_21_axic_reg_srl_fifo__parameterized2 esc_gen_wmux_wmux_aw_fifo_c90851b 
       (.A(esc_gen_rep_0__fifoaddr_reg_0_2da314e ),
        .D(D),
        .esc_FSM_onehot_gen_axi_write_cs_reg_1_dc473f5 (esc_FSM_onehot_gen_axi_write_cs_reg_1_dc473f5 ),
        .esc_FSM_onehot_state_reg_1__0_2261399 (esc_FSM_onehot_state_reg_1_070266a ),
        .Q(Q),
        .aa_wm_awgrant_enc({aa_wm_awgrant_enc[1],esc_NLW_gen_wmux_wmux_aw_fifo_aa_wm_awgrant_enc_UNCONNECTED_0ed6d5e [0]}),
        .aclk(aclk),
        .areset_d1(areset_d1),
        .f_decoder_return({f_decoder_return[2],esc_NLW_gen_wmux_wmux_aw_fifo_f_decoder_return_UNCONNECTED_e7bec0a [1],f_decoder_return[0]}),
        .esc_gen_axi_s_axi_bvalid_i_reg_1e6dfb5 (esc_gen_axi_s_axi_bvalid_i_reg_1e6dfb5 ),
        .esc_gen_rep_0__fifoaddr_reg_0__0_fd46e5a (esc_gen_rep_0__fifoaddr_reg_0__0_fd46e5a ),
        .m_aready(m_aready),
        .m_avalid(m_avalid),
        .m_avalid_0(m_avalid_0),
        .m_select_enc_1(m_select_enc_1),
        .m_select_enc_3(m_select_enc_3),
        .mi_wready_1(mi_wready_1),
        .push(push),
        .reset(reset),
        .s_axi_wlast({s_axi_wlast[2],esc_NLW_gen_wmux_wmux_aw_fifo_s_axi_wlast_UNCONNECTED_31fe55b [1],s_axi_wlast[0]}),
        .s_axi_wready(s_axi_wready),
        .esc_s_axi_wready_2_bad3bf1 (esc_s_axi_wready_2_bad3bf1 ),
        .sa_wm_awvalid(sa_wm_awvalid),
        .esc_storage_data1_reg_0__0_22cc170 (esc_storage_data1_reg_0_3e8f598 ),
        .esc_storage_data1_reg_0__1_c56c57a (m_select_enc[0]),
        .esc_storage_data1_reg_0__2_ff09e73 (esc_storage_data1_reg_0__0_22cc170 ),
        .esc_storage_data1_reg_1__0_19392bf (m_select_enc[1]),
        .esc_storage_data1_reg_1__2_7868a8c (esc_storage_data1_reg_1__0_19392bf ),
        .wm_mr_wlast_1(wm_mr_wlast_1),
        .wm_mr_wvalid_1(wm_mr_wvalid_1));
endmodule

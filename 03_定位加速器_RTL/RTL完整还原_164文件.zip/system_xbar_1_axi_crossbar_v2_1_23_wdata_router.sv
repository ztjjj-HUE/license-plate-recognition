// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_wdata_router
   (m_avalid,
    ss_wr_awready_0,
    m_select_enc,
    m_aready,
    wm_mr_wvalid_1,
    m_aready_0,
    m_axi_wvalid,
    st_aa_awtarget_hot,
    aclk,
    areset_d1,
    reset,
    s_axi_awvalid,
    m_ready_d,
    s_axi_wlast,
    s_axi_wvalid,
    esc_FSM_onehot_state_reg_3_5c113c4 ,
    wm_mr_wlast_1,
    mi_wready_1,
    esc_gen_axi_s_axi_wready_i_i_2_12e5647 ,
    esc_gen_axi_s_axi_wready_i_i_2_0_c3af132 ,
    m_avalid_1,
    m_axi_wlast,
    m_axi_wready,
    .m_axi_wvalid_0_sp_1(m_axi_wvalid_0_sn_1),
    f_decoder_return,
    m_avalid_2);
  output m_avalid;
  output ss_wr_awready_0;
  output m_select_enc;
  output m_aready;
  output wm_mr_wvalid_1;
  output m_aready_0;
  output [0:0]m_axi_wvalid;
  input [1:0]st_aa_awtarget_hot;
  input aclk;
  input areset_d1;
  input reset;
  input [0:0]s_axi_awvalid;
  input [0:0]m_ready_d;
  input [0:0]s_axi_wlast;
  input [0:0]s_axi_wvalid;
  input esc_FSM_onehot_state_reg_3_5c113c4 ;
  input wm_mr_wlast_1;
  input mi_wready_1;
  input esc_gen_axi_s_axi_wready_i_i_2_12e5647 ;
  input esc_gen_axi_s_axi_wready_i_i_2_0_c3af132 ;
  input m_avalid_1;
  input [0:0]m_axi_wlast;
  input [0:0]m_axi_wready;
  input [0:0]f_decoder_return;
  input m_avalid_2;
  input m_axi_wvalid_0_sn_1;

  wire esc_FSM_onehot_state_reg_3_5c113c4 ;
  wire aclk;
  wire areset_d1;
  wire [0:0]f_decoder_return;
  wire esc_gen_axi_s_axi_wready_i_i_2_12e5647 ;
  wire esc_gen_axi_s_axi_wready_i_i_2_0_c3af132 ;
  wire m_aready;
  wire m_aready_0;
  wire m_avalid;
  wire m_avalid_1;
  wire m_avalid_2;
  wire [0:0]m_axi_wlast;
  wire [0:0]m_axi_wready;
  wire [0:0]m_axi_wvalid;
  wire m_axi_wvalid_0_sn_1;
  wire [0:0]m_ready_d;
  wire m_select_enc;
  wire mi_wready_1;
  wire reset;
  wire [0:0]s_axi_awvalid;
  wire [0:0]s_axi_wlast;
  wire [0:0]s_axi_wvalid;
  wire ss_wr_awready_0;
  wire [1:0]st_aa_awtarget_hot;
  wire wm_mr_wlast_1;
  wire wm_mr_wvalid_1;

  system_xbar_1_axi_data_fifo_v2_1_21_axic_reg_srl_fifo wrouter_aw_fifo
       (.esc_FSM_onehot_state_reg_3__0_58ac7ab (esc_FSM_onehot_state_reg_3_5c113c4 ),
        .aclk(aclk),
        .areset_d1(areset_d1),
        .f_decoder_return(f_decoder_return),
        .esc_gen_axi_s_axi_wready_i_i_2_12e5647 (esc_gen_axi_s_axi_wready_i_i_2_12e5647 ),
        .esc_gen_axi_s_axi_wready_i_i_2_0_c3af132 (esc_gen_axi_s_axi_wready_i_i_2_0_c3af132 ),
        .m_aready(m_aready),
        .m_aready_0(m_aready_0),
        .m_avalid_1(m_avalid_1),
        .m_avalid_2(m_avalid_2),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wready(m_axi_wready),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wvalid_0_sp_1(m_axi_wvalid_0_sn_1),
        .m_ready_d(m_ready_d),
        .m_valid_i_reg_0(m_avalid),
        .mi_wready_1(mi_wready_1),
        .reset(reset),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wvalid(s_axi_wvalid),
        .s_ready_i_reg_0(ss_wr_awready_0),
        .st_aa_awtarget_hot(st_aa_awtarget_hot),
        .esc_storage_data1_reg_0__0_22cc170 (m_select_enc),
        .wm_mr_wlast_1(wm_mr_wlast_1),
        .wm_mr_wvalid_1(wm_mr_wvalid_1));
endmodule

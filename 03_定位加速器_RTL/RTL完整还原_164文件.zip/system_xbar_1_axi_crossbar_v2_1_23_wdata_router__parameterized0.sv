// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_wdata_router__parameterized0
   (ss_wr_awready_1,
    m_select_enc,
    s_axi_wready,
    esc_storage_data1_reg_0_3e8f598 ,
    esc_storage_data1_reg_0__0_22cc170 ,
    esc_storage_data1_reg_0__1_c56c57a ,
    aclk,
    areset_d1,
    reset,
    s_axi_awvalid,
    m_ready_d,
    esc_s_axi_wready_1_4923277 ,
    s_axi_wlast,
    s_axi_wvalid,
    m_select_enc_0,
    m_select_enc_1,
    esc_m_axi_wvalid_0_57ca2b0 ,
    m_select_enc_2);
  output ss_wr_awready_1;
  output m_select_enc;
  output [0:0]s_axi_wready;
  output esc_storage_data1_reg_0_3e8f598 ;
  output esc_storage_data1_reg_0__0_22cc170 ;
  input [0:0]esc_storage_data1_reg_0__1_c56c57a ;
  input aclk;
  input areset_d1;
  input reset;
  input [0:0]s_axi_awvalid;
  input [0:0]m_ready_d;
  input esc_s_axi_wready_1_4923277 ;
  input [0:0]s_axi_wlast;
  input [0:0]s_axi_wvalid;
  input [1:0]m_select_enc_0;
  input m_select_enc_1;
  input esc_m_axi_wvalid_0_57ca2b0 ;
  input [1:0]m_select_enc_2;

  wire esc_m_axi_wvalid_0_57ca2b0 ;
  wire [1:0]m_select_enc_0;
  wire m_select_enc_1;
  wire [1:0]m_select_enc_2;
  wire esc_storage_data1_reg_0_3e8f598 ;
  wire esc_storage_data1_reg_0__0_22cc170 ;

  system_xbar_1_axi_data_fifo_v2_1_21_axic_reg_srl_fifo__parameterized0_6 wrouter_aw_fifo
       (.esc_m_axi_wvalid_0_57ca2b0 (esc_m_axi_wvalid_0_57ca2b0 ),
        .m_select_enc_0(m_select_enc_0),
        .m_select_enc_1(m_select_enc_1),
        .m_select_enc_2(m_select_enc_2),
        .esc_storage_data1_reg_0__1_c56c57a (esc_storage_data1_reg_0_3e8f598 ),
        .esc_storage_data1_reg_0__2_ff09e73 (esc_storage_data1_reg_0__0_22cc170 ));
endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_crossbar_v2_1_23_wdata_router__parameterized0_4
   (areset_d1,
    ss_wr_awready_2,
    m_select_enc,
    s_axi_wready,
    m_valid_i_reg,
    aclk,
    reset,
    s_axi_awvalid,
    m_ready_d,
    st_aa_awtarget_hot,
    esc_s_axi_wready_2_bad3bf1 ,
    s_axi_wlast,
    s_axi_wvalid);
  output areset_d1;
  output ss_wr_awready_2;
  output m_select_enc;
  output [0:0]s_axi_wready;
  output m_valid_i_reg;
  input aclk;
  input reset;
  input [0:0]s_axi_awvalid;
  input [0:0]m_ready_d;
  input [0:0]st_aa_awtarget_hot;
  input esc_s_axi_wready_2_bad3bf1 ;
  input [0:0]s_axi_wlast;
  input [0:0]s_axi_wvalid;

  wire aclk;
  wire areset_d1;
  wire [0:0]m_ready_d;
  wire m_select_enc;
  wire m_valid_i_reg;
  wire reset;
  wire [0:0]s_axi_awvalid;
  wire [0:0]s_axi_wlast;
  wire [0:0]s_axi_wready;
  wire esc_s_axi_wready_2_bad3bf1 ;
  wire [0:0]s_axi_wvalid;
  wire ss_wr_awready_2;
  wire [0:0]st_aa_awtarget_hot;

  system_xbar_1_axi_data_fifo_v2_1_21_axic_reg_srl_fifo__parameterized0 wrouter_aw_fifo
       (.SS(areset_d1),
        .aclk(aclk),
        .m_ready_d(m_ready_d),
        .m_select_enc(m_select_enc),
        .m_valid_i_reg_0(m_valid_i_reg),
        .reset(reset),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wready(s_axi_wready),
        .esc_s_axi_wready_2_bad3bf1 (esc_s_axi_wready_2_bad3bf1 ),
        .s_axi_wvalid(s_axi_wvalid),
        .s_ready_i_reg_0(ss_wr_awready_2),
        .st_aa_awtarget_hot(st_aa_awtarget_hot));
endmodule

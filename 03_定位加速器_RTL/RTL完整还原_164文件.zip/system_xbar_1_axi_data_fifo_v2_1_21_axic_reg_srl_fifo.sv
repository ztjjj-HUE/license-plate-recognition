// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_data_fifo_v2_1_21_axic_reg_srl_fifo
   (m_valid_i_reg_0,
    s_ready_i_reg_0,
    esc_storage_data1_reg_0__0_22cc170 ,
    m_aready,
    wm_mr_wvalid_1,
    m_aready_0,
    m_axi_wvalid,
    st_aa_awtarget_hot,
    aclk,
    areset_d1,
    reset,
    s_axi_awvalid,
    m_ready_d,
    s_axi_wlast,
    s_axi_wvalid,
    esc_FSM_onehot_state_reg_3__0_58ac7ab ,
    wm_mr_wlast_1,
    mi_wready_1,
    esc_gen_axi_s_axi_wready_i_i_2_12e5647 ,
    esc_gen_axi_s_axi_wready_i_i_2_0_c3af132 ,
    m_avalid_1,
    m_axi_wlast,
    m_axi_wready,
    .m_axi_wvalid_0_sp_1(m_axi_wvalid_0_sn_1),
    f_decoder_return,
    m_avalid_2);
  output m_valid_i_reg_0;
  output s_ready_i_reg_0;
  output esc_storage_data1_reg_0__0_22cc170 ;
  output m_aready;
  output wm_mr_wvalid_1;
  output m_aready_0;
  output [0:0]m_axi_wvalid;
  input [1:0]st_aa_awtarget_hot;
  input aclk;
  input areset_d1;
  input reset;
  input [0:0]s_axi_awvalid;
  input [0:0]m_ready_d;
  input [0:0]s_axi_wlast;
  input [0:0]s_axi_wvalid;
  input esc_FSM_onehot_state_reg_3__0_58ac7ab ;
  input wm_mr_wlast_1;
  input mi_wready_1;
  input esc_gen_axi_s_axi_wready_i_i_2_12e5647 ;
  input esc_gen_axi_s_axi_wready_i_i_2_0_c3af132 ;
  input m_avalid_1;
  input [0:0]m_axi_wlast;
  input [0:0]m_axi_wready;
  input [0:0]f_decoder_return;
  input m_avalid_2;
  input m_axi_wvalid_0_sn_1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire esc_FSM_onehot_state_0__i_1_n_0_78643ea ;
  wire esc_FSM_onehot_state_1__i_1_n_0_6912413 ;
  wire esc_FSM_onehot_state_1__i_2_n_0_4bafa4f ;
  wire esc_FSM_onehot_state_3__i_2_n_0_675d89d ;
  wire esc_FSM_onehot_state_reg_3__0_58ac7ab ;
  wire esc_FSM_onehot_state_reg_n_0__0_ee5cad1 ;
  wire aclk;
  wire areset_d1;
  wire [0:0]f_decoder_return;
  wire [2:0]fifoaddr;
  wire esc_gen_axi_s_axi_wready_i_i_2_12e5647 ;
  wire esc_gen_axi_s_axi_wready_i_i_2_0_c3af132 ;
  wire esc_gen_rep_0__fifoaddr_0__i_1_n_0_f91a071 ;
  wire esc_gen_rep_0__fifoaddr_0__i_2_n_0_39cade9 ;
  wire esc_gen_rep_0__fifoaddr_1__i_1_n_0_b55aa70 ;
  wire esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46 ;
  wire esc_gen_srls_0__gen_rep_0__srl_nx1_n_1_3dd95f4 ;
  wire load_s1;
  wire m_aready;
  wire m_aready_0;
  wire m_aready_1;
  wire m_avalid_1;
  wire m_avalid_2;
  wire [0:0]m_axi_wlast;
  wire [0:0]m_axi_wready;
  wire [0:0]m_axi_wvalid;
  wire m_axi_wvalid_0_sn_1;
  wire [0:0]m_ready_d;
  wire m_valid_i;
  wire m_valid_i_i_1_n_0;
  wire m_valid_i_reg_0;
  wire mi_wready_1;
  wire p_0_in8_in;
  wire p_9_in;
  wire push;
  wire reset;
  wire [0:0]s_axi_awvalid;
  wire [0:0]s_axi_wlast;
  wire [0:0]s_axi_wvalid;
  wire s_ready_i_i_1_n_0;
  wire s_ready_i_i_2_n_0;
  wire s_ready_i_reg_0;
  wire [1:0]st_aa_awtarget_hot;
  wire esc_storage_data1_reg_0__0_22cc170 ;
  wire wm_mr_wlast_1;
  wire wm_mr_wvalid_1;

  // Reconstructed LUT4: esc_FSM_onehot_state_0__i_1_a03811a
  assign esc_FSM_onehot_state_0__i_1_n_0_78643ea = ((p_0_in8_in) ? (((m_ready_d) ? (~(m_aready_1)) : (((s_axi_awvalid) ? (1'b1) : (~(m_aready_1)))))) : (1'b0));

  // Reconstructed LUT5: esc_FSM_onehot_state_1__i_1_c672e6d
  assign esc_FSM_onehot_state_1__i_1_n_0_6912413 = ((p_9_in) ? (((m_ready_d) ? (((esc_FSM_onehot_state_1__i_2_n_0_4bafa4f) ? (~(push)) : (1'b0))) : (((s_axi_awvalid) ? (1'b1) : (((esc_FSM_onehot_state_1__i_2_n_0_4bafa4f) ? (~(push)) : (1'b0))))))) : (((esc_FSM_onehot_state_1__i_2_n_0_4bafa4f) ? (~(push)) : (1'b0))));

  // Reconstructed LUT5: esc_FSM_onehot_state_1__i_2_1d1cfc1
  assign esc_FSM_onehot_state_1__i_2_n_0_4bafa4f = ((m_aready_1) ? (((fifoaddr[1]) ? (1'b0) : (((fifoaddr[0]) ? (1'b0) : (((fifoaddr[2]) ? (1'b0) : (esc_FSM_onehot_state_reg_n_0__0_ee5cad1))))))) : (1'b0));

  // Reconstructed LUT5: esc_FSM_onehot_state_3__i_1_64a1985
  assign m_valid_i = ((m_aready_1) ? (((p_0_in8_in) ? (((m_ready_d) ? (1'b1) : (((s_axi_awvalid) ? (esc_FSM_onehot_state_1__i_1_n_0_6912413) : (1'b1))))) : (esc_FSM_onehot_state_1__i_1_n_0_6912413))) : (((p_0_in8_in) ? (((m_ready_d) ? (esc_FSM_onehot_state_1__i_1_n_0_6912413) : (((s_axi_awvalid) ? (1'b1) : (esc_FSM_onehot_state_1__i_1_n_0_6912413))))) : (esc_FSM_onehot_state_1__i_1_n_0_6912413))));

  // Reconstructed LUT4: esc_FSM_onehot_state_3__i_2_40b6139
  assign esc_FSM_onehot_state_3__i_2_n_0_675d89d = ((m_aready_1) ? (((p_0_in8_in) ? (((m_ready_d) ? (1'b1) : (~(s_axi_awvalid)))) : (1'b0))) : (1'b0));

  // Reconstructed FDRE: esc_FSM_onehot_state_reg_0_536fb89
  reg recovered_6_q = 1'b0;
  assign esc_FSM_onehot_state_reg_n_0__0_ee5cad1 = recovered_6_q;
  wire recovered_6_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((areset_d1) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_6_q == (esc_FSM_onehot_state_0__i_1_n_0_78643ea)))) recovered_6_q <= (esc_FSM_onehot_state_0__i_1_n_0_78643ea);
  end

  // Reconstructed FDRE: esc_FSM_onehot_state_reg_1_070266a
  reg recovered_7_q = 1'b0;
  assign p_0_in8_in = recovered_7_q;
  wire recovered_7_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((areset_d1) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_7_q == (esc_FSM_onehot_state_1__i_1_n_0_6912413)))) recovered_7_q <= (esc_FSM_onehot_state_1__i_1_n_0_6912413);
  end

  // Reconstructed FDSE: esc_FSM_onehot_state_reg_3_5c113c4
  reg recovered_8_q = 1'b1;
  assign p_9_in = recovered_8_q;
  wire recovered_8_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_8_reset || (((areset_d1) === 1'bx) && (recovered_8_q == 1'b1))) recovered_8_q <= 1'b1;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_8_q == (esc_FSM_onehot_state_3__i_2_n_0_675d89d)))) recovered_8_q <= (esc_FSM_onehot_state_3__i_2_n_0_675d89d);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT3: esc_gen_primitive_shifter_gen_srls_0__srl_inst_i_2__2_5a27eb7
  assign m_aready = ((mi_wready_1) ? (((wm_mr_wlast_1) ? (wm_mr_wvalid_1) : (1'b0))) : (1'b0));

  // Reconstructed LUT3: esc_gen_primitive_shifter_gen_srls_0__srl_inst_i_2__3_de7f422
  assign m_aready_0 = ((m_axi_wready) ? (((m_axi_wlast) ? (m_axi_wvalid) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: esc_gen_primitive_shifter_gen_srls_0__srl_inst_i_3__1_6e804fe
  assign wm_mr_wvalid_1 = ((m_avalid_1) ? (((esc_gen_axi_s_axi_wready_i_i_2_0_c3af132) ? (((m_valid_i_reg_0) ? (((s_axi_wvalid) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b1) : (esc_gen_axi_s_axi_wready_i_i_2_12e5647))) : (esc_gen_axi_s_axi_wready_i_i_2_12e5647))) : (esc_gen_axi_s_axi_wready_i_i_2_12e5647))) : (esc_gen_axi_s_axi_wready_i_i_2_12e5647))) : (1'b0));

  // Reconstructed LUT2: esc_gen_rep_0__fifoaddr_0__i_1_751ffbd
  assign esc_gen_rep_0__fifoaddr_0__i_1_n_0_f91a071 = ((fifoaddr[0]) ? (~(esc_gen_rep_0__fifoaddr_0__i_2_n_0_39cade9)) : (esc_gen_rep_0__fifoaddr_0__i_2_n_0_39cade9));

  // Reconstructed LUT6: esc_gen_rep_0__fifoaddr_0__i_2_57488c8
  assign esc_gen_rep_0__fifoaddr_0__i_2_n_0_39cade9 = ((m_aready_1) ? (((s_ready_i_reg_0) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_ready_d) ? (1'b1) : (~(s_axi_awvalid)))) : (1'b0))) : (esc_FSM_onehot_state_reg_n_0__0_ee5cad1))) : (((p_0_in8_in) ? (((m_ready_d) ? (1'b0) : (s_axi_awvalid))) : (((s_ready_i_reg_0) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_ready_d) ? (1'b0) : (s_axi_awvalid))) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT5: esc_gen_rep_0__fifoaddr_1__i_1_452a188
  assign esc_gen_rep_0__fifoaddr_1__i_1_n_0_b55aa70 = ((fifoaddr[1]) ? (((push) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_aready_1) ? (1'b1) : (~(fifoaddr[0])))) : (~(fifoaddr[0])))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_aready_1) ? (fifoaddr[0]) : (1'b1))) : (1'b1))))) : (((push) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_aready_1) ? (1'b0) : (fifoaddr[0]))) : (fifoaddr[0]))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_aready_1) ? (~(fifoaddr[0])) : (1'b0))) : (1'b0))))));

  // Reconstructed LUT6: esc_gen_rep_0__fifoaddr_2__i_1_7a332c8
  assign esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46 = ((fifoaddr[2]) ? (((push) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_aready_1) ? (1'b1) : (((fifoaddr[1]) ? (~(fifoaddr[0])) : (1'b1))))) : (((fifoaddr[1]) ? (~(fifoaddr[0])) : (1'b1))))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_aready_1) ? (((fifoaddr[1]) ? (1'b1) : (fifoaddr[0]))) : (1'b1))) : (1'b1))))) : (((push) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_aready_1) ? (1'b0) : (((fifoaddr[1]) ? (fifoaddr[0]) : (1'b0))))) : (((fifoaddr[1]) ? (fifoaddr[0]) : (1'b0))))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_aready_1) ? (((fifoaddr[1]) ? (1'b0) : (~(fifoaddr[0])))) : (1'b0))) : (1'b0))))));

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_0_2da314e
  reg recovered_18_q = 1'b1;
  assign fifoaddr[0] = recovered_18_q;
  wire recovered_18_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((reset) === 1'bx) && (recovered_18_q == 1'b1))) recovered_18_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_18_q == (esc_gen_rep_0__fifoaddr_0__i_1_n_0_f91a071)))) recovered_18_q <= (esc_gen_rep_0__fifoaddr_0__i_1_n_0_f91a071);
  end

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_1_9ffca33
  reg recovered_19_q = 1'b1;
  assign fifoaddr[1] = recovered_19_q;
  wire recovered_19_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((reset) === 1'bx) && (recovered_19_q == 1'b1))) recovered_19_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_19_q == (esc_gen_rep_0__fifoaddr_1__i_1_n_0_b55aa70)))) recovered_19_q <= (esc_gen_rep_0__fifoaddr_1__i_1_n_0_b55aa70);
  end

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_2_19f7d82
  reg recovered_20_q = 1'b1;
  assign fifoaddr[2] = recovered_20_q;
  wire recovered_20_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((reset) === 1'bx) && (recovered_20_q == 1'b1))) recovered_20_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_20_q == (esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46)))) recovered_20_q <= (esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46);
  end

  system_xbar_1_axi_data_fifo_v2_1_21_ndeep_srl__parameterized0 esc_gen_srls_0__gen_rep_0__srl_nx1_87f4823 
       (.esc_FSM_onehot_state_reg_0_536fb89 (esc_gen_srls_0__gen_rep_0__srl_nx1_n_1_3dd95f4 ),
        .esc_FSM_onehot_state_reg_1_070266a (s_ready_i_reg_0),
        .esc_FSM_onehot_state_reg_3_5c113c4 (m_valid_i_reg_0),
        .esc_FSM_onehot_state_reg_3__0_58ac7ab (esc_FSM_onehot_state_reg_3__0_58ac7ab ),
        .Q({p_0_in8_in,esc_FSM_onehot_state_reg_n_0__0_ee5cad1 }),
        .aclk(aclk),
        .fifoaddr(fifoaddr),
        .load_s1(load_s1),
        .m_aready_1(m_aready_1),
        .m_ready_d(m_ready_d),
        .push(push),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wvalid(s_axi_wvalid),
        .st_aa_awtarget_hot(st_aa_awtarget_hot),
        .esc_storage_data1_reg_0_3e8f598 (esc_storage_data1_reg_0__0_22cc170 ));

  // Reconstructed LUT6: esc_m_axi_wvalid_0__INST_0_19e36b0
  assign m_axi_wvalid = ((m_avalid_2) ? (((f_decoder_return) ? (((m_valid_i_reg_0) ? (((s_axi_wvalid) ? (((esc_storage_data1_reg_0__0_22cc170) ? (m_axi_wvalid_0_sn_1) : (1'b1))) : (m_axi_wvalid_0_sn_1))) : (m_axi_wvalid_0_sn_1))) : (m_axi_wvalid_0_sn_1))) : (1'b0));

  // Reconstructed LUT5: m_valid_i_i_1
  assign m_valid_i_i_1_n_0 = ((esc_FSM_onehot_state_1__i_1_n_0_6912413) ? (1'b1) : (((s_axi_awvalid) ? (((m_ready_d) ? (1'b0) : (((p_0_in8_in) ? (~(m_aready_1)) : (1'b0))))) : (1'b0))));

  // Reconstructed FDRE: m_valid_i_reg
  reg recovered_24_q = 1'b0;
  assign m_valid_i_reg_0 = recovered_24_q;
  wire recovered_24_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_24_reset || (((areset_d1) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_24_q == (m_valid_i_i_1_n_0)))) recovered_24_q <= (m_valid_i_i_1_n_0);
  end

  // Reconstructed LUT6: s_ready_i_i_1
  assign s_ready_i_i_1_n_0 = ((s_ready_i_reg_0) ? (((fifoaddr[0]) ? (1'b1) : (((fifoaddr[1]) ? (((fifoaddr[2]) ? (((push) ? (s_ready_i_i_2_n_0) : (1'b1))) : (1'b1))) : (1'b1))))) : (s_ready_i_i_2_n_0));

  // Reconstructed LUT3: s_ready_i_i_2
  assign s_ready_i_i_2_n_0 = ((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_aready_1) ? (1'b1) : (areset_d1))) : (areset_d1));

  // Reconstructed FDRE: s_ready_i_reg
  reg recovered_27_q = 1'b0;
  assign s_ready_i_reg_0 = recovered_27_q;
  wire recovered_27_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_27_reset || (((reset) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_27_q == (s_ready_i_i_1_n_0)))) recovered_27_q <= (s_ready_i_i_1_n_0);
  end

  // Reconstructed LUT6: esc_storage_data1_0__i_2_9aaca67
  assign load_s1 = ((s_axi_awvalid) ? (((m_ready_d) ? (((m_aready_1) ? (esc_FSM_onehot_state_reg_n_0__0_ee5cad1) : (1'b0))) : (((p_0_in8_in) ? (((m_aready_1) ? (1'b1) : (p_9_in))) : (((m_aready_1) ? (((p_9_in) ? (1'b1) : (esc_FSM_onehot_state_reg_n_0__0_ee5cad1))) : (p_9_in))))))) : (((m_aready_1) ? (esc_FSM_onehot_state_reg_n_0__0_ee5cad1) : (1'b0))));

  // Reconstructed FDRE: esc_storage_data1_reg_0_3e8f598
  reg recovered_29_q = 1'b0;
  assign esc_storage_data1_reg_0__0_22cc170 = recovered_29_q;
  wire recovered_29_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_29_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_29_q == (esc_gen_srls_0__gen_rep_0__srl_nx1_n_1_3dd95f4)))) recovered_29_q <= (esc_gen_srls_0__gen_rep_0__srl_nx1_n_1_3dd95f4);
  end

endmodule

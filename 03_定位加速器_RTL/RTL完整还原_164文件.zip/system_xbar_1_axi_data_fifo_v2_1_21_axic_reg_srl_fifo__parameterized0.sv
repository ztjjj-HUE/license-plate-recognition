// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_data_fifo_v2_1_21_axic_reg_srl_fifo__parameterized0
   (SS,
    s_ready_i_reg_0,
    m_select_enc,
    s_axi_wready,
    m_valid_i_reg_0,
    aclk,
    reset,
    s_axi_awvalid,
    m_ready_d,
    st_aa_awtarget_hot,
    esc_s_axi_wready_2_bad3bf1 ,
    s_axi_wlast,
    s_axi_wvalid);
  output [0:0]SS;
  output s_ready_i_reg_0;
  output m_select_enc;
  output [0:0]s_axi_wready;
  output m_valid_i_reg_0;
  input aclk;
  input reset;
  input [0:0]s_axi_awvalid;
  input [0:0]m_ready_d;
  input [0:0]st_aa_awtarget_hot;
  input esc_s_axi_wready_2_bad3bf1 ;
  input [0:0]s_axi_wlast;
  input [0:0]s_axi_wvalid;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire esc_FSM_onehot_state_0__i_1__1_n_0_1dbc5bf ;
  wire esc_FSM_onehot_state_1__i_1__1_n_0_dfdfbcf ;
  wire esc_FSM_onehot_state_1__i_2__1_n_0_481aaad ;
  wire esc_FSM_onehot_state_1__i_3__1_n_0_e01b376 ;
  wire esc_FSM_onehot_state_3__i_2__1_n_0_f7a3d37 ;
  wire esc_FSM_onehot_state_reg_n_0__0_ee5cad1 ;
  wire [0:0]SS;
  wire aclk;
  wire esc_gen_rep_0__fifoaddr_0__i_1__0_n_0_f1aea08 ;
  wire esc_gen_rep_0__fifoaddr_1__i_1__0_n_0_6d9bc7e ;
  wire esc_gen_rep_0__fifoaddr_2__i_1__1_n_0_e61c8b2 ;
  wire esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f ;
  wire esc_gen_rep_0__fifoaddr_3__i_2__0_n_0_3209ca4 ;
  wire [3:0]esc_gen_rep_0__fifoaddr_reg_95ecfab ;
  wire esc_gen_srls_0__gen_rep_0__srl_nx1_n_1_3dd95f4 ;
  wire esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6 ;
  wire load_s1;
  wire m_avalid;
  wire [0:0]m_ready_d;
  wire m_select_enc;
  wire m_valid_i;
  wire m_valid_i_i_1__1_n_0;
  wire m_valid_i_reg_0;
  wire p_0_in8_in;
  wire p_9_in;
  wire push;
  wire reset;
  wire [0:0]s_axi_awvalid;
  wire [0:0]s_axi_wlast;
  wire [0:0]s_axi_wready;
  wire esc_s_axi_wready_2_bad3bf1 ;
  wire [0:0]s_axi_wvalid;
  wire s_ready_i_i_1__1_n_0;
  wire s_ready_i_i_2__1_n_0;
  wire s_ready_i_reg_0;
  wire [0:0]st_aa_awtarget_hot;

  // Reconstructed LUT4: esc_FSM_onehot_state_0__i_1__1_a9b6110
  assign esc_FSM_onehot_state_0__i_1__1_n_0_1dbc5bf = ((m_ready_d) ? (((esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) ? (p_0_in8_in) : (1'b0))) : (((s_axi_awvalid) ? (p_0_in8_in) : (((esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) ? (p_0_in8_in) : (1'b0))))));

  // Reconstructed LUT6: esc_FSM_onehot_state_1__i_1__1_089b0be
  assign esc_FSM_onehot_state_1__i_1__1_n_0_dfdfbcf = ((esc_FSM_onehot_state_1__i_3__1_n_0_e01b376) ? (((m_ready_d) ? (1'b0) : (((s_axi_awvalid) ? (p_9_in) : (1'b0))))) : (((m_ready_d) ? (~(esc_FSM_onehot_state_1__i_2__1_n_0_481aaad)) : (((s_axi_awvalid) ? (((s_ready_i_reg_0) ? (p_9_in) : (((esc_FSM_onehot_state_1__i_2__1_n_0_481aaad) ? (p_9_in) : (1'b1))))) : (~(esc_FSM_onehot_state_1__i_2__1_n_0_481aaad)))))));

  // Reconstructed LUT4: esc_FSM_onehot_state_1__i_2__1_3df99b7
  assign esc_FSM_onehot_state_1__i_2__1_n_0_481aaad = ((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (1'b1) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (1'b1) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [2]) ? (1'b1) : (esc_gen_rep_0__fifoaddr_reg_95ecfab [3]))))));

  // Reconstructed LUT2: esc_FSM_onehot_state_1__i_3__1_5eab9e3
  assign esc_FSM_onehot_state_1__i_3__1_n_0_e01b376 = ((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) : (1'b1));

  // Reconstructed LUT5: esc_FSM_onehot_state_3__i_1__1_ca384a9
  assign m_valid_i = ((m_ready_d) ? (((p_0_in8_in) ? (((esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) ? (esc_FSM_onehot_state_1__i_1__1_n_0_dfdfbcf) : (1'b1))) : (esc_FSM_onehot_state_1__i_1__1_n_0_dfdfbcf))) : (((s_axi_awvalid) ? (((p_0_in8_in) ? (((esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) ? (1'b1) : (esc_FSM_onehot_state_1__i_1__1_n_0_dfdfbcf))) : (esc_FSM_onehot_state_1__i_1__1_n_0_dfdfbcf))) : (((p_0_in8_in) ? (((esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) ? (esc_FSM_onehot_state_1__i_1__1_n_0_dfdfbcf) : (1'b1))) : (esc_FSM_onehot_state_1__i_1__1_n_0_dfdfbcf))))));

  // Reconstructed LUT4: esc_FSM_onehot_state_3__i_2__1_e4bb3cb
  assign esc_FSM_onehot_state_3__i_2__1_n_0_f7a3d37 = ((m_ready_d) ? (((esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) ? (1'b0) : (p_0_in8_in))) : (((s_axi_awvalid) ? (1'b0) : (((esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) ? (1'b0) : (p_0_in8_in))))));

  // Reconstructed FDRE: esc_FSM_onehot_state_reg_0_536fb89
  reg recovered_7_q = 1'b0;
  assign esc_FSM_onehot_state_reg_n_0__0_ee5cad1 = recovered_7_q;
  wire recovered_7_reset = ((SS)) && ((SS) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((SS) === 1'bx) && (recovered_7_q == 1'b0))) recovered_7_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_7_q == (esc_FSM_onehot_state_0__i_1__1_n_0_1dbc5bf)))) recovered_7_q <= (esc_FSM_onehot_state_0__i_1__1_n_0_1dbc5bf);
  end

  // Reconstructed FDRE: esc_FSM_onehot_state_reg_1_070266a
  reg recovered_8_q = 1'b0;
  assign p_0_in8_in = recovered_8_q;
  wire recovered_8_reset = ((SS)) && ((SS) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_8_reset || (((SS) === 1'bx) && (recovered_8_q == 1'b0))) recovered_8_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_8_q == (esc_FSM_onehot_state_1__i_1__1_n_0_dfdfbcf)))) recovered_8_q <= (esc_FSM_onehot_state_1__i_1__1_n_0_dfdfbcf);
  end

  // Reconstructed FDSE: esc_FSM_onehot_state_reg_3_5c113c4
  reg recovered_9_q = 1'b1;
  assign p_9_in = recovered_9_q;
  wire recovered_9_reset = ((SS)) && ((SS) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_9_reset || (((SS) === 1'bx) && (recovered_9_q == 1'b1))) recovered_9_q <= 1'b1;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_9_q == (esc_FSM_onehot_state_3__i_2__1_n_0_f7a3d37)))) recovered_9_q <= (esc_FSM_onehot_state_3__i_2__1_n_0_f7a3d37);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed FDRE: areset_d1_reg
  reg recovered_12_q = 1'b0;
  assign SS = recovered_12_q;
  wire recovered_12_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_12_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_12_q == 1'b0))) recovered_12_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_12_q == (reset)))) recovered_12_q <= (reset);
  end

  // Reconstructed LUT1: esc_gen_rep_0__fifoaddr_0__i_1__0_c3b534a
  assign esc_gen_rep_0__fifoaddr_0__i_1__0_n_0_f1aea08 = ~(esc_gen_rep_0__fifoaddr_reg_95ecfab [0]);

  // Reconstructed LUT3: esc_gen_rep_0__fifoaddr_1__i_1__0_a34c1fa
  assign esc_gen_rep_0__fifoaddr_1__i_1__0_n_0_6d9bc7e = ((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (~(push)) : (push))) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (push) : (~(push)))));

  // Reconstructed LUT4: esc_gen_rep_0__fifoaddr_2__i_1__1_e099e36
  assign esc_gen_rep_0__fifoaddr_2__i_1__1_n_0_e61c8b2 = ((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (((push) ? (~(esc_gen_rep_0__fifoaddr_reg_95ecfab [2])) : (esc_gen_rep_0__fifoaddr_reg_95ecfab [2]))) : (esc_gen_rep_0__fifoaddr_reg_95ecfab [2]))) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (esc_gen_rep_0__fifoaddr_reg_95ecfab [2]) : (((push) ? (esc_gen_rep_0__fifoaddr_reg_95ecfab [2]) : (~(esc_gen_rep_0__fifoaddr_reg_95ecfab [2])))))));

  // Reconstructed LUT6: esc_gen_rep_0__fifoaddr_3__i_1__1_20a3516
  assign esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f = ((s_ready_i_reg_0) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_ready_d) ? (~(esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6)) : (((s_axi_awvalid) ? (esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) : (~(esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6)))))) : (((m_ready_d) ? (1'b0) : (((s_axi_awvalid) ? (((p_0_in8_in) ? (esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) : (1'b0))) : (1'b0))))))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((m_ready_d) ? (~(esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6)) : (((s_axi_awvalid) ? (((p_0_in8_in) ? (1'b1) : (~(esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6)))) : (~(esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6)))))) : (((m_ready_d) ? (1'b0) : (((s_axi_awvalid) ? (((p_0_in8_in) ? (esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) : (1'b0))) : (1'b0))))))));

  // Reconstructed LUT5: esc_gen_rep_0__fifoaddr_3__i_2__0_a8ea4fb
  assign esc_gen_rep_0__fifoaddr_3__i_2__0_n_0_3209ca4 = ((push) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [2]) ? (~(esc_gen_rep_0__fifoaddr_reg_95ecfab [3])) : (esc_gen_rep_0__fifoaddr_reg_95ecfab [3]))) : (esc_gen_rep_0__fifoaddr_reg_95ecfab [3]))) : (esc_gen_rep_0__fifoaddr_reg_95ecfab [3]))) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (esc_gen_rep_0__fifoaddr_reg_95ecfab [3]) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (esc_gen_rep_0__fifoaddr_reg_95ecfab [3]) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [2]) ? (esc_gen_rep_0__fifoaddr_reg_95ecfab [3]) : (~(esc_gen_rep_0__fifoaddr_reg_95ecfab [3])))))))));

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_0_2da314e
  reg recovered_18_q = 1'b1;
  assign esc_gen_rep_0__fifoaddr_reg_95ecfab [0] = recovered_18_q;
  wire recovered_18_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((reset) === 1'bx) && (recovered_18_q == 1'b1))) recovered_18_q <= 1'b1;
    else if ((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) || ((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) === 1'bz) || (((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) === 1'bx) && (recovered_18_q == (esc_gen_rep_0__fifoaddr_0__i_1__0_n_0_f1aea08)))) recovered_18_q <= (esc_gen_rep_0__fifoaddr_0__i_1__0_n_0_f1aea08);
  end

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_1_9ffca33
  reg recovered_19_q = 1'b1;
  assign esc_gen_rep_0__fifoaddr_reg_95ecfab [1] = recovered_19_q;
  wire recovered_19_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((reset) === 1'bx) && (recovered_19_q == 1'b1))) recovered_19_q <= 1'b1;
    else if ((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) || ((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) === 1'bz) || (((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) === 1'bx) && (recovered_19_q == (esc_gen_rep_0__fifoaddr_1__i_1__0_n_0_6d9bc7e)))) recovered_19_q <= (esc_gen_rep_0__fifoaddr_1__i_1__0_n_0_6d9bc7e);
  end

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_2_19f7d82
  reg recovered_20_q = 1'b1;
  assign esc_gen_rep_0__fifoaddr_reg_95ecfab [2] = recovered_20_q;
  wire recovered_20_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((reset) === 1'bx) && (recovered_20_q == 1'b1))) recovered_20_q <= 1'b1;
    else if ((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) || ((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) === 1'bz) || (((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) === 1'bx) && (recovered_20_q == (esc_gen_rep_0__fifoaddr_2__i_1__1_n_0_e61c8b2)))) recovered_20_q <= (esc_gen_rep_0__fifoaddr_2__i_1__1_n_0_e61c8b2);
  end

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_3_53270b1
  reg recovered_21_q = 1'b1;
  assign esc_gen_rep_0__fifoaddr_reg_95ecfab [3] = recovered_21_q;
  wire recovered_21_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_21_reset || (((reset) === 1'bx) && (recovered_21_q == 1'b1))) recovered_21_q <= 1'b1;
    else if ((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) || ((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) === 1'bz) || (((esc_gen_rep_0__fifoaddr_3__i_1__1_n_0_6b0e21f) === 1'bx) && (recovered_21_q == (esc_gen_rep_0__fifoaddr_3__i_2__0_n_0_3209ca4)))) recovered_21_q <= (esc_gen_rep_0__fifoaddr_3__i_2__0_n_0_3209ca4);
  end

  system_xbar_1_axi_data_fifo_v2_1_21_ndeep_srl esc_gen_srls_0__gen_rep_0__srl_nx1_87f4823 
       (.esc_FSM_onehot_state_reg_0_536fb89 (esc_gen_srls_0__gen_rep_0__srl_nx1_n_1_3dd95f4 ),
        .esc_FSM_onehot_state_reg_3_5c113c4 (esc_s_axi_wready_2_bad3bf1 ),
        .Q(esc_gen_rep_0__fifoaddr_reg_95ecfab ),
        .aclk(aclk),
        .esc_gen_rep_0__fifoaddr_reg_1_9ffca33 ({p_0_in8_in,esc_FSM_onehot_state_reg_n_0__0_ee5cad1 }),
        .esc_gen_rep_0__fifoaddr_reg_1__0_5d4a2a3 (s_ready_i_reg_0),
        .load_s1(load_s1),
        .m_avalid(m_avalid),
        .m_ready_d(m_ready_d),
        .m_select_enc(m_select_enc),
        .push(push),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_wlast(s_axi_wlast),
        .esc_s_axi_wlast_2_40b5096 (esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6 ),
        .s_axi_wvalid(s_axi_wvalid),
        .st_aa_awtarget_hot(st_aa_awtarget_hot));

  // Reconstructed LUT2: esc_m_axi_wvalid_0__INST_0_i_4_678140b
  assign m_valid_i_reg_0 = ((s_axi_wvalid) ? (~(m_avalid)) : (1'b1));

  // Reconstructed LUT5: m_valid_i_i_1__1
  assign m_valid_i_i_1__1_n_0 = ((esc_FSM_onehot_state_1__i_1__1_n_0_dfdfbcf) ? (1'b1) : (((esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) ? (((p_0_in8_in) ? (((s_axi_awvalid) ? (~(m_ready_d)) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed FDRE: m_valid_i_reg
  reg recovered_25_q = 1'b0;
  assign m_avalid = recovered_25_q;
  wire recovered_25_reset = ((SS)) && ((SS) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_25_reset || (((SS) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_25_q == (m_valid_i_i_1__1_n_0)))) recovered_25_q <= (m_valid_i_i_1__1_n_0);
  end

  // Reconstructed LUT2: esc_s_axi_wready_2__INST_0_a7a9f69
  assign s_axi_wready = ((esc_s_axi_wready_2_bad3bf1) ? (m_avalid) : (1'b0));

  // Reconstructed LUT6: s_ready_i_i_1__1
  assign s_ready_i_i_1__1_n_0 = ((s_ready_i_reg_0) ? (((push) ? (((s_ready_i_i_2__1_n_0) ? (1'b1) : (((SS) ? (1'b1) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (~(esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6)) : (1'b0))))))) : (1'b1))) : (((SS) ? (1'b1) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (~(esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6)) : (1'b0))))));

  // Reconstructed LUT4: s_ready_i_i_2__1
  assign s_ready_i_i_2__1_n_0 = ((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (1'b1) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [2]) ? (~(esc_gen_rep_0__fifoaddr_reg_95ecfab [3])) : (1'b1))) : (1'b1))));

  // Reconstructed FDRE: s_ready_i_reg
  reg recovered_29_q = 1'b0;
  assign s_ready_i_reg_0 = recovered_29_q;
  wire recovered_29_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_29_reset || (((reset) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_29_q == (s_ready_i_i_1__1_n_0)))) recovered_29_q <= (s_ready_i_i_1__1_n_0);
  end

  // Reconstructed LUT6: esc_storage_data1_0__i_2__1_03ce1d7
  assign load_s1 = ((m_ready_d) ? (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (~(esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6)) : (1'b0))) : (((s_axi_awvalid) ? (((p_0_in8_in) ? (((esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) ? (p_9_in) : (1'b1))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (((esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6) ? (p_9_in) : (1'b1))) : (p_9_in))))) : (((esc_FSM_onehot_state_reg_n_0__0_ee5cad1) ? (~(esc_gen_srls_0__gen_rep_0__srl_nx1_n_2_bc169a6)) : (1'b0))))));

  // Reconstructed FDRE: esc_storage_data1_reg_0_3e8f598
  reg recovered_31_q = 1'b0;
  assign m_select_enc = recovered_31_q;
  wire recovered_31_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_31_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_31_q == 1'b0))) recovered_31_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_31_q == (esc_gen_srls_0__gen_rep_0__srl_nx1_n_1_3dd95f4)))) recovered_31_q <= (esc_gen_srls_0__gen_rep_0__srl_nx1_n_1_3dd95f4);
  end

endmodule

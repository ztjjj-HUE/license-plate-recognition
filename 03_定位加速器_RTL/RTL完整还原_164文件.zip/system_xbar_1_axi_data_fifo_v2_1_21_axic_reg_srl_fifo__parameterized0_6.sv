// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_data_fifo_v2_1_21_axic_reg_srl_fifo__parameterized0_6
   (s_ready_i_reg_0,
    esc_storage_data1_reg_0__0_22cc170 ,
    s_axi_wready,
    esc_storage_data1_reg_0__1_c56c57a ,
    esc_storage_data1_reg_0__2_ff09e73 ,
    aclk,
    areset_d1,
    reset,
    s_axi_awvalid,
    m_ready_d,
    esc_storage_data1_reg_0__3_4bcca58 ,
    esc_s_axi_wready_1_4923277 ,
    s_axi_wlast,
    s_axi_wvalid,
    m_select_enc_0,
    m_select_enc_1,
    esc_m_axi_wvalid_0_57ca2b0 ,
    m_select_enc_2);
  output s_ready_i_reg_0;
  output esc_storage_data1_reg_0__0_22cc170 ;
  output [0:0]s_axi_wready;
  output esc_storage_data1_reg_0__1_c56c57a ;
  output esc_storage_data1_reg_0__2_ff09e73 ;
  input aclk;
  input areset_d1;
  input reset;
  input [0:0]s_axi_awvalid;
  input [0:0]m_ready_d;
  input [0:0]esc_storage_data1_reg_0__3_4bcca58 ;
  input esc_s_axi_wready_1_4923277 ;
  input [0:0]s_axi_wlast;
  input [0:0]s_axi_wvalid;
  input [1:0]m_select_enc_0;
  input m_select_enc_1;
  input esc_m_axi_wvalid_0_57ca2b0 ;
  input [1:0]m_select_enc_2;

  wire esc_m_axi_wvalid_0_57ca2b0 ;
  wire [1:0]m_select_enc_0;
  wire m_select_enc_1;
  wire [1:0]m_select_enc_2;
  wire esc_storage_data1_reg_0__1_c56c57a ;
  wire esc_storage_data1_reg_0__2_ff09e73 ;

  // Reconstructed LUT4: esc_gen_primitive_shifter_gen_srls_0__srl_inst_i_5_e8f9c5d
  assign esc_storage_data1_reg_0__2_ff09e73 = ((esc_m_axi_wvalid_0_57ca2b0) ? (1'b0) : (((m_select_enc_1) ? (((m_select_enc_2[0]) ? (1'b0) : (m_select_enc_2[1]))) : (1'b0))));

  // Reconstructed LUT4: esc_m_axi_wvalid_0__INST_0_i_1_f1439a6
  assign esc_storage_data1_reg_0__1_c56c57a = ((esc_m_axi_wvalid_0_57ca2b0) ? (1'b0) : (((m_select_enc_1) ? (1'b0) : (((m_select_enc_0[0]) ? (1'b0) : (m_select_enc_0[1]))))));

endmodule

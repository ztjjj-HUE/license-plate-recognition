// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_data_fifo_v2_1_21_axic_reg_srl_fifo__parameterized1
   (m_avalid,
    f_decoder_return,
    esc_storage_data1_reg_1__0_19392bf ,
    esc_storage_data1_reg_0__0_22cc170 ,
    Q,
    m_valid_i_reg_0,
    m_axi_wlast,
    m_axi_wstrb,
    m_axi_wdata,
    push,
    aa_wm_awgrant_enc,
    aclk,
    areset_d1,
    sa_wm_awvalid,
    m_aready,
    m_ready_d,
    esc_FSM_onehot_state_reg_1__0_2261399 ,
    p_1_in,
    esc_FSM_onehot_state_reg_1__1_f4c0b3e ,
    m_axi_wready,
    s_axi_wlast,
    D,
    reset,
    E,
    s_axi_wstrb,
    s_axi_wdata);
  output m_avalid;
  output [2:0]f_decoder_return;
  output esc_storage_data1_reg_1__0_19392bf ;
  output esc_storage_data1_reg_0__0_22cc170 ;
  output [1:0]Q;
  output m_valid_i_reg_0;
  output [0:0]m_axi_wlast;
  output [3:0]m_axi_wstrb;
  output [31:0]m_axi_wdata;
  input push;
  input [1:0]aa_wm_awgrant_enc;
  input aclk;
  input areset_d1;
  input [0:0]sa_wm_awvalid;
  input m_aready;
  input [0:0]m_ready_d;
  input [0:0]esc_FSM_onehot_state_reg_1__0_2261399 ;
  input p_1_in;
  input esc_FSM_onehot_state_reg_1__1_f4c0b3e ;
  input [0:0]m_axi_wready;
  input [2:0]s_axi_wlast;
  input [1:0]D;
  input reset;
  input [0:0]E;
  input [11:0]s_axi_wstrb;
  input [95:0]s_axi_wdata;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [1:0]D;
  wire [0:0]E;
  wire esc_FSM_onehot_state_1__i_1__2_n_0_ad0acdf ;
  wire esc_FSM_onehot_state_1__i_2__2_n_0_917036a ;
  wire [0:0]esc_FSM_onehot_state_reg_1__0_2261399 ;
  wire esc_FSM_onehot_state_reg_1__1_f4c0b3e ;
  wire [1:0]Q;
  wire [1:0]aa_wm_awgrant_enc;
  wire aclk;
  wire areset_d1;
  wire [2:0]f_decoder_return;
  wire esc_gen_rep_0__fifoaddr_0__i_1__1_n_0_7a7b7b1 ;
  wire esc_gen_rep_0__fifoaddr_1__i_1__1_n_0_482dddc ;
  wire esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46 ;
  wire esc_gen_rep_0__fifoaddr_3__i_2__1_n_0_9e6dc75 ;
  wire [3:0]esc_gen_rep_0__fifoaddr_reg_95ecfab ;
  wire esc_gen_srls_0__gen_rep_0__srl_nx1_n_0_7b42e4e ;
  wire esc_gen_srls_0__gen_rep_1__srl_nx1_n_2_f364b1e ;
  wire load_s1;
  wire m_aready;
  wire m_avalid;
  wire [31:0]m_axi_wdata;
  wire [0:0]m_axi_wlast;
  wire [0:0]m_axi_wready;
  wire [3:0]m_axi_wstrb;
  wire [0:0]m_ready_d;
  wire m_valid_i;
  wire m_valid_i_i_1__2_n_0;
  wire m_valid_i_reg_0;
  wire p_1_in;
  wire p_7_in;
  wire push;
  wire reset;
  wire [95:0]s_axi_wdata;
  wire [2:0]s_axi_wlast;
  wire [11:0]s_axi_wstrb;
  wire [0:0]sa_wm_awvalid;
  wire state2;
  wire esc_storage_data1_reg_0__0_22cc170 ;
  wire esc_storage_data1_reg_1__0_19392bf ;
  wire [2:0]esc_NLW_gen_srls_0__gen_rep_1__srl_nx1_s_axi_wlast_UNCONNECTED_ba82de1 ;

  // Reconstructed LUT5: esc_FSM_onehot_state_1__i_1__2_af80984
  assign esc_FSM_onehot_state_1__i_1__2_n_0_ad0acdf = ((p_7_in) ? (((p_1_in) ? (esc_FSM_onehot_state_1__i_2__2_n_0_917036a) : (((esc_FSM_onehot_state_reg_1__0_2261399) ? (((m_ready_d) ? (esc_FSM_onehot_state_1__i_2__2_n_0_917036a) : (1'b1))) : (esc_FSM_onehot_state_1__i_2__2_n_0_917036a))))) : (esc_FSM_onehot_state_1__i_2__2_n_0_917036a));

  // Reconstructed LUT6: esc_FSM_onehot_state_1__i_2__2_f57e90a
  assign esc_FSM_onehot_state_1__i_2__2_n_0_917036a = ((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (1'b0) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (1'b0) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [2]) ? (1'b0) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [3]) ? (1'b0) : (((esc_FSM_onehot_state_reg_1__1_f4c0b3e) ? (Q[0]) : (1'b0))))))))));

  // Reconstructed LUT6: esc_FSM_onehot_state_3__i_1__2_1994cf2
  assign m_valid_i = ((p_7_in) ? (((state2) ? (((Q[0]) ? (((sa_wm_awvalid) ? (1'b1) : (m_aready))) : (((Q[1]) ? (((sa_wm_awvalid) ? (1'b1) : (m_aready))) : (sa_wm_awvalid))))) : (((Q[1]) ? (((sa_wm_awvalid) ? (1'b1) : (m_aready))) : (sa_wm_awvalid))))) : (((state2) ? (((Q[0]) ? (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (m_aready))) : (((sa_wm_awvalid) ? (1'b0) : (m_aready))))) : (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (m_aready))) : (1'b0))))) : (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (m_aready))) : (1'b0))))));

  // Reconstructed LUT4: esc_FSM_onehot_state_3__i_4_54f286e
  assign state2 = ((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (1'b0) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (1'b0) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [2]) ? (1'b0) : (~(esc_gen_rep_0__fifoaddr_reg_95ecfab [3])))))));

  // Reconstructed FDRE: esc_FSM_onehot_state_reg_0_536fb89
  reg recovered_5_q = 1'b0;
  assign Q[0] = recovered_5_q;
  wire recovered_5_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((areset_d1) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_5_q == (D[0])))) recovered_5_q <= (D[0]);
  end

  // Reconstructed FDRE: esc_FSM_onehot_state_reg_1_070266a
  reg recovered_6_q = 1'b0;
  assign Q[1] = recovered_6_q;
  wire recovered_6_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((areset_d1) === 1'bx) && (recovered_6_q == 1'b0))) recovered_6_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_6_q == (esc_FSM_onehot_state_1__i_1__2_n_0_ad0acdf)))) recovered_6_q <= (esc_FSM_onehot_state_1__i_1__2_n_0_ad0acdf);
  end

  // Reconstructed FDSE: esc_FSM_onehot_state_reg_3_5c113c4
  reg recovered_7_q = 1'b1;
  assign p_7_in = recovered_7_q;
  wire recovered_7_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_7_reset || (((areset_d1) === 1'bx) && (recovered_7_q == 1'b1))) recovered_7_q <= 1'b1;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_7_q == (D[1])))) recovered_7_q <= (D[1]);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT1: esc_gen_rep_0__fifoaddr_0__i_1__1_2bb2036
  assign esc_gen_rep_0__fifoaddr_0__i_1__1_n_0_7a7b7b1 = ~(esc_gen_rep_0__fifoaddr_reg_95ecfab [0]);

  // Reconstructed LUT3: esc_gen_rep_0__fifoaddr_1__i_1__1_d6e547d
  assign esc_gen_rep_0__fifoaddr_1__i_1__1_n_0_482dddc = ((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (((push) ? (~(esc_gen_rep_0__fifoaddr_reg_95ecfab [0])) : (esc_gen_rep_0__fifoaddr_reg_95ecfab [0]))) : (((push) ? (esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) : (~(esc_gen_rep_0__fifoaddr_reg_95ecfab [0])))));

  // Reconstructed LUT4: esc_gen_rep_0__fifoaddr_2__i_1_7a332c8
  assign esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46 = ((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [2]) ? (((push) ? (~(esc_gen_rep_0__fifoaddr_reg_95ecfab [0])) : (1'b1))) : (((push) ? (esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) : (1'b0))))) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [2]) ? (((push) ? (1'b1) : (esc_gen_rep_0__fifoaddr_reg_95ecfab [0]))) : (((push) ? (1'b0) : (~(esc_gen_rep_0__fifoaddr_reg_95ecfab [0])))))));

  // Reconstructed LUT5: esc_gen_rep_0__fifoaddr_3__i_2__1_3120d59
  assign esc_gen_rep_0__fifoaddr_3__i_2__1_n_0_9e6dc75 = ((esc_gen_rep_0__fifoaddr_reg_95ecfab [2]) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [3]) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (~(push)) : (1'b1))) : (1'b1))) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (push) : (1'b0))) : (1'b0))))) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [3]) ? (((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (1'b1) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (1'b1) : (push))))) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [1]) ? (1'b0) : (((esc_gen_rep_0__fifoaddr_reg_95ecfab [0]) ? (1'b0) : (~(push)))))))));

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_0_2da314e
  reg recovered_14_q = 1'b1;
  assign esc_gen_rep_0__fifoaddr_reg_95ecfab [0] = recovered_14_q;
  wire recovered_14_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_14_reset || (((reset) === 1'bx) && (recovered_14_q == 1'b1))) recovered_14_q <= 1'b1;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_14_q == (esc_gen_rep_0__fifoaddr_0__i_1__1_n_0_7a7b7b1)))) recovered_14_q <= (esc_gen_rep_0__fifoaddr_0__i_1__1_n_0_7a7b7b1);
  end

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_1_9ffca33
  reg recovered_15_q = 1'b1;
  assign esc_gen_rep_0__fifoaddr_reg_95ecfab [1] = recovered_15_q;
  wire recovered_15_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_15_reset || (((reset) === 1'bx) && (recovered_15_q == 1'b1))) recovered_15_q <= 1'b1;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_15_q == (esc_gen_rep_0__fifoaddr_1__i_1__1_n_0_482dddc)))) recovered_15_q <= (esc_gen_rep_0__fifoaddr_1__i_1__1_n_0_482dddc);
  end

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_2_19f7d82
  reg recovered_16_q = 1'b1;
  assign esc_gen_rep_0__fifoaddr_reg_95ecfab [2] = recovered_16_q;
  wire recovered_16_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_16_reset || (((reset) === 1'bx) && (recovered_16_q == 1'b1))) recovered_16_q <= 1'b1;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_16_q == (esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46)))) recovered_16_q <= (esc_gen_rep_0__fifoaddr_2__i_1_n_0_db6fa46);
  end

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_3_53270b1
  reg recovered_17_q = 1'b1;
  assign esc_gen_rep_0__fifoaddr_reg_95ecfab [3] = recovered_17_q;
  wire recovered_17_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_17_reset || (((reset) === 1'bx) && (recovered_17_q == 1'b1))) recovered_17_q <= 1'b1;
    else if ((E) || ((E) === 1'bz) || (((E) === 1'bx) && (recovered_17_q == (esc_gen_rep_0__fifoaddr_3__i_2__1_n_0_9e6dc75)))) recovered_17_q <= (esc_gen_rep_0__fifoaddr_3__i_2__1_n_0_9e6dc75);
  end

  system_xbar_1_axi_data_fifo_v2_1_21_ndeep_srl_12 esc_gen_srls_0__gen_rep_0__srl_nx1_87f4823 
       (.esc_FSM_onehot_state_reg_0_536fb89 (esc_gen_srls_0__gen_rep_0__srl_nx1_n_0_7b42e4e ),
        .load_s1(load_s1),
        .esc_storage_data1_reg_0__0_22cc170 (esc_storage_data1_reg_0__0_22cc170 ));
  system_xbar_1_axi_data_fifo_v2_1_21_ndeep_srl_13 esc_gen_srls_0__gen_rep_1__srl_nx1_8532c48 
       (.esc_FSM_onehot_state_reg_0_536fb89 (esc_gen_srls_0__gen_rep_1__srl_nx1_n_2_f364b1e ),
        .Q(esc_gen_rep_0__fifoaddr_reg_95ecfab ),
        .aa_wm_awgrant_enc(aa_wm_awgrant_enc[1]),
        .aclk(aclk),
        .f_decoder_return(f_decoder_return[0]),
        .load_s1(load_s1),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wlast_0_sp_1(esc_storage_data1_reg_0__0_22cc170 ),
        .push(push),
        .s_axi_wlast({s_axi_wlast[2],esc_NLW_gen_srls_0__gen_rep_1__srl_nx1_s_axi_wlast_UNCONNECTED_ba82de1 [1],s_axi_wlast[0]}),
        .esc_storage_data1_reg_1_261ad78 (esc_storage_data1_reg_1__0_19392bf ),
        .esc_storage_data1_reg_1__0_19392bf (Q[0]));

  // Reconstructed LUT4: esc_m_axi_wdata_0__INST_0_4de4066
  assign m_axi_wdata[0] = ((s_axi_wdata[64]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[0]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[0]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_10__INST_0_2f1f0c5
  assign m_axi_wdata[10] = ((s_axi_wdata[74]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[10]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[10]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_11__INST_0_e491e76
  assign m_axi_wdata[11] = ((s_axi_wdata[75]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[11]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[11]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_12__INST_0_a55ad3d
  assign m_axi_wdata[12] = ((s_axi_wdata[76]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[12]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[12]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_13__INST_0_138e487
  assign m_axi_wdata[13] = ((s_axi_wdata[77]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[13]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[13]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_14__INST_0_aee325a
  assign m_axi_wdata[14] = ((s_axi_wdata[78]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[14]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[14]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_15__INST_0_05f2c55
  assign m_axi_wdata[15] = ((s_axi_wdata[79]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[15]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[15]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_16__INST_0_74d7104
  assign m_axi_wdata[16] = ((s_axi_wdata[80]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[16]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[16]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_17__INST_0_e01c508
  assign m_axi_wdata[17] = ((s_axi_wdata[81]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[17]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[17]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_18__INST_0_110a7f4
  assign m_axi_wdata[18] = ((s_axi_wdata[82]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[18]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[18]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_19__INST_0_59eaf91
  assign m_axi_wdata[19] = ((s_axi_wdata[83]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[19]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[19]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_1__INST_0_f522351
  assign m_axi_wdata[1] = ((s_axi_wdata[65]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[1]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[1]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_20__INST_0_f411807
  assign m_axi_wdata[20] = ((s_axi_wdata[84]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[20]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[20]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_21__INST_0_7ca2473
  assign m_axi_wdata[21] = ((s_axi_wdata[85]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[21]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[21]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_22__INST_0_2a65d7c
  assign m_axi_wdata[22] = ((s_axi_wdata[86]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[22]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[22]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_23__INST_0_9b2bac8
  assign m_axi_wdata[23] = ((s_axi_wdata[87]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[23]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[23]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_24__INST_0_4382526
  assign m_axi_wdata[24] = ((s_axi_wdata[88]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[24]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[24]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_25__INST_0_7e5fe10
  assign m_axi_wdata[25] = ((s_axi_wdata[89]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[25]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[25]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_26__INST_0_8a68474
  assign m_axi_wdata[26] = ((s_axi_wdata[90]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[26]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[26]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_27__INST_0_5c8aaac
  assign m_axi_wdata[27] = ((s_axi_wdata[91]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[27]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[27]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_28__INST_0_f106064
  assign m_axi_wdata[28] = ((s_axi_wdata[92]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[28]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[28]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_29__INST_0_6d2d8e8
  assign m_axi_wdata[29] = ((s_axi_wdata[93]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[29]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[29]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_2__INST_0_6aaf43a
  assign m_axi_wdata[2] = ((s_axi_wdata[66]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[2]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[2]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_30__INST_0_6a56d04
  assign m_axi_wdata[30] = ((s_axi_wdata[94]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[30]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[30]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_31__INST_0_e0984c2
  assign m_axi_wdata[31] = ((s_axi_wdata[95]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[31]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[31]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_3__INST_0_f57ff27
  assign m_axi_wdata[3] = ((s_axi_wdata[67]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[3]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[3]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_4__INST_0_d051596
  assign m_axi_wdata[4] = ((s_axi_wdata[68]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[4]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[4]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_5__INST_0_7a3422c
  assign m_axi_wdata[5] = ((s_axi_wdata[69]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[5]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[5]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_6__INST_0_8517102
  assign m_axi_wdata[6] = ((s_axi_wdata[70]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[6]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[6]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_7__INST_0_ed3dce0
  assign m_axi_wdata[7] = ((s_axi_wdata[71]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[7]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[7]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_8__INST_0_8f1f74d
  assign m_axi_wdata[8] = ((s_axi_wdata[72]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[8]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[8]))))));

  // Reconstructed LUT4: esc_m_axi_wdata_9__INST_0_9dce380
  assign m_axi_wdata[9] = ((s_axi_wdata[73]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wdata[9]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wdata[9]))))));

  // Reconstructed LUT4: esc_m_axi_wstrb_0__INST_0_9e62e7f
  assign m_axi_wstrb[0] = ((s_axi_wstrb[8]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wstrb[0]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wstrb[0]))))));

  // Reconstructed LUT4: esc_m_axi_wstrb_1__INST_0_d614450
  assign m_axi_wstrb[1] = ((s_axi_wstrb[9]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wstrb[1]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wstrb[1]))))));

  // Reconstructed LUT4: esc_m_axi_wstrb_2__INST_0_87c18d7
  assign m_axi_wstrb[2] = ((s_axi_wstrb[10]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wstrb[2]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wstrb[2]))))));

  // Reconstructed LUT4: esc_m_axi_wstrb_3__INST_0_8ac6c66
  assign m_axi_wstrb[3] = ((s_axi_wstrb[11]) ? (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b1) : (s_axi_wstrb[3]))))) : (((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (s_axi_wstrb[3]))))));

  // Reconstructed LUT6: m_valid_i_i_1__2
  assign m_valid_i_i_1__2_n_0 = ((p_7_in) ? (((state2) ? (((Q[0]) ? (((sa_wm_awvalid) ? (1'b1) : (m_aready))) : (sa_wm_awvalid))) : (sa_wm_awvalid))) : (((state2) ? (((Q[0]) ? (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (m_aready))) : (((sa_wm_awvalid) ? (1'b0) : (m_aready))))) : (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (1'b0))) : (1'b0))))) : (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (1'b0))) : (1'b0))))));

  // Reconstructed FDRE: m_valid_i_reg
  reg recovered_57_q = 1'b0;
  assign m_avalid = recovered_57_q;
  wire recovered_57_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_57_reset || (((areset_d1) === 1'bx) && (recovered_57_q == 1'b0))) recovered_57_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_57_q == (m_valid_i_i_1__2_n_0)))) recovered_57_q <= (m_valid_i_i_1__2_n_0);
  end

  // Reconstructed LUT2: esc_s_axi_wready_2__INST_0_i_3_5cac1ac
  assign f_decoder_return[2] = ((esc_storage_data1_reg_0__0_22cc170) ? (1'b0) : (esc_storage_data1_reg_1__0_19392bf));

  // Reconstructed LUT2: esc_s_axi_wready_2__INST_0_i_4_ebf11d6
  assign m_valid_i_reg_0 = ((m_axi_wready) ? (m_avalid) : (1'b0));

  // Reconstructed LUT5: esc_storage_data1_1__i_2_a6c152d
  assign load_s1 = ((Q[0]) ? (((m_aready) ? (1'b1) : (((sa_wm_awvalid) ? (p_7_in) : (1'b0))))) : (((m_aready) ? (((sa_wm_awvalid) ? (((Q[1]) ? (1'b1) : (p_7_in))) : (1'b0))) : (((sa_wm_awvalid) ? (p_7_in) : (1'b0))))));

  // Reconstructed FDRE: esc_storage_data1_reg_0_3e8f598
  reg recovered_61_q = 1'b0;
  assign esc_storage_data1_reg_0__0_22cc170 = recovered_61_q;
  wire recovered_61_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_61_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_61_q == 1'b0))) recovered_61_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_61_q == (esc_gen_srls_0__gen_rep_0__srl_nx1_n_0_7b42e4e)))) recovered_61_q <= (esc_gen_srls_0__gen_rep_0__srl_nx1_n_0_7b42e4e);
  end

  // Reconstructed FDRE: esc_storage_data1_reg_1_261ad78
  reg recovered_62_q = 1'b0;
  assign esc_storage_data1_reg_1__0_19392bf = recovered_62_q;
  wire recovered_62_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_62_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_62_q == 1'b0))) recovered_62_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_62_q == (esc_gen_srls_0__gen_rep_1__srl_nx1_n_2_f364b1e)))) recovered_62_q <= (esc_gen_srls_0__gen_rep_1__srl_nx1_n_2_f364b1e);
  end

endmodule

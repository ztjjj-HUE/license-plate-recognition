// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_data_fifo_v2_1_21_axic_reg_srl_fifo__parameterized2
   (A,
    m_avalid,
    Q,
    s_axi_wready,
    esc_storage_data1_reg_0__0_22cc170 ,
    esc_storage_data1_reg_0__1_c56c57a ,
    esc_storage_data1_reg_1__0_19392bf ,
    esc_storage_data1_reg_1__1_4c7e429 ,
    esc_storage_data1_reg_0__2_ff09e73 ,
    esc_FSM_onehot_gen_axi_write_cs_reg_1_dc473f5 ,
    wm_mr_wlast_1,
    esc_storage_data1_reg_1__2_7868a8c ,
    push,
    aa_wm_awgrant_enc,
    aclk,
    reset,
    esc_gen_rep_0__fifoaddr_reg_0__0_fd46e5a ,
    areset_d1,
    m_aready,
    esc_FSM_onehot_state_reg_1__0_2261399 ,
    m_avalid_0,
    m_select_enc_1,
    f_decoder_return,
    esc_s_axi_wready_2_bad3bf1 ,
    m_select_enc_2,
    m_select_enc_3,
    sa_wm_awvalid,
    wm_mr_wvalid_1,
    esc_gen_axi_s_axi_bvalid_i_reg_1e6dfb5 ,
    mi_wready_1,
    s_axi_wlast,
    D);
  output [0:0]A;
  output m_avalid;
  output [2:0]Q;
  output [0:0]s_axi_wready;
  output esc_storage_data1_reg_0__0_22cc170 ;
  output esc_storage_data1_reg_0__1_c56c57a ;
  output esc_storage_data1_reg_1__0_19392bf ;
  output esc_storage_data1_reg_1__1_4c7e429 ;
  output esc_storage_data1_reg_0__2_ff09e73 ;
  output esc_FSM_onehot_gen_axi_write_cs_reg_1_dc473f5 ;
  output wm_mr_wlast_1;
  output esc_storage_data1_reg_1__2_7868a8c ;
  input push;
  input [1:0]aa_wm_awgrant_enc;
  input aclk;
  input reset;
  input esc_gen_rep_0__fifoaddr_reg_0__0_fd46e5a ;
  input areset_d1;
  input m_aready;
  input esc_FSM_onehot_state_reg_1__0_2261399 ;
  input m_avalid_0;
  input m_select_enc_1;
  input [2:0]f_decoder_return;
  input esc_s_axi_wready_2_bad3bf1 ;
  input m_select_enc_2;
  input m_select_enc_3;
  input [0:0]sa_wm_awvalid;
  input wm_mr_wvalid_1;
  input esc_gen_axi_s_axi_bvalid_i_reg_1e6dfb5 ;
  input mi_wready_1;
  input [2:0]s_axi_wlast;
  input [1:0]D;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire [0:0]A;
  wire [1:0]D;
  wire esc_FSM_onehot_gen_axi_write_cs_reg_1_dc473f5 ;
  wire esc_FSM_onehot_state_1__i_1__3_n_0_693d909 ;
  wire esc_FSM_onehot_state_reg_1__0_2261399 ;
  wire [2:0]Q;
  wire S_WREADY0;
  wire [1:0]aa_wm_awgrant_enc;
  wire aclk;
  wire areset_d1;
  wire [2:0]f_decoder_return;
  wire [1:1]fifoaddr;
  wire esc_gen_axi_s_axi_bvalid_i_reg_1e6dfb5 ;
  wire esc_gen_rep_0__fifoaddr_1__i_1__2_n_0_dc63835 ;
  wire esc_gen_rep_0__fifoaddr_reg_0__0_fd46e5a ;
  wire esc_gen_srls_0__gen_rep_0__srl_nx1_n_0_7b42e4e ;
  wire esc_gen_srls_0__gen_rep_1__srl_nx1_n_0_bd865db ;
  wire load_s1;
  wire m_aready;
  wire m_avalid;
  wire m_avalid_0;
  wire m_select_enc_1;
  wire m_select_enc_3;
  wire m_valid_i;
  wire m_valid_i_i_1__3_n_0;
  wire mi_wready_1;
  wire push;
  wire reset;
  wire [2:0]s_axi_wlast;
  wire [0:0]s_axi_wready;
  wire esc_s_axi_wready_2_bad3bf1 ;
  wire [0:0]sa_wm_awvalid;
  wire state2;
  wire esc_storage_data1_reg_0__0_22cc170 ;
  wire esc_storage_data1_reg_0__1_c56c57a ;
  wire esc_storage_data1_reg_0__2_ff09e73 ;
  wire esc_storage_data1_reg_1__0_19392bf ;
  wire esc_storage_data1_reg_1__2_7868a8c ;
  wire wm_mr_wlast_1;
  wire wm_mr_wvalid_1;

  // Reconstructed LUT6: esc_FSM_onehot_state_1__i_1__3_c7985a3
  assign esc_FSM_onehot_state_1__i_1__3_n_0_693d909 = ((esc_FSM_onehot_state_reg_1__0_2261399) ? (1'b1) : (((push) ? (1'b0) : (((A) ? (1'b0) : (((fifoaddr) ? (1'b0) : (((Q[0]) ? (m_aready) : (1'b0))))))))));

  // Reconstructed LUT6: esc_FSM_onehot_state_3__i_1__3_286e429
  assign m_valid_i = ((Q[2]) ? (((state2) ? (((Q[0]) ? (((sa_wm_awvalid) ? (1'b1) : (m_aready))) : (((Q[1]) ? (((sa_wm_awvalid) ? (1'b1) : (m_aready))) : (sa_wm_awvalid))))) : (((Q[1]) ? (((sa_wm_awvalid) ? (1'b1) : (m_aready))) : (sa_wm_awvalid))))) : (((state2) ? (((Q[0]) ? (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (m_aready))) : (((sa_wm_awvalid) ? (1'b0) : (m_aready))))) : (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (m_aready))) : (1'b0))))) : (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (m_aready))) : (1'b0))))));

  // Reconstructed LUT2: esc_FSM_onehot_state_3__i_4__0_23fc16a
  assign state2 = ((fifoaddr) ? (1'b0) : (~(A)));

  // Reconstructed FDRE: esc_FSM_onehot_state_reg_0_536fb89
  reg recovered_4_q = 1'b0;
  assign Q[0] = recovered_4_q;
  wire recovered_4_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_4_reset || (((areset_d1) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_4_q == (D[0])))) recovered_4_q <= (D[0]);
  end

  // Reconstructed FDRE: esc_FSM_onehot_state_reg_1_070266a
  reg recovered_5_q = 1'b0;
  assign Q[1] = recovered_5_q;
  wire recovered_5_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_5_reset || (((areset_d1) === 1'bx) && (recovered_5_q == 1'b0))) recovered_5_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_5_q == (esc_FSM_onehot_state_1__i_1__3_n_0_693d909)))) recovered_5_q <= (esc_FSM_onehot_state_1__i_1__3_n_0_693d909);
  end

  // Reconstructed FDSE: esc_FSM_onehot_state_reg_3_5c113c4
  reg recovered_6_q = 1'b1;
  assign Q[2] = recovered_6_q;
  wire recovered_6_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_6_reset || (((areset_d1) === 1'bx) && (recovered_6_q == 1'b1))) recovered_6_q <= 1'b1;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_6_q == (D[1])))) recovered_6_q <= (D[1]);
  end

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT3: esc_gen_axi_s_axi_wready_i_i_2_12e5647
  assign esc_FSM_onehot_gen_axi_write_cs_reg_1_dc473f5 = ((esc_gen_axi_s_axi_bvalid_i_reg_1e6dfb5) ? (((wm_mr_wvalid_1) ? (wm_mr_wlast_1) : (1'b0))) : (1'b0));

  // Reconstructed LUT4: esc_gen_primitive_shifter_gen_srls_0__srl_inst_i_4_4057f78
  assign wm_mr_wlast_1 = ((esc_storage_data1_reg_1__0_19392bf) ? (((esc_storage_data1_reg_0__1_c56c57a) ? (1'b0) : (s_axi_wlast[2]))) : (((esc_storage_data1_reg_0__1_c56c57a) ? (1'b0) : (s_axi_wlast[0]))));

  // Reconstructed LUT2: esc_gen_primitive_shifter_gen_srls_0__srl_inst_i_6_f3036ca
  assign esc_storage_data1_reg_1__2_7868a8c = ((esc_storage_data1_reg_0__1_c56c57a) ? (1'b0) : (~(esc_storage_data1_reg_1__0_19392bf)));

  // Reconstructed LUT5: esc_gen_rep_0__fifoaddr_1__i_1__2_0467584
  assign esc_gen_rep_0__fifoaddr_1__i_1__2_n_0_dc63835 = ((fifoaddr) ? (((push) ? (((A) ? (((Q[0]) ? (m_aready) : (1'b0))) : (1'b1))) : (((A) ? (1'b1) : (((Q[0]) ? (~(m_aready)) : (1'b1))))))) : (((push) ? (((A) ? (((Q[0]) ? (~(m_aready)) : (1'b1))) : (1'b0))) : (((A) ? (1'b0) : (((Q[0]) ? (m_aready) : (1'b0))))))));

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_0_2da314e
  reg recovered_13_q = 1'b1;
  assign A = recovered_13_q;
  wire recovered_13_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_13_reset || (((reset) === 1'bx) && (recovered_13_q == 1'b1))) recovered_13_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_13_q == (esc_gen_rep_0__fifoaddr_reg_0__0_fd46e5a)))) recovered_13_q <= (esc_gen_rep_0__fifoaddr_reg_0__0_fd46e5a);
  end

  // Reconstructed FDSE: esc_gen_rep_0__fifoaddr_reg_1_9ffca33
  reg recovered_14_q = 1'b1;
  assign fifoaddr = recovered_14_q;
  wire recovered_14_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_14_reset || (((reset) === 1'bx) && (recovered_14_q == 1'b1))) recovered_14_q <= 1'b1;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_14_q == (esc_gen_rep_0__fifoaddr_1__i_1__2_n_0_dc63835)))) recovered_14_q <= (esc_gen_rep_0__fifoaddr_1__i_1__2_n_0_dc63835);
  end

  system_xbar_1_axi_data_fifo_v2_1_21_ndeep_srl__parameterized2 esc_gen_srls_0__gen_rep_0__srl_nx1_87f4823 
       (.esc_FSM_onehot_state_reg_0_536fb89 (esc_gen_srls_0__gen_rep_0__srl_nx1_n_0_7b42e4e ),
        .load_s1(load_s1),
        .esc_storage_data1_reg_0__0_22cc170 (esc_storage_data1_reg_0__1_c56c57a ));
  system_xbar_1_axi_data_fifo_v2_1_21_ndeep_srl__parameterized2_9 esc_gen_srls_0__gen_rep_1__srl_nx1_8532c48 
       (.esc_FSM_onehot_state_reg_0_536fb89 (esc_gen_srls_0__gen_rep_1__srl_nx1_n_0_bd865db ),
        .Q(Q[0]),
        .aa_wm_awgrant_enc(aa_wm_awgrant_enc[1]),
        .aclk(aclk),
        .fifoaddr(fifoaddr),
        .load_s1(load_s1),
        .push(push),
        .esc_storage_data1_reg_1_261ad78 (A),
        .esc_storage_data1_reg_1__0_19392bf (esc_storage_data1_reg_1__0_19392bf ));

  // Reconstructed LUT6: m_valid_i_i_1__3
  assign m_valid_i_i_1__3_n_0 = ((Q[2]) ? (((state2) ? (((Q[0]) ? (((sa_wm_awvalid) ? (1'b1) : (m_aready))) : (sa_wm_awvalid))) : (sa_wm_awvalid))) : (((state2) ? (((Q[0]) ? (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (m_aready))) : (((sa_wm_awvalid) ? (1'b0) : (m_aready))))) : (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (1'b0))) : (1'b0))))) : (((Q[1]) ? (((sa_wm_awvalid) ? (~(m_aready)) : (1'b0))) : (1'b0))))));

  // Reconstructed FDRE: m_valid_i_reg
  reg recovered_18_q = 1'b0;
  assign m_avalid = recovered_18_q;
  wire recovered_18_reset = ((areset_d1)) && ((areset_d1) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((areset_d1) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((m_valid_i) || ((m_valid_i) === 1'bz) || (((m_valid_i) === 1'bx) && (recovered_18_q == (m_valid_i_i_1__3_n_0)))) recovered_18_q <= (m_valid_i_i_1__3_n_0);
  end

  // Reconstructed LUT2: esc_s_axi_wready_0__INST_0_c198ae5
  assign s_axi_wready = ((m_avalid_0) ? (esc_storage_data1_reg_0__0_22cc170) : (1'b0));

  // Reconstructed LUT6: esc_s_axi_wready_0__INST_0_i_1_5b87663
  assign esc_storage_data1_reg_0__0_22cc170 = ((esc_s_axi_wready_2_bad3bf1) ? (((f_decoder_return[0]) ? (((m_select_enc_1) ? (((S_WREADY0) ? (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (~(esc_storage_data1_reg_0__1_c56c57a)))) : (1'b0))) : (1'b1))) : (((m_select_enc_1) ? (((S_WREADY0) ? (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (~(esc_storage_data1_reg_0__1_c56c57a)))) : (1'b0))) : (1'b0))))) : (((m_select_enc_1) ? (((S_WREADY0) ? (((esc_storage_data1_reg_1__0_19392bf) ? (1'b0) : (~(esc_storage_data1_reg_0__1_c56c57a)))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_s_axi_wready_2__INST_0_i_1_835d365
  assign esc_storage_data1_reg_0__2_ff09e73 = ((esc_s_axi_wready_2_bad3bf1) ? (((f_decoder_return[2]) ? (((m_select_enc_3) ? (((S_WREADY0) ? (((esc_storage_data1_reg_1__0_19392bf) ? (~(esc_storage_data1_reg_0__1_c56c57a)) : (1'b0))) : (1'b0))) : (1'b1))) : (((m_select_enc_3) ? (((S_WREADY0) ? (((esc_storage_data1_reg_1__0_19392bf) ? (~(esc_storage_data1_reg_0__1_c56c57a)) : (1'b0))) : (1'b0))) : (1'b0))))) : (((m_select_enc_3) ? (((S_WREADY0) ? (((esc_storage_data1_reg_1__0_19392bf) ? (~(esc_storage_data1_reg_0__1_c56c57a)) : (1'b0))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT2: esc_s_axi_wready_2__INST_0_i_2_3bbb7b3
  assign S_WREADY0 = ((mi_wready_1) ? (m_avalid) : (1'b0));

  // Reconstructed LUT5: esc_storage_data1_1__i_2__0_534aa1b
  assign load_s1 = ((Q[0]) ? (((m_aready) ? (1'b1) : (((sa_wm_awvalid) ? (Q[2]) : (1'b0))))) : (((m_aready) ? (((sa_wm_awvalid) ? (((Q[1]) ? (1'b1) : (Q[2]))) : (1'b0))) : (((sa_wm_awvalid) ? (Q[2]) : (1'b0))))));

  // Reconstructed FDRE: esc_storage_data1_reg_0_3e8f598
  reg recovered_24_q = 1'b0;
  assign esc_storage_data1_reg_0__1_c56c57a = recovered_24_q;
  wire recovered_24_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_24_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_24_q == (esc_gen_srls_0__gen_rep_0__srl_nx1_n_0_7b42e4e)))) recovered_24_q <= (esc_gen_srls_0__gen_rep_0__srl_nx1_n_0_7b42e4e);
  end

  // Reconstructed FDRE: esc_storage_data1_reg_1_261ad78
  reg recovered_25_q = 1'b0;
  assign esc_storage_data1_reg_1__0_19392bf = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_25_q == (esc_gen_srls_0__gen_rep_1__srl_nx1_n_0_bd865db)))) recovered_25_q <= (esc_gen_srls_0__gen_rep_1__srl_nx1_n_0_bd865db);
  end

endmodule

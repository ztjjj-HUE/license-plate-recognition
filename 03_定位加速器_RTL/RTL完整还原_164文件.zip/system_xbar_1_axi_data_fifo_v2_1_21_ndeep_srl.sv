// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_data_fifo_v2_1_21_ndeep_srl
   (push,
    esc_FSM_onehot_state_reg_0_536fb89 ,
    esc_s_axi_wlast_2_40b5096 ,
    Q,
    aclk,
    .st_aa_awtarget_hot(st_aa_awtarget_enc_2),
    esc_gen_rep_0__fifoaddr_reg_1_9ffca33 ,
    load_s1,
    m_select_enc,
    esc_gen_rep_0__fifoaddr_reg_1__0_5d4a2a3 ,
    m_ready_d,
    s_axi_awvalid,
    s_axi_wlast,
    m_avalid,
    s_axi_wvalid,
    esc_FSM_onehot_state_reg_3_5c113c4 );
  output push;
  output esc_FSM_onehot_state_reg_0_536fb89 ;
  output esc_s_axi_wlast_2_40b5096 ;
  input [3:0]Q;
  input aclk;
  input [1:0]esc_gen_rep_0__fifoaddr_reg_1_9ffca33 ;
  input load_s1;
  input m_select_enc;
  input esc_gen_rep_0__fifoaddr_reg_1__0_5d4a2a3 ;
  input [0:0]m_ready_d;
  input [0:0]s_axi_awvalid;
  input [0:0]s_axi_wlast;
  input m_avalid;
  input [0:0]s_axi_wvalid;
  input esc_FSM_onehot_state_reg_3_5c113c4 ;
  input st_aa_awtarget_enc_2;

  wire esc_FSM_onehot_state_reg_0_536fb89 ;
  wire esc_FSM_onehot_state_reg_3_5c113c4 ;
  wire [3:0]Q;
  wire aclk;
  wire [1:0]esc_gen_rep_0__fifoaddr_reg_1_9ffca33 ;
  wire esc_gen_rep_0__fifoaddr_reg_1__0_5d4a2a3 ;
  wire load_s1;
  wire m_avalid;
  wire [0:0]m_ready_d;
  wire m_select_enc;
  wire push;
  wire [0:0]s_axi_awvalid;
  wire [0:0]s_axi_wlast;
  wire esc_s_axi_wlast_2_40b5096 ;
  wire [0:0]s_axi_wvalid;
  wire st_aa_awtarget_enc_2;
  wire storage_data2;

  // Reconstructed SRL16E: esc_gen_primitive_shifter_gen_srls_0__srl_inst_44ed1e3
  reg [15:0] recovered_1_shift = 16'h0000;
  always @(posedge aclk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_1_shift <= {recovered_1_shift[14:0],st_aa_awtarget_enc_2};
  assign storage_data2 = recovered_1_shift[{Q[3],Q[2],Q[1],Q[0]}];

  // Reconstructed LUT6: esc_gen_primitive_shifter_gen_srls_0__srl_inst_i_1__1_61dac8f
  assign push = ((esc_s_axi_wlast_2_40b5096) ? (((esc_gen_rep_0__fifoaddr_reg_1_9ffca33 [1]) ? (((s_axi_awvalid) ? (~(m_ready_d)) : (1'b0))) : (((s_axi_awvalid) ? (((m_ready_d) ? (1'b0) : (((esc_gen_rep_0__fifoaddr_reg_1_9ffca33 [0]) ? (esc_gen_rep_0__fifoaddr_reg_1__0_5d4a2a3) : (1'b0))))) : (1'b0))))) : (((s_axi_awvalid) ? (((m_ready_d) ? (1'b0) : (((esc_gen_rep_0__fifoaddr_reg_1_9ffca33 [0]) ? (esc_gen_rep_0__fifoaddr_reg_1__0_5d4a2a3) : (1'b0))))) : (1'b0))));

  // Reconstructed LUT4: esc_gen_primitive_shifter_gen_srls_0__srl_inst_i_3__0_4ccb962
  assign esc_s_axi_wlast_2_40b5096 = ((esc_FSM_onehot_state_reg_3_5c113c4) ? (((s_axi_wvalid) ? (((m_avalid) ? (~(s_axi_wlast)) : (1'b1))) : (1'b1))) : (1'b1));

  // Reconstructed LUT5: esc_storage_data1_0__i_1__3_94b921c
  assign esc_FSM_onehot_state_reg_0_536fb89 = ((m_select_enc) ? (((load_s1) ? (((esc_gen_rep_0__fifoaddr_reg_1_9ffca33 [0]) ? (storage_data2) : (st_aa_awtarget_enc_2))) : (1'b1))) : (((load_s1) ? (((esc_gen_rep_0__fifoaddr_reg_1_9ffca33 [0]) ? (storage_data2) : (st_aa_awtarget_enc_2))) : (1'b0))));

endmodule

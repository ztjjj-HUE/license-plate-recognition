// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_data_fifo_v2_1_21_ndeep_srl_13
   (m_axi_wlast,
    f_decoder_return,
    esc_FSM_onehot_state_reg_0_536fb89 ,
    push,
    aa_wm_awgrant_enc,
    Q,
    aclk,
    s_axi_wlast,
    .m_axi_wlast_0_sp_1(m_axi_wlast_0_sn_1),
    esc_storage_data1_reg_1_261ad78 ,
    esc_storage_data1_reg_1__0_19392bf ,
    load_s1);
  output [0:0]m_axi_wlast;
  output [0:0]f_decoder_return;
  output esc_FSM_onehot_state_reg_0_536fb89 ;
  input push;
  input [0:0]aa_wm_awgrant_enc;
  input [3:0]Q;
  input aclk;
  input [2:0]s_axi_wlast;
  input esc_storage_data1_reg_1_261ad78 ;
  input [0:0]esc_storage_data1_reg_1__0_19392bf ;
  input load_s1;
  input m_axi_wlast_0_sn_1;

  wire esc_FSM_onehot_state_reg_0_536fb89 ;
  wire [3:0]Q;
  wire [0:0]aa_wm_awgrant_enc;
  wire aclk;
  wire [0:0]f_decoder_return;
  wire load_s1;
  wire [0:0]m_axi_wlast;
  wire m_axi_wlast_0_sn_1;
  wire push;
  wire [2:0]s_axi_wlast;
  wire esc_storage_data1_reg_1_261ad78 ;
  wire [0:0]esc_storage_data1_reg_1__0_19392bf ;
  wire [1:1]storage_data2;

  // Reconstructed SRL16E: esc_gen_primitive_shifter_gen_srls_0__srl_inst_44ed1e3
  reg [15:0] recovered_1_shift = 16'h0000;
  always @(posedge aclk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_1_shift <= {recovered_1_shift[14:0],aa_wm_awgrant_enc};
  assign storage_data2 = recovered_1_shift[{Q[3],Q[2],Q[1],Q[0]}];

  // Reconstructed LUT4: esc_m_axi_wlast_0__INST_0_2e08486
  assign m_axi_wlast = ((esc_storage_data1_reg_1_261ad78) ? (((m_axi_wlast_0_sn_1) ? (1'b0) : (s_axi_wlast[2]))) : (((m_axi_wlast_0_sn_1) ? (1'b0) : (s_axi_wlast[0]))));

  // Reconstructed LUT2: esc_m_axi_wvalid_0__INST_0_i_2_fa8c4ca
  assign f_decoder_return = ((m_axi_wlast_0_sn_1) ? (1'b0) : (~(esc_storage_data1_reg_1_261ad78)));

  // Reconstructed LUT5: esc_storage_data1_1__i_1_cc044f5
  assign esc_FSM_onehot_state_reg_0_536fb89 = ((esc_storage_data1_reg_1_261ad78) ? (((load_s1) ? (((aa_wm_awgrant_enc) ? (((esc_storage_data1_reg_1__0_19392bf) ? (storage_data2) : (1'b1))) : (((esc_storage_data1_reg_1__0_19392bf) ? (storage_data2) : (1'b0))))) : (1'b1))) : (((load_s1) ? (((aa_wm_awgrant_enc) ? (((esc_storage_data1_reg_1__0_19392bf) ? (storage_data2) : (1'b1))) : (((esc_storage_data1_reg_1__0_19392bf) ? (storage_data2) : (1'b0))))) : (1'b0))));

endmodule

// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_data_fifo_v2_1_21_ndeep_srl__parameterized0
   (push,
    esc_FSM_onehot_state_reg_0_536fb89 ,
    m_aready_1,
    st_aa_awtarget_hot,
    fifoaddr,
    aclk,
    Q,
    load_s1,
    esc_storage_data1_reg_0_3e8f598 ,
    esc_FSM_onehot_state_reg_1_070266a ,
    m_ready_d,
    s_axi_awvalid,
    s_axi_wlast,
    s_axi_wvalid,
    esc_FSM_onehot_state_reg_3_5c113c4 ,
    esc_FSM_onehot_state_reg_3__0_58ac7ab );
  output push;
  output esc_FSM_onehot_state_reg_0_536fb89 ;
  output m_aready_1;
  input [1:0]st_aa_awtarget_hot;
  input [2:0]fifoaddr;
  input aclk;
  input [1:0]Q;
  input load_s1;
  input esc_storage_data1_reg_0_3e8f598 ;
  input esc_FSM_onehot_state_reg_1_070266a ;
  input [0:0]m_ready_d;
  input [0:0]s_axi_awvalid;
  input [0:0]s_axi_wlast;
  input [0:0]s_axi_wvalid;
  input esc_FSM_onehot_state_reg_3_5c113c4 ;
  input esc_FSM_onehot_state_reg_3__0_58ac7ab ;

  wire esc_const0_a0cf646 ;
  wire esc_FSM_onehot_state_reg_0_536fb89 ;
  wire esc_FSM_onehot_state_reg_1_070266a ;
  wire esc_FSM_onehot_state_reg_3_5c113c4 ;
  wire esc_FSM_onehot_state_reg_3__0_58ac7ab ;
  wire [1:0]Q;
  wire aclk;
  wire [2:0]fifoaddr;
  wire load_s1;
  wire m_aready_1;
  wire [0:0]m_ready_d;
  wire push;
  wire [0:0]s_axi_awvalid;
  wire [0:0]s_axi_wlast;
  wire [0:0]s_axi_wvalid;
  wire [1:0]st_aa_awtarget_hot;
  wire esc_storage_data1_reg_0_3e8f598 ;
  wire storage_data2;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed SRL16E: esc_gen_primitive_shifter_gen_srls_0__srl_inst_44ed1e3
  reg [15:0] recovered_2_shift = 16'h0000;
  always @(posedge aclk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_2_shift <= {recovered_2_shift[14:0],st_aa_awtarget_hot[1]};
  assign storage_data2 = recovered_2_shift[{esc_const0_a0cf646,fifoaddr[2],fifoaddr[1],fifoaddr[0]}];

  // Reconstructed LUT6: esc_gen_primitive_shifter_gen_srls_0__srl_inst_i_1_6cdddf2
  assign push = ((s_axi_awvalid) ? (((m_ready_d) ? (1'b0) : (((Q[0]) ? (((esc_FSM_onehot_state_reg_1_070266a) ? (1'b1) : (((Q[1]) ? (~(m_aready_1)) : (1'b0))))) : (((Q[1]) ? (~(m_aready_1)) : (1'b0))))))) : (1'b0));

  // Reconstructed LUT4: esc_gen_primitive_shifter_gen_srls_0__srl_inst_i_2_f7e74f6
  assign m_aready_1 = ((esc_FSM_onehot_state_reg_3__0_58ac7ab) ? (((esc_FSM_onehot_state_reg_3_5c113c4) ? (((s_axi_wvalid) ? (s_axi_wlast) : (1'b0))) : (1'b0))) : (1'b0));

  // Reconstructed LUT5: esc_storage_data1_0__i_1__1_ecd5625
  assign esc_FSM_onehot_state_reg_0_536fb89 = ((esc_storage_data1_reg_0_3e8f598) ? (((load_s1) ? (((Q[0]) ? (storage_data2) : (st_aa_awtarget_hot[0]))) : (1'b1))) : (((load_s1) ? (((Q[0]) ? (storage_data2) : (st_aa_awtarget_hot[0]))) : (1'b0))));

endmodule

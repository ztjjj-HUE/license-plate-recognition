// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_data_fifo_v2_1_21_ndeep_srl__parameterized2
   (esc_FSM_onehot_state_reg_0_536fb89 ,
    push,
    aa_wm_awgrant_enc,
    fifoaddr,
    esc_storage_data1_reg_0_3e8f598 ,
    aclk,
    Q,
    load_s1,
    esc_storage_data1_reg_0__0_22cc170 );
  output esc_FSM_onehot_state_reg_0_536fb89 ;
  input push;
  input [0:0]aa_wm_awgrant_enc;
  input [0:0]fifoaddr;
  input esc_storage_data1_reg_0_3e8f598 ;
  input aclk;
  input [0:0]Q;
  input load_s1;
  input esc_storage_data1_reg_0__0_22cc170 ;

  wire esc_FSM_onehot_state_reg_0_536fb89 ;
  wire load_s1;
  wire esc_storage_data1_reg_0__0_22cc170 ;

  // Reconstructed LUT2: esc_storage_data1_0__i_1__0_fb59dca
  assign esc_FSM_onehot_state_reg_0_536fb89 = ((esc_storage_data1_reg_0__0_22cc170) ? (~(load_s1)) : (1'b0));

endmodule

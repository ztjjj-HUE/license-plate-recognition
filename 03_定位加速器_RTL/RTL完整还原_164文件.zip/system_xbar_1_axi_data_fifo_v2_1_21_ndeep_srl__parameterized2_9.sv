// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_data_fifo_v2_1_21_ndeep_srl__parameterized2_9
   (esc_FSM_onehot_state_reg_0_536fb89 ,
    push,
    aa_wm_awgrant_enc,
    fifoaddr,
    esc_storage_data1_reg_1_261ad78 ,
    aclk,
    Q,
    load_s1,
    esc_storage_data1_reg_1__0_19392bf );
  output esc_FSM_onehot_state_reg_0_536fb89 ;
  input push;
  input [0:0]aa_wm_awgrant_enc;
  input [0:0]fifoaddr;
  input esc_storage_data1_reg_1_261ad78 ;
  input aclk;
  input [0:0]Q;
  input load_s1;
  input esc_storage_data1_reg_1__0_19392bf ;

  wire esc_const0_a0cf646 ;
  wire esc_FSM_onehot_state_reg_0_536fb89 ;
  wire [0:0]Q;
  wire [0:0]aa_wm_awgrant_enc;
  wire aclk;
  wire [0:0]fifoaddr;
  wire load_s1;
  wire push;
  wire esc_storage_data1_reg_1_261ad78 ;
  wire esc_storage_data1_reg_1__0_19392bf ;
  wire [1:1]storage_data2;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed SRL16E: esc_gen_primitive_shifter_gen_srls_0__srl_inst_44ed1e3
  reg [15:0] recovered_2_shift = 16'h0000;
  always @(posedge aclk)
    if ((push) == 1'b1 || (push) === 1'bz) recovered_2_shift <= {recovered_2_shift[14:0],aa_wm_awgrant_enc};
  assign storage_data2 = recovered_2_shift[{esc_const0_a0cf646,esc_const0_a0cf646,fifoaddr,esc_storage_data1_reg_1_261ad78}];

  // Reconstructed LUT5: esc_storage_data1_1__i_1__0_a6a389f
  assign esc_FSM_onehot_state_reg_0_536fb89 = ((esc_storage_data1_reg_1__0_19392bf) ? (((load_s1) ? (((aa_wm_awgrant_enc) ? (((Q) ? (storage_data2) : (1'b1))) : (((Q) ? (storage_data2) : (1'b0))))) : (1'b1))) : (((load_s1) ? (((aa_wm_awgrant_enc) ? (((Q) ? (storage_data2) : (1'b1))) : (((Q) ? (storage_data2) : (1'b0))))) : (1'b0))));

endmodule

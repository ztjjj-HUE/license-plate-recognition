// Functional RTL reconstructed from the supplied Vivado structural netlist.
// Expanded registers retain INIT and logical controls; vendor GSR and SDF timing are not reproduced.
// DSP, block RAM, PS7 and bidirectional buffers retain their vendor primitive dependencies.
`timescale 1ps/1ps
module system_xbar_1_axi_register_slice_v2_1_22_axic_register_slice__parameterized1_10
   (esc_aresetn_d_reg_0__0_7ec703c ,
    reset,
    m_valid_i_reg_inv_0,
    m_axi_bready,
    .s_axi_bready_0_sp_1(s_axi_bready_0_sn_1),
    esc_chosen_reg_0_cbf18f4 ,
    p_2_in,
    s_axi_bvalid,
    m_valid_i_reg_inv_1,
    s_axi_bresp,
    esc_gen_single_thread_active_target_hot_reg_0_ad29f1b ,
    m_valid_i_reg_inv_2,
    .s_axi_bready_1_sp_1(s_axi_bready_1_sn_1),
    esc_gen_arbiter_last_rr_hot_reg_2_331f69e ,
    m_valid_i_reg_inv_3,
    esc_m_ready_d_reg_0_0b6f615 ,
    valid_qual_i,
    m_valid_i_reg_inv_4,
    esc_s_axi_bready_0__0_3434b82 ,
    esc_s_axi_bready_0__1_d3d5ffa ,
    esc_m_payload_i_reg_13__0_806bc71 ,
    aclk,
    s_axi_bready,
    esc_s_axi_bvalid_2_c27c6a9 ,
    esc_s_axi_bvalid_2__0_818c752 ,
    esc_gen_single_thread_accept_limit00_in_035b519 ,
    chosen_3,
    s_axi_bresp_1_sp_1,
    esc_gen_single_thread_accept_limit00_in_4_2fd5f97 ,
    s_axi_bvalid_1_sp_1,
    esc_gen_single_thread_active_target_enc_5_e55385f ,
    esc_gen_single_thread_active_target_hot_6_39288f1 ,
    esc_gen_single_thread_active_target_enc_8_fb84636 ,
    esc_gen_single_thread_active_target_hot_9_c174533 ,
    esc_gen_arbiter_grant_hot_reg_0_a9342fe ,
    esc_gen_arbiter_grant_hot_reg_0__0_ecdaa7a ,
    esc_gen_arbiter_grant_hot_reg_0__1_19ecfc2 ,
    esc_gen_arbiter_grant_hot_reg_0__2_61247c6 ,
    st_aa_awtarget_hot,
    esc_gen_arbiter_grant_hot_2__i_2_0_b9e2d8c ,
    esc_gen_arbiter_grant_hot_2__i_2_1_41eea12 ,
    f_hot2enc_return,
    mi_awmaxissuing,
    esc_gen_single_thread_s_avalid_en_5fadb6c ,
    m_ready_d,
    s_axi_awvalid,
    esc_gen_arbiter_qual_reg_reg_2_6329989 ,
    esc_gen_single_thread_s_avalid_en_10_f6a2988 ,
    m_ready_d_11,
    esc_gen_arbiter_qual_reg_reg_1_28b1af8 ,
    esc_gen_arbiter_qual_reg_0__i_2_797ce0d ,
    esc_gen_master_slots_0__w_issuing_cnt_reg_1_c906b05 ,
    m_axi_awready,
    esc_gen_master_slots_0__w_issuing_cnt_reg_1__0_425b987 ,
    esc_gen_master_slots_0__w_issuing_cnt_reg_1__1_2989a68 ,
    m_valid_i_reg_inv_5,
    m_axi_bvalid,
    aresetn,
    esc_last_rr_hot_reg_0_b00b3ee ,
    p_2_in_12,
    esc_last_rr_hot_reg_0__0_0b10be6 ,
    esc_m_payload_i_reg_15__0_8da49f0 );
  output esc_aresetn_d_reg_0__0_7ec703c ;
  output reset;
  output m_valid_i_reg_inv_0;
  output [0:0]m_axi_bready;
  output esc_chosen_reg_0_cbf18f4 ;
  output p_2_in;
  output [2:0]s_axi_bvalid;
  output m_valid_i_reg_inv_1;
  output [5:0]s_axi_bresp;
  output esc_gen_single_thread_active_target_hot_reg_0_ad29f1b ;
  output m_valid_i_reg_inv_2;
  output esc_gen_arbiter_last_rr_hot_reg_2_331f69e ;
  output m_valid_i_reg_inv_3;
  output [1:0]esc_m_ready_d_reg_0_0b6f615 ;
  output [1:0]valid_qual_i;
  output [0:0]m_valid_i_reg_inv_4;
  output esc_s_axi_bready_0__0_3434b82 ;
  output esc_s_axi_bready_0__1_d3d5ffa ;
  output [11:0]esc_m_payload_i_reg_13__0_806bc71 ;
  input aclk;
  input [2:0]s_axi_bready;
  input [0:0]esc_s_axi_bvalid_2_c27c6a9 ;
  input esc_s_axi_bvalid_2__0_818c752 ;
  input esc_gen_single_thread_accept_limit00_in_035b519 ;
  input [0:0]chosen_3;
  input s_axi_bresp_1_sp_1;
  input esc_gen_single_thread_accept_limit00_in_4_2fd5f97 ;
  input s_axi_bvalid_1_sp_1;
  input esc_gen_single_thread_active_target_enc_5_e55385f ;
  input [0:0]esc_gen_single_thread_active_target_hot_6_39288f1 ;
  input esc_gen_single_thread_active_target_enc_8_fb84636 ;
  input [0:0]esc_gen_single_thread_active_target_hot_9_c174533 ;
  input esc_gen_arbiter_grant_hot_reg_0_a9342fe ;
  input esc_gen_arbiter_grant_hot_reg_0__0_ecdaa7a ;
  input esc_gen_arbiter_grant_hot_reg_0__1_19ecfc2 ;
  input esc_gen_arbiter_grant_hot_reg_0__2_61247c6 ;
  input [2:0]st_aa_awtarget_hot;
  input [0:0]esc_gen_arbiter_grant_hot_2__i_2_0_b9e2d8c ;
  input esc_gen_arbiter_grant_hot_2__i_2_1_41eea12 ;
  input [1:0]f_hot2enc_return;
  input [0:0]mi_awmaxissuing;
  input esc_gen_single_thread_s_avalid_en_5fadb6c ;
  input [0:0]m_ready_d;
  input [1:0]s_axi_awvalid;
  input esc_gen_arbiter_qual_reg_reg_2_6329989 ;
  input esc_gen_single_thread_s_avalid_en_10_f6a2988 ;
  input [0:0]m_ready_d_11;
  input esc_gen_arbiter_qual_reg_reg_1_28b1af8 ;
  input esc_gen_arbiter_qual_reg_0__i_2_797ce0d ;
  input esc_gen_master_slots_0__w_issuing_cnt_reg_1_c906b05 ;
  input [0:0]m_axi_awready;
  input [0:0]esc_gen_master_slots_0__w_issuing_cnt_reg_1__0_425b987 ;
  input esc_gen_master_slots_0__w_issuing_cnt_reg_1__1_2989a68 ;
  input m_valid_i_reg_inv_5;
  input [0:0]m_axi_bvalid;
  input aresetn;
  input esc_last_rr_hot_reg_0_b00b3ee ;
  input p_2_in_12;
  input esc_last_rr_hot_reg_0__0_0b10be6 ;
  input [15:0]esc_m_payload_i_reg_15__0_8da49f0 ;
  output s_axi_bready_0_sn_1;
  output s_axi_bready_1_sn_1;

  wire esc_const0_a0cf646 ;
  wire esc_const1_c064970 ;
  wire aclk;
  wire aresetn;
  wire esc_aresetn_d_reg_0__0_7ec703c ;
  wire [0:0]chosen_3;
  wire [1:0]f_hot2enc_return;
  wire [0:0]esc_gen_arbiter_grant_hot_2__i_2_0_b9e2d8c ;
  wire esc_gen_arbiter_grant_hot_2__i_2_1_41eea12 ;
  wire esc_gen_arbiter_grant_hot_2__i_4_n_0_8297fc4 ;
  wire esc_gen_arbiter_grant_hot_reg_0_a9342fe ;
  wire esc_gen_arbiter_grant_hot_reg_0__0_ecdaa7a ;
  wire esc_gen_arbiter_grant_hot_reg_0__1_19ecfc2 ;
  wire esc_gen_arbiter_grant_hot_reg_0__2_61247c6 ;
  wire esc_gen_arbiter_last_rr_hot_reg_2_331f69e ;
  wire esc_gen_arbiter_qual_reg_0__i_2_797ce0d ;
  wire esc_gen_arbiter_qual_reg_2__i_4__0_n_0_01601f2 ;
  wire esc_gen_arbiter_qual_reg_2__i_8_n_0_6423f8e ;
  wire esc_gen_arbiter_qual_reg_reg_2_6329989 ;
  wire esc_gen_master_slots_0__w_issuing_cnt_reg_1_c906b05 ;
  wire [0:0]esc_gen_master_slots_0__w_issuing_cnt_reg_1__0_425b987 ;
  wire esc_gen_master_slots_0__w_issuing_cnt_reg_1__1_2989a68 ;
  wire esc_gen_single_thread_accept_limit00_in_035b519 ;
  wire esc_gen_single_thread_active_target_enc_8_fb84636 ;
  wire [0:0]esc_gen_single_thread_active_target_hot_9_c174533 ;
  wire esc_gen_single_thread_s_avalid_en_5fadb6c ;
  wire esc_last_rr_hot_reg_0_b00b3ee ;
  wire esc_last_rr_hot_reg_0__0_0b10be6 ;
  wire [0:0]m_axi_awready;
  wire [0:0]m_axi_bready;
  wire [0:0]m_axi_bvalid;
  wire [11:0]esc_m_payload_i_reg_13__0_806bc71 ;
  wire [15:0]esc_m_payload_i_reg_15__0_8da49f0 ;
  wire [0:0]m_ready_d;
  wire [1:0]esc_m_ready_d_reg_0_0b6f615 ;
  wire m_valid_i_inv_i_1_n_0;
  wire m_valid_i_reg_inv_0;
  wire m_valid_i_reg_inv_1;
  wire m_valid_i_reg_inv_2;
  wire m_valid_i_reg_inv_3;
  wire [0:0]m_valid_i_reg_inv_4;
  wire m_valid_i_reg_inv_5;
  wire [0:0]mi_awmaxissuing;
  wire p_2_in;
  wire p_2_in_12;
  wire reset;
  wire [1:0]s_axi_awvalid;
  wire [2:0]s_axi_bready;
  wire esc_s_axi_bready_0__0_3434b82 ;
  wire esc_s_axi_bready_0__1_d3d5ffa ;
  wire s_axi_bready_0_sn_1;
  wire s_axi_bready_1_sn_1;
  wire s_axi_bresp_1_sn_1;
  wire [2:0]s_axi_bvalid;
  wire [0:0]esc_s_axi_bvalid_2_c27c6a9 ;
  wire esc_s_axi_bvalid_2__0_818c752 ;
  wire esc_s_axi_bvalid_2__INST_0_i_1_n_0_844c37e ;
  wire esc_s_axi_bvalid_2__INST_0_i_3_n_0_89e2c7d ;
  wire esc_s_axi_bvalid_2__INST_0_i_4_n_0_7420aa2 ;
  wire esc_s_axi_bvalid_2__INST_0_i_5_n_0_e2b859a ;
  wire s_ready_i_i_1__2_n_0;
  wire s_ready_i_i_3__0_n_0;
  wire [2:0]st_aa_awtarget_hot;
  wire [13:12]st_mr_bid_0;
  wire [1:0]valid_qual_i;

  assign esc_chosen_reg_0_cbf18f4  = s_axi_bvalid[0];
  assign s_axi_bresp[1] = s_axi_bresp_1_sn_1;
  assign s_axi_bresp[0] = s_axi_bresp_1_sn_1;
  assign s_axi_bresp_1_sn_1 = s_axi_bresp_1_sp_1;

  // Reconstructed GND: GND
  assign esc_const0_a0cf646 = 1'b0;

  // Reconstructed VCC: VCC
  assign esc_const1_c064970 = 1'b1;

  // Reconstructed LUT1: esc_aresetn_d_0__i_1_a2e3207
  assign reset = ~(aresetn);

  // Reconstructed FDRE: esc_aresetn_d_reg_0_e1dde1e
  reg recovered_4_q = 1'b0;
  assign esc_aresetn_d_reg_0__0_7ec703c = recovered_4_q;
  wire recovered_4_reset = ((reset)) && ((reset) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_4_reset || (((reset) === 1'bx) && (recovered_4_q == 1'b0))) recovered_4_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_4_q == (esc_const1_c064970)))) recovered_4_q <= (esc_const1_c064970);
  end

  // Reconstructed LUT5: esc_gen_arbiter_grant_hot_2__i_2_8da79a1
  assign m_valid_i_reg_inv_2 = ((esc_gen_arbiter_grant_hot_reg_0__2_61247c6) ? (((esc_gen_arbiter_grant_hot_reg_0__1_19ecfc2) ? (((esc_gen_arbiter_grant_hot_reg_0__0_ecdaa7a) ? (1'b0) : (esc_gen_arbiter_grant_hot_reg_0_a9342fe))) : (((esc_gen_arbiter_grant_hot_reg_0__0_ecdaa7a) ? (1'b0) : (((esc_gen_arbiter_grant_hot_reg_0_a9342fe) ? (esc_gen_arbiter_grant_hot_2__i_4_n_0_8297fc4) : (1'b0))))))) : (1'b0));

  // Reconstructed LUT5: esc_gen_arbiter_grant_hot_2__i_4_6eb2a02
  assign esc_gen_arbiter_grant_hot_2__i_4_n_0_8297fc4 = ((esc_gen_arbiter_grant_hot_2__i_2_1_41eea12) ? (~(st_aa_awtarget_hot[0])) : (((esc_gen_arbiter_grant_hot_2__i_2_0_b9e2d8c) ? (((m_valid_i_reg_inv_0) ? (1'b0) : (((s_axi_bready_1_sn_1) ? (~(st_aa_awtarget_hot[0])) : (1'b0))))) : (~(st_aa_awtarget_hot[0])))));

  // Reconstructed LUT6: esc_gen_arbiter_last_rr_hot_2__i_4_32bde48
  assign esc_gen_arbiter_last_rr_hot_reg_2_331f69e = ((m_valid_i_reg_inv_3) ? (((esc_gen_single_thread_s_avalid_en_5fadb6c) ? (((esc_gen_arbiter_qual_reg_2__i_4__0_n_0_01601f2) ? (1'b0) : (((st_aa_awtarget_hot[2]) ? (((mi_awmaxissuing) ? (1'b0) : (f_hot2enc_return[1]))) : (1'b0))))) : (1'b0))) : (((esc_gen_single_thread_s_avalid_en_5fadb6c) ? (((esc_gen_arbiter_qual_reg_2__i_4__0_n_0_01601f2) ? (1'b0) : (((st_aa_awtarget_hot[2]) ? (((mi_awmaxissuing) ? (1'b0) : (f_hot2enc_return[1]))) : (f_hot2enc_return[1]))))) : (1'b0))));

  // Reconstructed LUT3: esc_gen_arbiter_qual_reg_2__i_1_c03ee58
  assign esc_m_ready_d_reg_0_0b6f615 [1] = ((s_axi_awvalid[1]) ? (((m_ready_d) ? (1'b1) : (valid_qual_i[1]))) : (1'b1));

  // Reconstructed LUT6: esc_gen_arbiter_qual_reg_2__i_2_ed6406b
  assign valid_qual_i[1] = ((mi_awmaxissuing) ? (((esc_gen_arbiter_qual_reg_2__i_4__0_n_0_01601f2) ? (1'b0) : (((esc_gen_arbiter_qual_reg_reg_2_6329989) ? (((st_aa_awtarget_hot[2]) ? (1'b0) : (~(m_valid_i_reg_inv_3)))) : (((esc_gen_single_thread_active_target_enc_8_fb84636) ? (1'b0) : (((st_aa_awtarget_hot[2]) ? (1'b0) : (~(m_valid_i_reg_inv_3)))))))))) : (((esc_gen_arbiter_qual_reg_2__i_4__0_n_0_01601f2) ? (1'b0) : (((esc_gen_arbiter_qual_reg_reg_2_6329989) ? (((st_aa_awtarget_hot[2]) ? (1'b1) : (~(m_valid_i_reg_inv_3)))) : (((esc_gen_single_thread_active_target_enc_8_fb84636) ? (st_aa_awtarget_hot[2]) : (((st_aa_awtarget_hot[2]) ? (1'b0) : (~(m_valid_i_reg_inv_3)))))))))));

  // Reconstructed LUT5: esc_gen_arbiter_qual_reg_2__i_3__0_84514e0
  assign m_valid_i_reg_inv_3 = ((esc_gen_arbiter_qual_reg_2__i_8_n_0_6423f8e) ? (((m_valid_i_reg_inv_0) ? (esc_gen_arbiter_qual_reg_0__i_2_797ce0d) : (1'b0))) : (((s_axi_bready[0]) ? (((s_ready_i_i_3__0_n_0) ? (((m_valid_i_reg_inv_0) ? (esc_gen_arbiter_qual_reg_0__i_2_797ce0d) : (1'b0))) : (esc_gen_arbiter_qual_reg_0__i_2_797ce0d))) : (esc_gen_arbiter_qual_reg_0__i_2_797ce0d))));

  // Reconstructed LUT6: esc_gen_arbiter_qual_reg_2__i_4__0_df61404
  assign esc_gen_arbiter_qual_reg_2__i_4__0_n_0_01601f2 = ((s_axi_bready[2]) ? (((esc_gen_single_thread_accept_limit00_in_035b519) ? (((esc_s_axi_bvalid_2__0_818c752) ? (((esc_s_axi_bvalid_2_c27c6a9) ? (((esc_s_axi_bvalid_2__INST_0_i_1_n_0_844c37e) ? (m_valid_i_reg_inv_0) : (1'b1))) : (1'b0))) : (((esc_s_axi_bvalid_2__INST_0_i_1_n_0_844c37e) ? (m_valid_i_reg_inv_0) : (1'b1))))) : (1'b0))) : (esc_gen_single_thread_accept_limit00_in_035b519));

  // Reconstructed LUT4: esc_gen_arbiter_qual_reg_2__i_8_601bbe3
  assign esc_gen_arbiter_qual_reg_2__i_8_n_0_6423f8e = ((s_axi_bready[2]) ? (((esc_gen_single_thread_active_target_hot_9_c174533) ? (((esc_s_axi_bvalid_2__INST_0_i_3_n_0_89e2c7d) ? (1'b0) : (st_mr_bid_0[13]))) : (1'b0))) : (1'b0));

  // Reconstructed LUT6: esc_gen_master_slots_0__w_issuing_cnt_4__i_1_dae59db
  assign m_valid_i_reg_inv_4 = ((esc_gen_master_slots_0__w_issuing_cnt_reg_1__1_2989a68) ? (((m_valid_i_reg_inv_0) ? (1'b0) : (((s_axi_bready_1_sn_1) ? (esc_gen_master_slots_0__w_issuing_cnt_reg_1_c906b05) : (1'b0))))) : (((esc_gen_master_slots_0__w_issuing_cnt_reg_1__0_425b987) ? (((m_axi_awready) ? (((m_valid_i_reg_inv_0) ? (1'b1) : (~(s_axi_bready_1_sn_1)))) : (((m_valid_i_reg_inv_0) ? (1'b0) : (((s_axi_bready_1_sn_1) ? (esc_gen_master_slots_0__w_issuing_cnt_reg_1_c906b05) : (1'b0))))))) : (((m_valid_i_reg_inv_0) ? (1'b0) : (((s_axi_bready_1_sn_1) ? (esc_gen_master_slots_0__w_issuing_cnt_reg_1_c906b05) : (1'b0))))))));

  // Reconstructed LUT2: esc_gen_multi_thread_active_cnt_59__i_3_4a33d36
  assign s_axi_bready_0_sn_1 = ((s_axi_bready[0]) ? (~(s_axi_bvalid[0])) : (1'b1));

  // Reconstructed LUT6: esc_gen_multi_thread_arbiter_resp_inst_last_rr_hot_0__i_1__0_c5545cb
  assign esc_s_axi_bready_0__1_d3d5ffa = ((esc_last_rr_hot_reg_0__0_0b10be6) ? (((m_valid_i_reg_inv_1) ? (((p_2_in_12) ? (1'b1) : (((esc_last_rr_hot_reg_0_b00b3ee) ? (((s_axi_bvalid[0]) ? (~(s_axi_bready[0])) : (1'b0))) : (1'b1))))) : (((esc_last_rr_hot_reg_0_b00b3ee) ? (((s_axi_bvalid[0]) ? (~(s_axi_bready[0])) : (1'b0))) : (1'b1))))) : (((m_valid_i_reg_inv_1) ? (((p_2_in_12) ? (((s_axi_bvalid[0]) ? (s_axi_bready[0]) : (1'b1))) : (1'b0))) : (1'b0))));

  // Reconstructed LUT6: esc_gen_multi_thread_arbiter_resp_inst_last_rr_hot_1__i_1__0_a5b95da
  assign esc_s_axi_bready_0__0_3434b82 = ((esc_last_rr_hot_reg_0__0_0b10be6) ? (((m_valid_i_reg_inv_1) ? (((p_2_in_12) ? (((esc_last_rr_hot_reg_0_b00b3ee) ? (1'b1) : (((s_axi_bvalid[0]) ? (~(s_axi_bready[0])) : (1'b0))))) : (((esc_last_rr_hot_reg_0_b00b3ee) ? (((s_axi_bvalid[0]) ? (s_axi_bready[0]) : (1'b1))) : (1'b0))))) : (((p_2_in_12) ? (1'b1) : (((esc_last_rr_hot_reg_0_b00b3ee) ? (((s_axi_bvalid[0]) ? (s_axi_bready[0]) : (1'b1))) : (1'b0))))))) : (((m_valid_i_reg_inv_1) ? (((p_2_in_12) ? (((s_axi_bvalid[0]) ? (~(s_axi_bready[0])) : (1'b0))) : (1'b0))) : (p_2_in_12))));

  // Reconstructed LUT5: esc_gen_single_thread_accept_cnt_4__i_3__2_9ee81b9
  assign p_2_in = ((s_axi_bready[2]) ? (((esc_s_axi_bvalid_2__0_818c752) ? (((esc_s_axi_bvalid_2_c27c6a9) ? (((esc_s_axi_bvalid_2__INST_0_i_1_n_0_844c37e) ? (~(m_valid_i_reg_inv_0)) : (1'b0))) : (1'b1))) : (((esc_s_axi_bvalid_2__INST_0_i_1_n_0_844c37e) ? (~(m_valid_i_reg_inv_0)) : (1'b0))))) : (1'b0));

  // Reconstructed FDRE: esc_m_payload_i_reg_10_ffe4795
  reg recovered_18_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [8] = recovered_18_q;
  wire recovered_18_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_18_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_18_q == 1'b0))) recovered_18_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_18_q == (esc_m_payload_i_reg_15__0_8da49f0 [10])))) recovered_18_q <= (esc_m_payload_i_reg_15__0_8da49f0 [10]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_11_41a697a
  reg recovered_19_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [9] = recovered_19_q;
  wire recovered_19_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_19_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_19_q == 1'b0))) recovered_19_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_19_q == (esc_m_payload_i_reg_15__0_8da49f0 [11])))) recovered_19_q <= (esc_m_payload_i_reg_15__0_8da49f0 [11]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_12_69d425e
  reg recovered_20_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [10] = recovered_20_q;
  wire recovered_20_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_20_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_20_q == 1'b0))) recovered_20_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_20_q == (esc_m_payload_i_reg_15__0_8da49f0 [12])))) recovered_20_q <= (esc_m_payload_i_reg_15__0_8da49f0 [12]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_13_5fdb661
  reg recovered_21_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [11] = recovered_21_q;
  wire recovered_21_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_21_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_21_q == 1'b0))) recovered_21_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_21_q == (esc_m_payload_i_reg_15__0_8da49f0 [13])))) recovered_21_q <= (esc_m_payload_i_reg_15__0_8da49f0 [13]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_15_33b4ebb
  reg recovered_22_q = 1'b0;
  assign st_mr_bid_0[13] = recovered_22_q;
  wire recovered_22_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_22_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_22_q == 1'b0))) recovered_22_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_22_q == (esc_m_payload_i_reg_15__0_8da49f0 [15])))) recovered_22_q <= (esc_m_payload_i_reg_15__0_8da49f0 [15]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_2_3bf2adb
  reg recovered_23_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [0] = recovered_23_q;
  wire recovered_23_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_23_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_23_q == 1'b0))) recovered_23_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_23_q == (esc_m_payload_i_reg_15__0_8da49f0 [2])))) recovered_23_q <= (esc_m_payload_i_reg_15__0_8da49f0 [2]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_3_3eab624
  reg recovered_24_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [1] = recovered_24_q;
  wire recovered_24_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_24_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_24_q == 1'b0))) recovered_24_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_24_q == (esc_m_payload_i_reg_15__0_8da49f0 [3])))) recovered_24_q <= (esc_m_payload_i_reg_15__0_8da49f0 [3]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_4_60ef705
  reg recovered_25_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [2] = recovered_25_q;
  wire recovered_25_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_25_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_25_q == 1'b0))) recovered_25_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_25_q == (esc_m_payload_i_reg_15__0_8da49f0 [4])))) recovered_25_q <= (esc_m_payload_i_reg_15__0_8da49f0 [4]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_5_6200800
  reg recovered_26_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [3] = recovered_26_q;
  wire recovered_26_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_26_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_26_q == 1'b0))) recovered_26_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_26_q == (esc_m_payload_i_reg_15__0_8da49f0 [5])))) recovered_26_q <= (esc_m_payload_i_reg_15__0_8da49f0 [5]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_6_8d56399
  reg recovered_27_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [4] = recovered_27_q;
  wire recovered_27_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_27_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_27_q == 1'b0))) recovered_27_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_27_q == (esc_m_payload_i_reg_15__0_8da49f0 [6])))) recovered_27_q <= (esc_m_payload_i_reg_15__0_8da49f0 [6]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_7_ba4380d
  reg recovered_28_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [5] = recovered_28_q;
  wire recovered_28_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_28_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_28_q == 1'b0))) recovered_28_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_28_q == (esc_m_payload_i_reg_15__0_8da49f0 [7])))) recovered_28_q <= (esc_m_payload_i_reg_15__0_8da49f0 [7]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_8_f05b222
  reg recovered_29_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [6] = recovered_29_q;
  wire recovered_29_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_29_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_29_q == 1'b0))) recovered_29_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_29_q == (esc_m_payload_i_reg_15__0_8da49f0 [8])))) recovered_29_q <= (esc_m_payload_i_reg_15__0_8da49f0 [8]);
  end

  // Reconstructed FDRE: esc_m_payload_i_reg_9_9458063
  reg recovered_30_q = 1'b0;
  assign esc_m_payload_i_reg_13__0_806bc71 [7] = recovered_30_q;
  wire recovered_30_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_30_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_30_q == 1'b0))) recovered_30_q <= 1'b0;
    else if ((m_valid_i_reg_inv_0) || ((m_valid_i_reg_inv_0) === 1'bz) || (((m_valid_i_reg_inv_0) === 1'bx) && (recovered_30_q == (esc_m_payload_i_reg_15__0_8da49f0 [9])))) recovered_30_q <= (esc_m_payload_i_reg_15__0_8da49f0 [9]);
  end

  // Reconstructed LUT4: m_valid_i_inv_i_1
  assign m_valid_i_inv_i_1_n_0 = ((m_valid_i_reg_inv_5) ? (((m_axi_bvalid) ? (((m_axi_bready) ? (1'b0) : (s_axi_bready_1_sn_1))) : (((m_axi_bready) ? (1'b1) : (s_axi_bready_1_sn_1))))) : (1'b1));

  // Reconstructed FDRE: m_valid_i_reg_inv
  reg recovered_32_q = 1'b1;
  assign m_valid_i_reg_inv_0 = recovered_32_q;
  wire recovered_32_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_32_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_32_q == 1'b0))) recovered_32_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_32_q == (m_valid_i_inv_i_1_n_0)))) recovered_32_q <= (m_valid_i_inv_i_1_n_0);
  end

  // Reconstructed LUT3: esc_s_axi_bvalid_0__INST_0_i_1_6e1e201
  assign s_axi_bvalid[0] = ((s_axi_bresp_1_sn_1) ? (1'b1) : (((chosen_3) ? (m_valid_i_reg_inv_1) : (1'b0))));

  // Reconstructed LUT3: esc_s_axi_bvalid_0__INST_0_i_2_29b91e8
  assign m_valid_i_reg_inv_1 = ((st_mr_bid_0[13]) ? (((esc_s_axi_bvalid_2__INST_0_i_3_n_0_89e2c7d) ? (~(m_valid_i_reg_inv_0)) : (1'b0))) : (~(m_valid_i_reg_inv_0)));

  // Reconstructed LUT4: esc_s_axi_bvalid_2__INST_0_ec21cc1
  assign s_axi_bvalid[2] = ((esc_s_axi_bvalid_2__0_818c752) ? (((esc_s_axi_bvalid_2_c27c6a9) ? (((esc_s_axi_bvalid_2__INST_0_i_1_n_0_844c37e) ? (~(m_valid_i_reg_inv_0)) : (1'b0))) : (1'b1))) : (((esc_s_axi_bvalid_2__INST_0_i_1_n_0_844c37e) ? (~(m_valid_i_reg_inv_0)) : (1'b0))));

  // Reconstructed LUT3: esc_s_axi_bvalid_2__INST_0_i_1_4dfda9e
  assign esc_s_axi_bvalid_2__INST_0_i_1_n_0_844c37e = ((st_mr_bid_0[13]) ? (((esc_s_axi_bvalid_2__INST_0_i_3_n_0_89e2c7d) ? (1'b0) : (esc_gen_single_thread_active_target_hot_9_c174533))) : (1'b0));

  // Reconstructed LUT6: esc_s_axi_bvalid_2__INST_0_i_3_00bcdd3
  assign esc_s_axi_bvalid_2__INST_0_i_3_n_0_89e2c7d = ((esc_s_axi_bvalid_2__INST_0_i_5_n_0_e2b859a) ? (1'b1) : (((esc_m_payload_i_reg_13__0_806bc71 [6]) ? (1'b1) : (((esc_m_payload_i_reg_13__0_806bc71 [7]) ? (1'b1) : (((esc_m_payload_i_reg_13__0_806bc71 [4]) ? (1'b1) : (((esc_m_payload_i_reg_13__0_806bc71 [5]) ? (1'b1) : (esc_s_axi_bvalid_2__INST_0_i_4_n_0_7420aa2))))))))));

  // Reconstructed LUT4: esc_s_axi_bvalid_2__INST_0_i_4_b993c52
  assign esc_s_axi_bvalid_2__INST_0_i_4_n_0_7420aa2 = ((esc_m_payload_i_reg_13__0_806bc71 [10]) ? (1'b1) : (((esc_m_payload_i_reg_13__0_806bc71 [11]) ? (1'b1) : (((esc_m_payload_i_reg_13__0_806bc71 [8]) ? (1'b1) : (esc_m_payload_i_reg_13__0_806bc71 [9]))))));

  // Reconstructed LUT4: esc_s_axi_bvalid_2__INST_0_i_5_af5c71a
  assign esc_s_axi_bvalid_2__INST_0_i_5_n_0_e2b859a = ((esc_m_payload_i_reg_13__0_806bc71 [2]) ? (1'b1) : (((esc_m_payload_i_reg_13__0_806bc71 [3]) ? (1'b1) : (((esc_m_payload_i_reg_13__0_806bc71 [0]) ? (1'b1) : (esc_m_payload_i_reg_13__0_806bc71 [1]))))));

  // Reconstructed LUT5: s_ready_i_i_1__2
  assign s_ready_i_i_1__2_n_0 = ((esc_aresetn_d_reg_0__0_7ec703c) ? (((m_axi_bvalid) ? (((m_valid_i_reg_inv_0) ? (~(m_valid_i_reg_inv_5)) : (((s_axi_bready_1_sn_1) ? (1'b1) : (~(m_valid_i_reg_inv_5)))))) : (((m_valid_i_reg_inv_0) ? (1'b1) : (((s_axi_bready_1_sn_1) ? (1'b1) : (~(m_valid_i_reg_inv_5)))))))) : (1'b0));

  // Reconstructed LUT4: s_ready_i_i_2__2
  assign s_axi_bready_1_sn_1 = ((esc_s_axi_bvalid_2__INST_0_i_1_n_0_844c37e) ? (((s_axi_bready[2]) ? (1'b1) : (((s_axi_bready[0]) ? (s_ready_i_i_3__0_n_0) : (1'b0))))) : (((s_axi_bready[0]) ? (s_ready_i_i_3__0_n_0) : (1'b0))));

  // Reconstructed LUT4: s_ready_i_i_3__0
  assign s_ready_i_i_3__0_n_0 = ((m_valid_i_reg_inv_0) ? (1'b0) : (((esc_s_axi_bvalid_2__INST_0_i_3_n_0_89e2c7d) ? (chosen_3) : (((st_mr_bid_0[13]) ? (1'b0) : (chosen_3))))));

  // Reconstructed FDRE: s_ready_i_reg
  reg recovered_43_q = 1'b0;
  assign m_axi_bready = recovered_43_q;
  wire recovered_43_reset = ((esc_const0_a0cf646)) && ((esc_const0_a0cf646) !== 1'bz);
  always @(posedge aclk) begin
    if (recovered_43_reset || (((esc_const0_a0cf646) === 1'bx) && (recovered_43_q == 1'b0))) recovered_43_q <= 1'b0;
    else if ((esc_const1_c064970) || ((esc_const1_c064970) === 1'bz) || (((esc_const1_c064970) === 1'bx) && (recovered_43_q == (s_ready_i_i_1__2_n_0)))) recovered_43_q <= (s_ready_i_i_1__2_n_0);
  end

endmodule
